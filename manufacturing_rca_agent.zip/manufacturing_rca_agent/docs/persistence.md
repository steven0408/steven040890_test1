# Persistence Architecture (Phase 8A / 8B)

Phase 8A: no real PostgreSQL, everything below is a provider-neutral
model/contract, backed by InMemory implementations. Phase 8B (section 11)
adds a real PostgreSQL adapter implementing the exact same Protocols --
still never connected to a real/remote database in this codebase's own
test suite, only to an ephemeral local container used for one-time
verification (never committed as a running fixture).

## 1. Checkpoint persistence vs. analysis/audit persistence

These are two different responsibilities with two different data models,
even if a future deployment happens to point both at the same PostgreSQL
instance:

| | Checkpoint persistence | Analysis/Audit persistence |
|---|---|---|
| Answers | "Where is the Agent *right now*?" | "What did the Agent *find/do*?" |
| Owner | LangGraph's own checkpointer (`BaseCheckpointSaver`) | This codebase's repositories (`agent/persistence/`) |
| Unit | thread_id / checkpoint_ns / channel values | Run / Module / Objective / Evidence / Finding / ... |
| Lifecycle | Every superstep, including mid-run pending Sends | Once a value is final (a completed Objective, a confirmed Finding, ...) |
| Implementation this phase | `InMemorySaver` (development) | InMemory repositories (this phase); PostgreSQL-compatible saver + repositories are separate future work |

**Phase 8A does not reimplement LangGraph checkpoint internals.** The only
seam this phase defines is a config contract for which saver a deployment
uses:

```python
class CheckpointerProfile(str, Enum):
    DEVELOPMENT_IN_MEMORY = "development_in_memory"   # InMemorySaver -- what every test in this suite uses today
    PRODUCTION_POSTGRES = "production_postgres"        # a PostgreSQL-compatible LangGraph saver -- not implemented this phase
```

Whatever the checkpointer profile, the analysis/audit repositories in this
document are a **separate write path** -- `RunPersistenceWriter` runs
*after* a module/run reaches a terminal state, projecting from `AgentState`
into the repositories below; it never reads or writes a LangGraph
checkpoint.

## 2. Four persistence domains (item 1)

| Domain | Question | Owner |
|---|---|---|
| A. Runtime | "Where is execution right now?" | LangGraph checkpointer (see above) -- out of scope for the repositories below |
| B. Analysis | "What did the Agent find?" | `RunRepository` (`agent/persistence/run_repository.py`) |
| C. Audit | "How did the Agent analyze it?" | `AuditRepository` (`agent/persistence/audit_repository.py`) -- composes existing sinks |
| D. Learning | "What new Candidate did the Agent propose?" | `LearningCandidateRepository` (`agent/persistence/learning_repository.py`) -- composes the existing `LearningCandidateSink` |

Never one giant `AgentState` JSON table -- each domain has its own
repository, and within Analysis/Audit, relational-core-plus-JSONB-extension
fields (never full normalization, never a single JSON dump) -- see each
model's own docstring in `agent/persistence/records.py`.

## 3. Reused vs. new models

Reused as-is (already relational-core-shaped): `ObjectiveRecord`,
`ToolCallRecord`, `LLMCallRecord`, `ContextBuildRecord`,
`SynthesisContextBuildRecord`, `PlannerDecisionRecord`,
`SynthesisGenerationRecord`, `EvaluationRecord`, `RunEvaluation`,
`HumanFeedback`, `LearningCandidate`, `LearningEvidenceLink`,
`CandidateReview`, `HandoffPackage`.

New this phase (`agent/persistence/records.py`): `RunRecord`,
`ModuleRunRecord`, `EvidenceRecord`, `FindingRecord`,
`FindingEvidenceLink`, `RootCauseRecord`, `RootCauseFindingLink`,
`ValidatedKnowledgeRecord` (future-only, unwritten this phase).

## 4. Runtime-lineage gaps closed by Phase 8A-1

Phase 8A originally reported two timestamp fields the persistence schema
wanted with no runtime source: `ModuleState` had no module-level
`started_at`/`completed_at`, and `AgentState` had no run-level
`completed_at` (only `UserRequest.submitted_at` as a weak `started_at`
proxy). Phase 8A-1 (Runtime Lifecycle Instrumentation) added real fields
for both -- see `agent/state/state.py`/`agent/state/models.py` and the
Phase 8A-1 report for the full write-boundary and replay-semantics
discussion. `RunRecord.started_at/completed_at` and
`ModuleRunRecord.started_at/completed_at` are now sourced directly from
`AgentState.started_at/completed_at` and `ModuleState.started_at/
completed_at`, not proxies. `ModuleRunRecord.started_at` stays `None`
only for a module that ends up `SKIPPED` (Option A: "SKIPPED means never
actually started" -- though no node in this codebase currently produces
that status). Both remain honestly `Optional` rather than backfilled with
a fabricated value for a run/module that hasn't reached its terminal
timestamp yet.

## 5. Repository boundaries (item 15)

- **RunRepository** -- Run, ModuleRun, Objective, Evidence, Finding
  (+ FindingEvidenceLink), RootCause (+ RootCauseFindingLink),
  HandoffPackage. One repository: these are read/written together as one
  aggregate (a Run and everything discovered within it), not because a
  single large interface is easier to write.
- **AuditRepository** -- a compose-not-duplicate bundle of every existing
  audit Sink (`LLMUsageSink`, `ContextAuditSink`,
  `SynthesisContextAuditSink`, `PlannerDecisionAuditSink`,
  `SynthesisGenerationAuditSink`, `ToolCallAuditSink`, `HumanAuditSink`,
  `EvaluationAuditSink`) plus one new `RunEvaluationStore` (no prior home
  existed for the metrics themselves, only their lineage record).
- **HumanFeedbackRepository** -- no wrapper; `HumanFeedbackSink` already
  *is* this repository (`list_for_run`/`list_for_target`/
  `latest_for_target` already cover item 19's historical-query needs).
- **LearningCandidateRepository** -- a thin compose-not-duplicate wrapper
  around `LearningCandidateSink`, adding exactly one new capability
  (`get_candidate_with_evidence`) the sink didn't already have.

## 6. Idempotency strategy (item 18)

- **Logical/analysis records** (Run, ModuleRun, Objective, Evidence,
  Finding, RootCause, RunEvaluation, LearningCandidate): keyed by their
  own stable domain id in a dict -- `save_*`/`record`/`update` is always an
  **upsert**. Persisting the same completed run twice overwrites the same
  rows, never doubles them (`tests/test_persistence_run_repository.py::
  test_persisting_the_same_run_twice_never_duplicates_logical_records`).
- **Append-only events** (physical `ToolCallRecord`, `HumanFeedback`,
  `LearningEvidenceLink`): never deduplicated by content -- each call to
  `record()`/`record_evidence_link()` adds a new row, matching Phase
  5B-1.1/7B/7C's own append-only discipline for these exact record types.
  Two physical Tool attempts persist as two rows; two Human Feedback
  submissions persist as two rows.

## 7. Transaction boundary (item 16)

`PersistenceUnitOfWork` (`agent/persistence/unit_of_work.py`) is a staged-
write buffer: `stage(fn)` queues a zero-arg write; nothing touches a
repository until `commit()` runs the queue. An exception inside the `with`
block, an explicit `rollback()`, or simply exiting the block without ever
calling `commit()` all have the same effect -- the queue is discarded and
the repositories were never touched. This is the InMemory-correct shape of
"rollback": since nothing was written until commit, discarding the pending
queue *is* the rollback, with no snapshot/restore machinery needed. A real
PostgreSQL unit of work would replace `commit()`'s body with a real
`connection.commit()` without changing this class's external contract.

## 8. RunPersistenceWriter (item 17)

The only downstream service that projects `AgentState` (+ optionally a
`RunEvaluation`, `list[HumanFeedback]`, `list[LearningCandidate]`) into
repository writes, via a `PersistenceUnitOfWork`. No LangGraph node writes
to a repository directly; generic node code is untouched by this phase.
Root-cause projection reuses `ModuleHandoffBuilder` (Phase 6A) rather than
re-deriving "which findings count as a root cause" a second time.

## 9. Retention / sensitive-data policy (item 21)

`PersistenceSettings` (`agent/persistence/settings.py`): `save_raw_prompt`
(default `False` -- moot today, since `LLMCallRecord`/`ContextBuildRecord`
never had a prompt field to begin with), `save_raw_tool_payload` (default
`False` -- actively enforced: `RunPersistenceWriter` redacts
`EvidenceRecord.structured_payload` to `None` unless explicitly opted in,
keeping only `payload_type`), `audit_retention_days`, `analysis_retention_days`
(contract only, no cleanup job implemented). Secrets follow the same
"config carries the env-var *name*, never the value" discipline
`DataSourceConfig` already established in Phase 5D.

## 10. Schema versioning (item 22)

Every genuinely new top-level record (`RunRecord`, `ModuleRunRecord`,
`EvidenceRecord`, `FindingRecord`, `RootCauseRecord`,
`ValidatedKnowledgeRecord`) carries `schema_version: str = "1"`.
`RunEvaluation` and `LearningCandidate` (existing top-level aggregates,
extended this phase) also gained `schema_version`; `HumanFeedback` already
had an equivalent (`feedback_version`, Phase 7B) and was left unchanged.
The remaining reused audit records (`ToolCallRecord`, `LLMCallRecord`,
`ContextBuildRecord`, `PlannerDecisionRecord`, `SynthesisGenerationRecord`,
`EvaluationRecord`) were **not** individually given a `schema_version`
field this phase -- a deliberate scope decision, versioned instead at the
table/repository level for now; see the Phase 8A report for the explicit
trade-off.

## 11. PostgreSQL adapter (Phase 8B)

Package: `agent/persistence/postgres/` -- `config.py` (`PostgresSettings`,
env-var-*name*-only), `errors.py` (three typed exceptions), `connection.py`
(`PostgresConnectionFactory`, `allow_test_database_only`),
`migrations/0001_initial.sql` + `schema.py` (DDL + `apply_schema`),
`mapping.py` (every `Record <-> SQL row` function), `repositories.py`
(one class per Phase 8A Protocol), `unit_of_work.py`
(`PostgresPersistenceUnitOfWork`). `agent/persistence/factory.py` is the
new backend-selection seam (`PersistenceBackendConfig.backend`: `memory` |
`postgres`), consumed by `agent/bootstrap.py`'s `AppConfig.persistence`
(defaults to `memory`, so pre-8B callers are unaffected).

**Driver**: `psycopg` 3 (`postgres` optional extra), raw parameterized SQL
via named placeholders (`%(col)s`) -- no ORM, no domain-model mirror.
Repositories depend only on a minimal duck-typed connection surface
(`.execute(sql, params) -> cursor` with `.fetchone()`/`.fetchall()`,
`.commit()`/`.rollback()`), so `tests/postgres_fake.py::FakeConnection`
exercises every repository/mapping/UoW test without `psycopg` installed.

**FK strategy**: hard FKs only within the Run/Module/Objective/Evidence/
Finding/RootCause/HandoffPackage aggregate (always written in dependency
order inside one `RunPersistenceWriter` transaction); every audit table
and the post-run Evaluation/Feedback/Learning tables keep `run_id` as an
indexed *conceptual* lineage column with no hard FK, since those are
written live during a run or in a separate later transaction/process --
a hard FK there would wrongly couple write ordering across independent
call sites.

**Connection lifetime**: live/event sinks (LLM/Tool/Planner/Context/
Human-audit, HumanFeedback) use one **autocommit** connection each, so
every `.record()` is immediately durable with no caller-managed
transaction. `RunRepository` shares one long-lived non-autocommit
connection with `PostgresPersistenceUnitOfWork` (the only class allowed
to call `.commit()`/`.rollback()` on it) -- but `RunRepository`'s own
*read* methods (`get_run`, `list_*`, ...) are never staged through the
UoW, so each one commits immediately after fetching (see
`repositories.py::PostgresRunRepository`'s docstring). This exact gap --
a read leaving an implicit transaction open indefinitely -- was caught
empirically during this phase's local-Postgres verification: an
uncommitted `SELECT` deadlocked a later `CREATE INDEX IF NOT EXISTS` on
the same table. Not a design review finding; a real bug the verification
step existed to catch.

**Test safety**: `connection.py::allow_test_database_only()` refuses to
proceed unless `PostgresSettings.require_test_database` is explicitly set
AND the *resolved* database name contains `test` and not `prod` --
checked against the actual resolved name, not merely the caller's claim.
`tests/test_persistence_postgres_integration.py` is the only file that
touches a real database, gated behind `@pytest.mark.postgres` and a
`TEST_POSTGRES_DSN` env var that is unset (and therefore skipped) by
default; it was verified once against an ephemeral local
`postgres:16-alpine` Docker container (network name `rca_pg_test_net`,
database `rca_test`) created and destroyed solely for that verification,
never against any real/remote host.

## 12. Objective Scope Persistence (Phase WB-2B.2)

Four responsibilities, kept structurally distinct all the way through
persistence, never merged:

| Concept | Answers | Where it lives |
|---|---|---|
| `ObjectiveAction` | WHAT kind of analytical action/depth | `Objective.action` / `ObjectiveRecord.action` |
| `capability_key` | WHICH domain capability was used | `Objective.capability_key` / `ObjectiveRecord.capability_key` |
| `TargetRef` | WHO/WHAT was primarily under investigation | `Objective.target_ref` / `ObjectiveRecord.target_ref` |
| `ObjectiveScope` | The query/analytical BOUNDARY (date, filters, group_by) | `Objective.scope` / `ObjectiveRecord.scope` |

`ObjectiveScope` (`agent/state/scope.py`) is a structured representation
of **query intent**, persisted for audit/debugging/historical
reconstruction/evaluation traceability -- e.g. "this run's ASE03 WIP Hold
objective was scoped to `snapshot_date=2026-08-12`, `plant=ASE03`."
Persistence never turns that stored intent back into a live query: a
Skill/Tool re-executing against a DataSource is the only thing that ever
touches manufacturing data. This agent-persistence database has no
scope-to-SQL translator anywhere in it, and must never grow one -- adding
such a converter would make this DB a manufacturing-data query engine
instead of an audit trail, and would let LLM-generated `dimension`/
`operator`/`value` strings reach a real `WHERE` clause. See
`agent/persistence/records.py`/`repositories.py`'s own guard test
(`test_no_scope_to_sql_where_clause_converter_exists_in_this_codebase`).

**Projection, never interpretation**: `ObjectiveRecord.scope` is built by
copying `Objective.scope` verbatim in exactly one place --
`agent/graph/nodes/module/module_planner.py::_build_dispatch_update`
(the same function that already projects `action`/`capability_key`/
`target_ref`). `RunPersistenceWriter` never re-derives, re-infers, or
guesses a scope from `target_ref`/`capability_key` -- it only ever
forwards whatever `ObjectiveRecord` a module's `objective_history`
already contains.

**Storage strategy**: `objectives.scope JSONB`, nullable. Rejected
alternative: a column per manufacturing dimension (`plant`, `operation`,
`customer`, ...) -- `ScopeFilter.dimension` is intentionally an open
vocabulary Core has no opinion on, so flattening it into columns would
require a schema migration for every new domain dimension and would leak
manufacturing semantics into Core persistence. A single `JSONB` column
matches `ObjectiveScope`'s own generic, structured shape and needs zero
schema changes when a future domain (Yield, Q-Time, Cycle Time, ...)
introduces dimensions this file has never heard of.

**None vs. empty**: `Objective.scope = None` ("no scope was ever
supplied") and `Objective.scope = ObjectiveScope()` ("a scope object was
supplied, but every field inside it is empty/default") are different
values, preserved as different values all the way through persistence --
`None` maps to a SQL `NULL`; `ObjectiveScope()` maps to a real (non-NULL)
JSONB value (`{"time": null, "filters": [], "group_by": []}`). Neither is
ever collapsed into the other.

**PostgreSQL migration**: added directly to `migrations/0001_initial.sql`
(a new nullable `scope JSONB` column on `objectives`), not a new
`0002_*.sql` file -- this project has never been deployed against a real
Postgres instance (Phase 8B's own local-Docker verification was ephemeral
and torn down), so there is no existing data a real migration path would
need to preserve. The same policy Phase WB-2B.1 already established for
`capability_key`/`proposed_capability_key`.

**Bug found and fixed this phase**: Phase WB-2B.1 had already added
`capability_key`/`proposed_capability_key` to `mapping.py`'s
`objective_to_row`/`planner_decision_to_row` and to the SQL schema, but
never added them to `repositories.py`'s `_OBJECTIVE_COLUMNS`/
`_PLANNER_DECISION_COLUMNS` lists -- the actual `INSERT`/`UPDATE`
statement `_upsert_sql()` builds only ever includes columns named in that
list, so the real PostgreSQL upsert silently never wrote those two
columns even though the offline `mapping.py`-level round-trip tests
passed (they call `objective_to_row`/`objective_from_row` directly,
bypassing `_OBJECTIVE_COLUMNS` entirely). Fixed alongside adding `scope`
to the same two lists; regression-tested against `FakeConnection` by
asserting the generated SQL/params actually contain these columns, not
just that the mapping functions compute them.

**Not persisted this phase (by design)**: `PlannerDecisionRecord` does
NOT gain a `proposed_scope` field. Reading `agent/planning/objective_factory.py::build_objective_from_proposal`
and `agent/planning/policies/llm.py::decision_from_objective` confirms
`ObjectiveProposal.scope` and the resulting `Objective.scope` are always
identical (an unconditional passthrough in both directions, no
normalization/validation step in between) -- so persisting
`Objective.scope` via `ObjectiveRecord.scope` already captures everything
`proposed_scope` would have. Adding a second, always-redundant copy would
be denormalization without a lineage reason.
