# WB (Wire Bond BU) Data Layer -- V1

Scope: **Data Layer only**. No Tool, Skill, Planner policy, Module, or
`ObjectiveAction` was added this phase -- see the phase report for the
full scope guard. This document is the canonical reference for
`agent/domain/wb/`.

## 0. Domain glossary

- **WB BU** -- Wire Bond business unit. Not to be confused with **WB
  Operation/Station** (`OPER 2800`) -- the same three letters mean two
  different things depending on context; this codebase never conflates
  them (`plant_id` identifies the BU's plants, `operation_id` identifies
  the station, always two separate fields on every canonical record).
- **Plant** -- one of 5 physical plants under WB BU: `ASE01` (P1),
  `ASE02` (P2), `ASE03` (P3), `ASE07` (P7), `ASE08` (P8).
- **Operation** -- a process station within a plant. Known: `2600` = DA,
  `2800` = WB. `operation_id` stays a free string on every canonical
  record (real data may contain other operation codes) -- `2600`/`2800`
  are a display-label lookup (`agent/domain/wb/mappings.py::operation_label`),
  never a closed enum.
- **BANK** -- inventory NOT yet issued into the production flow.
- **WIP** -- lots already issued, currently moving through operations.
- **OUTPUT** -- completed output at a given operation.
- **OEE** -- plant/operation equipment utilization and loss signal.

### Cross-dataset semantic model (item 5 -- data relationship only, NOT a causal rule)

```
WB BU
  |
  v
Plant (ASE01 / ASE02 / ASE03 / ASE07 / ASE08)
  |
  v
BANK  --material issue-->  WIP  --production flow-->  OUTPUT

OEE = equipment-side explanatory signal (parallel to the BANK -> WIP -> OUTPUT chain, not part of it)
```

This is a **data lineage/semantic relationship**, not an RCA rule. Nothing
in `agent/domain/wb/` encodes "if BANK is short then OUTPUT is low
because of BANK" -- that inference, if it is ever built, belongs to a
future Skill/Policy phase, explicitly out of scope here (item 22).

## 1. Grain differences (item 6) -- no positional join, ever

| Source | Grain |
|---|---|
| OEE | `production_date x plant_id x operation_id` |
| OUTPUT | `production_date x plant_id x location x operation_id x product (device/package/lead_count)` |
| BANK | `snapshot(source_sync_time) x plant_id x mother_batch_id x product` |
| WIP | `snapshot(source_sync_time) x child_batch_id x operation_id` |

Any future cross-dataset alignment must join on `production_date`/aligned
snapshot + `plant_id` + `operation_id` + product/batch where available --
**never** by row position or array index. Nothing in this phase performs
such a join; this table exists so a future phase doesn't reach for one by
accident.

## 2. Snapshot semantics (item 7)

| Source | Update rhythm | Has real `production_date`? |
|---|---|---|
| OEE | daily, 08:30 (usually yesterday's data) | yes (`DATE`) |
| OUTPUT | daily, 08:30 | yes (`DATA_DATE`) |
| BANK | every 2 hours, even hour (`:40`) | **no** -- snapshot only |
| WIP | every 2 hours, odd hour (`:30`) | **no** -- snapshot only |

`DataFreshness` (`agent/domain/wb/models.py`) is source-level metadata
(one constant per source: `WB_PLANT_OEE_FRESHNESS`, `WB_BANK_FRESHNESS`,
`WB_WIP_FRESHNESS`, `WB_STAGE_OUTPUT_FRESHNESS`), exposed via each
DataSource's `freshness()` method -- not embedded per-record. Three
distinct time concepts are never conflated into one "date":

- **production_date** -- OEE/OUTPUT only, the calendar day production
  happened.
- **source_sync_time** -- every record, when the source DB/API last wrote
  this row (a real timestamp, not a business date).
- **snapshot date** -- BANK/WIP only, the calendar day `source_sync_time`
  falls on -- there is no other "date" for a snapshot dataset.
  `InMemoryWBBankDataSource`/`InMemoryWBWIPDataSource` accept an optional
  `snapshot_dates: dict[id(record), date]` map (supplied by the synthetic
  dataset builder) precisely so callers can filter "by day" without a
  `WBBankRecord`/`WBWIPRecord` needing a fake `production_date` field it
  doesn't semantically have.

## 3. Response-shape normalization (item 8)

The 4 real Flask endpoints are inconsistent: OEE/BANK/OUTPUT use pandas
`to_json(orient="columns")` (`{"COL": {"0": v, "1": v, ...}, ...}`), WIP
uses `to_dict(orient="records")` (`[{...}, {...}]`). `agent/domain/wb/normalization.py::normalize_api_rows`
accepts either shape (plus `{}`/`[]` for empty) and always returns
`list[dict]`. No canonical parser or DataSource caller ever sees the raw
shape difference.

## 4. Missing-value normalization (item 9)

`normalize_missing_value`: `"" -> None`, `NaN -> None`. **`0`/`0.0`/`False`
are never touched** -- they are legitimate business values (this matters
concretely: `WBWIPRecord.current_quantity == 0` is a real, different fact
from "quantity unknown", and must stay distinguishable).

## 5. Unknown fields (item 10)

| Source | Field | Status |
|---|---|---|
| OEE | `ENG` -> `engineering_ratio` | UNKNOWN |
| OEE | `TS` -> `ts_ratio` | UNKNOWN |
| BANK | `cust_runtype` -> `customer_run_type` | UNKNOWN |
| BANK | `run_type` -> `run_type` | UNKNOWN |
| BANK | `uom` -> `unit_of_measure` | UNKNOWN |
| WIP | `RUN_TYPE` -> `run_type` | UNKNOWN |
| OUTPUT | `SUP_FAC` -> `source_facility` | UNKNOWN |
| OUTPUT | `TT_BOND_DIAG` -> `bond_diagram` | UNKNOWN |

Every one of these fields is still typed and carried onto its canonical
record -- the raw value is never dropped -- but no code in
`agent/domain/wb/` (parsing, normalization, synthetic generation) assigns
it a business meaning, and the synthetic golden scenarios (section 7)
never use one of these fields to construct a scenario's "truth." This
stays true until a human supplies a real definition.

## 6. Plant/site mappings

```python
PLANT_ID_MAP = {"A01001": "ASE01", "A01002": "ASE02", "A01003": "ASE03", "A01007": "ASE07", "A01008": "ASE08"}
SITE_GROUP_PLANTS = {"A1": {"ASE01", "ASE02", "ASE03"}, "A2": {"ASE07", "ASE08"}}
OPERATION_LABELS = {"2600": "DA", "2800": "WB"}
```

Lives in `agent/domain/wb/mappings.py` -- the DataSource/normalization
layer, never a Planner prompt or `AgentState`/`ModuleState` field, per
this phase's explicit instruction. `resolve_plant_id`/`resolve_site_group`
return the raw value **unchanged** when it isn't recognized (e.g. the OEE
sample's placeholder `"[FAB_A]"`) -- never a guessed/nearest match. Use
`is_known_plant_id` to distinguish "resolved" from "passed through
unknown."

## 7. Golden Scenarios (items 12-16)

All anchored on `production_date = 2026-08-12` ("the golden day"), one
plant each, so five different data stories coexist in the same synthetic
dataset without needing five separate small datasets.

| Scenario | Plant | Data truth | Expected data-level interpretation |
|---|---|---|---|
| A -- equipment-side loss | ASE01 (OPER 2800) | BANK/WIP normal, OEE down (DOWN/SETUP up), OUTPUT down | Output shortage is consistent with equipment-side loss |
| B -- material/input shortage | ASE07 (OPER 2800) | Most BANK rows `MATERIAL_SHORTAGE`, OEE normal, WIP input lower, OUTPUT down | Output shortage NOT primarily supported by OEE loss -- input/material shortage is the stronger candidate signal |
| C -- WIP/Hold flow issue | ASE03 | BANK/OEE normal, WIP `Hold` ratio sharply elevated, OUTPUT down | Flow/Hold issue signal is stronger than equipment loss |
| D -- normal | ASE02 | BANK/WIP/OEE/OUTPUT all normal | False-positive control -- no shortage signal should appear |
| E -- missing data | ASE08 | OEE record absent entirely for 2026-08-12 | Data gap stays explicit (`list_oee(production_date=...)` returns `[]` for that plant) -- never backfilled with a fabricated `0` |

**This phase only proves the synthetic data is internally coherent and
correctly round-trips through the canonical parsing/DataSource layer.**
No RCA rule, causal inference, Skill, or Policy reads these scenarios --
see `tests/test_wb_golden_scenarios.py` for what's actually asserted
(counts, ratios, presence/absence -- data facts, not conclusions).

## 8. Old (equipment-level) OEE vs. new (plant-level) WB OEE (item 23)

**Decision: Option B -- a fully separate `WBPlantOEERecord`/`WBPlantOEEDataSource`,
not an extension of the existing `agent/domain/oee/` equipment-level
model.**

Reviewed both:

- `agent/domain/oee/dataset.py::EquipmentSnapshot`/`ScreeningResult` (Phase
  5A, extended Phase 8B-1 with `OEEDataSource`/`InMemoryOEEDataSource`) is
  grain `equipment_id` -- one row per physical machine, with
  Availability/Performance/Quality broken out separately so
  `OEEPlanningPolicy` can screen/rank/deep-dive by A/P/Q dimension. This
  is a **machine-level RCA dataset**.
- The real WB OEE API (`GET /api/wb/oeedata`) is grain
  `production_date x plant_id x operation_id` -- one row per plant per
  operation per day, with a *different* metric set (`DOWN`/`SETUP`/`PM`/
  `IDLE`/`PRODUCTIVE` ratios, no A/P/Q breakdown at all, no
  `equipment_id`). This is a **plant/operation-level operational KPI
  dataset** -- structurally incompatible with `EquipmentSnapshot` (no
  A/P/Q fields to compute a `pattern_of()` worst-dimension grouping from,
  no per-equipment identity to screen/rank).

Forcing `WBPlantOEERecord` into `EquipmentSnapshot`'s shape would mean
either fabricating fake A/P/Q values from `DOWN`/`SETUP`/`PRODUCTIVE`
(inventing data the source doesn't provide) or silently dropping
`OEEPlanningPolicy`'s entire screening/ranking mechanism for WB data (an
architecture change smuggled in as a "data model reuse" -- and explicitly
against item 22's "do not build a new RCA policy this phase" AND against
the equally-explicit "do not stretch an existing model to cover a
fundamentally different grain" discipline this codebase already applies
elsewhere (Phase 6A's Full-State-vs-Context discipline, Phase 8A's
relational-core-vs-JSONB discipline)).

`WBPlantOEERecord` therefore lives entirely in its own package
(`agent/domain/wb/`), with its own `WBPlantOEEDataSource`/
`InMemoryWBPlantOEEDataSource`/`RemoteWBPlantOEEDataSource`, and does not
touch `agent/domain/oee/` at all. **If a genuine machine-level WB dataset
ever appears** (real per-equipment A/P/Q data), it would be a new,
separate case for reusing `EquipmentSnapshot`'s shape -- not something
this phase's plant-level data justifies.

## 9. WB ISSUE (Phase WB-3A)

### 9.1 Purpose

ISSUE = material release data (`iss_qty`, 投料量): how much material was
released/issued into production, per plant/schedule/customer/device-
package, on a given release date. Extends the existing chain diagram
(section 0) with one more upstream stage:

```
BANK  --material issue-->  ISSUE  --release into flow-->  WIP  --production flow-->  OUTPUT
```

Still a **data lineage/semantic relationship, not a causal rule** (same
discipline as section 0's own diagram) -- nothing in `agent/domain/wb/`,
`agent/tools/wb/issue_tools.py`, or `agent/planning/policies/wb.py`
encodes "low ISSUE caused low OUTPUT" or "material shortage caused low
ISSUE." Those remain future RCA-phase inferences, if ever built.

### 9.2 Grain

Deliberately described conservatively (item I): **"one source ISSUE
record"** -- available dimensions are plant x schedule (mother batch) x
customer x device/package x release date/time. No row-level id field is
documented in the real API's response shape, so this phase does NOT
claim one row is provably a unique release event.

### 9.3 Raw -> Canonical mapping

| Raw field | Canonical field | Meaning |
|---|---|---|
| `SYNC_TIME` | `source_sync_time` | when this row was written/synced to the DB -- NOT a business date |
| `prctr` | `plant_id` (via `resolve_plant_id`) | plant code |
| `site` | `site` (raw, unmapped) | broad site/group code (e.g. `A2`) -- never canonicalized to one plant |
| `schedule` | `schedule` | mother batch code, 6 digits |
| `cust_2_code` | `customer_code` | customer 2-code |
| `customer_name` | `customer_name` | customer name |
| `dev_type` | `device_type` | product/device type |
| `iss_qty` | `issue_quantity` | issued quantity -- `0` is a real value, never missing |
| `lead_count` | `lead_count` | lead count |
| `pack_code` | `package_code` | package code |
| `pack_typ` | `package_type` | package type |
| `region` | `region` | region |
| `rel_date` | `release_date` (tolerant-parsed) + `release_date_raw` (always preserved) | the actual release/issue date -- NOT `source_sync_time` |
| `rel_sys` | `release_system` | release system |
| `rel_time` | `release_time` | release time |
| `time` | `time_bucket` | `AM`/`PM` |
| `wafer_inch` | `wafer_inch` | wafer size |
| `year` | `year` | year suffix |

### 9.4 Unknown fields

| Raw field | Canonical field | Status |
|---|---|---|
| `bd_no` | `bd_no_unknown` | UNKNOWN |
| `cu_flag` | `cu_flag_unknown` | UNKNOWN |
| `cust_runtype` | `customer_run_type_unknown` | UNKNOWN |
| `customer_sod` | `customer_sod_unknown` | UNKNOWN |
| `internal_sod` | `internal_sod_unknown` | UNKNOWN |
| `routid` | `routid_unknown` | UNKNOWN |
| `run_type` | `run_type_unknown` | UNKNOWN |
| `uom` | `unit_of_measure_unknown` | UNKNOWN |
| `user_id` | `user_id_unknown` | UNKNOWN |
| `user_name` | `user_name_unknown` | UNKNOWN |

Same discipline as section 5: raw value always preserved, never assigned
a guessed business meaning, never used by any Tool/Skill/Policy for
causal reasoning. `cu_flag = "Y"` in particular is NOT interpreted as any
business flag.

### 9.5 Plant/site mapping

Reuses `resolve_plant_id` (section 6) on `prctr` -- no second mapping
mechanism. An unrecognized `prctr` value passes through unchanged (never
raises, never guessed). `site` (e.g. `A2`) is preserved as its own raw
field, exactly like BANK's `site_group_raw` -- it is a group/site
semantic covering multiple plants (`SITE_GROUP_PLANTS`), never
canonicalized down to one plant.

### 9.6 SYNC_TIME vs. release_date vs. API `date` parameter

**The single most important semantic distinction this phase reviewed**
(item V): the real Flask endpoint's own implementation filters
`"SYNC_TIME" LIKE "{date}%"` -- its `date` query parameter is a
**sync-date filter, not a release-date filter**. `WBIssueDataSource.list_issue(*, sync_date: date | None)`
and `RemoteWBIssueDataSource` name their parameter `sync_date` precisely
to keep this honest -- neither claims to filter by `release_date`.
`query_wb_issue`/`summarize_wb_issue`/`analyze_wb_issue_trend`
(`agent/tools/wb/issue_tools.py`) fetch unscoped from the DataSource and
filter precisely by the canonical `release_date` field themselves, in
Python -- a documented Tool-layer responsibility, never a DataSource-
level capability the real API doesn't actually have. Fetching across
multiple sync dates to assemble a full release-date's worth of records
(needed for a real deployment, since one sync-date query may not capture
every record for a given release_date) is explicitly NOT attempted this
phase -- see section 9.11.

### 9.7 Freshness decision

`WB_ISSUE_FRESHNESS`: `update_frequency=DAILY`, `typical_sync_times=("08:40",)`,
**`is_snapshot=False`**. Same category as OEE/OUTPUT, NOT BANK/WIP: an
ISSUE record carries its own real business date (`release_date`) distinct
from `source_sync_time` -- exactly the trait `is_snapshot` exists to
capture. It is a "release-event dataset synchronized daily", not a
snapshot-of-current-state dataset like BANK/WIP (which have no comparable
business-date field at all).

### 9.8 Synthetic dataset design

14 days (`ISSUE_DAYS`, 2026-07-30 .. 2026-08-12, the existing golden day)
x 5 plants x 4 records/plant/day = 280 records. ASE07 (the same plant as
Golden Scenario B) shows a clear decline for the 4 days at/including the
golden day (`ISSUE_DECLINE_START = 2026-08-09`): ~400/day vs. baseline
~1000/day (a ~60% drop, `-60.0%`/`DOWN` when measured with a 4-day
current-period window). This is a deliberately-placed **observed**
pattern living alongside Golden Scenario B's existing BANK material-
shortage signal -- neither the generator, any Tool, nor any Skill ever
asserts a causal link between them; a future RCA phase may or may not
find these two signals meaningfully related.

### 9.9 Tool capability

`agent/tools/wb/issue_tools.py`:

| tool_id | Purpose | DataSource |
|---|---|---|
| `query_wb_issue` | Raw/canonical ISSUE record retrieval, filtered by release_date/plant/customer/device/package | `WBIssueDataSource` |
| `summarize_wb_issue` | Deterministic total issue_quantity + by_plant/by_customer/by_device breakdown | `WBIssueDataSource` |
| `analyze_wb_issue_trend` | Deterministic current-period vs. baseline-period average-daily comparison for ONE plant over a `[start, end]` release-date range | `WBIssueDataSource` |

### 9.10 Skill capability

- `wb.issue_status_summary` (`capability_key=wb.issue.status_summary`,
  INFORMATION, entity-scoped) -- "what is this plant's Issue status on
  this date."
- `wb.issue_trend_analysis` (`capability_key=wb.issue.trend_analysis`,
  ANALYSIS, entity-scoped) -- "is this plant's recent Issue quantity
  below its own baseline." Uses `ObjectiveScope.time.start`/`.end` (a
  bounded range, already part of the existing `TimeScope` contract -- no
  Core change was needed).

Both reuse `TimeScopeKind.PRODUCTION_DATE` as the `scope.time.kind` tag
(a deliberate choice, not a new Core enum member -- see section 9.6:
`WBQueryScope.release_date`/`.release_date_start`/`.release_date_end`,
never `.production_date`, is what's actually echoed back in results, so
nothing downstream mislabels an ISSUE date as an OEE/OUTPUT-style
production date).

`WBPlanningPolicy` routes an INFORMATION request mentioning `"issue"`/`"投料"`
to `wb.issue.status_summary` via the same topic-keyword mechanism already
used for OEE/BANK/WIP/OUTPUT (never a hardcoded "if this exact question
then this Tool" mapping). ANALYSIS+"issue" WITHOUT a historical-intent
keyword is still not auto-wired to the trend capability -- it fails closed
(no viable objective), never crashes, never fabricates a date range.
**Phase WB-3B update:** ANALYSIS+"issue" WITH a historical-intent keyword
(see section 10.6) now routes to `wb.issue.trend_analysis` over a
deterministic default window -- see section 10 below; section 9.11's
first bullet (below) is superseded by that update, kept here only for
historical trace.

### 9.11 Known limitations (Phase WB-3A; superseded items marked)

- ~~**WBPlanningPolicy does not autonomously produce `wb.issue.trend_analysis`
  Objectives.**~~ **Superseded by Phase WB-3B section 10.6** -- now wired
  behind a historical-intent keyword, with a deterministic 7/14/30-day
  default window.
- **`RemoteWBIssueDataSource` cannot assemble a full release-date's worth
  of records from one API call** (section 9.6) -- a real deployment
  wanting "every ISSUE record released on date D" would need to query
  across multiple candidate sync dates and de-duplicate, which this phase
  does not attempt. Still true as of WB-3B -- see section 10.10.
- **No formal `Limitation` record for `SUCCESS + availability.is_empty=True`**
  (the same pre-existing gap Phase WB-2C/WB-2D found and documented for
  OEE/BANK/WIP/OUTPUT -- see the Phase WB-2D report's "Limitation on
  missing data" note) -- ISSUE inherits this exact gap, not a new one.
  Still true as of WB-3B (deferred to a future WB-3C, see section 10.11).
- ~~**No `analyze_wb_issue_trend` <-> ISSUE+BANK+WIP+OUTPUT cross-source
  join Tool**~~ **Partially superseded by Phase WB-3B section 10** -- the
  first cross-source Tool (`analyze_wb_issue_vs_output`, ISSUE vs. OUTPUT
  only) now exists; ISSUE-vs-OEE, BANK-vs-OUTPUT, WIP-vs-OUTPUT,
  OEE-vs-OUTPUT remain unbuilt (see section 10.11).

## 10. Historical Analysis & Cross-Source Data Integration (Phase WB-3B)

### 10.1 Purpose

WB-3A/WB-2D only ever answer "what does this look like on ONE date."
Phase WB-3B adds the deterministic machinery to answer window-based
questions -- "has this been low all week," "how many times has this
happened," "is this a one-off or recurring," "did two signals move
together over the same window" -- **without any LLM ever computing an
average, a percentage, a recurrence count, or a join itself.** The
Planner decides WHICH window/topic to look at; a Tool performs the
arithmetic, every time, through one shared function.

### 10.2 `compute_historical_metrics` -- the one shared calculation

`agent/domain/wb/historical.py::compute_historical_metrics(daily_values,
*, current_date, window_start, is_abnormal)` is the ONLY place any of
these numbers are computed. Every trend Tool (ISSUE/OEE/WIP-Hold/
BANK-shortage/OUTPUT) and the cross-source Tool call through it -- no
Tool, Skill, or Planner ever re-derives this arithmetic a second,
slightly-different way.

Design decisions, all deliberate:

- **Baseline excludes `current_date`.** `current=2026-08-12` with a
  7-day window starting `2026-08-06` means baseline =
  `2026-08-06..2026-08-11` (6 days), current = `2026-08-12` alone. A
  regression test (`test_baseline_leakage_regression_current_value_must_not_shift_baseline`,
  `tests/test_wb_historical_domain.py`) pins this down: if the current
  day's value leaked into the baseline average, the result would visibly
  differ, and the test catches that.
- **A missing day is simply absent from `daily_values`** -- never a
  fabricated `0`. `observed_days = len(daily_values)`, never the
  window's calendar length. `persistence_ratio` is `None` (not `0`) when
  `observed_days == 0`.
- **Abnormality direction is domain-specific**, supplied by the caller as
  `is_abnormal(value, baseline_value) -> bool` -- never a universal
  "value < baseline" rule (a high WIP Hold ratio is bad; a high OEE is
  good). Four predicates, all in `agent/domain/wb/historical.py`:

  | Predicate | Rule | Mirrors |
  |---|---|---|
  | `oee_is_abnormal` | `oee < 70.0` | Phase WB-2D's own RCA threshold |
  | `wip_hold_ratio_is_abnormal` | `ratio >= 0.3` | Phase WB-2D's own RCA threshold |
  | `bank_shortage_ratio_is_abnormal` | `ratio >= 0.5` | Phase WB-2D's own RCA threshold |
  | `below_self_baseline_is_abnormal` | `value < baseline * 0.7` | ISSUE/OUTPUT have no domain-independent "low" value, so the threshold is relative to the window's OWN baseline; `baseline is None` is never treated as abnormal |

- **`recurrence_count`** = number of OBSERVED days in the window
  (including `current_date`) that are abnormal, computed purely from
  `daily_values` -- **never** derived from `ObjectiveHistory`/objective
  retry count. Regression: `test_recurrence_count_reflects_data_not_the_single_objective_dispatch`
  (`tests/test_wb_historical_planning_policy.py`) dispatches ASE03's WIP
  Hold trend capability exactly once and confirms the Finding still
  reports a recurrence of 4 (from the data), not 1 (from the dispatch
  count).
- **`consecutive_abnormal_days`** walks backward from `current_date`,
  stopping at the first missing OR normal day -- a distinct concept from
  `recurrence_count` (a plant can be recurring-but-not-consecutive, e.g.
  the synthetic WIP pattern below, or fully-consecutive, e.g. the
  synthetic BANK pattern below).
- **No baseline or no current value -> `WBTrendDirection.INSUFFICIENT_DATA`**,
  `relative_deviation=None` -- never a fabricated `0%`/"flat".

### 10.3 `WBHistoricalMetricSummary` -- the shared result shape

One shared Pydantic model (`current_value`, `baseline_value`,
`absolute_deviation`, `relative_deviation`, `trend_direction`,
`window_start`, `window_end`, `observed_days`, `abnormal_days`,
`recurrence_count`, `persistence_ratio`, `consecutive_abnormal_days`),
embedded as a `metrics:` field on the 4 NEW trend Results (OEE/WIP-Hold/
BANK-shortage/OUTPUT) and on the cross-source Result's `issue`/`output`
fields. `WBIssueTrendAnalysisResult` (Phase WB-3A, pre-existing) keeps
its own flat field names for backward compatibility -- it is still
computed through the exact same `compute_historical_metrics` internally,
via additive fields (`observed_days`, `abnormal_days`, `recurrence_count`,
`persistence_ratio`, `consecutive_abnormal_days`), never a breaking
reshape of the WB-3A contract. `agent/planning/policies/wb.py::
_issue_trend_metrics_adapter` bridges ISSUE's flat shape into
`WBHistoricalMetricSummary` purely for shared Finding-description logic
-- it never mutates or re-persists the original payload.

### 10.4 Trend Tools (one per source, item 8-12)

| tool_id | Source | Date semantic | Abnormality predicate |
|---|---|---|---|
| `analyze_wb_issue_trend` | ISSUE (extended, WB-3A) | `release_date` range | `below_self_baseline_is_abnormal` |
| `analyze_wb_oee_trend` | OEE | `production_date` range | `oee_is_abnormal` |
| `analyze_wb_wip_hold_trend` | WIP | `snapshot_date` range (never `production_date` -- WIP has none) | `wip_hold_ratio_is_abnormal` |
| `analyze_wb_bank_shortage_trend` | BANK | `snapshot_date` range | `bank_shortage_ratio_is_abnormal` (material_shortage specifically -- never merges `Ready To Issue`/`No Wafer In` into one "bad" bucket) |
| `analyze_wb_output_trend` | OUTPUT | `production_date` range | `below_self_baseline_is_abnormal` |

**OEE plant-wide aggregation convention (item 9):** WB Plant OEE grain is
`production_date x plant_id x operation_id`. When `operation_id` is
unspecified, `AnalyzeWBOEETrendTool` picks each day's WORST-OEE operation
as that day's representative value -- reusing `AnalyzeWBOEELossTool`'s
own `ranking[0]`-worst convention, never an invented production-volume-
weighted average (no weighting data exists in this dataset). A
`limitations` entry documents this whenever a day genuinely had multiple
operations and no `operation_id` was supplied.

**WIP/BANK snapshot fetching:** both trend Tools loop one calendar day at
a time (`cursor` from `start` to `end`), calling the existing
`select_latest_snapshot()` convention PER DAY -- never once across the
whole range -- so a day with more than one same-day sync is never
double-counted into two data points.

### 10.5 Cross-Source Tool -- `analyze_wb_issue_vs_output`

The first (and, this phase, only) cross-source WB Tool
(`agent/tools/wb/cross_source_tools.py::AnalyzeWBIssueVsOutputTool`),
consuming both `WBIssueDataSource` and `WBStageOutputDataSource` at once.
**Descriptive temporal association only** -- `WBIssueOutputRelationshipResult`
has no `causal`/`cause_strength`/estimated-causal-effect field anywhere;
"ASE07 issue quantity and output moved in the same direction over the
overlapping historical window" is what this Tool can say, "low issue
caused low output" is not, and nothing in this codebase constructs that
sentence (`tests/test_wb_cross_source_tools.py::test_result_model_has_no_causal_fields_at_all`
is a structural regression, not just a wording one).

**Join semantics:**

- **Join key is business date** -- `release_date` for ISSUE,
  `production_date` for OUTPUT -- **never** `source_sync_time`. A
  regression test constructs ISSUE/OUTPUT records for the same business
  day with deliberately different `source_sync_time` values (even
  different calendar days) and confirms the join still succeeds
  (`test_join_uses_business_date_not_sync_time_even_when_sync_time_differs`).
- **Daily aggregation happens BEFORE any join.** Both sources are reduced
  to `dict[date, float]` totals (`_issue_daily_totals`/`_output_daily_totals`)
  first; the "join" itself is then a plain dict-key intersection
  (`set(issue_daily) & set(output_daily)`) -- there is no row-level join
  anywhere in this file, so a many-to-many row explosion is structurally
  impossible, not just avoided by convention
  (`test_daily_aggregation_happens_before_join_no_many_to_many_row_explosion`
  confirms multiple same-day rows on both sides sum correctly instead of
  cross-multiplying).
- **Partial/insufficient overlap is reported, never hidden.**
  `overlap_observed_days` reflects the SMALLER of the two sources' actual
  observed days, with a `limitations` entry describing the gap. Below
  `MIN_OVERLAP_DAYS = 2` (a documented, conservative first-cut threshold,
  not a statistically-derived one), `direction_alignment` is always
  `INSUFFICIENT_DATA` and `both_declining` is always `None` -- never a
  guessed alignment from one overlapping day.

`WBDirectionAlignment` (`SAME_DIRECTION`/`OPPOSITE_DIRECTION`/`MIXED`/
`INSUFFICIENT_DATA`) is purely descriptive classification, computed from
each side's already-independently-computed `trend_direction`.

### 10.6 WBPlanningPolicy wiring -- historical ANALYSIS/RCA

**Historical-intent keyword gate (item 60):** a small, fixed keyword
tuple (`_HISTORICAL_KEYWORDS` in `agent/planning/policies/wb.py`:
最近/過去/這週/上週/7天/14天/30天/trend/history/historical/recurring/
repeated/persistent/持續/反覆/發生幾次) is the SOLE signal distinguishing
a historical request from a plain one -- deliberately bounded, not a
large NLP dictionary; a future LLM Planner is the intended
production-richer path. `_detect_window_days` defaults to 7 (checks for
"30" then "14" in the goal text, capped at 30).

**ANALYSIS:** `_propose_historical_analysis` proposes exactly one
range-scoped Objective for the detected topic's trend capability (never
retried once attempted). Existing WB-2D/WB-3A non-historical ANALYSIS
paths are entirely unchanged -- this is an ADDED branch, gated behind
`_wants_historical()`, never a modification of the existing dispatch.

**RCA -- single-capability topics (OEE/WIP/BANK):** symptom-check first
(reusing the existing WB-2D RCA capability), THEN the historical trend
capability as a follow-up round -- both gated by `_wants_historical()`.

**RCA -- OUTPUT (cross-source chain, item 28/45):**
`_propose_output_historical_rca` is a 4-step, evidence-driven chain,
re-reading actual Evidence at every step (never a hardcoded sequence):

```
1. wb.output.comparison           (is this plant's output actually low?)
2. wb.output.trend_analysis       (has it been low over the window?)
3. wb.issue.trend_analysis        (has ISSUE also been low over the window?)
4. wb.issue_output.relationship_analysis   -- ONLY IF step 3 shows ISSUE trend_direction == DOWN
```

If step 3's ISSUE trend is NOT declining, step 4 is skipped entirely --
the chain stops at 3 rounds with a Finding that never claims an
issue/output association. This is the item 45 "dynamic replanning"
requirement satisfied structurally: the SAME goal statement against
different underlying Evidence (real ASE07 data with a declining ISSUE
trend, vs. a controlled dataset where ASE07's ISSUE trend is flat)
produces a different next Objective and a different final Finding --
proven by `tests/test_wb_historical_planning_policy.py::
test_dynamic_replanning_flat_issue_trend_skips_relationship_capability`.

### 10.7 Skills (item 13/27)

5 new Skills (`agent/skills/wb/`): `wb.oee_trend_analysis`,
`wb.wip_hold_trend_analysis`, `wb.bank_shortage_trend_analysis`,
`wb.output_trend_analysis`, `wb.issue_output_relationship_analysis` --
all `task_types: [analysis, rca]`, never `information` (a historical/
cross-source association is never surfaced as a plain status lookup).
`wb.issue_trend_analysis` (Phase WB-3A) had its own `task_types` extended
from `[analysis]` to `[analysis, rca]` this phase -- the one Skill-file
edit needed to let the OUTPUT cross-source RCA chain's step 3 (section
10.6) resolve at all; without it, `CapabilityResolver` silently failed to
match an RCA-tier Objective for `wb.issue.trend_analysis`, producing an
ERROR observation deep in the chain (documented as Bug #1 in the phase's
own implementation notes).

All 5 new range-scoped Skills use `parameter_mapping: {plant_id:
objective.scope.filter.plant, start: objective.scope.time.start, end:
objective.scope.time.end}` -- confirming (again, as WB-3A's own
`wb.issue_trend_analysis` already proved) that `objective.<dotted.path>`
already supports nested paths; no `SkillRunner` change was needed.

### 10.8 Synthetic dataset extension

`agent/domain/wb/synthetic.py` extends `BANK_SNAPSHOTS`/`WIP_SNAPSHOTS`
from 2 to 14 daily entries (`HISTORY_DAYS`, 2026-07-30..2026-08-12, the
same 14-day window ISSUE already used since WB-3A -- `ISSUE_DAYS` is now
an alias of `HISTORY_DAYS`). The 2026-08-12 Golden Scenario values are
preserved byte-for-byte (ASE07 BANK 7/10 shortage, ASE03 WIP 22/30 hold)
-- verified by `test_bank_shortage_trend_preserves_exact_golden_day_ratio`/
`test_wip_hold_trend_preserves_exact_golden_day_ratio`.

Two DELIBERATELY DIFFERENT synthetic shapes, so recurrence and
consecutive-days are tested as genuinely distinct concepts, not just two
names for the same thing:

- **ASE07 BANK material-shortage: PERSISTENT** -- elevated on 4
  CONSECUTIVE days (`_BANK_SHORTAGE_DAYS`, 2026-08-09..08-12) ending on
  the golden day. `recurrence_count == consecutive_abnormal_days` for
  this plant/window.
- **ASE03 WIP Hold: RECURRING but NON-consecutive** -- elevated on 4 of 7
  days, ALTERNATING (`_WIP_HOLD_RECURRING_DAYS` = {08-06, 08-08, 08-10,
  08-12}). `recurrence_count > consecutive_abnormal_days` for this
  plant/window (the day immediately before the golden day is normal, so
  `consecutive_abnormal_days` is low even though `recurrence_count` is 4).

### 10.9 Freshness (item 39)

No wall-clock `now()` dependency was added anywhere in this phase's
Tools (test-instability risk, explicitly avoided) -- freshness stays the
existing source-level `DataFreshness` metadata (section 2), unchanged.
`WBIssueOutputRelationshipResult.availability` uses ISSUE's freshness as
the primary one when both sources' cadences agree (both are `DAILY`
today); a `limitations` entry would flag a cadence mismatch if one ever
existed (currently a `# pragma: no cover` defensive branch, since it
cannot occur with today's two DAILY sources).

### 10.10 Known limitations carried into a future phase

- **`RemoteWBIssueDataSource` still cannot assemble a full release-date's
  worth of records from one API call** (section 9.6, unchanged by this
  phase) -- the same limitation applies to every historical Tool that
  fetches ISSUE data across a multi-day window: a real deployment would
  need N sync-date API calls (roughly one per calendar day in the
  window) to assemble a 7/14/30-day ISSUE history, de-duplicated across
  overlapping sync windows. Not attempted this phase -- offline/synthetic
  semantics only; real remote multi-call orchestration is future-phase
  work.
- **Only ISSUE-vs-OUTPUT was built as a cross-source Tool this phase**
  (item 26's own explicit scope boundary) -- ISSUE-vs-OEE, BANK-vs-OUTPUT,
  WIP-vs-OUTPUT, OEE-vs-OUTPUT remain unbuilt; each would need its own
  join-key/grain review (section 1's grain table) before being added, not
  a mechanical copy of `AnalyzeWBIssueVsOutputTool`.
- **No formal `ModuleState.limitations` for `SUCCESS + availability.
  is_empty=True` / historical `INSUFFICIENT_DATA` / partial cross-source
  overlap** -- the same pre-existing gap sections 9.11/WB-2D already
  documented, now with more instances (every historical/cross-source
  Tool can legitimately return `INSUFFICIENT_DATA`/partial-overlap
  outcomes). Each Tool's own `limitations: list[str]` field captures this
  at the Result level today; promoting these into a formal, structured
  `ModuleState.limitations` record remains a candidate for a future
  WB-3C phase (deliberately not implemented or even design-committed
  this phase -- see the Phase WB-3B completion report's own read-only
  audit).
- **Cross-module RCA remains entirely out of scope** -- this phase's
  cross-source work is explicitly INSIDE the WB Module only (ISSUE+OUTPUT,
  both WB domain data); nothing here touches `Coordinator` or any
  multi-Module reasoning.

## 11. Structured Limitation Propagation (Phase WB-3C)

`WBPlanningPolicy.derive_state_updates` now surfaces domain-interpreted
evidence gaps as ordinary `agent.state.models.Limitation` records -- the
same model `module_planner.py`'s own two built-in write paths already
used, no parallel WB-specific schema. The only generic seam change was
additive: `DomainStateUpdates.limitations` (`agent/planning/policies/base.py`)
plus a one-line mechanical passthrough in `module_reflector.py`. Five
bounded categories, embedded as a fixed suffix on `limitation_id` itself
(`{module_id}-lim-{objective_id}-{category}`, doubling as the
deterministic dedup key -- never a free-text hash): `no_data`,
`insufficient_history`, `partial_overlap`, `datasource_unavailable`,
`unsupported_grain` (the last one narrow -- only the OEE trend Tool's own
worst-operation-per-day note, not general equipment-level-intent
detection). See `agent/planning/policies/wb.py`'s own `_derive_wb_limitations`
and its helper functions for the exact logic.

## 12. Deterministic Data Validation (Phase WB-3D)

### 12.1 Purpose and placement

`agent/domain/wb/validation.py` -- the layer between "canonical records
came back from a DataSource" and "this data is trustworthy enough to
feed a calculation." Reuses the exact detect-vs-interpret split section
11 established: this module DETECTS (is this record/result
trustworthy?), Tool Results carry the finding (`WBDataAvailability.
validation_issues`, additive), and `WBPlanningPolicy` INTERPRETS (does
this gap matter to the current objective? -- creates a `Limitation` if
so). Not a generic Data Quality platform -- five bounded, WB-specific
categories, each implemented only as far as the actual data/metadata
genuinely supports.

### 12.2 `WBValidationIssue`/`WBValidationOutcome`

WB-domain-only (no Core enum): `WBValidationSeverity` (ERROR/WARNING/
INFO). `WBValidationIssue` (code, message, severity, field, record_count,
sample) -- N same-shape invalid records collapse into ONE issue with
`record_count=N`, never N separate manager-facing items; `sample` is
exactly one bounded, non-sensitive example, never a raw row dump.
`WBValidationOutcome` (issues, raw_record_count, usable_record_count,
invalid_record_count) is returned alongside `usable_records` by every
`validate_*_records` function -- `WBDataAvailability.record_count`/
`is_empty` keep their exact WB-2A meaning (raw), `usable_record_count`
is the new, separate signal that distinguishes "no data" from
"all-invalid data" (section 12.7).

### 12.3 The five categories

| Category | Rule | Severity |
|---|---|---|
| `invalid_value_range` | OEE/productive/downtime/setup/pm/idle ratio outside [0, 100] -- `engineering_ratio`/`ts_ratio` deliberately NOT checked (UNKNOWN meaning) | ERROR |
| `negative_quantity` | ISSUE `issue_quantity` / WIP `current_quantity` / BANK `wafer_quantity`/`die_quantity` / OUTPUT `output_quantity` < 0 (0 stays valid; `None` is never flagged -- missing != invalid) | ERROR |
| `scope_mismatch` | returned `plant_id` != requested plant -- see 12.5's own architecture finding | ERROR (structurally unreachable today, see 12.5) |
| `date_mismatch` | returned business date outside the requested window (never `source_sync_time`) | ERROR |
| `suspected_duplicate` | composite-key collision, source-specific (see 12.6) -- never a destructive dedupe | WARNING |
| `potential_truncation` | `returned_count == limit` (WIP only -- the only WB DataSource Protocol with a `limit` parameter at all) | WARNING |
| `stale_or_late_data` | latest available business date < requested end (never wall-clock `now()`) | WARNING |

### 12.4 Metric-aware exclusion (never a blanket "drop the whole record")

An invalid FIELD only excludes a record from calculations that actually
CONSUME that field -- excluding it from an unrelated count-based
calculation would incorrectly shrink a denominator the field never fed.
Concretely: WIP's `hold_ratio`/`total_lot_count`/`hold_lot_count` are
LOT-COUNT metrics that never read `current_quantity` -- only a genuine
scope mismatch excludes a lot there; `hold_quantity`/`total_quantity`
(SUMS) additionally exclude quantity-invalid records. BANK's status
distribution/shortage ratio are COUNT metrics that never read wafer/die
quantity at all -- quantity is still validated and reported, but never
excludes a record from BANK's own current calculations. OEE/ISSUE/OUTPUT
trend and summary values are computed FROM the flagged field directly, so
full exclusion (scope + quantity/range) applies throughout.

### 12.5 Architecture finding: SCOPE_MISMATCH is structurally unreachable today

None of the 5 `WBDataSource` Protocols (`list_oee`, `list_bank`,
`list_wip`, `list_output`, `list_issue`) accept a `plant_id` parameter
(confirmed by reading `agent/domain/wb/datasource.py`'s own Protocol
surface) -- every one returns records across ALL plants for the
requested date/snapshot, and Tool-layer `_filter()`'s own unconditional
plant-equality check is the ONLY plant-scoping mechanism anywhere in this
codebase. Running scope-mismatch validation AFTER that filter can never
find anything (every surviving record already matches by construction);
running it BEFORE the filter conflates "another plant's data legitimately
exists in this unscoped multi-plant fetch" with "no data for my plant"
-- confirmed by a real regression during implementation (Golden Scenario
E's ASE08-missing-data case briefly stopped reporting `is_empty=True`
correctly when validation was moved before filtering, since ASE01-08's
other plants' records made the raw fetch non-empty). The fix: filtering
stays FIRST (matching every prior WB phase's own established behavior),
`check_scope_plant_mismatch` runs on the already-filtered set as a
structural/regression guard -- it will not fire for any conforming
`InMemory*`/`Remote*` implementation today, but exists so a genuinely
non-conforming DataSource (verified via a purpose-built test double) is
never silently trusted. This becomes actively meaningful once a Remote
DataSource sends a plant filter over HTTP and the real API might not
honor it -- a Real API Shadow Validation concern (section 12.10).

### 12.6 Duplicate detection -- per source

Category A (safe deterministic key) was not found for any of the 5
sources -- none of the real WB APIs document a row-level unique id.
Category B (suspected only, composite key, never destructive): OEE
(`production_date, plant_id, operation_id`), ISSUE (`schedule,
release_date, plant_id, customer_code, device_type`), WIP
(`mother_batch_id, child_batch_id, operation_id, source_sync_time`),
OUTPUT (`production_date, plant_id, operation_id, device_type,
package_code, lead_count`). Category C (cannot detect safely, not
attempted at all): BANK -- multiple real records can legitimately share a
batch/snapshot (item 12's own explicit caution); no duplicate check
exists for it, deliberately, rather than risk false-positiving a
legitimate repeat.

### 12.7 NO_DATA vs. ALL-INVALID vs. NORMAL

Three genuinely different situations, never collapsed: (1) `record_count
== 0` -> `is_empty=True` -> NO_DATA Limitation (section 11's own
category, unchanged). (2) `record_count > 0` but `usable_record_count ==
0` -> a dedicated `validation-all-invalid` Limitation, explicit that data
WAS returned but none of it could be trusted -- distinct wording, never
presented as "no data available". (3) Full valid data showing no
abnormality -> a Finding rejecting the premise, ZERO limitations (item
42's own critical regression, tested). A related implementation finding:
several pre-existing WB Finding-description branches indexed into
`payload.ranking[0]`/similar assuming `not is_empty` implied a non-empty
ranking -- case (2) breaks that assumption (raw records exist, but
`ranking` can now be empty after exclusion), so both `_describe_finding`
and `_describe_finding_rca` gained an explicit `usable_record_count == 0`
guard before any capability-specific branch runs.

### 12.8 Historical/cross-source invalid-day exclusion

An invalid record's calendar day is simply absent from the trend Tools'
own `daily_values` dict -- the exact same "missing day" semantics
`compute_historical_metrics` (WB-3B) already established for genuinely
absent data now transparently covers "present but invalid" data too,
with zero changes to `compute_historical_metrics` itself. The
cross-source Tool validates ISSUE/OUTPUT records BEFORE building daily
totals, so `overlap_observed_days` is always computed from USABLE
business dates -- an invalid ISSUE day never joins against a valid OUTPUT
day, and a PARTIAL_SOURCE_OVERLAP Limitation and a validation-derived
Limitation can coexist without either suppressing the other.

### 12.9 Validation Issue -> Limitation mapping

`WBPlanningPolicy._validation_issue_limitations` promotes every issue in
`payload.availability.validation_issues` for the round that just
completed into a `Limitation`, `impact_statement` phrased by severity
(ERROR: "excluded... cannot be reliably assessed"; WARNING: "remains part
of this result... should be treated as provisional") -- reusing each
issue's own already-bounded `message` rather than re-deriving wording.

### 12.10 Real API Shadow readiness (read-only)

Once a Remote DataSource sends real HTTP requests, this validation layer
already has somewhere to plug in unchanged: HTTP timeout/5xx already maps
through the existing `map_wb_datasource_error` -> DATASOURCE_UNAVAILABLE
path (WB-3C, unchanged); "success + empty" and "success + only N days"
already exercised via the historical/cross-source tests (WB-3B/3D);
`invalid_value_range`/`negative_quantity`/`date_mismatch` need no new
code once real out-of-range values appear; `scope_mismatch` becomes
genuinely meaningful the moment a Remote DataSource's query includes a
plant filter sent over HTTP (section 12.5); truncation risk already
matches WIP's real `limit=5000` API parameter exactly. Not attempted
this phase -- no real call was made.
