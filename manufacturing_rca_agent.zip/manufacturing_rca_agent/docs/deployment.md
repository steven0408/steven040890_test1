# Deployment Guide

Phase PROD-1 packaged the existing Agent Harness as a FastAPI application
(`agent_api/`). This document is the operational reference for running it.

## Architecture

```
Client
  -> FastAPI (agent_api/main.py)          -- routes, validation, error mapping only
  -> AgentService (agent_api/service.py)  -- the one seam into the Harness
  -> Production Graph (agent/graph/production.py)
       Standardizer (LLM) -> Analyzer (LLM) -> Module Coordinator
       -> Module Subgraph (Planner/Gate/Executor/Reflector loop, LLM-backed)
       -> Global Completion Check -> Synthesis (LLM)
  -> LLMRouter -> OpenAI-compatible adapter (agent/llm/providers)
  -> WB capability -> Skill -> Tool -> RemoteWB*DataSource or InMemory (config-selected)
  -> HandoffPackage.markdown -> FastAPI response
```

`agent_api/` contains no WB/OEE business semantics -- it only knows request
validation, run_id, Agent invocation, runtime event forwarding, error
mapping, and response formatting.

## Required environment variables

See `.env.example` for the full template with placeholders. Summary:

| Variable | Required? | Purpose |
|---|---|---|
| `LLM_PROVIDER` | Yes | `internal_openai` \| `openai` \| `anthropic`. Never `mock` in production. |
| `INTERNAL_LLM_MODEL` / `INTERNAL_LLM_BASE_URL` / `INTERNAL_LLM_API_KEY` | Yes, if `LLM_PROVIDER=internal_openai` | Internal OpenAI-compatible endpoint. |
| `WB_DATASOURCE_PROFILE` | No (default `in_memory`) | `remote` selects the real WB API adapters. |
| `WB_API_BASE_URL` | Yes, if `WB_DATASOURCE_PROFILE=remote` | WB Flask API base URL. |
| `AGENT_RUNTIME_DB_URL` | No | Optional debug/runtime-event PostgreSQL DSN. Absence/unreachability never stops the service. |
| `AGENT_FACTORY_ID` / `AGENT_FACTORY_NAME` | No | Defaults provided. |
| `AGENT_ENABLED_MODULES` | No (default `WB`) | Comma-separated module types. |
| `AGENT_CORS_ALLOW_ORIGINS` | No (default: disabled) | Comma-separated origins. |
| `AGENT_REQUEST_TIMEOUT_SECONDS` | No | Per-request wall-clock cap for `/analyze`. |

At startup, `ApiSettings.from_env()` validates all of the above
**structurally only** -- it never calls the LLM, the WB API, or Postgres.
A missing required variable fails startup immediately with a clear error
(never a silent fallback).

## Running

```
docker build -t manufacturing-rca-agent-api .
docker run --rm -p 80:80 \
  -e LLM_PROVIDER=internal_openai \
  -e INTERNAL_LLM_MODEL=/model/gpt-oss-120b \
  -e INTERNAL_LLM_BASE_URL=http://<LLM_HOST>:<PORT>/v1/ \
  -e INTERNAL_LLM_API_KEY=EMPTY \
  -e WB_DATASOURCE_PROFILE=remote \
  -e WB_API_BASE_URL=http://<WB_API_HOST>:<PORT> \
  -e AGENT_RUNTIME_DB_URL=postgresql://<USER>:<PASSWORD>@<HOST>:<PORT>/<DB> \
  manufacturing-rca-agent-api
```

Or directly (no Docker):

```
pip install -e '.[llm,api,postgres]'
uvicorn agent_api.main:app --host 0.0.0.0 --port 80
```

## Endpoints

- `GET /health` -- process alive, no dependency checks. Never leaks a secret/connection string.
- `GET /ready` -- structural config readiness (e.g. flags `LLM_PROVIDER=mock`).
- `POST /api/agent/v1/analyze` -- primary endpoint. `{"prompt": "..."}` or `{"request": {"raw_text": "..."}}`. Returns Markdown (`text/markdown`) by default; `?format=json` for a structured body.
- `POST /api/agent/v1/analyze/stream` -- Server-Sent Events progress stream. No chain-of-thought, no raw prompts.
- `GET /api/agent/v1/runs/{run_id}/events` -- bounded RuntimeEvents for a run, if a durable sink (Postgres) is configured. Empty (not an error) when only stdout logging is active.

## Runtime observability

Every run publishes bounded `RuntimeEvent`s (`agent_api/runtime_events.py`)
to a Composite sink: stdout is always on; a PostgreSQL sink is added only
if `AGENT_RUNTIME_DB_URL` is set and reachable at startup. Failure of the
optional Postgres sink -- missing config, missing driver, unreachable host
-- degrades to stdout-only and never stops the Agent from serving
requests. Schema: `agent/persistence/postgres/migrations/0002_runtime_events.sql`.

## Known gaps (see the Phase PROD-1 completion report for full detail)

- Authentication is **not implemented**. Deploy behind an authenticating
  reverse proxy / gateway until a future phase adds it.
- The Agent's own Run/Module/Objective/Evidence Postgres persistence
  (distinct from the runtime-event debug table above) is not wired into
  `agent_api`'s default composition this phase -- it defaults to
  in-memory. The existing `AppConfig.persistence`/`PostgresSettings`
  mechanism (`agent/persistence/`) already supports it; wiring it through
  `ApiSettings` is a small, deferred, non-blocking follow-up.
- Human-in-the-loop interrupt/resume is not exposed via any endpoint this
  phase (read-only audit only -- see the completion report).
