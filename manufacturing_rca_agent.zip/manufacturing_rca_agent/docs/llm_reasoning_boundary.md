# LLM Reasoning Boundary — WBPlanningPolicy Responsibility Audit

Phase PROD-1.4 deliverable. Read-only audit of `agent/planning/policies/wb.py`
(and its Core seams) performed by direct code reading, not inferred from any
prior phase's report. Classifies every piece of logic into one of four
categories and states who should own it going forward.

## Categories

- **A. COGNITIVE_REASONING** — judgment calls about evidence/hypotheses/what
  to investigate next. Target owner: LLM Planner / LLM Reflector.
- **B. DETERMINISTIC_VALIDATION** — range/shape/scope correctness checks.
  Stays deterministic, always.
- **C. DETERMINISTIC_CALCULATION** — aggregation/ranking/trend math. Stays
  deterministic, always.
- **D. ORCHESTRATION_SAFETY** — budget/permission/state-machine control.
  Stays deterministic, always; never delegated to an LLM.

## Responsibility Matrix

| Current Logic | Current Location | Category | Future Owner | Keep/Move | Reason |
|---|---|---|---|---|---|
| Which contributing factor to check next for Output-RCA (`_propose_output_rca`, walks `_RCA_CONTRIBUTING_ORDER`) | `wb.py:1207-1245` | A | LLM Planner (happy path) | **Already moved** — `LLMPlanningPolicy.propose_next_objective`'s try-block never calls `self._baseline` (llm.py:306-333); WBPlanningPolicy is consulted only in the `except LLMRouterError` branch | This function is the deterministic FALLBACK's own decision procedure, not a helper the LLM path calls into. Confirmed by direct read — no shared call. |
| Fixed candidate order tuple `_RCA_CONTRIBUTING_ORDER = ("bank","wip","oee")` | `wb.py:332` | A (fallback-only) | Stays as WBPlanningPolicy's own internal ordering heuristic | Keep, unchanged | It is an explicitly-labeled "deterministic-baseline heuristic, not a claim this is the only valid order" (wb.py:328-331) — legitimate for a safety-net fallback, illegitimate only if the LLM path were forced through it, which it structurally is not. |
| Historical-intent keyword detection (`_wants_historical`, `_HISTORICAL_KEYWORDS`) | `wb.py:220-231` | A (fallback-only) | LLM Planner decides via `should investigate historical evidence` judgment in normal mode; this keyword list remains the FALLBACK's substitute for that judgment | Keep as fallback | Genuinely a stand-in for language understanding — correct to keep deterministic-only for the no-LLM safety net, wrong to treat as authoritative when an LLM is available. |
| Evidence-sufficiency check (`is_sufficient`) | `wb.py:1247-1264` | A | LLM Reflector (`objective_assessment == SATISFIED`) | **Already moved**, conditionally | `LLMReflectionPolicy.is_sufficient` (llm_reflection.py:269-273) uses the LLM's own `objective_assessment` when available, falls back to `wb.py`'s version only on LLM failure. |
| Finding description / causal wording (`describe_finding`, `_describe_finding_rca`) | `wb.py:1266-1306`+ | A | LLM Reflector (`finding_candidate` + `causal_level` ladder) | **Already moved**, conditionally | `LLMReflectionPolicy.describe_finding` (llm_reflection.py:275-285) uses the LLM's `FindingCandidate` when available; WB's own `_MODULE_TYPES_NEVER_CONFIRM_ROOT_CAUSE` guard (llm_reflection.py:84) still caps what the LLM is even ALLOWED to claim — a deterministic ceiling on a cognitive decision, not a cognitive decision itself. |
| Hypothesis proposal/update | N/A in `wb.py` (WBPlanningPolicy never writes `hypotheses`) | A | LLM Reflector only | Already LLM-only | `derive_state_updates` on the deterministic baseline never adds hypotheses (base.py's own default `DomainStateUpdates()` is empty on that field for WB); only `LLMReflectionPolicy.derive_state_updates` (llm_reflection.py:287-327) ever populates `Hypothesis` records. |
| Which contributing-factor evidence counts as "abnormal" (`_oee_is_abnormal`, `_wip_is_abnormal`, `_bank_is_elevated`, `_output_is_low` — the 0.3/0.5/0.7/70.0 thresholds) | `wb.py:341-391` | **C**, not A | Stays deterministic — these are calibrated thresholds against the known-normal baseline, not a judgment call | Keep | These are numeric classification rules ("is this cell of the ranked table above/below X"), the same category as a groupby/ratio calculation — an LLM re-deciding "is 58.0% OEE abnormal" independently, differently each call, would be a regression, not an improvement. The LLM's job is deciding WHAT TO DO given the classification, not re-deriving the classification itself. |
| Trend classification wording (single-day/recurring/persistent — `_describe_trend_finding`'s `recurrence_count`/`consecutive_abnormal_days` branches) | `wb.py:721-769` | **C**, not A | Stays deterministic (fallback); LLM Reflector may restate/contextualize but the underlying classification numbers are deterministic | Keep computation deterministic; LLM may still choose how to PRESENT it | `recurrence_count`/`consecutive_abnormal_days` are pure counting, already computed by `compute_historical_metrics` (agent/domain/wb/historical.py) — a deterministic calculation, not a cognitive judgment. The wording template itself is a fallback-only presentation choice; in LLM mode the Reflector composes its own `rationale_summary`/`finding_candidate.statement` from the same underlying numbers via `historical_recurrence_reasoning.md` (a Reasoning Skill, not hardcoded prose). |
| Range validation (OEE 0-100, quantity ≥ 0, scope/plant mismatch, duplicate detection) | `agent/domain/wb/validation.py` (`validate_oee_records` etc.) | B | Deterministic Tool layer | Keep | Textbook validation — never a judgment call. |
| Capability/action/scope-dimension semantic validation (`validate_planner_decision`, `_validate_scope`) | `agent/planning/policies/llm.py:77-262` | B | Deterministic (runs AFTER the LLM decides, as a gate) | Keep | Catches hallucination; this is exactly the kind of "LLM proposes, Python verifies" boundary the phase wants — never removed even when the LLM is the primary decision-maker. |
| Reflection semantic validation incl. the WB `CONFIRMED_CAUSAL` ban (`validate_reflection_decision`, `_MODULE_TYPES_NEVER_CONFIRM_ROOT_CAUSE`) | `agent/planning/policies/llm_reflection.py:74-161` | B | Deterministic (post-LLM gate) | Keep | A hard domain-honesty ceiling on what the LLM is allowed to conclude, independent of how persuasive its own rationale is. |
| Ranking/grouping/aggregation/trend-metric math | `agent/tools/wb/*.py`, `agent/domain/wb/historical.py` | C | Deterministic Tools | Keep | Never delegated to an LLM in this codebase, confirmed by the Node Responsibility Matrix in the PROD-1.3 report (reconfirmed this phase, Section 27 below). |
| Budget/step/tool-call limits, retry control | `ModuleState.budget`, `module_completion_check.py` | D | Deterministic orchestration | Keep | Never LLM-controlled; `should_continue` (LLM Reflector's own bounded hint) only ever INFORMS `module_completion_check`'s own terminal-status rule, never overrides it (module_completion_check.py never reads `should_continue` directly — confirmed unchanged this phase). |
| Objective/observation/evidence state bookkeeping, capability resolution | `module_planner.py`, `capability_executor.py`, `CapabilityResolver` | D | Deterministic orchestration | Keep | Pure orchestration nodes, no LLM call anywhere in the chain (confirmed by direct read, Section 27). |
| Execution permission gating (Human-in-loop `interrupt()`) | `execution_gate.py` | D | Deterministic | Keep | Out of scope for this phase per Section XXXIV freeze. |

## Summary judgment

The COGNITIVE_REASONING logic in `WBPlanningPolicy` (contributing-factor
selection, evidence-sufficiency, finding/causal wording, hypothesis
handling) is **already structurally bypassed by the LLM happy path** when
`LLMPlanningPolicy`/`LLMReflectionPolicy` are wired with a live LLM client —
confirmed by reading `agent/planning/policies/llm.py` and
`agent/planning/policies/llm_reflection.py` line by line: neither's
`try` block ever calls into `self._baseline`. `WBPlanningPolicy` is consulted
in exactly two circumstances: (1) the `except LLMRouterError` fallback
branch of both wrapping policies, and (2) whenever no LLM client is
configured at all (Mode A / a `mock` provider). This matches the target
architecture in the phase spec's Section IV almost exactly as-built; the
work this phase (documented in the completion report) is to (a) verify this
behaviorally where possible, (b) remove the one remaining structural
obstacle to genuinely SELECTIVE LLM reasoning under a 2048-token budget —
capability retrieval is currently alphabetical-only, not evidence/lexical
aware (see the completion report's Section 10) — and (c) close two
suspected gaps from PROD-1.3 that, on direct re-verification this phase,
turned out not to be real application defects (see Section 13/14 of the
completion report).
