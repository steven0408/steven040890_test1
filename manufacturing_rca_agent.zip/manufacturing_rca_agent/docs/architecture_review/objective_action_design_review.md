# ObjectiveAction Design Review (Phase 8B-1 Part I)

**Status: design freeze decision only. No migration performed this
phase**, per explicit instruction. If a future phase adopts Option 2/3
below, it should be its own scoped migration phase, not folded into 8B-1.

**Update (Phase WB-2B.1)**: Option 2 (generic verb enum + domain
capability key) was landed, once a second real domain (WB) existed to
validate the verb set against, exactly as recommended below. See the
Phase WB-2B.1 report for the final verb set (`QUERY`/`SUMMARIZE`/
`SCREEN`/`COMPARE`/`ANALYZE`/`DRILL_DOWN`), `Objective.capability_key`,
and `ObjectiveScope`. This document's analysis (sections 1-4) is kept
as-is below for historical record.

## 1. What does `ObjectiveAction` actually do today? (evidence, not opinion)

Grep/read across the real usage sites:

| Usage site | File | Role |
|---|---|---|
| Enum definition | `agent/state/enums.py` | 4 members: `EQUIPMENT_SCREENING`, `EQUIPMENT_DETAIL`, `CURRENT_STATUS` (all OEE-shaped), `GENERIC_QUERY` (domain-agnostic, Harness-mechanics test fixture only) |
| `Objective.action` / `ObjectiveRecord.action` | `agent/state/models.py` | the field a Planner (mock or LLM) sets on every Objective it dispatches |
| `SkillDefinition.actions: list[ObjectiveAction]` | `agent/skills/models.py` | which actions a Skill declares it satisfies -- `CapabilityResolver` matches `objective.action in skill.actions` |
| `CapabilityResolver.resolve()` | `agent/capability/resolver.py` | routing key: `objective.action` -> candidate Skills, filtered by `domain`/`task_type` first |
| `ObjectiveProposal.action: ObjectiveAction` | `agent/llm/prompts/planner.py` | **part of the LLM's forced structured-output JSON schema** -- the LLM must emit one of the 4 enum values verbatim, cannot hallucinate a new string |
| `ACTION_TARGET_TYPE` / `ALLOWED_ACTIONS_BY_TASK_TYPE` | `agent/planning/policies/llm.py` | **NEW FINDING this phase**: the generic, cross-domain `LLMPlanningPolicy` wrapper hardcodes two module-level dicts mapping *each individual `ObjectiveAction` value* to its expected `TargetRefType` and to which `TaskType`s may use it. This is domain-specific semantic knowledge (today, entirely OEE's) living in generic Planner-validation code, not inside `OEEPlanningPolicy`. |
| `OEEPlanningPolicy` | `agent/planning/policies/oee.py` | constructs `Objective(action=ObjectiveAction.EQUIPMENT_SCREENING, ...)` etc. directly |
| Semantic validators | `agent/planning/policies/llm.py::PlannerSemanticValidationError`, `agent/graph/nodes/analyzer_llm.py::AnalyzerSemanticValidationError` | reject an LLM proposal whose `action` isn't in the allowed set for the current `task_type` |
| Tests | ~15+ files reference `ObjectiveAction.*` directly (test_planner_semantic_validation.py, test_oee_planning_policy.py, test_capability_resolver.py, ...) | closed-enum assumption baked into many assertions |

**Correction to the Phase 8B architecture review's section G.4**: that
review stated Planner generic code has "zero domain references." That
was true for `module_planner.py` itself, but **`agent/planning/policies/llm.py`
(the generic LLM-augmentation wrapper every domain's policy gets wrapped
in) does hardcode per-`ObjectiveAction`-value semantic rules** (`ACTION_TARGET_TYPE`,
`ALLOWED_ACTIONS_BY_TASK_TYPE`). This was missed in the original review
because those dicts are keyed by enum member, not by a literal `"OEE"`
string -- a text/name grep for `"OEE"` doesn't find it, but it is exactly
the same category of coupling: a second domain's new `ObjectiveAction`
values would need entries in these two dicts too, in this shared file,
not inside the new domain's own policy file.

## 2. What role is `ObjectiveAction` actually playing?

Based on the evidence above, it is currently **Option C**: a shared
closed enum where every new action *shape* requires editing
`agent/state/enums.py` (add the member) AND `agent/planning/policies/llm.py`
(add its target-type/task-type rules). It is NOT a generic analytical verb
set (Option A) -- `EQUIPMENT_SCREENING`/`EQUIPMENT_DETAIL` are equipment-
specific nouns-in-verb-clothing, not domain-independent verbs like
`SCREEN`/`DRILL_DOWN`. It is also not yet a namespaced capability-routing
key (Option B) -- there is no `"oee."` prefix or domain segment in the
enum values themselves; domain-scoping happens entirely through
`SkillDefinition.domains`/`Skill.task_types` as a SEPARATE filter applied
before the action match.

## 3. Three options, compared

| Criterion | Option 1: keep shared enum | Option 2: generic action enum + domain capability key | Option 3: namespaced action string |
|---|---|---|---|
| **Shape** | `ObjectiveAction.EQUIPMENT_SCREENING` (as today) | `ActionVerb.SCREEN` / `.DRILL_DOWN` / `.QUERY_STATUS` (generic, closed) + `Objective.capability_key: str` (open, e.g. `"oee.equipment"`) resolved by domain | `Objective.action: str` = `"oee.equipment_screening"` (open string, still validated against `SkillDefinition.actions: list[str]`) |
| **Type safety** | Highest -- pydantic enum validation rejects any unknown value at the model layer, before it reaches business logic | High -- verb is still a closed enum; the capability_key is a free string but is validated by `CapabilityResolver` at resolve time (already how `TargetRef.ref_id` works today) | Lowest -- any string round-trips through pydantic; typos only caught at `CapabilityResolver.resolve()` time (a runtime `CapabilityResolutionError`, not a schema error) |
| **Skill matching** | Exact enum match, `CapabilityResolver` unchanged | Two-part match (verb + capability_key) -- `CapabilityResolver` needs a second matching dimension | Exact string match -- `CapabilityResolver` unchanged in shape, only the type of `actions`/`action` changes from `list[ObjectiveAction]`/`ObjectiveAction` to `list[str]`/`str` |
| **LLM structured output** | Cleanest -- a closed enum is the easiest possible JSON schema constraint (`"enum": [...]`) for a provider's forced-tool-use/structured-output mode to honor reliably | Almost as clean -- verb is still a closed enum in the schema; capability_key becomes a free string field the LLM must copy from `Relevant Capabilities` context (an extra hallucination surface, though `PlannerSemanticValidationError` already re-validates post-hoc) | Weakest -- `action` becomes an open string in the LLM's JSON schema; more surface for the LLM to invent a plausible-but-wrong value (mitigated the same way target_ref.ref_id already is: post-hoc `PlannerSemanticValidationError` re-validation, not schema-level prevention) |
| **Semantic validation** | `ACTION_TARGET_TYPE`/`ALLOWED_ACTIONS_BY_TASK_TYPE` in `llm.py` grow by N entries per new domain (today's real coupling cost) | Same two dicts shrink to just the generic verb set (small, stable, ~5-8 verbs total, rarely edited again) -- `TargetRefType`/`TaskType` rules move to being a property of the *verb*, not the *domain+equipment* combination, so they stop growing per-domain | Those two dicts disappear entirely from `llm.py` -- each domain's own Skill markdown (`task_types:`, plus a new per-Skill `target_ref_type:` field) becomes the sole source of that rule, fully decentralized |
| **New-domain onboarding** | Must edit `agent/state/enums.py` (shared core file) + `agent/planning/policies/llm.py` (shared core file) for any genuinely new action shape | Must edit `agent/state/enums.py` only if a genuinely new *verb* doesn't exist yet (rare after the first few domains cover most verbs) -- otherwise zero shared-file edits, only the new domain's own Skill markdown + policy | Zero shared-file edits ever -- a new domain invents its own namespaced strings freely |
| **Backward compatibility** | N/A (no change) | Migration: every existing `ObjectiveAction.EQUIPMENT_SCREENING` reference becomes `(ActionVerb.SCREEN, "oee.equipment")` or similar -- touches `OEEPlanningPolicy`, `SkillDefinition`/4 markdown files, `llm.py`'s 2 dicts, ~15 test files | Migration: every `ObjectiveAction.X` becomes a string literal `"oee.x"` -- same breadth of touch, but simpler mechanical find-replace (enum member -> string) since there's no second field to introduce |
| **Migration cost** | None (status quo) | Medium-high -- introduces a genuinely new two-field concept or a paired-tuple, real design work, real test churn | Medium -- mechanical but still touches ~15+ files and both closed-enum invariants (`SkillDefinition.actions`, `PlannerDecisionRecord.proposed_action`) that currently assume `ObjectiveAction` |
| **Typo risk** | None -- enum, caught at parse time | Low -- verb still an enum; capability_key typos caught at `CapabilityResolver.resolve()` (already how a bad `target_ref.ref_id` fails today, i.e. an existing, accepted failure mode) | Medium -- `action` typos caught only at `CapabilityResolver.resolve()`, same failure mode, larger surface (no verb-level enum backstop at all) |
| **Plugin independence** (can a new domain add an action without editing shared files) | **No** -- must touch `enums.py` + `llm.py` | **Mostly** -- only if the new domain needs a verb the existing set doesn't cover (uncommon after the first 2-3 domains) | **Yes, always** |

## 4. Recommendation

**Freeze on Option 1 (keep the shared enum) for this phase, but flag it as
the leading blocker for a second real domain**, and recommend **Option 2**
(generic verb enum + domain capability key) as the target for a future,
separately-scoped migration phase -- not Option 3. Reasoning:

- Option 3's main advantage (zero shared-file edits ever) is bought by
  giving up the enum-level type safety and LLM structured-output
  reliability this codebase has consistently prioritized everywhere else
  (`RCABaseModel(extra="forbid")`, closed enums throughout `agent/state/enums.py`,
  `SkillDefinition`'s own load-time validators). That trade-off cuts
  against this project's own established discipline.
- Option 2 keeps the strongest LLM-reliability property (closed verb enum
  in the structured-output schema) while removing the actual pain point
  this review measured: `ACTION_TARGET_TYPE`/`ALLOWED_ACTIONS_BY_TASK_TYPE`
  growing by N per-domain entries in a shared file. A generic verb set
  (`SCREEN`/`DRILL_DOWN`/`QUERY_STATUS`/`COMPARE`/`RANK`, or similar) is
  small and should stabilize after the first 2-3 real domains are built --
  most future domains would reuse existing verbs rather than mint new
  ones, at which point onboarding domain N+1 touches zero shared files on
  this axis.
- This migration should NOT happen speculatively before a second real
  domain exists to validate the verb set against. Attempting to guess the
  "right" generic verbs with only OEE as a reference risks the same
  mistake Option 1 already made once (baking equipment-specific nouns into
  what was meant to be a shared enum).

**Concrete next step (separate phase, not 8B-1)**: when a second real
domain (Yield, or a real Output/WIP) is actually built, treat that as the
forcing function -- design the Option 2 verb set against two real
examples instead of one, migrate `ObjectiveAction` then, and fold
`ACTION_TARGET_TYPE`/`ALLOWED_ACTIONS_BY_TASK_TYPE`'s domain-specific rows
out of `agent/planning/policies/llm.py` into each domain's own
`ModulePackage`/Skill markdown at the same time.
