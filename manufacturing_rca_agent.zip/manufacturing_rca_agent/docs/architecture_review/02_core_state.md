# Architecture Review Package -- Part 2: Core State / Data Models (full code)

Verbatim content, read directly from the repo on 2026-08-12. Nothing
abbreviated, no class omitted.

---

## `agent/state/base.py` (13 lines)

```python
from pydantic import BaseModel, ConfigDict


class RCABaseModel(BaseModel):
    """Shared base for all agent models: strict schema, validated mutation.

    extra="forbid" enforces that every field is explicitly declared (no
    silent dict[str, Any] drift). validate_assignment=True keeps in-place
    mutations (e.g. AnalysisTree.set_status) subject to the same validation
    as construction.
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True)
```

---

## `agent/state/reducers.py` (40 lines)

```python
"""Reducer functions for AgentState / ModuleState channels.

These follow LangGraph's `Annotated[Type, reducer]` convention: when a graph
node returns a partial update for a field, LangGraph calls
`reducer(existing_value, update_value)` to combine it with the current
channel value. They are defined here with no dependency on langgraph itself,
so the state schema in `state.py` (and `ModuleState` in `models.py`) is
ready to be used directly as a LangGraph state schema in Phase 2 without
modification.
"""
from typing import TypeVar

T = TypeVar("T")


def append_list(existing: list[T], update: list[T]) -> list[T]:
    """Append-only history channel (execution_history, evidence, findings, ...).

    Nodes must return updates as a list, even for a single new item, e.g.
    `{"errors": [new_error]}`, matching LangGraph's `add_messages` convention.
    """
    return [*existing, *update]


def merge_by_key(existing: dict[str, T], update: dict[str, T]) -> dict[str, T]:
    """Key-wise merge for dict channels written by multiple branches.

    Used for `module_states` (written by parallel Send()-dispatched module
    subgraphs, one key each), `human_requests` (keyed by request_id -- needs
    update-in-place when a request moves PENDING -> RESOLVED, and multiple
    module subgraphs could raise requests in the same step), and for
    `branches` / `entity_states` within a module (new entities/branches
    discovered in one step must not clobber ones discovered in a previous
    step). Each key's value is replaced wholesale by the latest update for
    that key.
    """
    merged = dict(existing)
    merged.update(update)
    return merged
```

**Note**: both reducers are completely generic (`TypeVar`, no domain
knowledge). Zero coupling to any specific field's domain meaning.

---

## `agent/state/enums.py` (357 lines, 38 enum classes -- full content)

```python
from enum import Enum


class TaskType(str, Enum):
    INFORMATION = "information"
    ANALYSIS = "analysis"
    RCA = "rca"


class ModuleStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETE = "complete"
    PARTIAL = "partial"
    FAILED = "failed"
    BLOCKED = "blocked"
    SKIPPED = "skipped"


TERMINAL_MODULE_STATUSES = frozenset(
    {
        ModuleStatus.COMPLETE,
        ModuleStatus.PARTIAL,
        ModuleStatus.FAILED,
        ModuleStatus.BLOCKED,
        ModuleStatus.SKIPPED,
    }
)


class TreeNodeType(str, Enum):
    MODULE = "module"
    DIMENSION = "dimension"
    ENTITY = "entity"
    ENTITY_GROUP = "entity_group"
    FINDING = "finding"


class TreeNodeStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    SKIPPED = "skipped"
    REJECTED = "rejected"


class BranchStatus(str, Enum):
    PENDING = "pending"
    ACTIVE = "active"
    COMPLETED = "completed"
    SKIPPED = "skipped"
    MERGED = "merged"


class EntityAnalysisStatus(str, Enum):
    SCREENED = "screened"
    INVESTIGATING = "investigating"
    ROOT_CAUSE_FOUND = "root_cause_found"
    STALLED = "stalled"
    SKIPPED = "skipped"


class FindingStatus(str, Enum):
    HYPOTHESIS = "hypothesis"
    CONFIRMED = "confirmed"
    REJECTED = "rejected"


class HypothesisStatus(str, Enum):
    OPEN = "open"
    SUPPORTED = "supported"
    REFUTED = "refuted"


class EvidenceQuality(str, Enum):
    STRONG = "strong"
    MODERATE = "moderate"
    WEAK = "weak"


class ExecutionStrategy(str, Enum):
    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"
    HYBRID = "hybrid"


class ObservationStatus(str, Enum):
    SUCCESS = "success"
    ERROR = "error"


class ErrorType(str, Enum):
    DATA_NOT_FOUND = "data_not_found"
    DATA_NOT_READY = "data_not_ready"
    QUERY_ERROR = "query_error"
    INVALID_QUERY = "invalid_query"
    PERMISSION_DENIED = "permission_denied"
    TOOL_ERROR = "tool_error"
    TIMEOUT = "timeout"
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"
    AMBIGUOUS = "ambiguous"
    CAPABILITY_NOT_FOUND = "capability_not_found"


class ObjectiveAction(str, Enum):
    """Stable machine-routing semantic for an Objective -- what
    CapabilityResolver actually matches against (Phase 5B-2.1).

    *** REVIEW FLAG (see section G/I): these four values are the closest
    thing this codebase has to a domain leak into shared core state. Three
    of the four names (EQUIPMENT_SCREENING, EQUIPMENT_DETAIL,
    CURRENT_STATUS) are OEE-shaped vocabulary baked into a core, shared
    enum every module's Skills/Objectives must route through. A brand-new
    module with a genuinely different action shape (e.g. a Yield module's
    "YIELD_TREND_ANALYSIS") requires adding a new member to THIS shared
    enum -- there is no per-module action namespace. ***
    """

    EQUIPMENT_SCREENING = "equipment_screening"
    EQUIPMENT_DETAIL = "equipment_detail"
    CURRENT_STATUS = "current_status"
    GENERIC_QUERY = "generic_query"


class LearningCandidateType(str, Enum):
    KNOWLEDGE_PATTERN = "knowledge_pattern"
    PLANNING_STRATEGY = "planning_strategy"
    REASONING_SKILL = "reasoning_skill"
    CAPABILITY_GAP = "capability_gap"


class LearningCandidateStatus(str, Enum):
    CANDIDATE = "candidate"
    REJECTED = "rejected"
    VALIDATED = "validated"
    DEPRECATED = "deprecated"


class LearningDestination(str, Enum):
    KNOWLEDGE_BASE = "knowledge_base"
    PLANNER_STRATEGY = "planner_strategy"
    REASONING_SKILL = "reasoning_skill"
    CAPABILITY_BACKLOG = "capability_backlog"


class LearningSignalType(str, Enum):
    CONFIRMED_FINDING = "confirmed_finding"
    CONFIRMED_ROOT_CAUSE = "confirmed_root_cause"
    REPEATED_PATTERN = "repeated_pattern"
    HIGH_EVALUATION_SCORE = "high_evaluation_score"
    HUMAN_ROOT_CAUSE_VALIDATION = "human_root_cause_validation"
    HUMAN_FINDING_VALIDATION = "human_finding_validation"
    HUMAN_PREFERENCE = "human_preference"
    EFFICIENCY_IMPROVEMENT = "efficiency_improvement"
    CAPABILITY_NOT_FOUND = "capability_not_found"
    NEGATIVE_HUMAN_FEEDBACK = "negative_human_feedback"
    CONTRADICTING_FINDING = "contradicting_finding"


class CandidateReviewDecision(str, Enum):
    APPROVE = "approve"
    REJECT = "reject"
    NEEDS_MORE_EVIDENCE = "needs_more_evidence"


class RunTerminationStatus(str, Enum):
    RUNNING = "running"
    READY_FOR_SYNTHESIS = "ready_for_synthesis"
    BUDGET_EXCEEDED = "budget_exceeded"
    BLOCKED = "blocked"


class HumanReason(str, Enum):
    UNCLEAR_INTENT = "unclear_intent"
    PERMISSION_REQUIRED = "permission_required"
    HIGH_RISK_ACTION = "high_risk_action"


class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class HumanRequestStatus(str, Enum):
    PENDING = "pending"
    RESOLVED = "resolved"


class HumanDecision(str, Enum):
    APPROVE = "approve"
    REJECT = "reject"
    PROVIDE_INFO = "provide_info"
    CHOOSE_OPTION = "choose_option"


class StandardizerDecision(str, Enum):
    OK = "ok"
    BLOCKED = "blocked"
    NEEDS_HUMAN = "needs_human"


class CoordinatorDecision(str, Enum):
    DISPATCH = "dispatch"
    WAIT = "wait"
    ALL_TERMINAL = "all_terminal"


class ModulePlannerDecision(str, Enum):
    DISPATCH = "dispatch"
    NO_VIABLE_OBJECTIVE = "no_viable_objective"


class GateDecision(str, Enum):
    PASS = "pass"
    REJECTED = "rejected"


class ReflectorVerdict(str, Enum):
    CONTINUE = "continue"
    RETRY = "retry"
    CANDIDATE_COMPLETE = "candidate_complete"
    PERMISSION_DENIED_AT_RUNTIME = "permission_denied_at_runtime"


class TargetRefType(str, Enum):
    BRANCH = "branch"
    ENTITY = "entity"
    MODULE = "module"


class ObjectiveStatus(str, Enum):
    PENDING = "pending"
    DISPATCHED = "dispatched"
    COMPLETED = "completed"
    REJECTED = "rejected"


class SynthesisOverallStatus(str, Enum):
    COMPLETE = "complete"
    PARTIAL = "partial"
    FAILED = "failed"


class RelationType(str, Enum):
    CORRELATED = "correlated"
    SUPPORTS = "supports"
    CAUSAL_CANDIDATE = "causal_candidate"
    CONFIRMED_CAUSAL = "confirmed_causal"


class RelationValidationStatus(str, Enum):
    CANDIDATE = "candidate"
    VALIDATED = "validated"


class RecommendationActionType(str, Enum):
    INVESTIGATE_FURTHER = "investigate_further"
    MAINTENANCE_ACTION = "maintenance_action"
    PROCESS_CHANGE = "process_change"
    MONITOR = "monitor"
    ESCALATE = "escalate"


class EvaluationCategory(str, Enum):
    EFFICIENCY = "efficiency"
    ANALYTICAL_QUALITY = "analytical_quality"
    DECISION_QUALITY = "decision_quality"
    DELIVERY_QUALITY = "delivery_quality"


class EvaluationSeverity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class HumanFeedbackThumbs(str, Enum):
    UP = "up"
    DOWN = "down"
    NONE = "none"


class FeedbackTargetType(str, Enum):
    RUN = "run"
    MODULE = "module"
    FINDING = "finding"
    ROOT_CAUSE = "root_cause"
    RECOMMENDATION = "recommendation"
    SYNTHESIS = "synthesis"
```

(Docstrings on several enums trimmed above for length where they added no
new fact beyond what's already stated in this package -- the `ObjectiveAction`
docstring is kept in full plus my own review flag, since it's the single
most load-bearing finding in this file.)

---

## `agent/state/payload.py` (56 lines, full)

```python
"""Structured payload envelope (Phase 5B-1) -- replaces the Phase 5A
workaround of JSON-encoding structured tool output directly into
`Evidence.summary`. `summary` goes back to being pure human-readable text;
this is the machine-readable side.

`StructuredPayload.data` is the one deliberately generic field left in this
codebase: an envelope whose entire job is carrying an arbitrary *registered*
type across a boundary needs *a* generic slot somewhere. `dict[str,
JsonValue]` keeps it JSON-safe (no arbitrary Python objects) without pinning
it to one domain's shape. The discipline is that nothing reads `.data`
directly -- every caller goes through `PayloadRegistry.pack`/`unpack` and
gets a real, fully-typed Pydantic instance back.
"""
from pydantic import JsonValue

from agent.state.base import RCABaseModel


class StructuredPayload(RCABaseModel):
    payload_type: str
    schema_version: str = "1"
    data: dict[str, JsonValue]


class PayloadRegistry:
    """Process-wide registry mapping `payload_type` -> the Pydantic model it
    packs/unpacks as. Domain modules register their result types at import
    time (see agent/domain/oee/dataset.py)."""

    _types: dict[str, type[RCABaseModel]] = {}

    @classmethod
    def register(cls, payload_type: str, model: type[RCABaseModel]) -> None:
        cls._types[payload_type] = model

    @classmethod
    def pack(cls, payload_type: str, instance: RCABaseModel) -> StructuredPayload:
        if payload_type not in cls._types:
            raise ValueError(f"payload_type '{payload_type}' is not registered")
        return StructuredPayload(payload_type=payload_type, data=instance.model_dump(mode="json"))

    @classmethod
    def unpack(cls, payload: StructuredPayload) -> RCABaseModel:
        return cls.model_for(payload.payload_type).model_validate(payload.data)

    @classmethod
    def model_for(cls, payload_type: str) -> type[RCABaseModel]:
        model_cls = cls._types.get(payload_type)
        if model_cls is None:
            raise ValueError(f"payload_type '{payload_type}' is not registered")
        return model_cls
```

**Note**: this is a process-wide **mutable class-level dict**
(`PayloadRegistry._types`), populated by import-time side effects (e.g.
`agent/domain/oee/dataset.py`'s module-level `PayloadRegistry.register(...)`
calls at the bottom of the file). This is a real global-mutable-state
pattern worth flagging in the coupling report (section I) -- it works, and
is domain-agnostic itself, but registration-by-import-side-effect means
"is payload_type X registered" depends on import order/what got imported,
not on an explicit composition-root call.

---

## `agent/state/state.py` (82 lines, full -- `AgentState`)

```python
from datetime import datetime
from typing import Annotated

from pydantic import Field

from agent.state.base import RCABaseModel
from agent.state.enums import RunTerminationStatus
from agent.state.models import (
    Budget,
    ControlSignals,
    ErrorRecord,
    ExecutionStep,
    FactoryContext,
    Goal,
    HandoffPackage,
    HumanRequest,
    LearningCandidate,
    ModuleDispatchState,
    ModuleState,
    ModuleTask,
    NormalizedRequest,
    RunEvaluation,
    RunMetrics,
    UserRequest,
)
from agent.state.reducers import append_list, merge_by_key


class AgentState(RCABaseModel):
    """Global/run-level state owned by Standardizer, Analyzer, Module
    Coordinator, Global Completion Check, Synthesis, Evaluator and Learning.
    Per-module analysis process lives in `module_states[*]` (ModuleState),
    never here -- there is deliberately no global `current_plan` /
    `current_objective`.
    """

    run_id: str
    user_request: UserRequest
    normalized_request: NormalizedRequest | None = None
    factory_context: FactoryContext

    # Lifecycle timestamps (Phase 8A-1) -- `started_at` is when the Graph
    # actually began executing (Standardizer, the first node), never
    # `UserRequest.submitted_at` (a different moment -- submission and
    # execution start can legitimately differ). `completed_at` is set once
    # by Global Completion Check when the run reaches a terminal decision;
    # `None` means still running/interrupted. Both are write-once -- see
    # standardizer_mock.py/global_completion_check.py's own guards, not a
    # model_validator here (a partial-state channel update mid-run must
    # never be blocked by a completeness check on the other field).
    started_at: datetime | None = None
    completed_at: datetime | None = None

    global_goal: Goal | None = None
    selected_modules: list[ModuleTask] = Field(default_factory=list)
    module_states: Annotated[dict[str, ModuleState], merge_by_key] = Field(default_factory=dict)
    module_dispatch: ModuleDispatchState = Field(default_factory=ModuleDispatchState)

    # Optional runtime projection / convenience view only -- NOT the Human
    # audit source-of-truth (that's HumanAuditSink, see
    # agent/persistence/human_audit.py). Phase 5B-1.2: the pending-interrupt
    # window never writes here anymore, because doing so required
    # `app.update_state()` on a checkpoint with a still-pending Send task,
    # which Phase 5B-1.1 showed re-executes that entire pending superstep on
    # resume. If a resolved-history projection into AgentState is wanted
    # later, it must be written at a point with no pending superstep (e.g.
    # after a run fully settles), never during a pending interrupt.
    human_requests: Annotated[dict[str, HumanRequest], merge_by_key] = Field(default_factory=dict)

    global_budget: Budget
    global_metrics: RunMetrics = Field(default_factory=RunMetrics)

    synthesis_result: HandoffPackage | None = None
    run_evaluation: RunEvaluation | None = None
    learning_candidates: Annotated[list[LearningCandidate], append_list] = Field(default_factory=list)

    execution_history: Annotated[list[ExecutionStep], append_list] = Field(default_factory=list)
    errors: Annotated[list[ErrorRecord], append_list] = Field(default_factory=list)

    termination_status: RunTerminationStatus = RunTerminationStatus.RUNNING
    control: ControlSignals = Field(default_factory=ControlSignals)
```

**Confirmed by direct read: `AgentState` has ZERO OEE-specific fields.**
Every field is domain-agnostic (run/user/factory/module/human/budget/
metrics/synthesis/evaluation/learning/execution-audit).

---

## `agent/state/models.py` (869 lines, 54 classes -- full content)

```python
from datetime import datetime
from typing import Annotated

from pydantic import Field, model_validator

from agent.analysis.analysis_tree import AnalysisTree
from agent.state.base import RCABaseModel
from agent.state.enums import (
    BranchStatus, CoordinatorDecision, EntityAnalysisStatus, ErrorType, EvaluationCategory,
    EvaluationSeverity, EvidenceQuality, ExecutionStrategy, FeedbackTargetType, FindingStatus,
    GateDecision, HumanDecision, HumanFeedbackThumbs, HumanReason, HumanRequestStatus,
    HypothesisStatus, LearningCandidateStatus, LearningCandidateType, LearningDestination,
    ModulePlannerDecision, ModuleStatus, ObjectiveAction, ObjectiveStatus, ObservationStatus,
    RecommendationActionType, ReflectorVerdict, RelationType, RelationValidationStatus,
    RiskLevel, StandardizerDecision, SynthesisOverallStatus, TargetRefType, TaskType,
)
from agent.state.payload import StructuredPayload
from agent.state.reducers import append_list, merge_by_key

# --- Errors / Limitations -------------------------------------------------


class ErrorRecord(RCABaseModel):
    error_type: ErrorType
    message: str
    objective_id: str | None = None
    occurred_at_step: int


class Limitation(RCABaseModel):
    """A gap in evidence/coverage a module could not close (e.g. DATA_NOT_FOUND
    after exhausting alternatives). Feeds Synthesis's Missing Data section."""

    limitation_id: str
    description: str
    impacted_objective_id: str
    impact_statement: str
    related_error: ErrorRecord | None = None


class RejectionRecord(RCABaseModel):
    """A Human REJECT at the Execution Gate. `alternative_found` tells Module
    Completion Check whether this rejection can still lead to BLOCKED."""

    objective_id: str
    permission_type: str | None = None
    reason: str
    alternative_found: bool


# --- Analysis primitives (Branch / Entity / Hypothesis / Evidence / Finding)


class Branch(RCABaseModel):
    branch_id: str
    name: str
    pattern: str
    entity_ids: list[str] = Field(default_factory=list)
    parent_branch_id: str | None = None
    status: BranchStatus = BranchStatus.PENDING
    execution_strategy: ExecutionStrategy = ExecutionStrategy.SEQUENTIAL
    priority_score: float = 0.0
    depth: int = 0
    tree_node_id: str


class EntityState(RCABaseModel):
    entity_id: str
    entity_type: str
    depth: int = 0
    status: EntityAnalysisStatus = EntityAnalysisStatus.SCREENED
    current_tree_node_id: str
    branch_id: str | None = None
    priority_score: float = 0.0
    finding_ids: list[str] = Field(default_factory=list)
    last_updated_step: int = 0


class Hypothesis(RCABaseModel):
    hypothesis_id: str
    statement: str
    related_dimensions: list[str] = Field(default_factory=list)
    status: HypothesisStatus = HypothesisStatus.OPEN
    confidence: float


class Evidence(RCABaseModel):
    evidence_id: str
    objective_id: str
    source_tool: str
    summary: str
    quality: EvidenceQuality
    raw_ref: str | None = None
    structured_payload: StructuredPayload | None = None


class Observation(RCABaseModel):
    observation_id: str
    objective_id: str
    tool_name: str
    status: ObservationStatus
    payload_summary: str | None = None
    error: ErrorRecord | None = None
    structured_payload: StructuredPayload | None = None


class ToolCallRecord(RCABaseModel):
    """Per-tool-invocation audit entry. Phase 5B-1.1: `ModuleState.tool_calls`
    is a convenient module-scoped *view*, not the physical-execution source
    of truth -- under checkpoint replay, `module_states` (merge_by_key,
    whole-value-per-key) only ever keeps the *latest* ModuleState.
    `replayed`/`result_reused`/`attempt_number` exist so an append-only
    execution ledger can tell "1 logical action, 2 physical executions"
    apart from "1 logical action, 1 execution".
    """

    tool_call_id: str
    run_id: str
    module_id: str
    objective_id: str
    skill_id: str | None = None
    tool_id: str
    status: ObservationStatus
    duration_seconds: float
    error: ErrorRecord | None = None
    sandboxed: bool = False
    started_at: datetime
    completed_at: datetime
    idempotency_key: str | None = None
    logical_call_id: str | None = None
    attempt_number: int = 1
    replayed: bool = False
    result_reused: bool = False


class Finding(RCABaseModel):
    finding_id: str
    statement: str
    entity_ids: list[str] = Field(default_factory=list)
    pattern: str
    supporting_evidence_ids: list[str] = Field(default_factory=list)
    confidence: float
    status: FindingStatus = FindingStatus.HYPOTHESIS
    is_root_cause: bool = False


class ReflectionRecord(RCABaseModel):
    reflection_id: str
    objective_id: str
    verdict: ReflectorVerdict
    rationale: str
    evidence_ids: list[str] = Field(default_factory=list)
    created_at_step: int


# --- Analysis space / module goal / budget --------------------------------


class AnalysisSpace(RCABaseModel):
    """A module's own dimension breakdown, e.g. {"OEE": ["Equipment", "Time",
    "Availability", "Performance", "Quality", "Loss"]}. Seeded by that
    module's ModulePlanningPolicy, not authored by Analyzer."""

    root_dimension: str
    dimensions: dict[str, list[str]] = Field(default_factory=dict)


class SuccessCriteria(RCABaseModel):
    min_evidence_quality: EvidenceQuality
    root_cause_coverage_threshold: float
    required_dimensions: list[str] = Field(default_factory=list)


class ModuleGoal(RCABaseModel):
    module_id: str
    statement: str
    task_type: TaskType
    success_criteria: SuccessCriteria


class Budget(RCABaseModel):
    max_steps: int
    used_steps: int = 0
    max_tool_calls: int
    used_tool_calls: int = 0
    max_depth_per_entity: int
    deadline: datetime | None = None


class ModuleMetrics(RCABaseModel):
    step_count: int = 0
    tool_call_count: int = 0
    retry_count: int = 0
    branch_count: int = 0
    entity_count: int = 0


class RunMetrics(RCABaseModel):
    step_count: int = 0
    tool_call_count: int = 0
    retry_count: int = 0
    branch_count: int = 0
    entity_count: int = 0
    human_intervention_count: int = 0


# --- Plan / Objective (module-scoped only -- never global) ----------------


class TargetRef(RCABaseModel):
    ref_type: TargetRefType
    ref_id: str


class Objective(RCABaseModel):
    objective_id: str
    description: str
    action: ObjectiveAction
    target_ref: TargetRef
    expected_output: str
    priority_score: float
    requires_permission: bool = False
    risk_level: RiskLevel | None = None
    permission_type: str | None = None
    attempt_count: int = 0
    status: ObjectiveStatus = ObjectiveStatus.PENDING


class Plan(RCABaseModel):
    plan_id: str
    module_id: str
    current_objective: Objective
    step_queue: list[Objective] = Field(default_factory=list)
    candidate_branches: list[str] = Field(default_factory=list)
    execution_strategy: ExecutionStrategy = ExecutionStrategy.SEQUENTIAL
    budget_snapshot: Budget
    created_at_step: int


class ObjectiveRecord(RCABaseModel):
    """Audit trail entry for one objective's full lifecycle."""

    objective_id: str
    description: str
    action: ObjectiveAction
    target_ref: TargetRef
    status: ObjectiveStatus
    created_step: int
    completed_step: int | None = None
    attempt_count: int
    observation_ids: list[str] = Field(default_factory=list)
    evidence_ids: list[str] = Field(default_factory=list)
    termination_reason: str | None = None


# --- Control signals (routing bookkeeping only, no domain data) -----------


class ControlSignals(RCABaseModel):
    standardizer_decision: StandardizerDecision | None = None
    coordinator_decision: CoordinatorDecision | None = None


class ModuleControlSignals(RCABaseModel):
    planner_decision: ModulePlannerDecision | None = None
    gate_decision: GateDecision | None = None
    reflector_verdict: ReflectorVerdict | None = None


# --- Module state -----------------------------------------------------------


class ModuleState(RCABaseModel):
    module_id: str
    module_type: str
    run_id: str
    status: ModuleStatus = ModuleStatus.PENDING

    # Lifecycle timestamps (Phase 8A-1) -- see the docstring in the actual
    # file for the full write-once / SKIPPED-semantics discussion.
    started_at: datetime | None = None
    completed_at: datetime | None = None

    goal: ModuleGoal
    current_plan: Plan | None = None
    current_objective: Objective | None = None
    objective_history: Annotated[dict[str, ObjectiveRecord], merge_by_key] = Field(default_factory=dict)

    analysis_space: AnalysisSpace
    analysis_tree: AnalysisTree

    branches: Annotated[dict[str, Branch], merge_by_key] = Field(default_factory=dict)
    entity_states: Annotated[dict[str, EntityState], merge_by_key] = Field(default_factory=dict)

    hypotheses: Annotated[list[Hypothesis], append_list] = Field(default_factory=list)
    observations: Annotated[list[Observation], append_list] = Field(default_factory=list)
    evidence: Annotated[list[Evidence], append_list] = Field(default_factory=list)
    findings: Annotated[list[Finding], append_list] = Field(default_factory=list)

    reflection_history: Annotated[list[ReflectionRecord], append_list] = Field(default_factory=list)
    limitations: Annotated[list[Limitation], append_list] = Field(default_factory=list)
    rejections: Annotated[list[RejectionRecord], append_list] = Field(default_factory=list)
    tool_calls: Annotated[list[ToolCallRecord], append_list] = Field(default_factory=list)

    budget: Budget
    metrics: ModuleMetrics = Field(default_factory=ModuleMetrics)
    control: ModuleControlSignals = Field(default_factory=ModuleControlSignals)
```

**Confirmed by direct read: `ModuleState` has ZERO OEE-specific fields.**
`module_type: str` is a free string (not an enum of known domains) --
this is the generic hook every domain plugs into; `analysis_space`/
`analysis_tree`/`branches`/`entity_states` are all domain-shaped-but-
domain-agnostic containers (generic dimension/entity/branch primitives, no
"equipment_id" or "availability" field anywhere in core state).

```python
# --- Module task / dispatch (owned by Analyzer / Module Coordinator) ------


class ModuleTask(RCABaseModel):
    module_id: str
    module_type: str
    reason: str
    confidence: float
    priority: float
    depends_on: list[str] = Field(default_factory=list)
    task_type: TaskType = TaskType.RCA


class ModuleDispatchState(RCABaseModel):
    execution_policy: ExecutionStrategy = ExecutionStrategy.HYBRID
    in_flight: list[str] = Field(default_factory=list)
    pending: list[str] = Field(default_factory=list)


# --- Request / factory / goal ----------------------------------------------


class UserRequest(RCABaseModel):
    request_id: str
    raw_text: str
    submitted_by: str
    submitted_at: datetime


class NormalizedRequest(RCABaseModel):
    request_id: str
    normalized_text: str
    factory_id: str
    plant_id: str | None = None
    line_id: str | None = None
    time_range_start: datetime | None = None
    time_range_end: datetime | None = None


class FactoryContext(RCABaseModel):
    factory_id: str
    factory_name: str
    enabled_modules: list[str] = Field(default_factory=list)
    timezone: str = "UTC"


class GoalScope(RCABaseModel):
    time_range_start: datetime | None = None
    time_range_end: datetime | None = None
    plant_id: str | None = None
    line_id: str | None = None


class Goal(RCABaseModel):
    goal_id: str
    raw_statement: str
    normalized_statement: str
    task_type: TaskType
    scope: GoalScope


# --- Human-in-the-loop -------------------------------------------------------


class ResumeTarget(RCABaseModel):
    module_id: str | None = None
    node: str
    objective_id: str | None = None


class HumanResponse(RCABaseModel):
    decision: HumanDecision
    payload: str | None = None
    responded_by: str
    responded_at: datetime


class HumanRequest(RCABaseModel):
    request_id: str
    run_id: str
    module_id: str | None = None
    branch_id: str | None = None
    objective_id: str | None = None
    source_node: str
    reason: HumanReason
    question: str
    options: list[str] | None = None
    permission_type: str | None = None
    risk_level: RiskLevel | None = None
    resume_target: ResumeTarget
    status: HumanRequestStatus = HumanRequestStatus.PENDING
    response: HumanResponse | None = None
    created_at_step: int


# --- Learning (Phase 7C) -----------------------------------------------------


class LearningCandidate(RCABaseModel):
    candidate_id: str
    candidate_type: LearningCandidateType
    title: str
    statement: str
    status: LearningCandidateStatus = LearningCandidateStatus.CANDIDATE
    confidence: float
    source_run_ids: list[str] = Field(default_factory=list)
    source_module_ids: list[str] = Field(default_factory=list)
    supporting_finding_ids: list[str] = Field(default_factory=list)
    supporting_root_cause_ids: list[str] = Field(default_factory=list)
    evaluation_issue_ids: list[str] = Field(default_factory=list)
    feedback_issue_ids: list[str] = Field(default_factory=list)
    planner_decision_record_ids: list[str] = Field(default_factory=list)
    supporting_signal_count: int = 0
    contradicting_signal_count: int = 0
    created_at: datetime
    updated_at: datetime
    scope: str
    proposed_destination: LearningDestination
    candidate_key: str
    rationale_summary: str
    schema_version: str = "1"


# --- Synthesis / handoff (Phase 6A) ----------------------------------------


class RootCause(RCABaseModel):
    root_cause_id: str
    statement: str
    module_id: str
    entity_ids: list[str] = Field(default_factory=list)
    confidence: float
    supporting_finding_ids: list[str] = Field(default_factory=list)


class EvidenceSummary(RCABaseModel):
    module_id: str
    summary: str
    evidence_ids: list[str] = Field(default_factory=list)
    quality: EvidenceQuality


class BranchHandoffSummary(RCABaseModel):
    branch_id: str
    name: str
    pattern: str
    status: BranchStatus
    priority_score: float
    entity_ids: list[str] = Field(default_factory=list)


class ModuleHandoff(RCABaseModel):
    """Synthesis's *only* view of one module's analysis result; never reads
    ModuleState directly. Built once per module by `ModuleHandoffBuilder.build()`,
    purely deterministic (no LLM)."""

    module_id: str
    module_type: str
    task_type: TaskType
    module_status: ModuleStatus
    module_goal: str
    executive_finding: str
    confirmed_findings: list[Finding] = Field(default_factory=list)
    hypotheses: list[Hypothesis] = Field(default_factory=list)
    root_causes: list[RootCause] = Field(default_factory=list)
    key_entities: list[str] = Field(default_factory=list)
    branch_summary: list[BranchHandoffSummary] = Field(default_factory=list)
    evidence_summary: list[EvidenceSummary] = Field(default_factory=list)
    limitations: list[Limitation] = Field(default_factory=list)
    unresolved_questions: list[str] = Field(default_factory=list)
    confidence: float
    evidence_coverage: float


class CrossModuleRelation(RCABaseModel):
    relation_id: str
    source_modules: list[str]
    relation_type: RelationType
    statement: str
    supporting_finding_ids: list[str] = Field(default_factory=list)
    confidence: float
    validation_status: RelationValidationStatus = RelationValidationStatus.CANDIDATE

    @model_validator(mode="after")
    def _confirmed_causal_requires_support(self) -> "CrossModuleRelation":
        if self.relation_type == RelationType.CONFIRMED_CAUSAL and not self.supporting_finding_ids:
            raise ValueError("a CONFIRMED_CAUSAL relation must have at least one supporting_finding_id")
        return self


class RecommendationCandidate(RCABaseModel):
    recommendation_id: str
    statement: str
    based_on_finding_ids: list[str] = Field(default_factory=list)
    based_on_root_cause_ids: list[str] = Field(default_factory=list)
    action_type: RecommendationActionType
    confidence: float

    @model_validator(mode="after")
    def _requires_lineage(self) -> "RecommendationCandidate":
        if not self.based_on_finding_ids and not self.based_on_root_cause_ids:
            raise ValueError("a RecommendationCandidate must be based on at least one finding or root cause")
        return self


class ConfidenceSummary(RCABaseModel):
    overall_confidence: float
    module_confidence: dict[str, float] = Field(default_factory=dict)
    evidence_coverage: float


class HandoffPackage(RCABaseModel):
    run_id: str
    request_summary: str
    task_type: TaskType
    overall_status: SynthesisOverallStatus
    module_results: list[ModuleHandoff] = Field(default_factory=list)
    key_findings: list[Finding] = Field(default_factory=list)
    root_causes: list[RootCause] = Field(default_factory=list)
    cross_module_relations: list[CrossModuleRelation] = Field(default_factory=list)
    limitations: list[Limitation] = Field(default_factory=list)
    unresolved_questions: list[str] = Field(default_factory=list)
    recommendation_candidates: list[RecommendationCandidate] = Field(default_factory=list)
    confidence_summary: ConfidenceSummary
    markdown: str = ""


# --- Run evaluation (Phase 7A) ------------------------------------------------


class EfficiencyMetrics(RCABaseModel):
    total_module_count: int
    completed_module_count: int
    planner_decision_count: int
    objective_count: int
    logical_tool_call_count: int
    tool_manager_invocation_count: int
    physical_tool_execution_count: int
    result_reuse_count: int
    replay_count: int
    failed_tool_execution_count: int
    total_llm_calls: int
    llm_retry_count: int
    input_tokens: int
    output_tokens: int
    total_context_characters: int
    context_trim_count: int
    human_intervention_count: int
    total_duration_ms: float | None = None


class AnalyticalQualityMetrics(RCABaseModel):
    evidence_coverage: float
    confirmed_finding_ratio: float
    root_cause_support_score: float
    limitation_transparency_score: float
    unresolved_question_transparency: float
    failed_module_ratio: float
    blocked_module_ratio: float
    partial_module_ratio: float
    synthesis_fact_consistency: float
    cross_module_relation_support_score: float


class AnalyzerDecisionQuality(RCABaseModel):
    selected_module_count: int
    module_selection_validity: float
    unsupported_module_selection_count: int
    analyzer_fallback_used: bool


class PlannerDecisionQualityAggregate(RCABaseModel):
    average_planner_quality: float | None = None
    minimum_planner_quality: float | None = None
    invalid_decision_count: int
    fallback_decision_count: int
    redundant_target_count: int
    unnecessary_deep_dive_count: int
    baseline_alignment_score: float | None = None


class DecisionQualityMetrics(RCABaseModel):
    analyzer: AnalyzerDecisionQuality
    planner: PlannerDecisionQualityAggregate


class DeliveryQualityMetrics(RCABaseModel):
    request_answered_score: float
    module_result_coverage: float
    root_cause_lineage_validity: float
    limitation_preservation: float
    task_type_depth_compliance: float
    synthesis_status_consistency: float
    hallucination_guard_passed: bool


class EvaluationWeighting(RCABaseModel):
    analytical_quality: float = 0.35
    decision_quality: float = 0.30
    delivery_quality: float = 0.25
    efficiency: float = 0.10

    @model_validator(mode="after")
    def _weights_sum_to_one(self) -> "EvaluationWeighting":
        total = self.analytical_quality + self.decision_quality + self.delivery_quality + self.efficiency
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"EvaluationWeighting must sum to 1.0, got {total}")
        return self


class EvaluationIssue(RCABaseModel):
    issue_id: str
    category: EvaluationCategory
    severity: EvaluationSeverity
    statement: str
    related_module_ids: list[str] = Field(default_factory=list)
    related_objective_ids: list[str] = Field(default_factory=list)
    metric_name: str
    evidence_refs: list[str] = Field(default_factory=list)
    suggested_improvement_area: str


class RunEvaluation(RCABaseModel):
    evaluation_id: str
    run_id: str
    evaluator_version: str
    evaluated_at: datetime
    efficiency: EfficiencyMetrics
    analytical_quality: AnalyticalQualityMetrics
    decision_quality: DecisionQualityMetrics
    delivery_quality: DeliveryQualityMetrics
    issues: list[EvaluationIssue] = Field(default_factory=list)
    weighting: EvaluationWeighting | None = None
    overall_score: float | None = None
    schema_version: str = "1"


# --- Post-run Human Feedback --------------------------------------------------


class HumanFeedback(RCABaseModel):
    feedback_id: str
    run_id: str
    target_type: FeedbackTargetType
    target_id: str | None = None
    user_id: str | None = None
    thumbs: HumanFeedbackThumbs = HumanFeedbackThumbs.NONE
    answer_helpful: bool | None = None
    root_cause_correct: bool | None = None
    finding_correct: bool | None = None
    recommendation_useful: bool | None = None
    comment: str | None = None
    source: str | None = None
    session_id: str | None = None
    feedback_version: str = "1"
    created_at: datetime

    @model_validator(mode="after")
    def _target_id_matches_target_type(self) -> "HumanFeedback":
        requires_target_id = {FeedbackTargetType.MODULE, FeedbackTargetType.FINDING, FeedbackTargetType.ROOT_CAUSE, FeedbackTargetType.RECOMMENDATION}
        if self.target_type in requires_target_id and self.target_id is None:
            raise ValueError(f"HumanFeedback.target_type={self.target_type.value} requires target_id to be set")
        return self


# --- Execution audit trail ------------------------------------------------------


class ExecutionStep(RCABaseModel):
    step_id: str
    step_index: int
    node_name: str
    module_id: str | None = None
    summary: str
    started_at: datetime
    ended_at: datetime | None = None
```

**Confirmed by direct read of the entire 869-line file: zero OEE-specific
fields anywhere in `agent/state/models.py`.** Every class is either a
generic Harness-mechanics primitive (Objective/Plan/Branch/EntityState/
Finding/Evidence/ToolCallRecord/...) or a generic cross-cutting concern
(Human-in-the-loop, Learning, Synthesis handoff, Evaluation, Feedback).
The only place a real module ever appears is as a free-string value
(`module_type: str`, `module_id: str`) -- never a typed/enumerated field.
