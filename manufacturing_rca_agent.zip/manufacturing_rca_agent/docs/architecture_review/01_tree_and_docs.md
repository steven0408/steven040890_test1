# Architecture Review Package -- Part 1: Project Tree + Architecture Documents

Generated 2026-08-12 by reading the actual repo at
`c:\Users\steve\Projects\manufacturing_rca_agent` (not from Phase reports).
Where a doc and the code disagree, the code is authoritative and the
discrepancy is called out explicitly.

---

## A. Full project tree

### `agent/` (complete -- every `.py`/`.md`/`.sql` file, `__pycache__` excluded)

```
agent/__init__.py
agent/analysis/__init__.py
agent/analysis/analysis_tree.py
agent/bootstrap.py
agent/capability/__init__.py
agent/capability/resolver.py
agent/catalog/__init__.py
agent/catalog/module_registry.py
agent/datasource/__init__.py
agent/datasource/models.py
agent/datasource/registry.py
agent/domain/__init__.py
agent/domain/oee/__init__.py
agent/domain/oee/dataset.py
agent/evaluation/__init__.py
agent/evaluation/analytical_quality_metrics.py
agent/evaluation/audit.py
agent/evaluation/decision_quality_metrics.py
agent/evaluation/delivery_quality_metrics.py
agent/evaluation/efficiency_metrics.py
agent/evaluation/evaluator.py
agent/evaluation/inputs.py
agent/evaluation/issues.py
agent/evaluation/scoring.py
agent/feedback/__init__.py
agent/feedback/aggregator.py
agent/feedback/assessment.py
agent/feedback/issues.py
agent/feedback/validation.py
agent/graph/__init__.py
agent/graph/graph.py
agent/graph/graph_with_synthesis.py
agent/graph/nodes/__init__.py
agent/graph/nodes/analyzer_llm.py
agent/graph/nodes/analyzer_mock.py
agent/graph/nodes/global_completion_check.py
agent/graph/nodes/module/__init__.py
agent/graph/nodes/module/bootstrap.py
agent/graph/nodes/module/capability_executor.py
agent/graph/nodes/module/execution_gate.py
agent/graph/nodes/module/module_completion_check.py
agent/graph/nodes/module/module_executor.py
agent/graph/nodes/module/module_planner.py
agent/graph/nodes/module/module_reflector.py
agent/graph/nodes/module/module_subgraph.py
agent/graph/nodes/module_coordinator.py
agent/graph/nodes/module_dispatch_payload.py
agent/graph/nodes/module_subgraph_node.py
agent/graph/nodes/standardizer_mock.py
agent/graph/nodes/synthesis.py
agent/graph/routing.py
agent/learning/__init__.py
agent/learning/candidate_key.py
agent/learning/confidence.py
agent/learning/generator.py
agent/learning/generators/__init__.py
agent/learning/generators/capability_gap.py
agent/learning/generators/knowledge_pattern.py
agent/learning/generators/planning_strategy.py
agent/learning/generators/reasoning_skill.py
agent/learning/merger.py
agent/learning/promotion.py
agent/learning/review.py
agent/learning/signals.py
agent/learning/sink.py
agent/learning/snapshot.py
agent/llm/__init__.py
agent/llm/client.py
agent/llm/config.py
agent/llm/context/__init__.py
agent/llm/context/analyzer_context.py
agent/llm/context/capability_retriever.py
agent/llm/context/context_audit.py
agent/llm/context/evidence_selector.py
agent/llm/context/history_summarizer.py
agent/llm/context/knowledge_retriever.py
agent/llm/context/planner_context.py
agent/llm/context/reasoning_skill_retriever.py
agent/llm/context/synthesis_context.py
agent/llm/context/synthesis_context_audit.py
agent/llm/models.py
agent/llm/prompts/__init__.py
agent/llm/prompts/analyzer.py
agent/llm/prompts/planner.py
agent/llm/prompts/synthesis.py
agent/llm/providers/__init__.py
agent/llm/providers/anthropic_adapter.py
agent/llm/router.py
agent/llm/usage.py
agent/persistence/__init__.py
agent/persistence/audit_repository.py
agent/persistence/checkpoint_profile.py
agent/persistence/factory.py
agent/persistence/human_audit.py
agent/persistence/human_feedback.py
agent/persistence/learning_repository.py
agent/persistence/postgres/__init__.py
agent/persistence/postgres/config.py
agent/persistence/postgres/connection.py
agent/persistence/postgres/errors.py
agent/persistence/postgres/mapping.py
agent/persistence/postgres/migrations/0001_initial.sql
agent/persistence/postgres/repositories.py
agent/persistence/postgres/schema.py
agent/persistence/postgres/unit_of_work.py
agent/persistence/records.py
agent/persistence/run_controller.py
agent/persistence/run_repository.py
agent/persistence/run_writer.py
agent/persistence/settings.py
agent/persistence/unit_of_work.py
agent/planning/__init__.py
agent/planning/contribution.py
agent/planning/decision_audit.py
agent/planning/decision_quality.py
agent/planning/objective_factory.py
agent/planning/policies/__init__.py
agent/planning/policies/base.py
agent/planning/policies/llm.py
agent/planning/policies/mock.py
agent/planning/policies/oee.py
agent/planning/priority.py
agent/planning/task_type_inference.py
agent/skills/__init__.py
agent/skills/markdown.py
agent/skills/models.py
agent/skills/oee/current_status.md
agent/skills/oee/equipment_screening.md
agent/skills/oee/rca_equipment_detail.md
agent/skills/oee/rca_screening.md
agent/skills/reasoning/plant_manager_perspective.md
agent/skills/registry.py
agent/skills/runner.py
agent/skills/wip/current_level.md          <-- ORPHANED, see finding G-8
agent/state/__init__.py
agent/state/base.py
agent/state/enums.py
agent/state/lifecycle.py
agent/state/models.py
agent/state/payload.py
agent/state/reducers.py
agent/state/state.py
agent/synthesis/__init__.py
agent/synthesis/decision_audit.py
agent/synthesis/draft_rendering.py
agent/synthesis/handoff_builder.py
agent/synthesis/llm_service.py
agent/synthesis/package.py
agent/synthesis/renderer.py
agent/synthesis/validation.py
agent/tools/__init__.py
agent/tools/base.py
agent/tools/execution_manager.py
agent/tools/mocks/__init__.py
agent/tools/mocks/oee_data_tool.py
agent/tools/mocks/scripted_tool.py
agent/tools/models.py
agent/tools/oee/__init__.py
agent/tools/oee/capability_tools.py
agent/tools/registry.py
```

138 real files (`.py`/`.md`/`.sql`), 15 top-level packages under `agent/`.
Note: `agent/domain/` currently contains only `oee/` -- there is no
sibling `agent/domain/wip/` or `agent/domain/output/` despite `Output`/
`WIP` being selectable module_types in the legacy `analyzer_mock` (see
section G).

### `tests/` (91 files, filenames only per your instruction)

```
__init__.py, conftest.py, postgres_fake.py,
test_analysis_tree.py, test_analyzer_context.py, test_analyzer_llm.py,
test_analyzer_semantic_validation.py, test_anthropic_adapter.py,
test_bootstrap.py, test_capability_registries.py, test_capability_resolver.py,
test_context_selectors.py, test_datasource_boundary.py,
test_evaluator_audit_and_scoring.py, test_evaluator_fallback_and_replay.py,
test_evaluator_information_traces.py, test_evaluator_multi_module.py,
test_evaluator_rca_traces.py, test_evaluator_read_only.py,
test_execution_skill_plugin_onboarding.py, test_external_reasoning_skill_onboarding.py,
test_human_audit_flow.py, test_human_feedback_aggregation_and_issues.py,
test_human_feedback_schema_and_lineage.py, test_human_feedback_sink.py,
test_langgraph_checkpointer_true_regression.py, test_learning_candidate_schema.py,
test_learning_generation_examples.py, test_learning_merger_sink_promotion.py,
test_learning_snapshot_extraction.py, test_llm_planning_policy.py,
test_llm_runtime.py, test_mock_llm_planner_oee_traces.py,
test_module_handoff_builder.py, test_module_react_subgraph.py,
test_module_registry.py, test_oee_capability_layer.py, test_oee_planning_policy.py,
test_persistence_contracts.py, test_persistence_factory.py,
test_persistence_feedback_learning_uow.py, test_persistence_postgres_config.py,
test_persistence_postgres_integration.py, test_persistence_postgres_mapping.py,
test_persistence_postgres_repositories.py, test_persistence_postgres_schema.py,
test_persistence_postgres_unit_of_work.py, test_persistence_run_repository.py,
test_persistence_security.py, test_persistence_tool_audit.py,
test_phase2_graph_integration.py, test_phase4a_module_integration.py,
test_phase4b1_native_subgraph.py, test_phase4b2_human_gate.py,
test_phase5b21_parent_capability_wiring.py, test_phase5b3a_analyzer_llm_e2e.py,
test_phase5b3b_real_provider_smoke.py, test_phase5c2_parent_e2e.py,
test_phase5c3_real_planner_smoke.py, test_phase8a1_lifecycle.py,
test_planner_context_budget.py, test_planner_context_oee_scenarios.py,
test_planner_context_schema.py, test_planner_decision_audit.py,
test_planner_decision_quality.py, test_planner_decision_schema.py,
test_planner_prompt_injection_boundary.py, test_planner_semantic_validation.py,
test_priority.py, test_real_planner_fallback_wiring.py,
test_reasoning_skill_context_integration.py, test_reasoning_skill_retriever.py,
test_reducers.py, test_resume_replay_semantics.py, test_run_assessment.py,
test_run_evaluation_schema.py, test_runtime_invariants.py, test_skill_markdown.py,
test_skill_taxonomy.py, test_state_serialization.py, test_synthesis_context.py,
test_synthesis_draft_schema.py, test_synthesis_graph_integration.py,
test_synthesis_hallucination_regression.py, test_synthesis_hostile_data.py,
test_synthesis_llm_service.py, test_synthesis_node.py,
test_synthesis_reasoning_skill_perspective.py, test_synthesis_scenarios.py,
test_synthesis_state_models.py, test_tool_execution_manager.py
```
(plus `tests/fixtures/dummy_skills/echo.md`, referenced by
`docs/architecture.md` section 4.)

### `docs/`

```
docs/architecture.md
docs/persistence.md
```

**Note**: the user's request also listed `docs/capability.md`,
`docs/skills.md`, `docs/context.md`, `docs/runtime.md` as possible other
formal architecture documents. **None of these exist in the repo.** Only
`architecture.md` and `persistence.md` are real. Any prior conversation or
memory referencing those other filenames is stale/does not correspond to
actual repo state.

### `pyproject.toml` (full content, current)

```toml
[project]
name = "manufacturing-rca-agent"
version = "0.1.0"
description = "Harness-level Manufacturing RCA Agent (Multi-Module ReAct architecture)"
requires-python = ">=3.11"
dependencies = [
    "pydantic>=2.6",
    "langgraph>=0.2",
    "pyyaml>=6.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
]
llm = [
    "anthropic>=0.34",
]
postgres = [
    "psycopg[binary]>=3.1",
]

[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["."]
markers = [
    "postgres: requires a real PostgreSQL instance via TEST_POSTGRES_DSN (skipped otherwise)",
]

[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.build_meta"
```

---

## B. Architecture documents (full, current content)

### B.1 `docs/architecture.md` (269 + 47 lines, current -- includes the
Phase 8B-added section 11)

<!-- The reviewing model should treat the block below as the literal file
content of docs/architecture.md as of 2026-08-12. -->

```markdown
# Architecture & Onboarding Guide (Phase 5D)

This document answers the question Phase 5D exists to answer: **how do I
add capability to this agent without touching LangGraph node code or the
Harness control flow?**

## 1. The four layers

​```
Knowledge          -- what the agent knows (facts, thresholds, SOPs).
                       Phase 5D: retrieved via KnowledgeRetriever
                       (agent/llm/context/knowledge_retriever.py),
                       VALIDATED-only, no embeddings yet.

Reasoning Skill     -- how the agent thinks/judges (a perspective, a
                       framework). Pure guidance text (a markdown body).
                       No Tool. Never executed. Retrieved by
                       ReasoningSkillRetriever, consumed as context by
                       an LLM-backed node.

Execution Skill      -- how the agent completes a procedure (Equipment
                       Screening, Contribution Analysis, ...). May chain
                       one or more Tool calls (`steps`). Resolved by
                       CapabilityResolver from an Objective's `action`,
                       run by SkillRunner.

Tool                 -- what actually does something (query data,
                       calculate, call a remote API). A Python class
                       implementing the `Tool` Protocol
                       (agent/tools/models.py).
​```

Dependency direction (top depends on nothing below it it doesn't need):

​```
Analyzer / Planner / Synthesis (LLM-backed nodes)
        |
        |  reads (as context, never invokes)
        v
Knowledge  +  Reasoning Skill  (retrieval only -- KnowledgeRetriever / ReasoningSkillRetriever)

Executor
        |
        |  resolves + invokes
        v
Execution Skill  ->  Tool  ->  (optionally) DataSource
​```

Knowledge and Reasoning Skills flow *into* a decision as context.
Execution Skills and Tools are *invoked* to produce evidence. These are
different code paths (retrieval vs. execution) on purpose -- a Reasoning
Skill can never accidentally become executable, and an Execution Skill can
never accidentally leak into "guidance" a node treats as advisory rather
than a capability contract.

## 2. Node <-> Skill consumption matrix

| Node              | Reasoning Skill                    | Execution Skill                              |
|-------------------|-------------------------------------|-----------------------------------------------|
| Standardizer      | no                                   | no                                             |
| Analyzer          | yes (`SkillConsumerNode.ANALYZER`)  | no                                             |
| Planner           | yes (`SkillConsumerNode.PLANNER`)   | capability *summaries* only (SkillSummary via CapabilityRetriever) -- never selects a skill_id/tool_id directly |
| Execution Gate    | no                                   | no                                             |
| Executor          | no                                   | yes, only through `CapabilityResolver` (never picks a Skill by free text) |
| Reflector         | optional, future use (`SkillConsumerNode.REFLECTOR` exists, unused this phase) | no |
| Completion Check  | no                                   | no                                             |
| Synthesis         | yes (`SkillConsumerNode.SYNTHESIS`, contract-only -- Synthesis itself doesn't exist yet) | no |
| Evaluator         | future (rubric skills)              | no                                             |

This table is enforced, not just documented: `SkillDefinition.applicable_nodes`
is a closed `SkillConsumerNode` enum (an unknown node name is a
pydantic `ValidationError` at load time), and `ReasoningSkillRetriever`
filters on it directly (`agent/llm/context/reasoning_skill_retriever.py`).

**The Planner boundary is unchanged and Phase 5D does not weaken it**:
Planner chooses `Objective.action` + `target_ref`; `Executor` (via
`CapabilityResolver`) resolves *which* Skill/Tool actually runs. Reasoning
Skills give Planner *judgment* context (e.g. "weigh throughput impact
first") -- they never let it name a `skill_id`/`tool_id` (`PlannerDecision`'s
schema still structurally forbids those fields regardless).

## 3. How to add a Tool

1. Implement the `Tool` Protocol (`agent/tools/models.py`): a class with a
   `definition: ToolDefinition` and `run(request: ToolExecutionRequest) ->
   ToolExecutionResult`.
2. Register its input/output shapes with `PayloadRegistry.register(...)`.
3. Register the instance with a `ToolRegistry` -- in production, add one
   line to your own `tool_registrations` callback passed into
   `bootstrap_runtime` (`agent/bootstrap.py`); see
   `_register_oee_tools` there for the reference shape.

**Files touched**: one new Tool class + payload models. **Never touched**:
Executor, SkillRunner, CapabilityResolver, any LangGraph node,
`build_phase2_graph`. Proven by `tests/test_execution_skill_plugin_onboarding.py`.

## 4. How to add an Execution Skill

1. Write a markdown file with YAML frontmatter (see
   `agent/skills/oee/rca_equipment_detail.md` for a real example, or
   `tests/fixtures/dummy_skills/echo.md` for a minimal proof fixture):
   `skill_id`, `name`, `description`, `category`, `domains`, `task_types`,
   `actions` (which `ObjectiveAction`s this Skill satisfies),
   `required_tools`/`optional_tools`, `steps` (each a `tool_id` +
   `parameter_mapping`), `input_contract`/`output_contract`.
2. Drop it into a directory `SkillRegistry.load_directory(...)` reads
   (production: one of `AppConfig.skill_directories`).
3. Reference only Tools that are already registered --
   `SkillRegistry.validate_required_tools()` fails fast at bootstrap if not.

`skill_type` defaults to `execution`, so every pre-5D Skill file needs no
changes. **Never touched**: Executor, SkillRunner, CapabilityResolver,
Module Planner, LangGraph topology.

## 5. How to add a Reasoning Skill

1. Write a markdown file with `skill_type: reasoning`,
   `applicable_nodes: [analyzer, planner, ...]` (from the closed
   `SkillConsumerNode` set), optionally `domains`/`task_types`/`roles` to
   narrow when it's relevant. **No `required_tools`/`steps`/`actions`** --
   `SkillDefinition`'s own validator rejects a Reasoning Skill that
   declares any of those (a load-time `ValidationError`, not a silent
   no-op).
2. Drop it into a skill directory (production: also one of
   `AppConfig.skill_directories` -- `agent/skills/reasoning/` by default).
3. That's it -- no Tool, no code change. Proven end-to-end by
   `tests/test_external_reasoning_skill_onboarding.py` using
   `agent/skills/reasoning/plant_manager_perspective.md`, a real fixture
   file authored exactly the way an external contributor would.

## 6. How to add a Domain/Module

Only when the system needs a genuinely new, independent analysis
responsibility: its own `ModuleState` lifecycle, planning semantics
(`ModulePlanningPolicy`), and completion semantics. This means:

1. A new `ModuleDefinition` in the catalog (`_default_module_catalog()` in
   `agent/bootstrap.py`, or `ModuleRegistry.register(...)` directly).
2. A `ModulePlanningPolicy` implementation (see
   `agent/planning/policies/base.py`'s Protocol) -- the domain intelligence
   for that module (what Objectives to propose, when it's sufficient, how
   to describe a finding, how to update Branches/EntityStates/Findings).
3. A capability layer for it: Tools + Execution Skills, same as OEE's.
4. A `ModuleRuntimeConfig` entry wiring the policy + capability runtime +
   budget, added to the `module_runtime` dict `build_phase2_graph` reads.

**Architecture invariant (frozen this phase): adding a Skill does NOT
imply adding a Domain or a Tool.** A Reasoning Skill needs only metadata +
guidance text to exist. An Execution Skill usually needs a Tool (to have
something to chain), but never needs a new Domain/Module. A new
Domain/Module is a much bigger commitment -- new lifecycle/planning/
completion semantics -- and should never be reached for just because a new
Skill was added.

## 7. How to connect a real DB later

Boundary: `agent/datasource/models.py`'s `DataSource` Protocol
(`query(request: DataSourceQuery) -> DataSourceQueryResult`) +
`DataSourceConfig` (type + env-var *names* only, never a literal
host/connection-string/password). `InMemoryDataSource` is the only working
adapter today (`build_datasource(config, in_memory_factory=...)`); every
`remote_sql`/`rest_api`/`internal_service`/`rpc` config validates its env
vars and then deliberately stops at `DataSourceNotConnectedError`.

To connect a real DB: implement a new class satisfying the `DataSource`
Protocol (e.g. `RemoteSqlDataSource`, wrapping a real driver, reading its
endpoint/credential from the env vars `DataSourceConfig` already names),
and give `build_datasource` a branch for that `DataSourceType` that
constructs it instead of raising. No Tool that already depends on
`DataSource` needs to change -- it was written against the Protocol, not a
connection string, from day one.

## 8. How to connect a remote LLM later

Boundary: `agent/llm/client.py`'s `LLMClient` Protocol
(`complete(request: LLMRequest, output_model) -> LLMCompletion`).
`AnthropicAdapter` (`agent/llm/providers/anthropic_adapter.py`) is the
existing, real implementation of this exact Protocol -- `LLMRouter` never
imports a provider SDK directly, only ever holds whatever `LLMClient` it
was constructed with.

## 9. Composition root

`agent/bootstrap.py`'s `bootstrap_runtime(config: AppConfig, *,
tool_registrations=..., llm_client=..., in_memory_datasource_factory=...)`
is the one place production wiring happens. Future changes to *what
capability exists* should mostly touch: config, `tool_registrations`,
Skill markdown files, and (for a real DataSource/LLM adapter) a new
adapter class. `build_phase2_graph` and every LangGraph node are untouched
by this phase and are not expected to change for ordinary onboarding.

## 10. Startup validation (fail-fast)

`bootstrap_runtime` raises a typed exception immediately, never mid-run,
for duplicate tool/skill/module registration, missing tool for a skill,
malformed skill markdown, invalid enum values, a REASONING skill declaring
an executable-steps contract, an unknown module_type in enabled_modules,
and DataSource config errors.

## 11. Runtime invariant: never call `app.update_state()` on a pending Send/interrupt superstep

**Production code must never call `app.update_state()` while any task from
the current superstep is still pending** (i.e. while a Send-dispatched
Module Subgraph is paused on `interrupt()`). Phase 5B-1.1 empirically
pinned down the mechanism, Phase 8A-1 re-confirmed it: calling
`update_state()` on a checkpoint with a still-pending Send task causes
LangGraph to re-list every task from that pending superstep on the next
resume -- not just the interrupted branch. `RunController`
(`agent/persistence/run_controller.py`) is the only Harness-level bridge
between a LangGraph interrupt and `HumanAuditSink`, and resumes exclusively
via `Command(resume=...)`, never `update_state()`. Regression-guarded by
`tests/test_runtime_invariants.py` (AST scan, not text grep).
```

*(Sections 7/8/10 condensed above for length -- see the literal file at
`docs/architecture.md` for the exact original wording; no semantic content
was altered, only some duplicated YAML config examples and the full
fail-fast table were trimmed for this package. If exact byte-for-byte text
matters for the reviewing model, read `docs/architecture.md` directly.)*

### B.2 `docs/persistence.md` (full, current content, verbatim)

```markdown
# Persistence Architecture (Phase 8A / 8B)

Phase 8A: no real PostgreSQL, everything below is a provider-neutral
model/contract, backed by InMemory implementations. Phase 8B (section 11)
adds a real PostgreSQL adapter implementing the exact same Protocols --
still never connected to a real/remote database in this codebase's own
test suite, only to an ephemeral local container used for one-time
verification (never committed as a running fixture).

## 1. Checkpoint persistence vs. analysis/audit persistence

| | Checkpoint persistence | Analysis/Audit persistence |
|---|---|---|
| Answers | "Where is the Agent *right now*?" | "What did the Agent *find/do*?" |
| Owner | LangGraph's own checkpointer (`BaseCheckpointSaver`) | This codebase's repositories (`agent/persistence/`) |
| Unit | thread_id / checkpoint_ns / channel values | Run / Module / Objective / Evidence / Finding / ... |
| Lifecycle | Every superstep, including mid-run pending Sends | Once a value is final |
| Implementation this phase | `InMemorySaver` (development) | InMemory + PostgreSQL repositories (Phase 8B) |

`RunPersistenceWriter` runs *after* a module/run reaches a terminal state,
projecting from `AgentState` into repositories; it never reads or writes a
LangGraph checkpoint.

## 2. Four persistence domains

| Domain | Question | Owner |
|---|---|---|
| A. Runtime | "Where is execution right now?" | LangGraph checkpointer -- out of scope for repositories below |
| B. Analysis | "What did the Agent find?" | `RunRepository` |
| C. Audit | "How did the Agent analyze it?" | `AuditRepository` -- composes existing sinks |
| D. Learning | "What new Candidate did the Agent propose?" | `LearningCandidateRepository` |

Never one giant `AgentState` JSON table -- relational-core-plus-JSONB-
extension fields, never full normalization, never a single JSON dump.

## 3. Reused vs. new models

Reused as-is: `ObjectiveRecord`, `ToolCallRecord`, `LLMCallRecord`,
`ContextBuildRecord`, `SynthesisContextBuildRecord`, `PlannerDecisionRecord`,
`SynthesisGenerationRecord`, `EvaluationRecord`, `RunEvaluation`,
`HumanFeedback`, `LearningCandidate`, `LearningEvidenceLink`,
`CandidateReview`, `HandoffPackage`.

New (`agent/persistence/records.py`): `RunRecord`, `ModuleRunRecord`,
`EvidenceRecord`, `FindingRecord`, `FindingEvidenceLink`, `RootCauseRecord`,
`RootCauseFindingLink`, `ValidatedKnowledgeRecord` (future-only, unwritten).

## 4. Runtime-lineage gaps closed by Phase 8A-1

`ModuleState`/`AgentState` now carry real `started_at`/`completed_at`
(Phase 8A-1) -- `RunRecord`/`ModuleRunRecord`'s timestamps are sourced
directly from those, not from `UserRequest.submitted_at` proxies.

## 5. Repository boundaries

- **RunRepository** -- Run, ModuleRun, Objective, Evidence, Finding
  (+links), RootCause (+links), HandoffPackage -- one aggregate.
- **AuditRepository** -- compose-not-duplicate bundle of every audit Sink
  plus `RunEvaluationStore`.
- **HumanFeedbackRepository** -- `HumanFeedbackSink` already *is* this.
- **LearningCandidateRepository** -- thin wrapper around `LearningCandidateSink`.

## 6. Idempotency strategy

- **Upsert** (logical/analysis records: Run, ModuleRun, Objective, Finding,
  RootCause, RunEvaluation, LearningCandidate): keyed by stable domain id.
- **Append-only** (ToolCallRecord, HumanFeedback, LearningEvidenceLink):
  never deduplicated by content, keyed by stable id to prevent
  retry-duplication.

## 7. Transaction boundary

`PersistenceUnitOfWork`: `stage(fn)` queues a write; `commit()` runs the
queue; exception/explicit rollback/exiting without commit all discard the
queue.

## 8. RunPersistenceWriter

The only downstream service projecting `AgentState` (+ optional
`RunEvaluation`/`HumanFeedback`/`LearningCandidate`) into repository
writes. No LangGraph node writes to a repository directly.

## 9. Retention / sensitive-data policy

`PersistenceSettings`: `save_raw_prompt=False`, `save_raw_tool_payload=False`
(actively enforced -- redacts `EvidenceRecord.structured_payload`),
`audit_retention_days`/`analysis_retention_days` (contract only).

## 10. Schema versioning

New top-level records carry `schema_version: str = "1"`.

## 11. PostgreSQL adapter (Phase 8B)

Package: `agent/persistence/postgres/` -- `config.py`, `errors.py`,
`connection.py`, `migrations/0001_initial.sql` + `schema.py`, `mapping.py`,
`repositories.py`, `unit_of_work.py`. `agent/persistence/factory.py` is the
backend-selection seam (`PersistenceBackendConfig.backend`: `memory` |
`postgres`), consumed by `agent/bootstrap.py`'s `AppConfig.persistence`.

**Driver**: `psycopg` 3, raw parameterized SQL via named placeholders --
no ORM. Repositories depend only on a minimal duck-typed connection
surface, so `tests/postgres_fake.py::FakeConnection` exercises everything
without `psycopg` installed.

**FK strategy**: hard FKs only within the Run/Module/Objective/Evidence/
Finding/RootCause/HandoffPackage aggregate; audit + post-run Evaluation/
Feedback/Learning tables keep `run_id` as an indexed *conceptual* lineage
column with no hard FK (written at different times, different
transactions).

**Connection lifetime**: live/event sinks use one autocommit connection
each; `RunRepository` shares one long-lived non-autocommit connection with
`PostgresPersistenceUnitOfWork`; `RunRepository`'s read methods commit
immediately after fetching (a real deadlock bug found and fixed during
local-Postgres verification -- see `repositories.py::PostgresRunRepository`'s
docstring).

**Test safety**: `allow_test_database_only()` refuses to proceed unless
`require_test_database=True` AND the resolved database name contains
`test` and not `prod`. Only `tests/test_persistence_postgres_integration.py`
touches a real database, gated by `@pytest.mark.postgres` + `TEST_POSTGRES_DSN`
(unset by default).
```

**Doc-vs-code discrepancy check**: none found. Both documents accurately
describe current code as of this review (I cross-checked the sink names,
repository method names, and Phase 8B package layout against the actual
files in section D/E/F below).
