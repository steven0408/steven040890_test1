# Phase 8B-1 Re-Assessment (Part N)

This is an addendum to the original 4-part Architecture Review package
(`01_tree_and_docs.md` through `04_analysis.md`), not a full regeneration.
**Those 4 files are now stale in the specific places listed below** --
everywhere else in them (core state models, contracts, most of the
dependency scan) is unchanged and still accurate, since Phase 8B-1
deliberately did not touch `agent/state/`, `agent/persistence/`,
`agent/llm/context/`, `agent/synthesis/`, `agent/evaluation/`,
`agent/learning/`, or any LangGraph node.

## What's now stale in the original package

- **`01_tree_and_docs.md` section A** (project tree): missing the new
  `agent/modules/` package (`__init__.py`, `models.py`, `registry.py`,
  `oee/__init__.py`, `oee/package.py`), missing `agent/domain/oee/datasource.py`,
  missing `agent/graph/production.py`, and still lists
  `agent/skills/wip/current_level.md` (deleted, Part G).
- **`01_tree_and_docs.md` section B** (docs): `docs/architecture.md`
  sections 6/9 were rewritten this phase (see the live file for current
  text) -- the reproduced text in that package file is the pre-8B-1
  version.
- **`03_domain_bootstrap_contracts.md` section D.2/D.3 and section E**:
  the "how OEE is registered" table and the full `bootstrap.py` listing
  are now the OLD, pre-refactor shape. `bootstrap.py` no longer imports
  `OEEPlanningPolicy`/OEE Tool classes/`MOCK_EQUIPMENT` at all -- see the
  live file, or the diff described below.
- **`04_analysis.md` section G.5**: "4 OEE hardcode sites in bootstrap.py"
  no longer exist -- `bootstrap.py` is now domain-generic. Section G.4's
  correction (that this session's Part I work found) still applies and is
  now documented in `objective_action_design_review.md`.
- **`04_analysis.md` section J** (god files table): `bootstrap.py`'s
  import count (33) will have dropped (fewer domain-specific imports);
  line count changed. Not re-measured this session -- not load-bearing
  for the freeze decision.
- **`architecture_manifest.json`**: `domain_specific_imports_in_core`,
  `onboarding_change_counts`, and `coupling_report_grades` are all
  superseded by this file's tables below.

## What changed this phase (Phase 8B-1 summary)

| Area | Before | After |
|---|---|---|
| `agent/bootstrap.py` | imported `OEEPlanningPolicy`, 6 OEE Tool classes, `MOCK_EQUIPMENT`, `OEE_THRESHOLD`; hardcoded 1 `ModuleDefinition`; `if "OEE" in config.enabled_modules:` block | imports nothing OEE-specific; generic `for module_type in config.enabled_modules: package = packages.get(module_type); ...` loop over `ModulePackageRegistry` |
| OEE wiring | scattered across `bootstrap.py` (4 sites) | consolidated into `agent/modules/oee/package.py::build_oee_module_package()`, the only file importing OEE's concrete classes |
| OEE Tool data access | `QueryOEEDataTool(MOCK_EQUIPMENT, threshold)` -- raw list injected directly | `QueryOEEDataTool(datasource, threshold)` where `datasource: OEEDataSource` (new Protocol, `agent/domain/oee/datasource.py`); `InMemoryOEEDataSource` is the only implementation, still backed by `MOCK_EQUIPMENT` |
| Payload registration | `PayloadRegistry.register(...)` at import time (module-level side effect in `dataset.py`/`capability_tools.py`) | explicit `register_oee_result_payloads()`/`register_oee_input_payloads()`, called once by `ModulePackage.payload_registrations` |
| `agent/skills/wip/current_level.md` | orphaned, referenced a non-existent Tool | deleted |
| `analyzer_mock` | reachable as the silent default of `build_phase2_graph`/`build_phase6_graph`, no guard | still the default (unchanged, for the ~90 existing tests), but `agent/graph/production.py::build_production_graph()`/`build_production_graph_with_synthesis()` require `analyzer` explicitly; `agent/bootstrap.py` never imports `analyzer_mock` (AST-guarded) |
| `ObjectiveAction` | undocumented shared-enum coupling | design-reviewed, frozen at Option 1 this phase, Option 2 recommended for a future phase (`objective_action_design_review.md`); **new finding**: `agent/planning/policies/llm.py`'s `ACTION_TARGET_TYPE`/`ALLOWED_ACTIONS_BY_TASK_TYPE` dicts are a second, previously-unflagged shared-file coupling point for this enum |

## Updated coupling grades

| Dimension | Before (Phase 8B review) | After (Phase 8B-1) | Meets Part N target? |
|---|---|---|---|
| Core state isolation | A | A | target A -- met |
| Domain isolation | A- | **A** | target A -- met |
| Tool modularity | B+ | **A-** | target A- -- met |
| Skill modularity | A | A | target A -- met |
| DataSource modularity | B | **A-** | target A- -- met (OEE now genuinely exercises the boundary) |
| Context isolation | A | A | target A -- met |
| Persistence domain-agnostic | A | A | target A -- met |
| Bootstrap extensibility | C | **A-** | target A- -- met |
| New-domain onboarding | C+ | **A-** | target A- -- met |
| Removal ergonomics | B+ | **A-** | target A- -- met |

**Evidence for the upgraded grades**:
- Domain isolation A- -> A: OEE's Tools no longer take a raw injected
  list; they depend on a typed `OEEDataSource` Protocol, and
  `agent/modules/oee/package.py` is the sole file importing OEE's concrete
  classes.
- Tool modularity B+ -> A-: the Tool -> DataSource -> backend-adapter
  chain (Part D/E's target) is now real and proven
  (`InMemoryOEEDataSource` -> `QueryOEEDataTool` -> `SkillRunner`, exercised
  by the full existing OEE test suite, 41 tests, all still passing). Still
  A- not A because no domain-agnostic (`domains=[]`) shared Tool exists in
  production code yet -- unchanged limitation, out of this phase's scope.
- DataSource modularity B -> A-: same evidence as above, from the
  DataSource side.
- Bootstrap extensibility C -> A-: `bootstrap.py` contains zero
  domain-name literals or domain-specific imports; adding a package is a
  one-line registration, not an `if` block.
- New-domain onboarding C+ -> A-: `tests/test_modules_onboarding.py`'s
  `DummyYield` fixture is a real, running, end-to-end proof --
  `test_dummy_yield_runs_end_to_end_through_the_real_generic_harness`
  drives a request through the actual parent graph, actual Module ReAct
  subgraph, actual Module Completion Check, reaching a real terminal
  status, with zero changes to any file under `agent/`.
- Removal ergonomics B+ -> A-: `test_core_bootstrap_works_with_an_empty_module_package_registry`
  and `test_removing_oee_package_leaves_no_oee_payload_types_registered`
  prove this directly rather than by file-count inference.

## Onboarding change counts (measured, not estimated)

| Scenario | Existing files modified | Proven by |
|---|---|---|
| New Domain (`DummyYield`) | **0** | `tests/test_modules_onboarding.py` (the fixture is defined entirely inside the test file itself) |
| New Tool on an existing domain | **0** existing files (simulated via `dataclasses.replace` on a copy of the real package; a real onboarding edits exactly 1 line inside that domain's own `package.py`, which is not a "central"/shared file) | `test_new_tool_onboarding_touches_only_its_own_module_package` |
| New Execution Skill | **0** | `test_new_execution_skill_onboarding_is_a_pure_file_add` |
| New Reasoning Skill (no Tool) | **0** | `test_new_reasoning_skill_onboarding_is_a_pure_file_add_no_tool_needed` |

All four now meet the Part N target (LangGraph node / AgentState /
ModuleState / Persistence schema / bootstrap domain-specific-if-block
changes = 0).

## Freeze readiness

**Recommendation: ready to declare `Harness / Data Structure Architecture
V1 Frozen`**, conditional on the one open, explicitly-deferred item below.

**Closed this phase**: all 6 blocking/near-blocking items the original
review raised (bootstrap if-chain, orphan WIP skill, OEE bypassing
DataSource, implicit payload registration, analyzer_mock production
ambiguity) plus the newly-found `agent/planning/policies/llm.py` coupling
are now either fixed or explicitly, consciously deferred with a documented
reason (ObjectiveAction).

**Still open, by design (not a defect, a scoped decision)**: `ObjectiveAction`
stays Option 1 (shared closed enum) until a second real domain exists to
design Option 2's generic verb set against -- see
`objective_action_design_review.md` section 4. This does not block
connecting real OEE data (Part E proved the DataSource swap point works
without touching Tools/Skills/Planner); it only matters again when a
second real domain is actually built.
