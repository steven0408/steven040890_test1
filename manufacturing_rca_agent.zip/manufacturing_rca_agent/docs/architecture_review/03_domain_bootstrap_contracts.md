# Architecture Review Package -- Part 3: Domain Architecture, Bootstrap/Registration, Contracts + Examples

---

## D. Module / Domain architecture (OEE)

### D.1 Every OEE-related file, verbatim

**`agent/domain/oee/dataset.py`** (167 lines) -- the mock data + domain
result-shape models + `PayloadRegistry` registrations:

```python
"""Mock manufacturing dataset for Phase 5A -- deterministic stand-in for a
real OEE data source. 12 equipment: 5 abnormal (OEE below the 0.80
threshold), 7 normal.
"""
from agent.state.base import RCABaseModel
from agent.state.payload import PayloadRegistry


class EquipmentRecord(RCABaseModel):
    equipment_id: str
    availability: float
    performance: float
    quality: float
    oee: float
    production_weight: float
    downtime_minutes: float
    downtime_reason: str | None = None
    failure_reason: str | None = None


class EquipmentSnapshot(RCABaseModel):
    equipment_id: str
    oee: float
    availability: float
    performance: float
    quality: float
    production_weight: float


class ScreeningResult(RCABaseModel):
    threshold: float
    equipment: list[EquipmentSnapshot]


class EquipmentDetail(RCABaseModel):
    equipment_id: str
    downtime_minutes: float
    downtime_reason: str | None
    failure_reason: str | None


def pattern_of(snapshot: EquipmentSnapshot) -> str:
    """Which A/P/Q dimension is this equipment's worst."""
    values = {"Availability": snapshot.availability, "Performance": snapshot.performance, "Quality": snapshot.quality}
    return min(values, key=values.get)


class ContributionItem(RCABaseModel):
    equipment_id: str
    oee: float
    availability: float
    performance: float
    quality: float
    production_weight: float
    pattern: str
    contribution: float


class ContributionResult(RCABaseModel):
    threshold: float
    items: list[ContributionItem]


class PatternGroup(RCABaseModel):
    pattern: str
    equipment_ids: list[str]
    total_contribution: float


class RankedScreeningResult(RCABaseModel):
    threshold: float
    groups: list[PatternGroup]


class CurrentOEEStatus(RCABaseModel):
    threshold: float
    equipment_count: int
    average_oee: float
    worst_equipment_id: str
    worst_oee: float


def _record(equipment_id, availability, performance, quality, production_weight, downtime_minutes,
            downtime_reason=None, failure_reason=None) -> EquipmentRecord:
    return EquipmentRecord(
        equipment_id=equipment_id, availability=availability, performance=performance, quality=quality,
        oee=round(availability * performance * quality, 4), production_weight=production_weight,
        downtime_minutes=downtime_minutes, downtime_reason=downtime_reason, failure_reason=failure_reason,
    )


MOCK_EQUIPMENT: list[EquipmentRecord] = [
    # 5 abnormal (EQ001/EQ003/EQ012 availability, EQ007 performance, EQ009 quality)
    # 7 normal (EQ002/EQ004/EQ005/EQ006/EQ008/EQ010/EQ011)
    # -- full 12-row literal list in the actual file, omitted here for length,
    # see agent/domain/oee/dataset.py:143-158 for the exact values.
]

OEE_THRESHOLD = 0.80

PayloadRegistry.register("oee.screening_result", ScreeningResult)
PayloadRegistry.register("oee.equipment_detail", EquipmentDetail)
PayloadRegistry.register("oee.contribution_result", ContributionResult)
PayloadRegistry.register("oee.ranked_screening_result", RankedScreeningResult)
PayloadRegistry.register("oee.current_status", CurrentOEEStatus)
```

**`agent/planning/policies/oee.py`** (435 lines, `OEEPlanningPolicy` --
ALL OEE domain intelligence lives here: screening/grouping/ranking/
deep-dive selection/finding description for all three TaskTypes RCA/
ANALYSIS/INFORMATION). Full file already delivered verbatim in this
session's working context; key structural facts for the review:

- Implements the generic `ModulePlanningPolicy` protocol
  (`agent/planning/policies/base.py`) -- `propose_next_objective`,
  `is_sufficient`, `describe_finding`, `derive_state_updates`.
- Imports ONLY from `agent.domain.oee.dataset`, `agent.planning.contribution`,
  `agent.planning.policies.base`, `agent.state.*` -- no import from any
  other domain, no import from any graph node.
- Every OEE-specific concept (equipment, A/P/Q dimensions, contribution
  scoring, pattern grouping, deep-dive cap) is a private method (`_screening`,
  `_group_and_rank`, `_contribution`, `_propose_rca`, ...) -- nothing
  leaks out of this one class.
- The ONLY OEE-specific vocabulary that escapes this file into shared core
  state is via `ObjectiveAction.EQUIPMENT_SCREENING`/`EQUIPMENT_DETAIL`/
  `CURRENT_STATUS` (defined in `agent/state/enums.py`, see section C) and
  `TargetRefType.ENTITY`/`.MODULE` (generic, not OEE-specific).

**`agent/tools/oee/capability_tools.py`** (340 lines) -- 6 concrete Tool
classes (`QueryOEEDataTool`, `QueryEquipmentDetailTool`, `FilterRowsTool`,
`CalculateContributionTool`, `RankingTool`, `AggregateOEEStatusTool`), each
implementing the generic `Tool` Protocol (`agent/tools/models.py`). Full
file already delivered verbatim in working context. Structural facts:

- Every `ToolDefinition.domains=["oee"]` -- this is how `ToolRegistry.allowed_for("OEE")`
  and `CapabilityResolver`'s domain filter (`module_type.lower()`) restrict
  these tools to the OEE module without either registry/resolver knowing
  "OEE" as a special string; `"oee"` is just data on the Tool, matched
  generically against `module_type.lower()`.
- Each Tool's `run()` reads/writes only `agent.domain.oee.dataset` models
  -- the capability layer's generic `ToolExecutionRequest`/`ToolExecutionResult`
  envelope carries the OEE-typed payload opaquely.
- `QueryOEEDataTool`/`QueryEquipmentDetailTool` take `equipment: list[EquipmentRecord]`
  injected via constructor (from `MOCK_EQUIPMENT`, wired in
  `bootstrap.py::_register_oee_tools`) -- **OEE does NOT go through the
  `DataSource` abstraction** (`agent/datasource/models.py`) at all; it's
  still a raw in-process Python list injected directly. This is a real,
  concrete finding: the `DataSource` boundary Phase 5D built is currently
  unused by the one real domain that exists.

**`agent/skills/oee/*.md`** (4 files) -- `equipment_screening.md`
(ANALYSIS), `current_status.md` (INFORMATION), `rca_screening.md`/
`rca_equipment_detail.md` (RCA). One full example reproduced in section F.

### D.2 How OEE is registered into every registry

| Registry | OEE registration site | Mechanism |
|---|---|---|
| `ModuleRegistry` | `agent/bootstrap.py::_default_module_catalog()` | hardcoded `ModuleDefinition(module_type="OEE", ...)` literal in a Python function |
| `ToolRegistry` | `agent/bootstrap.py::_register_oee_tools()` (the **default** `tool_registrations` callback) | 6 explicit `tool_registry.register(SomeOEETool(...))` calls, each OEE Tool class imported by name |
| `SkillRegistry` | `AppConfig.skill_directories` default value = `[.../skills/oee, .../skills/reasoning]` | directory path, loaded generically via `SkillRegistry.load_directory()` -- **not a hardcoded skill_id list**, just a hardcoded default directory path |
| `CapabilityResolver` | not registered directly -- resolves generically from whatever's in SkillRegistry/ToolRegistry | **zero OEE-specific code** |
| `ModuleRuntimeConfig` | `agent/bootstrap.py::bootstrap_runtime()`, inside `if "OEE" in config.enabled_modules:` | hardcoded `if` block constructing `OEEPlanningPolicy()` + `LLMPlanningPolicy(...)` + `ModuleCapabilityRuntime(...)` |
| `PayloadRegistry` | `agent/domain/oee/dataset.py` + `agent/tools/oee/capability_tools.py` (both have module-level `PayloadRegistry.register(...)` calls at import time) | import-time side effect, not a bootstrap call |

### D.3 "If I wanted to completely remove OEE, which files would I need to change?"

**Files to DELETE outright** (pure OEE content, safe to remove wholesale):
```
agent/domain/oee/                      (dataset.py + __init__.py)
agent/planning/policies/oee.py
agent/tools/oee/                       (capability_tools.py + __init__.py)
agent/skills/oee/                      (4 .md files)
agent/tools/mocks/oee_data_tool.py     (legacy Phase 3-5A direct-tool path)
```

**Files to EDIT** (contain OEE-specific lines mixed with generic code):

1. `agent/bootstrap.py` -- 4 separate edits:
   - remove the `ModuleDefinition(module_type="OEE", ...)` entry from `_default_module_catalog()`
   - delete `_register_oee_tools()` entirely (and its 6 `from agent.tools.oee...` imports + `from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD`), and change `tool_registrations: Callable[...] = _register_oee_tools` to some other default (or make it required, no default)
   - delete the `if "OEE" in config.enabled_modules:` block (the only place `OEEPlanningPolicy`/`LLMPlanningPolicy`/`ModuleCapabilityRuntime` are wired for OEE)
   - remove `from agent.planning.policies.oee import OEEPlanningPolicy` import
2. `agent/graph/nodes/analyzer_mock.py` -- remove the hardcoded `ModuleTask(module_id="OEE", ...)` literal (one of 3 hardcoded entries; also touches Output/WIP, see section G)
3. `AppConfig.skill_directories`' default list (inside `agent/bootstrap.py`) -- drop the `skills/oee` path
4. `agent/domain/__init__.py` -- becomes an empty package (harmless to leave)

**Files that need ZERO changes** (this is the actual isolation proof):
`agent/state/*` (all of it), `agent/graph/nodes/module/*` (the entire
generic Module ReAct loop), `agent/capability/resolver.py`,
`agent/skills/registry.py`, `agent/skills/runner.py`, `agent/tools/registry.py`,
`agent/catalog/module_registry.py`, `agent/persistence/*` (all of it --
confirmed zero OEE references, section G), `agent/evaluation/*`,
`agent/learning/*`, `agent/synthesis/*`, `agent/llm/*` (all context
builders/retrievers are domain-agnostic).

**Net result**: removing OEE touches **2 files with real edits**
(`bootstrap.py`, `analyzer_mock.py`) plus deleting 5 self-contained
directories/files. No test-suite-wide ripple beyond the OEE-specific test
files themselves (`test_oee_capability_layer.py`, `test_oee_planning_policy.py`,
`test_mock_llm_planner_oee_traces.py`, `test_planner_context_oee_scenarios.py`,
and OEE-fixture-dependent assertions inside a handful of integration tests
like `test_phase5b21_parent_capability_wiring.py`).

---

## E. Bootstrap / Registration (full code)

### `agent/bootstrap.py` (253 lines, full -- current state including Phase 8B's `persistence` field)

```python
"""Composition root (Phase 5D-10) -- the one place production wiring
happens.
"""
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from pydantic import Field

from agent.capability.resolver import CapabilityResolver
from agent.catalog.module_registry import DuplicateModuleDefinitionError, ModuleDefinition, ModuleRegistry
from agent.datasource.models import DataSourceConfig, InMemoryDataSource, build_datasource
from agent.datasource.registry import DataSourceRegistry
from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.llm.client import LLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.context.analyzer_context import AnalyzerContextBuilder
from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
from agent.llm.context.context_audit import ContextAuditSink
from agent.llm.context.evidence_selector import DeterministicEvidenceSelector
from agent.llm.context.planner_context import PlannerContextBuilder
from agent.llm.context.reasoning_skill_retriever import DeterministicReasoningSkillRetriever
from agent.llm.router import LLMRouter
from agent.llm.usage import LLMUsageSink
from agent.persistence.factory import PersistenceBackendConfig, PersistenceLayer, build_persistence_layer
from agent.planning.decision_audit import PlannerDecisionAuditSink
from agent.planning.policies.llm import LLMPlanningPolicy
from agent.planning.policies.oee import OEEPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.base import RCABaseModel
from agent.state.enums import TaskType
from agent.state.models import Budget
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.oee.capability_tools import (
    AggregateOEEStatusTool, CalculateContributionTool, FilterRowsTool,
    QueryEquipmentDetailTool, QueryOEEDataTool, RankingTool,
)
from agent.tools.registry import ToolRegistry


class BootstrapConfigError(ValueError):
    pass


class AppConfig(RCABaseModel):
    factory_id: str
    factory_name: str
    enabled_modules: list[str] = Field(default_factory=lambda: ["OEE"])
    skill_directories: list[str] = Field(
        default_factory=lambda: [
            str(Path(__file__).resolve().parent / "skills" / "oee"),
            str(Path(__file__).resolve().parent / "skills" / "reasoning"),
        ]
    )
    datasources: dict[str, DataSourceConfig] = Field(default_factory=dict)
    llm_routes: dict[str, LLMRouteConfig] = Field(
        default_factory=lambda: {
            "analyzer": LLMRouteConfig(route="analyzer", model="claude-haiku-4-5-20251001"),
            "planner": LLMRouteConfig(route="planner", model="claude-haiku-4-5-20251001"),
        }
    )
    persistence: PersistenceBackendConfig = Field(default_factory=PersistenceBackendConfig)


@dataclass(frozen=True)
class RuntimeContext:
    module_registry: ModuleRegistry
    skill_registry: SkillRegistry
    tool_registry: ToolRegistry
    capability_resolver: CapabilityResolver
    reasoning_skill_retriever: DeterministicReasoningSkillRetriever
    datasource_registry: DataSourceRegistry
    llm_router: LLMRouter
    llm_usage_sink: LLMUsageSink
    context_audit_sink: ContextAuditSink
    decision_audit_sink: PlannerDecisionAuditSink
    analyzer_context_builder: AnalyzerContextBuilder
    persistence_layer: PersistenceLayer
    module_runtime: dict[str, ModuleRuntimeConfig] = field(default_factory=dict)


def _default_module_catalog() -> list[ModuleDefinition]:
    # *** OEE HARDCODE SITE 1/4 ***
    return [
        ModuleDefinition(
            module_type="OEE", name="OEE Analysis",
            description="Overall Equipment Effectiveness -- Availability/Performance/Quality across equipment.",
            supported_task_types=[TaskType.INFORMATION, TaskType.ANALYSIS, TaskType.RCA],
            key_questions=["What is current OEE?", "Which equipment has the worst OEE?", "Why did OEE decline?"],
        ),
    ]


def _register_oee_tools(tool_registry: ToolRegistry) -> None:
    # *** OEE HARDCODE SITE 2/4 -- also the DEFAULT tool_registrations callback ***
    tool_registry.register(QueryOEEDataTool(MOCK_EQUIPMENT, OEE_THRESHOLD))
    tool_registry.register(QueryEquipmentDetailTool(MOCK_EQUIPMENT))
    tool_registry.register(FilterRowsTool())
    tool_registry.register(CalculateContributionTool())
    tool_registry.register(RankingTool())
    tool_registry.register(AggregateOEEStatusTool())


def bootstrap_runtime(
    config: AppConfig,
    *,
    tool_registrations: Callable[[ToolRegistry], None] = _register_oee_tools,  # *** OEE HARDCODE SITE 3/4 (default arg) ***
    llm_client: LLMClient,
    in_memory_datasource_factory: Callable[[DataSourceConfig], InMemoryDataSource] | None = None,
) -> RuntimeContext:
    module_registry = ModuleRegistry()
    for definition in _default_module_catalog():
        module_registry.register(definition)
    for module_type in config.enabled_modules:
        try:
            module_registry.get(module_type)
        except Exception as exc:
            raise BootstrapConfigError(
                f"enabled_modules names '{module_type}', which has no built-in ModuleDefinition -- "
                "adding a genuinely new module requires adding one to _default_module_catalog() "
                "(and real planning/capability wiring), not just config"
            ) from exc

    skill_registry = SkillRegistry()
    for directory in config.skill_directories:
        skill_registry.load_directory(Path(directory))

    tool_registry = ToolRegistry()
    tool_registrations(tool_registry)
    skill_registry.validate_required_tools(tool_registry)

    capability_resolver = CapabilityResolver(skill_registry, tool_registry)
    reasoning_skill_retriever = DeterministicReasoningSkillRetriever(skill_registry)

    datasource_registry = DataSourceRegistry()
    for name, ds_config in config.datasources.items():
        datasource_registry.register(name, build_datasource(ds_config, in_memory_factory=in_memory_datasource_factory))

    persistence_layer = build_persistence_layer(config.persistence)
    llm_usage_sink = persistence_layer.audit_repository.llm_usage_sink
    llm_router = LLMRouter(routes=config.llm_routes, client=llm_client, usage_sink=llm_usage_sink)

    context_audit_sink = persistence_layer.audit_repository.planner_context_sink
    decision_audit_sink = persistence_layer.audit_repository.planner_decision_sink
    analyzer_context_builder = AnalyzerContextBuilder(module_registry, reasoning_skill_retriever=reasoning_skill_retriever)

    module_runtime: dict[str, ModuleRuntimeConfig] = {}
    if "OEE" in config.enabled_modules:  # *** OEE HARDCODE SITE 4/4 -- the big one ***
        planner_context_builder = PlannerContextBuilder(
            DeterministicEvidenceSelector(), DeterministicCapabilityRetriever(skill_registry),
            audit_sink=context_audit_sink, reasoning_skill_retriever=reasoning_skill_retriever,
        )
        oee_policy = LLMPlanningPolicy(
            OEEPlanningPolicy(), planner_context_builder, llm_router, decision_audit_sink=decision_audit_sink
        )
        module_runtime["OEE"] = ModuleRuntimeConfig(
            policy=oee_policy,
            capability=ModuleCapabilityRuntime(capability_resolver=capability_resolver, skill_runner=SkillRunner(tool_registry, ToolExecutionManager())),
            budget=Budget(max_steps=10, max_tool_calls=30, max_depth_per_entity=4),
        )

    return RuntimeContext(
        module_registry=module_registry, skill_registry=skill_registry, tool_registry=tool_registry,
        capability_resolver=capability_resolver, reasoning_skill_retriever=reasoning_skill_retriever,
        datasource_registry=datasource_registry, llm_router=llm_router, llm_usage_sink=llm_usage_sink,
        context_audit_sink=context_audit_sink, decision_audit_sink=decision_audit_sink,
        analyzer_context_builder=analyzer_context_builder, persistence_layer=persistence_layer,
        module_runtime=module_runtime,
    )
```

**This is the single most important file for your review question #6/#7.**
`bootstrap_runtime()`'s body is ~90 lines; roughly 25 of them (the
`if "OEE" in config.enabled_modules:` block, `_register_oee_tools`,
`_default_module_catalog`'s one entry) are OEE-specific and would need to
become a **generic per-module registration mechanism** (e.g. a
`dict[str, ModulePackage]` the loop iterates) before adding a second real
domain (Yield/WIP/Output) would be "config only, zero new `if` blocks".
Today, adding a second real domain means **copy-pasting this whole `if`
block with the new module_type name** -- it is not yet a loop over a
registry of domain plugins. See section K.

### `agent/catalog/module_registry.py` (76 lines, full)

```python
"""ModuleRegistry (Phase 5B-3) -- the high-level Module capability catalog
Analyzer reads instead of relying on prompt-hardcoded module names.
"""
from __future__ import annotations

from pydantic import Field

from agent.state.base import RCABaseModel
from agent.state.enums import TaskType
from agent.state.models import FactoryContext


class ModuleDefinition(RCABaseModel):
    module_type: str
    name: str
    description: str
    supported_task_types: list[TaskType]
    key_questions: list[str] = Field(default_factory=list)
    domains: list[str] = Field(default_factory=list)
    enabled: bool = True


class DuplicateModuleDefinitionError(ValueError):
    pass


class ModuleDefinitionNotFoundError(KeyError):
    pass


class ModuleRegistry:
    def __init__(self) -> None:
        self._modules: dict[str, ModuleDefinition] = {}

    def register(self, definition: ModuleDefinition) -> None:
        if definition.module_type in self._modules:
            raise DuplicateModuleDefinitionError(f"module_type '{definition.module_type}' is already registered")
        self._modules[definition.module_type] = definition

    def get(self, module_type: str) -> ModuleDefinition:
        definition = self._modules.get(module_type)
        if definition is None:
            raise ModuleDefinitionNotFoundError(f"no ModuleDefinition registered for module_type '{module_type}'")
        return definition

    def list(self) -> list[ModuleDefinition]:
        return list(self._modules.values())

    def available_for(self, factory_context: FactoryContext) -> list[ModuleDefinition]:
        return [
            definition for definition in self._modules.values()
            if definition.enabled and definition.module_type in factory_context.enabled_modules
        ]
```

### `agent/capability/resolver.py` (94 lines, full)

```python
"""CapabilityResolver (Phase 5B-2, action-based matching since Phase 5B-2.1).
Deterministic/rule-based (no LLM): matches an Objective's typed `action`
against each candidate Skill's own declared `actions`, filtered first by
`module_type` (Skill.domains) and `task_type` (Skill.task_types).
"""
from agent.skills.models import SkillDefinition, SkillType
from agent.skills.registry import SkillRegistry
from agent.state.base import RCABaseModel
from agent.state.enums import TaskType
from agent.state.models import Objective
from agent.tools.models import ToolDefinition
from agent.tools.registry import ToolRegistry


class CapabilityResolutionError(RuntimeError):
    def __init__(self, *, module_type: str, task_type: TaskType, objective_action: str, reason: str):
        self.module_type = module_type
        self.task_type = task_type
        self.objective_action = objective_action
        self.reason = reason
        super().__init__(
            f"no Skill resolves objective action '{objective_action}' for "
            f"module_type={module_type}, task_type={task_type.value}: {reason}"
        )


class ResolvedCapability(RCABaseModel):
    selected_skill: SkillDefinition
    resolved_tools: list[ToolDefinition]
    resolution_reason: str


class CapabilityResolver:
    def __init__(self, skill_registry: SkillRegistry, tool_registry: ToolRegistry):
        self._skills = skill_registry
        self._tools = tool_registry

    def resolve(self, objective: Objective, module_type: str, task_type: TaskType) -> ResolvedCapability:
        domain = module_type.lower()  # <-- NO hardcoded domain name anywhere in this class
        candidates: list[SkillDefinition] = []
        for skill in self._skills.list():
            if skill.skill_type != SkillType.EXECUTION:
                continue
            if skill.domains and domain not in skill.domains:
                continue
            if skill.task_types and task_type not in skill.task_types:
                continue
            if objective.action not in skill.actions:
                continue
            candidates.append(skill)

        if not candidates:
            raise CapabilityResolutionError(
                module_type=module_type, task_type=task_type, objective_action=objective.action.value,
                reason="no registered skill declares a matching domain/task_type/action",
            )

        candidates.sort(key=lambda skill: skill.skill_id)
        chosen = candidates[0]
        resolved_tools = [self._tools.get(tool_id).definition for tool_id in chosen.required_tools]
        reason = f"domain='{domain}' task_type='{task_type.value}' action='{objective.action.value}' matched skill '{chosen.skill_id}'"
        return ResolvedCapability(selected_skill=chosen, resolved_tools=resolved_tools, resolution_reason=reason)
```

### `agent/skills/registry.py` (90 lines, full)

```python
"""SkillRegistry (Phase 5B-2) -- loads Skills from their markdown files."""
from __future__ import annotations

from pathlib import Path

from agent.skills.markdown import parse_skill_markdown
from agent.skills.models import SkillDefinition, SkillType
from agent.tools.registry import ToolNotFoundError, ToolRegistry


class SkillRegistryError(ValueError):
    pass


class DuplicateSkillError(SkillRegistryError):
    pass


class SkillNotFoundError(SkillRegistryError):
    pass


class MissingToolForSkillError(SkillRegistryError):
    pass


class SkillRegistry:
    def __init__(self) -> None:
        self._skills: dict[str, SkillDefinition] = {}
        self._bodies: dict[str, str] = {}

    def register(self, definition: SkillDefinition, body: str = "") -> None:
        if definition.skill_id in self._skills:
            raise DuplicateSkillError(f"skill_id '{definition.skill_id}' is already registered")
        self._skills[definition.skill_id] = definition
        self._bodies[definition.skill_id] = body

    def load_markdown_file(self, path: Path) -> SkillDefinition:
        text = Path(path).read_text(encoding="utf-8")
        definition, body = parse_skill_markdown(text)
        self.register(definition, body)
        return definition

    def load_directory(self, directory: Path) -> list[SkillDefinition]:
        return [self.load_markdown_file(path) for path in sorted(Path(directory).glob("**/*.md"))]

    def get(self, skill_id: str) -> SkillDefinition:
        skill = self._skills.get(skill_id)
        if skill is None:
            raise SkillNotFoundError(f"no skill registered with skill_id '{skill_id}'")
        return skill

    def instructions(self, skill_id: str) -> str:
        self.get(skill_id)
        return self._bodies[skill_id]

    def list(self, *, domain=None, category=None, skill_type=None, enabled_only=True) -> list[SkillDefinition]:
        result = list(self._skills.values())
        if enabled_only:
            result = [s for s in result if s.enabled]
        if domain is not None:
            result = [s for s in result if not s.domains or domain.lower() in s.domains]
        if category is not None:
            result = [s for s in result if s.category == category]
        if skill_type is not None:
            result = [s for s in result if s.skill_type == skill_type]
        return result

    def validate_required_tools(self, tool_registry: ToolRegistry) -> None:
        for skill in self._skills.values():
            if skill.skill_type != SkillType.EXECUTION:
                continue
            for tool_id in (*skill.required_tools, *skill.optional_tools):
                try:
                    tool_registry.get(tool_id)
                except ToolNotFoundError as exc:
                    raise MissingToolForSkillError(
                        f"skill '{skill.skill_id}' requires tool '{tool_id}', which is not registered"
                    ) from exc
```

### `agent/skills/runner.py` (185 lines, full) -- reproduced verbatim in
working session context; key facts: `SkillRunner.run()` takes a
`SkillDefinition` + `Objective` + `ModuleState`, chains `skill.steps`
through `ToolExecutionManager.execute()`, zero domain-specific code.

### `agent/tools/registry.py` (48 lines, full)

```python
"""ToolRegistry (Phase 5B-2)."""
from __future__ import annotations

from agent.tools.models import Tool, ToolDefinition


class DuplicateToolError(ValueError):
    pass


class ToolNotFoundError(KeyError):
    pass


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        tool_id = tool.definition.tool_id
        if tool_id in self._tools:
            raise DuplicateToolError(f"tool_id '{tool_id}' is already registered")
        self._tools[tool_id] = tool

    def get(self, tool_id: str) -> Tool:
        tool = self._tools.get(tool_id)
        if tool is None:
            raise ToolNotFoundError(f"no tool registered with tool_id '{tool_id}'")
        return tool

    def list(self) -> list[ToolDefinition]:
        return [t.definition for t in self._tools.values()]

    def allowed_for(self, module_type: str) -> list[ToolDefinition]:
        domain = module_type.lower()  # <-- generic, no hardcode
        return [t.definition for t in self._tools.values() if not t.definition.domains or domain in t.definition.domains]
```

### `agent/datasource/models.py` (140 lines, full) + `agent/datasource/registry.py` (32 lines, full)

Both reproduced verbatim in working session context. `DataSourceConfig`
carries only `type`/`endpoint_env`/`credential_env`/`options` -- never a
literal secret. `build_datasource()` only has a working branch for
`DataSourceType.IN_MEMORY`; every remote type validates env vars then
raises `DataSourceNotConnectedError` (deliberately, per Phase 5D scope).
**OEE does not use this at all** -- see D.1's finding.

### `agent/persistence/factory.py` (Phase 8B backend selection -- see
Part 4/section E of the Phase 8B report for full content; already
delivered verbatim earlier this session, ~155 lines, `PersistenceBackendConfig`
+ `build_persistence_layer()`). Zero OEE/domain references.

---

## F. Skill / Tool / DataSource contracts + real examples

### F.1 `ToolDefinition` / `Tool` Protocol / `ToolExecutionRequest`/`Result` (`agent/tools/models.py`, 165 lines, full)

```python
import hashlib
from enum import Enum
from typing import Protocol

from pydantic import Field

from agent.state.base import RCABaseModel
from agent.state.enums import ErrorType, EvidenceQuality, ObservationStatus, RiskLevel
from agent.state.payload import StructuredPayload


class ToolCategory(str, Enum):
    QUERY = "query"
    TRANSFORM = "transform"
    CALCULATION = "calculation"
    SANDBOX = "sandbox"


class ToolSideEffect(str, Enum):
    READ_ONLY = "read_only"
    IDEMPOTENT_WRITE = "idempotent_write"
    NON_IDEMPOTENT_WRITE = "non_idempotent_write"


class ExecutionType(str, Enum):
    DETERMINISTIC = "deterministic"
    QUERY_BACKEND = "query_backend"
    SANDBOXED_CODE = "sandboxed_code"


class PermissionLevel(str, Enum):
    PUBLIC = "public"
    RESTRICTED = "restricted"
    ADMIN = "admin"


class ToolIOField(RCABaseModel):
    name: str
    type_name: str
    description: str
    required: bool = True


class ToolIOSchema(RCABaseModel):
    model_name: str
    fields: list[ToolIOField] = Field(default_factory=list)


class ToolDefinition(RCABaseModel):
    tool_id: str
    name: str
    description: str
    category: ToolCategory
    domains: list[str] = Field(default_factory=list)  # [] = shared/domain-agnostic
    input_schema: ToolIOSchema
    output_schema: ToolIOSchema
    execution_type: ExecutionType
    permission_level: PermissionLevel = PermissionLevel.PUBLIC
    risk_level: RiskLevel = RiskLevel.LOW
    read_only: bool = True
    side_effect: ToolSideEffect = ToolSideEffect.READ_ONLY
    timeout_seconds: float = 30.0
    sandbox_required: bool = False
    input_payload_type: str
    output_payload_type: str


class ToolExecutionIdentity(RCABaseModel):
    run_id: str
    module_id: str
    objective_id: str
    skill_id: str | None = None
    skill_step_id: str | None = None
    logical_attempt: int = 1

    def idempotency_key(self) -> str:
        parts = [self.run_id, self.module_id, self.objective_id, self.skill_id or "-", self.skill_step_id or "-", str(self.logical_attempt)]
        return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()


class ToolExecutionRequest(RCABaseModel):
    tool_id: str
    parameters: StructuredPayload
    run_id: str
    module_id: str
    objective_id: str | None = None
    requested_by_skill: str | None = None
    idempotency_key: str | None = None


class ToolExecutionResult(RCABaseModel):
    status: ObservationStatus
    payload: StructuredPayload | None = None
    summary: str | None = None
    error_type: ErrorType | None = None
    error_message: str | None = None
    quality: EvidenceQuality | None = None


class Tool(Protocol):
    definition: ToolDefinition

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult: ...
```

### F.2 Legacy `MockTool` Protocol (`agent/tools/base.py`, 26 lines, full -- still used by Harness-mechanics regression tests)

```python
from typing import Protocol

from agent.state.base import RCABaseModel
from agent.state.enums import ErrorType, EvidenceQuality, ObservationStatus
from agent.state.models import Objective
from agent.state.payload import StructuredPayload


class ToolResult(RCABaseModel):
    status: ObservationStatus
    payload_summary: str | None = None
    structured_payload: StructuredPayload | None = None
    quality: EvidenceQuality | None = None
    error_type: ErrorType | None = None
    error_message: str | None = None


class MockTool(Protocol):
    def run(self, objective: Objective) -> ToolResult: ...
```

### F.3 `SkillDefinition` / `SkillStep` / taxonomy (`agent/skills/models.py`, 144 lines, full)

```python
from datetime import datetime
from enum import Enum

from pydantic import Field, model_validator

from agent.state.base import RCABaseModel
from agent.state.enums import ObjectiveAction, RiskLevel, TaskType
from agent.state.models import ErrorRecord
from agent.state.payload import StructuredPayload


class SkillType(str, Enum):
    EXECUTION = "execution"
    REASONING = "reasoning"


class SkillConsumerNode(str, Enum):
    STANDARDIZER = "standardizer"
    ANALYZER = "analyzer"
    PLANNER = "planner"
    EXECUTION_GATE = "execution_gate"
    EXECUTOR = "executor"
    REFLECTOR = "reflector"
    COMPLETION_CHECK = "completion_check"
    SYNTHESIS = "synthesis"
    EVALUATOR = "evaluator"


class SkillStep(RCABaseModel):
    tool_id: str
    parameter_mapping: dict[str, str] = Field(default_factory=dict)


class SkillDefinition(RCABaseModel):
    skill_id: str
    name: str
    description: str
    domains: list[str] = Field(default_factory=list)
    category: str
    required_tools: list[str] = Field(default_factory=list)
    optional_tools: list[str] = Field(default_factory=list)
    steps: list[SkillStep] = Field(default_factory=list)
    input_contract: str
    output_contract: str
    risk_level: RiskLevel = RiskLevel.LOW
    version: str = "1"
    skill_type: SkillType = SkillType.EXECUTION
    applicable_nodes: list[SkillConsumerNode] = Field(default_factory=list)
    roles: list[str] = Field(default_factory=list)
    enabled: bool = True
    task_types: list[TaskType] = Field(default_factory=list)
    actions: list[ObjectiveAction] = Field(default_factory=list)

    @model_validator(mode="after")
    def _validate_skill_type_shape(self) -> "SkillDefinition":
        if self.skill_type == SkillType.REASONING and (self.steps or self.required_tools or self.optional_tools or self.actions):
            raise ValueError(
                f"skill '{self.skill_id}' is skill_type=reasoning but declares an executable-steps contract "
                "(steps/required_tools/optional_tools/actions) -- reasoning skills are pure guidance, never "
                "executed by SkillRunner/CapabilityResolver"
            )
        return self


class SkillExecutionStatus(str, Enum):
    SUCCESS = "success"
    ERROR = "error"


class SkillExecutionResult(RCABaseModel):
    skill_id: str
    status: SkillExecutionStatus
    output_payload: StructuredPayload | None = None
    summary: str
    tool_call_ids: list[str] = Field(default_factory=list)
    error: ErrorRecord | None = None
    started_at: datetime
    completed_at: datetime
```

### F.4 `ReasoningSkillRetriever` / `CapabilityRetriever` -- already reproduced verbatim above in section E context; both purely deterministic metadata filters, zero domain hardcode.

### F.5 `DataSource` Protocol / `DataSourceConfig` -- see section E, `agent/datasource/models.py`.

### F.6 `ModuleDefinition` -- see section E, `agent/catalog/module_registry.py`.

### F.7 Real examples

**One OEE Execution Skill markdown** (`agent/skills/oee/equipment_screening.md`, full):

```markdown
---
skill_id: oee.equipment_screening
name: Equipment Screening
description: Identify equipment whose OEE falls below the factory threshold.
domains: [oee]
category: screening
required_tools: [query_oee_data, filter_rows, calculate_contribution, ranking]
optional_tools: []
steps:
  - tool_id: query_oee_data
    parameter_mapping: {}
  - tool_id: filter_rows
    parameter_mapping:
      threshold: prev.threshold
  - tool_id: calculate_contribution
    parameter_mapping: {}
  - tool_id: ranking
    parameter_mapping: {}
input_contract: OEEQueryInput
output_contract: RankedScreeningResult
risk_level: low
version: "1"
task_types: [analysis]
actions: [equipment_screening]
---

# Skill: Equipment Screening

## Goal
Identify equipment whose OEE falls below the factory threshold.

## Procedure
1. Call `query_oee_data` to fetch A/P/Q/OEE for every equipment.
2. Call `filter_rows` (oee < threshold) to get the abnormal set.
3. Call `calculate_contribution` per equipment (abnormality x weight).
4. Call `ranking` to sort by contribution, grouped by worst dimension.

## Output Contract
RankedScreeningResult (agent.domain.oee.dataset).
```

**One Reasoning Skill markdown** (`agent/skills/reasoning/plant_manager_perspective.md`, full -- notice `domains: []`, `task_types: []`, no `steps`/`required_tools`/`actions` at all, exactly the shape Scenario 4 in section H would reuse):

```markdown
---
skill_id: reasoning.plant_manager_perspective
name: Plant Manager Perspective
description: Judge findings and next-step priorities the way a plant manager would -- throughput and delivery impact first, cosmetic metrics last.
category: perspective
input_contract: AnalyzerContext / PlannerContext
output_contract: guidance text (no structured output -- pure judgment framing)
skill_type: reasoning
applicable_nodes: [analyzer, planner, synthesis]
domains: []
task_types: []
roles: [plant_manager]
version: "1"
---

# Skill: Plant Manager Perspective

## Goal
Frame decisions the way a plant manager actually prioritizes them on a
production floor -- guidance for *how to weigh options*, not a procedure
to execute. There is no Tool behind this Skill.

## Guidance
- Throughput and on-time-delivery impact outweigh cosmetic metric
  improvements.
- Prefer root causes that are actionable this shift over root causes that
  require a capital project, all else equal.
- Do not let this framing override evidence.
```

**One OEE Tool** (`QueryOEEDataTool`, from `agent/tools/oee/capability_tools.py`):

```python
class QueryOEEDataTool:
    def __init__(self, equipment: list[EquipmentRecord], threshold: float, unavailable: bool = False):
        self._equipment = equipment
        self._threshold = threshold
        self._unavailable = unavailable
        self.definition = ToolDefinition(
            tool_id="query_oee_data", name="Query OEE Data",
            description="Fetch A/P/Q/OEE for every equipment (raw, unfiltered).",
            category=ToolCategory.QUERY, domains=["oee"],
            input_schema=ToolIOSchema(model_name="OEEQueryInput"),
            output_schema=ToolIOSchema(model_name="ScreeningResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="oee.query_input", output_payload_type="oee.screening_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        PayloadRegistry.unpack(request.parameters)
        if self._unavailable:
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=ErrorType.DATA_NOT_FOUND,
                                        error_message="OEE data source unavailable for 'screen_equipment'")
        result = ScreeningResult(threshold=self._threshold, equipment=[
            EquipmentSnapshot(equipment_id=e.equipment_id, oee=e.oee, availability=e.availability,
                               performance=e.performance, quality=e.quality, production_weight=e.production_weight)
            for e in self._equipment
        ])
        abnormal_count = sum(1 for e in result.equipment if e.oee < result.threshold)
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("oee.screening_result", result),
            summary=f"Screened {len(result.equipment)} equipment against a {result.threshold:.0%} OEE threshold; {abnormal_count} abnormal.",
            quality=EvidenceQuality.STRONG,
        )
```

**One "shared"/domain-agnostic Tool**: **there is currently NO Tool in the
codebase with `domains=[]` (truly shared across all modules)**. Every real
Tool (`agent/tools/oee/capability_tools.py`'s 6 classes) declares
`domains=["oee"]`. `ToolRegistry.allowed_for()`'s `not t.definition.domains`
branch (shared-tool support) exists and is tested
(`tests/test_capability_registries.py` per naming convention), but has
**zero real production example** -- this is a documented capability with
no real-world instance yet, worth flagging in section I/K as "untested in
anger."
