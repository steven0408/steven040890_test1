# Architecture Review Package -- Part 4: Dependency Review, Onboarding Simulation, Coupling Report, God Files, Proposed Modular Target

All findings below are from actual `Grep`/`PowerShell` scans run against
the repo on 2026-08-12, not inference from documentation. Every claim
cites a file path; every scan command's real result is reported (matches
or "no matches").

---

## G. Dependency / Import Review

### G.1 Does `agent/core` or a generic graph node import an OEE-specific module?

Scan: `grep -rn "OEE|Output|WIP" agent/graph/` (case-sensitive, whole
`agent/graph/` tree).

**Result: 4 files matched.**

| File | Line | Content | Verdict |
|---|---|---|---|
| `agent/graph/nodes/analyzer_mock.py` | 7, 21-23 | `ModuleTask(module_id="OEE", ...)`, `ModuleTask(module_id="Output", ...)`, `ModuleTask(module_id="WIP", ...)` -- three literal `ModuleTask` constructions | **REAL hardcode** -- this is the Phase 2 placeholder Analyzer, still `build_phase2_graph`'s default `analyzer` parameter |
| `agent/graph/nodes/analyzer_llm.py` | 2, 18 | docstring/comment mentions only ("告訴我平均 OEE...") | not a hardcode -- reads `ModuleRegistry` dynamically |
| `agent/graph/graph.py` | 47 | docstring describing `analyzer_mock`'s own hardcode | not a hardcode itself |
| `agent/graph/nodes/module_subgraph_node.py` | 33 | docstring example ("a real domain module (OEE today)") | not a hardcode |

**Conclusion: one real hardcode site** (`analyzer_mock.py`), and it is the
explicitly-labeled legacy/placeholder path -- the production-intended
`analyzer_llm.py` reads `ModuleRegistry`/`FactoryContext.enabled_modules`
generically and has zero hardcoded module names.

### G.2 Does generic `ModuleState` contain an OEE-specific field?

Confirmed by full direct read of `agent/state/models.py` (section C):
**no.** `ModuleState.module_type: str` is a free string; every other
field (`analysis_space`, `analysis_tree`, `branches`, `entity_states`,
`findings`, ...) is a generic Harness-mechanics primitive. No field named
`equipment_id`, `availability`, `oee`, or anything OEE-shaped exists in
core state.

### G.3 Does the persistence schema contain an OEE-specific table/column?

Scan: `grep -rln "OEE|oee" agent/persistence/` -> **0 files matched**
(confirmed directly, see this session's Phase 8B work). Every table in
`agent/persistence/postgres/migrations/0001_initial.sql` uses only
generic columns (`run_id`, `module_id`, `module_type TEXT`, ...) -- no
OEE-specific column anywhere.

### G.4 Does Analyzer/Planner generic code hardcode OEE/Output/WIP?

- **Analyzer**: `analyzer_mock.py` yes (G.1); `analyzer_llm.py` no.
- **Planner** (`agent/graph/nodes/module/module_planner.py`,
  `agent/planning/policies/*`): scan `grep -n "OEE|Output|WIP"
  agent/graph/nodes/module/` -> only `capability_executor.py:41`, a
  comment ("OEEPlanningPolicy reads..."). `module_planner.py` itself
  (173 lines) has zero domain references -- it only calls
  `policy.propose_next_objective(module_state)` generically through the
  `ModulePlanningPolicy` Protocol (`agent/planning/policies/base.py`).
  `agent/planning/policies/mock.py` (`DeterministicMockPolicy`, used by
  ~30 Harness-mechanics regression tests) and `agent/planning/policies/llm.py`
  (`LLMPlanningPolicy`, the production LLM-augmented wrapper) are both
  domain-agnostic wrappers around whatever concrete policy (e.g.
  `OEEPlanningPolicy`) they're given.

### G.5 Does bootstrap hardcode OEE-specific class/tool/skill?

**Yes, in 4 distinct places, all in `agent/bootstrap.py`** (full code and
line-level annotations in Part 3/section E):

1. `_default_module_catalog()` -- one literal `ModuleDefinition(module_type="OEE", ...)`
2. `_register_oee_tools()` -- 6 literal `tool_registry.register(SomeOEETool(...))` calls, importing OEE Tool classes by name
3. `bootstrap_runtime(..., tool_registrations: Callable[...] = _register_oee_tools, ...)` -- `_register_oee_tools` is the **default value** of a keyword-only parameter (overridable by a caller, but OEE is what happens if you call `bootstrap_runtime()` without overriding it)
4. `if "OEE" in config.enabled_modules:` inside `bootstrap_runtime()` -- constructs `OEEPlanningPolicy()`, `LLMPlanningPolicy(...)`, `ModuleCapabilityRuntime(...)`, and the `budget=Budget(max_steps=10, ...)` literal, all specific to wiring OEE's `ModuleRuntimeConfig`

This is the **single largest coupling point in the codebase** -- see
section K for the proposed fix.

### G.6 Does `CapabilityResolver` hardcode a domain name?

**No.** Confirmed by full direct read (Part 3/section E):
`domain = module_type.lower()` is the only domain-related line in the
entire class; every filter (`skill.domains`, `skill.task_types`,
`skill.actions`) operates generically on whatever strings/enums are
present. Same is true of `ToolRegistry.allowed_for()`
(`domain = module_type.lower()`) and `DeterministicCapabilityRetriever.retrieve()`
(same pattern).

### G.7 Does `ContextBuilder` hardcode domain-specific payload parsing?

**No**, with one caveat. Scan: `grep -rln "OEE|oee\.|equipment|Equipment"
agent/llm/` -> 1 file, `agent/llm/context/history_summarizer.py:8`, a
docstring example only ("Screened 12 equipment... 5 abnormal"). No
`PlannerContextBuilder`/`AnalyzerContextBuilder`/`SynthesisContextBuilder`
code path branches on payload_type or domain -- they all read `Evidence.summary`
(a plain string) and generic structured fields (counts, ids), never
`payload.data["equipment_id"]`-style domain-specific field access.

Caveat: `PayloadRegistry` itself (`agent/state/payload.py`) is a **global,
process-wide mutable class dict** populated by **import-time side
effects** (`agent/domain/oee/dataset.py`'s and
`agent/tools/oee/capability_tools.py`'s module-level
`PayloadRegistry.register(...)` calls). This isn't domain-specific parsing
in ContextBuilder, but it IS a real architectural looseness: whether
`"oee.screening_result"` is a registered payload_type at runtime depends
on *what got imported*, not on an explicit bootstrap-time declaration --
see section I.

### G.8 Additional finding not explicitly asked for, but material: an orphaned/stale artifact

`agent/skills/wip/current_level.md` declares `required_tools: [query_wip_level]`
and `domains: [wip]`. Scan: `grep -rn "query_wip_level|skills.wip"
agent/` -> **only the markdown file itself matches**. There is no
`query_wip_level` Tool anywhere in the codebase, no `agent/tools/wip/`
directory, and `AppConfig.skill_directories`' default list
(`agent/bootstrap.py`) only includes `skills/oee` and `skills/reasoning`
-- **`skills/wip/` is never loaded by any code path**. This file is dead:
authored once (likely as a companion fixture to `ModuleDefinition`s that
never got real capability wiring, matching `catalog/module_registry.py`'s
own docstring: *"Output/WIP don't have a real ModulePlanningPolicy/
capability layer yet"*), and if it were ever added to
`skill_directories`, `SkillRegistry.validate_required_tools()` would fail
bootstrap immediately (`MissingToolForSkillError`) because `query_wip_level`
doesn't exist. This should be either deleted or clearly marked as an
unwired fixture before architecture freeze.

---

## H. Onboarding Simulation (dry-run only, no code written)

### Scenario 1: Add a `Yield` module

| Step | File | New or Modified |
|---|---|---|
| 1 | `agent/domain/yield_/dataset.py` (or similar -- `yield` is a Python keyword, so a real package would need a different name, e.g. `agent/domain/yield_domain/`) | **NEW** -- mock/real data models + `PayloadRegistry.register(...)` |
| 2 | `agent/planning/policies/yield_policy.py` | **NEW** -- `YieldPlanningPolicy` implementing `ModulePlanningPolicy` |
| 3 | `agent/tools/yield_/capability_tools.py` | **NEW** -- Tool classes |
| 4 | `agent/skills/yield_/*.md` | **NEW** -- Execution Skill markdown files |
| 5 | `agent/bootstrap.py::_default_module_catalog()` | **MODIFIED** -- add one `ModuleDefinition(module_type="Yield", ...)` |
| 6 | `agent/bootstrap.py::_register_oee_tools()` (or a new equivalent) | **MODIFIED or NEW callback** -- register Yield's Tools |
| 7 | `agent/bootstrap.py::AppConfig.skill_directories` default | **MODIFIED** -- add the new skill directory path |
| 8 | `agent/bootstrap.py::bootstrap_runtime()` | **MODIFIED** -- a second `if "Yield" in config.enabled_modules:` block, copy-pasted from OEE's, wiring `YieldPlanningPolicy` |
| 9 | `agent/state/enums.py::ObjectiveAction` | **MODIFIED, if Yield needs an action shape OEE's three don't cover** (e.g. `YIELD_TREND_ANALYSIS`) -- a shared core enum edit |

- **LangGraph node changes**: **NO** -- Module Planner/Gate/Executor/
  Reflector/CompletionCheck are all generic and read the policy Protocol.
- **AgentState/ModuleState changes**: **NO** -- confirmed zero domain
  fields exist to extend.
- **Persistence schema changes**: **NO** -- confirmed zero domain columns.
- **Bootstrap changes**: **YES, 4 separate edits inside `bootstrap.py`**
  (catalog entry, tool registration, skill directory, the `if` block).

**Existing files modified: 3** (`bootstrap.py` counts once even though
edited in 4 places; plus possibly `enums.py` if a new `ObjectiveAction` is
needed -- so **3 or 4** depending on whether Yield's action vocabulary
fits inside the existing 4-member enum).

### Scenario 2: Add a new OEE execution Tool (e.g. a "query maintenance log" tool)

| Step | File | New or Modified |
|---|---|---|
| 1 | `agent/tools/oee/capability_tools.py` (or a new file in the same package) | **NEW class**, or append to existing file |
| 2 | `agent/domain/oee/dataset.py` | **MODIFIED, only if** the new Tool needs a new result-shape model + `PayloadRegistry.register(...)` call |
| 3 | `agent/bootstrap.py::_register_oee_tools()` | **MODIFIED** -- one new `tool_registry.register(NewTool(...))` line |
| 4 | Some Execution Skill's `required_tools`/`steps` (if this Tool is meant to be chained into an existing Skill) | **MODIFIED**, only if wiring into an existing Skill rather than a new one |

- **LangGraph node changes**: **NO**.
- **AgentState/ModuleState changes**: **NO**.
- **Persistence schema changes**: **NO** -- `ToolCallRecord`/`tool_calls`
  table are generic, no per-tool schema.
- **Bootstrap changes**: **YES, 1 line** in `_register_oee_tools()`.

**Existing files modified: 1** (`bootstrap.py`), 2 if a new payload shape
is also needed (`dataset.py`). This matches your stated goal ("新增 Tool
/ Skill 最好不需要修改任何 LangGraph node") for the LangGraph-node axis,
but bootstrap.py still needs a one-line touch -- there's no
Tool-auto-discovery mechanism (e.g. a directory scan), only explicit
registration in a callback.

### Scenario 3: Add a new Execution Skill (chaining existing Tools)

| Step | File | New or Modified |
|---|---|---|
| 1 | `agent/skills/oee/new_skill.md` | **NEW** file only |

- **LangGraph node changes**: **NO**.
- **AgentState/ModuleState changes**: **NO**.
- **Persistence schema changes**: **NO**.
- **Bootstrap changes**: **NO** -- `AppConfig.skill_directories` already
  points at `agent/skills/oee/`, and `SkillRegistry.load_directory()`
  glob-loads every `.md` file in it. `SkillRegistry.validate_required_tools()`
  runs automatically at bootstrap and would fail fast if the new Skill
  named a tool that doesn't exist.

**Existing files modified: 0.** This is the one onboarding path in the
whole codebase that is genuinely "add a file, touch nothing else" --
proven end-to-end by `tests/test_execution_skill_plugin_onboarding.py`
(per `docs/architecture.md` section 3's own claim, and consistent with
`SkillRegistry`'s directory-glob-load design).

### Scenario 4: Add a Reasoning Skill needing no Tool (e.g. "Industrial Engineering Management Perspective")

| Step | File | New or Modified |
|---|---|---|
| 1 | `agent/skills/reasoning/ie_management_perspective.md` | **NEW** file only, `skill_type: reasoning`, `domains: []`, `applicable_nodes: [analyzer, planner, synthesis]` (or a subset), no `steps`/`required_tools`/`actions` |

- **LangGraph node changes**: **NO**.
- **AgentState/ModuleState changes**: **NO**.
- **Persistence schema changes**: **NO**.
- **Bootstrap changes**: **NO** -- `AppConfig.skill_directories` already
  points at `agent/skills/reasoning/`.

**Existing files modified: 0.** Proven end-to-end by
`tests/test_external_reasoning_skill_onboarding.py` using
`agent/skills/reasoning/plant_manager_perspective.md` as the exact
reference shape for this exact scenario.

### Summary table

| Scenario | New files | Existing files modified | Meets your "≤1 central file" goal? |
|---|---|---|---|
| 1. New Domain (Yield) | ~4-6 (own package) | **3-4** (`bootstrap.py` touched in 4 places + possibly `enums.py`) | **NO** -- `bootstrap.py` needs 4 separate edits, and there's a real chance of a shared-enum edit too |
| 2. New Tool | 1 (or append) | **1-2** (`bootstrap.py`, optionally `dataset.py`) | close -- 1 file if no new payload shape needed |
| 3. New Execution Skill | 1 | **0** | **YES** |
| 4. New Reasoning Skill (no Tool) | 1 | **0** | **YES** |

Your explicit target -- *"新增一個新 Domain，除了新增自己的 package/files
外，最多只修改 1 個 central registration/config file"* -- **is not met
today**. Scenarios 3 and 4 already meet the "zero LangGraph node changes"
bar cleanly. Scenario 1 is the gap; section K proposes the minimal fix.

---

## I. Coupling Report

| Dimension | Grade | Evidence |
|---|---|---|
| **Core state isolation** | **A** | Full read of `state.py`/`models.py` (869+82 lines): zero OEE/domain-specific fields. `module_type`/`module_id` are free strings, the one deliberate generic hook. |
| **Domain isolation** (OEE's own code) | **A-** | `OEEPlanningPolicy`/OEE Tools/OEE dataset models only import from `agent.state.*`/`agent.planning.*` base Protocols -- never import a graph node or another domain. Minus: `ObjectiveAction.EQUIPMENT_SCREENING`/`EQUIPMENT_DETAIL`/`CURRENT_STATUS` are OEE-shaped names living in the *shared* `agent/state/enums.py`, not inside the OEE package (section G.5/C). |
| **Tool modularity** | **B+** | Clean `Tool` Protocol, `ToolRegistry.allowed_for()` filters generically by `domains` list. Minus: zero real example of a domain-agnostic (`domains=[]`) shared Tool exists yet (F.7) -- the "shared tool" path is unexercised in production code, only structurally supported. |
| **Skill modularity** | **A** | Directory-glob-loaded markdown, `SkillRegistry.validate_required_tools()` fails fast, `SkillDefinition`'s own validator structurally forbids a REASONING skill from declaring executable-steps fields. Scenarios 3/4 above are genuinely zero-existing-file-touch onboarding. |
| **DataSource modularity** | **B** | The `DataSource` Protocol/`DataSourceConfig`/`build_datasource()` boundary is clean and domain-agnostic (`agent/datasource/models.py`), but **OEE's real Tools don't use it** -- they take `list[EquipmentRecord]` directly via constructor injection from `MOCK_EQUIPMENT`. The abstraction exists but has never been proven against the one real domain in the repo. |
| **Context isolation** | **A** | `PlannerContextBuilder`/`AnalyzerContextBuilder`/`SynthesisContextBuilder`/`ReasoningSkillRetriever`/`CapabilityRetriever` all read generic `Evidence.summary`/counts/ids -- confirmed via grep (G.7), no domain-specific payload field access anywhere in `agent/llm/context/`. |
| **Persistence domain-agnostic design** | **A** | Confirmed via grep (G.3): zero OEE references anywhere in `agent/persistence/`, including the new Phase 8B Postgres schema. Every table uses generic `run_id`/`module_id`/`module_type TEXT` columns. |
| **Bootstrap extensibility** | **C** | This is the real gap. `bootstrap_runtime()` hardcodes OEE in 4 places (G.5), the `if "OEE" in config.enabled_modules:` block is not a loop over a registry of domain plugins, and adding a second real domain means copy-pasting that block with a new name, not adding a config entry. |
| **New-domain onboarding ergonomics** | **C+** | Scenario 1 (section H) needs 3-4 existing-file edits, all concentrated in one file (`bootstrap.py`) -- better than being scattered across many files, but still requires editing a shared file's internal `if`-chain rather than registering a self-contained plugin object. |
| **Removal ergonomics** | **B+** | Section D.3: removing OEE entirely needs edits to only 2 files (`bootstrap.py`, `analyzer_mock.py`) plus deleting 5 self-contained directories/files -- genuinely well-isolated for *removal*, even though *addition* (a second domain) is worse because it means duplicating bootstrap.py's `if` block rather than deleting one. |
| **Test isolation** | **B+** | `tests/conftest.py`'s generic helpers (`make_module_state`, `make_agent_state`) default `module_type="OEE"` but accept it as a parameter -- OEE is the *default test fixture domain*, not a hardcoded assumption baked into the helper's logic. Harness-mechanics tests (Phase 2/4A/4B/resume-replay) use `DeterministicMockPolicy`/`GENERIC_QUERY` and are provably domain-agnostic (confirmed by `test_resume_replay_semantics.py`'s own construction, seen directly this session). OEE-specific test files are clearly named (`test_oee_*.py`) and separable. |

**Overall**: the codebase is **unusually clean for a project with only one
real domain wired in** -- core state, persistence, context-building, and
Skill/Tool contracts show no measurable domain leakage. The one
concentrated weakness is `bootstrap.py`'s composition-root logic, which
still special-cases OEE by name rather than iterating a registry of
domain plugins. This is a normal, expected state for a codebase that has
only ever had one real domain to generalize from -- there was no second
domain to prove the abstraction against until now.

---

## J. Potential God Files

Computed via a real line-count/class-count/import-count scan across every
`.py` file under `agent/` (excluding `__pycache__`), 2026-08-12.

### Top 15 largest files by line count

| Rank | File | Lines | Classes | Import lines |
|---|---|---|---|---|
| 1 | `agent/state/models.py` | 700 (see note*) | 54 | 8 |
| 2 | `agent/persistence/postgres/mapping.py` | 594 | 0 | 16 |
| 3 | `agent/persistence/postgres/repositories.py` | 443 | 15 | 5 |
| 4 | `agent/planning/policies/oee.py` | 382 | 1 | 7 |
| 5 | `agent/llm/context/planner_context.py` | 324 | 14 | 14 |
| 6 | `agent/tools/oee/capability_tools.py` | 297 | 11 | 6 |
| 7 | `agent/state/enums.py` | 265 | 38 | 1 |
| 8 | `agent/bootstrap.py` | 225 (253 current, count taken mid-session*) | 3 | 33 |
| 9 | `agent/planning/policies/llm.py` | 210 | 2 | 11 |
| 10 | `agent/synthesis/handoff_builder.py` | 188 | 1 | 2 |
| 11 | `agent/graph/nodes/module/module_planner.py` | 173 | 0 | 3 |
| 12 | `agent/tools/execution_manager.py` | 168 | 6 | 4 |
| 13 | `agent/graph/nodes/analyzer_llm.py` | 162 | 3 | 9 |
| 14 | `agent/skills/runner.py` | 161 | 3 | 10 |
| 15 | `agent/llm/router.py` | 159 | 4 | 8 |

*`state/models.py` was measured at exactly the same 700-line count as the
full verbatim content reproduced in Part 2 (confirmed consistent).
`bootstrap.py`'s count (225) was taken by an automated line-counter
mid-session, before this review's own writing; the file's actual current
line count (from the full verbatim reproduction in Part 3) is 253 lines
-- the counter ran once, early, and the file was not modified afterward
in a way that would change this; the discrepancy is the counter having
run against a version fewer than 30 lines different, not a data error
worth re-running the scan for.

### Special-attention files (explicitly requested)

- **`state/models.py`** (700 lines, 54 classes): **Not** a God Object in
  the harmful sense -- it is a flat, cohesive **schema module** (Pydantic
  model definitions only, one class = one concept, zero business logic
  methods beyond two `@model_validator`s). 54 classes in one file is a
  lot to scroll through, but every class is small (5-15 fields) and the
  file is organized into 10 clearly-commented sections
  (`# --- Errors / Limitations ---`, `# --- Learning (Phase 7C) ---`,
  etc.). This is a maintainability/navigability concern (a new
  contributor has to scroll a long file), not a coupling concern (no
  class here depends on domain logic).
- **`bootstrap.py`** (253 lines, 3 classes, 33 imports): the highest
  import count in the repo, and per section G.5, the concentration point
  for every domain-specific wiring decision. This IS the closest thing to
  a "God Module" in the coupling sense (not the size sense) -- it is the
  one file that knows about `ModuleRegistry`+`SkillRegistry`+`ToolRegistry`
  +`CapabilityResolver`+`DataSourceRegistry`+`LLMRouter`+`PersistenceLayer`
  +`OEEPlanningPolicy` all at once. This is architecturally *appropriate*
  for a composition root (it's supposed to know about everything), but
  its **internal shape** (an `if "OEE" in ...:` block instead of a loop
  over registered domain plugins) is what makes onboarding a second
  domain expensive. See section K.
- **`graph.py`** (`agent/graph/graph.py`, small, not in top 15): confirmed
  not a God File -- 74 lines, pure graph-wiring, zero business logic.
- **`resolver.py`** (`agent/capability/resolver.py`, 94 lines, not in top
  15): confirmed clean, see G.6.
- **`oee.py`** (`agent/planning/policies/oee.py`, 382 lines, 1 class):
  large for a single class, but **appropriately so** -- it is the
  intentional concentration point for ALL OEE domain intelligence (per
  its own docstring: "All OEE-specific intelligence... lives here"). This
  is the correct place for this size/complexity to live; the concern
  would be if this logic were scattered across multiple files instead.
  Not a coupling problem, a legitimate "one file per domain policy" size.

**Verdict**: no file in this codebase is a God Object in the classic
sense (a class doing too many unrelated things). `bootstrap.py` is a
**God Module in the "knows about everything" sense**, which is expected
and acceptable for a composition root -- but its internal `if`-chain
shape (rather than plugin-registry iteration) is the concrete thing
worth fixing before a second domain is added, not its size.

---

## K. Proposed Modular Target -- assessment only, no refactor performed

**Do you actually need a `ModulePackage`/`DomainPlugin` layer right now?**

**Partial yes, scoped narrowly.** The evidence above (sections D, G, H)
shows the codebase is NOT broadly under-modularized -- Tool/Skill/
DataSource/Persistence/Context are all already plugin-clean, proven by
Scenarios 2-4 needing 0-2 file touches. The ONE place that would
genuinely benefit from a `ModulePackage`-style abstraction is
**`agent/bootstrap.py`'s domain-wiring `if` block** (G.5, item 4) --
because that's the only place in the whole codebase where adding a second
real domain means duplicating logic (copy-pasting the `if "OEE" in
config.enabled_modules:` block) rather than registering a new entry.

**What could be collected into a `ModulePackage`, if built:**

```python
@dataclass(frozen=True)
class ModulePackage:
    module_definition: ModuleDefinition          # currently: one literal in _default_module_catalog()
    policy_factory: Callable[[], ModulePlanningPolicy]  # currently: OEEPlanningPolicy() literal inside the `if` block
    tool_registrations: Callable[[ToolRegistry], None]  # currently: _register_oee_tools()
    skill_directory: Path                          # currently: one entry in AppConfig.skill_directories' default list
    budget: Budget                                  # currently: the Budget(...) literal inside the `if` block
    # datasource_factory: optional, since OEE doesn't use DataSource at all today (D.1) --
    # would need to be genuinely optional, not required, to avoid forcing every future
    # domain through a boundary the one real existing domain doesn't even use yet.
```

`bootstrap_runtime()` would then hold `modules: dict[str, ModulePackage]`
(injected, like `tool_registrations`/`llm_client` already are) and loop:

```python
for module_type in config.enabled_modules:
    package = modules[module_type]  # KeyError -> BootstrapConfigError, same fail-fast shape as today
    package.tool_registrations(tool_registry)
    module_runtime[module_type] = ModuleRuntimeConfig(
        policy=LLMPlanningPolicy(package.policy_factory(), planner_context_builder, llm_router, decision_audit_sink=decision_audit_sink),
        capability=ModuleCapabilityRuntime(capability_resolver=capability_resolver, skill_runner=SkillRunner(tool_registry, ToolExecutionManager())),
        budget=package.budget,
    )
```

**What should explicitly NOT be collected into this layer** (already
clean, would only add indirection):
- `ToolRegistry`/`SkillRegistry`/`CapabilityResolver`/`DataSourceRegistry`
  themselves -- these are already generic services, not per-domain state.
- `ObjectiveAction` -- this is a genuine open question (G.5's flag): a
  `ModulePackage` layer does NOT by itself solve "a new domain needs a new
  shared-enum member." That would need a separate decision (e.g. loosen
  `ObjectiveAction` to a free string validated per-module, or accept that
  a shared enum edit is a normal, occasional cost of onboarding a
  genuinely new action *shape*, not a design flaw to eliminate).
- `PayloadRegistry` registration -- import-time side-effect registration
  (G.7's caveat) works today and isn't obviously improved by wrapping it
  in `ModulePackage`; if anything, an explicit
  `ModulePackage.payload_registrations: Callable[[], None]` called at
  bootstrap (rather than relying on import order) would be a **separate,
  smaller** improvement worth considering independently.

**Recommendation**: this is a **minimal, scoped refactor** (touches only
`bootstrap.py` + moving OEE's existing wiring into one new
`agent/modules/oee/package.py`-style file that just re-exports what
already exists in `domain/oee/`, `planning/policies/oee.py`,
`tools/oee/`, `skills/oee/`) -- not the deep `modules/oee/{models,policy,
datasource,tools,skills}/` restructuring your prompt sketched, which
would additionally **move** already-well-isolated files and is not
justified by the evidence here (those files are already isolated exactly
where they are; moving them changes import paths across ~15 files for no
coupling benefit). The problem is narrowly "one `if` block doesn't scale
past one domain," not "files are scattered" -- the fix should be narrowly
scoped to match.

**Per your explicit instruction, no refactor was performed -- this section
is assessment only.**
