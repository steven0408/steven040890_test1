# Architecture & Onboarding Guide (Phase 5D)

This document answers the question Phase 5D exists to answer: **how do I
add capability to this agent without touching LangGraph node code or the
Harness control flow?**

## 1. The four layers

```
Knowledge          -- what the agent knows (facts, thresholds, SOPs).
                       Phase 5D: retrieved via KnowledgeRetriever
                       (agent/llm/context/knowledge_retriever.py),
                       VALIDATED-only, no embeddings yet.

Reasoning Skill     -- how the agent thinks/judges (a perspective, a
                       framework). Pure guidance text (a markdown body).
                       No Tool. Never executed. Retrieved by
                       ReasoningSkillRetriever, consumed as context by
                       an LLM-backed node.

Execution Skill      -- how the agent completes a procedure (Equipment
                       Screening, Contribution Analysis, ...). May chain
                       one or more Tool calls (`steps`). Resolved by
                       CapabilityResolver from an Objective's `action`,
                       run by SkillRunner.

Tool                 -- what actually does something (query data,
                       calculate, call a remote API). A Python class
                       implementing the `Tool` Protocol
                       (agent/tools/models.py).
```

Dependency direction (top depends on nothing below it it doesn't need):

```
Analyzer / Planner / Synthesis (LLM-backed nodes)
        |
        |  reads (as context, never invokes)
        v
Knowledge  +  Reasoning Skill  (retrieval only -- KnowledgeRetriever / ReasoningSkillRetriever)

Executor
        |
        |  resolves + invokes
        v
Execution Skill  ->  Tool  ->  (optionally) DataSource
```

Knowledge and Reasoning Skills flow *into* a decision as context.
Execution Skills and Tools are *invoked* to produce evidence. These are
different code paths (retrieval vs. execution) on purpose -- a Reasoning
Skill can never accidentally become executable, and an Execution Skill can
never accidentally leak into "guidance" a node treats as advisory rather
than a capability contract.

## 2. Node <-> Skill consumption matrix

| Node              | Reasoning Skill                    | Execution Skill                              |
|-------------------|-------------------------------------|-----------------------------------------------|
| Standardizer      | no                                   | no                                             |
| Analyzer          | yes (`SkillConsumerNode.ANALYZER`)  | no                                             |
| Planner           | yes (`SkillConsumerNode.PLANNER`)   | capability *summaries* only (SkillSummary via CapabilityRetriever) -- never selects a skill_id/tool_id directly |
| Execution Gate    | no                                   | no                                             |
| Executor          | no                                   | yes, only through `CapabilityResolver` (never picks a Skill by free text) |
| Reflector         | optional, future use (`SkillConsumerNode.REFLECTOR` exists, unused this phase) | no |
| Completion Check  | no                                   | no                                             |
| Synthesis         | yes (`SkillConsumerNode.SYNTHESIS`, contract-only -- Synthesis itself doesn't exist yet) | no |
| Evaluator         | future (rubric skills)              | no                                             |

This table is enforced, not just documented: `SkillDefinition.applicable_nodes`
is a closed `SkillConsumerNode` enum (an unknown node name is a
pydantic `ValidationError` at load time), and `ReasoningSkillRetriever`
filters on it directly (`agent/llm/context/reasoning_skill_retriever.py`).

**The Planner boundary is unchanged and Phase 5D does not weaken it**:
Planner chooses `Objective.action` + `target_ref`; `Executor` (via
`CapabilityResolver`) resolves *which* Skill/Tool actually runs. Reasoning
Skills give Planner *judgment* context (e.g. "weigh throughput impact
first") -- they never let it name a `skill_id`/`tool_id` (`PlannerDecision`'s
schema still structurally forbids those fields regardless).

## 3. How to add a Tool

1. Implement the `Tool` Protocol (`agent/tools/models.py`): a class with a
   `definition: ToolDefinition` and `run(request: ToolExecutionRequest) ->
   ToolExecutionResult`.
2. Register its input/output shapes with `PayloadRegistry.register(...)`.
3. Register the instance with a `ToolRegistry` -- in production, add one
   line to your own `tool_registrations` callback passed into
   `bootstrap_runtime` (`agent/bootstrap.py`); see
   `_register_oee_tools` there for the reference shape.

**Files touched**: one new Tool class + payload models. **Never touched**:
Executor, SkillRunner, CapabilityResolver, any LangGraph node,
`build_phase2_graph`. Proven by `tests/test_execution_skill_plugin_onboarding.py`.

## 4. How to add an Execution Skill

1. Write a markdown file with YAML frontmatter (see
   `agent/skills/oee/rca_equipment_detail.md` for a real example, or
   `tests/fixtures/dummy_skills/echo.md` for a minimal proof fixture):
   `skill_id`, `name`, `description`, `category`, `domains`, `task_types`,
   `actions` (which `ObjectiveAction`s this Skill satisfies),
   `required_tools`/`optional_tools`, `steps` (each a `tool_id` +
   `parameter_mapping`), `input_contract`/`output_contract`.
2. Drop it into a directory `SkillRegistry.load_directory(...)` reads
   (production: one of `AppConfig.skill_directories`).
3. Reference only Tools that are already registered --
   `SkillRegistry.validate_required_tools()` fails fast at bootstrap if not.

`skill_type` defaults to `execution`, so every pre-5D Skill file needs no
changes. **Never touched**: Executor, SkillRunner, CapabilityResolver,
Module Planner, LangGraph topology.

## 5. How to add a Reasoning Skill

1. Write a markdown file with `skill_type: reasoning`,
   `applicable_nodes: [analyzer, planner, ...]` (from the closed
   `SkillConsumerNode` set), optionally `domains`/`task_types`/`roles` to
   narrow when it's relevant. **No `required_tools`/`steps`/`actions`** --
   `SkillDefinition`'s own validator rejects a Reasoning Skill that
   declares any of those (a load-time `ValidationError`, not a silent
   no-op).
2. Drop it into a skill directory (production: also one of
   `AppConfig.skill_directories` -- `agent/skills/reasoning/` by default).
3. That's it -- no Tool, no code change. Proven end-to-end by
   `tests/test_external_reasoning_skill_onboarding.py` using
   `agent/skills/reasoning/plant_manager_perspective.md`, a real fixture
   file authored exactly the way an external contributor would.

**Phase WB-3E added 7 more domain-scoped Reasoning Skills** (`domains:
[wb]`, `agent/skills/reasoning/wb_manufacturing_flow_reasoning.md` and 6
siblings) -- mental models and decision heuristics for the WB Planner
(process-flow reasoning, historical recurrence, cross-source evidence,
causal-inference guardrails, data-quality awareness, alternative-
hypothesis consideration, stopping criteria), never fixed workflows (no
"Step 1 query X, Step 2 query Y" -- see each file's own "Guidance"
section). `PlannerContextBudget`'s `max_reasoning_skills`/
`max_context_characters` defaults for ANALYSIS/RCA were tuned upward
(`agent/llm/context/planner_context.py::_DEFAULT_BUDGETS`) to actually
make room for this richer per-domain content -- verified empirically,
not guessed (see `tests/test_wb_reasoning_skills_context.py`).

## 6. How to add a Domain/Module

Only when the system needs a genuinely new, independent analysis
responsibility: its own `ModuleState` lifecycle, planning semantics
(`ModulePlanningPolicy`), and completion semantics. Since Phase 8B-1, this
means building one `ModulePackage` (`agent/modules/models.py`) and
registering it -- **`agent/bootstrap.py` itself is never edited**:

1. A `ModulePlanningPolicy` implementation (see
   `agent/planning/policies/base.py`'s Protocol) -- the domain intelligence
   for that module (what Objectives to propose, when it's sufficient, how
   to describe a finding, how to update Branches/EntityStates/Findings).
   Lives in `agent/planning/policies/<name>.py`, same as `oee.py`.
2. A capability layer for it: Tools + Execution Skills, same shape as
   OEE's (`agent/tools/<name>/`, `agent/skills/<name>/`). If the domain
   has its own data to fetch, give it its own `<Name>DataSource` Protocol
   (see `agent/domain/oee/datasource.py`) rather than injecting a raw
   list/client into a Tool's constructor directly.
3. One `agent/modules/<name>/package.py` exposing a single
   `build_<name>_module_package() -> ModulePackage` function -- this is
   the ONLY file that imports the domain's own policy/Tool/dataset
   classes. See `agent/modules/oee/package.py` for the reference shape:
   `module_definition`, `policy_factory`, `tool_registrations`,
   `skill_directories`, `budget`, `payload_registrations`.
4. Register it: either add one line to
   `agent/bootstrap.py::default_module_package_registry()`, or (for a
   caller that doesn't want the built-in default) construct your own
   `ModulePackageRegistry` and pass it to
   `bootstrap_runtime(..., module_packages=your_registry)`.

**`bootstrap_runtime()` itself never imports or references a concrete
domain policy/Tool/dataset class** -- it only knows the generic
`ModulePackage` contract and loops over whichever packages
`config.enabled_modules` selects. `tests/test_modules_onboarding.py`'s
`DummyYield` fixture proves this end-to-end: a brand-new domain, wired in
and runnable through the real parent graph, with zero changes to any file
under `agent/` (LangGraph nodes, `AgentState`/`ModuleState`, persistence
schema, `CapabilityResolver`, `SkillRegistry`, `ToolRegistry`, or
`bootstrap.py`'s own body all untouched).

**Architecture invariant (frozen since Phase 5D, unchanged by Phase
8B-1's ModulePackage refactor): adding a Skill does NOT imply adding a
Domain or a Tool.** A Reasoning Skill needs only metadata + guidance text
to exist. An Execution Skill usually needs a Tool (to have something to
chain), but never needs a new Domain/Module. A new Domain/Module is a
much bigger commitment -- new lifecycle/planning/completion semantics --
and should never be reached for just because a new Skill was added.

## 7. How to connect a real DB later

Boundary: `agent/datasource/models.py`'s `DataSource` Protocol
(`query(request: DataSourceQuery) -> DataSourceQueryResult`) +
`DataSourceConfig` (type + env-var *names* only, never a literal
host/connection-string/password). `InMemoryDataSource` is the only working
adapter today (`build_datasource(config, in_memory_factory=...)`); every
`remote_sql`/`rest_api`/`internal_service`/`rpc` config validates its env
vars and then deliberately stops at `DataSourceNotConnectedError`.

To connect a real DB: implement a new class satisfying the `DataSource`
Protocol (e.g. `RemoteSqlDataSource`, wrapping a real driver, reading its
endpoint/credential from the env vars `DataSourceConfig` already names),
and give `build_datasource` a branch for that `DataSourceType` that
constructs it instead of raising. No Tool that already depends on
`DataSource` needs to change -- it was written against the Protocol, not a
connection string, from day one. Example conceptual config:

```yaml
datasources:
  manufacturing_db:
    type: remote_sql
    endpoint_env: MANUFACTURING_DB_ENDPOINT
    credential_env: MANUFACTURING_DB_TOKEN
```

## 8. LLM providers -- Anthropic, OpenAI Cloud, internal OpenAI-compatible

Boundary: `agent/llm/client.py`'s `LLMClient` Protocol
(`complete(request: LLMRequest, output_model) -> LLMCompletion`).
`LLMRouter` never imports a provider SDK directly, only ever holds
whatever `LLMClient` it was constructed with (`bootstrap_runtime(...,
llm_client=...)`) -- Analyzer/Planner/Synthesis all share this ONE
client/router per `RuntimeContext`, so a provider swap is visible
everywhere at once, never per-node.

**Phase WB-3E landed real providers on this exact boundary, unchanged
from the Phase 5D-9 design above** -- confirming the boundary really was
sufficient without a redesign:

- `AnthropicAdapter` (`agent/llm/providers/anthropic_adapter.py`) --
  raw `anthropic` SDK, forced tool-use for structured output.
- `OpenAICompatibleAdapter` (`agent/llm/providers/openai_adapter.py`) --
  raw `openai` SDK (never `langchain-openai`; see the Phase WB-3E report
  for the rationale), Chat Completions only (never the Responses API, for
  broad compatibility across an arbitrary internal deployment). ONE class
  serves BOTH OpenAI Cloud (`base_url=None`, SDK default) and an internal
  OpenAI-compatible endpoint (`base_url=<internal /v1/ URL>`) -- they
  differ only in constructor config, never in code path. Two-tier
  structured-output strategy: forced tool-calling (mirrors
  `AnthropicAdapter`'s own mechanism) by default, with a plain
  prompt-instructed JSON-mode fallback (`use_tool_calling=False`) for a
  deployment that doesn't support tool calling.
- `MockLLMClient` (`agent/llm/client.py`) -- deterministic test double,
  reachable in a real run only via the explicit `LLM_PROVIDER=mock`
  profile below, never a silent default.

**Provider selection** lives in `agent/llm/providers/provider_config.py`
(`LLMProviderConfig.from_env()` + `build_llm_client()`), a layer IN FRONT
OF `bootstrap_runtime` -- `AppConfig`/`bootstrap_runtime` themselves are
unmodified; a caller builds a client from env vars, then passes it in:

```python
provider_config = LLMProviderConfig.from_env()      # reads LLM_PROVIDER
llm_client = build_llm_client(provider_config)       # never logs/persists the resolved secret
llm_routes = provider_config.build_routes(["analyzer", "planner"])
runtime = bootstrap_runtime(AppConfig(..., llm_routes=llm_routes), llm_client=llm_client)
```

Two runtime profiles, `LLM_PROVIDER` env var:

```
LLM_PROVIDER=openai
  OPENAI_MODEL=<model>            OPENAI_API_KEY=<secret>

LLM_PROVIDER=internal_openai
  INTERNAL_LLM_MODEL=/model/gpt-oss-120b
  INTERNAL_LLM_BASE_URL=http://<host>:<port>/v1/
  INTERNAL_LLM_API_KEY=EMPTY      (or a real credential, still env-only)
  INTERNAL_LLM_USE_TOOL_CALLING=false   # opt-out if the deployment doesn't support it
```

Every field on `LLMProviderConfig` is either a plain value (model,
temperature, max_tokens) or the NAME of an env var holding a secret
(`api_key_env`/`base_url_env`) -- mirroring `DataSourceConfig`'s own
established convention exactly. The config object itself never carries a
literal secret value, so it's safe to log/serialize/pass around.

A genuinely new third provider follows the exact same 3 steps the old
section 8 described (implement `complete()`, map exceptions to the 3
generic typed errors, take endpoint/credential config in the
constructor) -- `LLMRouter`/`LLMRouteConfig`/every LLM-backed node stay
untouched.

## 9. Composition root

`agent/bootstrap.py`'s `bootstrap_runtime(config: AppConfig, *,
module_packages=..., llm_client=..., in_memory_datasource_factory=...)`
is the one place production wiring happens (Phase 8B-1: `module_packages`
replaced the old per-domain `tool_registrations` callback + hardcoded
catalog):

```
AppConfig (YAML/JSON-shaped, no secrets -- only env-var names)
  +  ModulePackageRegistry (defaults to default_module_package_registry(), currently just OEE)
   v
bootstrap_runtime(config, module_packages, llm_client)
   +- ModuleRegistry           (one ModuleDefinition per enabled ModulePackage)
   +- SkillRegistry            (config.skill_directories + each enabled package's own skill_directories)
   +- ToolRegistry             (each enabled package's tool_registrations)
   +- ReasoningSkillRetriever  (reads SkillRegistry)
   +- CapabilityResolver       (reads SkillRegistry + ToolRegistry)
   +- DataSourceRegistry       (config.datasources -> build_datasource)
   +- LLMRouter                (config.llm_routes + the injected LLMClient)
   +- Audit sinks              (backend chosen by config.persistence)
   +- module_runtime           (dict[str, ModuleRuntimeConfig], one per enabled package)
           v
      build_production_graph(module_runtime, checkpointer, analyzer=...)   <- agent/graph/production.py,
                                                                                 required `analyzer`, never analyzer_mock
```

Future changes to *what capability exists* should mostly touch: config,
one `ModulePackage` registration, Skill markdown files, and (for a real
DataSource/LLM adapter) a new adapter class. `build_phase2_graph`/
`build_phase6_graph` and every LangGraph node are untouched by ordinary
onboarding -- see section 6.

**Production entrypoint boundary (Phase 8B-1 Part H)**: `build_phase2_graph`/
`build_phase6_graph` both default their `analyzer` parameter to
`analyzer_mock` (a Phase 2 legacy fixture -- hardcoded OEE/Output/WIP
selection, ignores TaskType) so the many Harness-mechanics regression
tests written against that default keep working. A real deployment's own
entrypoint must call `agent/graph/production.py`'s
`build_production_graph()`/`build_production_graph_with_synthesis()`
instead -- both require `analyzer` explicitly (no default), so it is not
possible to silently end up running `analyzer_mock` in production.
`agent/bootstrap.py` itself never imports `analyzer_mock`
(AST-regression-guarded, `tests/test_analyzer_mock_production_boundary.py`).

## 10. Startup validation (fail-fast)

`bootstrap_runtime` raises a typed exception immediately, never mid-run,
for:

| Problem | Exception |
|---|---|
| Duplicate `tool_id` | `DuplicateToolError` |
| Duplicate `skill_id` | `DuplicateSkillError` |
| Duplicate `module_type` | `DuplicateModuleDefinitionError` |
| EXECUTION skill's required tool not registered | `MissingToolForSkillError` |
| Malformed Skill markdown (bad frontmatter/YAML) | `SkillMarkdownError` |
| Invalid `action`/`skill_type`/`applicable_nodes` value | pydantic `ValidationError` |
| REASONING skill declaring an executable-steps contract | pydantic `ValidationError` (`SkillDefinition`'s own validator) |
| `enabled_modules` names an unknown module_type | `BootstrapConfigError` |
| DataSource missing required env var | `DataSourceConfigError` |
| Duplicate DataSource name | `DuplicateDataSourceError` |

No new aggregating exception type was introduced -- each layer's own
existing typed error propagates as-is; the first problem stops bootstrap.
See `tests/test_bootstrap.py` for one test per row above.

## 11. Runtime invariant: never call `app.update_state()` on a pending Send/interrupt superstep

**Production code must never call `app.update_state()` while any task from
the current superstep is still pending (i.e. while a Send-dispatched
Module Subgraph is paused on `interrupt()`).** This is a hard rule, not a
style preference -- treat it the same way as the Planner/Executor boundary
in section 2: a forbidden pattern, not a general-purpose API available to
any future caller.

**Why**: Phase 5B-1.1 empirically pinned down the mechanism, and Phase
8A-1 independently re-confirmed it while wiring lifecycle timestamps
(`tests/test_resume_replay_semantics.py`, `tests/test_phase8a1_lifecycle.py`):
calling `update_state()` on a checkpoint with a still-pending Send task
causes LangGraph to re-list *every* task from that pending superstep under
the `update_state()` call's own task id on the next resume -- not just the
interrupted branch. Every sibling Send branch (already-completed modules
included) is re-executed from scratch: `build_initial_module_state()` runs
again, Tools physically re-run (new `ToolCallRecord` timestamps on
otherwise-identical output), and Module lifecycle timestamps
(`started_at`/`completed_at`, Phase 8A-1) re-stamp with new wall-clock
values. A second `update_state()` call adds no further effect beyond the
first.

Without an intervening `update_state()` call, none of this happens:
siblings are never re-executed, and the interrupted branch itself resumes
from its own checkpoint rather than restarting -- LangGraph's own resume
machinery continues from the checkpointed values, ignoring whatever fresh
state a node's wrapper function reassigns before calling
`child_app.invoke()` (see `module_subgraph_node.py`'s docstring).

**How production avoids it structurally**: `RunController`
(`agent/persistence/run_controller.py`) is the only Harness-level bridge
between a LangGraph interrupt and `HumanAuditSink` -- it records a pending
`HumanRequest` and a Human's `HumanResponse` entirely in
`HumanAuditSink`, and resumes the graph exclusively via
`Command(resume=...)`. It never calls `update_state()`. This isn't a
workaround applied after the fact; the audit sink exists specifically so
`update_state()` is never *needed* for the Human flow.

**Regression guard**: `tests/test_runtime_invariants.py` AST-scans every
file under `agent/` (the only place this pattern could leak into
production) for an actual `.update_state(` call and fails if one appears
outside the small, explicitly-named set of test-only helper modules (none
currently exist) -- mirroring the same AST-over-substring-grep discipline
`agent/learning/`'s promotion-boundary tests already use, so a docstring
merely *mentioning* `update_state()` (as this section and several modules'
own docstrings do) can never trip it.
