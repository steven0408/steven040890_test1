"""Phase PROD-1: typed Agent errors mapped to safe API responses. Never
`detail=str(e)` for an arbitrary exception (item 28) -- an unexpected
internal failure is logged in full (stdout only) and returned to the
client as a bounded, generic message plus an `error_type` the client can
branch on programmatically.
"""
from enum import Enum

from pydantic import BaseModel


class ApiErrorType(str, Enum):
    INVALID_REQUEST = "invalid_request"       # 400 -- malformed input shape (not a schema violation)
    VALIDATION_ERROR = "validation_error"      # 422 -- pydantic schema violation
    PROVIDER_UNAVAILABLE = "provider_unavailable"  # 503 -- required LLM/config not reachable/configured
    INTERNAL_ERROR = "internal_error"          # 500 -- unexpected failure, detail withheld from client
    NOT_FOUND = "not_found"                    # 404 -- run_id / resource does not exist


_STATUS_BY_TYPE: dict[ApiErrorType, int] = {
    ApiErrorType.INVALID_REQUEST: 400,
    ApiErrorType.VALIDATION_ERROR: 422,
    ApiErrorType.PROVIDER_UNAVAILABLE: 503,
    ApiErrorType.INTERNAL_ERROR: 500,
    ApiErrorType.NOT_FOUND: 404,
}


class AgentApiError(Exception):
    """Base typed error every route handler catches and maps -- carries a
    SAFE client-facing message plus an internal detail that only ever goes
    to stdout logging, never the HTTP response body."""

    def __init__(self, error_type: ApiErrorType, message: str, *, internal_detail: str | None = None, run_id: str | None = None):
        super().__init__(message)
        self.error_type = error_type
        self.message = message
        self.internal_detail = internal_detail
        self.run_id = run_id

    @property
    def http_status(self) -> int:
        return _STATUS_BY_TYPE[self.error_type]


class InvalidRequestError(AgentApiError):
    def __init__(self, message: str, *, run_id: str | None = None):
        super().__init__(ApiErrorType.INVALID_REQUEST, message, run_id=run_id)


class ProviderUnavailableError(AgentApiError):
    def __init__(self, message: str, *, internal_detail: str | None = None, run_id: str | None = None):
        super().__init__(ApiErrorType.PROVIDER_UNAVAILABLE, message, internal_detail=internal_detail, run_id=run_id)


class RunNotFoundError(AgentApiError):
    def __init__(self, run_id: str):
        super().__init__(ApiErrorType.NOT_FOUND, f"No data found for run_id '{run_id}'", run_id=run_id)


class AgentExecutionError(AgentApiError):
    """Wraps an unexpected failure raised while invoking the production
    graph -- the client sees a bounded generic message; `internal_detail`
    (the real exception text/traceback-adjacent info) is stdout-logged
    only, never returned (item 29: no traceback to client)."""

    def __init__(self, message: str = "Analysis failed unexpectedly.", *, internal_detail: str | None = None, run_id: str | None = None):
        super().__init__(ApiErrorType.INTERNAL_ERROR, message, internal_detail=internal_detail, run_id=run_id)


class ErrorResponse(BaseModel):
    run_id: str | None = None
    status: str = "error"
    error_type: ApiErrorType
    message: str
