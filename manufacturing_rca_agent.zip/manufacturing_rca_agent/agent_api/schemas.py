"""Phase PROD-1: API request/response DTOs. `AgentAnalyzeRequest` is an
external DTO that `agent_api/service.py` converts into the existing
`UserRequest`/`FactoryContext` domain models -- it does not duplicate or
replace them, and it carries no field FastAPI itself interprets (no
TaskType/module/capability guessing here -- see agent_api/service.py's own
docstring for why that stays Standardizer/Analyzer/Planner's job).
"""
from typing import Any

from pydantic import BaseModel, Field, model_validator


class AgentAnalyzeRequest(BaseModel):
    """Exactly one of `prompt` / `request` must be provided (Mode A / Mode
    B, item 4-5). `request`, when given, is kept conservative this phase
    (item 7) -- a plain dict normalized the same way a prompt would be
    (only `raw_text`/`plant_id`-shaped keys are read), never a bypass of
    Standardizer's own extraction/validation."""

    prompt: str | None = Field(default=None, description="Free-text request, e.g. '請分析 2026-08-12 ASE07 Output 下降原因'.")
    request: dict[str, Any] | None = Field(
        default=None,
        description="Structured input (conservative this phase): {'raw_text': str, 'plant_id'?: str}. Still normalized/validated through the existing Standardizer, never a bypass.",
    )
    run_id: str | None = Field(default=None, description="Optional caller-supplied run id; generated (UUID4) when absent.")
    factory_id: str | None = Field(default=None, description="Optional factory override; defaults to the deployment's configured factory_id.")
    metadata: dict[str, str] | None = Field(default=None, description="Optional caller-supplied tags (e.g. session_id/user_id) -- carried into runtime events' own metadata, never interpreted by FastAPI or any cognitive node.")

    @model_validator(mode="after")
    def _exactly_one_input_mode(self) -> "AgentAnalyzeRequest":
        has_prompt = self.prompt is not None and self.prompt.strip() != ""
        has_request = self.request is not None
        if has_prompt == has_request:
            raise ValueError("exactly one of 'prompt' or 'request' must be provided (not both, not neither)")
        if has_request and "raw_text" not in self.request:
            raise ValueError("'request' must include a 'raw_text' key (structured input is conservative this phase -- see agent_api/schemas.py)")
        return self


class AgentAnalyzeResponse(BaseModel):
    """`?format=json` response body (item 9) -- never the full AgentState
    (item 26/77). `module_statuses` maps module_id -> ModuleStatus value."""

    run_id: str
    status: str
    markdown: str
    module_statuses: dict[str, str] = Field(default_factory=dict)


class HealthResponse(BaseModel):
    status: str
    service: str
    version: str
    llm_profile: str
    runtime_db_logging: bool
    wb_remote_datasource_configured: bool


class ReadyResponse(BaseModel):
    ready: bool
    reasons: list[str] = Field(default_factory=list)


class RunEventsResponse(BaseModel):
    run_id: str
    events: list[dict[str, Any]]
