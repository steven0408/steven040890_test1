"""Phase PROD-1: deployment configuration -- every field here is read from
an environment variable NAME, never a literal secret/host/credential value,
mirroring the exact discipline already established by
`agent.llm.providers.provider_config.LLMProviderConfig`,
`agent.datasource.models.DataSourceConfig`, and
`agent.persistence.postgres.config.PostgresSettings`. This module does not
invent a second config mechanism -- it composes those three existing ones
plus a handful of API-layer-only settings (CORS, request timeout, WB API
base URL, runtime debug DB URL).

`ApiSettings.from_env()` performs STRUCTURAL validation only (required env
vars are set, values parse) -- it never opens a network connection, never
calls the LLM, never contacts the WB API or either PostgreSQL database
(Phase PROD-1's own explicit "do not verify formal infrastructure" rule).
"""
import os
from dataclasses import dataclass, field

from agent.llm.providers.provider_config import LLMProviderConfig, LLMProviderConfigError
from agent.llm.token_budget import LLMContextProfile, RouteTokenBudget

_DEFAULT_FACTORY_ID = "factory-a"
_DEFAULT_FACTORY_NAME = "Factory A"
_DEFAULT_MODULES = ["WB"]

_COGNITIVE_ROUTES = ["standardizer", "analyzer", "planner", "reflector", "synthesis"]

# Phase PROD-1.1 (item 3): the development/OpenAI-era default -- large
# enough that context budgeting is effectively a no-op unless an operator
# explicitly sets LLM_CONTEXT_WINDOW_TOKENS smaller (e.g. 2048 for the
# internal gpt-oss-120b deployment). No cognitive node/Context Builder
# hardcodes this number; only ApiSettings reads it, once, at startup.
_DEFAULT_CONTEXT_WINDOW_TOKENS = 128_000

# Phase PROD-1.1 (item 10/54): per-route reserved OUTPUT budgets. Every
# value here is a documented starting point, not empirically proven optimal
# against the real internal model (this phase performs no required live
# LLM testing -- item 71 explicitly makes that optional) -- generous enough
# to leave room for a reasoning model's own `reasoning_content` (item 10)
# ahead of the earlier production-observed `max_tokens=200`, which was
# already shown insufficient. `minimum_output_tokens` is roughly half of
# `max_output_tokens` -- the floor used only for the "could this route ever
# succeed at all" structural check (LLMContextProfile.minimum_viable_window).
_DEFAULT_ROUTE_OUTPUT_BUDGETS: dict[str, tuple[int, int]] = {
    "standardizer": (400, 150),
    "analyzer": (400, 150),
    "planner": (700, 250),
    "reflector": (600, 250),
    "synthesis": (700, 250),
}
_DEFAULT_SAFETY_MARGIN_TOKENS = 96


class ApiConfigError(RuntimeError):
    """A required piece of deployment configuration is missing or
    structurally invalid -- raised at startup, never mid-request."""


@dataclass(frozen=True)
class ApiSettings:
    llm_provider_config: LLMProviderConfig

    factory_id: str = _DEFAULT_FACTORY_ID
    factory_name: str = _DEFAULT_FACTORY_NAME
    enabled_modules: list[str] = field(default_factory=lambda: list(_DEFAULT_MODULES))

    # WB production DataSource profile: "in_memory" (default -- the frozen
    # synthetic dataset every offline test already uses) or "remote" (the
    # 5 RemoteWB*DataSource classes, agent/domain/wb/remote.py). Switching
    # requires only this env var + WB_API_BASE_URL -- no Tool/Skill/Policy
    # code changes (see agent/domain/wb/remote.py::build_remote_wb_datasources).
    wb_datasource_profile: str = "in_memory"
    wb_api_base_url_env: str = "WB_API_BASE_URL"

    # Optional runtime/debug event PostgreSQL -- deliberately a single DSN
    # env var (not the PostgresSettings host/port/db/user/password-as-
    # separate-env-var-name shape) because this is a distinct, optional,
    # best-effort observability database, not the Agent's own Run
    # persistence layer (agent/persistence/postgres, unchanged/reused as-is
    # for actual analysis persistence when configured separately via
    # AppConfig.persistence). Never required for the Agent to start.
    runtime_db_url_env: str = "AGENT_RUNTIME_DB_URL"

    cors_allow_origins: list[str] = field(default_factory=list)
    request_timeout_seconds: float | None = None

    # Phase PROD-1.1: context window is config-driven (item 3), never
    # hardcoded in any cognitive node. `reserved_output_tokens_override`,
    # when set, applies uniformly to every route's `max_output_tokens`
    # (item 87's own "do not expose dozens of unnecessary knobs" --
    # per-route overrides are available programmatically via
    # LLMContextProfile.route_budgets for a future deployment that needs
    # them, but this phase exposes only ONE env knob for the common case).
    context_window_tokens: int = _DEFAULT_CONTEXT_WINDOW_TOKENS
    reserved_output_tokens_override: int | None = None

    @classmethod
    def from_env(cls) -> "ApiSettings":
        try:
            llm_provider_config = LLMProviderConfig.from_env()
        except LLMProviderConfigError as exc:
            raise ApiConfigError(f"LLM configuration is invalid or incomplete: {exc}") from exc

        context_window_raw = os.environ.get("LLM_CONTEXT_WINDOW_TOKENS")
        try:
            context_window_tokens = int(context_window_raw) if context_window_raw else _DEFAULT_CONTEXT_WINDOW_TOKENS
        except ValueError:
            raise ApiConfigError(f"LLM_CONTEXT_WINDOW_TOKENS={context_window_raw!r} must be an integer")
        if context_window_tokens <= 0:
            raise ApiConfigError(f"LLM_CONTEXT_WINDOW_TOKENS={context_window_tokens} must be positive")

        reserved_output_raw = os.environ.get("LLM_RESERVED_OUTPUT_TOKENS")
        try:
            reserved_output_tokens_override = int(reserved_output_raw) if reserved_output_raw else None
        except ValueError:
            raise ApiConfigError(f"LLM_RESERVED_OUTPUT_TOKENS={reserved_output_raw!r} must be an integer")

        wb_datasource_profile = os.environ.get("WB_DATASOURCE_PROFILE", "in_memory").strip().lower()
        if wb_datasource_profile not in ("in_memory", "remote"):
            raise ApiConfigError(f"WB_DATASOURCE_PROFILE={wb_datasource_profile!r} must be 'in_memory' or 'remote'")
        if wb_datasource_profile == "remote" and not os.environ.get("WB_API_BASE_URL"):
            raise ApiConfigError("WB_DATASOURCE_PROFILE=remote requires WB_API_BASE_URL to be set")

        factory_id = os.environ.get("AGENT_FACTORY_ID", _DEFAULT_FACTORY_ID)
        factory_name = os.environ.get("AGENT_FACTORY_NAME", _DEFAULT_FACTORY_NAME)
        enabled_modules = _split_csv(os.environ.get("AGENT_ENABLED_MODULES"), default=_DEFAULT_MODULES)
        cors_origins = _split_csv(os.environ.get("AGENT_CORS_ALLOW_ORIGINS"), default=[])

        timeout_raw = os.environ.get("AGENT_REQUEST_TIMEOUT_SECONDS")
        request_timeout_seconds = float(timeout_raw) if timeout_raw else None

        return cls(
            llm_provider_config=llm_provider_config,
            factory_id=factory_id,
            factory_name=factory_name,
            enabled_modules=enabled_modules,
            wb_datasource_profile=wb_datasource_profile,
            request_timeout_seconds=request_timeout_seconds,
            cors_allow_origins=cors_origins,
            context_window_tokens=context_window_tokens,
            reserved_output_tokens_override=reserved_output_tokens_override,
        )

    def llm_routes(self) -> dict:
        """Every cognitive node's route, all served by the one configured
        LLM client -- see LLMProviderConfig.build_routes's own docstring
        for why (one LLMClient/model per RuntimeContext today)."""
        return self.llm_provider_config.build_routes(_COGNITIVE_ROUTES)

    def context_profile(self) -> LLMContextProfile:
        """Phase PROD-1.1: the ONE place a real deployment's
        `LLM_CONTEXT_WINDOW_TOKENS` becomes an `LLMContextProfile` --
        injected into `LLMRouter` (agent_api/service.py), never read
        directly by any cognitive node. Route output budgets come from
        `_DEFAULT_ROUTE_OUTPUT_BUDGETS` unless `LLM_RESERVED_OUTPUT_TOKENS`
        overrides all of them uniformly."""
        route_budgets = {}
        for route, (default_max, default_min) in _DEFAULT_ROUTE_OUTPUT_BUDGETS.items():
            max_output = self.reserved_output_tokens_override or default_max
            min_output = min(default_min, max_output)
            route_budgets[route] = RouteTokenBudget(max_output_tokens=max_output, minimum_output_tokens=min_output, safety_margin_tokens=_DEFAULT_SAFETY_MARGIN_TOKENS)
        return LLMContextProfile(context_window_tokens=self.context_window_tokens, route_budgets=route_budgets)

    def runtime_db_url(self) -> str | None:
        """Resolves the runtime-event debug DB's DSN from the env var this
        settings object *names* (`runtime_db_url_env`) -- never stores the
        value itself. Returns None (not an error) when unset -- runtime
        event persistence is optional, see agent_api/runtime_events.py."""
        return os.environ.get(self.runtime_db_url_env)

    def is_mock_llm(self) -> bool:
        return self.llm_provider_config.provider == "mock"


def _split_csv(raw: str | None, *, default: list[str]) -> list[str]:
    if not raw:
        return list(default)
    return [item.strip() for item in raw.split(",") if item.strip()]
