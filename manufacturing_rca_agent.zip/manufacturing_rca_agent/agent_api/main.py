"""Phase PROD-1: FastAPI application -- ROUTES ONLY (request validation,
run_id, Agent invocation via AgentService, runtime event forwarding, error
mapping, response formatting). No WB/OEE business semantics anywhere in
this file -- see agent_api/service.py for the one seam that talks to the
Harness.

Run with: uvicorn agent_api.main:app --host 0.0.0.0 --port 80
"""
import concurrent.futures
import logging
import os
import sys
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response, StreamingResponse

from agent_api.config import ApiConfigError, ApiSettings
from agent_api.dependencies import get_agent_service, get_event_sink, get_settings
from agent_api.errors import AgentApiError, ApiErrorType, ErrorResponse, InvalidRequestError
from agent_api.runtime_events import build_runtime_event_sink, event_to_sse
from agent_api.schemas import AgentAnalyzeRequest, AgentAnalyzeResponse, HealthResponse, ReadyResponse, RunEventsResponse
from agent_api.service import AgentService, normalize_request

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
_logger = logging.getLogger("agent_api")

_SERVICE_NAME = "manufacturing-rca-agent-api"
_SERVICE_VERSION = "0.1.0"
_executor = concurrent.futures.ThreadPoolExecutor(max_workers=8, thread_name_prefix="agent-analyze")


@asynccontextmanager
async def lifespan(app: FastAPI):
    _logger.info("%s starting up...", _SERVICE_NAME)
    try:
        settings = ApiSettings.from_env()
    except ApiConfigError as exc:
        _logger.error("startup configuration is invalid: %s", exc)
        raise

    _logger.info(
        "configuration: llm_provider=%s wb_datasource_profile=%s enabled_modules=%s factory_id=%s",
        settings.llm_provider_config.provider, settings.wb_datasource_profile, settings.enabled_modules, settings.factory_id,
    )
    if settings.is_mock_llm():
        _logger.warning("LLM_PROVIDER=mock is configured -- this process is NOT using a production LLM. Never set this in a real deployment.")

    event_sink = build_runtime_event_sink(settings.runtime_db_url())
    _logger.info("runtime event sink: %s", type(event_sink).__name__)

    agent_service = AgentService.from_settings(settings, event_sink)
    _logger.info("module packages loaded: %s", list(agent_service.runtime_context.module_runtime.keys()))
    _logger.info("%s startup complete.", _SERVICE_NAME)

    app.state.settings = settings
    app.state.event_sink = event_sink
    app.state.agent_service = agent_service
    yield
    _logger.info("%s shutting down.", _SERVICE_NAME)


app = FastAPI(
    title="Manufacturing RCA Agent API",
    description="Transport layer over the existing Manufacturing RCA Agent Harness. Carries no WB/OEE business semantics of its own.",
    version=_SERVICE_VERSION,
    lifespan=lifespan,
)

# Item 49: CORS is opt-in, off by default. Starlette only allows
# `add_middleware()` before the app has started serving (it raises
# `RuntimeError: Cannot add middleware after an application has started`
# once a request/lifespan has run) -- so this must happen here, at import
# time right after `app` construction, not inside `lifespan()`. Reading
# one env var directly (not the full `ApiSettings.from_env()`, which
# requires LLM_PROVIDER and would turn a harmless CORS check into a hard
# import-time failure) is a narrow, deliberate exception to "no import-
# time side effects" (item 53) -- it is pure config reading, no network
# call, no client construction.
_cors_origins = [o.strip() for o in os.environ.get("AGENT_CORS_ALLOW_ORIGINS", "").split(",") if o.strip()]
if _cors_origins:
    app.add_middleware(CORSMiddleware, allow_origins=_cors_origins, allow_methods=["*"], allow_headers=["*"])


@app.exception_handler(AgentApiError)
async def handle_agent_api_error(request: Request, exc: AgentApiError) -> JSONResponse:
    if exc.internal_detail:
        _logger.error("run=%s error_type=%s internal_detail=%s", exc.run_id, exc.error_type.value, exc.internal_detail)
    return JSONResponse(status_code=exc.http_status, content=ErrorResponse(run_id=exc.run_id, error_type=exc.error_type, message=exc.message).model_dump(mode="json"))


@app.exception_handler(Exception)
async def handle_unexpected_error(request: Request, exc: Exception) -> JSONResponse:
    # Item 28/29: never `detail=str(e)` for an arbitrary exception -- full
    # detail goes to stdout only.
    _logger.exception("unhandled exception on %s", request.url.path)
    return JSONResponse(status_code=500, content=ErrorResponse(error_type=ApiErrorType.INTERNAL_ERROR, message="Unexpected internal error.").model_dump(mode="json"))


@app.get("/health", response_model=HealthResponse)
def health_check(settings: ApiSettings = Depends(get_settings)) -> HealthResponse:
    return HealthResponse(
        status="healthy",
        service=_SERVICE_NAME,
        version=_SERVICE_VERSION,
        llm_profile=settings.llm_provider_config.provider,
        runtime_db_logging=settings.runtime_db_url() is not None,
        wb_remote_datasource_configured=settings.wb_datasource_profile == "remote",
    )


@app.get("/ready", response_model=ReadyResponse)
def readiness_check(settings: ApiSettings = Depends(get_settings)) -> ReadyResponse:
    """Structural readiness only (item 27) -- never calls the real LLM/WB
    API/Postgres. By the time this process is serving requests at all, the
    lifespan above already fail-fast-validated required config; this
    endpoint re-states that for an external load balancer/orchestrator."""
    reasons: list[str] = []
    if settings.is_mock_llm():
        reasons.append("LLM_PROVIDER=mock is configured -- not a production LLM profile.")
    return ReadyResponse(ready=not reasons, reasons=reasons)


def _run_with_optional_timeout(service: AgentService, normalized, settings: ApiSettings):
    if settings.request_timeout_seconds is None:
        return service.analyze(normalized)
    future = _executor.submit(service.analyze, normalized)
    try:
        return future.result(timeout=settings.request_timeout_seconds)
    except concurrent.futures.TimeoutError as exc:
        raise InvalidRequestError(f"Analysis exceeded AGENT_REQUEST_TIMEOUT_SECONDS={settings.request_timeout_seconds}") from exc


@app.post("/api/agent/v1/analyze", description="Runs one Agent analysis. Primary output is Markdown (Content-Type: text/markdown); pass ?format=json for a structured response.")
def analyze(
    body: AgentAnalyzeRequest,
    format: str = Query(default="markdown", pattern="^(markdown|json)$"),
    service: AgentService = Depends(get_agent_service),
    settings: ApiSettings = Depends(get_settings),
):
    normalized = normalize_request(prompt=body.prompt, request=body.request, run_id=body.run_id, factory_id=body.factory_id, metadata=body.metadata)
    result = _run_with_optional_timeout(service, normalized, settings)

    if format == "json":
        return AgentAnalyzeResponse(run_id=result.run_id, status=result.status, markdown=result.markdown, module_statuses=result.module_statuses)
    # Item 58: PARTIAL/COMPLETE analytical status with valid Markdown is
    # still a 200 -- HTTP status reflects transport/system outcome, never
    # analytical completeness.
    return Response(content=result.markdown, media_type="text/markdown; charset=utf-8")


@app.post("/api/agent/v1/analyze/stream", description="Server-Sent Events debug/progress stream for one Agent analysis. Never streams chain-of-thought.")
def analyze_stream(body: AgentAnalyzeRequest, service: AgentService = Depends(get_agent_service)):
    normalized = normalize_request(prompt=body.prompt, request=body.request, run_id=body.run_id, factory_id=body.factory_id, metadata=body.metadata)

    def _generate():
        for event in service.stream(normalized):
            yield event_to_sse(event)

    return StreamingResponse(_generate(), media_type="text/event-stream")


@app.get("/api/agent/v1/runs/{run_id}/events", response_model=RunEventsResponse, description="Bounded RuntimeEvents for one run_id, if the runtime event sink retained them.")
def run_events(run_id: str):
    sink = app.state.event_sink
    events = sink.list_for_run(run_id)
    return RunEventsResponse(run_id=run_id, events=[e.model_dump(mode="json", exclude_none=True) for e in events])


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("agent_api.main:app", host="0.0.0.0", port=80, reload=False, log_level="info")
