"""Phase PROD-1: bounded operational/debug event contract -- a
PRESENTATION PROJECTION of already-existing typed decisions (ObjectiveRecord,
ToolCallRecord, ReflectionRecord -- agent/state/models.py), never a second
source of truth for them (item 23 of the phase spec). RuntimeEvent is
deliberately much smaller than any of those: no raw prompts, no chain-of-
thought, no full evidence payload -- see `_MAX_SUMMARY_CHARS` and every
field's own docstring below for the bound.

Sink architecture (item 21):

    RuntimeEventSink (Protocol: record / list_for_run)
        StdoutRuntimeEventSink   -- always on, one JSON line per event
        InMemoryRuntimeEventSink -- test double / same-process lookup
        PostgresRuntimeEventSink -- optional, best-effort, never required
        CompositeRuntimeEventSink -- fans out to N sinks, isolates failures

No LangGraph node depends on any of this -- `RuntimeEventPublisher` is
constructed fresh per run by `agent_api/service.py::AgentService`, and
every event it publishes is DERIVED from the parent graph's own
`stream_mode="updates"` output plus each terminal `ModuleState`'s already-
existing `objective_history`/`tool_calls`/`reflection_history` fields --
never a new decision, never something a node calls into directly (item 22:
nodes must not know Postgres/SQL/FastAPI).
"""
import json
import logging
import sys
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Protocol

from pydantic import BaseModel, Field

_logger = logging.getLogger("agent_api.runtime_events")

_MAX_SUMMARY_CHARS = 500  # bounded -- never a raw Evidence/Tool payload dump


class RuntimeEventType(str, Enum):
    RUN_STARTED = "run_started"
    STANDARDIZER_COMPLETED = "standardizer_completed"
    ANALYZER_COMPLETED = "analyzer_completed"
    MODULE_STARTED = "module_started"
    PLANNER_DECISION = "planner_decision"
    EXECUTION_GATE_COMPLETED = "execution_gate_completed"
    TOOL_COMPLETED = "tool_completed"
    TOOL_FAILED = "tool_failed"
    REFLECTOR_COMPLETED = "reflector_completed"
    MODULE_COMPLETED = "module_completed"
    SYNTHESIS_COMPLETED = "synthesis_completed"
    RUN_COMPLETED = "run_completed"
    RUN_FAILED = "run_failed"


class RuntimeEvent(BaseModel):
    """Every field is either a bounded scalar or a small bounded dict
    (`scope`/`metadata`) -- never free-form prose beyond `summary`, which
    is truncated to `_MAX_SUMMARY_CHARS`. Deliberately excludes: raw LLM
    prompts, raw system prompts, chain-of-thought, credentials, full
    ModuleState/AgentState, raw manufacturing rows (item 13/19/45)."""

    event_id: str
    run_id: str
    sequence: int
    timestamp: datetime
    event_type: RuntimeEventType
    node: str | None = None
    module_id: str | None = None
    objective_id: str | None = None
    status: str | None = None
    summary: str | None = None
    capability_key: str | None = None
    tool_id: str | None = None
    scope: dict[str, Any] | None = None
    error_type: str | None = None
    error_message: str | None = None
    metadata: dict[str, str] = Field(default_factory=dict)
    schema_version: str = "1"


def _bound(text: str | None) -> str | None:
    if text is None:
        return None
    return text if len(text) <= _MAX_SUMMARY_CHARS else text[:_MAX_SUMMARY_CHARS] + "...(truncated)"


class RuntimeEventSink(Protocol):
    def record(self, event: RuntimeEvent) -> None: ...

    def list_for_run(self, run_id: str) -> list[RuntimeEvent]: ...


class StdoutRuntimeEventSink:
    """Always-on, Docker-friendly: one structured log line per event to
    stdout, matching this repo's own established
    `%(asctime)s [%(levelname)s] %(message)s` handler convention (see
    agent_api/main.py's logging.basicConfig call). Never raises -- a
    logging-handler-level failure must not fail an Agent run."""

    def __init__(self, logger: logging.Logger | None = None):
        self._logger = logger or _logger

    def record(self, event: RuntimeEvent) -> None:
        try:
            self._logger.info(
                "[run=%s] %s node=%s module=%s status=%s %s",
                event.run_id, event.event_type.value, event.node, event.module_id, event.status,
                event.summary or "",
            )
        except Exception:  # pragma: no cover -- logging must never break a run
            pass

    def list_for_run(self, run_id: str) -> list[RuntimeEvent]:
        return []  # stdout is not queryable -- by design, see runtime_db_url()'s own docstring


class InMemoryRuntimeEventSink:
    """Test double + same-process debug lookup (never the production
    durable store -- that's PostgresRuntimeEventSink, when configured)."""

    def __init__(self):
        self._events: list[RuntimeEvent] = []

    def record(self, event: RuntimeEvent) -> None:
        self._events.append(event)

    def list_for_run(self, run_id: str) -> list[RuntimeEvent]:
        return [e for e in self._events if e.run_id == run_id]


class CompositeRuntimeEventSink:
    """Fans out to every wrapped sink, isolating each one's own failure
    (item 44: one event insert failing must never fail the Agent run, nor
    prevent the OTHER sinks -- e.g. stdout -- from still receiving the
    event). `list_for_run` reads from the first sink that returns a
    non-empty list (in practice: Postgres if present, else InMemory)."""

    def __init__(self, sinks: list[RuntimeEventSink]):
        self._sinks = sinks

    def record(self, event: RuntimeEvent) -> None:
        for sink in self._sinks:
            try:
                sink.record(event)
            except Exception as exc:  # best-effort -- observability must never break analysis (item 44/45)
                _logger.warning("runtime event sink %s failed to record event: %s", type(sink).__name__, exc)

    def list_for_run(self, run_id: str) -> list[RuntimeEvent]:
        for sink in self._sinks:
            try:
                events = sink.list_for_run(run_id)
            except Exception as exc:
                _logger.warning("runtime event sink %s failed to list events: %s", type(sink).__name__, exc)
                continue
            if events:
                return events
        return []


# ============================================================================
# Optional PostgreSQL sink -- lazy psycopg import, best-effort connect at
# construction time only, disables itself (never raises into a caller) on
# any failure. Reuses the existing agent/persistence/postgres SQL/insert
# pattern (`_SimpleAppendOnlyTable`'s own insert-ignore-on-conflict shape)
# for consistency, but is its own table/migration (agent_runtime_events,
# migrations/0002_runtime_events.sql) since no existing audit table is a
# single unified bounded progress stream (item 19's own explicit finding).
# ============================================================================

_INSERT_SQL = """
INSERT INTO agent_runtime_events (
    event_id, run_id, sequence, created_at, event_type, node, module_id, objective_id,
    status, summary, capability_key, tool_id, scope, metadata, error_type, error_message, schema_version
) VALUES (
    %(event_id)s, %(run_id)s, %(sequence)s, %(created_at)s, %(event_type)s, %(node)s, %(module_id)s, %(objective_id)s,
    %(status)s, %(summary)s, %(capability_key)s, %(tool_id)s, %(scope)s, %(metadata)s, %(error_type)s, %(error_message)s, %(schema_version)s
) ON CONFLICT (event_id) DO NOTHING
"""

_SELECT_SQL = "SELECT * FROM agent_runtime_events WHERE run_id = %(run_id)s ORDER BY sequence"


def _event_to_row(event: RuntimeEvent) -> dict[str, Any]:
    return {
        "event_id": event.event_id, "run_id": event.run_id, "sequence": event.sequence,
        "created_at": event.timestamp, "event_type": event.event_type.value, "node": event.node,
        "module_id": event.module_id, "objective_id": event.objective_id, "status": event.status,
        "summary": event.summary, "capability_key": event.capability_key, "tool_id": event.tool_id,
        "scope": _jsonb(event.scope), "metadata": _jsonb(event.metadata), "error_type": event.error_type,
        "error_message": event.error_message, "schema_version": event.schema_version,
    }


def _jsonb(value: Any) -> Any:
    if value is None:
        return None
    try:
        from psycopg.types.json import Jsonb

        return Jsonb(value)
    except ImportError:
        return value


def _row_to_event(row: dict[str, Any]) -> RuntimeEvent:
    return RuntimeEvent(
        event_id=row["event_id"], run_id=row["run_id"], sequence=row["sequence"], timestamp=row["created_at"],
        event_type=RuntimeEventType(row["event_type"]), node=row["node"], module_id=row["module_id"],
        objective_id=row["objective_id"], status=row["status"], summary=row["summary"],
        capability_key=row["capability_key"], tool_id=row["tool_id"], scope=row["scope"] or None,
        metadata=row["metadata"] or {}, error_type=row["error_type"], error_message=row["error_message"],
        schema_version=row["schema_version"],
    )


class PostgresRuntimeEventSink:
    """Takes an already-open connection (never a DSN) -- mirrors every
    other Postgres*Sink in agent/persistence/postgres/repositories.py.
    Callers should use `build_optional_postgres_runtime_event_sink()`
    below rather than constructing this directly in application code."""

    def __init__(self, connection):
        self._conn = connection

    def record(self, event: RuntimeEvent) -> None:
        self._conn.execute(_INSERT_SQL, _event_to_row(event))

    def list_for_run(self, run_id: str) -> list[RuntimeEvent]:
        cursor = self._conn.execute(_SELECT_SQL, {"run_id": run_id})
        return [_row_to_event(row) for row in cursor.fetchall()]


def build_optional_postgres_runtime_event_sink(dsn: str | None) -> RuntimeEventSink | None:
    """Item 17/42/43: lazy, best-effort, one attempt at startup. Returns
    None (never raises) on ANY failure -- missing dsn, missing `psycopg`
    driver, unreachable host, missing table. The caller (agent_api/service.py)
    always has a StdoutRuntimeEventSink to fall back to, so the Agent API
    remains fully usable either way."""
    if not dsn:
        _logger.info("AGENT_RUNTIME_DB_URL not set -- runtime event Postgres sink disabled, stdout logging only")
        return None
    try:
        import psycopg
        from psycopg.rows import dict_row

        connection = psycopg.connect(dsn, autocommit=True, connect_timeout=5)
        connection.row_factory = dict_row
        # Confirms the table exists without creating it here -- migrations
        # (agent/persistence/postgres/migrations/0002_runtime_events.sql)
        # are the one source of schema truth, never created ad hoc by the
        # application at request time.
        connection.execute("SELECT 1 FROM agent_runtime_events LIMIT 1")
        _logger.info("runtime event Postgres sink connected and enabled")
        return PostgresRuntimeEventSink(connection)
    except ImportError:
        _logger.warning("psycopg is not installed -- runtime event Postgres sink disabled, stdout logging only")
        return None
    except Exception as exc:
        _logger.warning("runtime event Postgres sink unavailable (%s) -- disabled, stdout logging only", exc)
        return None


def build_runtime_event_sink(dsn: str | None) -> RuntimeEventSink:
    """The one production composition point (item 21's 'preferred:
    Composite: stdout + optional Postgres'). Stdout is always present;
    Postgres is added only if it connects successfully."""
    sinks: list[RuntimeEventSink] = [StdoutRuntimeEventSink()]
    postgres_sink = build_optional_postgres_runtime_event_sink(dsn)
    if postgres_sink is not None:
        sinks.append(postgres_sink)
    return CompositeRuntimeEventSink(sinks)


@dataclass
class RuntimeEventPublisher:
    """Run-scoped (item 24: NOT a global) -- one fresh instance per
    request/run, so concurrent runs can never share or collide on
    `sequence`. `sequence` is a simple run-local monotonic counter (item 24's
    own "stable sequence generated by a run-local event publisher" option),
    not derived from wall-clock time, so ordering is exact even under
    clock skew."""

    run_id: str
    sink: RuntimeEventSink
    _sequence: int = field(default=0, init=False)

    def publish(
        self, event_type: RuntimeEventType, *, node: str | None = None, module_id: str | None = None,
        objective_id: str | None = None, status: str | None = None, summary: str | None = None,
        capability_key: str | None = None, tool_id: str | None = None, scope: dict[str, Any] | None = None,
        error_type: str | None = None, error_message: str | None = None, metadata: dict[str, str] | None = None,
    ) -> RuntimeEvent:
        self._sequence += 1
        event = RuntimeEvent(
            event_id=str(uuid.uuid4()), run_id=self.run_id, sequence=self._sequence,
            timestamp=datetime.now(timezone.utc), event_type=event_type, node=node, module_id=module_id,
            objective_id=objective_id, status=status, summary=_bound(summary), capability_key=capability_key,
            tool_id=tool_id, scope=scope, error_type=error_type, error_message=_bound(error_message),
            metadata=metadata or {},
        )
        self.sink.record(event)
        return event


def event_to_sse(event: RuntimeEvent) -> str:
    """Server-Sent Events wire format (item 14/80) -- `event: <type>` +
    `data: <json>`, one blank line terminator."""
    payload = event.model_dump(mode="json", exclude_none=True)
    return f"event: {event.event_type.value}\ndata: {json.dumps(payload, ensure_ascii=False)}\n\n"
