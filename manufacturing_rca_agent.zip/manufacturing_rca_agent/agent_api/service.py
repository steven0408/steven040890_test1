"""Phase PROD-1: AgentService -- the ONE application-service seam between
FastAPI (transport) and the existing Harness (reasoning). Responsibilities:
generate/accept run_id, build the initial `AgentState`, invoke the
production graph, collect the final `HandoffPackage.markdown`, and publish
bounded `RuntimeEvent`s. It contains NO WB/OEE business rules, no
capability/Tool/Skill selection logic -- those remain Standardizer/
Analyzer/Planner's job, unchanged, per this phase's own invariant.

Composition (built once, at construction time, reused across requests --
item 53/54 "avoid import-time side effects", "clean lifespan init"):

    ApiSettings
      -> LLMProviderConfig -> build_llm_client()          (agent/llm/providers)
      -> ModulePackageRegistry (OEE + WB, WB datasources per profile)
      -> bootstrap_runtime(AppConfig, module_packages=..., llm_client=...)  (agent/bootstrap.py)
      -> StandardizerLLMService / AnalyzerLLMService / SynthesisLLMService  (existing, unchanged)
      -> build_production_graph_with_synthesis(...)        (agent/graph/production.py)
      -> compiled once, shared InMemorySaver, thread_id=run_id per request  (item 60)
"""
import logging
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone

from langgraph.checkpoint.memory import InMemorySaver

from agent.bootstrap import AppConfig, RuntimeContext, bootstrap_runtime
from agent.domain.wb.http_client import UrllibHttpClient
from agent.domain.wb.remote import WBApiConfig, build_remote_wb_datasources
from agent.graph.nodes.analyzer_llm import AnalyzerLLMService
from agent.graph.nodes.standardizer_llm import StandardizerLLMService
from agent.graph.nodes.synthesis import make_llm_synthesis_node
from agent.graph.production import build_production_graph_with_synthesis
from agent.llm.context.standardizer_context import StandardizerContextBuilder
from agent.llm.context.synthesis_context import SynthesisContextBuilder
from agent.llm.providers.provider_config import build_llm_client
from agent.modules.oee.package import build_oee_module_package
from agent.modules.registry import ModulePackageRegistry
from agent.modules.wb.package import build_wb_module_package
from agent.state.enums import ObservationStatus
from agent.state.models import Budget, FactoryContext, ModuleState, UserRequest
from agent.state.state import AgentState
from agent.synthesis.handoff_builder import ModuleHandoffBuilder
from agent.synthesis.llm_service import SynthesisLLMService

from agent_api.config import ApiSettings
from agent_api.errors import AgentExecutionError, InvalidRequestError
from agent_api.runtime_events import RuntimeEventPublisher, RuntimeEventSink, RuntimeEventType

_logger = logging.getLogger("agent_api.service")

_DEFAULT_BUDGET = Budget(max_steps=20, max_tool_calls=40, max_depth_per_entity=5)


class NormalizedAnalyzeInput:
    """Application-layer view of `AgentAnalyzeRequest` -- resolves the
    Mode A/B split into one plain `raw_text` + optional `run_id`/
    `factory_id`, so `AgentService.analyze`/`.stream` don't repeat the
    prompt-vs-structured branching."""

    def __init__(self, *, raw_text: str, run_id: str | None, factory_id: str | None, metadata: dict[str, str] | None):
        self.raw_text = raw_text
        self.run_id = run_id
        self.factory_id = factory_id
        self.metadata = metadata or {}


@dataclass
class AnalyzeResult:
    run_id: str
    status: str
    markdown: str
    module_statuses: dict[str, str]


def build_module_package_registry(settings: ApiSettings) -> ModulePackageRegistry:
    """Item 36/37's own "smallest composition wiring" -- the ONE place a
    production deployment selects Remote vs. InMemory WB DataSources, via
    config only. No Tool/Skill/Policy code changes either way."""
    registry = ModulePackageRegistry()
    registry.register(build_oee_module_package())

    if settings.wb_datasource_profile == "remote":
        wb_api_config = WBApiConfig(base_url_env=settings.wb_api_base_url_env)
        datasources = build_remote_wb_datasources(wb_api_config, http_client=UrllibHttpClient())
        registry.register(build_wb_module_package(datasources=datasources))
    else:
        registry.register(build_wb_module_package())  # frozen synthetic default, unchanged

    return registry


class AgentService:
    def __init__(
        self,
        settings: ApiSettings,
        runtime_context: RuntimeContext,
        graph_app,
        event_sink: RuntimeEventSink,
        *,
        standardizer_service: StandardizerLLMService | None = None,
        analyzer_service: AnalyzerLLMService | None = None,
        synthesis_service: SynthesisLLMService | None = None,
    ):
        self._settings = settings
        self._runtime_context = runtime_context
        self._app = graph_app
        self._event_sink = event_sink
        # Phase PROD-1.2: exposed read-only (see the properties below) so a
        # calibration/smoke caller (scripts/production_calibration.py) can
        # exercise each cognitive route individually through the EXACT SAME
        # already-built service objects the production graph itself uses --
        # never a second, parallel LLM client/service construction.
        self._standardizer_service = standardizer_service
        self._analyzer_service = analyzer_service
        self._synthesis_service = synthesis_service

    @classmethod
    def from_settings(cls, settings: ApiSettings, event_sink: RuntimeEventSink) -> "AgentService":
        """The one production construction path -- `main.py`'s lifespan
        calls this exactly once at startup. Never called per-request
        (item 53/54: no per-request re-bootstrap)."""
        llm_client = build_llm_client(settings.llm_provider_config)  # never mock_responder here -- see errors if LLM_PROVIDER=mock (item 25/34/71)
        module_packages = build_module_package_registry(settings)
        # Phase PROD-1.1: config-driven, never hardcoded -- see
        # ApiSettings.context_profile()'s own docstring. Threaded into
        # bootstrap_runtime (Standardizer/Analyzer/Planner/Reflector all
        # sit behind it) and into SynthesisContextBuilder below (built
        # outside bootstrap_runtime, since Synthesis is not per-module).
        context_profile = settings.context_profile()

        app_config = AppConfig(
            factory_id=settings.factory_id, factory_name=settings.factory_name,
            enabled_modules=settings.enabled_modules, llm_routes=settings.llm_routes(),
        )
        runtime_context = bootstrap_runtime(app_config, module_packages=module_packages, llm_client=llm_client, context_profile=context_profile)

        standardizer_service = StandardizerLLMService(StandardizerContextBuilder(), runtime_context.llm_router)
        analyzer_service = AnalyzerLLMService(runtime_context.module_registry, runtime_context.analyzer_context_builder, runtime_context.llm_router)
        synthesis_service = SynthesisLLMService(
            SynthesisContextBuilder(ModuleHandoffBuilder(), reasoning_skill_retriever=runtime_context.reasoning_skill_retriever, context_profile=context_profile),
            runtime_context.llm_router,
        )

        from agent.graph.nodes.analyzer_llm import make_analyzer_llm_node
        from agent.graph.nodes.standardizer_llm import make_standardizer_llm_node

        checkpointer = InMemorySaver()
        graph = build_production_graph_with_synthesis(
            runtime_context.module_runtime, checkpointer, make_llm_synthesis_node(synthesis_service),
            analyzer=make_analyzer_llm_node(analyzer_service), standardizer=make_standardizer_llm_node(standardizer_service),
        )
        graph_app = graph.compile(checkpointer=checkpointer)

        return cls(
            settings, runtime_context, graph_app, event_sink,
            standardizer_service=standardizer_service, analyzer_service=analyzer_service, synthesis_service=synthesis_service,
        )

    @property
    def runtime_context(self) -> RuntimeContext:
        return self._runtime_context

    @property
    def standardizer_service(self) -> StandardizerLLMService | None:
        return self._standardizer_service

    @property
    def analyzer_service(self) -> AnalyzerLLMService | None:
        return self._analyzer_service

    @property
    def synthesis_service(self) -> SynthesisLLMService | None:
        return self._synthesis_service

    def _build_initial_state(self, request: NormalizedAnalyzeInput) -> tuple[str, AgentState]:
        run_id = request.run_id or str(uuid.uuid4())
        factory_id = request.factory_id or self._settings.factory_id
        now = datetime.now(timezone.utc)
        state = AgentState(
            run_id=run_id,
            user_request=UserRequest(request_id=f"{run_id}-req", raw_text=request.raw_text, submitted_by="agent_api", submitted_at=now),
            factory_context=FactoryContext(factory_id=factory_id, factory_name=self._settings.factory_name, enabled_modules=self._settings.enabled_modules),
            global_budget=_DEFAULT_BUDGET,
            started_at=now,
        )
        return run_id, state

    def analyze(self, request: NormalizedAnalyzeInput) -> AnalyzeResult:
        run_id, initial_state = self._build_initial_state(request)
        publisher = RuntimeEventPublisher(run_id=run_id, sink=self._event_sink)
        publisher.publish(RuntimeEventType.RUN_STARTED, node="standardizer", summary="Run started.")

        try:
            result = self._app.invoke(initial_state, config={"configurable": {"thread_id": run_id}})
        except Exception as exc:  # never a bare 500 with a traceback leaked to the client (item 28/29)
            publisher.publish(RuntimeEventType.RUN_FAILED, error_type=type(exc).__name__, error_message=str(exc))
            _logger.exception("run %s failed during graph invocation", run_id)
            raise AgentExecutionError(internal_detail=str(exc), run_id=run_id) from exc

        final_state = AgentState.model_validate(result)
        _publish_state_events(final_state, publisher)

        if final_state.synthesis_result is None:
            publisher.publish(RuntimeEventType.RUN_FAILED, error_type="NoSynthesisResult", error_message="Run ended with no synthesis_result.")
            raise AgentExecutionError("Analysis did not produce a result.", internal_detail="synthesis_result is None", run_id=run_id)

        markdown = final_state.synthesis_result.markdown
        status = final_state.synthesis_result.overall_status.value
        module_statuses = {mid: m.status.value for mid, m in final_state.module_states.items()}
        publisher.publish(RuntimeEventType.RUN_COMPLETED, status=status, summary=f"{len(module_statuses)} module(s) completed.")

        return AnalyzeResult(run_id=run_id, status=status, markdown=markdown, module_statuses=module_statuses)

    def stream(self, request: NormalizedAnalyzeInput):
        """Yields `RuntimeEvent`s live, via LangGraph's own
        `stream_mode="updates"` (item 22: no per-node DB/instrumentation
        hooks -- this IS the "execution wrapper" the phase spec asks for,
        built entirely from LangGraph's existing, unmodified per-node
        update stream). The parent graph's own nodes
        (standardizer/analyzer/module_coordinator/module_subgraph/
        global_completion_check/synthesis) each yield one update on
        completion; a `module_subgraph` update is additionally expanded
        into one event per Planner round / Tool call / Reflector verdict
        using that module's own already-existing `objective_history`/
        `tool_calls`/`reflection_history` (no new decision, a pure
        projection -- item 23).

        Known, documented simplification: per-round module events arrive
        as one batch immediately after the whole module's ReAct loop
        finishes (LangGraph's `stream_mode="updates"` fires on NODE
        completion, and `module_subgraph` is one node from the parent's
        perspective) rather than truly live mid-loop -- see the Phase
        PROD-1 completion report's streaming section for why this was
        chosen over `subgraphs=True` streaming this phase.
        """
        run_id, initial_state = self._build_initial_state(request)
        publisher = RuntimeEventPublisher(run_id=run_id, sink=self._event_sink)
        yield publisher.publish(RuntimeEventType.RUN_STARTED, node="standardizer", summary="Run started.")

        try:
            for update in self._app.stream(initial_state, config={"configurable": {"thread_id": run_id}}, stream_mode="updates"):
                for node_name, node_update in update.items():
                    yield from _events_for_node_update(node_name, node_update, publisher)
        except Exception as exc:
            yield publisher.publish(RuntimeEventType.RUN_FAILED, error_type=type(exc).__name__, error_message=str(exc))
            _logger.exception("run %s failed during streamed graph invocation", run_id)
            return

        # Authoritative final state (never trust the incrementally-merged
        # copy above for the actual response payload) -- one final
        # `.get_state()` read, matching how `analyze()` reads `.invoke()`'s
        # own return value.
        snapshot = self._app.get_state(config={"configurable": {"thread_id": run_id}})
        final_state = AgentState.model_validate(snapshot.values)

        if final_state.synthesis_result is not None:
            markdown = final_state.synthesis_result.markdown
            yield publisher.publish(RuntimeEventType.RUN_COMPLETED, status=final_state.synthesis_result.overall_status.value, metadata={"markdown_present": "true"})
            yield publisher.publish(RuntimeEventType.RUN_COMPLETED, node="final", summary=markdown, metadata={"final": "true"})
        else:
            yield publisher.publish(RuntimeEventType.RUN_FAILED, error_type="NoSynthesisResult", error_message="Run ended with no synthesis_result.")


def normalize_request(*, prompt: str | None, request: dict | None, run_id: str | None, factory_id: str | None, metadata: dict[str, str] | None) -> NormalizedAnalyzeInput:
    """Mirrors `agent_api/schemas.py::AgentAnalyzeRequest`'s own exactly-
    one-of validation -- kept as a pure function so `main.py`'s route
    handler stays a thin adapter (no branching logic of its own beyond
    calling this)."""
    if prompt is not None and prompt.strip():
        return NormalizedAnalyzeInput(raw_text=prompt, run_id=run_id, factory_id=factory_id, metadata=metadata)
    if request is not None:
        raw_text = request.get("raw_text")
        if not raw_text or not isinstance(raw_text, str):
            raise InvalidRequestError("'request.raw_text' must be a non-empty string")
        resolved_factory_id = factory_id or request.get("plant_id")
        return NormalizedAnalyzeInput(raw_text=raw_text, run_id=run_id, factory_id=resolved_factory_id, metadata=metadata)
    raise InvalidRequestError("exactly one of 'prompt' or 'request' must be provided")


# ============================================================================
# RuntimeEvent projection helpers -- pure functions, no FastAPI/Postgres
# dependency, domain-agnostic (never branch on module_type/capability_key
# content, only read them generically off already-existing typed records).
# ============================================================================

_NODE_EVENT_TYPE = {
    "standardizer": RuntimeEventType.STANDARDIZER_COMPLETED,
    "analyzer": RuntimeEventType.ANALYZER_COMPLETED,
    "synthesis": RuntimeEventType.SYNTHESIS_COMPLETED,
}


def _events_for_node_update(node_name: str, node_update: dict, publisher: RuntimeEventPublisher):
    if node_name == "module_subgraph":
        module_states = node_update.get("module_states") or {}
        for module_id, module_state_raw in module_states.items():
            module_state = module_state_raw if isinstance(module_state_raw, ModuleState) else ModuleState.model_validate(module_state_raw)
            yield from _events_for_module_state(module_id, module_state, publisher)
        return

    event_type = _NODE_EVENT_TYPE.get(node_name)
    if event_type is None:
        return  # module_coordinator / global_completion_check: no dedicated client-facing event, covered by RUN_COMPLETED
    yield publisher.publish(event_type, node=node_name)


def _events_for_module_state(module_id: str, module_state: ModuleState, publisher: RuntimeEventPublisher):
    yield publisher.publish(RuntimeEventType.MODULE_STARTED, node="module_subgraph", module_id=module_id, summary=f"module_type={module_state.module_type}")

    for objective_id, record in sorted(module_state.objective_history.items(), key=lambda kv: kv[1].created_step):
        scope = record.scope.model_dump(mode="json") if record.scope is not None else None
        yield publisher.publish(
            RuntimeEventType.PLANNER_DECISION, node="module_planner", module_id=module_id, objective_id=objective_id,
            capability_key=record.capability_key, status=record.status.value, scope=scope, summary=record.description,
        )
        for tool_call in module_state.tool_calls:
            if tool_call.objective_id != objective_id:
                continue
            event_type = RuntimeEventType.TOOL_COMPLETED if tool_call.status == ObservationStatus.SUCCESS else RuntimeEventType.TOOL_FAILED
            yield publisher.publish(
                event_type, node="module_executor", module_id=module_id, objective_id=objective_id,
                tool_id=tool_call.tool_id, status=tool_call.status.value,
                error_type=tool_call.error.error_type.value if tool_call.error else None,
                error_message=tool_call.error.message if tool_call.error else None,
            )
        for reflection in module_state.reflection_history:
            if reflection.objective_id != objective_id:
                continue
            yield publisher.publish(
                RuntimeEventType.REFLECTOR_COMPLETED, node="module_reflector", module_id=module_id, objective_id=objective_id,
                status=reflection.verdict.value, summary=reflection.rationale,
            )

    yield publisher.publish(RuntimeEventType.MODULE_COMPLETED, node="module_completion_check", module_id=module_id, status=module_state.status.value)


def _publish_state_events(final_state: AgentState, publisher: RuntimeEventPublisher) -> None:
    """Non-streaming (`analyze()`) equivalent of `_events_for_node_update`
    -- publishes the same bounded event set to the sink (for DB/stdout
    observability) without yielding them to an HTTP response."""
    publisher.publish(RuntimeEventType.STANDARDIZER_COMPLETED, node="standardizer")
    publisher.publish(RuntimeEventType.ANALYZER_COMPLETED, node="analyzer")
    for module_id, module_state in final_state.module_states.items():
        for _ in _events_for_module_state(module_id, module_state, publisher):
            pass  # already recorded via publisher.publish's own side effect
    if final_state.synthesis_result is not None:
        publisher.publish(RuntimeEventType.SYNTHESIS_COMPLETED, node="synthesis")
