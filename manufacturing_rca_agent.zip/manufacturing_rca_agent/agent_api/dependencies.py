"""Phase PROD-1: FastAPI dependency providers -- thin accessors onto
`app.state`, built once at lifespan startup (agent_api/main.py). No route
handler constructs an AgentService/settings/sink itself."""
from fastapi import Request

from agent_api.config import ApiSettings
from agent_api.runtime_events import RuntimeEventSink
from agent_api.service import AgentService


def get_agent_service(request: Request) -> AgentService:
    return request.app.state.agent_service


def get_settings(request: Request) -> ApiSettings:
    return request.app.state.settings


def get_event_sink(request: Request) -> RuntimeEventSink:
    return request.app.state.event_sink
