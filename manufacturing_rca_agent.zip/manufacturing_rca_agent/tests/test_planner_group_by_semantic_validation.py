"""Phase WB-3F.1 item 34: `validate_planner_decision`'s `_validate_scope`
now also checks `ObjectiveProposal.scope.group_by` entries against the
proposed capability's own `accepted_scope_dimensions` -- an LLM-proposed
group_by naming a dimension the capability has no notion of at all must be
rejected before any Tool ever runs, never silently ignored.

Phase WB-3F.2: `wb.bank.status_summary` now genuinely accepts `customer` as
a real filter dimension (customer_code is Tool-wired this phase), so
`group_by=["customer"]` is no longer a good "capability has no notion of
this at all" example -- switched to a dimension name that remains
genuinely unknown to this Skill.
"""
import pytest

from agent.planning.policies.llm import PlannerSemanticValidationError, validate_planner_decision
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.state.enums import EntityAnalysisStatus, ObjectiveAction, TargetRefType, TaskType
from agent.state.models import EntityState, TargetRef
from agent.state.scope import ObjectiveScope, ScopeFilter, ScopeOperator

from .conftest import make_module_state
from .test_wb_reasoning_llm_live import _wb_registries


def _module_state_with_ase07():
    entity_states = {"ASE07": EntityState(entity_id="ASE07", entity_type="PLANT", status=EntityAnalysisStatus.INVESTIGATING, current_tree_node_id="n1", priority_score=0.9)}
    return make_module_state(module_type="WB").model_copy(update={"entity_states": entity_states})


def _dispatch_with_group_by(group_by: list[str]) -> PlannerDecision:
    proposal = ObjectiveProposal(
        action=ObjectiveAction.SUMMARIZE,
        capability_key="wb.bank.status_summary",
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="ASE07"),
        scope=ObjectiveScope(filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE07")], group_by=group_by),
        description="d", expected_output="eo",
    )
    return PlannerDecision(decision=PlannerDecisionType.DISPATCH, next_objective=proposal, priority=1.0, rationale_summary="x")


def test_group_by_dimension_the_capability_does_not_accept_is_rejected():
    _, skill_registry, _ = _wb_registries()

    decision = _dispatch_with_group_by(["device_serial"])  # wb.bank.status_summary has no notion of this dimension at all
    with pytest.raises(PlannerSemanticValidationError, match="group_by"):
        validate_planner_decision(decision, module_state=_module_state_with_ase07(), task_type=TaskType.RCA, skill_registry=skill_registry)


def test_group_by_dimension_the_capability_does_accept_passes():
    _, skill_registry, _ = _wb_registries()

    decision = _dispatch_with_group_by(["plant"])  # accepted (even though not a real breakdown for this Tool -- see report's own documented limitation)
    validate_planner_decision(decision, module_state=_module_state_with_ase07(), task_type=TaskType.RCA, skill_registry=skill_registry)


def test_empty_group_by_is_always_fine():
    _, skill_registry, _ = _wb_registries()

    decision = _dispatch_with_group_by([])
    validate_planner_decision(decision, module_state=_module_state_with_ase07(), task_type=TaskType.RCA, skill_registry=skill_registry)


def test_customer_group_by_is_now_accepted_phase_wb_3f_2():
    """customer_code is genuinely Tool-wired this phase (agent/skills/wb/
    bank_status_summary.md's parameter_mapping) -- accepted_scope_dimensions
    correctly includes it now, so this must NOT raise."""
    _, skill_registry, _ = _wb_registries()

    decision = _dispatch_with_group_by(["package"])
    validate_planner_decision(decision, module_state=_module_state_with_ase07(), task_type=TaskType.RCA, skill_registry=skill_registry)
