"""Phase 7C item 8: build_learning_run_snapshot against a real RCA-COMPLETE
trace -- proves the extraction (not just the schema) works end to end.
"""
from agent.evaluation.evaluator import RunEvaluator
from agent.learning.snapshot import build_learning_run_snapshot
from agent.state.enums import ModuleStatus, TaskType
from agent.state.models import Goal, GoalScope

from .conftest import make_agent_state, make_run_audit_bundle_from_modules, run_oee_module_state_history


def test_real_rca_complete_trace_produces_a_populated_snapshot():
    history = run_oee_module_state_history(TaskType.RCA)
    final = history[-1]
    assert final.status == ModuleStatus.COMPLETE
    state = make_agent_state(run_id="run-1").model_copy(
        update={
            "module_states": {"OEE": final},
            "global_goal": Goal(goal_id="g1", raw_statement="why", normalized_statement="why", task_type=TaskType.RCA, scope=GoalScope()),
        }
    )
    evaluation = RunEvaluator().evaluate(state, make_run_audit_bundle_from_modules([final]))

    snapshot = build_learning_run_snapshot(state, evaluation)

    assert snapshot.run_id == "run-1"
    assert snapshot.module_types == ["OEE"]
    assert snapshot.task_type == TaskType.RCA
    assert any("Motor Failure" in f.statement for f in snapshot.confirmed_findings)
    assert any("Motor Failure" in rc.statement for rc in snapshot.root_causes)
    assert snapshot.evaluation_summary.overall_score is None  # no weighting was supplied to RunEvaluator
    assert snapshot.feedback_summary is None  # none supplied
    assert snapshot.planner_summary.objective_count == evaluation.efficiency.objective_count


def test_snapshot_never_carries_full_module_state():
    """Structural proof the projection is bounded -- no field on
    LearningRunSnapshot is/contains a raw ModuleState."""
    import typing

    from agent.learning.snapshot import LearningRunSnapshot
    from agent.state.base import RCABaseModel
    from agent.state.models import ModuleState

    def _nested(annotation, seen: set) -> set:
        origin = typing.get_origin(annotation)
        if origin is None:
            if isinstance(annotation, type) and issubclass(annotation, RCABaseModel) and annotation not in seen:
                seen.add(annotation)
                for field in annotation.model_fields.values():
                    seen |= _nested(field.annotation, seen)
            return seen
        for arg in typing.get_args(annotation):
            seen |= _nested(arg, seen)
        return seen

    nested = _nested(LearningRunSnapshot, set())
    assert ModuleState not in nested
