﻿"""Phase 5C-2 end-to-end: Mock LLM Analyzer -> OEE -> Mock LLM Planner ->
Capability Layer -> ToolExecutionManager -> deterministic Reflector ->
Completion Check -> fan-in -> READY_FOR_SYNTHESIS, for all three TaskTypes,
through the real production-style parent graph (not a standalone module).
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD
from agent.graph.graph import build_phase2_graph
from agent.graph.nodes.analyzer_llm import AnalyzerLLMService, make_analyzer_llm_node
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.llm.client import MockLLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.context.analyzer_context import AnalyzerContextBuilder
from agent.llm.prompts.analyzer import AnalyzerDecision, ModuleSelection
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.planning.policies.mock import DeterministicMockPolicy
from agent.state.enums import (
    EvidenceQuality,
    FindingStatus,
    ModuleStatus,
    ObjectiveAction,
    ObservationStatus,
    RunTerminationStatus,
    TargetRefType,
    TaskType,
)
from agent.state.models import TargetRef
from agent.state.state import AgentState
from agent.tools.base import ToolResult
from agent.tools.mocks.scripted_tool import ScriptedMockTool

from .conftest import make_agent_state, make_budget, make_llm_planning_policy, make_module_registry, make_oee_capability_runtime


def _legacy_runtime() -> ModuleRuntimeConfig:
    return ModuleRuntimeConfig(
        policy=DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1),
        tool=ScriptedMockTool({"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}),
        budget=make_budget(max_steps=3, max_tool_calls=5, max_depth_per_entity=2),
    )


def _proposal(action, ref_type, ref_id, description, capability_key) -> ObjectiveProposal:
    return ObjectiveProposal(action=action, capability_key=capability_key, target_ref=TargetRef(ref_type=ref_type, ref_id=ref_id), description=description, expected_output="analysis data")


def _analyzer_node_selecting_oee_only(task_type: TaskType):
    def responder(request):
        return AnalyzerDecision(
            task_type=task_type,
            selected_modules=[ModuleSelection(module_type="OEE", priority=0.9, confidence=0.9, rationale="OEE relevant to this request.", goal_statement="Assess OEE for the requested scope.")],
            reasoning_summary="Mock decision.",
            confidence=0.9,
        )

    registry = make_module_registry()
    router = LLMRouter(routes={"analyzer": LLMRouteConfig(route="analyzer", model="mock-analyzer")}, client=MockLLMClient(responder), usage_sink=InMemoryLLMUsageSink())
    service = AnalyzerLLMService(registry, AnalyzerContextBuilder(registry), router)
    return make_analyzer_llm_node(service)


class _SequencedResponder:
    def __init__(self, decisions: list[PlannerDecision]):
        self._decisions = decisions
        self.calls = 0

    def __call__(self, request):
        index = min(self.calls, len(self._decisions) - 1)
        self.calls += 1
        return self._decisions[index]


def _run(planner_policy, analyzer_task_type: TaskType, raw_text: str, run_id: str) -> AgentState:
    runtime = {
        "OEE": ModuleRuntimeConfig(policy=planner_policy, capability=make_oee_capability_runtime(MOCK_EQUIPMENT, OEE_THRESHOLD), budget=make_budget(max_steps=6, max_tool_calls=20, max_depth_per_entity=3)),
        "Output": _legacy_runtime(),
        "WIP": _legacy_runtime(),
    }
    checkpointer = InMemorySaver()
    analyzer_node = _analyzer_node_selecting_oee_only(analyzer_task_type)
    graph = build_phase2_graph(runtime, checkpointer, analyzer=analyzer_node)
    app = graph.compile(checkpointer=checkpointer)

    initial_state = make_agent_state(run_id=run_id, raw_text=raw_text)
    result = app.invoke(initial_state, config={"configurable": {"thread_id": run_id}})
    return AgentState.model_validate(result)


def test_information_end_to_end_mock_llm_analyzer_and_planner():
    decision = PlannerDecision(
        decision=PlannerDecisionType.DISPATCH,
        next_objective=_proposal(ObjectiveAction.SUMMARIZE, TargetRefType.MODULE, "OEE", "Get current OEE status", "oee.current_status"),
        priority=1.0,
        rationale_summary="Information request.",
    )
    planner_policy, planner_usage_sink, planner_client = make_llm_planning_policy(lambda req: decision)

    final_state = _run(planner_policy, TaskType.INFORMATION, "今天平均 OEE 多少？", "e2e-info")

    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.COMPLETE
    assert [r.action for r in oee.objective_history.values()] == [ObjectiveAction.SUMMARIZE]
    assert [tc.tool_id for tc in oee.tool_calls] == ["query_oee_data", "aggregate_oee_status"]
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS
    assert len(planner_client.calls) == 1


def test_analysis_end_to_end_mock_llm_analyzer_and_planner():
    decision = PlannerDecision(
        decision=PlannerDecisionType.DISPATCH,
        next_objective=_proposal(ObjectiveAction.SCREEN, TargetRefType.MODULE, "OEE", "Screen and rank abnormal equipment", "oee.equipment_screening"),
        priority=1.0,
        rationale_summary="Analysis request.",
    )
    planner_policy, planner_usage_sink, planner_client = make_llm_planning_policy(lambda req: decision)

    final_state = _run(planner_policy, TaskType.ANALYSIS, "哪些設備 OEE 比較差？", "e2e-analysis")

    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.COMPLETE
    assert oee.findings[-1].is_root_cause is False
    assert oee.entity_states == {}
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS
    assert len(planner_client.calls) == 1


def test_rca_end_to_end_mock_llm_analyzer_and_planner():
    decisions = [
        PlannerDecision(
            decision=PlannerDecisionType.DISPATCH,
            next_objective=_proposal(ObjectiveAction.SCREEN, TargetRefType.MODULE, "OEE", "Screen abnormal equipment", "oee.equipment_screening"),
            priority=1.0,
            rationale_summary="No screening evidence yet.",
        ),
        PlannerDecision(
            decision=PlannerDecisionType.DISPATCH,
            # canonical TargetRef (Phase 5C-2.1) -- bare entity id
            next_objective=_proposal(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", "Deep-dive EQ001", "oee.equipment_detail"),
            priority=1.0,
            rationale_summary="Availability dominant; EQ001 highest contribution.",
        ),
        PlannerDecision(
            decision=PlannerDecisionType.DISPATCH,
            next_objective=_proposal(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ003", "Deep-dive EQ003", "oee.equipment_detail"),
            priority=1.0,
            rationale_summary="EQ001 confirmed Motor Failure; EQ003 unexplored.",
        ),
    ]
    planner_policy, planner_usage_sink, planner_client = make_llm_planning_policy(_SequencedResponder(decisions))

    final_state = _run(planner_policy, TaskType.RCA, "為什麼今天 OEE 下降？", "e2e-rca")

    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.COMPLETE
    final_finding = oee.findings[-1]
    assert final_finding.status == FindingStatus.CONFIRMED
    assert final_finding.is_root_cause is True
    assert set(final_finding.entity_ids) == {"EQ001", "EQ003"}
    assert "Motor Failure" in final_finding.pattern
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS
    assert len(planner_client.calls) == 3
