"""Phase WB-2C item 41 (L) + Phase WB-2C.1 items 17-21: genuine PARENT
graph WB traces -- `User -> Analyzer -> WB ModuleTask -> Send -> WB module
subgraph -> Coordinator fan-in -> Global Completion Check ->
READY_FOR_SYNTHESIS`, through the real `build_phase2_graph` composition
(never a bypassed module-subgraph-only shortcut). All offline
(scripted/Mock Analyzer, no real LLM/API/DB).

Phase WB-2C.1 closed the `ModuleGoal.statement` architecture gap Phase
WB-2C could only document (see agent/planning/policies/wb.py's module
docstring, now marked RESOLVED): `AnalyzerDecision.selected_modules[i]`
now carries a required `goal_statement` field that flows verbatim through
`ModuleTask` -> `ModuleDispatchPayload` -> `build_initial_module_state` ->
`ModuleGoal.statement`. These tests therefore no longer inject a goal via
`model_copy(update={"goal": ...})` -- the scripted Analyzer's own
`goal_statement` is the only source of truth, exactly as it would be with
a real LLM Analyzer in production.
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.domain.wb.synthetic import GOLDEN_DATE
from agent.graph.graph import build_phase2_graph
from agent.graph.nodes.analyzer_llm import AnalyzerLLMService, make_analyzer_llm_node
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.llm.client import MockLLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.context.analyzer_context import AnalyzerContextBuilder
from agent.llm.prompts.analyzer import AnalyzerDecision, ModuleSelection
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.modules.wb.package import build_wb_module_package
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import ModuleStatus, RunTerminationStatus, TaskType
from agent.state.state import AgentState
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry

from .conftest import make_agent_state, make_module_registry

_DATE = GOLDEN_DATE.isoformat()  # "2026-08-12"


def _make_wb_enabled_state(run_id: str, raw_text: str) -> AgentState:
    """`make_agent_state()`'s default `factory_context.enabled_modules`
    is `["OEE", "Output", "WIP"]` -- it never includes "WB". Both
    `validate_analyzer_decision` and `_deterministic_fallback_decision`
    (agent/graph/nodes/analyzer_llm.py) filter candidate modules through
    `module_registry.available_for(factory_context)`, so without this
    override even a scripted AnalyzerDecision selecting WB fails semantic
    validation (WB "not registered/enabled/available for this factory"),
    which AnalyzerLLMService treats as an LLMRouterError and silently
    falls back to WIP/Output -- not a production bug, a test-fixture gap
    in this file only."""
    state = make_agent_state(run_id=run_id, raw_text=raw_text)
    return state.model_copy(update={"factory_context": state.factory_context.model_copy(update={"enabled_modules": ["WB"]})})


def _wb_module_runtime_config() -> ModuleRuntimeConfig:
    package = build_wb_module_package()
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner_capability = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=SkillRunner(tool_registry, ToolExecutionManager()))
    return ModuleRuntimeConfig(policy=WBPlanningPolicy(), capability=runner_capability, budget=package.budget)


def _analyzer_node_selecting_wb_only(task_type: TaskType, goal_statement: str, *, rationale: str = "WB relevant to this request."):
    """Scripts a real, module-specific `goal_statement` -- distinct from
    `rationale` -- exactly as a real LLM Analyzer would be expected to
    produce (Phase WB-2C.1 item 6/7)."""

    def responder(request):
        return AnalyzerDecision(
            task_type=task_type,
            selected_modules=[ModuleSelection(module_type="WB", priority=0.9, confidence=0.9, rationale=rationale, goal_statement=goal_statement)],
            reasoning_summary="Mock decision.",
            confidence=0.9,
        )

    registry = make_module_registry()
    registry.register(build_wb_module_package().module_definition)  # Analyzer's own catalog must know WB exists (item 28)
    router = LLMRouter(routes={"analyzer": LLMRouteConfig(route="analyzer", model="mock-analyzer")}, client=MockLLMClient(responder), usage_sink=InMemoryLLMUsageSink())
    service = AnalyzerLLMService(registry, AnalyzerContextBuilder(registry), router)
    return make_analyzer_llm_node(service)


def _invoke(task_type: TaskType, goal_statement: str, raw_text: str, run_id: str) -> AgentState:
    runtime = {"WB": _wb_module_runtime_config()}
    checkpointer = InMemorySaver()
    analyzer_node = _analyzer_node_selecting_wb_only(task_type, goal_statement)
    graph = build_phase2_graph(runtime, checkpointer, analyzer=analyzer_node)
    app = graph.compile(checkpointer=checkpointer)

    initial_state = _make_wb_enabled_state(run_id, raw_text)
    result = app.invoke(initial_state, config={"configurable": {"thread_id": run_id}})
    return AgentState.model_validate(result)


def test_wb_module_is_selectable_via_module_registry_catalog():
    """Item 28: Analyzer discovers WB through ModuleDefinition/ModuleRegistry
    catalog metadata -- never a hardcoded "if WIP then WB" prompt rule."""
    registry = make_module_registry()
    registry.register(build_wb_module_package().module_definition)
    definition = registry.get("WB")
    assert definition.module_type == "WB"
    assert TaskType.INFORMATION in definition.supported_task_types
    assert TaskType.ANALYSIS in definition.supported_task_types


# ============================================================================
# Item 19: INFORMATION minimal-depth parent trace
# ============================================================================


def test_case_1_oee_information_parent_trace_reaches_complete():
    final_state = _invoke(
        TaskType.INFORMATION,
        goal_statement=f"Report ASE01 WB OEE status for {_DATE}.",
        raw_text="2026-08-12 ASE01 OEE 是多少？",
        run_id="wb-parent-oee-info",
    )

    wb = final_state.module_states["WB"]
    assert wb.status == ModuleStatus.COMPLETE
    assert len(wb.objective_history) == 1  # minimal depth -- never auto-chases WIP/Bank/Output
    record = next(iter(wb.objective_history.values()))
    assert record.capability_key == "wb.oee.plant_status"
    assert record.target_ref.ref_id == "ASE01"
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


def test_case_1_wb_evidence_and_findings_present_no_root_cause():
    final_state = _invoke(
        TaskType.INFORMATION,
        goal_statement=f"Report ASE01 WB OEE status for {_DATE}.",
        raw_text="2026-08-12 ASE01 OEE 是多少？",
        run_id="wb-parent-oee-info-evidence",
    )

    wb = final_state.module_states["WB"]
    assert len(wb.evidence) == 1
    assert len(wb.findings) >= 1
    assert all(not f.is_root_cause for f in wb.findings)
    assert "58.0" in wb.findings[-1].statement


# ============================================================================
# Item 17 Case 1: OEE ANALYSIS parent trace (comparison + dominant loss)
# ============================================================================


def test_case_2_oee_analysis_parent_trace_reaches_complete():
    final_state = _invoke(
        TaskType.ANALYSIS,
        goal_statement=f"Compare WB plant OEE for {_DATE}, identify the lowest-performing plant, and identify the dominant recorded loss category.",
        raw_text="2026-08-12 哪個 WB Plant OEE 最差？主要 loss 是什麼？",
        run_id="wb-parent-oee-analysis",
    )

    wb = final_state.module_states["WB"]
    assert wb.status == ModuleStatus.COMPLETE
    record = next(iter(wb.objective_history.values()))
    assert record.capability_key == "wb.oee.status_analysis"
    finding = wb.findings[-1]
    assert "ASE01" in finding.statement
    assert "downtime" in finding.statement
    assert finding.is_root_cause is False
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


# ============================================================================
# Item 17 Case 2: WIP ANALYSIS (Hold) parent trace
# ============================================================================


def test_case_3_wip_hold_analysis_parent_trace_reaches_complete():
    final_state = _invoke(
        TaskType.ANALYSIS,
        goal_statement=f"Determine WB WIP Hold status for ASE03 on snapshot date {_DATE}.",
        raw_text="2026-08-12 ASE03 Hold 狀況？",
        run_id="wb-parent-wip-hold",
    )

    wb = final_state.module_states["WB"]
    assert wb.status == ModuleStatus.COMPLETE
    record = next(iter(wb.objective_history.values()))
    assert record.capability_key == "wb.wip.hold_analysis"
    assert record.target_ref.ref_id == "ASE03"
    finding = wb.findings[-1]
    assert "22/30" in finding.statement
    assert "73.3%" in finding.statement
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


# ============================================================================
# Item 18: BANK INFORMATION parent trace
# ============================================================================


def test_case_4_bank_information_parent_trace_reaches_complete():
    final_state = _invoke(
        TaskType.INFORMATION,
        goal_statement=f"Report WB BANK status for ASE07 on {_DATE}.",
        raw_text="2026-08-12 ASE07 BANK 狀況？",
        run_id="wb-parent-bank-info",
    )

    wb = final_state.module_states["WB"]
    assert wb.status == ModuleStatus.COMPLETE
    record = next(iter(wb.objective_history.values()))
    assert record.capability_key == "wb.bank.status_summary"
    assert record.target_ref.ref_id == "ASE07"
    assert "7" in wb.findings[-1].statement
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


# ============================================================================
# Item 18: OUTPUT ANALYSIS (comparison) parent trace
# ============================================================================


def test_case_5_output_comparison_parent_trace_reaches_complete():
    final_state = _invoke(
        TaskType.ANALYSIS,
        goal_statement=f"Compare WB plant Output for {_DATE} and identify the lowest-performing plant.",
        raw_text="2026-08-12 哪個 WB Plant Output 最低？",
        run_id="wb-parent-output-comparison",
    )

    wb = final_state.module_states["WB"]
    assert wb.status == ModuleStatus.COMPLETE
    record = next(iter(wb.objective_history.values()))
    assert record.capability_key == "wb.output.comparison"
    assert wb.findings[-1].is_root_cause is False
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


# ============================================================================
# Robustness: an ambiguous/no-signal goal_statement still terminates
# cleanly (never a crash/hang), even though the architecture gap that used
# to force this path in every WB-2C parent test is now closed
# ============================================================================


def test_ambiguous_goal_statement_fails_cleanly_without_fabricating_an_answer():
    """Not the WB-2C architecture-gap regression anymore (goal_statement now
    genuinely flows through) -- this proves WBPlanningPolicy's "never guess"
    rule (item 15) still holds even when a real, non-mock goal_statement
    happens to name no topic/plant/date WBPlanningPolicy's keyword detector
    recognizes: it returns None rather than fabricate a plant/date, which
    resolves to FAILED (no findings) through the existing generic
    completion rule -- and the parent graph still reaches
    READY_FOR_SYNTHESIS cleanly."""
    final_state = _invoke(
        TaskType.ANALYSIS,
        goal_statement="Investigate Wire Bond operations.",  # no oee/bank/wip/output keyword, no date, no plant
        raw_text="WB 分析",
        run_id="wb-parent-ambiguous",
    )

    wb = final_state.module_states["WB"]
    assert wb.status == ModuleStatus.FAILED  # no viable objective -- never a fabricated answer
    assert len(wb.objective_history) == 0
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS
