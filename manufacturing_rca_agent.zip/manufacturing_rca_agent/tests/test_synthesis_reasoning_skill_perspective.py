"""Phase 6B item 6: reasoning-skill / audience perspective actually changes
presentation, never facts. Same OEE findings feed two syntheses -- one
with no reasoning skill retrievable, one with `plant_manager_perspective`
retrievable -- and the responder conditions its wording on whether
guidance text appears in the rendered prompt (exactly what a real LLM
would do), while both drafts reference the identical authoritative
root_cause_id. The two markdown outputs must differ in wording but agree
exactly on root causes/facts.
"""
from pathlib import Path

from agent.llm.context.synthesis_context import SynthesisContextBuilder
from agent.llm.context.synthesis_context_audit import InMemorySynthesisContextAuditSink
from agent.llm.context.reasoning_skill_retriever import DeterministicReasoningSkillRetriever
from agent.llm.prompts.synthesis import SynthesisDraft
from agent.llm.router import LLMRouter
from agent.llm.config import LLMRouteConfig
from agent.llm.client import MockLLMClient
from agent.llm.usage import InMemoryLLMUsageSink
from agent.skills.registry import SkillRegistry
from agent.state.enums import TaskType
from agent.state.models import Goal, GoalScope
from agent.synthesis.handoff_builder import ModuleHandoffBuilder
from agent.synthesis.llm_service import SynthesisLLMService

from .conftest import run_oee_module_state_history, make_agent_state

REASONING_SKILLS_DIR = Path(__file__).resolve().parent.parent / "agent" / "skills" / "reasoning"


def _rca_state():
    history = run_oee_module_state_history(TaskType.RCA)
    state = make_agent_state()
    return state.model_copy(
        update={
            "module_states": {"OEE": history[-1]},
            "global_goal": Goal(goal_id="g1", raw_statement="為什麼 OEE 下降？", normalized_statement="Why did OEE decline?", task_type=TaskType.RCA, scope=GoalScope()),
        }
    )


def _make_responder(root_cause_ids: list[str]):
    def responder(request):
        prompt_text = "\n".join(m.content for m in request.messages)
        if "plant_manager_perspective" in prompt_text:
            summary = "Management priority: the bottleneck line's Motor Failure needs immediate maintenance action to protect throughput."
            audience = "Plant Manager View"
        else:
            summary = "Root cause analysis: Motor Failure identified as the confirmed Availability-loss mechanism."
            audience = ""
        return SynthesisDraft(executive_summary=summary, root_cause_ids=root_cause_ids, audience_summary=audience)

    return responder


def _service(reasoning_skill_retriever, responder):
    context_builder = SynthesisContextBuilder(ModuleHandoffBuilder(), reasoning_skill_retriever=reasoning_skill_retriever, audit_sink=InMemorySynthesisContextAuditSink())
    router = LLMRouter(routes={"synthesis": LLMRouteConfig(route="synthesis", model="mock-synthesis-v1")}, client=MockLLMClient(responder), usage_sink=InMemoryLLMUsageSink())
    return SynthesisLLMService(context_builder, router)


def test_reasoning_skill_changes_wording_but_not_facts():
    state = _rca_state()
    context_without = SynthesisContextBuilder(ModuleHandoffBuilder()).build(state).context
    root_cause_ids = [rc.root_cause_id for h in context_without.module_handoffs for rc in h.root_causes]
    assert root_cause_ids

    responder = _make_responder(root_cause_ids)

    no_skill_outcome = _service(None, responder).synthesize(state)
    with_skill_outcome = _service(DeterministicReasoningSkillRetriever(_reasoning_registry()), responder).synthesize(state)

    # facts identical -- same root causes, same overall status, same module results
    assert no_skill_outcome.package.root_causes == with_skill_outcome.package.root_causes
    assert no_skill_outcome.package.overall_status == with_skill_outcome.package.overall_status
    assert {m.module_id for m in no_skill_outcome.package.module_results} == {m.module_id for m in with_skill_outcome.package.module_results}

    # wording differs
    assert no_skill_outcome.package.markdown != with_skill_outcome.package.markdown
    assert "Plant Manager View" not in no_skill_outcome.package.markdown
    assert "Plant Manager View" in with_skill_outcome.package.markdown
    assert "Motor Failure" in no_skill_outcome.package.markdown
    assert "Motor Failure" in with_skill_outcome.package.markdown  # the fact still shows up, just worded differently


def _reasoning_registry() -> SkillRegistry:
    registry = SkillRegistry()
    registry.load_directory(REASONING_SKILLS_DIR)
    return registry
