"""Phase 7A items 13.H/13.I: multi-module coverage/status consistency, and
a BLOCKED module correctly treated as an authorization gap -- never
folded into "data-quality failure" (analytical_quality's ratios), matching
Phase 6A's own BLOCKED-vs-data-limitation separation.
"""
from agent.evaluation.evaluator import RunEvaluator
from agent.state.enums import FindingStatus, ModuleStatus, TaskType
from agent.state.models import Finding, RejectionRecord

from .conftest import make_agent_state, make_module_state, make_run_audit_bundle_from_modules


def test_multi_module_coverage_and_global_status_consistency():
    oee = make_module_state(module_id="OEE", module_type="OEE").model_copy(
        update={"status": ModuleStatus.COMPLETE, "findings": [Finding(finding_id="f1", statement="OEE Motor Failure confirmed.", pattern="Availability", confidence=0.9, status=FindingStatus.CONFIRMED, is_root_cause=True)]}
    )
    output = make_module_state(module_id="Output", module_type="Output").model_copy(
        update={"status": ModuleStatus.COMPLETE, "findings": [Finding(finding_id="f1", statement="Output on target.", pattern="none", confidence=0.9, status=FindingStatus.CONFIRMED, is_root_cause=False)]}
    )
    wip = make_module_state(module_id="WIP", module_type="WIP").model_copy(update={"status": ModuleStatus.PARTIAL})

    state = make_agent_state().model_copy(update={"module_states": {"OEE": oee, "Output": output, "WIP": wip}})
    bundle = make_run_audit_bundle_from_modules([oee, output, wip])
    evaluation = RunEvaluator().evaluate(state, bundle)

    assert evaluation.efficiency.total_module_count == 3
    assert evaluation.efficiency.completed_module_count == 2
    assert evaluation.analytical_quality.partial_module_ratio == 1 / 3
    assert evaluation.delivery_quality.module_result_coverage == 1.0  # all 3 selected modules have a terminal result
    assert evaluation.delivery_quality.synthesis_status_consistency == 1.0


def test_blocked_module_not_treated_as_data_quality_failure():
    blocked = make_module_state().model_copy(
        update={"status": ModuleStatus.BLOCKED, "rejections": [RejectionRecord(objective_id="o1", permission_type="restricted_query", reason="operator denied", alternative_found=False)]}
    )
    state = make_agent_state().model_copy(update={"module_states": {"OEE": blocked}})
    bundle = make_run_audit_bundle_from_modules([blocked])
    evaluation = RunEvaluator().evaluate(state, bundle)

    assert evaluation.analytical_quality.blocked_module_ratio == 1.0
    assert evaluation.analytical_quality.failed_module_ratio == 0.0  # BLOCKED is not FAILED
    # the rejection record itself counts as the "explanation" -- an
    # authorization gap is transparently represented, not silently missing
    assert evaluation.analytical_quality.limitation_transparency_score == 1.0
    assert not any("data" in i.statement.lower() and "authorization" not in i.statement.lower() for i in evaluation.issues)
