"""Phase 7B items 1/3: HumanFeedback target-type structural validation and
`validate_human_feedback`'s lineage checking against a real HandoffPackage.
"""
from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from agent.feedback.validation import FeedbackLineageError, validate_human_feedback
from agent.llm.context.synthesis_context import SynthesisContextBuilder
from agent.state.enums import FeedbackTargetType, TaskType
from agent.state.models import HumanFeedback
from agent.synthesis.handoff_builder import ModuleHandoffBuilder
from agent.synthesis.package import build_handoff_package

from .conftest import make_agent_state, run_oee_module_state_history


def _now():
    return datetime.now(timezone.utc)


def _real_handoff_package():
    history = run_oee_module_state_history(TaskType.RCA)
    state = make_agent_state().model_copy(update={"module_states": {"OEE": history[-1]}})
    outcome = SynthesisContextBuilder(ModuleHandoffBuilder()).build(state)
    return build_handoff_package(outcome.context), state


# ============================================================================
# Structural validation (item 1)
# ============================================================================


def test_run_target_may_omit_target_id():
    HumanFeedback(feedback_id="f1", run_id="run-1", target_type=FeedbackTargetType.RUN, created_at=_now())


def test_synthesis_target_may_omit_target_id():
    HumanFeedback(feedback_id="f1", run_id="run-1", target_type=FeedbackTargetType.SYNTHESIS, created_at=_now())


@pytest.mark.parametrize("target_type", [FeedbackTargetType.MODULE, FeedbackTargetType.FINDING, FeedbackTargetType.ROOT_CAUSE, FeedbackTargetType.RECOMMENDATION])
def test_target_types_requiring_target_id_reject_none(target_type):
    with pytest.raises(ValidationError):
        HumanFeedback(feedback_id="f1", run_id="run-1", target_type=target_type, target_id=None, created_at=_now())


@pytest.mark.parametrize("target_type", [FeedbackTargetType.MODULE, FeedbackTargetType.FINDING, FeedbackTargetType.ROOT_CAUSE, FeedbackTargetType.RECOMMENDATION])
def test_target_types_requiring_target_id_accept_one(target_type):
    HumanFeedback(feedback_id="f1", run_id="run-1", target_type=target_type, target_id="real-id", created_at=_now())


def test_feedback_signals_stay_independent_no_implied_inference():
    """thumbs_up must never be conflated with root_cause_correct, and
    vice versa -- both simply coexist as independent optional fields."""
    feedback = HumanFeedback(
        feedback_id="f1", run_id="run-1", target_type=FeedbackTargetType.RUN,
        thumbs="up", created_at=_now(),
    )
    assert feedback.root_cause_correct is None
    assert feedback.finding_correct is None
    assert feedback.recommendation_useful is None


# ============================================================================
# Lineage validation against a real HandoffPackage (item 3)
# ============================================================================


def test_module_target_lineage_valid():
    package, _ = _real_handoff_package()
    module_id = package.module_results[0].module_id
    feedback = HumanFeedback(feedback_id="f1", run_id=package.run_id, target_type=FeedbackTargetType.MODULE, target_id=module_id, created_at=_now())
    validate_human_feedback(feedback, handoff_package=package)  # must not raise


def test_module_target_lineage_rejects_fake_id():
    package, _ = _real_handoff_package()
    feedback = HumanFeedback(feedback_id="f1", run_id=package.run_id, target_type=FeedbackTargetType.MODULE, target_id="NotARealModule", created_at=_now())
    with pytest.raises(FeedbackLineageError):
        validate_human_feedback(feedback, handoff_package=package)


def test_root_cause_target_lineage_valid_and_fake_rejected():
    package, _ = _real_handoff_package()
    assert package.root_causes  # sanity -- real RCA COMPLETE trace has one
    real_id = package.root_causes[0].root_cause_id
    validate_human_feedback(
        HumanFeedback(feedback_id="f1", run_id=package.run_id, target_type=FeedbackTargetType.ROOT_CAUSE, target_id=real_id, created_at=_now()),
        handoff_package=package,
    )
    with pytest.raises(FeedbackLineageError):
        validate_human_feedback(
            HumanFeedback(feedback_id="f2", run_id=package.run_id, target_type=FeedbackTargetType.ROOT_CAUSE, target_id="fake-root-cause", created_at=_now()),
            handoff_package=package,
        )


def test_finding_target_lineage_valid_and_fake_rejected():
    package, _ = _real_handoff_package()
    real_id = package.key_findings[0].finding_id
    validate_human_feedback(
        HumanFeedback(feedback_id="f1", run_id=package.run_id, target_type=FeedbackTargetType.FINDING, target_id=real_id, created_at=_now()),
        handoff_package=package,
    )
    with pytest.raises(FeedbackLineageError):
        validate_human_feedback(
            HumanFeedback(feedback_id="f2", run_id=package.run_id, target_type=FeedbackTargetType.FINDING, target_id="fake-finding", created_at=_now()),
            handoff_package=package,
        )


def test_recommendation_target_lineage_rejects_fake_id_even_when_no_candidates_exist():
    package, _ = _real_handoff_package()
    assert package.recommendation_candidates == []  # Phase 6A/6B never auto-generate one
    with pytest.raises(FeedbackLineageError):
        validate_human_feedback(
            HumanFeedback(feedback_id="f1", run_id=package.run_id, target_type=FeedbackTargetType.RECOMMENDATION, target_id="fake-rec", created_at=_now()),
            handoff_package=package,
        )


def test_run_and_synthesis_targets_never_raise():
    package, _ = _real_handoff_package()
    validate_human_feedback(HumanFeedback(feedback_id="f1", run_id=package.run_id, target_type=FeedbackTargetType.RUN, created_at=_now()), handoff_package=package)
    validate_human_feedback(HumanFeedback(feedback_id="f2", run_id=package.run_id, target_type=FeedbackTargetType.SYNTHESIS, created_at=_now()), handoff_package=package)
