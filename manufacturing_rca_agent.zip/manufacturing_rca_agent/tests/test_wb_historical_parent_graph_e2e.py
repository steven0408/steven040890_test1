"""Phase WB-3B item 55/56/70: full parent graph trace for historical
ANALYSIS and cross-source RCA requests -- `User -> Analyzer -> WB
ModuleTask -> ModuleGoal -> WBPlanningPolicy -> Objective ->
CapabilityResolver -> Skill -> Tool -> InMemory DataSource -> Evidence ->
Finding -> CompletionCheck`, through the real `build_phase2_graph`
composition (mirrors `test_wb_issue_parent_graph_e2e.py`'s own pattern
exactly). No test-side manual Skill selection, no `goal` injection
shortcut -- the real Analyzer -> ModuleTask -> ModuleGoal propagation
path is exercised end to end. All offline.
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.graph.graph import build_phase2_graph
from agent.graph.nodes.analyzer_llm import AnalyzerLLMService, make_analyzer_llm_node
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.llm.client import MockLLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.context.analyzer_context import AnalyzerContextBuilder
from agent.llm.prompts.analyzer import AnalyzerDecision, ModuleSelection
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.modules.wb.package import build_wb_module_package
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import ModuleStatus, RunTerminationStatus, TaskType
from agent.state.state import AgentState
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry

from .conftest import make_agent_state, make_module_registry

_FORBIDDEN_CAUSAL_WORDS = ("caused", "causes", "causing", "proves", "root cause", "directly caused", "due to", "because of")


def _make_wb_enabled_state(run_id: str, raw_text: str) -> AgentState:
    state = make_agent_state(run_id=run_id, raw_text=raw_text)
    return state.model_copy(update={"factory_context": state.factory_context.model_copy(update={"enabled_modules": ["WB"]})})


def _wb_module_runtime_config() -> ModuleRuntimeConfig:
    package = build_wb_module_package()
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner_capability = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=SkillRunner(tool_registry, ToolExecutionManager()))
    return ModuleRuntimeConfig(policy=WBPlanningPolicy(), capability=runner_capability, budget=package.budget)


def _analyzer_node_selecting_wb(task_type: TaskType, goal_statement: str):
    def responder(request):
        return AnalyzerDecision(
            task_type=task_type,
            selected_modules=[ModuleSelection(module_type="WB", priority=0.9, confidence=0.9, rationale="WB owns the historical/cross-source data relevant to this request.", goal_statement=goal_statement)],
            reasoning_summary="Mock decision.",
            confidence=0.9,
        )

    registry = make_module_registry()
    registry.register(build_wb_module_package().module_definition)
    router = LLMRouter(routes={"analyzer": LLMRouteConfig(route="analyzer", model="mock-analyzer")}, client=MockLLMClient(responder), usage_sink=InMemoryLLMUsageSink())
    service = AnalyzerLLMService(registry, AnalyzerContextBuilder(registry), router)
    return make_analyzer_llm_node(service)


# ============================================================================
# Item 55(1): Historical ANALYSIS parent E2E.
# "ASE07 最近一週投料是不是一直偏低？" -> Analyzer selects WB/ANALYSIS ->
# WBPlanningPolicy selects wb.issue.trend_analysis -> Evidence -> Finding
# (persistent low issue) -> COMPLETE -> READY_FOR_SYNTHESIS.
# ============================================================================


def test_parent_graph_historical_analysis_reaches_ready_for_synthesis():
    runtime = {"WB": _wb_module_runtime_config()}
    checkpointer = InMemorySaver()
    analyzer_node = _analyzer_node_selecting_wb(TaskType.ANALYSIS, "2026-08-12 ASE07 這週投料是不是一直偏低？")
    graph = build_phase2_graph(runtime, checkpointer, analyzer=analyzer_node)
    app = graph.compile(checkpointer=checkpointer)

    initial_state = _make_wb_enabled_state("wb-hist-analysis-parent", "ASE07 最近一週投料是不是一直偏低？")
    result = app.invoke(initial_state, config={"configurable": {"thread_id": "wb-hist-analysis-parent"}})
    final_state = AgentState.model_validate(result)

    wb = final_state.module_states["WB"]
    assert wb.status == ModuleStatus.COMPLETE
    assert len(wb.objective_history) == 1
    record = next(iter(wb.objective_history.values()))
    assert record.capability_key == "wb.issue.trend_analysis"
    assert record.target_ref.ref_id == "ASE07"

    finding = wb.findings[-1]
    assert finding.is_root_cause is False
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


# ============================================================================
# Item 55(2): Cross-source RCA parent E2E.
# "為什麼 ASE07 2026-08-12 Output 偏低？" -> real multi-round expected:
# Output current -> Output historical -> Issue historical -> relationship
# analysis -> final supported candidate/pattern. At minimum proves the
# cross-source Tool actually gets selected by the Planner through the
# real parent graph (not just the module subgraph tests).
# ============================================================================


def test_parent_graph_cross_source_rca_selects_relationship_capability():
    runtime = {"WB": _wb_module_runtime_config()}
    checkpointer = InMemorySaver()
    analyzer_node = _analyzer_node_selecting_wb(TaskType.RCA, "2026-08-12 ASE07 output 偏低 這週 trend root cause")
    graph = build_phase2_graph(runtime, checkpointer, analyzer=analyzer_node)
    app = graph.compile(checkpointer=checkpointer)

    initial_state = _make_wb_enabled_state("wb-hist-rca-parent", "為什麼 ASE07 2026-08-12 Output 偏低？")
    result = app.invoke(initial_state, config={"configurable": {"thread_id": "wb-hist-rca-parent"}})
    final_state = AgentState.model_validate(result)

    wb = final_state.module_states["WB"]
    assert wb.status == ModuleStatus.COMPLETE
    caps = [r.capability_key for r in wb.objective_history.values()]
    assert "wb.issue_output.relationship_analysis" in caps  # the cross-source Tool was actually selected by the real Planner
    assert caps[0] == "wb.output.comparison"  # symptom-first, never guessed straight to relationship

    finding = wb.findings[-1]
    assert finding.is_root_cause is False
    statement_lower = finding.statement.lower()
    for forbidden in _FORBIDDEN_CAUSAL_WORDS:
        assert forbidden not in statement_lower
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS
