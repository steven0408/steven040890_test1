"""Phase 7B item 4: InMemoryHumanFeedbackSink -- append-only, get/
list_for_run/list_for_target/latest_for_target.
"""
from datetime import datetime, timedelta, timezone

from agent.persistence.human_feedback import InMemoryHumanFeedbackSink
from agent.state.enums import FeedbackTargetType, HumanFeedbackThumbs
from agent.state.models import HumanFeedback


def _fb(feedback_id, run_id="run-1", target_type=FeedbackTargetType.RUN, target_id=None, offset_seconds=0, **kwargs):
    return HumanFeedback(
        feedback_id=feedback_id, run_id=run_id, target_type=target_type, target_id=target_id,
        created_at=datetime.now(timezone.utc) + timedelta(seconds=offset_seconds), **kwargs
    )


def test_record_and_list_for_run():
    sink = InMemoryHumanFeedbackSink()
    sink.record(_fb("f1"))
    sink.record(_fb("f2", run_id="run-2"))
    assert [f.feedback_id for f in sink.list_for_run("run-1")] == ["f1"]


def test_get_by_feedback_id():
    sink = InMemoryHumanFeedbackSink()
    sink.record(_fb("f1"))
    assert sink.get("f1").feedback_id == "f1"
    assert sink.get("does-not-exist") is None


def test_append_only_never_overwrites_a_prior_record():
    """The same human re-evaluating the same target adds a NEW record;
    the old one is never mutated or removed."""
    sink = InMemoryHumanFeedbackSink()
    sink.record(_fb("f1", target_type=FeedbackTargetType.ROOT_CAUSE, target_id="rc1", thumbs=HumanFeedbackThumbs.DOWN, offset_seconds=0))
    sink.record(_fb("f2", target_type=FeedbackTargetType.ROOT_CAUSE, target_id="rc1", thumbs=HumanFeedbackThumbs.UP, offset_seconds=10))

    history = sink.list_for_target("run-1", FeedbackTargetType.ROOT_CAUSE, "rc1")
    assert [f.feedback_id for f in history] == ["f1", "f2"]  # both preserved, in submission order
    assert sink.get("f1").thumbs == HumanFeedbackThumbs.DOWN  # unchanged


def test_latest_for_target_reads_most_recent_by_created_at():
    sink = InMemoryHumanFeedbackSink()
    sink.record(_fb("f1", target_type=FeedbackTargetType.ROOT_CAUSE, target_id="rc1", thumbs=HumanFeedbackThumbs.DOWN, offset_seconds=0))
    sink.record(_fb("f2", target_type=FeedbackTargetType.ROOT_CAUSE, target_id="rc1", thumbs=HumanFeedbackThumbs.UP, offset_seconds=10))

    latest = sink.latest_for_target("run-1", FeedbackTargetType.ROOT_CAUSE, "rc1")
    assert latest.feedback_id == "f2"


def test_latest_for_target_returns_none_when_no_feedback_exists():
    sink = InMemoryHumanFeedbackSink()
    assert sink.latest_for_target("run-1", FeedbackTargetType.ROOT_CAUSE, "rc1") is None


def test_list_for_target_distinguishes_different_targets_of_the_same_type():
    sink = InMemoryHumanFeedbackSink()
    sink.record(_fb("f1", target_type=FeedbackTargetType.FINDING, target_id="f-a"))
    sink.record(_fb("f2", target_type=FeedbackTargetType.FINDING, target_id="f-b"))
    assert [f.feedback_id for f in sink.list_for_target("run-1", FeedbackTargetType.FINDING, "f-a")] == ["f1"]
    assert [f.feedback_id for f in sink.list_for_target("run-1", FeedbackTargetType.FINDING, "f-b")] == ["f2"]
