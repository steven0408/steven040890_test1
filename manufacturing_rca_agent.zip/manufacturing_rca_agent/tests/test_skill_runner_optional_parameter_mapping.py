"""Phase WB-3F.2: generic SkillRunner regression for the new OPTIONAL scope-
filter parameter-mapping source (`objective.scope.filter_optional.<dim>`),
closing the exact blocker WB-3F.1 reported and stopped at rather than
worked around. Covers both the pure `_resolve_param()` unit level and a
full `SkillRunner.run()` execution against a real WB Tool, to prove the
`_MISSING` sentinel never leaks past `overlay` construction.
"""
from datetime import date

import pytest

from agent.domain.wb.datasource import InMemoryWBBankDataSource
from agent.domain.wb.models import WBBankRecord, WBBankStatus, WBSiteGroup
from agent.skills.models import SkillExecutionStatus
from agent.skills.runner import SkillParameterResolutionError, SkillRunner, _MISSING, _resolve_param
from agent.skills.wb.registration import register_wb_skills
from agent.skills.registry import SkillRegistry
from agent.state.enums import ObjectiveAction, TargetRefType
from agent.state.models import Objective, TargetRef
from agent.state.payload import PayloadRegistry
from agent.state.scope import ObjectiveScope, ScopeFilter, ScopeOperator
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry
from agent.tools.wb.registration import register_wb_tools

from .conftest import make_module_state, make_wb_datasources

_DATE = date(2026, 8, 12)


def _objective(*, plant: str | None = "ASE07", customer: str | None = None, group_by: list[str] | None = None) -> Objective:
    filters = []
    if plant is not None:
        filters.append(ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value=plant))
    if customer is not None:
        filters.append(ScopeFilter(dimension="customer", operator=ScopeOperator.EQ, value=customer))
    return Objective(
        objective_id="obj-1", description="d", action=ObjectiveAction.SUMMARIZE,
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id=plant or "ASE07"),
        scope=ObjectiveScope(filters=filters, group_by=group_by or []),
        expected_output="eo", priority_score=1.0,
    )


# ============================================================================
# 1-2: required semantics unchanged.
# ============================================================================


def test_required_filter_present_resolves():
    objective = _objective(plant="ASE07")
    assert _resolve_param("objective.scope.filter.plant", None, objective) == "ASE07"


def test_required_filter_missing_still_raises():
    objective = _objective(plant=None)
    with pytest.raises(SkillParameterResolutionError, match="no scope filter for dimension 'plant'"):
        _resolve_param("objective.scope.filter.plant", None, objective)


# ============================================================================
# 3-4: optional semantics -- present resolves, absent returns _MISSING.
# ============================================================================


def test_optional_filter_present_resolves():
    objective = _objective(customer="CUST_A")
    assert _resolve_param("objective.scope.filter_optional.customer", None, objective) == "CUST_A"


def test_optional_filter_missing_returns_missing_sentinel():
    objective = _objective(customer=None)
    assert _resolve_param("objective.scope.filter_optional.customer", None, objective) is _MISSING


# ============================================================================
# 6-7: optional scalar and optional list (group_by via the plain path,
# which is always safe here since `plant` is required -- see report §3).
# ============================================================================


def test_optional_scalar_dimension_never_confused_with_required_one():
    """A Skill can map the SAME dimension name as both required (plant)
    and, on a different Tool parameter, never conflate optional vs
    required resolution -- the prefix alone decides."""
    objective = _objective(plant="ASE07")
    assert _resolve_param("objective.scope.filter.plant", None, objective) == "ASE07"
    assert _resolve_param("objective.scope.filter_optional.plant", None, objective) == "ASE07"


def test_optional_list_group_by_resolves_via_plain_path():
    objective = _objective(group_by=["package"])
    assert _resolve_param("objective.scope.group_by", None, objective) == ["package"]


def test_empty_group_by_resolves_to_empty_list_not_missing():
    objective = _objective(group_by=[])
    result = _resolve_param("objective.scope.group_by", None, objective)
    assert result == []
    assert result is not _MISSING


# ============================================================================
# 8: invalid source syntax still raises.
# ============================================================================


def test_unsupported_source_prefix_raises():
    objective = _objective()
    with pytest.raises(SkillParameterResolutionError, match="unsupported parameter source"):
        _resolve_param("banana.nonsense", None, objective)


# ============================================================================
# 5/9/10: Tool default preserved, sentinel never reaches the Tool, existing
# behavior unchanged -- proven at the full SkillRunner.run() level against
# the REAL bank_status_summary Skill/Tool.
# ============================================================================


def _sync():
    from datetime import datetime

    return datetime(2026, 8, 12, 8, 0)


def _bank_records() -> list[WBBankRecord]:
    return [
        WBBankRecord(
            plant_id="ASE07", site_group=WBSiteGroup.A2, site_group_raw="A2", mother_batch_id=f"M{i}",
            customer_code="CUST_A" if i < 5 else "CUST_B", customer_sub_code=None, customer_group=None,
            device=None, package_code="PKG_X" if i % 2 == 0 else "PKG_Y", lead_count=None, wafer_size_inch=None,
            wafer_quantity=5, die_quantity=100, bank_status=WBBankStatus.MATERIAL_SHORTAGE if i < 3 else WBBankStatus.READY_TO_ISSUE,
            bank_status_raw="x", bank_entry_time=None, description=None, run_type=None, customer_run_type=None,
            unit_of_measure=None, source_sync_time=_sync(),
        )
        for i in range(10)
    ]


def _runner_and_skill():
    skill_registry = SkillRegistry()
    register_wb_skills(skill_registry)
    tool_registry = ToolRegistry()
    register_wb_tools(tool_registry, datasources=make_wb_datasources())
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    skill = skill_registry.get("wb.bank_status_summary")
    return runner, skill


def test_tool_default_survives_omission_end_to_end():
    """No customer filter supplied -- customer_code must NOT be forced to
    None in a way that breaks anything, and the Tool must see EVERY
    customer (its own default), not zero records."""
    runner, skill = _runner_and_skill()
    objective = _objective(plant="ASE07")  # no customer filter
    module_state = make_module_state(module_id="WB", module_type="WB")

    outcome = runner.run(skill, objective, module_state)
    assert outcome.result.status == SkillExecutionStatus.SUCCESS
    payload = PayloadRegistry.unpack(outcome.result.output_payload)
    # ASE07's own golden dataset total_count -- whatever it is, this call
    # must succeed and never crash on a missing optional parameter.
    assert payload.total_count >= 0


def test_optional_present_reaches_the_real_tool_and_changes_the_result():
    runner, skill = _runner_and_skill()
    objective_no_filter = _objective(plant="ASE07")
    objective_customer = _objective(plant="ASE07", customer="CUST_A")
    module_state = make_module_state(module_id="WB", module_type="WB")

    result_all = runner.run(skill, objective_no_filter, module_state)
    result_cust = runner.run(skill, objective_customer, module_state)
    assert result_all.result.status == SkillExecutionStatus.SUCCESS
    assert result_cust.result.status == SkillExecutionStatus.SUCCESS
    payload_all = PayloadRegistry.unpack(result_all.result.output_payload)
    payload_cust = PayloadRegistry.unpack(result_cust.result.output_payload)
    # narrower filter must never see MORE records than the unfiltered call
    assert payload_cust.total_count <= payload_all.total_count


def test_sentinel_never_reaches_tool_input_or_serialization():
    """Direct proof the _MISSING object itself never survives past
    overlay construction -- if it did, Pydantic validation of the Tool's
    input model would fail with a type error, not silently succeed."""
    runner, skill = _runner_and_skill()
    objective = _objective(plant="ASE07")  # no customer -- would resolve to _MISSING
    module_state = make_module_state(module_id="WB", module_type="WB")

    outcome = runner.run(skill, objective, module_state)
    assert outcome.result.status == SkillExecutionStatus.SUCCESS  # if _MISSING leaked into Pydantic validation, this would ERROR instead
    payload = PayloadRegistry.unpack(outcome.result.output_payload)
    assert "_Missing" not in payload.model_dump_json()
    assert "MISSING" not in payload.model_dump_json()


def test_existing_required_only_skill_behavior_is_byte_identical():
    """A Skill with ONLY required mappings (e.g. output_comparison's own
    production_date) must behave identically to before this phase --
    proven by the full offline suite staying green, reconfirmed narrowly
    here for wb.bank_status_summary's own required `plant` path."""
    runner, skill = _runner_and_skill()
    objective = _objective(plant="ASE07")
    module_state = make_module_state(module_id="WB", module_type="WB")
    outcome = runner.run(skill, objective, module_state)
    assert outcome.result.status == SkillExecutionStatus.SUCCESS
