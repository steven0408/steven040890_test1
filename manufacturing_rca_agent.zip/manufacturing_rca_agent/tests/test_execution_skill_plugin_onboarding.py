﻿"""Phase 5D-7: EXECUTION Skill plug-in onboarding proof. A brand-new Tool
implementation + ToolDefinition + a brand-new Skill markdown file (loaded
from tests/fixtures/dummy_skills/echo.md, not agent/skills/oee/ -- this is
a proof fixture, not a real domain capability) is registered and run
through the *real*, unmodified capability-executor node function
(agent.graph.nodes.module.capability_executor.make_capability_module_executor)
-- proving the plug-in mechanism, not domain correctness.

Nothing in Executor / SkillRunner / CapabilityResolver / Module Planner /
LangGraph topology was touched to make this fixture work.
"""
from pathlib import Path

from agent.capability.resolver import CapabilityResolver
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime, make_capability_module_executor
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.base import RCABaseModel
from agent.state.enums import ObjectiveAction, ObservationStatus, TargetRefType, TaskType
from agent.state.models import Objective, TargetRef
from agent.state.payload import PayloadRegistry
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.models import ExecutionType, ToolCategory, ToolDefinition, ToolExecutionRequest, ToolExecutionResult, ToolIOSchema, ToolSideEffect
from agent.tools.registry import ToolRegistry

from .conftest import make_budget, make_module_state

DUMMY_SKILLS_DIR = Path(__file__).resolve().parent / "fixtures" / "dummy_skills"


class DummyEchoInput(RCABaseModel):
    text: str


class DummyEchoOutput(RCABaseModel):
    text: str


PayloadRegistry.register("dummy.echo_input", DummyEchoInput)
PayloadRegistry.register("dummy.echo_output", DummyEchoOutput)


class DummyEchoTool:
    """A brand-new Tool -- nothing but the existing `Tool` Protocol
    (agent/tools/models.py) implemented fresh, same as any real Tool would
    be."""

    definition = ToolDefinition(
        tool_id="dummy_echo_tool", name="Dummy Echo Tool", description="Uppercases the input text.",
        category=ToolCategory.TRANSFORM, domains=[],
        input_schema=ToolIOSchema(model_name="DummyEchoInput"), output_schema=ToolIOSchema(model_name="DummyEchoOutput"),
        execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
        input_payload_type="dummy.echo_input", output_payload_type="dummy.echo_output",
    )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        parsed = DummyEchoInput.model_validate(request.parameters.data)
        output = DummyEchoOutput(text=parsed.text.upper())
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("dummy.echo_output", output), summary=f"echoed: {output.text}",
        )


def _dummy_runtime() -> ModuleCapabilityRuntime:
    tool_registry = ToolRegistry()
    tool_registry.register(DummyEchoTool())

    skill_registry = SkillRegistry()
    skill_registry.load_directory(DUMMY_SKILLS_DIR)
    skill_registry.validate_required_tools(tool_registry)  # must not raise -- proves the plug-in wiring is self-consistent

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    return ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)


def test_dummy_skill_loads_and_resolves_through_the_real_capability_resolver():
    runtime = _dummy_runtime()
    objective = Objective(
        objective_id="dummy-obj-1", description="hello dummy skill", action=ObjectiveAction.QUERY,
        target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="DUMMY"), expected_output="uppercased text", priority_score=1.0,
    )
    resolved = runtime.capability_resolver.resolve(objective, "DUMMY", TaskType.RCA)
    assert resolved.selected_skill.skill_id == "dummy.echo"
    assert [t.tool_id for t in resolved.resolved_tools] == ["dummy_echo_tool"]


def test_dummy_skill_runs_through_the_real_unmodified_capability_executor_node():
    runtime = _dummy_runtime()
    objective = Objective(
        objective_id="dummy-obj-1", description="hello dummy skill", action=ObjectiveAction.QUERY,
        target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="DUMMY"), expected_output="uppercased text", priority_score=1.0,
    )
    module_state = make_module_state(module_id="mod-dummy", module_type="DUMMY", run_id="run-dummy").model_copy(
        update={"current_objective": objective, "budget": make_budget()}
    )

    executor = make_capability_module_executor(runtime)  # the real, unmodified node function
    result = executor(module_state)

    assert result["observations"][0].status == ObservationStatus.SUCCESS
    assert result["evidence"][0].summary == "echoed: HELLO DUMMY SKILL"
    output = PayloadRegistry.unpack(result["evidence"][0].structured_payload)
    assert isinstance(output, DummyEchoOutput)
    assert output.text == "HELLO DUMMY SKILL"
