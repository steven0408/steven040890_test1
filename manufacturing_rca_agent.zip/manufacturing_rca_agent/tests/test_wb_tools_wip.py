"""Phase WB-2A item P: WB WIP Tools -- Query + Summarize + Hold analysis,
snapshot selection, hold_ratio empty-denominator handling, DataSource
exception mapping.
"""
from agent.domain.wb.datasource import InMemoryWBWIPDataSource
from agent.domain.wb.errors import WBDataSourceUnavailableError
from agent.domain.wb.models import WBLotStatus
from agent.domain.wb.synthetic import GOLDEN_DATE, SCENARIO_C_PLANT, WIP_SNAPSHOTS, build_wb_wip_records
from agent.domain.wb.tool_results import WBHoldAnalysisResult, WBWIPQueryResult, WBWIPSummaryResult, register_wb_tool_result_payloads
from agent.state.enums import ErrorType, ObservationStatus
from agent.state.payload import PayloadRegistry
from agent.tools.models import ToolExecutionRequest
from agent.tools.wb.wip_tools import (
    AnalyzeWBHoldTool,
    QueryWBWIPTool,
    SummarizeWBWIPTool,
    WBHoldAnalysisInput,
    WBWIPQueryInput,
    WBWIPSummaryInput,
    register_wb_wip_input_payloads,
)


def setup_module(module):
    register_wb_wip_input_payloads()
    register_wb_tool_result_payloads()


def _wip_datasource():
    records, snapshot_dates = build_wb_wip_records()
    return InMemoryWBWIPDataSource(records, snapshot_dates=snapshot_dates)


def _run(tool, payload_type, params):
    request = ToolExecutionRequest(
        tool_id=tool.definition.tool_id, parameters=PayloadRegistry.pack(payload_type, params),
        run_id="run-1", module_id="WB",
    )
    return tool.run(request)


# ============================================================================
# Query + snapshot selection
# ============================================================================


def test_query_filters_by_snapshot_date_plant_operation():
    tool = QueryWBWIPTool(_wip_datasource())
    result = _run(tool, "wb.wip_query_input", WBWIPQueryInput(snapshot_date=GOLDEN_DATE, plant_id=SCENARIO_C_PLANT, operation_id="2600"))
    payload = PayloadRegistry.unpack(result.payload)
    assert isinstance(payload, WBWIPQueryResult)
    assert len(payload.records) == 15
    assert all(r.plant_id == SCENARIO_C_PLANT and r.operation_id == "2600" for r in payload.records)


def test_latest_snapshot_only_default_collapses_to_one_sync_time():
    tool = QueryWBWIPTool(_wip_datasource())
    result = _run(tool, "wb.wip_query_input", WBWIPQueryInput(plant_id=SCENARIO_C_PLANT))
    payload = PayloadRegistry.unpack(result.payload)
    sync_times = {r.source_sync_time for r in payload.records}
    assert sync_times == {WIP_SNAPSHOTS[-1]}


def test_latest_snapshot_only_false_returns_all_snapshots():
    """Phase WB-3B: WIP_SNAPSHOTS extended from 2 to 14 (one per day
    across HISTORY_DAYS, for historical/recurrence analysis)."""
    tool = QueryWBWIPTool(_wip_datasource())
    result = _run(tool, "wb.wip_query_input", WBWIPQueryInput(plant_id=SCENARIO_C_PLANT, latest_snapshot_only=False))
    payload = PayloadRegistry.unpack(result.payload)
    sync_times = {r.source_sync_time for r in payload.records}
    assert len(sync_times) == len(WIP_SNAPSHOTS)
    assert len(payload.records) == 2 * 15 * len(WIP_SNAPSHOTS)  # 2 operations x 15 rows x N snapshots


def test_query_status_filter():
    tool = QueryWBWIPTool(_wip_datasource())
    result = _run(tool, "wb.wip_query_input", WBWIPQueryInput(snapshot_date=GOLDEN_DATE, plant_id=SCENARIO_C_PLANT, status=WBLotStatus.HOLD.value))
    payload = PayloadRegistry.unpack(result.payload)
    assert len(payload.records) == 22  # Golden Scenario C: 11 Hold per operation x 2 operations
    assert all(r.lot_status == WBLotStatus.HOLD for r in payload.records)


def test_query_result_limit_applies_after_filtering():
    tool = QueryWBWIPTool(_wip_datasource())
    result = _run(tool, "wb.wip_query_input", WBWIPQueryInput(snapshot_date=GOLDEN_DATE, plant_id=SCENARIO_C_PLANT, limit=5))
    payload = PayloadRegistry.unpack(result.payload)
    assert len(payload.records) == 5


def test_unknown_plant_returns_empty_not_error():
    tool = QueryWBWIPTool(_wip_datasource())
    result = _run(tool, "wb.wip_query_input", WBWIPQueryInput(snapshot_date=GOLDEN_DATE, plant_id="ASE99"))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.records == []
    assert payload.availability.is_empty is True
    assert result.status == ObservationStatus.SUCCESS


# ============================================================================
# Summarize
# ============================================================================


def test_summarize_totals_and_grouping():
    tool = SummarizeWBWIPTool(_wip_datasource())
    result = _run(tool, "wb.wip_summary_input", WBWIPSummaryInput(snapshot_date=GOLDEN_DATE, plant_id=SCENARIO_C_PLANT))
    payload = PayloadRegistry.unpack(result.payload)
    assert isinstance(payload, WBWIPSummaryResult)
    assert payload.lot_count == 30  # 2 operations x 15
    assert payload.total_quantity > 0
    assert list(payload.by_status.keys()) == sorted(payload.by_status.keys())
    assert list(payload.by_operation.keys()) == sorted(payload.by_operation.keys())


# ============================================================================
# Hold analysis -- Golden Scenario C + empty-denominator handling (item L)
# ============================================================================


def test_hold_ratio_golden_scenario_c():
    tool = AnalyzeWBHoldTool(_wip_datasource())
    result = _run(tool, "wb.hold_analysis_input", WBHoldAnalysisInput(snapshot_date=GOLDEN_DATE, plant_id=SCENARIO_C_PLANT))
    payload = PayloadRegistry.unpack(result.payload)
    assert isinstance(payload, WBHoldAnalysisResult)
    assert payload.total_lot_count == 30
    assert payload.hold_lot_count == 22
    assert payload.hold_ratio == 22 / 30


def test_hold_ratio_is_none_not_zero_when_no_lots_in_scope():
    tool = AnalyzeWBHoldTool(_wip_datasource())
    result = _run(tool, "wb.hold_analysis_input", WBHoldAnalysisInput(snapshot_date=GOLDEN_DATE, plant_id="ASE99"))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.total_lot_count == 0
    assert payload.hold_lot_count == 0
    assert payload.hold_ratio is None  # never silently 0.0
    assert result.status == ObservationStatus.SUCCESS


def test_hold_analysis_is_descriptive_only_no_causal_fields():
    """Item C3/J: the result model must never carry a root-cause verdict
    field -- only counts/ratios/groupings."""
    fields = set(WBHoldAnalysisResult.model_fields.keys())
    assert not any("cause" in f.lower() or "reason" in f.lower() for f in fields)


def test_hold_grouping_excludes_non_hold_lots():
    tool = AnalyzeWBHoldTool(_wip_datasource())
    result = _run(tool, "wb.hold_analysis_input", WBHoldAnalysisInput(snapshot_date=GOLDEN_DATE, plant_id=SCENARIO_C_PLANT))
    payload = PayloadRegistry.unpack(result.payload)
    assert sum(payload.by_operation.values()) == payload.hold_lot_count


# ============================================================================
# DataSource exception mapping
# ============================================================================


class _BrokenWIPDataSource:
    def list_wip(self, *, snapshot_date=None, limit=5000):
        raise WBDataSourceUnavailableError("wip source down")

    def freshness(self):
        from agent.domain.wb.models import WB_WIP_FRESHNESS

        return WB_WIP_FRESHNESS


def test_datasource_error_maps_to_error_result():
    tool = QueryWBWIPTool(_BrokenWIPDataSource())
    result = _run(tool, "wb.wip_query_input", WBWIPQueryInput())
    assert result.status == ObservationStatus.ERROR
    assert result.error_type == ErrorType.DATA_NOT_FOUND
