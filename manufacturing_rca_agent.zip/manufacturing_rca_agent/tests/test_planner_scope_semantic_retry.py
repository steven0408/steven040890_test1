"""Phase WB-3F.3 item 9: offline, MockLLM-driven proof that the EXISTING
retry mechanism (LLMRouter retry -> LLMPlanningPolicy fallback, unchanged
this phase) already handles "Planner proposed the right capability but
omitted a REQUIRED scope dimension" correctly -- no new validator, no new
WB-specific parsing. `required_scope_dimensions` is a property of the
capability (already enforced by `validate_planner_decision`'s existing
`_validate_scope`), not a claim about what the user "explicitly" asked for
(that harder, structurally-unavailable problem is reported separately in
the completion report, item 6/9).
"""
from agent.llm.client import MockLLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
from agent.llm.context.evidence_selector import DeterministicEvidenceSelector
from agent.llm.context.planner_context import PlannerContextBuilder
from agent.llm.models import DecisionSource
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.planning.decision_audit import InMemoryPlannerDecisionAuditSink
from agent.planning.policies.llm import LLMPlanningPolicy
from agent.planning.policies.wb import WBPlanningPolicy
from agent.state.enums import EntityAnalysisStatus, ObjectiveAction, TargetRefType, TaskType
from agent.state.models import EntityState, ModuleTask, TargetRef

from .test_wb_reasoning_llm_live import _wb_registries, _bootstrap_module_state, _budget


def test_missing_required_scope_dimension_triggers_retry_then_succeeds():
    package, skill_registry, tool_registry = _wb_registries()
    usage_sink = InMemoryLLMUsageSink()
    call_count = {"n": 0}

    def responder(request):
        call_count["n"] += 1
        if call_count["n"] == 1:
            # correct capability, but the REQUIRED `plant` scope dimension is missing
            return PlannerDecision(
                decision=PlannerDecisionType.DISPATCH,
                next_objective=ObjectiveProposal(
                    action=ObjectiveAction.SUMMARIZE, capability_key="wb.bank.status_summary",
                    target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="ASE07"),
                    scope=None, description="d", expected_output="eo",
                ),
                priority=1.0, rationale_summary="first attempt, no scope",
            )
        # second attempt: same capability, required dimension now present
        from agent.state.scope import ObjectiveScope, ScopeFilter, ScopeOperator

        return PlannerDecision(
            decision=PlannerDecisionType.DISPATCH,
            next_objective=ObjectiveProposal(
                action=ObjectiveAction.SUMMARIZE, capability_key="wb.bank.status_summary",
                target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="ASE07"),
                scope=ObjectiveScope(filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE07")]),
                description="d", expected_output="eo",
            ),
            priority=1.0, rationale_summary="second attempt, scope corrected",
        )

    router = LLMRouter(
        routes={"planner": LLMRouteConfig(route="planner", model="mock-model", max_retries=1)},
        client=MockLLMClient(responder), usage_sink=usage_sink,
    )
    context_builder = PlannerContextBuilder(DeterministicEvidenceSelector(), DeterministicCapabilityRetriever(skill_registry))
    decision_sink = InMemoryPlannerDecisionAuditSink()
    policy = LLMPlanningPolicy(WBPlanningPolicy(), context_builder, router, skill_registry, decision_audit_sink=decision_sink)

    module_state = _bootstrap_module_state(TaskType.INFORMATION, "ASE07 的 BANK 狀況", "run-retry", _budget())
    entity_states = {"ASE07": EntityState(entity_id="ASE07", entity_type="PLANT", status=EntityAnalysisStatus.INVESTIGATING, current_tree_node_id="n1", priority_score=0.9)}
    module_state = module_state.model_copy(update={"entity_states": entity_states})
    objective = policy.propose_next_objective(module_state)

    assert call_count["n"] == 2  # first attempt failed semantic validation, retried once
    assert objective is not None
    assert objective.capability_key == "wb.bank.status_summary"
    assert objective.scope is not None and any(f.dimension == "plant" for f in objective.scope.filters)

    record = decision_sink.list_for_run("run-retry")[0]
    assert record.source == DecisionSource.LLM  # NOT fallback -- the retry itself succeeded, no WBPlanningPolicy branch was needed
