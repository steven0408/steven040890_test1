"""Phase WB-2D edge cases: DataSource-unavailable alternative path (item
19/50), budget exhaustion semantics (item 20/49), and entity/scope
validation extended to RCA (item 33's G/H equivalents for TaskType.RCA).
All via the real Module ReAct Subgraph -- no hand-built ModuleState/
Evidence shortcuts, so the ERROR path is genuinely exercised through a
real Tool catching a real DataSource exception. All offline.
"""
from datetime import date

import pytest
from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.domain.wb.datasource import (
    InMemoryWBBankDataSource,
    InMemoryWBIssueDataSource,
    InMemoryWBPlantOEEDataSource,
    InMemoryWBStageOutputDataSource,
    InMemoryWBWIPDataSource,
)
from agent.domain.wb.errors import WBDataSourceUnavailableError
from agent.domain.wb.synthetic import (
    build_wb_bank_records,
    build_wb_issue_records,
    build_wb_plant_oee_records,
    build_wb_stage_output_records,
    build_wb_wip_records,
)
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.modules.wb.package import build_wb_module_package
from agent.planning.policies.llm import PlannerSemanticValidationError, validate_planner_decision
from agent.planning.policies.wb import WBPlanningPolicy, build_wb_initial_entity_states
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import ModuleStatus, ObjectiveAction, TargetRefType, TaskType
from agent.state.models import Budget, ModuleState, ModuleTask, TargetRef
from agent.state.scope import ObjectiveScope, ScopeFilter, ScopeOperator, TimeScope, TimeScopeKind
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry
from agent.tools.wb.registration import WBDataSources

from .conftest import make_module_state


class _FailingWBBankDataSource:
    """A WBBankDataSource-shaped test double that always fails -- proves
    the RCA Planner's alternative-path behavior (item 50) against a REAL
    Tool catching a REAL DataSource exception, not a hand-built Observation."""

    def list_bank(self, *, snapshot_date: date | None = None):
        raise WBDataSourceUnavailableError("simulated WB Bank outage")

    def freshness(self):
        raise WBDataSourceUnavailableError("simulated WB Bank outage")


def _wb_module_runtime(*, bank_unavailable: bool = False, budget: Budget | None = None):
    bank_records, bank_snapshot_dates = build_wb_bank_records()
    wip_records, wip_snapshot_dates = build_wb_wip_records()

    datasources = WBDataSources(
        oee=InMemoryWBPlantOEEDataSource(build_wb_plant_oee_records()),
        bank=_FailingWBBankDataSource() if bank_unavailable else InMemoryWBBankDataSource(bank_records, snapshot_dates=bank_snapshot_dates),
        wip=InMemoryWBWIPDataSource(wip_records, snapshot_dates=wip_snapshot_dates),
        output=InMemoryWBStageOutputDataSource(build_wb_stage_output_records()),
        issue=InMemoryWBIssueDataSource(build_wb_issue_records()),
    )
    package = build_wb_module_package(datasources=datasources)
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    runtime = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)
    return package, runtime


def _run(thread_id: str, statement: str, *, bank_unavailable: bool = False, budget: Budget | None = None) -> ModuleState:
    package, runtime = _wb_module_runtime(bank_unavailable=bank_unavailable)
    policy = WBPlanningPolicy()
    graph = build_module_react_subgraph(policy, capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id="WB", module_type="WB", reason=statement, goal_statement=statement, confidence=0.9, priority=0.9, task_type=TaskType.RCA)
    initial = build_initial_module_state(task, budget or package.budget, run_id=f"run-{thread_id}", task_type=TaskType.RCA)
    result = app.invoke(initial, config={"configurable": {"thread_id": thread_id}})
    return ModuleState.model_validate(result)


# ============================================================================
# Item 19/50: DataSource unavailable -- alternative path, not immediate FAILED
# ============================================================================


def test_bank_datasource_unavailable_falls_through_to_wip_then_oee():
    """ASE07's low Output would normally stop at Bank (Golden Scenario B).
    With Bank genuinely unavailable, the Planner must not retry it and
    must not give up -- it should fall through to WIP, then OEE, exactly
    like the ASE01 contradiction case (Bank NORMAL) does."""
    final_state = _run("rca-bank-down", "2026-08-12 ASE07 output 偏低 root cause", bank_unavailable=True)

    chain = [r.capability_key for r in final_state.objective_history.values()]
    assert chain[0] == "wb.output.comparison"
    assert "wb.bank.status_summary" in chain  # attempted (and failed) -- never silently skipped
    assert chain.count("wb.bank.status_summary") == 1  # never retried
    assert "wb.wip.hold_analysis" in chain  # alternative path was tried

    # ASE07's WIP is normal too (only its BANK is the golden-scenario
    # signal) -- so the chain should continue to OEE, which is also
    # normal for ASE07 (Golden B's own "despite normal OEE" framing) --
    # ending exhausted, never a fabricated cause.
    assert final_state.status == ModuleStatus.COMPLETE
    finding = final_state.findings[-1]
    assert finding.is_root_cause is False
    assert "material shortage" not in finding.statement.lower()  # the failed source is never cited as a finding


def test_bank_unavailable_never_immediately_fails_while_other_paths_remain():
    final_state = _run("rca-bank-down-status", "2026-08-12 ASE07 output 偏低 root cause", bank_unavailable=True)
    assert final_state.status != ModuleStatus.FAILED


# ============================================================================
# Item 20/49: budget exhaustion semantics
# ============================================================================


def test_budget_exhaustion_mid_investigation_yields_partial():
    """ASE01's Output-RCA needs 4 rounds to reach its OEE candidate
    (Golden dynamic-replanning case). A budget of 2 cuts it off mid-chain
    -- PARTIAL is expected (findings already exist from the rounds that
    did complete), never FAILED, and never a fabricated final answer."""
    tight_budget = Budget(max_steps=2, max_tool_calls=2, max_depth_per_entity=1)
    final_state = _run("rca-budget-partial", "2026-08-12 ASE01 output 偏低 root cause", budget=tight_budget)

    assert len(final_state.objective_history) == 2
    assert final_state.status == ModuleStatus.PARTIAL
    assert len(final_state.findings) >= 1


def test_budget_exhaustion_with_zero_findings_yields_failed():
    """Generic completion semantics (module_completion_check.py, untouched
    this phase): `FAILED if not module_state.findings`. A budget of 0
    steps means Planner never even gets to dispatch the first symptom
    check, so no observation/Evidence/Finding can exist at all."""
    zero_budget = Budget(max_steps=0, max_tool_calls=0, max_depth_per_entity=1)
    final_state = _run("rca-budget-failed", "2026-08-12 ASE01 output 偏低 root cause", budget=zero_budget)

    assert len(final_state.objective_history) == 0
    assert len(final_state.findings) == 0
    assert final_state.status == ModuleStatus.FAILED


# ============================================================================
# Entity/scope validation extended to RCA (mirrors WB-2C Cases G/H, this
# time with task_type=RCA rather than ANALYSIS)
# ============================================================================


def _wb_registries():
    package = build_wb_module_package()
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    return skill_registry, tool_registry


def test_rca_invalid_entity_rejected_before_tool_execution():
    skill_registry, _ = _wb_registries()
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    module_state = module_state.model_copy(update={
        "goal": module_state.goal.model_copy(update={"task_type": TaskType.RCA}),
        "entity_states": build_wb_initial_entity_states(),  # ASE99 deliberately never seeded
    })

    proposal = ObjectiveProposal(
        action=ObjectiveAction.SUMMARIZE, capability_key="wb.oee.plant_status",
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="ASE99"),
        scope=ObjectiveScope(time=TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, date=date(2026, 8, 12)), filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE99")]),
        description="invalid plant", expected_output="status",
    )
    decision = PlannerDecision(decision=PlannerDecisionType.DISPATCH, next_objective=proposal, priority=1.0, rationale_summary="x")

    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=module_state, task_type=TaskType.RCA, skill_registry=skill_registry)


def test_rca_missing_required_scope_rejected_before_tool_execution():
    skill_registry, tool_registry = _wb_registries()
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    module_state = module_state.model_copy(update={
        "goal": module_state.goal.model_copy(update={"task_type": TaskType.RCA}),
        "entity_states": build_wb_initial_entity_states(),
    })

    proposal = ObjectiveProposal(
        action=ObjectiveAction.SUMMARIZE, capability_key="wb.oee.plant_status",
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="ASE01"),
        scope=None,  # missing production_date + plant filter
        description="missing scope", expected_output="status",
    )
    decision = PlannerDecision(decision=PlannerDecisionType.DISPATCH, next_objective=proposal, priority=1.0, rationale_summary="x")

    from agent.tools.execution_manager import InMemoryToolCallAuditSink

    audit_sink = InMemoryToolCallAuditSink()
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=module_state, task_type=TaskType.RCA, skill_registry=skill_registry)
    assert len(audit_sink.list_for_run(module_state.run_id)) == 0  # ToolExecutionManager never touched
