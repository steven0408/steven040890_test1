"""Phase WB-2B.1: SkillRunner execution for WB Skills -- scope-based
parameter mapping (proving runtime scope, never a hardcoded plant/date),
Golden Scenarios A-E through the real Skill layer, and the 3-way
distinction required by item 13: (A) valid data, (B) valid query / zero
records, (C) DataSource/tool execution failure.
"""
from agent.domain.wb.errors import WBDataSourceUnavailableError
from agent.domain.wb.synthetic import (
    GOLDEN_DATE,
    SCENARIO_A_PLANT,
    SCENARIO_B_PLANT,
    SCENARIO_C_PLANT,
    SCENARIO_D_PLANT,
    SCENARIO_E_PLANT,
)
from agent.domain.wb.tool_results import WBHoldAnalysisResult, WBOEELossAnalysisResult
from agent.skills.models import SkillExecutionStatus
from agent.skills.runner import SkillRunner
from agent.skills.wb.registration import register_wb_skills
from agent.skills.registry import SkillRegistry
from agent.state.enums import ErrorType, ObjectiveAction, TargetRefType
from agent.state.models import Objective, TargetRef
from agent.state.payload import PayloadRegistry
from agent.state.scope import ObjectiveScope, ScopeFilter, ScopeOperator, TimeScope, TimeScopeKind
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry
from agent.tools.wb.registration import WBDataSources, register_wb_tools

from .conftest import make_module_state, make_wb_datasources


def _skill_registry():
    registry = SkillRegistry()
    register_wb_skills(registry)
    return registry


def _tool_registry():
    registry = ToolRegistry()
    register_wb_tools(registry, datasources=make_wb_datasources())
    return registry


def _entity_objective(objective_id: str, plant: str, *, time_kind: TimeScopeKind, date_value) -> Objective:
    return Objective(
        objective_id=objective_id, description=f"scoped to {plant}", action=ObjectiveAction.ANALYZE,
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id=plant),
        scope=ObjectiveScope(
            time=TimeScope(kind=time_kind, date=date_value),
            filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value=plant)],
        ),
        expected_output="status", priority_score=1.0,
    )


def _module_objective_with_date(objective_id: str, *, time_kind: TimeScopeKind, date_value) -> Objective:
    return Objective(
        objective_id=objective_id, description="module-wide", action=ObjectiveAction.COMPARE,
        target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="WB"),
        scope=ObjectiveScope(time=TimeScope(kind=time_kind, date=date_value)),
        expected_output="status", priority_score=1.0,
    )


# ============================================================================
# Parameter mapping -- runtime scope, never hardcoded
# ============================================================================


def test_oee_plant_status_scopes_to_the_objectives_own_target_not_hardcoded():
    """The Skill markdown contains no literal plant id or date -- two
    different Objectives against the exact same Skill must yield two
    different, correctly-scoped results."""
    skill_registry, tool_registry = _skill_registry(), _tool_registry()
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    skill = skill_registry.get("wb.oee_plant_status")

    outcome_a = runner.run(skill, _entity_objective("obj-a", SCENARIO_A_PLANT, time_kind=TimeScopeKind.PRODUCTION_DATE, date_value=GOLDEN_DATE), module_state)
    outcome_c = runner.run(skill, _entity_objective("obj-c", SCENARIO_C_PLANT, time_kind=TimeScopeKind.PRODUCTION_DATE, date_value=GOLDEN_DATE), module_state)

    payload_a = PayloadRegistry.unpack(outcome_a.result.output_payload)
    payload_c = PayloadRegistry.unpack(outcome_c.result.output_payload)
    assert {r.plant_id for r in payload_a.ranking} == {SCENARIO_A_PLANT}
    assert {r.plant_id for r in payload_c.ranking} == {SCENARIO_C_PLANT}


def test_oee_status_analysis_is_module_wide_never_scopes_to_one_plant():
    skill_registry, tool_registry = _skill_registry(), _tool_registry()
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    skill = skill_registry.get("wb.oee_status_analysis")

    outcome = runner.run(skill, _module_objective_with_date("obj-1", time_kind=TimeScopeKind.PRODUCTION_DATE, date_value=GOLDEN_DATE), module_state)
    payload = PayloadRegistry.unpack(outcome.result.output_payload)
    assert len({r.plant_id for r in payload.ranking}) > 1  # ranks every plant, not just one


def test_bank_status_summary_scopes_to_the_objectives_own_target():
    skill_registry, tool_registry = _skill_registry(), _tool_registry()
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    skill = skill_registry.get("wb.bank_status_summary")

    outcome = runner.run(skill, _entity_objective("obj-1", SCENARIO_B_PLANT, time_kind=TimeScopeKind.SNAPSHOT_DATE, date_value=GOLDEN_DATE), module_state)
    payload = PayloadRegistry.unpack(outcome.result.output_payload)
    assert set(payload.by_plant.keys()) == {SCENARIO_B_PLANT}


def test_module_wide_output_comparison_never_scopes_to_one_plant():
    skill_registry, tool_registry = _skill_registry(), _tool_registry()
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    skill = skill_registry.get("wb.output_comparison")

    outcome = runner.run(skill, _module_objective_with_date("obj-1", time_kind=TimeScopeKind.PRODUCTION_DATE, date_value=GOLDEN_DATE), module_state)
    payload = PayloadRegistry.unpack(outcome.result.output_payload)
    assert len({e.plant_id for e in payload.comparison}) > 1  # ranks every plant, not just one


# ============================================================================
# Golden Scenarios A-E through the real Skill layer
# ============================================================================


def test_golden_scenario_a_via_oee_plant_status_skill():
    skill_registry, tool_registry = _skill_registry(), _tool_registry()
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    objective = _entity_objective("obj-a", SCENARIO_A_PLANT, time_kind=TimeScopeKind.PRODUCTION_DATE, date_value=GOLDEN_DATE)
    outcome = runner.run(skill_registry.get("wb.oee_plant_status"), objective, module_state)
    payload = PayloadRegistry.unpack(outcome.result.output_payload)
    assert isinstance(payload, WBOEELossAnalysisResult)
    worst = payload.ranking[0]
    assert worst.plant_id == SCENARIO_A_PLANT
    assert worst.oee == 58.0
    assert worst.dominant_loss_category == "downtime"


def test_golden_scenario_b_via_bank_status_summary_skill():
    skill_registry, tool_registry = _skill_registry(), _tool_registry()
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    objective = _entity_objective("obj-b", SCENARIO_B_PLANT, time_kind=TimeScopeKind.SNAPSHOT_DATE, date_value=GOLDEN_DATE)
    outcome = runner.run(skill_registry.get("wb.bank_status_summary"), objective, module_state)
    payload = PayloadRegistry.unpack(outcome.result.output_payload)
    counts = {c.status.value: c.count for c in payload.by_status}
    assert payload.total_count == 10
    assert counts["material_shortage"] == 7


def test_golden_scenario_c_via_wip_hold_analysis_skill():
    skill_registry, tool_registry = _skill_registry(), _tool_registry()
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    objective = _entity_objective("obj-c", SCENARIO_C_PLANT, time_kind=TimeScopeKind.SNAPSHOT_DATE, date_value=GOLDEN_DATE)
    outcome = runner.run(skill_registry.get("wb.wip_hold_analysis"), objective, module_state)
    payload = PayloadRegistry.unpack(outcome.result.output_payload)
    assert isinstance(payload, WBHoldAnalysisResult)
    assert payload.total_lot_count == 30
    assert payload.hold_lot_count == 22
    assert abs(payload.hold_ratio - (22 / 30)) < 1e-9


def test_golden_scenario_d_normal_control_not_flagged_as_root_cause():
    skill_registry, tool_registry = _skill_registry(), _tool_registry()
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    objective = _entity_objective("obj-d", SCENARIO_D_PLANT, time_kind=TimeScopeKind.PRODUCTION_DATE, date_value=GOLDEN_DATE)
    outcome = runner.run(skill_registry.get("wb.oee_plant_status"), objective, module_state)
    payload = PayloadRegistry.unpack(outcome.result.output_payload)
    assert all(r.oee == 85.0 for r in payload.ranking)  # baseline, no degradation
    assert not any("cause" in field.lower() for field in type(payload.ranking[0]).model_fields)


def test_golden_scenario_e_missing_oee_stays_absent_not_zero_through_skill_layer():
    skill_registry, tool_registry = _skill_registry(), _tool_registry()
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    objective = _entity_objective("obj-e", SCENARIO_E_PLANT, time_kind=TimeScopeKind.PRODUCTION_DATE, date_value=GOLDEN_DATE)
    outcome = runner.run(skill_registry.get("wb.oee_plant_status"), objective, module_state)
    payload = PayloadRegistry.unpack(outcome.result.output_payload)

    assert payload.ranking == []  # no fabricated golden-day row -- true absence
    assert payload.availability.is_empty is True
    assert outcome.result.status == SkillExecutionStatus.SUCCESS  # absence is not an error


# ============================================================================
# Item 13: A (valid data) / B (valid query, zero records) / C (execution failure)
# ============================================================================


def test_a_valid_data_is_success_with_populated_result():
    skill_registry, tool_registry = _skill_registry(), _tool_registry()
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    objective = _entity_objective("obj-1", SCENARIO_B_PLANT, time_kind=TimeScopeKind.SNAPSHOT_DATE, date_value=GOLDEN_DATE)
    outcome = runner.run(skill_registry.get("wb.bank_status_summary"), objective, module_state)
    assert outcome.result.status == SkillExecutionStatus.SUCCESS
    assert outcome.result.error is None
    payload = PayloadRegistry.unpack(outcome.result.output_payload)
    assert payload.total_count > 0


def test_b_valid_query_zero_records_is_success_not_error():
    """A plant that genuinely doesn't exist in the dataset -- SUCCESS with
    an empty, non-fabricated result, never an ERROR."""
    skill_registry, tool_registry = _skill_registry(), _tool_registry()
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    objective = _entity_objective("obj-2", "ASE99", time_kind=TimeScopeKind.SNAPSHOT_DATE, date_value=GOLDEN_DATE)
    outcome = runner.run(skill_registry.get("wb.bank_status_summary"), objective, module_state)
    assert outcome.result.status == SkillExecutionStatus.SUCCESS
    assert outcome.result.error is None
    payload = PayloadRegistry.unpack(outcome.result.output_payload)
    assert payload.total_count == 0
    assert payload.availability.is_empty is True


class _BrokenBankDataSource:
    def list_bank(self, *, snapshot_date=None):
        raise WBDataSourceUnavailableError("bank source unreachable")

    def freshness(self):
        from agent.domain.wb.models import WB_BANK_FRESHNESS

        return WB_BANK_FRESHNESS


def test_c_datasource_execution_failure_is_error_distinct_from_b():
    """The SAME Skill (`wb.bank_status_summary`) that returns SUCCESS+empty
    in test B above must return ERROR here -- proving the Harness can tell
    "legitimately no data" apart from "couldn't get data at all"."""
    skill_registry = _skill_registry()
    tool_registry = ToolRegistry()
    datasources = make_wb_datasources()
    broken = WBDataSources(oee=datasources.oee, bank=_BrokenBankDataSource(), wip=datasources.wip, output=datasources.output, issue=datasources.issue)
    register_wb_tools(tool_registry, datasources=broken)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    objective = _entity_objective("obj-3", SCENARIO_B_PLANT, time_kind=TimeScopeKind.SNAPSHOT_DATE, date_value=GOLDEN_DATE)

    outcome = runner.run(skill_registry.get("wb.bank_status_summary"), objective, module_state)

    assert outcome.result.status == SkillExecutionStatus.ERROR
    assert outcome.result.error is not None
    assert outcome.result.error.error_type == ErrorType.DATA_NOT_FOUND  # see report item 13's taxonomy review
    assert outcome.result.output_payload is None  # no partial/fabricated payload on failure


# ============================================================================
# Case 5 (item U) at the SkillRunner level: missing required scope
# ============================================================================


def test_missing_required_scope_returns_typed_error_not_a_crash():
    """`wb.oee_plant_status` requires BOTH production_date and plant --
    an Objective with no scope at all must fail as a typed
    SkillExecutionResult.ERROR, never an unhandled AttributeError."""
    skill_registry, tool_registry = _skill_registry(), _tool_registry()
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    objective = Objective(
        objective_id="obj-nodate", description="missing scope", action=ObjectiveAction.ANALYZE,
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id=SCENARIO_A_PLANT),
        expected_output="status", priority_score=1.0,
        # scope intentionally omitted
    )

    outcome = runner.run(skill_registry.get("wb.oee_plant_status"), objective, module_state)

    assert outcome.result.status == SkillExecutionStatus.ERROR
    assert outcome.result.error.error_type == ErrorType.INVALID_QUERY
