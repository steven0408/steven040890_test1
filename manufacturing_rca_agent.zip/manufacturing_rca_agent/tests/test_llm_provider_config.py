"""Phase WB-3E: `LLMProviderConfig`/`build_llm_client` -- the env-driven
provider-selection layer in front of `bootstrap_runtime`. Fully offline:
no network call, no real API key needed (secrets are read from
whatever-named env var the config points at, but never validated against
a real provider here -- that's the live smoke tests' job).
"""
import os

import pytest

from agent.llm.client import MockLLMClient
from agent.llm.providers.provider_config import LLMProviderConfig, LLMProviderConfigError, build_llm_client

pytest.importorskip("openai")
pytest.importorskip("anthropic")


@pytest.fixture(autouse=True)
def _clean_llm_env(monkeypatch):
    """Every LLM-provider-related env var this module touches, cleared
    before each test -- no test may accidentally observe a leftover
    value from another test or the outer environment."""
    for name in (
        "LLM_PROVIDER", "OPENAI_MODEL", "OPENAI_API_KEY", "OPENAI_TEMPERATURE", "OPENAI_MAX_TOKENS",
        "INTERNAL_LLM_MODEL", "INTERNAL_LLM_BASE_URL", "INTERNAL_LLM_API_KEY", "INTERNAL_LLM_TEMPERATURE",
        "INTERNAL_LLM_USE_TOOL_CALLING", "ANTHROPIC_MODEL", "ANTHROPIC_API_KEY",
    ):
        monkeypatch.delenv(name, raising=False)


# ============================================================================
# from_env() -- no implicit default provider
# ============================================================================


def test_unset_llm_provider_raises_config_error_never_silently_defaults():
    with pytest.raises(LLMProviderConfigError):
        LLMProviderConfig.from_env()


def test_unrecognized_provider_raises_config_error():
    os.environ["LLM_PROVIDER"] = "not_a_real_provider"
    with pytest.raises(LLMProviderConfigError):
        LLMProviderConfig.from_env()
    del os.environ["LLM_PROVIDER"]


# ============================================================================
# OpenAI Cloud profile
# ============================================================================


def test_openai_cloud_profile_from_env(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "openai")
    monkeypatch.setenv("OPENAI_MODEL", "gpt-4o-mini")
    monkeypatch.setenv("OPENAI_API_KEY", "sk-should-never-appear-in-config-object")

    config = LLMProviderConfig.from_env()

    assert config.provider == "openai"
    assert config.model == "gpt-4o-mini"
    assert config.base_url_env is None  # OpenAI Cloud: SDK's own default, no override
    assert config.api_key_env == "OPENAI_API_KEY"
    # the config object NEVER carries the literal key value -- only the env var NAME
    assert "sk-should-never-appear-in-config-object" not in config.model_dump_json()


def test_openai_cloud_missing_model_raises_config_error(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "openai")
    monkeypatch.setenv("OPENAI_API_KEY", "sk-x")
    with pytest.raises(LLMProviderConfigError):
        LLMProviderConfig.from_env()


def test_openai_cloud_temperature_and_max_tokens_configurable(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "openai")
    monkeypatch.setenv("OPENAI_MODEL", "gpt-4o-mini")
    monkeypatch.setenv("OPENAI_API_KEY", "sk-x")
    monkeypatch.setenv("OPENAI_TEMPERATURE", "0.3")
    monkeypatch.setenv("OPENAI_MAX_TOKENS", "1500")

    config = LLMProviderConfig.from_env()
    assert config.temperature == 0.3
    assert config.max_tokens == 1500


# ============================================================================
# Internal OpenAI-compatible profile (item BC's own reference: gpt-oss-120b)
# ============================================================================


def test_internal_openai_profile_from_env(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "internal_openai")
    monkeypatch.setenv("INTERNAL_LLM_MODEL", "/model/gpt-oss-120b")
    monkeypatch.setenv("INTERNAL_LLM_BASE_URL", "http://10.11.33.5:9120/v1/")
    monkeypatch.setenv("INTERNAL_LLM_API_KEY", "EMPTY")

    config = LLMProviderConfig.from_env()

    assert config.provider == "internal_openai"
    assert config.model == "/model/gpt-oss-120b"
    assert config.base_url_env == "INTERNAL_LLM_BASE_URL"
    assert config.api_key_env == "INTERNAL_LLM_API_KEY"
    # the config object never carries the literal base_url/api_key VALUE either
    assert "10.11.33.5" not in config.model_dump_json()
    assert config.temperature == 0.0  # production reference default
    assert config.max_tokens == 3000  # production reference default
    assert config.max_retries == 1  # production reference default


def test_internal_openai_use_tool_calling_can_be_disabled(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "internal_openai")
    monkeypatch.setenv("INTERNAL_LLM_MODEL", "/model/gpt-oss-120b")
    monkeypatch.setenv("INTERNAL_LLM_BASE_URL", "http://10.11.33.5:9120/v1/")
    monkeypatch.setenv("INTERNAL_LLM_API_KEY", "EMPTY")
    monkeypatch.setenv("INTERNAL_LLM_USE_TOOL_CALLING", "false")

    config = LLMProviderConfig.from_env()
    assert config.use_tool_calling is False


def test_internal_openai_use_tool_calling_defaults_true(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "internal_openai")
    monkeypatch.setenv("INTERNAL_LLM_MODEL", "/model/gpt-oss-120b")
    monkeypatch.setenv("INTERNAL_LLM_BASE_URL", "http://10.11.33.5:9120/v1/")
    monkeypatch.setenv("INTERNAL_LLM_API_KEY", "EMPTY")

    config = LLMProviderConfig.from_env()
    assert config.use_tool_calling is True


def test_internal_openai_missing_base_url_still_constructs_config_but_client_build_fails_gracefully(monkeypatch):
    """`base_url_env` is always "INTERNAL_LLM_BASE_URL" for this profile
    (the field NAME is fixed) -- but if that named env var isn't actually
    SET when `build_llm_client` later resolves it, the adapter falls back
    to the SDK's own default base_url (None), which is a real, if
    surprising, behavior worth a dedicated regression."""
    monkeypatch.setenv("LLM_PROVIDER", "internal_openai")
    monkeypatch.setenv("INTERNAL_LLM_MODEL", "/model/gpt-oss-120b")
    monkeypatch.setenv("INTERNAL_LLM_API_KEY", "EMPTY")
    # INTERNAL_LLM_BASE_URL deliberately left unset

    config = LLMProviderConfig.from_env()
    assert config.base_url_env == "INTERNAL_LLM_BASE_URL"
    client = build_llm_client(config)
    assert "api.openai.com" in str(client._client.base_url)  # fell back to the SDK's own default, not a crash


# ============================================================================
# Anthropic profile (existing adapter, now reachable through the same
# env-driven layer)
# ============================================================================


def test_anthropic_profile_from_env(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "anthropic")
    monkeypatch.setenv("ANTHROPIC_MODEL", "claude-haiku-4-5-20251001")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-should-never-appear")

    config = LLMProviderConfig.from_env()
    assert config.provider == "anthropic"
    assert config.model == "claude-haiku-4-5-20251001"
    assert "sk-ant-should-never-appear" not in config.model_dump_json()


# ============================================================================
# build_llm_client -- dispatch + secret handling
# ============================================================================


def test_build_llm_client_openai_reads_key_from_named_env_var(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "sk-real-looking-test-key")
    config = LLMProviderConfig(provider="openai", model="gpt-4o-mini", api_key_env="OPENAI_API_KEY")
    client = build_llm_client(config)
    from agent.llm.providers.openai_adapter import OpenAICompatibleAdapter

    assert isinstance(client, OpenAICompatibleAdapter)


def test_build_llm_client_internal_openai_passes_base_url(monkeypatch):
    monkeypatch.setenv("INTERNAL_LLM_API_KEY", "EMPTY")
    monkeypatch.setenv("INTERNAL_LLM_BASE_URL", "http://10.11.33.5:9120/v1/")
    config = LLMProviderConfig(provider="internal_openai", model="/model/gpt-oss-120b", base_url_env="INTERNAL_LLM_BASE_URL", api_key_env="INTERNAL_LLM_API_KEY")
    client = build_llm_client(config)
    assert str(client._client.base_url) == "http://10.11.33.5:9120/v1/"


def test_build_llm_client_anthropic(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
    config = LLMProviderConfig(provider="anthropic", model="claude-haiku-4-5-20251001", api_key_env="ANTHROPIC_API_KEY")
    client = build_llm_client(config)
    from agent.llm.providers.anthropic_adapter import AnthropicAdapter

    assert isinstance(client, AnthropicAdapter)


def test_build_llm_client_mock_requires_explicit_responder():
    config = LLMProviderConfig(provider="mock", model="mock")
    with pytest.raises(LLMProviderConfigError):
        build_llm_client(config)


def test_build_llm_client_mock_with_responder():
    config = LLMProviderConfig(provider="mock", model="mock")
    client = build_llm_client(config, mock_responder=lambda request: {"value": "ok"})
    assert isinstance(client, MockLLMClient)


# ============================================================================
# Provider switching (item AJ) -- same downstream shape, different config
# ============================================================================


def test_provider_switch_openai_to_internal_is_config_only(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "sk-x")
    openai_config = LLMProviderConfig(provider="openai", model="gpt-4o-mini", api_key_env="OPENAI_API_KEY")
    openai_client = build_llm_client(openai_config)

    monkeypatch.setenv("INTERNAL_LLM_API_KEY", "EMPTY")
    monkeypatch.setenv("INTERNAL_LLM_BASE_URL", "http://10.11.33.5:9120/v1/")
    internal_config = LLMProviderConfig(provider="internal_openai", model="/model/gpt-oss-120b", base_url_env="INTERNAL_LLM_BASE_URL", api_key_env="INTERNAL_LLM_API_KEY")
    internal_client = build_llm_client(internal_config)

    # same adapter CLASS, different instances -- proves "one class serves
    # both modes" (item E) rather than needing two code paths.
    assert type(openai_client) is type(internal_client)


def test_build_routes_uses_same_model_for_every_route():
    config = LLMProviderConfig(provider="openai", model="gpt-4o-mini")
    routes = config.build_routes(["analyzer", "planner"])
    assert routes["analyzer"].model == "gpt-4o-mini"
    assert routes["planner"].model == "gpt-4o-mini"
    assert set(routes.keys()) == {"analyzer", "planner"}
