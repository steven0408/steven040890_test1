﻿from pathlib import Path

import pytest

from agent.skills.markdown import SkillMarkdownError, parse_skill_markdown
from agent.skills.models import SkillDefinition, SkillStep
from agent.state.enums import ObjectiveAction, RiskLevel, TargetRefType, TaskType

_EQUIPMENT_SCREENING_PATH = (
    Path(__file__).resolve().parents[1] / "agent" / "skills" / "oee" / "equipment_screening.md"
)


def test_parses_frontmatter_into_skill_definition():
    text = _EQUIPMENT_SCREENING_PATH.read_text(encoding="utf-8")
    definition, body = parse_skill_markdown(text)

    assert definition == SkillDefinition(
        skill_id="oee.equipment_screening",
        name="Equipment Screening",
        description="Identify equipment whose OEE falls below the factory threshold.",
        domains=["oee"],
        category="screening",
        required_tools=["query_oee_data", "filter_rows", "calculate_contribution", "ranking"],
        optional_tools=[],
        steps=[
            SkillStep(tool_id="query_oee_data", parameter_mapping={}),
            SkillStep(tool_id="filter_rows", parameter_mapping={"threshold": "prev.threshold"}),
            SkillStep(tool_id="calculate_contribution", parameter_mapping={}),
            SkillStep(tool_id="ranking", parameter_mapping={}),
        ],
        input_contract="OEEQueryInput",
        output_contract="RankedScreeningResult",
        risk_level=RiskLevel.LOW,
        version="1",
        task_types=[TaskType.ANALYSIS],
        actions=[ObjectiveAction.SCREEN],
        capability_key="oee.equipment_screening",
        expected_target_ref_type=TargetRefType.MODULE,
        accepted_scope_dimensions=[],
        required_scope_dimensions=[],
    )


def test_body_is_narrative_text_not_reparsed():
    text = _EQUIPMENT_SCREENING_PATH.read_text(encoding="utf-8")
    _, body = parse_skill_markdown(text)

    assert body.startswith("# Skill: Equipment Screening")
    assert "## Procedure" in body
    assert "## Fallback" in body
    # the narrative mentions tool names in prose, but that prose is never
    # parsed back into `steps` -- frontmatter is the only structured source
    assert "query_oee_data" in body


def test_missing_frontmatter_delimiter_raises():
    with pytest.raises(SkillMarkdownError):
        parse_skill_markdown("# Just a heading\n\nNo frontmatter here.")


def test_invalid_yaml_frontmatter_raises():
    broken = "---\nskill_id: [unterminated\n---\nbody\n"
    with pytest.raises(SkillMarkdownError):
        parse_skill_markdown(broken)


def test_frontmatter_missing_required_field_raises():
    text = """---
skill_id: oee.incomplete
name: Incomplete Skill
description: missing several required fields
category: screening
---
body
"""
    with pytest.raises(Exception):  # pydantic ValidationError
        parse_skill_markdown(text)
