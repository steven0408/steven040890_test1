"""Phase 6B item 15: Synthesis wired into a real parent graph
(`build_phase6_graph`) -- Global Completion Check -> Synthesis -> END,
reusing every node `build_phase2_graph` already uses unmodified. Proves a
full deterministic-Planner RCA run's Motor Failure finding survives all
the way through to `state.synthesis_result`, both with the deterministic
Synthesis node and the Mock-LLM-backed one (with its built-in fallback).
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD
from agent.graph.graph_with_synthesis import build_phase6_graph
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.graph.nodes.synthesis import make_llm_synthesis_node, make_synthesis_node
from agent.llm.config import LLMRouteConfig
from agent.llm.context.synthesis_context import SynthesisContextBuilder
from agent.llm.prompts.synthesis import SynthesisDraft
from agent.llm.client import MockLLMClient
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.planning.policies.oee import OEEPlanningPolicy
from agent.state.enums import RunTerminationStatus, SynthesisOverallStatus, TaskType
from agent.state.models import Goal, GoalScope, ModuleTask
from agent.state.state import AgentState
from agent.synthesis.handoff_builder import ModuleHandoffBuilder
from agent.synthesis.llm_service import SynthesisLLMService

from .conftest import make_agent_state, make_budget, make_oee_capability_runtime


def _single_oee_analyzer_node(task_type: TaskType):
    def node(state: AgentState) -> dict:
        goal = Goal(goal_id=f"{state.run_id}-goal", raw_statement=state.user_request.raw_text, normalized_statement=state.user_request.raw_text, task_type=task_type, scope=GoalScope())
        task = ModuleTask(module_id="OEE", module_type="OEE", reason="synthesis graph integration smoke", goal_statement="Synthesis graph integration smoke goal.", confidence=1.0, priority=1.0, task_type=task_type)
        return {"global_goal": goal, "selected_modules": [task]}

    return node


def _module_runtime() -> dict[str, ModuleRuntimeConfig]:
    return {
        "OEE": ModuleRuntimeConfig(
            policy=OEEPlanningPolicy(), capability=make_oee_capability_runtime(MOCK_EQUIPMENT, OEE_THRESHOLD),
            budget=make_budget(max_steps=6, max_tool_calls=20, max_depth_per_entity=3),
        )
    }


def _run(synthesis_node, run_id: str) -> AgentState:
    checkpointer = InMemorySaver()
    graph = build_phase6_graph(_module_runtime(), checkpointer, synthesis_node, analyzer=_single_oee_analyzer_node(TaskType.RCA))
    app = graph.compile(checkpointer=checkpointer)
    result = app.invoke(make_agent_state(run_id=run_id, raw_text="為什麼今天 OEE 下降？"), config={"configurable": {"thread_id": run_id}})
    return AgentState.model_validate(result)


def test_deterministic_synthesis_node_reaches_final_synthesis_result():
    final_state = _run(make_synthesis_node(), "graph-synth-deterministic")

    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS
    assert final_state.synthesis_result is not None
    assert final_state.synthesis_result.overall_status == SynthesisOverallStatus.COMPLETE
    assert "Motor Failure" in final_state.synthesis_result.markdown


def test_llm_synthesis_node_reaches_final_synthesis_result():
    def responder(request):
        prompt = "\n".join(m.content for m in request.messages)
        # pull the real root_cause id straight out of the rendered DATA
        # block instead of hardcoding one, keeping this test honest about
        # what the deterministic layer actually produced
        import re

        match = re.search(r"root_cause\[([^\]]+)\]", prompt)
        root_cause_ids = [match.group(1)] if match else []
        return SynthesisDraft(executive_summary="Confirmed root cause: Motor Failure on the Availability-dominant equipment.", root_cause_ids=root_cause_ids)

    router = LLMRouter(routes={"synthesis": LLMRouteConfig(route="synthesis", model="mock-synthesis-v1")}, client=MockLLMClient(responder), usage_sink=InMemoryLLMUsageSink())
    service = SynthesisLLMService(SynthesisContextBuilder(ModuleHandoffBuilder()), router)

    final_state = _run(make_llm_synthesis_node(service), "graph-synth-llm")

    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS
    assert final_state.synthesis_result is not None
    assert final_state.synthesis_result.overall_status == SynthesisOverallStatus.COMPLETE
    assert "Motor Failure" in final_state.synthesis_result.markdown
