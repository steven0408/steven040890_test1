﻿"""Phase 7A items 13.F/13.G: Planner fallback-heavy runs (fallback_decision_
count correct, an issue is raised) and Tool replay/reuse (logical vs.
manager-invocation vs. physical-execution counts stay distinct, per the
Phase 5B-1.2 terminology freeze).
"""
from datetime import datetime, timezone

from agent.evaluation.evaluator import RunEvaluator
from agent.evaluation.inputs import RunAuditBundle
from agent.llm.models import DecisionSource
from agent.llm.prompts.planner import PlannerDecisionType
from agent.planning.decision_audit import PlannerDecisionRecord
from agent.state.enums import ObjectiveAction, ObservationStatus, TargetRefType
from agent.state.models import TargetRef, ToolCallRecord

from .conftest import make_agent_state, make_module_state


def _now():
    return datetime.now(timezone.utc)


def _planner_record(i: int, source: DecisionSource) -> PlannerDecisionRecord:
    return PlannerDecisionRecord(
        decision_record_id=f"dec-{i}", run_id="run-1", module_id="mod-oee", step=i, decision=PlannerDecisionType.DISPATCH,
        proposed_action=ObjectiveAction.SCREEN, target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="OEE"),
        priority=1.0, source=source, rationale_summary="x", created_at=_now(),
    )


def test_planner_fallback_heavy_run_counts_correctly_and_raises_an_issue():
    module_state = make_module_state()
    state = make_agent_state().model_copy(update={"module_states": {"OEE": module_state}})
    records = [_planner_record(1, DecisionSource.FALLBACK), _planner_record(2, DecisionSource.FALLBACK), _planner_record(3, DecisionSource.LLM)]
    bundle = RunAuditBundle(planner_decision_records=records)

    evaluation = RunEvaluator().evaluate(state, bundle)

    assert evaluation.efficiency.planner_decision_count == 3
    assert evaluation.decision_quality.planner.fallback_decision_count == 2
    issue = next(i for i in evaluation.issues if i.metric_name == "fallback_decision_count")
    assert "2" in issue.statement


def test_tool_replay_and_reuse_counts_stay_distinct():
    module_state = make_module_state()
    state = make_agent_state().model_copy(update={"module_states": {"OEE": module_state}})

    key = "shared-idempotency-key"
    records = [
        ToolCallRecord(
            tool_call_id="tc-1", run_id="run-1", module_id="mod-oee", objective_id="o1", tool_id="query_oee_data",
            status=ObservationStatus.SUCCESS, duration_seconds=0.1, started_at=_now(), completed_at=_now(),
            idempotency_key=key, logical_call_id="mod-oee-o1-query_oee_data", attempt_number=1, replayed=False, result_reused=False,
        ),
        ToolCallRecord(
            tool_call_id="tc-2", run_id="run-1", module_id="mod-oee", objective_id="o1", tool_id="query_oee_data",
            status=ObservationStatus.SUCCESS, duration_seconds=0.0, started_at=_now(), completed_at=_now(),
            idempotency_key=key, logical_call_id="mod-oee-o1-query_oee_data", attempt_number=2, replayed=True, result_reused=True,
        ),
        ToolCallRecord(
            tool_call_id="tc-3", run_id="run-1", module_id="mod-oee", objective_id="o2", tool_id="query_equipment_detail",
            status=ObservationStatus.ERROR, duration_seconds=0.2, started_at=_now(), completed_at=_now(),
            idempotency_key="another-key", logical_call_id="mod-oee-o2-query_equipment_detail", attempt_number=1, replayed=False, result_reused=False,
        ),
    ]
    bundle = RunAuditBundle(tool_call_records=records)

    evaluation = RunEvaluator().evaluate(state, bundle)
    m = evaluation.efficiency

    assert m.logical_tool_call_count == 2  # 2 distinct idempotency_keys
    assert m.tool_manager_invocation_count == 3  # every ToolExecutionManager.execute() call
    assert m.physical_tool_execution_count == 2  # tc-1 and tc-3 actually called tool.run()
    assert m.result_reuse_count == 1  # tc-2, cache hit
    assert m.replay_count == 1  # tc-2, attempt_number > 1
    assert m.failed_tool_execution_count == 1  # tc-3
