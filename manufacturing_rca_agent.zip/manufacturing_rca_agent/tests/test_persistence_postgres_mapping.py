﻿"""Offline (always-run) mapping tests -- item 11/12. No DB, no `psycopg`
required: `Record -> to_row() -> from_row() -> Record` round-trips are pure
Python. Covers enum handling, timezone-aware datetimes, optional fields,
JSON payloads, and nested ids across a representative sample spanning
every schema section (A-F).
"""
from datetime import datetime, timezone

from agent.evaluation.audit import EvaluationRecord
from agent.learning.review import CandidateReview
from agent.learning.signals import LearningEvidenceLink
from agent.llm.context.context_audit import ContextBuildRecord
from agent.llm.context.synthesis_context_audit import SynthesisContextBuildRecord
from agent.llm.context.knowledge_retriever import ValidationStatus
from agent.llm.models import DecisionSource, LLMCallRecord, LLMCallStatus
from agent.llm.prompts.planner import PlannerDecisionType
from agent.persistence.postgres import mapping as m
from agent.persistence.records import (
    EvidenceRecord,
    FindingEvidenceLink,
    FindingRecord,
    ModuleRunRecord,
    RootCauseFindingLink,
    RootCauseRecord,
    RunRecord,
    ValidatedKnowledgeRecord,
)
from agent.planning.decision_audit import PlannerDecisionRecord
from agent.state.enums import (
    CandidateReviewDecision,
    EvaluationCategory,
    EvaluationSeverity,
    EvidenceQuality,
    FeedbackTargetType,
    FindingStatus,
    HumanDecision,
    HumanFeedbackThumbs,
    HumanReason,
    HumanRequestStatus,
    LearningCandidateStatus,
    LearningCandidateType,
    LearningDestination,
    LearningSignalType,
    ModuleStatus,
    ObjectiveAction,
    ObjectiveStatus,
    ObservationStatus,
    RiskLevel,
    RunTerminationStatus,
    TaskType,
)
from agent.state.models import (
    ErrorRecord,
    EvaluationIssue,
    HandoffPackage,
    HumanFeedback,
    HumanRequest,
    HumanResponse,
    LearningCandidate,
    ObjectiveRecord,
    ResumeTarget,
    RunEvaluation,
    TargetRef,
)
from agent.synthesis.decision_audit import SynthesisGenerationRecord, SynthesisSource
from agent.tools.execution_manager import ToolCallRecord

_TS = datetime(2026, 8, 12, 3, 4, 5, tzinfo=timezone.utc)


def _assert_tz_aware(dt: datetime) -> None:
    assert dt.tzinfo is not None


# ============================================================================
# A. Run / Analysis aggregate
# ============================================================================


def test_run_record_round_trip():
    record = RunRecord(
        run_id="run-1", user_request="why is output low", normalized_request="normalized", factory_id="factory-a",
        task_type=TaskType.RCA, run_status=RunTerminationStatus.READY_FOR_SYNTHESIS, started_at=_TS, completed_at=_TS,
        created_at=_TS, application_version="v1",
    )
    row = m.run_to_row(record)
    restored = m.run_from_row(row)
    assert restored == record
    _assert_tz_aware(restored.started_at)


def test_run_record_round_trip_with_optional_fields_none():
    record = RunRecord(
        run_id="run-2", user_request="x", factory_id="factory-a", run_status=RunTerminationStatus.READY_FOR_SYNTHESIS,
        created_at=_TS,
    )
    assert m.run_from_row(m.run_to_row(record)) == record


def test_module_run_record_round_trip():
    record = ModuleRunRecord(
        run_id="run-1", module_id="OEE", module_type="OEE", task_type=TaskType.RCA, module_status=ModuleStatus.COMPLETE,
        goal="why did OEE decline", started_at=_TS, completed_at=_TS, step_count=3, tool_call_count=2,
        limitation_count=0, finding_count=1,
    )
    assert m.module_run_from_row(m.module_run_to_row(record)) == record


def test_objective_record_round_trip_with_nested_target_ref():
    record = ObjectiveRecord(
        objective_id="obj-1", description="check availability", action=ObjectiveAction.SUMMARIZE,
        capability_key="oee.current_status",  # Phase WB-2B.1: new nullable column, exercised with a real value here
        target_ref=TargetRef(ref_type="entity", ref_id="EQ001"), status=ObjectiveStatus.COMPLETED, created_step=1,
        completed_step=2, attempt_count=1, observation_ids=["obs-1"], evidence_ids=["ev-1"],
        termination_reason="candidate_complete",
    )
    row = m.objective_to_row("run-1", "OEE", record)
    assert row["run_id"] == "run-1" and row["module_id"] == "OEE"
    assert row["capability_key"] == "oee.current_status"
    restored = m.objective_from_row(row)
    assert restored == record


def test_objective_record_round_trip_with_null_capability_key():
    """The domain-agnostic Harness-mechanics path (DeterministicMockPolicy)
    never sets capability_key -- must round-trip as NULL, not a crash."""
    record = ObjectiveRecord(
        objective_id="obj-2", description="mock source query", action=ObjectiveAction.QUERY,
        target_ref=TargetRef(ref_type="module", ref_id="primary"), status=ObjectiveStatus.COMPLETED, created_step=1,
        attempt_count=1,
    )
    row = m.objective_to_row("run-1", "OEE", record)
    assert row["capability_key"] is None
    assert m.objective_from_row(row) == record


def test_evidence_record_round_trip_with_structured_payload():
    record = EvidenceRecord(
        evidence_id="ev-1", run_id="run-1", module_id="OEE", objective_id="obj-1", source_tool="query_oee_data",
        quality=EvidenceQuality.STRONG, summary="OEE is 62%", payload_type="oee_status",
        structured_payload={"oee": 0.62, "equipment": ["EQ001"]},
    )
    assert m.evidence_from_row(m.evidence_to_row(record)) == record


def test_evidence_record_round_trip_with_no_payload():
    record = EvidenceRecord(
        evidence_id="ev-2", run_id="run-1", module_id="OEE", objective_id="obj-1", source_tool="t",
        quality=EvidenceQuality.WEAK, summary="s",
    )
    assert m.evidence_from_row(m.evidence_to_row(record)) == record


def test_finding_record_round_trip():
    record = FindingRecord(
        finding_id="f-1", run_id="run-1", module_id="OEE", statement="Availability declined", pattern="decline",
        status=FindingStatus.CONFIRMED, confidence=0.85, is_root_cause=True, entity_ids=["EQ001", "EQ002"],
    )
    assert m.finding_from_row(m.finding_to_row(record)) == record


def test_finding_evidence_link_round_trip():
    link = FindingEvidenceLink(finding_id="f-1", evidence_id="ev-1")
    assert m.finding_evidence_link_from_row(m.finding_evidence_link_to_row(link)) == link


def test_root_cause_record_round_trip():
    record = RootCauseRecord(root_cause_id="rc-1", run_id="run-1", module_id="OEE", statement="Machine EQ001 down", confidence=0.9, entity_ids=["EQ001"])
    assert m.root_cause_from_row(m.root_cause_to_row(record)) == record


def test_root_cause_finding_link_round_trip():
    link = RootCauseFindingLink(root_cause_id="rc-1", finding_id="f-1")
    assert m.root_cause_finding_link_from_row(m.root_cause_finding_link_to_row(link)) == link


def _handoff_package(run_id="run-1"):
    from agent.state.enums import SynthesisOverallStatus
    from agent.state.models import ConfidenceSummary

    return HandoffPackage(
        run_id=run_id, request_summary="why is output low", task_type=TaskType.RCA,
        overall_status=SynthesisOverallStatus.COMPLETE, confidence_summary=ConfidenceSummary(overall_confidence=0.8, evidence_coverage=0.9),
    )


def test_handoff_package_round_trip():
    package = _handoff_package()
    row = m.handoff_package_to_row(package)
    assert row["run_id"] == "run-1"
    assert m.handoff_package_from_row(row) == package


# ============================================================================
# B. Audit domain
# ============================================================================


def test_llm_call_record_round_trip():
    record = LLMCallRecord(
        llm_call_id="llm-1", run_id="run-1", module_id="OEE", node="planner", route="planner", model="mock-v1",
        input_tokens=100, output_tokens=50, latency_ms=250.5, status=LLMCallStatus.SUCCESS, retry_count=1,
        estimated_cost=0.002, started_at=_TS, completed_at=_TS,
    )
    assert m.llm_call_from_row(m.llm_call_to_row(record)) == record


def test_context_build_record_round_trip():
    record = ContextBuildRecord(
        context_build_record_id="cb-1", run_id="run-1", module_id="OEE", node="planner", included_findings_count=1,
        included_evidence_count=2, included_skills_count=3, included_knowledge_count=0,
        included_reasoning_skills_count=1, estimated_context_characters=500, items_trimmed=0, build_duration_ms=1.2,
        started_at=_TS, completed_at=_TS,
    )
    assert m.context_build_from_row(m.context_build_to_row(record)) == record


def test_synthesis_context_build_record_round_trip():
    record = SynthesisContextBuildRecord(
        context_build_record_id="scb-1", run_id="run-1", included_modules=["OEE", "Output"],
        included_findings_count=2, included_root_causes_count=1, included_limitations_count=0,
        included_reasoning_skills_count=0, estimated_context_characters=100, items_trimmed=0, build_duration_ms=0.5,
        started_at=_TS, completed_at=_TS,
    )
    assert m.synthesis_context_build_from_row(m.synthesis_context_build_to_row(record)) == record


def test_planner_decision_record_round_trip_with_optional_nested_target_ref():
    record = PlannerDecisionRecord(
        decision_record_id="pd-1", run_id="run-1", module_id="OEE", step=1, decision=PlannerDecisionType.DISPATCH,
        proposed_action=ObjectiveAction.SUMMARIZE, proposed_capability_key="oee.current_status",
        target_ref=TargetRef(ref_type="entity", ref_id="EQ001"),
        priority=0.8, source=DecisionSource.LLM, rationale_summary="dispatch to check availability",
        context_build_record_id="cb-1", llm_call_id="llm-1", created_at=_TS,
    )
    row = m.planner_decision_to_row(record)
    assert row["proposed_capability_key"] == "oee.current_status"
    assert m.planner_decision_from_row(row) == record


def test_planner_decision_record_round_trip_fallback_no_target_ref():
    record = PlannerDecisionRecord(
        decision_record_id="pd-2", run_id="run-1", module_id="OEE", step=2, decision=PlannerDecisionType.NO_VIABLE_OBJECTIVE,
        source=DecisionSource.FALLBACK, rationale_summary="no viable objective", fallback_reason="llm timeout", created_at=_TS,
    )
    assert m.planner_decision_from_row(m.planner_decision_to_row(record)) == record


def test_synthesis_generation_record_round_trip():
    record = SynthesisGenerationRecord(
        synthesis_record_id="sg-1", run_id="run-1", source=SynthesisSource.LLM, context_build_record_id="scb-1",
        llm_call_id="llm-2", included_module_ids=["OEE"], referenced_finding_ids=["f-1"],
        referenced_root_cause_ids=["rc-1"], referenced_relation_ids=[], referenced_recommendation_ids=["rec-1"],
        created_at=_TS,
    )
    assert m.synthesis_generation_from_row(m.synthesis_generation_to_row(record)) == record


def test_tool_call_record_round_trip_with_error():
    record = ToolCallRecord(
        tool_call_id="tc-1", run_id="run-1", module_id="OEE", objective_id="obj-1", tool_id="query_oee_data",
        status=ObservationStatus.ERROR, duration_seconds=0.5,
        error=ErrorRecord(error_type="data_not_found", message="no rows", objective_id="obj-1", occurred_at_step=1),
        started_at=_TS, completed_at=_TS, idempotency_key="idem-1", logical_call_id="log-1", attempt_number=2,
        replayed=True, result_reused=False,
    )
    assert m.tool_call_from_row(m.tool_call_to_row(record)) == record


def test_tool_call_record_round_trip_success_no_error():
    record = ToolCallRecord(
        tool_call_id="tc-2", run_id="run-1", module_id="OEE", objective_id="obj-1", tool_id="query_oee_data",
        status=ObservationStatus.SUCCESS, duration_seconds=0.1, started_at=_TS, completed_at=_TS,
    )
    assert m.tool_call_from_row(m.tool_call_to_row(record)) == record


def test_evaluation_record_round_trip():
    record = EvaluationRecord(
        evaluation_id="eval-1", run_id="run-1", evaluator_version="v1", evaluated_at=_TS,
        metric_source_counts={"tool_calls": 3, "llm_calls": 2}, planner_decision_record_ids=["pd-1"],
        synthesis_record_id="sg-1", tool_audit_record_count=3, llm_call_record_count=2, context_record_count=1,
        human_intervention_count=0,
    )
    assert m.evaluation_record_from_row(m.evaluation_record_to_row(record)) == record


def _human_request(request_id="hr-1"):
    return HumanRequest(
        request_id=request_id, run_id="run-1", module_id="OEE", objective_id="obj-1", source_node="execution_gate",
        reason=HumanReason.PERMISSION_REQUIRED, question="approve maintenance_db_access?", options=["approve", "reject"],
        permission_type="maintenance_db_access", risk_level=RiskLevel.HIGH,
        resume_target=ResumeTarget(module_id="OEE", node="execution_gate", objective_id="obj-1"),
        status=HumanRequestStatus.PENDING, created_at_step=1,
    )


def test_human_request_round_trip_without_response():
    request = _human_request()
    row = m.human_request_to_row(request)
    assert m.human_request_from_row(row, None) == request


def test_human_request_round_trip_with_response():
    request = _human_request("hr-2").model_copy(update={"status": HumanRequestStatus.RESOLVED})
    response = HumanResponse(decision=HumanDecision.APPROVE, responded_by="tester", responded_at=_TS)
    response_row = m.human_response_to_row("hr-2", response)
    restored = m.human_request_from_row(m.human_request_to_row(request), response_row)
    assert restored.response == response
    assert restored.status == HumanRequestStatus.RESOLVED


# ============================================================================
# C. RunEvaluation + issues
# ============================================================================


def _run_evaluation():
    from agent.state.models import AnalyticalQualityMetrics, AnalyzerDecisionQuality, DecisionQualityMetrics, DeliveryQualityMetrics, EfficiencyMetrics, PlannerDecisionQualityAggregate

    return RunEvaluation(
        evaluation_id="eval-1", run_id="run-1", evaluator_version="v1", evaluated_at=_TS,
        efficiency=EfficiencyMetrics(
            total_module_count=3, completed_module_count=3, planner_decision_count=5, objective_count=3,
            logical_tool_call_count=3, tool_manager_invocation_count=3, physical_tool_execution_count=3,
            result_reuse_count=0, replay_count=0, failed_tool_execution_count=0, total_llm_calls=2, llm_retry_count=0,
            input_tokens=100, output_tokens=50, total_context_characters=500, context_trim_count=0,
            human_intervention_count=0, total_duration_ms=1234.5,
        ),
        analytical_quality=AnalyticalQualityMetrics(
            evidence_coverage=0.9, confirmed_finding_ratio=0.8, root_cause_support_score=0.7,
            limitation_transparency_score=1.0, unresolved_question_transparency=1.0, failed_module_ratio=0.0,
            blocked_module_ratio=0.0, partial_module_ratio=0.0, synthesis_fact_consistency=1.0,
            cross_module_relation_support_score=0.5,
        ),
        decision_quality=DecisionQualityMetrics(
            analyzer=AnalyzerDecisionQuality(selected_module_count=3, module_selection_validity=1.0, unsupported_module_selection_count=0, analyzer_fallback_used=False),
            planner=PlannerDecisionQualityAggregate(invalid_decision_count=0, fallback_decision_count=0, redundant_target_count=0, unnecessary_deep_dive_count=0),
        ),
        delivery_quality=DeliveryQualityMetrics(
            request_answered_score=1.0, module_result_coverage=1.0, root_cause_lineage_validity=1.0,
            limitation_preservation=1.0, task_type_depth_compliance=1.0, synthesis_status_consistency=1.0,
            hallucination_guard_passed=True,
        ),
        overall_score=0.85,
    )


def test_run_evaluation_round_trip_with_issues():
    evaluation = _run_evaluation()
    issue = EvaluationIssue(
        issue_id="issue-1", category=EvaluationCategory.EFFICIENCY, severity=EvaluationSeverity.MEDIUM,
        statement="too many LLM retries", related_module_ids=["OEE"], related_objective_ids=["obj-1"],
        metric_name="llm_retry_count", evidence_refs=["llm-1"], suggested_improvement_area="prompt tuning",
    )
    row = m.run_evaluation_to_row(evaluation)
    restored = m.run_evaluation_from_row(row, [issue])
    assert restored.model_copy(update={"issues": []}) == evaluation.model_copy(update={"issues": []})
    assert restored.issues == [issue]


def test_run_evaluation_round_trip_no_weighting_no_issues():
    evaluation = _run_evaluation()
    restored = m.run_evaluation_from_row(m.run_evaluation_to_row(evaluation), [])
    assert restored == evaluation


def test_evaluation_issue_round_trip():
    issue = EvaluationIssue(
        issue_id="issue-2", category=EvaluationCategory.DELIVERY_QUALITY if hasattr(EvaluationCategory, "DELIVERY_QUALITY") else EvaluationCategory.EFFICIENCY,
        severity=EvaluationSeverity.HIGH, statement="s", metric_name="m", suggested_improvement_area="a",
    )
    assert m.evaluation_issue_from_row(m.evaluation_issue_to_row("eval-1", issue)) == issue


# ============================================================================
# D. Human Feedback
# ============================================================================


def test_human_feedback_round_trip():
    feedback = HumanFeedback(
        feedback_id="fb-1", run_id="run-1", target_type=FeedbackTargetType.FINDING, target_id="f-1",
        user_id="steven040890@gmail.com", thumbs=HumanFeedbackThumbs.UP, finding_correct=True, comment="looks right",
        created_at=_TS,
    )
    assert m.human_feedback_from_row(m.human_feedback_to_row(feedback)) == feedback


def test_human_feedback_round_trip_run_level_no_target_id():
    feedback = HumanFeedback(feedback_id="fb-2", run_id="run-1", target_type=FeedbackTargetType.RUN, created_at=_TS)
    assert m.human_feedback_from_row(m.human_feedback_to_row(feedback)) == feedback


# ============================================================================
# E. Learning
# ============================================================================


def test_learning_candidate_round_trip():
    candidate = LearningCandidate(
        candidate_id="cand-1", candidate_type=LearningCandidateType.KNOWLEDGE_PATTERN, title="pattern",
        statement="Availability decline may be associated with EQ001 downtime", confidence=0.7,
        source_run_ids=["run-1", "run-2"], source_module_ids=["OEE"], supporting_finding_ids=["f-1"],
        supporting_signal_count=2, contradicting_signal_count=0, created_at=_TS, updated_at=_TS,
        scope="factory-a", proposed_destination=LearningDestination.KNOWLEDGE_BASE, candidate_key="oee:eq001:availability",
        rationale_summary="two independent runs support this pairing",
    )
    assert m.learning_candidate_from_row(m.learning_candidate_to_row(candidate)) == candidate


def test_learning_candidate_round_trip_all_statuses():
    for status in LearningCandidateStatus:
        candidate = LearningCandidate(
            candidate_id=f"cand-{status.value}", candidate_type=LearningCandidateType.CAPABILITY_GAP, title="t",
            statement="s", status=status, confidence=0.5, created_at=_TS, updated_at=_TS, scope="factory-a",
            proposed_destination=LearningDestination.CAPABILITY_BACKLOG, candidate_key=f"key-{status.value}",
            rationale_summary="r",
        )
        assert m.learning_candidate_from_row(m.learning_candidate_to_row(candidate)) == candidate


def test_learning_evidence_link_round_trip():
    link = LearningEvidenceLink(link_id="link-1", candidate_id="cand-1", signal_type=LearningSignalType.CONFIRMED_FINDING, source_run_id="run-1", supports=True, strength=0.6)
    assert m.learning_evidence_link_from_row(m.learning_evidence_link_to_row(link)) == link


def test_candidate_review_round_trip():
    review = CandidateReview(review_id="rev-1", candidate_id="cand-1", reviewer="steven040890@gmail.com", decision=CandidateReviewDecision.APPROVE, comment="looks good", reviewed_at=_TS)
    assert m.candidate_review_from_row(m.candidate_review_to_row(review)) == review


# ============================================================================
# F. Validated Knowledge (future-only, mapping still tested for schema completeness)
# ============================================================================


def test_validated_knowledge_record_round_trip():
    record = ValidatedKnowledgeRecord(
        knowledge_id="vk-1", statement="EQ001 chronically underperforms", knowledge_type="equipment_pattern",
        validation_status=ValidationStatus.VALIDATED, confidence=0.95, scope="factory-a", source_candidate_id="cand-1",
        approved_by="steven040890@gmail.com", approved_at=_TS,
    )
    assert m.validated_knowledge_from_row(m.validated_knowledge_to_row(record)) == record
