"""Phase PROD-1: static production composition wiring for WB DataSources.

Confirms the thing the phase spec explicitly asked to verify: whether the
composition root can select `Remote*DataSource` instances via config,
versus always constructing `InMemory*DataSource`
(`agent/modules/wb/package.py::_default_wb_datasources()`, unchanged).
`build_remote_wb_datasources` (agent/domain/wb/remote.py) is the smallest
composition wiring closing that gap -- these tests only construct objects
and confirm the produced `WBDataSources` is structurally the Remote
variant with every WB Tool's own Protocol satisfied; they NEVER call
`.list_*()` against a real host (this file's own `UrllibHttpClient` test
below points at `http://127.0.0.1:0`, a port nothing listens on, purely to
prove the typed-error path, exactly mirroring `test_wb_remote_adapter.py`'s
own "never contacts a real host" discipline).
"""
import pytest

from agent.domain.wb.datasource import (
    WBBankDataSource,
    WBIssueDataSource,
    WBPlantOEEDataSource,
    WBStageOutputDataSource,
    WBWIPDataSource,
)
from agent.domain.wb.http_client import UrllibHttpClient
from agent.domain.wb.remote import (
    RemoteWBBankDataSource,
    RemoteWBIssueDataSource,
    RemoteWBPlantOEEDataSource,
    RemoteWBStageOutputDataSource,
    RemoteWBWIPDataSource,
    WBApiConfig,
    build_remote_wb_datasources,
)
from agent.modules.wb.package import build_wb_module_package
from agent.tools.wb.registration import WBDataSources

from .wb_fake_http_client import FakeHttpClient


@pytest.fixture()
def config(monkeypatch):
    monkeypatch.setenv("WB_API_BASE_URL_TEST", "http://fake-wb-host.invalid:18058")
    return WBApiConfig(base_url_env="WB_API_BASE_URL_TEST")


def test_build_remote_wb_datasources_returns_all_five_remote_classes(config):
    client = FakeHttpClient()
    datasources = build_remote_wb_datasources(config, http_client=client)

    assert isinstance(datasources, WBDataSources)
    assert isinstance(datasources.oee, RemoteWBPlantOEEDataSource)
    assert isinstance(datasources.bank, RemoteWBBankDataSource)
    assert isinstance(datasources.wip, RemoteWBWIPDataSource)
    assert isinstance(datasources.output, RemoteWBStageOutputDataSource)
    assert isinstance(datasources.issue, RemoteWBIssueDataSource)
    # Every Remote*DataSource still satisfies the exact same Protocol its
    # InMemory sibling does -- confirmed structurally, no isinstance check
    # possible against a Protocol without @runtime_checkable, so this
    # mirrors the existing satisfied-duck-typing discipline instead.
    assert hasattr(datasources.oee, "list_oee") and hasattr(datasources.oee, "freshness")


def test_build_remote_wb_datasources_never_calls_the_client(config):
    """Construction alone must never make a network call -- proves this
    phase's own 'do not call the formal API' constraint is structurally
    honored by the composition function itself, not just by test discipline."""
    client = FakeHttpClient()
    build_remote_wb_datasources(config, http_client=client)
    assert client.requests == []


def test_remote_wb_datasources_plug_straight_into_build_wb_module_package(config):
    """Confirms the *actual* composition-root extension point: no Tool/
    Skill/Policy code changes -- a caller just passes the Remote
    WBDataSources to the exact same `build_wb_module_package(datasources=...)`
    entrypoint bootstrap.py's own `default_module_package_registry()`
    already calls with the InMemory default."""
    client = FakeHttpClient()
    remote_datasources = build_remote_wb_datasources(config, http_client=client)
    package = build_wb_module_package(datasources=remote_datasources)
    assert package.module_definition.module_type == "WB"
    assert client.requests == []  # package construction alone still makes no call


# ============================================================================
# UrllibHttpClient -- stdlib-only HttpClient Protocol implementation.
# Never points at a real manufacturing host; only at a port nothing
# listens on, to prove the connection-error path.
# ============================================================================


def test_urllib_http_client_satisfies_the_protocol_shape():
    client = UrllibHttpClient()
    assert hasattr(client, "get")


def test_urllib_http_client_raises_on_unreachable_host():
    client = UrllibHttpClient()
    with pytest.raises(ConnectionError):
        client.get("http://127.0.0.1:0", params={}, timeout=0.5)
