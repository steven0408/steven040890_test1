"""Phase 7B items 5/6/9: HumanFeedbackAggregator + FeedbackIssue
classification -- test cases A, D, E, G, H from the spec.
"""
from datetime import datetime, timezone

from agent.feedback.aggregator import HumanFeedbackAggregator
from agent.feedback.issues import FeedbackIssueCategory, classify_feedback_issues
from agent.state.enums import EvaluationSeverity, FeedbackTargetType, HumanFeedbackThumbs
from agent.state.models import HumanFeedback


def _fb(feedback_id, **kwargs):
    base = dict(run_id="run-1", target_type=FeedbackTargetType.RUN, created_at=datetime.now(timezone.utc))
    base.update(kwargs)
    return HumanFeedback(feedback_id=feedback_id, **base)


# ============================================================================
# A. Positive run feedback
# ============================================================================


def test_positive_run_feedback_summary():
    feedback = [_fb("f1", thumbs=HumanFeedbackThumbs.UP, answer_helpful=True)]
    summary = HumanFeedbackAggregator().summarize("run-1", feedback)

    assert summary.total_feedback_count == 1
    assert summary.thumbs_up_count == 1
    assert summary.thumbs_down_count == 0
    assert summary.helpful_rate == 1.0
    assert summary.unresolved_negative_feedback_count == 0


# ============================================================================
# G. Multiple users
# ============================================================================


def test_multi_user_aggregation_denominator_correct():
    feedback = [
        _fb("f1", user_id="u1", thumbs=HumanFeedbackThumbs.UP),
        _fb("f2", user_id="u2", thumbs=HumanFeedbackThumbs.UP),
        _fb("f3", user_id="u3", thumbs=HumanFeedbackThumbs.DOWN),
    ]
    summary = HumanFeedbackAggregator().summarize("run-1", feedback)

    assert summary.total_feedback_count == 3
    assert summary.thumbs_up_count == 2
    assert summary.thumbs_down_count == 1


# ============================================================================
# H. Missing field -- denominator excludes unanswered feedback
# ============================================================================


def test_rate_denominator_only_counts_feedback_that_answered_the_field():
    feedback = [
        _fb("f1", target_type=FeedbackTargetType.ROOT_CAUSE, target_id="rc1", root_cause_correct=True),
        _fb("f2", target_type=FeedbackTargetType.ROOT_CAUSE, target_id="rc1"),  # did not answer root_cause_correct
        _fb("f3", target_type=FeedbackTargetType.ROOT_CAUSE, target_id="rc1"),  # did not answer either
    ]
    summary = HumanFeedbackAggregator().summarize("run-1", feedback)

    assert summary.root_cause_correct_rate == 1.0  # 1/1, not 1/3
    assert summary.finding_correct_rate is None  # nobody answered at all -- None, not 0.0


# ============================================================================
# D. Finding rejected
# ============================================================================


def test_finding_rejected_produces_incorrect_finding_issue():
    feedback = [_fb("f1", target_type=FeedbackTargetType.FINDING, target_id="find-1", finding_correct=False, comment="wrong pattern")]
    issues = classify_feedback_issues(feedback)

    assert len(issues) == 1
    assert issues[0].category == FeedbackIssueCategory.INCORRECT_FINDING
    assert issues[0].severity == EvaluationSeverity.MEDIUM
    assert issues[0].target_id == "find-1"
    assert issues[0].comment == "wrong pattern"


# ============================================================================
# C. Root cause rejected
# ============================================================================


def test_root_cause_rejected_produces_high_severity_issue():
    feedback = [_fb("f1", target_type=FeedbackTargetType.ROOT_CAUSE, target_id="rc1", root_cause_correct=False)]
    issues = classify_feedback_issues(feedback)

    assert len(issues) == 1
    assert issues[0].category == FeedbackIssueCategory.INCORRECT_ROOT_CAUSE
    assert issues[0].severity == EvaluationSeverity.HIGH


# ============================================================================
# E. Recommendation unhelpful
# ============================================================================


def test_recommendation_unhelpful_produces_recommendation_level_issue():
    feedback = [_fb("f1", target_type=FeedbackTargetType.RECOMMENDATION, target_id="rec1", recommendation_useful=False)]
    issues = classify_feedback_issues(feedback)

    assert len(issues) == 1
    assert issues[0].category == FeedbackIssueCategory.UNHELPFUL_RECOMMENDATION
    assert issues[0].target_id == "rec1"


def test_bare_thumbs_down_with_no_structured_signal_classified_as_other_low():
    feedback = [_fb("f1", thumbs=HumanFeedbackThumbs.DOWN)]
    issues = classify_feedback_issues(feedback)

    assert len(issues) == 1
    assert issues[0].category == FeedbackIssueCategory.OTHER
    assert issues[0].severity == EvaluationSeverity.LOW


def test_multiple_negative_fields_on_one_feedback_produce_multiple_issues():
    feedback = [_fb("f1", target_type=FeedbackTargetType.ROOT_CAUSE, target_id="rc1", root_cause_correct=False, answer_helpful=False)]
    issues = classify_feedback_issues(feedback)

    categories = {i.category for i in issues}
    assert categories == {FeedbackIssueCategory.INCORRECT_ROOT_CAUSE, FeedbackIssueCategory.ANSWER_NOT_HELPFUL}


def test_unresolved_negative_feedback_resolved_by_a_later_positive_on_same_target():
    from datetime import timedelta

    early = _fb("f1", target_type=FeedbackTargetType.ROOT_CAUSE, target_id="rc1", thumbs=HumanFeedbackThumbs.DOWN)
    later = _fb("f2", target_type=FeedbackTargetType.ROOT_CAUSE, target_id="rc1", thumbs=HumanFeedbackThumbs.UP, created_at=early.created_at + timedelta(seconds=10))
    summary = HumanFeedbackAggregator().summarize("run-1", [early, later])
    assert summary.unresolved_negative_feedback_count == 0  # the later positive supersedes the earlier negative
