"""Phase WB-2D: WBPlanningPolicy's RCA branch, exercised through the REAL
Module ReAct Subgraph (multi-round, real Planner/Gate/Executor/Reflector/
CompletionCheck nodes) -- not a bypassed unit call. Golden Scenarios A-E
(items 40-44) plus the dynamic-replanning/contradiction proof (item 45/46,
using ASE01 -- a plant the frozen synthetic dataset already gives a
"low Output, but Bank/WIP both normal, OEE abnormal" story for free, no
controlled DataSource fixture needed). `goal.statement` is built directly
on `ModuleTask` here (module-subgraph level, below Analyzer) -- the real
Analyzer->ModuleTask->ModuleGoal propagation path is proven separately by
tests/test_wb_rca_parent_graph_e2e.py. All offline.
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.modules.wb.package import build_wb_module_package
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import EntityAnalysisStatus, FindingStatus, ModuleStatus, TaskType
from agent.state.models import ModuleState, ModuleTask
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry


def _run_wb_rca(thread_id: str, statement: str) -> ModuleState:
    package = build_wb_module_package()
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    runtime = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)

    policy = WBPlanningPolicy()
    graph = build_module_react_subgraph(policy, capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id="WB", module_type="WB", reason=statement, goal_statement=statement, confidence=0.9, priority=0.9, task_type=TaskType.RCA)
    initial = build_initial_module_state(task, package.budget, run_id=f"run-{thread_id}", task_type=TaskType.RCA)

    result = app.invoke(initial, config={"configurable": {"thread_id": thread_id}})
    return ModuleState.model_validate(result)


# ============================================================================
# Item 1: WB Module supports RCA (schema-level)
# ============================================================================


def test_wb_module_definition_supports_rca():
    definition = build_wb_module_package().module_definition
    assert TaskType.RCA in definition.supported_task_types


def test_wb_rca_key_questions_never_promise_a_definitive_root_cause():
    """Item 38's own explicit prohibition: never write "Determine the true
    causal root cause" -- plant-level WB data cannot back that up."""
    definition = build_wb_module_package().module_definition
    rca_style_questions = definition.key_questions[-3:]
    for question in rca_style_questions:
        assert "true causal" not in question.lower()
        assert "the root cause" not in question.lower() or "best" in question.lower() or "which" in question.lower()


# ============================================================================
# Golden Scenario A (item 40): ASE01 OEE, single-capability, no root cause
# ============================================================================


def test_scenario_a_oee_rca():
    final_state = _run_wb_rca("rca-a", "2026-08-12 ASE01 OEE 表現差 root cause")

    assert final_state.status == ModuleStatus.COMPLETE
    assert len(final_state.objective_history) == 1
    record = next(iter(final_state.objective_history.values()))
    assert record.capability_key == "wb.oee.plant_status"
    assert record.target_ref.ref_id == "ASE01"

    finding = final_state.findings[-1]
    assert "58.0" in finding.statement
    assert "downtime" in finding.statement
    assert finding.is_root_cause is False


# ============================================================================
# Golden Scenario B (item 41): ASE07 Output, multi-capability, causal
# candidate (material shortage)
# ============================================================================


def test_scenario_b_output_rca_finds_material_shortage_candidate():
    final_state = _run_wb_rca("rca-b", "2026-08-12 ASE07 output 偏低 root cause")

    assert final_state.status == ModuleStatus.COMPLETE
    chain = [r.capability_key for r in final_state.objective_history.values()]
    assert chain == ["wb.output.comparison", "wb.bank.status_summary"]  # stopped at the first supported candidate

    finding = final_state.findings[-1]
    assert "material shortage" in finding.statement.lower()
    assert "ASE07" in finding.statement
    assert finding.is_root_cause is False  # item 47: never a premature root cause


# ============================================================================
# Golden Scenario C (item 42): ASE03 WIP, pattern confirmed, cause
# unresolved
# ============================================================================


def test_scenario_c_wip_hold_rca():
    final_state = _run_wb_rca("rca-c", "2026-08-12 ASE03 WIP hold 異常 root cause")

    assert final_state.status == ModuleStatus.COMPLETE
    assert len(final_state.objective_history) == 1
    record = next(iter(final_state.objective_history.values()))
    assert record.capability_key == "wb.wip.hold_analysis"

    finding = final_state.findings[-1]
    assert "22/30" in finding.statement
    assert "73.3%" in finding.statement
    assert "not available" in finding.statement.lower() or "unresolved" in finding.statement.lower()
    assert finding.is_root_cause is False


# ============================================================================
# Golden Scenario D (item 43): ASE02 normal, premise rejected, early stop
# ============================================================================


def test_scenario_d_normal_premise_is_rejected_without_deep_dive():
    final_state = _run_wb_rca("rca-d", "2026-08-12 ASE02 OEE 異常 root cause")

    assert final_state.status == ModuleStatus.COMPLETE
    assert len(final_state.objective_history) == 1  # symptom check only -- no deep dive on a rejected premise

    finding = final_state.findings[-1]
    assert "no abnormal" in finding.statement.lower()
    assert "85.0" in finding.statement
    assert finding.is_root_cause is False


def test_scenario_d_efficiency_regression_fewer_objectives_than_abnormal_cases():
    """Item 57: the normal-premise case should need meaningfully fewer
    objectives than an abnormal one -- proof the Planner isn't blindly
    running a fixed-depth workflow regardless of what it finds."""
    normal_state = _run_wb_rca("rca-d-eff", "2026-08-12 ASE02 OEE 異常 root cause")
    abnormal_state = _run_wb_rca("rca-b-eff", "2026-08-12 ASE07 output 偏低 root cause")
    assert len(normal_state.objective_history) < len(abnormal_state.objective_history)


# ============================================================================
# Golden Scenario E (item 44): ASE08 missing OEE data
# ============================================================================


def test_scenario_e_missing_data_never_fakes_a_zero_or_a_root_cause():
    final_state = _run_wb_rca("rca-e", "2026-08-12 ASE08 OEE 異常 root cause")

    for finding in final_state.findings:
        assert "OEE = 0" not in finding.statement
        assert "OEE=0" not in finding.statement
        assert finding.is_root_cause is False

    assert final_state.status in (ModuleStatus.PARTIAL, ModuleStatus.FAILED)
    assert final_state.status != ModuleStatus.COMPLETE
    assert final_state.findings[-1].status == FindingStatus.HYPOTHESIS  # never CONFIRMED for a no-data round


def test_scenario_e_final_status_is_partial():
    """Same generic-completion-rule chain as WB-2C's Case F (module
    docstring 'Confirmation rule' note): Reflector always records a
    Finding on a SUCCESS+is_empty observation, so NO_VIABLE_OBJECTIVE
    naturally resolves to PARTIAL through the existing generic rule --
    no CompletionCheck modification needed for RCA either."""
    final_state = _run_wb_rca("rca-e-status", "2026-08-12 ASE08 OEE 異常 root cause")
    assert final_state.status == ModuleStatus.PARTIAL


# ============================================================================
# Item 45/46: dynamic replanning + contradiction proof, using ASE01's own
# real data (low Output, Bank normal, WIP normal, OEE abnormal) -- no
# synthetic/controlled DataSource fixture needed
# ============================================================================


def test_dynamic_replanning_walks_bank_then_wip_then_oee_on_contradicting_evidence():
    """The whole point of item 0's architecture question: this is NOT a
    fixed Output -> Bank -> done workflow. When Bank comes back NORMAL for
    ASE01 (unlike ASE07), the Planner does not persist with a rejected
    material-shortage hypothesis -- it moves to WIP, then (WIP also
    normal) to OEE, where it finds ASE01's real, independently-confirmed
    OEE abnormality (Golden Scenario A) and reports THAT as the supported
    candidate instead."""
    final_state = _run_wb_rca("rca-f", "2026-08-12 ASE01 output 偏低 root cause")

    assert final_state.status == ModuleStatus.COMPLETE
    chain = [r.capability_key for r in final_state.objective_history.values()]
    assert chain == ["wb.output.comparison", "wb.bank.status_summary", "wb.wip.hold_analysis", "wb.oee.plant_status"]

    finding = final_state.findings[-1]
    assert "equipment-side" in finding.statement.lower() or "oee" in finding.statement.lower()
    assert "material shortage" not in finding.statement.lower()  # the rejected hypothesis never survives to the final finding
    assert finding.is_root_cause is False


def test_bank_and_wip_normal_findings_appear_before_the_final_oee_finding():
    """Confirms each intermediate round genuinely reflects that round's
    own evidence (item 12's contradiction-handling requirement), not just
    the final answer -- Bank/WIP normal findings are real, recorded
    interim Findings, not silently skipped."""
    final_state = _run_wb_rca("rca-f-interim", "2026-08-12 ASE01 output 偏低 root cause")
    statements = [f.statement.lower() for f in final_state.findings]
    assert any("output was confirmed low" in s for s in statements)  # after round 1
    # some interim round must reflect "no elevated shortage"/"no abnormal wip" before the OEE finding closes it out
    assert any("no elevated material-shortage" in s for s in statements)
    assert any("no abnormal wip" in s for s in statements)


# ============================================================================
# Item 47: no premature root cause (regression)
# ============================================================================


def test_no_premature_root_cause_for_material_shortage():
    final_state = _run_wb_rca("rca-no-premature", "2026-08-12 ASE07 output 偏低 root cause")
    for finding in final_state.findings:
        assert finding.is_root_cause is False


def test_no_finding_ever_claims_is_root_cause_true_across_all_golden_scenarios():
    for thread_id, statement in [
        ("rca-guard-a", "2026-08-12 ASE01 OEE 表現差 root cause"),
        ("rca-guard-b", "2026-08-12 ASE07 output 偏低 root cause"),
        ("rca-guard-c", "2026-08-12 ASE03 WIP hold 異常 root cause"),
        ("rca-guard-d", "2026-08-12 ASE02 OEE 異常 root cause"),
    ]:
        final_state = _run_wb_rca(thread_id, statement)
        assert all(not f.is_root_cause for f in final_state.findings)


# ============================================================================
# Item 48: objective dedup
# ============================================================================


def test_objective_dedup_never_repeats_the_same_capability_target_scope():
    final_state = _run_wb_rca("rca-dedup", "2026-08-12 ASE01 output 偏低 root cause")
    seen = set()
    for record in final_state.objective_history.values():
        key = (record.capability_key, record.target_ref.ref_id, record.scope.time.date if record.scope and record.scope.time else None)
        assert key not in seen, f"capability {key} was dispatched more than once"
        seen.add(key)


# ============================================================================
# Item 23/26: EntityState updated to INVESTIGATING, never ROOT_CAUSE_FOUND
# ============================================================================


def test_target_plant_entity_state_becomes_investigating_never_root_cause_found():
    final_state = _run_wb_rca("rca-entity", "2026-08-12 ASE07 output 偏低 root cause")
    assert final_state.entity_states["ASE07"].status == EntityAnalysisStatus.INVESTIGATING
    for state in final_state.entity_states.values():
        assert state.status != EntityAnalysisStatus.ROOT_CAUSE_FOUND  # no plant-level data confirms a true root cause this phase


# ============================================================================
# Item 21: symptom validation -- Planner confirms the premise before
# investigating (both directions already covered above via Scenario D and
# the dynamic-replanning test; this asserts the general shape)
# ============================================================================


def test_first_objective_is_always_the_symptom_check_for_the_detected_topic():
    output_state = _run_wb_rca("rca-symptom-output", "2026-08-12 ASE07 output 偏低 root cause")
    first_record = next(iter(output_state.objective_history.values()))
    assert first_record.capability_key == "wb.output.comparison"

    oee_state = _run_wb_rca("rca-symptom-oee", "2026-08-12 ASE01 OEE 表現差 root cause")
    first_record = next(iter(oee_state.objective_history.values()))
    assert first_record.capability_key == "wb.oee.plant_status"
