from agent.state.enums import BranchStatus, ErrorType, ExecutionStrategy
from agent.state.models import Branch, ErrorRecord
from agent.state.reducers import append_list, merge_by_key


def test_append_list_concatenates_without_mutating_inputs():
    existing = [ErrorRecord(error_type=ErrorType.TIMEOUT, message="a", occurred_at_step=1)]
    update = [ErrorRecord(error_type=ErrorType.TOOL_ERROR, message="b", occurred_at_step=2)]

    merged = append_list(existing, update)

    assert [e.message for e in merged] == ["a", "b"]
    assert existing == [ErrorRecord(error_type=ErrorType.TIMEOUT, message="a", occurred_at_step=1)]


def test_merge_by_key_adds_new_keys_and_overwrites_existing():
    def make_branch(branch_id: str, status: BranchStatus) -> Branch:
        return Branch(
            branch_id=branch_id,
            name=branch_id,
            pattern="Availability Loss",
            status=status,
            execution_strategy=ExecutionStrategy.SEQUENTIAL,
            tree_node_id="node-1",
        )

    existing = {"b1": make_branch("b1", BranchStatus.PENDING), "b2": make_branch("b2", BranchStatus.ACTIVE)}
    update = {"b1": make_branch("b1", BranchStatus.COMPLETED), "b3": make_branch("b3", BranchStatus.PENDING)}

    merged = merge_by_key(existing, update)

    assert merged["b1"].status == BranchStatus.COMPLETED
    assert merged["b2"].status == BranchStatus.ACTIVE
    assert merged["b3"].status == BranchStatus.PENDING
    assert existing["b1"].status == BranchStatus.PENDING
