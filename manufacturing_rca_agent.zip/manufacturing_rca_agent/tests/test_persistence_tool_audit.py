"""Phase 8A item 23.C: physical Tool attempts are preserved in full through
the audit sink -- the final ModuleState projection (which can lose a
duplicate physical execution to `merge_by_key`'s whole-value overwrite,
per agent/tools/execution_manager.py's own documented finding) is never
the source of truth for this; the `ToolCallAuditSink` is.
"""
from datetime import datetime, timezone

from agent.persistence.audit_repository import build_default_audit_repository
from agent.state.enums import ObservationStatus
from agent.state.models import ToolCallRecord


def _now():
    return datetime.now(timezone.utc)


def _record(tool_call_id, run_id, attempt_number, replayed, result_reused):
    return ToolCallRecord(
        tool_call_id=tool_call_id, run_id=run_id, module_id="OEE", objective_id="o1", tool_id="query_oee_data",
        status=ObservationStatus.SUCCESS, duration_seconds=0.1, started_at=_now(), completed_at=_now(),
        idempotency_key="shared-key", logical_call_id="OEE-o1-query_oee_data", attempt_number=attempt_number,
        replayed=replayed, result_reused=result_reused,
    )


def test_two_physical_attempts_both_persist_distinctly():
    audit_repo = build_default_audit_repository()
    audit_repo.tool_call_sink.record(_record("tc-1", "run-1", 1, replayed=False, result_reused=False))
    audit_repo.tool_call_sink.record(_record("tc-2", "run-1", 2, replayed=True, result_reused=False))  # a genuine second physical execution, not a cache hit

    records = audit_repo.tool_call_sink.list_for_run("run-1")
    assert len(records) == 2  # both physical attempts preserved, never collapsed into one
    assert {r.tool_call_id for r in records} == {"tc-1", "tc-2"}
    assert sum(1 for r in records if not r.result_reused) == 2  # both really executed


def test_tool_call_sink_scoped_by_run_id():
    audit_repo = build_default_audit_repository()
    audit_repo.tool_call_sink.record(_record("tc-1", "run-1", 1, replayed=False, result_reused=False))
    audit_repo.tool_call_sink.record(_record("tc-2", "run-2", 1, replayed=False, result_reused=False))

    assert [r.tool_call_id for r in audit_repo.tool_call_sink.list_for_run("run-1")] == ["tc-1"]
    assert [r.tool_call_id for r in audit_repo.tool_call_sink.list_for_run("run-2")] == ["tc-2"]
