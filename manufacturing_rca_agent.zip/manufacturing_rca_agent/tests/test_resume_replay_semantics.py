"""Phase 5B-1.1: pin the actual trigger for successful-sibling
re-execution, measured via external invocation counters -- never by
normalizing away or comparing final-state equality (that's what
test_phase4b2_human_gate.py's `_drop_tool_call_timestamps` is for, and it
answers a different question: "is the business state still correct", not
"did the branch physically re-run").

Finding, isolated across two topologies (flat Send vs. our production
nested-wrapper pattern) x three variants (no update_state / one call / two
calls):

  - With ZERO `app.update_state()` calls between interrupt and resume,
    a successful sibling's pending write IS correctly reused -- it is
    NOT re-executed, in either topology. This matches LangGraph's
    documented persistence semantics exactly.
  - The MOMENT `app.update_state()` is called on a checkpoint that still
    has a pending Send task (interrupted), resuming re-executes EVERY
    task from that pending superstep -- not just the interrupted one, and
    (in the nested topology) not just the interrupted step within the
    interrupted branch's own subgraph. A second update_state() call adds
    no further effect beyond the first.
  - The nested "wrapper calls child_app.invoke()" pattern is NOT the
    cause -- the flat topology (no nested subgraph at all) shows the
    exact same on/off behavior tied to update_state().

Mechanism (see the Phase 5B-1.1 report for the raw checkpoint dump):
calling `update_state()` while a Send-derived task list is still pending
causes LangGraph to write a new checkpoint whose `__pregel_tasks` bookkeeping
re-lists *every* originally-dispatched Send task under the update_state()
call's own task id -- superseding the sibling's already-completed pending
write, which was filed under a different task id.
"""
from typing import Annotated

from langchain_core.runnables import RunnableConfig
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command, Send, interrupt
from pydantic import BaseModel

from agent.graph.graph import build_phase2_graph
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.planning.policies.mock import DeterministicMockPolicy, PermissionSpec, Requirement
from agent.state.enums import EvidenceQuality, HumanDecision, ObservationStatus, RiskLevel
from agent.tools.base import ToolResult
from agent.tools.mocks.scripted_tool import ScriptedMockTool

from .conftest import make_agent_state, make_budget


def _append(existing, update):
    return [*existing, *update]


def _merge(existing, update):
    return {**existing, **update}


# ============================================================================
# Flat topology: Send -> single node per branch, no nested child graph
# ============================================================================


class _FlatChildState(BaseModel):
    model_config = {"extra": "forbid"}
    child_id: str
    log: Annotated[list, _append] = []


class _FlatParentState(BaseModel):
    model_config = {"extra": "forbid"}
    child_ids: list[str] = []
    results: Annotated[dict, _merge] = {}


def _build_flat_app(counters: dict, checkpointer):
    def flat_node(state: _FlatChildState) -> dict:
        counters[state.child_id] = counters.get(state.child_id, 0) + 1
        if state.child_id == "A":
            answer = interrupt({"q": "approve?"})
            return {"results": {"A": f"resumed-{answer}"}}
        return {"results": {state.child_id: "done"}}

    def dispatch(state: _FlatParentState):
        return [Send("flat_node", _FlatChildState(child_id=cid)) for cid in state.child_ids]

    def entry(state):
        return {}

    g = StateGraph(_FlatParentState)
    g.add_node("entry", entry)
    g.add_node("flat_node", flat_node)
    g.add_edge(START, "entry")
    g.add_conditional_edges("entry", dispatch, ["flat_node"])
    g.add_edge("flat_node", END)
    return g.compile(checkpointer=checkpointer)


def _run_flat(update_state_calls: int) -> dict:
    counters: dict = {}
    checkpointer = InMemorySaver()
    app = _build_flat_app(counters, checkpointer)
    config = {"configurable": {"thread_id": f"flat-{update_state_calls}"}}

    app.invoke(_FlatParentState(child_ids=["A", "B"]), config=config)
    for _ in range(update_state_calls):
        app.update_state(config, {"results": {"_marker": "x"}})
    app.invoke(Command(resume="approved"), config=config)
    return counters


def test_flat_topology_sibling_not_reexecuted_without_update_state():
    counters = _run_flat(update_state_calls=0)
    assert counters == {"A": 2, "B": 1}  # A resumes once more (expected); B never reruns


def test_flat_topology_sibling_reexecuted_after_one_update_state_call():
    counters = _run_flat(update_state_calls=1)
    assert counters == {"A": 2, "B": 2}


def test_flat_topology_second_update_state_call_adds_no_further_effect():
    counters = _run_flat(update_state_calls=2)
    assert counters == {"A": 2, "B": 2}  # same as a single call, not worse


# ============================================================================
# Nested-wrapper topology: matches production module_subgraph_node.py --
# Send -> wrapper function -> nested child_app.invoke(state, config)
# ============================================================================


class _NestedChildState(BaseModel):
    model_config = {"extra": "forbid"}
    child_id: str
    log: Annotated[list, _append] = []


def _build_nested_child_graph(counters: dict):
    def step1(state: _NestedChildState) -> dict:
        counters[f"{state.child_id}:step1"] = counters.get(f"{state.child_id}:step1", 0) + 1
        return {"log": [f"{state.child_id}-step1"]}

    def step2(state: _NestedChildState) -> dict:
        counters[f"{state.child_id}:step2"] = counters.get(f"{state.child_id}:step2", 0) + 1
        if state.child_id == "A":
            answer = interrupt({"q": "approve?"})
            return {"log": [f"{state.child_id}-step2-resumed-{answer}"]}
        return {"log": [f"{state.child_id}-step2-done"]}

    g = StateGraph(_NestedChildState)
    g.add_node("step1", step1)
    g.add_node("step2", step2)
    g.add_edge(START, "step1")
    g.add_edge("step1", "step2")
    g.add_edge("step2", END)
    return g


class _NestedParentState(BaseModel):
    model_config = {"extra": "forbid"}
    child_ids: list[str] = []
    results: Annotated[dict, _merge] = {}


def _build_nested_app(counters: dict, checkpointer):
    def wrapper(payload: dict, config: RunnableConfig) -> dict:
        counters[f"{payload['child_id']}:wrapper"] = counters.get(f"{payload['child_id']}:wrapper", 0) + 1
        child_app = _build_nested_child_graph(counters).compile(checkpointer=checkpointer)
        result = child_app.invoke(_NestedChildState(child_id=payload["child_id"]), config)
        return {"results": {payload["child_id"]: result}}

    def dispatch(state: _NestedParentState):
        return [Send("wrapper", {"child_id": cid}) for cid in state.child_ids]

    def entry(state):
        return {}

    g = StateGraph(_NestedParentState)
    g.add_node("entry", entry)
    g.add_node("wrapper", wrapper)
    g.add_edge(START, "entry")
    g.add_conditional_edges("entry", dispatch, ["wrapper"])
    g.add_edge("wrapper", END)
    return g.compile(checkpointer=checkpointer)


def _run_nested(update_state_calls: int) -> dict:
    counters: dict = {}
    checkpointer = InMemorySaver()
    app = _build_nested_app(counters, checkpointer)
    config = {"configurable": {"thread_id": f"nested-{update_state_calls}"}}

    app.invoke(_NestedParentState(child_ids=["A", "B"]), config=config)
    for _ in range(update_state_calls):
        app.update_state(config, {"results": {"_marker": "x"}})
    app.invoke(Command(resume="approved"), config=config)
    return counters


def test_nested_wrapper_topology_sibling_not_reexecuted_without_update_state():
    counters = _run_nested(update_state_calls=0)
    # B's wrapper + both internal steps: untouched. A's step1 (already
    # completed before A's own interrupt) is ALSO untouched -- only A's
    # step2 (where interrupt() actually lives) replays.
    assert counters == {
        "A:wrapper": 2, "A:step1": 1, "A:step2": 2,
        "B:wrapper": 1, "B:step1": 1, "B:step2": 1,
    }


def test_nested_wrapper_topology_sibling_reexecuted_after_update_state():
    counters = _run_nested(update_state_calls=1)
    # now EVERYTHING in the pending superstep reruns, including A's step1
    assert counters == {
        "A:wrapper": 2, "A:step1": 2, "A:step2": 2,
        "B:wrapper": 2, "B:step1": 2, "B:step2": 2,
    }


# ============================================================================
# Production-realistic confirmation: real build_phase2_graph, spy-wrapped
# tools counting PHYSICAL Tool.run() calls (not final-state comparison).
# ============================================================================


class _SpyTool:
    def __init__(self, inner, label: str, counters: dict):
        self.inner = inner
        self.label = label
        self.counters = counters

    def run(self, objective):
        self.counters[self.label] = self.counters.get(self.label, 0) + 1
        return self.inner.run(objective)


def _production_runtime(counters: dict) -> dict[str, ModuleRuntimeConfig]:
    return {
        "OEE": ModuleRuntimeConfig(
            policy=DeterministicMockPolicy(
                requirements=[
                    Requirement(
                        sources=["restricted"],
                        sufficiency_evidence_count=1,
                        restricted_sources={
                            "restricted": PermissionSpec(permission_type="maintenance_db_access", risk_level=RiskLevel.HIGH)
                        },
                    )
                ]
            ),
            tool=_SpyTool(
                ScriptedMockTool({"restricted": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}),
                "OEE",
                counters,
            ),
            budget=make_budget(max_steps=3, max_tool_calls=3, max_depth_per_entity=2),
        ),
        "Output": ModuleRuntimeConfig(
            policy=DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1),
            tool=_SpyTool(
                ScriptedMockTool({"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}),
                "Output",
                counters,
            ),
            budget=make_budget(max_steps=3, max_tool_calls=3, max_depth_per_entity=2),
        ),
        "WIP": ModuleRuntimeConfig(
            policy=DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1),
            tool=_SpyTool(
                ScriptedMockTool({"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}),
                "WIP",
                counters,
            ),
            budget=make_budget(max_steps=3, max_tool_calls=3, max_depth_per_entity=2),
        ),
    }


def _run_production(*, call_update_state: bool):
    counters: dict = {}
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(_production_runtime(counters), checkpointer)
    app = graph.compile(checkpointer=checkpointer)

    initial_state = make_agent_state()
    config = {"configurable": {"thread_id": initial_state.run_id}}

    app.invoke(initial_state, config=config)
    if call_update_state:
        app.update_state(config, {"human_requests": {}})
    result2 = app.invoke(Command(resume={"decision": HumanDecision.APPROVE.value}), config=config)
    return counters, result2


def test_production_graph_sibling_tools_not_physically_recalled_without_update_state():
    counters, _ = _run_production(call_update_state=False)
    assert counters == {"Output": 1, "WIP": 1, "OEE": 1}


def test_production_graph_sibling_tools_are_physically_recalled_after_update_state():
    counters, _ = _run_production(call_update_state=True)
    assert counters == {"Output": 2, "WIP": 2, "OEE": 1}


def test_final_module_state_tool_calls_count_does_not_reveal_the_duplicate_execution():
    """This is the concrete danger the Tool Safety Contract exists for:
    module_states uses merge_by_key (whole-value-per-key), so a module's
    SECOND physical execution simply replaces the first's ModuleState --
    the audit trail inside final state alone cannot tell you Output's tool
    actually ran twice, even though it demonstrably did (see the counters
    assertion above, from the SAME run)."""
    counters, result2 = _run_production(call_update_state=True)
    assert counters["Output"] == 2  # ground truth: it ran twice

    output_state = result2["module_states"]["Output"]
    assert len(output_state.tool_calls) == 1  # but the final state only shows one
