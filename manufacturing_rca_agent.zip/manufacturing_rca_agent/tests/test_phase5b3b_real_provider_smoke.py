"""Phase 5B-3B: real-provider smoke tests -- the only tests in this suite
that make a real network call to a real LLM provider (Anthropic). Skipped
entirely (not failed) when `ANTHROPIC_API_KEY` is not set, so the rest of
the suite (MockLLMClient-based) always passes in any environment,
including this one, without a secret.

Synthetic/simple requests only -- no factory raw data. Only semantic
results (TaskType + which modules) are asserted, never exact wording of
`reasoning_summary`/rationale (those are audit-only, per Phase 5B-3B's
"routing never depends on free text" rule) -- real LLM phrasing is not
reproducible byte-for-byte.
"""
import os

import pytest
from langgraph.checkpoint.memory import InMemorySaver

from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD, CurrentOEEStatus
from agent.graph.graph import build_phase2_graph
from agent.graph.nodes.analyzer_llm import AnalyzerLLMService, DecisionSource, make_analyzer_llm_node
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.llm.config import LLMRouteConfig
from agent.llm.context.analyzer_context import AnalyzerContextBuilder
from agent.llm.models import LLMCallStatus
from agent.llm.providers.anthropic_adapter import AnthropicAdapter
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.planning.policies.mock import DeterministicMockPolicy
from agent.planning.policies.oee import OEEPlanningPolicy
from agent.state.enums import EvidenceQuality, FindingStatus, ModuleStatus, ObservationStatus, RunTerminationStatus, TaskType
from agent.state.payload import PayloadRegistry
from agent.state.state import AgentState
from agent.tools.base import ToolResult
from agent.tools.mocks.scripted_tool import ScriptedMockTool

from .conftest import make_agent_state, make_budget, make_module_registry, make_oee_capability_runtime

pytestmark = pytest.mark.skipif(
    not os.environ.get("ANTHROPIC_API_KEY"),
    reason="ANTHROPIC_API_KEY not set -- real-provider smoke tests skipped (not failed) without a secret",
)

_MODEL = "claude-haiku-4-5-20251001"


def _real_service() -> tuple[AnalyzerLLMService, InMemoryLLMUsageSink]:
    registry = make_module_registry()
    usage_sink = InMemoryLLMUsageSink()
    router = LLMRouter(
        routes={"analyzer": LLMRouteConfig(route="analyzer", model=_MODEL, timeout_seconds=30.0, max_retries=1)},
        client=AnthropicAdapter(),
        usage_sink=usage_sink,
    )
    service = AnalyzerLLMService(registry, AnalyzerContextBuilder(registry), router)
    return service, usage_sink


def _assert_real_usage_recorded(usage_sink: InMemoryLLMUsageSink, run_id: str) -> None:
    records = usage_sink.list_for_run(run_id)
    assert records
    record = records[-1]  # the successful attempt, if any retries happened
    assert record.model == _MODEL
    assert record.status in (LLMCallStatus.SUCCESS, LLMCallStatus.INVALID_OUTPUT, LLMCallStatus.TIMEOUT, LLMCallStatus.PROVIDER_ERROR)
    assert record.latency_ms >= 0
    assert record.retry_count >= 0
    # real usage numbers are provider-reported, not fabricated -- 0 is a
    # legitimate value for a failed attempt, only assert non-negative
    assert record.input_tokens >= 0
    assert record.output_tokens >= 0
    assert record.estimated_cost is None  # no pricing config wired up this phase


# ============================================================================
# Semantic Analyzer decision cases (item 6)
# ============================================================================


def test_real_information_single_module():
    service, usage_sink = _real_service()
    outcome = service.decide(make_agent_state(run_id="smoke-info", raw_text="今天平均 OEE 多少？"))

    assert outcome.source == DecisionSource.LLM, outcome.fallback_reason
    assert outcome.decision.task_type == TaskType.INFORMATION
    assert "OEE" in {m.module_type for m in outcome.decision.selected_modules}
    _assert_real_usage_recorded(usage_sink, "smoke-info")


def test_real_analysis_single_module():
    service, usage_sink = _real_service()
    outcome = service.decide(make_agent_state(run_id="smoke-analysis", raw_text="哪些設備 OEE 比較差？"))

    assert outcome.source == DecisionSource.LLM, outcome.fallback_reason
    assert outcome.decision.task_type == TaskType.ANALYSIS
    assert "OEE" in {m.module_type for m in outcome.decision.selected_modules}
    _assert_real_usage_recorded(usage_sink, "smoke-analysis")


def test_real_rca_single_module():
    service, usage_sink = _real_service()
    outcome = service.decide(make_agent_state(run_id="smoke-rca-single", raw_text="為什麼今天 OEE 下降？"))

    assert outcome.source == DecisionSource.LLM, outcome.fallback_reason
    assert outcome.decision.task_type == TaskType.RCA
    assert "OEE" in {m.module_type for m in outcome.decision.selected_modules}
    _assert_real_usage_recorded(usage_sink, "smoke-rca-single")


def test_real_rca_multi_module():
    service, usage_sink = _real_service()
    outcome = service.decide(make_agent_state(run_id="smoke-rca-multi", raw_text="為什麼今天產出不足？"))

    assert outcome.source == DecisionSource.LLM, outcome.fallback_reason
    assert outcome.decision.task_type == TaskType.RCA
    selected = {m.module_type for m in outcome.decision.selected_modules}
    # no fixed ordering required, but must be semantically plausible and
    # must pass semantic validation (already enforced by the service) --
    # Output is the module most directly about "产出" (output)
    assert selected <= {"Output", "OEE", "WIP"}
    assert "Output" in selected
    _assert_real_usage_recorded(usage_sink, "smoke-rca-multi")


# ============================================================================
# End-to-end: real LLM Analyzer -> deterministic Harness/Capability path
# ============================================================================


def _legacy_runtime() -> ModuleRuntimeConfig:
    return ModuleRuntimeConfig(
        policy=DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1),
        tool=ScriptedMockTool({"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}),
        budget=make_budget(max_steps=3, max_tool_calls=5, max_depth_per_entity=2),
    )


def _module_runtime() -> dict[str, ModuleRuntimeConfig]:
    return {
        "OEE": ModuleRuntimeConfig(
            policy=OEEPlanningPolicy(),
            capability=make_oee_capability_runtime(MOCK_EQUIPMENT, OEE_THRESHOLD),
            budget=make_budget(max_steps=6, max_tool_calls=20, max_depth_per_entity=3),
        ),
        "Output": _legacy_runtime(),
        "WIP": _legacy_runtime(),
    }


def test_real_llm_analyzer_information_end_to_end_reaches_current_status_complete():
    service, usage_sink = _real_service()
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(_module_runtime(), checkpointer, analyzer=make_analyzer_llm_node(service))
    app = graph.compile(checkpointer=checkpointer)

    run_id = "smoke-e2e-info"
    result = app.invoke(make_agent_state(run_id=run_id, raw_text="今天平均 OEE 多少？"), config={"configurable": {"thread_id": run_id}})
    final_state = AgentState.model_validate(result)

    assert final_state.global_goal.task_type == TaskType.INFORMATION
    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.COMPLETE
    status = PayloadRegistry.unpack(oee.evidence[0].structured_payload)
    assert isinstance(status, CurrentOEEStatus)
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS
    _assert_real_usage_recorded(usage_sink, run_id)


def test_real_llm_analyzer_rca_end_to_end_reaches_motor_failure_complete():
    service, usage_sink = _real_service()
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(_module_runtime(), checkpointer, analyzer=make_analyzer_llm_node(service))
    app = graph.compile(checkpointer=checkpointer)

    run_id = "smoke-e2e-rca"
    result = app.invoke(make_agent_state(run_id=run_id, raw_text="為什麼今天 OEE 下降？"), config={"configurable": {"thread_id": run_id}})
    final_state = AgentState.model_validate(result)

    assert final_state.global_goal.task_type == TaskType.RCA
    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.COMPLETE
    final_finding = oee.findings[-1]
    assert final_finding.status == FindingStatus.CONFIRMED
    assert final_finding.is_root_cause is True
    assert "Motor Failure" in final_finding.pattern
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS
    _assert_real_usage_recorded(usage_sink, run_id)
