"""Phase 7A: RunEvaluation/EvaluationIssue/HumanFeedback/EvaluationWeighting
schema contracts.
"""
import pytest
from pydantic import ValidationError

from agent.state.enums import EvaluationCategory, EvaluationSeverity, HumanFeedbackThumbs
from agent.state.models import EvaluationIssue, EvaluationWeighting, HumanFeedback, RunEvaluation


def test_evaluation_weighting_default_sums_to_one():
    weighting = EvaluationWeighting()
    assert abs(weighting.analytical_quality + weighting.decision_quality + weighting.delivery_quality + weighting.efficiency - 1.0) < 1e-9


def test_evaluation_weighting_rejects_weights_not_summing_to_one():
    with pytest.raises(ValidationError):
        EvaluationWeighting(analytical_quality=0.5, decision_quality=0.5, delivery_quality=0.5, efficiency=0.5)


def test_evaluation_weighting_is_a_config_not_hardcoded_singleton():
    """Proves an alternative weighting strategy is a normal, first-class
    construction -- not something special-cased anywhere."""
    custom = EvaluationWeighting(analytical_quality=0.25, decision_quality=0.25, delivery_quality=0.25, efficiency=0.25)
    assert custom.efficiency == 0.25


def test_run_evaluation_top_level_fields():
    assert set(RunEvaluation.model_fields.keys()) == {
        "evaluation_id", "run_id", "evaluator_version", "evaluated_at", "efficiency", "analytical_quality", "decision_quality",
        "delivery_quality", "issues", "weighting", "overall_score", "schema_version",
    }


def test_run_evaluation_overall_score_is_optional():
    """The spec's explicit instruction: a first version can skip
    overall_score entirely and still be a complete RunEvaluation."""
    from agent.state.models import (
        AnalyticalQualityMetrics,
        AnalyzerDecisionQuality,
        DecisionQualityMetrics,
        DeliveryQualityMetrics,
        EfficiencyMetrics,
        PlannerDecisionQualityAggregate,
    )
    from datetime import datetime, timezone

    evaluation = RunEvaluation(
        evaluation_id="eval-1", run_id="run-1", evaluator_version="test", evaluated_at=datetime.now(timezone.utc),
        efficiency=EfficiencyMetrics(
            total_module_count=1, completed_module_count=1, planner_decision_count=0, objective_count=0,
            logical_tool_call_count=0, tool_manager_invocation_count=0, physical_tool_execution_count=0,
            result_reuse_count=0, replay_count=0, failed_tool_execution_count=0, total_llm_calls=0,
            llm_retry_count=0, input_tokens=0, output_tokens=0, total_context_characters=0, context_trim_count=0,
            human_intervention_count=0,
        ),
        analytical_quality=AnalyticalQualityMetrics(
            evidence_coverage=1.0, confirmed_finding_ratio=1.0, root_cause_support_score=1.0, limitation_transparency_score=1.0,
            unresolved_question_transparency=1.0, failed_module_ratio=0.0, blocked_module_ratio=0.0, partial_module_ratio=0.0,
            synthesis_fact_consistency=1.0, cross_module_relation_support_score=1.0,
        ),
        decision_quality=DecisionQualityMetrics(
            analyzer=AnalyzerDecisionQuality(selected_module_count=1, module_selection_validity=1.0, unsupported_module_selection_count=0, analyzer_fallback_used=False),
            planner=PlannerDecisionQualityAggregate(invalid_decision_count=0, fallback_decision_count=0, redundant_target_count=0, unnecessary_deep_dive_count=0),
        ),
        delivery_quality=DeliveryQualityMetrics(
            request_answered_score=1.0, module_result_coverage=1.0, root_cause_lineage_validity=1.0, limitation_preservation=1.0,
            task_type_depth_compliance=1.0, synthesis_status_consistency=1.0, hallucination_guard_passed=True,
        ),
    )
    assert evaluation.overall_score is None
    assert evaluation.weighting is None


def test_evaluation_issue_field_set_is_closed():
    assert set(EvaluationIssue.model_fields.keys()) == {
        "issue_id", "category", "severity", "statement", "related_module_ids", "related_objective_ids",
        "metric_name", "evidence_refs", "suggested_improvement_area",
    }


def test_evaluation_issue_category_and_severity_are_typed():
    issue = EvaluationIssue(
        issue_id="i1", category=EvaluationCategory.EFFICIENCY, severity=EvaluationSeverity.LOW,
        statement="x", metric_name="context_trim_count", suggested_improvement_area="budget tuning",
    )
    assert issue.category == EvaluationCategory.EFFICIENCY
    assert issue.severity == EvaluationSeverity.LOW


def test_human_feedback_field_set_and_default_thumbs():
    from datetime import datetime, timezone

    from agent.state.enums import FeedbackTargetType

    feedback = HumanFeedback(feedback_id="f1", run_id="run-1", target_type=FeedbackTargetType.RUN, created_at=datetime.now(timezone.utc))
    assert feedback.thumbs == HumanFeedbackThumbs.NONE
    assert set(HumanFeedback.model_fields.keys()) == {
        "feedback_id", "run_id", "target_type", "target_id", "user_id", "thumbs", "answer_helpful",
        "root_cause_correct", "finding_correct", "recommendation_useful", "comment", "source",
        "session_id", "feedback_version", "created_at",
    }
