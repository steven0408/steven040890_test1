"""FakeConnection/FakeCursor -- a minimal stand-in for a psycopg3
connection (`.execute(sql, params) -> cursor`, `cursor.fetchone()`/
`fetchall()`, `.commit()`/`.rollback()`), used by every offline (always-run)
Phase 8B test so `agent/persistence/postgres/repositories.py` and
`unit_of_work.py` are exercised without the `postgres` extra installed and
without a real database. Not itself a test module (no `test_` prefix --
pytest never collects it).

Two ways to use it:
  - Inspect `.executed` (a list of `(sql, params)` tuples) to assert what
    SQL/parameters a repository method produced.
  - Call `.set_fetchone(row)`/`.set_fetchall(rows)` before invoking a
    repository's read method to hand back a canned row/rows on the NEXT
    `execute()` call.

This is a recorder/stub, not a real relational engine -- it does not
interpret WHERE clauses, JOINs, or constraints. Full round-trip
correctness (a real INSERT followed by a real SELECT reflecting it) is
proven separately by the `@pytest.mark.postgres`-gated integration tests
against an actual PostgreSQL instance.
"""
from typing import Any


class FakeCursor:
    def __init__(self, rows: list[dict] | None = None):
        self._rows = rows or []

    def fetchone(self) -> dict | None:
        return self._rows[0] if self._rows else None

    def fetchall(self) -> list[dict]:
        return list(self._rows)


class FakeConnection:
    def __init__(self):
        self.executed: list[tuple[str, dict]] = []
        self.committed = False
        self.rolled_back = False
        self._next_rows: list[dict] | None = None

    def set_fetchone(self, row: dict | None) -> None:
        self._next_rows = [row] if row is not None else []

    def set_fetchall(self, rows: list[dict]) -> None:
        self._next_rows = list(rows)

    def execute(self, sql: str, params: dict[str, Any] | None = None) -> FakeCursor:
        self.executed.append((sql, dict(params or {})))
        rows = self._next_rows if self._next_rows is not None else []
        self._next_rows = None
        return FakeCursor(rows)

    def commit(self) -> None:
        self.committed = True

    def rollback(self) -> None:
        self.rolled_back = True

    # --- assertion helpers -------------------------------------------------

    def last_sql(self) -> str:
        return self.executed[-1][0]

    def sql_statements(self) -> list[str]:
        return [sql for sql, _ in self.executed]
