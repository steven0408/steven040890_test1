"""Phase PROD-1.1: LLMRouter's preflight Context Budget guard -- offline,
no real provider. Reproduces the production-observed condition (item 2):
an oversized request must never reach the client at all under a small
context_window_tokens profile."""
import pytest

from agent.llm.client import MockLLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.models import LLMCallStatus, LLMMessage, LLMRole
from agent.llm.router import LLMRouter, LLMRouterError
from agent.llm.token_budget import LLMContextBudgetExceededError, LLMContextProfile, RouteTokenBudget
from agent.llm.usage import InMemoryLLMUsageSink
from agent.state.base import RCABaseModel


class _Echo(RCABaseModel):
    value: str


def _router(context_profile=None, responder=None):
    usage_sink = InMemoryLLMUsageSink()
    client = MockLLMClient(responder or (lambda req: _Echo(value="ok")))
    router = LLMRouter(
        routes={"planner": LLMRouteConfig(route="planner", model="mock", max_retries=1)},
        client=client, usage_sink=usage_sink, context_profile=context_profile,
    )
    return router, usage_sink, client


def test_no_profile_configured_means_no_preflight_check_at_all():
    """Backward compatibility: every pre-existing caller (no context_profile
    passed) gets byte-identical behavior -- even a huge message list succeeds."""
    router, _, _ = _router(context_profile=None)
    huge_messages = [LLMMessage(role=LLMRole.USER, content="x" * 100_000)]
    outcome = router.call("planner", huge_messages, _Echo, run_id="r1", module_id=None, node="test")
    assert outcome.parsed_output == _Echo(value="ok")


def test_oversized_request_under_small_window_is_rejected_before_any_client_call():
    """Reproduces item 2's production condition: PlannerDecision-shaped
    input (large) against context_window_tokens=2048."""
    profile = LLMContextProfile(
        context_window_tokens=2048,
        route_budgets={"planner": RouteTokenBudget(max_output_tokens=650, minimum_output_tokens=150, safety_margin_tokens=128)},
    )
    call_count = 0

    def _responder(req):
        nonlocal call_count
        call_count += 1
        return _Echo(value="should never be reached")

    router, usage_sink, client = _router(context_profile=profile, responder=_responder)
    # ~5352 production-observed PlannerDecision prompt tokens, reproduced
    # via a large synthetic message (chars/3.5 ≈ tokens with this estimator).
    oversized_messages = [LLMMessage(role=LLMRole.USER, content="word " * 4000)]

    with pytest.raises(LLMRouterError) as exc_info:
        router.call("planner", oversized_messages, _Echo, run_id="r1", module_id=None, node="module_planner")

    assert isinstance(exc_info.value.last_error, LLMContextBudgetExceededError)
    assert call_count == 0  # the client (and therefore the network) was NEVER invoked
    assert len(client.calls) == 0

    records = usage_sink.list_for_run("r1")
    assert len(records) == 1
    assert records[0].status == LLMCallStatus.CONTEXT_BUDGET_EXCEEDED
    assert records[0].retry_count == 0


def test_small_request_under_small_window_succeeds():
    profile = LLMContextProfile(
        context_window_tokens=2048,
        route_budgets={"planner": RouteTokenBudget(max_output_tokens=650, minimum_output_tokens=150, safety_margin_tokens=128)},
    )
    router, usage_sink, _ = _router(context_profile=profile)
    small_messages = [LLMMessage(role=LLMRole.SYSTEM, content="be concise"), LLMMessage(role=LLMRole.USER, content="what is the goal?")]

    outcome = router.call("planner", small_messages, _Echo, run_id="r2", module_id=None, node="module_planner")
    assert outcome.parsed_output == _Echo(value="ok")
    records = usage_sink.list_for_run("r2")
    assert records[-1].status == LLMCallStatus.SUCCESS


def test_larger_window_profile_allows_the_same_request_that_a_small_window_rejects():
    """Item 52: same code, more optional context fits under a larger window
    -- no separate code path."""
    oversized_messages = [LLMMessage(role=LLMRole.USER, content="word " * 4000)]

    small_profile = LLMContextProfile(context_window_tokens=2048, route_budgets={"planner": RouteTokenBudget(max_output_tokens=650, minimum_output_tokens=150, safety_margin_tokens=128)})
    small_router, _, _ = _router(context_profile=small_profile)
    with pytest.raises(LLMRouterError):
        small_router.call("planner", oversized_messages, _Echo, run_id="r3", module_id=None, node="test")

    large_profile = LLMContextProfile(context_window_tokens=32000, route_budgets={"planner": RouteTokenBudget(max_output_tokens=650, minimum_output_tokens=150, safety_margin_tokens=128)})
    large_router, _, _ = _router(context_profile=large_profile)
    outcome = large_router.call("planner", oversized_messages, _Echo, run_id="r4", module_id=None, node="test")
    assert outcome.parsed_output == _Echo(value="ok")


def test_extreme_small_window_rejects_even_minimal_request():
    """Item 53: window=512 with a real route budget -- typed budget error,
    never a mysterious LLM failure, even for the smallest realistic request."""
    profile = LLMContextProfile(context_window_tokens=512, route_budgets={"planner": RouteTokenBudget(max_output_tokens=600, minimum_output_tokens=150, safety_margin_tokens=64)})
    router, _, client = _router(context_profile=profile)
    messages = [LLMMessage(role=LLMRole.USER, content="short")]
    with pytest.raises(LLMRouterError) as exc_info:
        router.call("planner", messages, _Echo, run_id="r5", module_id=None, node="test")
    assert isinstance(exc_info.value.last_error, LLMContextBudgetExceededError)
    assert len(client.calls) == 0
    # even reserved output alone (600) exceeds the window (512) -- this is
    # a configuration-incompatibility case (item 50/54), not an input-size
    # problem at all.
    assert profile.available_input_tokens("planner") < 0


def test_context_budget_exceeded_error_never_triggers_a_retry():
    """Item 56: context overflow gets NO network retry -- confirmed by
    call_count staying at 0 even though max_retries=1 (would be 2 attempts
    for a normal failure)."""
    profile = LLMContextProfile(context_window_tokens=2048, route_budgets={"planner": RouteTokenBudget(max_output_tokens=650, minimum_output_tokens=150, safety_margin_tokens=128)})
    call_count = 0

    def _responder(req):
        nonlocal call_count
        call_count += 1
        return _Echo(value="x")

    router, _, _ = _router(context_profile=profile, responder=_responder)
    oversized_messages = [LLMMessage(role=LLMRole.USER, content="word " * 4000)]
    with pytest.raises(LLMRouterError):
        router.call("planner", oversized_messages, _Echo, run_id="r6", module_id=None, node="test")
    assert call_count == 0
