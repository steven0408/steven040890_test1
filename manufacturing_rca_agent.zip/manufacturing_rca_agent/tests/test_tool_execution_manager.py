from datetime import datetime, timedelta, timezone

from agent.state.enums import ObservationStatus
from agent.state.payload import StructuredPayload
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.models import (
    ExecutionType,
    Tool,
    ToolCategory,
    ToolDefinition,
    ToolExecutionIdentity,
    ToolExecutionRequest,
    ToolExecutionResult,
    ToolIOSchema,
    ToolSideEffect,
)

_NOW = datetime(2026, 8, 9, tzinfo=timezone.utc)
_EMPTY_PAYLOAD = StructuredPayload(payload_type="test.empty", data={})


class _CountingTool:
    """Records every *physical* call it receives, unconditionally."""

    def __init__(self, tool_id: str, side_effect: ToolSideEffect):
        self.calls: list[ToolExecutionRequest] = []
        self.definition = ToolDefinition(
            tool_id=tool_id,
            name=tool_id,
            description="test tool",
            category=ToolCategory.QUERY,
            input_schema=ToolIOSchema(model_name="Empty"),
            output_schema=ToolIOSchema(model_name="Empty"),
            execution_type=ExecutionType.DETERMINISTIC,
            side_effect=side_effect,
            input_payload_type="test.empty",
            output_payload_type="test.empty",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        self.calls.append(request)
        return ToolExecutionResult(status=ObservationStatus.SUCCESS, payload=_EMPTY_PAYLOAD)


def _identity(**overrides) -> ToolExecutionIdentity:
    base = dict(run_id="run-1", module_id="OEE", objective_id="OEE-obj-1")
    base.update(overrides)
    return ToolExecutionIdentity(**base)


def _clock():
    return _NOW + timedelta(seconds=1)


def test_idempotency_key_is_deterministic_for_same_identity():
    a = _identity().idempotency_key()
    b = _identity().idempotency_key()
    assert a == b


def test_idempotency_key_differs_when_identity_differs():
    base = _identity().idempotency_key()
    different_objective = _identity(objective_id="OEE-obj-2").idempotency_key()
    different_module = _identity(module_id="Output").idempotency_key()
    assert base != different_objective
    assert base != different_module


def test_non_idempotent_write_tool_reuses_cached_result_on_replay():
    tool = _CountingTool("send_email", ToolSideEffect.NON_IDEMPOTENT_WRITE)
    manager = ToolExecutionManager()
    identity = _identity()

    # two Tool Manager Invocations (execute() called twice)...
    outcome1 = manager.execute(
        tool, identity, _EMPTY_PAYLOAD, tool_call_id="call-1", started_at=_NOW, completed_at_fn=_clock
    )
    outcome2 = manager.execute(
        tool, identity, _EMPTY_PAYLOAD, tool_call_id="call-2", started_at=_NOW, completed_at_fn=_clock
    )

    # ...for a single Logical Tool Call (same idempotency_key)...
    assert outcome1.record.idempotency_key == outcome2.record.idempotency_key

    # ...but exactly ONE Physical Tool Execution reached the tool
    assert len(tool.calls) == 1

    assert outcome1.record.attempt_number == 1
    assert outcome1.record.replayed is False
    assert outcome1.record.result_reused is False

    assert outcome2.record.attempt_number == 2
    assert outcome2.record.replayed is True
    assert outcome2.record.result_reused is True
    assert outcome2.record.idempotency_key == outcome1.record.idempotency_key
    assert outcome2.result == outcome1.result


def test_different_logical_identity_always_executes_physically():
    tool = _CountingTool("send_email", ToolSideEffect.NON_IDEMPOTENT_WRITE)
    manager = ToolExecutionManager()

    manager.execute(
        tool, _identity(objective_id="OEE-obj-1"), _EMPTY_PAYLOAD, tool_call_id="c1", started_at=_NOW, completed_at_fn=_clock
    )
    manager.execute(
        tool, _identity(objective_id="OEE-obj-2"), _EMPTY_PAYLOAD, tool_call_id="c2", started_at=_NOW, completed_at_fn=_clock
    )

    assert len(tool.calls) == 2


def test_every_physical_and_replayed_call_is_still_audited():
    tool = _CountingTool("query_oee", ToolSideEffect.READ_ONLY)
    manager = ToolExecutionManager()
    identity = _identity()

    manager.execute(tool, identity, _EMPTY_PAYLOAD, tool_call_id="c1", started_at=_NOW, completed_at_fn=_clock)
    manager.execute(tool, identity, _EMPTY_PAYLOAD, tool_call_id="c2", started_at=_NOW, completed_at_fn=_clock)

    # audit sink sees BOTH the physical execution and the replayed/reused
    # call -- this is exactly what a future append-only ledger needs to
    # distinguish "1 logical action, 2 physical/observed attempts" from
    # "ran once" -- unlike ModuleState.tool_calls, which would only show
    # whatever the last write happened to contain.
    audit_records = manager._audit_sink.records
    assert len(audit_records) == 2
    assert [r.replayed for r in audit_records] == [False, True]
