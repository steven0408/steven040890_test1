"""Phase 7A item 14: RunEvaluator never mutates the analysis it evaluates.
ModuleState / HandoffPackage / Findings must be byte-for-byte identical
before and after `.evaluate()`.
"""
from agent.evaluation.evaluator import RunEvaluator
from agent.state.enums import ModuleStatus, TaskType

from .conftest import make_agent_state, run_oee_module_state_history


def test_evaluator_does_not_mutate_module_states_or_findings():
    history = run_oee_module_state_history(TaskType.RCA)
    final = history[-1]
    assert final.status == ModuleStatus.COMPLETE
    state = make_agent_state().model_copy(update={"module_states": {"OEE": final}})

    before_module_state = final.model_copy(deep=True)
    before_findings = [f.model_copy(deep=True) for f in final.findings]

    RunEvaluator().evaluate(state)

    after_state = state.module_states["OEE"]
    assert after_state == before_module_state
    assert after_state.findings == before_findings


def test_evaluator_does_not_mutate_handoff_package():
    history = run_oee_module_state_history(TaskType.RCA)
    final = history[-1]
    state = make_agent_state().model_copy(update={"module_states": {"OEE": final}})

    RunEvaluator().evaluate(state)
    assert state.synthesis_result is None  # evaluator never sets it either -- that's Synthesis's job, not Evaluator's


def test_evaluator_does_not_mutate_agent_state_at_all():
    history = run_oee_module_state_history(TaskType.RCA)
    final = history[-1]
    state = make_agent_state().model_copy(update={"module_states": {"OEE": final}})
    before = state.model_copy(deep=True)

    RunEvaluator().evaluate(state)

    assert state == before
