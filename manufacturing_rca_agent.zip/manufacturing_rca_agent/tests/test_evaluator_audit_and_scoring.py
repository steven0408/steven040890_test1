"""Phase 7A items 3/9/10/11: overall_score weighting (optional, config-
driven), EvaluationRecord audit lineage, and the HumanFeedback contract
(built but never mixed into RunEvaluation's score this phase).
"""
from agent.evaluation.audit import InMemoryEvaluationAuditSink
from agent.evaluation.evaluator import EVALUATOR_VERSION, RunEvaluator
from agent.persistence.human_feedback import InMemoryHumanFeedbackSink
from agent.state.enums import HumanFeedbackThumbs, ModuleStatus, TaskType
from agent.state.models import EvaluationWeighting, HumanFeedback

from .conftest import make_agent_state, make_run_audit_bundle_from_modules, run_oee_module_state_history


def test_overall_score_is_none_without_a_weighting():
    history = run_oee_module_state_history(TaskType.RCA)
    state = make_agent_state().model_copy(update={"module_states": {"OEE": history[-1]}})
    evaluation = RunEvaluator().evaluate(state, make_run_audit_bundle_from_modules([history[-1]]))
    assert evaluation.overall_score is None
    assert evaluation.weighting is None


def test_overall_score_is_computed_and_traceable_to_its_weighting_when_provided():
    history = run_oee_module_state_history(TaskType.RCA)
    state = make_agent_state().model_copy(update={"module_states": {"OEE": history[-1]}})
    weighting = EvaluationWeighting()
    evaluation = RunEvaluator(weighting=weighting).evaluate(state, make_run_audit_bundle_from_modules([history[-1]]))

    assert evaluation.overall_score is not None
    assert 0.0 <= evaluation.overall_score <= 1.0
    assert evaluation.weighting == weighting


def test_custom_weighting_strategy_produces_a_different_score():
    history = run_oee_module_state_history(TaskType.RCA)
    state = make_agent_state().model_copy(update={"module_states": {"OEE": history[-1]}})
    bundle = make_run_audit_bundle_from_modules([history[-1]])

    default_score = RunEvaluator(weighting=EvaluationWeighting()).evaluate(state, bundle).overall_score
    efficiency_heavy = EvaluationWeighting(analytical_quality=0.1, decision_quality=0.1, delivery_quality=0.1, efficiency=0.7)
    alt_score = RunEvaluator(weighting=efficiency_heavy).evaluate(state, bundle).overall_score

    assert default_score != alt_score  # weighting genuinely changes the result -- not hard-coded


def test_evaluation_record_lineage_and_audit_sink():
    history = run_oee_module_state_history(TaskType.RCA)
    state = make_agent_state().model_copy(update={"module_states": {"OEE": history[-1]}})
    sink = InMemoryEvaluationAuditSink()
    bundle = make_run_audit_bundle_from_modules([history[-1]])

    RunEvaluator(audit_sink=sink).evaluate(state, bundle)

    record = sink.list_for_run(state.run_id)[0]
    assert record.evaluator_version == EVALUATOR_VERSION
    assert record.tool_audit_record_count == len(bundle.tool_call_records)
    assert record.metric_source_counts["tool_call_records"] == len(bundle.tool_call_records)
    assert sink.list_for_run("some-other-run") == []


def test_human_feedback_sink_records_and_is_never_read_by_the_evaluator():
    from datetime import datetime, timezone

    from agent.state.enums import FeedbackTargetType

    feedback_sink = InMemoryHumanFeedbackSink()
    feedback_sink.record(
        HumanFeedback(
            feedback_id="fb1", run_id="run-1", target_type=FeedbackTargetType.RUN, thumbs=HumanFeedbackThumbs.DOWN,
            root_cause_correct=False, created_at=datetime.now(timezone.utc),
        )
    )

    assert len(feedback_sink.list_for_run("run-1")) == 1
    # RunEvaluator.evaluate() has no parameter that could accept a
    # HumanFeedbackSink at all this phase -- structurally cannot mix it in
    import inspect

    from agent.evaluation.evaluator import RunEvaluator as _RunEvaluator

    params = inspect.signature(_RunEvaluator.evaluate).parameters
    assert "feedback" not in params and "human_feedback" not in params
