"""Phase 7B items 7/8/11/12.I/12.J: RunAssessment -- a read-only view over
RunEvaluation + HumanFeedbackSummary, and the four evaluator/human
agreement cases the spec calls out by name. Never mutates RunEvaluation.
"""
from datetime import datetime, timezone

from agent.evaluation.evaluator import RunEvaluator
from agent.feedback.aggregator import HumanFeedbackAggregator
from agent.feedback.assessment import AgreementDimension, EvaluationHumanAgreement, build_run_assessment
from agent.feedback.issues import classify_feedback_issues
from agent.state.enums import FeedbackTargetType, HumanFeedbackThumbs, ModuleStatus, TaskType
from agent.state.models import HumanFeedback

from .conftest import make_agent_state, make_run_audit_bundle_from_modules, run_oee_module_state_history


def _fb(feedback_id, **kwargs):
    base = dict(run_id="run-1", target_type=FeedbackTargetType.RUN, created_at=datetime.now(timezone.utc))
    base.update(kwargs)
    return HumanFeedback(feedback_id=feedback_id, **base)


def _rca_complete_state_and_evaluation():
    history = run_oee_module_state_history(TaskType.RCA)
    final = history[-1]
    assert final.status == ModuleStatus.COMPLETE
    state = make_agent_state(run_id="run-1").model_copy(update={"module_states": {"OEE": final}})
    evaluation = RunEvaluator().evaluate(state, make_run_audit_bundle_from_modules([final]))
    return state, evaluation


def _assess(evaluation, feedback):
    summary = HumanFeedbackAggregator().summarize("run-1", feedback)
    issues = classify_feedback_issues(feedback)
    return build_run_assessment(evaluation, summary, issues)


# ============================================================================
# A. Evaluator high + Human thumbs up -> agreement
# ============================================================================


def test_case_a_agreement_positive():
    _, evaluation = _rca_complete_state_and_evaluation()
    feedback = [_fb("f1", thumbs=HumanFeedbackThumbs.UP, answer_helpful=True)]
    assessment = _assess(evaluation, feedback)

    overall = next(s for s in assessment.agreement_signals if s.dimension == AgreementDimension.OVERALL)
    assert overall.agreement == EvaluationHumanAgreement.AGREE_POSITIVE


# ============================================================================
# B. Evaluator high analytical quality + Human thumbs down -> disagreement
# ============================================================================


def test_case_b_disagreement_evaluator_high_human_low():
    _, evaluation = _rca_complete_state_and_evaluation()
    feedback = [_fb("f1", thumbs=HumanFeedbackThumbs.DOWN)]
    assessment = _assess(evaluation, feedback)

    overall = next(s for s in assessment.agreement_signals if s.dimension == AgreementDimension.OVERALL)
    assert overall.agreement == EvaluationHumanAgreement.DISAGREE_EVALUATOR_HIGH_HUMAN_LOW


# ============================================================================
# C. Evaluator root-cause support high + Human root_cause_correct=False ->
# critical disagreement
# ============================================================================


def test_case_c_critical_root_cause_disagreement():
    _, evaluation = _rca_complete_state_and_evaluation()
    assert evaluation.analytical_quality.root_cause_support_score == 1.0
    feedback = [_fb("f1", target_type=FeedbackTargetType.ROOT_CAUSE, target_id="rc-any", root_cause_correct=False)]
    assessment = _assess(evaluation, feedback)

    root_cause_signal = next(s for s in assessment.agreement_signals if s.dimension == AgreementDimension.ROOT_CAUSE)
    assert root_cause_signal.evaluator_score == 1.0
    assert root_cause_signal.human_positive_rate == 0.0
    assert root_cause_signal.agreement == EvaluationHumanAgreement.DISAGREE_EVALUATOR_HIGH_HUMAN_LOW


# ============================================================================
# D. Evaluator delivery quality low + Human thumbs up -> both signals kept
# ============================================================================


def test_case_d_low_evaluator_high_human_both_signals_preserved():
    from agent.state.enums import RecommendationActionType, SynthesisOverallStatus
    from agent.state.models import ConfidenceSummary, HandoffPackage, RecommendationCandidate

    state, evaluation = _rca_complete_state_and_evaluation()
    # force a low delivery score via a hallucinated synthesis_result (see
    # test_evaluator_rca_traces.py's own hallucination-guard test for the
    # same construction) -- proves the *evaluator* side can be low even
    # while human sentiment is positive, and neither signal overwrites the other
    from agent.state.models import RootCause

    hallucinated_package = HandoffPackage(
        run_id="run-1", request_summary="why", task_type=TaskType.RCA, overall_status=SynthesisOverallStatus.PARTIAL,
        module_results=[], key_findings=[], root_causes=[RootCause(root_cause_id="rc-hallucinated", statement="never confirmed", module_id="OEE", confidence=0.9)],
        confidence_summary=ConfidenceSummary(overall_confidence=0.9, evidence_coverage=0.9),
    )
    state = state.model_copy(update={"synthesis_result": hallucinated_package})
    history = run_oee_module_state_history(TaskType.RCA)
    evaluation = RunEvaluator().evaluate(state, make_run_audit_bundle_from_modules([history[-1]]))
    assert evaluation.delivery_quality.hallucination_guard_passed is False

    feedback = [_fb("f1", thumbs=HumanFeedbackThumbs.UP, answer_helpful=True)]
    assessment = _assess(evaluation, feedback)

    overall = next(s for s in assessment.agreement_signals if s.dimension == AgreementDimension.OVERALL)
    # both signals still visible on the assessment -- nothing "resolved" the conflict
    assert overall.evaluator_score is not None and overall.human_positive_rate == 1.0
    assert overall.agreement == EvaluationHumanAgreement.DISAGREE_EVALUATOR_LOW_HUMAN_HIGH


def test_insufficient_feedback_when_no_human_feedback_submitted():
    _, evaluation = _rca_complete_state_and_evaluation()
    assessment = _assess(evaluation, [])
    overall = next(s for s in assessment.agreement_signals if s.dimension == AgreementDimension.OVERALL)
    assert overall.agreement == EvaluationHumanAgreement.INSUFFICIENT_FEEDBACK


# ============================================================================
# J. Read-only
# ============================================================================


def test_run_assessment_never_mutates_run_evaluation_or_agent_state():
    state, evaluation = _rca_complete_state_and_evaluation()
    evaluation_before = evaluation.model_copy(deep=True)
    state_before = state.model_copy(deep=True)

    _assess(evaluation, [_fb("f1", thumbs=HumanFeedbackThumbs.UP)])

    assert evaluation == evaluation_before
    assert state == state_before
