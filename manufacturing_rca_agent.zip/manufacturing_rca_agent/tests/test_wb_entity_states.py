"""Phase WB-2C item 6/7: WB Plant entity_states initialization + ownership.
All offline.
"""
from agent.planning.policies.wb import WB_CANONICAL_PLANTS, WBPlanningPolicy, build_wb_initial_entity_states
from agent.state.enums import EntityAnalysisStatus

from .conftest import make_module_state


def test_canonical_plant_ids_match_the_wb_data_layer_mapping():
    """Item 6: canonical ids only -- no P1/FAB_A/A01001 alias forms. The
    single authoritative source is agent/domain/wb/mappings.py::PLANT_ID_MAP,
    never a second hardcoded list here."""
    assert set(WB_CANONICAL_PLANTS) == {"ASE01", "ASE02", "ASE03", "ASE07", "ASE08"}


def test_build_wb_initial_entity_states_one_per_plant():
    states = build_wb_initial_entity_states()
    assert set(states.keys()) == set(WB_CANONICAL_PLANTS)
    for plant_id, state in states.items():
        assert state.entity_id == plant_id
        assert state.entity_type == "PLANT"
        assert state.status == EntityAnalysisStatus.SCREENED
        assert state.branch_id is None  # item 24: no branches this phase


def test_entity_states_are_seeded_via_derive_state_updates_not_module_init():
    """Item 7's ownership freeze, proven executably: `build_initial_module_state`
    (generic) never populates entity_states -- WBPlanningPolicy does, via
    the same DomainStateUpdates seam OEEPlanningPolicy already uses."""
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    assert module_state.entity_states == {}  # confirms generic init never touches it

    policy = WBPlanningPolicy()
    updates = policy.derive_state_updates(module_state)
    assert set(updates.entity_states.keys()) == set(WB_CANONICAL_PLANTS)


def test_derive_state_updates_is_idempotent_once_entity_states_already_present():
    """Reflector calls derive_state_updates every round -- must not keep
    re-emitting/overwriting entity_states once already seeded."""
    policy = WBPlanningPolicy()
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    module_state = module_state.model_copy(update={"entity_states": build_wb_initial_entity_states()})

    updates = policy.derive_state_updates(module_state)

    assert updates.entity_states == {}  # nothing more to add -- DomainStateUpdates() default
    assert updates.branches == {}
    assert updates.analysis_tree is None


def test_generic_validator_never_hardcodes_a_wb_plant_id():
    """Item 7's other half: the GENERIC Planner semantic validator
    (agent/planning/policies/llm.py) must contain no WB plant id literal
    anywhere -- it only ever reads module_state.entity_states, never
    hardcodes what a valid WB entity is."""
    from pathlib import Path

    source = Path("agent/planning/policies/llm.py").read_text(encoding="utf-8")
    for plant_id in WB_CANONICAL_PLANTS:
        assert plant_id not in source
