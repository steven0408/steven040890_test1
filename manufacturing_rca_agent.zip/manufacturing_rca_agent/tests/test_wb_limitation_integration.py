"""Phase WB-3C items 20-26/70: structured `Limitation` propagation beyond
`ModuleState` itself -- JSON/checkpoint round-trip, Synthesis handoff +
rendered Markdown (using the exact `_package_for` pattern
`test_synthesis_hallucination_regression.py` already established),
Synthesis hallucination guard (a Limitation about missing mechanism
detail must never get upgraded into a confirmed root cause), Evaluator
crash-smoke, and Persistence smoke (limitation_count + HandoffPackage
preservation). No Synthesis/Evaluator/Persistence code was modified this
phase -- these tests confirm the existing generic machinery already
handles WB-3C-sourced Limitations correctly, since they're ordinary
`Limitation` records on `ModuleState.limitations`, the same channel
`module_planner.py`'s own two built-in write paths already used. All
offline.
"""
from datetime import timedelta

from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.domain.wb.synthetic import GOLDEN_DATE, HISTORY_DECLINE_START
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.llm.context.synthesis_context import SynthesisContextBuilder
from agent.modules.wb.package import build_wb_module_package
from agent.persistence.audit_repository import build_default_audit_repository
from agent.persistence.human_feedback import InMemoryHumanFeedbackSink
from agent.learning.sink import InMemoryLearningCandidateSink
from agent.persistence.learning_repository import LearningCandidateRepository
from agent.persistence.run_repository import InMemoryRunRepository
from agent.persistence.run_writer import RunPersistenceWriter
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import ModuleStatus, RunTerminationStatus, TaskType
from agent.state.models import Goal, GoalScope, ModuleState, ModuleTask
from agent.synthesis.handoff_builder import ModuleHandoffBuilder
from agent.synthesis.package import build_handoff_package
from agent.synthesis.renderer import render_markdown
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry

from .conftest import make_agent_state

_WINDOW_START = HISTORY_DECLINE_START - timedelta(days=3)


def _run_wb(task_type: TaskType, thread_id: str, statement: str) -> ModuleState:
    package = build_wb_module_package()
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    runtime = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)

    policy = WBPlanningPolicy()
    graph = build_module_react_subgraph(policy, capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id="WB", module_type="WB", reason=statement, goal_statement=statement, confidence=0.9, priority=0.9, task_type=task_type)
    initial = build_initial_module_state(task, package.budget, run_id=f"run-{thread_id}", task_type=task_type)
    result = app.invoke(initial, config={"configurable": {"thread_id": thread_id}})
    return ModuleState.model_validate(result)


def _package_for(module_state: ModuleState, task_type: TaskType = TaskType.RCA, run_id: str = "run-wb3c-synth"):
    state = make_agent_state(run_id=run_id).model_copy(update={
        "module_states": {"WB": module_state},
        "global_goal": Goal(goal_id="g1", raw_statement="q", normalized_statement="q", task_type=task_type, scope=GoalScope()),
    })
    outcome = SynthesisContextBuilder(ModuleHandoffBuilder()).build(state)
    return build_handoff_package(outcome.context)


# ============================================================================
# 20/21. JSON and checkpoint round-trip.
# ============================================================================


def test_module_state_with_limitations_survives_json_round_trip():
    module_state = _run_wb(TaskType.RCA, "lim-json", "2026-08-12 ASE08 OEE 異常 root cause")
    assert module_state.limitations

    dumped = module_state.model_dump_json()
    restored = ModuleState.model_validate_json(dumped)

    assert restored.limitations == module_state.limitations
    assert restored.limitations[0].limitation_id == module_state.limitations[0].limitation_id
    assert restored.limitations[0].related_error == module_state.limitations[0].related_error


def test_checkpoint_round_trip_preserves_limitations_across_the_multi_round_graph():
    """The Module ReAct Subgraph's own `InMemorySaver` checkpointer already
    persists/restores the full `ModuleState` (including `limitations`,
    via the `append_list` reducer) across every round -- this test just
    confirms the FINAL state (after the graph's own internal checkpoint
    round-trips) still carries the limitation through to completion,
    proving no custom WB limitation object silently broke serialization."""
    module_state = _run_wb(TaskType.RCA, "lim-checkpoint", "2026-08-12 ASE07 output 偏低 這週 trend root cause")
    assert module_state.status == ModuleStatus.COMPLETE
    # a 4-round chain survived multiple checkpoint writes/reads intact
    assert len(module_state.objective_history) == 4


# ============================================================================
# 22/23. Synthesis handoff includes the Limitation; deterministic Markdown
# renders it.
# ============================================================================


def test_synthesis_handoff_includes_wb3c_limitation():
    module_state = _run_wb(TaskType.RCA, "lim-handoff", "2026-08-12 ASE08 OEE 異常 root cause")
    package = _package_for(module_state)

    wb_handoff = next(h for h in package.module_results if h.module_type == "WB")
    assert len(wb_handoff.limitations) == 1
    assert "ASE08" in wb_handoff.limitations[0].description
    assert len(package.limitations) >= 1


def test_markdown_includes_no_data_limitation_text():
    module_state = _run_wb(TaskType.RCA, "lim-md-nodata", "2026-08-12 ASE08 OEE 異常 root cause")
    package = _package_for(module_state)

    assert "## Limitations / Missing Information" in package.markdown
    assert "No WB data was available" in package.markdown
    assert "ASE08" in package.markdown


def test_markdown_includes_insufficient_history_and_partial_overlap_text():
    module_state = _run_wb(TaskType.RCA, "lim-md-hist", "2026-08-12 ASE01 OEE 表現差 這週 trend root cause")
    package = _package_for(module_state)
    assert "worst-performing operation" in package.markdown

    module_state_2 = _run_wb(TaskType.ANALYSIS, "lim-md-issue-hist", "2026-08-12 ASE07 這週投料是不是一直偏低？")
    package_2 = _package_for(module_state_2, task_type=TaskType.ANALYSIS)
    # full-coverage real dataset -- no insufficient-history text expected here,
    # confirms the markdown doesn't spuriously mention it when not applicable
    assert "no baseline period could be established" not in package_2.markdown


def test_markdown_never_says_analysis_failed_when_partial_findings_exist():
    """item 32: a PARTIAL module with real findings must not be rendered
    as "Analysis failed" -- the executive finding stays descriptive."""
    module_state = _run_wb(TaskType.RCA, "lim-md-partial", "2026-08-12 ASE08 OEE 異常 root cause")
    assert module_state.status == ModuleStatus.PARTIAL
    package = _package_for(module_state)
    assert "analysis failed" not in package.markdown.lower()


# ============================================================================
# 24/56. Synthesis hallucination guard -- a Limitation about missing
# mechanism detail must never be upgraded into a confirmed root cause.
# ============================================================================


def test_limitation_never_gets_upgraded_into_a_root_cause():
    module_state = _run_wb(TaskType.RCA, "lim-hallucination", "2026-08-12 ASE01 OEE 表現差 這週 trend root cause")
    package = _package_for(module_state)

    for rc in package.root_causes:
        assert "worst-performing operation" not in rc.statement
        assert "equipment/operation-level" not in rc.statement.lower()
    # the grain limitation's own wording never leaks into a causal claim
    assert "equipment failure" not in package.markdown.lower()


def test_datasource_unavailable_limitation_never_becomes_a_synthesis_root_cause():
    from agent.domain.wb.errors import WBDataSourceUnavailableError
    from agent.tools.wb.registration import WBDataSources
    from .conftest import make_wb_datasources

    class _BrokenBank:
        def list_bank(self, *, snapshot_date=None):
            raise WBDataSourceUnavailableError("simulated outage")

        def freshness(self):
            from agent.domain.wb.models import WB_BANK_FRESHNESS
            return WB_BANK_FRESHNESS

    base = make_wb_datasources()
    custom = WBDataSources(oee=base.oee, bank=_BrokenBank(), wip=base.wip, output=base.output, issue=base.issue)

    package = build_wb_module_package(datasources=custom)
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)
    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    runtime = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)
    graph = build_module_react_subgraph(WBPlanningPolicy(), capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)
    statement = "2026-08-12 ASE07 output 偏低 root cause"
    task = ModuleTask(module_id="WB", module_type="WB", reason=statement, goal_statement=statement, confidence=0.9, priority=0.9, task_type=TaskType.RCA)
    initial = build_initial_module_state(task, package.budget, run_id="run-lim-ds-synth", task_type=TaskType.RCA)
    result = app.invoke(initial, config={"configurable": {"thread_id": "lim-ds-synth"}})
    module_state = ModuleState.model_validate(result)

    handoff_package = _package_for(module_state)
    for rc in handoff_package.root_causes:
        assert "bank" not in rc.statement.lower() or "outage" not in rc.statement.lower()


# ============================================================================
# 25. Evaluator crash-smoke.
# ============================================================================


def test_run_evaluator_does_not_crash_on_a_limitation_bearing_wb_run():
    from agent.evaluation.evaluator import RunEvaluator

    module_state = _run_wb(TaskType.RCA, "lim-eval", "2026-08-12 ASE08 OEE 異常 root cause")
    final_state = make_agent_state(run_id="run-lim-eval").model_copy(update={
        "module_states": {"WB": module_state},
        "global_goal": Goal(goal_id="g1", raw_statement="ASE08 OEE abnormal?", normalized_statement="ASE08 OEE abnormal root cause", task_type=TaskType.RCA, scope=GoalScope()),
        "termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS,
    })

    evaluator = RunEvaluator()
    report = evaluator.evaluate(final_state)
    assert report is not None


# ============================================================================
# 26. Persistence smoke.
# ============================================================================


def _writer():
    run_repo = InMemoryRunRepository()
    audit_repo = build_default_audit_repository()
    feedback_sink = InMemoryHumanFeedbackSink()
    learning_repo = LearningCandidateRepository(InMemoryLearningCandidateSink())
    return RunPersistenceWriter(run_repo, audit_repo, feedback_sink, learning_repo), run_repo


def test_persistence_records_limitation_count_for_a_wb3c_run():
    module_state = _run_wb(TaskType.RCA, "lim-persist", "2026-08-12 ASE08 OEE 異常 root cause")
    assert len(module_state.limitations) == 1

    writer, run_repo = _writer()
    state = make_agent_state(run_id="run-lim-persist").model_copy(update={
        "module_states": {"WB": module_state},
        "global_goal": Goal(goal_id="g1", raw_statement="ASE08 OEE abnormal?", normalized_statement="ASE08 OEE abnormal root cause", task_type=TaskType.RCA, scope=GoalScope()),
        "termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS,
    })
    writer.persist_run(state)

    module_runs = run_repo.get_module_results("run-lim-persist")
    wb_run = next(r for r in module_runs if r.module_id == "WB")
    assert wb_run.limitation_count == 1


def test_persistence_preserves_handoff_package_limitations():
    """item 34/55: `Limitation`-content persistence (not just the count) is
    only durable via `HandoffPackage` persistence -- confirm that path
    specifically, since `ModuleRunRecord` itself only stores a count."""
    module_state = _run_wb(TaskType.RCA, "lim-persist-handoff", "2026-08-12 ASE08 OEE 異常 root cause")
    package = _package_for(module_state, run_id="run-lim-persist-handoff")

    writer, run_repo = _writer()
    state = make_agent_state(run_id="run-lim-persist-handoff").model_copy(update={
        "module_states": {"WB": module_state},
        "global_goal": Goal(goal_id="g1", raw_statement="ASE08 OEE abnormal?", normalized_statement="ASE08 OEE abnormal root cause", task_type=TaskType.RCA, scope=GoalScope()),
        "termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS,
        "synthesis_result": package,
    })
    writer.persist_run(state)

    restored = run_repo.get_handoff_package("run-lim-persist-handoff")
    assert restored is not None
    assert len(restored.limitations) >= 1
    assert any("ASE08" in lim.description for lim in restored.limitations)
