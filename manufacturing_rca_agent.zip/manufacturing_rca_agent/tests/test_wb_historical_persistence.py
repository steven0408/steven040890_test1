"""Phase WB-3B item 64/70: historical range-scoped Objective (`start`/
`end`, not a single `date`) and cross-source Evidence/Finding lineage
survive the existing WB-2B.2 persistence path (RunPersistenceWriter ->
InMemoryRunRepository, and the raw postgres row mapping) without
modification -- confirms no persistence-layer change was needed for the
range-scope `TimeScope`/multi-round historical chain this phase built.
All offline.
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.learning.sink import InMemoryLearningCandidateSink
from agent.modules.wb.package import build_wb_module_package
from agent.persistence.audit_repository import build_default_audit_repository
from agent.persistence.human_feedback import InMemoryHumanFeedbackSink
from agent.persistence.learning_repository import LearningCandidateRepository
from agent.persistence.run_repository import InMemoryRunRepository
from agent.persistence.run_writer import RunPersistenceWriter
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import ModuleStatus, RunTerminationStatus, TaskType
from agent.state.models import Goal, GoalScope, ModuleState, ModuleTask
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry

from .conftest import make_agent_state


def _run_wb(task_type: TaskType, thread_id: str, statement: str) -> ModuleState:
    package = build_wb_module_package()
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    runtime = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)

    graph = build_module_react_subgraph(WBPlanningPolicy(), capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id="WB", module_type="WB", reason=statement, goal_statement=statement, confidence=0.9, priority=0.9, task_type=task_type)
    initial = build_initial_module_state(task, package.budget, run_id=f"run-{thread_id}", task_type=task_type)
    result = app.invoke(initial, config={"configurable": {"thread_id": thread_id}})
    return ModuleState.model_validate(result)


def _writer():
    run_repo = InMemoryRunRepository()
    audit_repo = build_default_audit_repository()
    feedback_sink = InMemoryHumanFeedbackSink()
    learning_repo = LearningCandidateRepository(InMemoryLearningCandidateSink())
    return RunPersistenceWriter(run_repo, audit_repo, feedback_sink, learning_repo), run_repo


def test_historical_range_scoped_objective_round_trips_start_end():
    module_state = _run_wb(TaskType.ANALYSIS, "hist-persist", "2026-08-12 ASE07 這週投料是不是一直偏低？")
    assert module_state.status == ModuleStatus.COMPLETE
    record = next(iter(module_state.objective_history.values()))
    assert record.capability_key == "wb.issue.trend_analysis"
    assert record.scope.time.start is not None
    assert record.scope.time.end is not None
    assert record.scope.time.date is None  # a RANGE objective, never a point date

    from agent.persistence.postgres import mapping as m

    row = m.objective_to_row("run-hist-persist", "WB", record)
    restored = m.objective_from_row(row)

    assert restored == record
    assert restored.scope.time.start == record.scope.time.start
    assert restored.scope.time.end == record.scope.time.end


def test_cross_source_rca_chain_persists_with_full_evidence_lineage():
    module_state = _run_wb(TaskType.RCA, "hist-crosssource-persist", "2026-08-12 ASE07 output 偏低 這週 trend root cause")
    assert module_state.status == ModuleStatus.COMPLETE
    assert len(module_state.objective_history) == 4  # symptom + output trend + issue trend + relationship

    writer, run_repo = _writer()
    state = make_agent_state(run_id="run-hist-crosssource-persist").model_copy(update={
        "module_states": {"WB": module_state},
        "global_goal": Goal(goal_id="g1", raw_statement="ASE07 output low, historical?", normalized_statement="ASE07 output low historical root cause", task_type=TaskType.RCA, scope=GoalScope()),
        "termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS,
    })
    writer.persist_run(state)

    reloaded_objectives = run_repo.list_objectives("run-hist-crosssource-persist")
    assert len(reloaded_objectives) == 4
    capability_keys = {r.capability_key for r in reloaded_objectives}
    assert capability_keys == {"wb.output.comparison", "wb.output.trend_analysis", "wb.issue.trend_analysis", "wb.issue_output.relationship_analysis"}

    reloaded_evidence = run_repo.list_evidence("run-hist-crosssource-persist")
    assert len(reloaded_evidence) == 4
    objective_ids = {r.objective_id for r in reloaded_objectives}
    assert all(e.objective_id in objective_ids for e in reloaded_evidence)  # lineage intact across every round, including the cross-source one


def test_cross_source_objective_postgres_row_round_trips():
    from agent.persistence.postgres import mapping as m

    module_state = _run_wb(TaskType.RCA, "hist-crosssource-pg", "2026-08-12 ASE07 output 偏低 這週 trend root cause")
    relationship_record = next(r for r in module_state.objective_history.values() if r.capability_key == "wb.issue_output.relationship_analysis")

    row = m.objective_to_row("run-hist-crosssource-pg", "WB", relationship_record)
    restored = m.objective_from_row(row)

    assert restored == relationship_record
    assert restored.capability_key == "wb.issue_output.relationship_analysis"
