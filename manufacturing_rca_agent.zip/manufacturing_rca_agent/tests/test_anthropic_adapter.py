"""Phase 5B-3B: AnthropicAdapter -- fully offline, no network/API key
needed. Everything here injects a fake `client=` (any object shaped like
`anthropic.Anthropic().messages`) so adapter logic (request building,
structured-output parsing, usage extraction, exception mapping) is tested
deterministically. Real end-to-end network calls are Phase 5B-3B's
separate skip-marked smoke tests (test_phase5b3b_real_provider_smoke.py).
"""
import httpx
import pytest

anthropic = pytest.importorskip("anthropic")

from agent.llm.models import LLMInvalidOutputError, LLMMessage, LLMProviderError, LLMRequest, LLMRole, LLMTimeoutError
from agent.llm.providers.anthropic_adapter import AnthropicAdapter, AnthropicAdapterConfigError
from agent.state.base import RCABaseModel

_REQUEST = LLMRequest(
    route="analyzer",
    model="claude-haiku-4-5-20251001",
    messages=[LLMMessage(role=LLMRole.SYSTEM, content="be helpful"), LLMMessage(role=LLMRole.USER, content="hello")],
    output_schema_name="_Echo",
    timeout_seconds=10.0,
    run_id="run-1",
    module_id=None,
    node="analyzer",
)


class _Echo(RCABaseModel):
    value: str


class _FakeToolUseBlock:
    def __init__(self, input_dict: dict):
        self.type = "tool_use"
        self.input = input_dict


class _FakeTextBlock:
    def __init__(self, text: str):
        self.type = "text"
        self.text = text


class _FakeUsage:
    def __init__(self, input_tokens: int, output_tokens: int):
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens


class _FakeMessage:
    def __init__(self, content: list, usage: _FakeUsage | None = None):
        self.content = content
        self.usage = usage


class _FakeMessagesEndpoint:
    def __init__(self, responder):
        self._responder = responder
        self.calls: list[dict] = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return self._responder(kwargs)


class _FakeAnthropicClient:
    def __init__(self, responder):
        self.messages = _FakeMessagesEndpoint(responder)


def _http_request() -> httpx.Request:
    return httpx.Request("POST", "https://api.anthropic.com/v1/messages")


# ============================================================================
# Config / secret handling (item 10)
# ============================================================================


def test_no_api_key_and_no_client_raises_typed_config_error(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    with pytest.raises(AnthropicAdapterConfigError):
        AnthropicAdapter()


def test_injected_client_bypasses_api_key_requirement(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    fake = _FakeAnthropicClient(lambda kwargs: _FakeMessage([_FakeToolUseBlock({"value": "ok"})], _FakeUsage(5, 3)))
    adapter = AnthropicAdapter(client=fake)  # must not raise
    completion = adapter.complete(_REQUEST, _Echo)
    assert completion.parsed_output == _Echo(value="ok")


# ============================================================================
# Structured output happy path + usage extraction
# ============================================================================


def test_structured_output_parses_and_extracts_usage():
    fake = _FakeAnthropicClient(lambda kwargs: _FakeMessage([_FakeToolUseBlock({"value": "hello"})], _FakeUsage(42, 7)))
    adapter = AnthropicAdapter(client=fake)

    completion = adapter.complete(_REQUEST, _Echo)

    assert completion.parsed_output == _Echo(value="hello")
    assert completion.input_tokens == 42
    assert completion.output_tokens == 7
    assert completion.latency_ms >= 0

    # request building: forced tool-use with the output_model's own JSON schema
    call = fake.messages.calls[0]
    assert call["model"] == "claude-haiku-4-5-20251001"
    assert call["tool_choice"] == {"type": "tool", "name": "emit_decision"}
    assert call["tools"][0]["input_schema"] == _Echo.model_json_schema()
    assert call["timeout"] == 10.0
    assert call["system"] == "be helpful"


def test_missing_usage_object_yields_zero_not_fabricated_tokens():
    fake = _FakeAnthropicClient(lambda kwargs: _FakeMessage([_FakeToolUseBlock({"value": "x"})], usage=None))
    adapter = AnthropicAdapter(client=fake)
    completion = adapter.complete(_REQUEST, _Echo)
    assert completion.input_tokens == 0
    assert completion.output_tokens == 0


# ============================================================================
# Invalid structured output
# ============================================================================


def test_no_tool_use_block_raises_invalid_output():
    fake = _FakeAnthropicClient(lambda kwargs: _FakeMessage([_FakeTextBlock("I refuse to use the tool.")]))
    adapter = AnthropicAdapter(client=fake)
    with pytest.raises(LLMInvalidOutputError):
        adapter.complete(_REQUEST, _Echo)


def test_tool_use_input_failing_schema_validation_raises_invalid_output():
    fake = _FakeAnthropicClient(lambda kwargs: _FakeMessage([_FakeToolUseBlock({"value": "ok", "unexpected_extra": "x"})]))
    adapter = AnthropicAdapter(client=fake)
    with pytest.raises(LLMInvalidOutputError):
        adapter.complete(_REQUEST, _Echo)


# ============================================================================
# Provider exception mapping (item 9) -- real anthropic SDK exception
# instances, no network needed
# ============================================================================


def test_api_timeout_error_maps_to_llm_timeout_error():
    def raise_timeout(kwargs):
        raise anthropic.APITimeoutError(request=_http_request())

    adapter = AnthropicAdapter(client=_FakeAnthropicClient(raise_timeout))
    with pytest.raises(LLMTimeoutError):
        adapter.complete(_REQUEST, _Echo)


def test_authentication_error_maps_to_llm_provider_error():
    def raise_auth(kwargs):
        response = httpx.Response(status_code=401, request=_http_request())
        raise anthropic.AuthenticationError("invalid api key", response=response, body=None)

    adapter = AnthropicAdapter(client=_FakeAnthropicClient(raise_auth))
    with pytest.raises(LLMProviderError):
        adapter.complete(_REQUEST, _Echo)


def test_server_error_maps_to_llm_provider_error():
    def raise_server_error(kwargs):
        response = httpx.Response(status_code=500, request=_http_request())
        raise anthropic.APIStatusError("internal server error", response=response, body=None)

    adapter = AnthropicAdapter(client=_FakeAnthropicClient(raise_server_error))
    with pytest.raises(LLMProviderError):
        adapter.complete(_REQUEST, _Echo)


def test_unrecognized_exception_still_maps_to_llm_provider_error_never_leaks():
    def raise_unexpected(kwargs):
        raise RuntimeError("some completely unrelated bug")

    adapter = AnthropicAdapter(client=_FakeAnthropicClient(raise_unexpected))
    with pytest.raises(LLMProviderError):
        adapter.complete(_REQUEST, _Echo)
