"""Harness self-test -- confirms build_deterministic_service +
run_golden_scenario actually work before building the full Golden Matrix
on top of them."""
from agent.state.enums import TaskType

from .harness import build_deterministic_service, planner_decisions, reflection_decisions, route_sources, run_golden_scenario


def test_deterministic_smoke_information():
    service = build_deterministic_service(
        goal_statement="Check WB OEE status for ASE01 on 2026-08-12.", task_type=TaskType.INFORMATION,
    )
    final_state = run_golden_scenario(service, "請查詢 2026-08-12 ASE01 的 WB OEE 狀況。", run_id="smoke-info")

    print(f"\nsources={route_sources(service, 'smoke-info')}")
    print(f"status={final_state.termination_status.value}")
    wb = final_state.module_states.get("WB")
    print(f"module_status={wb.status.value if wb else None}")
    print(f"objective_history={len(wb.objective_history) if wb else 0}")
    print(f"evidence={len(wb.evidence) if wb else 0}")
    print(f"tool_calls={len(wb.tool_calls) if wb else 0}")
    print(f"recorders={ {k: r.summary() for k, r in service.recorders.items()} }")
    print(f"markdown_present={final_state.synthesis_result is not None}")
    if final_state.synthesis_result:
        print(f"markdown={final_state.synthesis_result.markdown[:300]}")

    assert wb is not None
    assert len(wb.objective_history) >= 1
