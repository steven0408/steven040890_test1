"""Phase PROD-1.3 Golden Scenarios G9 (insufficient data) and G10
(invalid/quality-limited data). Both must terminate cleanly WITHOUT
fabricating a value the data never supported."""
from agent.domain.wb.datasource import (
    InMemoryWBBankDataSource,
    InMemoryWBIssueDataSource,
    InMemoryWBPlantOEEDataSource,
    InMemoryWBStageOutputDataSource,
    InMemoryWBWIPDataSource,
)
from agent.domain.wb.synthetic import (
    GOLDEN_DATE,
    SCENARIO_E_PLANT,
    build_wb_bank_records,
    build_wb_issue_records,
    build_wb_plant_oee_records,
    build_wb_stage_output_records,
    build_wb_wip_records,
)
from agent.state.enums import TaskType
from agent.state.payload import PayloadRegistry
from agent.tools.wb.registration import WBDataSources

from .harness import build_deterministic_service, run_golden_scenario


def test_g9_insufficient_data_ase08_oee_missing():
    """G9 -- INSUFFICIENT DATA. Scenario E: OEE records are entirely absent
    for ASE08 on the golden date (a real, built-in gap in the golden
    dataset -- see synthetic.py's own `continue` skip, never a fixture
    invented for this test). A valid request against genuinely missing
    data must produce Limitation / unresolved question, never a fabricated
    OEE percentage."""
    service = build_deterministic_service(
        goal_statement=f"Check WB OEE status for {SCENARIO_E_PLANT} on 2026-08-12.", task_type=TaskType.INFORMATION,
    )
    final_state = run_golden_scenario(service, f"請查詢 2026-08-12 {SCENARIO_E_PLANT} 的 WB OEE 狀況。", run_id="g9")
    wb = final_state.module_states["WB"]

    print(f"\nG9 module_status: {wb.status.value}")
    print(f"G9 evidence: {[e.summary for e in wb.evidence]}")
    print(f"G9 limitations: {[lim.description for lim in wb.limitations]}")
    print(f"G9 findings: {[f.statement for f in wb.findings]}")

    # The OEE DataSource is date-scoped (production_date x plant_id x
    # operation grain), not plant-scoped -- it genuinely returns the
    # golden date's records for every OTHER plant (proving the query ran
    # for real), while ASE08 itself has none among them (Scenario E's own
    # gap, confirmed here rather than trusted from a prior report).
    oee_calls = service.recorders["oee"].calls
    assert any(c.method == "list_oee" and c.kwargs.get("production_date") == "2026-08-12" for c in oee_calls)
    real_call = next(c for c in oee_calls if c.method == "list_oee")
    assert real_call.record_count is not None and real_call.record_count > 0  # other plants' records genuinely returned

    assert len(wb.evidence) >= 1
    evidence = wb.evidence[-1]
    payload = PayloadRegistry.unpack(evidence.structured_payload)
    assert payload.availability.is_empty is True
    assert len(payload.ranking) == 0  # zero ASE08 rows after plant-filtering, never backfilled with a fabricated 0/None row

    # No fabricated OEE % anywhere for this plant.
    assert not any(f.status.value == "confirmed" and SCENARIO_E_PLANT in f.statement for f in wb.findings)
    assert wb.status.value in ("partial", "failed", "complete")


def test_g10_invalid_quality_limited_data():
    """G10 -- INVALID / QUALITY-LIMITED DATA. A controlled fixture (spec-
    sanctioned: 'use an existing validation scenario or a controlled
    synthetic fixture') built by taking the real golden OEE dataset and
    appending two deliberately invalid records (OEE=150%, OEE=-10%) for an
    otherwise-normal plant/date. Validation must flag the bad records; the
    invalid values must never surface as a Finding; the still-usable real
    records may still produce a supported Finding alongside them."""
    plant = "ASE02"  # Scenario D -- normal control plant, no special-case generator branch
    real_oee_records = build_wb_plant_oee_records()
    template = next(r for r in real_oee_records if r.plant_id == plant and r.production_date == GOLDEN_DATE)

    invalid_over_100 = template.model_copy(update={"operation_id": "9001", "oee": 150.0, "downtime_ratio": -30.0})
    invalid_negative = template.model_copy(update={"operation_id": "9002", "oee": -10.0})
    oee_records = real_oee_records + [invalid_over_100, invalid_negative]

    bank_records, bank_snapshot_dates = build_wb_bank_records()
    wip_records, wip_snapshot_dates = build_wb_wip_records()
    datasources = WBDataSources(
        oee=InMemoryWBPlantOEEDataSource(oee_records),
        bank=InMemoryWBBankDataSource(bank_records, snapshot_dates=bank_snapshot_dates),
        wip=InMemoryWBWIPDataSource(wip_records, snapshot_dates=wip_snapshot_dates),
        output=InMemoryWBStageOutputDataSource(build_wb_stage_output_records()),
        issue=InMemoryWBIssueDataSource(build_wb_issue_records()),
    )

    service = build_deterministic_service(
        datasources=datasources,
        goal_statement=f"Check WB OEE status for {plant} on 2026-08-12.",
        task_type=TaskType.INFORMATION,
    )
    final_state = run_golden_scenario(service, f"請查詢 2026-08-12 {plant} 的 WB OEE 狀況。", run_id="g10")
    wb = final_state.module_states["WB"]

    print(f"\nG10 module_status: {wb.status.value}")
    print(f"G10 evidence: {[e.summary for e in wb.evidence]}")
    print(f"G10 findings: {[(f.statement, f.status.value) for f in wb.findings]}")

    evidence = wb.evidence[-1]
    payload = PayloadRegistry.unpack(evidence.structured_payload)

    print(f"G10 validation_issues: {getattr(payload, 'validation_issues', None)}")
    print(f"G10 usable_record_count: {getattr(payload, 'usable_record_count', None)}")

    # The invalid records (150.0 / -10.0) must never surface as reported
    # OEE values anywhere in evidence text or Finding statements.
    combined_text = evidence.summary + " " + " ".join(f.statement for f in wb.findings)
    assert "150.0" not in combined_text and "150%" not in combined_text
    assert "-10.0" not in combined_text and "-10%" not in combined_text

    # A validation issue must have been recorded (never silently dropped).
    has_validation_signal = bool(getattr(payload, "validation_issues", None)) or bool(wb.limitations)
    assert has_validation_signal, "invalid records were present but no validation issue/limitation was recorded anywhere"
