"""Phase PROD-1.4 T18 -- Synthesis compatibility with LLM-Reflector-produced
Hypotheses.

Gap: every Mode A Golden E2E test in this suite (test_information_analysis,
test_historical_rca, etc.) forces the Reflector route to fail, so Reflector
always falls back to WBPlanningPolicy -- which NEVER writes `hypotheses`
(only `LLMReflectionPolicy` does, see agent/planning/policies/wb.py's own
docstring). This means the entire PROD-1.3 Golden Matrix never actually
exercised a Hypothesis-bearing Finding flowing through Synthesis. This
test closes that gap with a scripted (Mock, not real-provider) Reflector
response that proposes a new Hypothesis and a CAUSAL_CANDIDATE-level
finding, then verifies: (1) the Hypothesis is genuinely recorded on
ModuleState, (2) Synthesis processes it without error, (3) Synthesis
never promotes the hypothesis-level finding into a confirmed root cause
or invents stronger causal language than the Reflector itself used."""
from agent.llm.client import MockLLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.models import LLMTimeoutError
from agent.llm.prompts.analyzer import AnalyzerDecision, ModuleSelection
from agent.llm.prompts.reflector import CausalLevel, FindingCandidate, HypothesisProposal, ObjectiveAssessment, ReflectionDecision, ReflectionVerdict
from agent.state.enums import TaskType

from .harness import AppConfig, _FACTORY_ID, _ROUTES, _assemble_service, _single_wb_package_registry, bootstrap_runtime, golden_wb_datasources, run_golden_scenario, wrap_wb_datasources

_PLANT = "ASE01"  # Scenario A -- real, genuinely abnormal OEE data
_REQUEST_TEXT = f"請查詢 2026-08-12 {_PLANT} 的 WB OEE 狀況。"
_GOAL_STATEMENT = f"Check WB OEE status for {_PLANT} on 2026-08-12."

_CAUSAL_WORDS = ("caused", "confirmed cause", "definitively", "proven cause")


def _scripted_reflector_responder(request):
    if request.route == "analyzer":
        return AnalyzerDecision(
            task_type=TaskType.INFORMATION, confidence=0.9, reasoning_summary="stand-in",
            selected_modules=[ModuleSelection(module_type="WB", priority=0.9, confidence=0.9, rationale="WB-shaped request", goal_statement=_GOAL_STATEMENT)],
        )
    if request.route == "reflector":
        return ReflectionDecision(
            verdict=ReflectionVerdict.SUPPORTS,
            objective_assessment=ObjectiveAssessment.SATISFIED,
            finding_candidate=FindingCandidate(
                statement=f"{_PLANT}'s OEE is abnormally low, consistent with an equipment-side loss.",
                pattern="WB OEE Loss", entity_ids=[_PLANT], causal_level=CausalLevel.CAUSAL_CANDIDATE,
            ),
            hypothesis_proposals=[
                HypothesisProposal(statement=f"Equipment downtime is contributing to {_PLANT}'s low OEE.", confidence=0.6, related_dimensions=["oee"]),
            ],
            should_continue=False,
            rationale_summary="OEE evidence supports an equipment-loss candidate; stopping here.",
        )
    raise LLMTimeoutError(f"route '{request.route}' intentionally never answered -- isolates Reflector-only hypothesis wiring.")


def test_t18_llm_reflector_hypothesis_flows_through_synthesis_without_causal_inflation():
    datasources = golden_wb_datasources()
    wrapped_datasources, recorders = wrap_wb_datasources(datasources)
    module_packages_registry = _single_wb_package_registry(wrapped_datasources)

    llm_client = MockLLMClient(_scripted_reflector_responder)
    app_config = AppConfig(
        factory_id=_FACTORY_ID, factory_name="Factory A", enabled_modules=["WB"],
        llm_routes={route: LLMRouteConfig(route=route, model="mock-deterministic", max_retries=0) for route in _ROUTES},
    )
    runtime_context = bootstrap_runtime(app_config, module_packages=module_packages_registry, llm_client=llm_client)
    service = _assemble_service(runtime_context, app_config)
    service.recorders = recorders

    final_state = run_golden_scenario(service, _REQUEST_TEXT, run_id="t18-hypothesis")
    wb = final_state.module_states["WB"]

    print(f"\n[T18] WB status: {wb.status.value}")
    print(f"[T18] hypotheses: {[(h.statement, h.status.value, h.confidence) for h in wb.hypotheses]}")
    print(f"[T18] findings: {[(f.statement, f.is_root_cause, f.status.value) for f in wb.findings]}")

    # The LLM-proposed Hypothesis is genuinely recorded -- proof
    # LLMReflectionPolicy.derive_state_updates actually wired it (the gap
    # this test closes), not just accepted and discarded.
    assert len(wb.hypotheses) >= 1
    assert any("downtime" in h.statement.lower() for h in wb.hypotheses)

    # CAUSAL_CANDIDATE never maps to is_root_cause=True (only
    # CONFIRMED_CAUSAL does, and WB can never reach that level -- see
    # _MODULE_TYPES_NEVER_CONFIRM_ROOT_CAUSE in llm_reflection.py).
    assert not any(f.is_root_cause for f in wb.findings)

    assert final_state.synthesis_result is not None
    markdown = final_state.synthesis_result.markdown
    print(f"[T18] synthesis markdown excerpt: {markdown[:300]!r}")
    markdown_lower = markdown.lower()
    for word in _CAUSAL_WORDS:
        assert word not in markdown_lower, f"Synthesis inflated a causal_candidate-level finding into stronger causal language: {word!r}"
