"""Phase PROD-1.4 T13 -- validation_issues lineage completeness.

PROD-1.3's own completion report (Section 18, NON-BLOCKING) claimed
`validation_issues` came back `None` on the OEE ranking payload even
though invalid records were correctly excluded. Re-verified directly this
phase by reading `agent/tools/wb/oee_tools.py` and
`agent/domain/wb/tool_results.py`: `validation_issues` is a field on
`WBDataAvailability` (`compute_availability(..., validation_issues=
outcome.issues, ...)`, oee_tools.py:144), NOT a top-level field on
`WBOEELossAnalysisResult`/`WBPlantOEEQueryResult` themselves. PROD-1.3's
own G10 test read `getattr(payload, "validation_issues", None)` --
one level too shallow -- which is why it printed `None`: that attribute
genuinely does not exist at that level, regardless of whether validation
ran. The correct, populated path is `payload.availability.validation_issues`.

This test proves the correct path is populated end to end: Tool Result ->
Evidence.structured_payload -> unpacked payload.availability.validation_issues,
using the exact same 2-valid/2-invalid OEE fixture PROD-1.3's G10 built."""
from agent.domain.wb.datasource import (
    InMemoryWBBankDataSource,
    InMemoryWBIssueDataSource,
    InMemoryWBPlantOEEDataSource,
    InMemoryWBStageOutputDataSource,
    InMemoryWBWIPDataSource,
)
from agent.domain.wb.synthetic import (
    GOLDEN_DATE,
    build_wb_bank_records,
    build_wb_issue_records,
    build_wb_plant_oee_records,
    build_wb_stage_output_records,
    build_wb_wip_records,
)
from agent.state.enums import TaskType
from agent.state.payload import PayloadRegistry
from agent.tools.wb.registration import WBDataSources

from .harness import build_deterministic_service, run_golden_scenario


def test_t13_validation_issues_lineage_is_correctly_threaded():
    plant = "ASE02"
    real_oee_records = build_wb_plant_oee_records()
    template = next(r for r in real_oee_records if r.plant_id == plant and r.production_date == GOLDEN_DATE)

    invalid_over_100 = template.model_copy(update={"operation_id": "9001", "oee": 150.0, "downtime_ratio": -30.0})
    invalid_negative = template.model_copy(update={"operation_id": "9002", "oee": -10.0})
    oee_records = real_oee_records + [invalid_over_100, invalid_negative]

    bank_records, bank_snapshot_dates = build_wb_bank_records()
    wip_records, wip_snapshot_dates = build_wb_wip_records()
    datasources = WBDataSources(
        oee=InMemoryWBPlantOEEDataSource(oee_records),
        bank=InMemoryWBBankDataSource(bank_records, snapshot_dates=bank_snapshot_dates),
        wip=InMemoryWBWIPDataSource(wip_records, snapshot_dates=wip_snapshot_dates),
        output=InMemoryWBStageOutputDataSource(build_wb_stage_output_records()),
        issue=InMemoryWBIssueDataSource(build_wb_issue_records()),
    )

    service = build_deterministic_service(
        datasources=datasources, goal_statement=f"Check WB OEE status for {plant} on 2026-08-12.", task_type=TaskType.INFORMATION,
    )
    final_state = run_golden_scenario(service, f"請查詢 2026-08-12 {plant} 的 WB OEE 狀況。", run_id="t13")
    wb = final_state.module_states["WB"]

    evidence = wb.evidence[-1]
    payload = PayloadRegistry.unpack(evidence.structured_payload)

    print(f"\n[T13] payload type: {type(payload).__name__}")
    print(f"[T13] payload.availability.validation_issues: {payload.availability.validation_issues}")
    print(f"[T13] payload.availability.usable_record_count: {payload.availability.usable_record_count}")
    print(f"[T13] payload.availability.record_count: {payload.availability.record_count}")

    # The CORRECT (nested) path is populated -- this is the fix: the
    # earlier report's own test checked the wrong attribute depth, not an
    # application defect.
    assert len(payload.availability.validation_issues) >= 1
    assert payload.availability.usable_record_count == 2  # the 2 real, unmodified ASE02 records
    assert payload.availability.record_count == 4  # 2 valid + 2 injected invalid, all genuinely returned by the DataSource

    # Confirm getattr(payload, "validation_issues", None) -- the shallow
    # path PROD-1.3's own G10 test used -- IS genuinely None, so the
    # earlier finding is reproduced exactly, not silently different data.
    assert getattr(payload, "validation_issues", None) is None

    # Lineage continues correctly into module-level Limitation reporting.
    assert len(wb.limitations) >= 1
