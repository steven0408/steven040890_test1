"""Phase PROD-1.3 Golden Scenarios G1/G2/G3/G6 -- INFORMATION/ANALYSIS
tier. Mode A (DETERMINISTIC / FALLBACK ACCEPTANCE) only in this file; Mode
B (LLM BEHAVIORAL ACCEPTANCE) scenarios live in test_llm_mode_b.py so a
missing OPENAI_API_KEY never affects this file's own pass/fail.
"""
from agent.state.enums import TaskType

from .harness import build_deterministic_service, route_sources, run_golden_scenario


def test_g1_oee_information_ase01():
    """G1 -- OEE INFORMATION. Verifies: requested date/plant preserved,
    Tool arguments reflect the Objective scope, Evidence contains the real
    synthetic result, and the final Markdown is grounded in it."""
    service = build_deterministic_service(goal_statement="Check WB OEE status for ASE01 on 2026-08-12.", task_type=TaskType.INFORMATION)
    final_state = run_golden_scenario(service, "請查詢 2026-08-12 ASE01 的 WB OEE 狀況。", run_id="g1")

    wb = final_state.module_states["WB"]
    assert wb.status.value == "complete"
    assert len(wb.tool_calls) >= 1

    oee_calls = service.recorders["oee"].calls
    assert any(c.method == "list_oee" and c.kwargs.get("production_date") == "2026-08-12" for c in oee_calls)

    objective_record = next(iter(wb.objective_history.values()))
    assert objective_record.target_ref.ref_id == "ASE01"

    evidence = wb.evidence[-1]
    assert "ASE01" in evidence.summary and "2026-08-12" in evidence.summary
    from agent.state.payload import PayloadRegistry

    payload = PayloadRegistry.unpack(evidence.structured_payload)
    worst_row = payload.ranking[0]
    assert worst_row.plant_id == "ASE01"
    assert worst_row.oee == 58.0  # Scenario A's own real, unmodified synthetic value

    markdown = final_state.synthesis_result.markdown
    assert "ASE01" in markdown


def test_g2_oee_analysis_worst_plant():
    """G2 -- OEE ANALYSIS. Compares plants; the worst-performing plant and
    dominant loss category must be data-derived (Scenario A / ASE01 is the
    real worst OEE in the golden dataset -- 58.0 vs. ~85 normal)."""
    service = build_deterministic_service(goal_statement="Analyze WB OEE status across plants on 2026-08-12 to find the worst performer.", task_type=TaskType.ANALYSIS)
    final_state = run_golden_scenario(service, "比較 2026-08-12 各 WB Plant 的 OEE，找出表現最差的 Plant 與主要 loss。", run_id="g2")

    wb = final_state.module_states["WB"]
    assert wb.status.value in ("complete", "partial")
    assert len(wb.tool_calls) >= 1
    assert service.recorders["oee"].call_count >= 1

    evidence_summary = wb.evidence[-1].summary
    assert "ASE01" in evidence_summary  # data-derived worst plant, never hardcoded in test setup


def test_g3_wip_current_status_ase03():
    """G3 -- WIP CURRENT STATUS. ASE03's Hold ratio must come from real
    synthetic WIP records (Scenario C: 22/30 hold on the golden day)."""
    service = build_deterministic_service(goal_statement="Analyze WB WIP Hold status for ASE03 on 2026-08-12.", task_type=TaskType.ANALYSIS)
    final_state = run_golden_scenario(service, "請分析 2026-08-12 ASE03 的 WB WIP Hold 狀況。", run_id="g3")

    wb = final_state.module_states["WB"]
    assert len(wb.tool_calls) >= 1
    wip_calls = service.recorders["wip"].calls
    assert any(c.method == "list_wip" for c in wip_calls)
    assert wip_calls[0].record_count is not None and wip_calls[0].record_count > 0

    objective_record = next(iter(wb.objective_history.values()))
    assert objective_record.target_ref.ref_id == "ASE03"
    evidence_summary = wb.evidence[-1].summary
    assert "22/30" in evidence_summary  # Scenario C's own real, unmodified 73.3% Hold ratio


def test_g6_output_analysis_lowest_plant():
    """G6 -- OUTPUT ANALYSIS. Ranking/lowest-plant must be data-derived."""
    service = build_deterministic_service(goal_statement="Compare WB stage output across plants on 2026-08-12 to find the lowest.", task_type=TaskType.ANALYSIS)
    final_state = run_golden_scenario(service, "比較 2026-08-12 WB 各 Plant Output，找出最低的 Plant。", run_id="g6")

    wb = final_state.module_states["WB"]
    assert len(wb.tool_calls) >= 1
    output_calls = service.recorders["output"].calls
    assert any(c.method == "list_output" for c in output_calls)
    assert output_calls[0].record_count is not None and output_calls[0].record_count > 0
