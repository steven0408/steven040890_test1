"""Phase PROD-1.3 Section VIII -- the central behavioral test: is the
Planner actually reading Evidence, or just running a fixed sequence?

WBPlanningPolicy._propose_output_rca walks a FIXED contributing-factor
ORDER (`_RCA_CONTRIBUTING_ORDER = ("bank", "wip", "oee")`) but the
STOPPING POINT is entirely evidence-driven: it halts at the first
ABNORMAL contributing factor and never even queries the rest. This test
constructs two variants with an IDENTICAL user request/plant/date -- only
the underlying synthetic Evidence differs -- and proves the Planner's
actual round sequence differs accordingly.

Variant A: real, unmodified ASE07 (Scenario B) data -- BANK is abnormal
(elevated material-shortage). Expected: Planner stops after BANK; WIP/OEE
are never queried at all.

Variant B: same plant/date, BANK data replaced with a normal plant's
records (relabeled), WIP data replaced with Scenario C's (ASE03)
abnormal Hold pattern (relabeled). Expected: Planner checks BANK, finds
it normal ("ruled out"), continues to WIP, stops there. OEE is still
never queried.

If both variants produced the identical round sequence, that would be
FIXED-SEQUENCE BEHAVIOR -- this test reports that honestly if observed,
rather than forcing a particular outcome."""
from agent.domain.wb.datasource import (
    InMemoryWBBankDataSource,
    InMemoryWBIssueDataSource,
    InMemoryWBPlantOEEDataSource,
    InMemoryWBStageOutputDataSource,
    InMemoryWBWIPDataSource,
)
from datetime import timedelta

from agent.domain.wb.synthetic import (
    GOLDEN_DATE,
    SCENARIO_B_PLANT,
    SCENARIO_C_PLANT,
    SCENARIO_D_PLANT,
    build_wb_bank_records,
    build_wb_issue_records,
    build_wb_plant_oee_records,
    build_wb_stage_output_records,
    build_wb_wip_records,
)
from agent.state.enums import TaskType
from agent.tools.wb.registration import WBDataSources

from .harness import build_deterministic_service, run_golden_scenario

_TARGET_PLANT = SCENARIO_B_PLANT  # "ASE07" -- identical in both variants
_REQUEST_TEXT = f"請分析 2026-08-12 {_TARGET_PLANT} Output 偏低的原因。"  # IDENTICAL for both variants -- no historical wording, so this stays on the plain (single-round-per-factor) _propose_output_rca path
_GOAL_STATEMENT = f"Investigate why WB output was low at {_TARGET_PLANT} on 2026-08-12."  # IDENTICAL for both variants


def _round_capability_keys(wb_module_state) -> list[str]:
    return [r.capability_key for r in sorted(wb_module_state.objective_history.values(), key=lambda r: r.created_step)]


def _variant_a_real_bank_abnormal() -> WBDataSources:
    """Unmodified golden dataset -- ASE07's real BANK data is already
    Scenario B's own documented material-shortage pattern."""
    bank_records, bank_snapshot_dates = build_wb_bank_records()
    wip_records, wip_snapshot_dates = build_wb_wip_records()
    return WBDataSources(
        oee=InMemoryWBPlantOEEDataSource(build_wb_plant_oee_records()),
        bank=InMemoryWBBankDataSource(bank_records, snapshot_dates=bank_snapshot_dates),
        wip=InMemoryWBWIPDataSource(wip_records, snapshot_dates=wip_snapshot_dates),
        output=InMemoryWBStageOutputDataSource(build_wb_stage_output_records()),
        issue=InMemoryWBIssueDataSource(build_wb_issue_records()),
    )


def _variant_b_bank_normal_wip_abnormal() -> WBDataSources:
    """Same plant/date/Output-low symptom, but BANK is relabeled from a
    normal control plant (Scenario D / ASE02, no material-shortage
    concentration) and WIP is relabeled from Scenario C's (ASE03) own
    documented abnormal Hold pattern -- both real golden records, only
    `plant_id` overridden via `model_copy` so the target plant's identity
    changes, never the underlying record shape/values."""
    bank_records, bank_snapshot_dates = build_wb_bank_records()
    wip_records, wip_snapshot_dates = build_wb_wip_records()

    # BANK: drop ASE07's own (abnormal) records, splice in ASE02's
    # (normal) records relabeled as ASE07. SummarizeWBBankStatusTool
    # filters by plant_id BEFORE picking the latest snapshot (see
    # agent/tools/wb/bank_tools.py::_fetch), so this fully controls what
    # "ASE07's current bank status" resolves to.
    other_plant_bank = [r for r in bank_records if r.plant_id != _TARGET_PLANT]
    normal_donor_bank = [r for r in bank_records if r.plant_id == SCENARIO_D_PLANT]
    relabeled_bank = [r.model_copy(update={"plant_id": _TARGET_PLANT}) for r in normal_donor_bank]
    new_bank_records = other_plant_bank + relabeled_bank
    # snapshot_dates is keyed by id(record); kept records preserve their
    # original id-keyed entries, model_copy'd records get NEW ids so they
    # fall back to `source_sync_time.date()` (already the correct golden-
    # dataset day for the donor records) -- no new entries needed.
    new_bank_snapshot_dates = bank_snapshot_dates

    # WIP: only the golden-date snapshot matters (RCA's wip capability is
    # single-snapshot-dated) -- drop ASE07's golden-date-snapshot records,
    # splice in ASE03's golden-date-snapshot Hold-abnormal records
    # relabeled as ASE07. Other snapshot days are left untouched (unused
    # by this capability).
    def _snapshot_date_of(r, mapping):
        return mapping.get(id(r), r.source_sync_time.date())

    kept_wip = [
        r for r in wip_records
        if not (r.plant_id == _TARGET_PLANT and _snapshot_date_of(r, wip_snapshot_dates) == GOLDEN_DATE)
    ]
    donor_wip = [
        r for r in wip_records
        if r.plant_id == SCENARIO_C_PLANT and _snapshot_date_of(r, wip_snapshot_dates) == GOLDEN_DATE
    ]
    assert donor_wip, "Scenario C's own golden-date WIP records must exist in the real dataset"
    relabeled_wip = [r.model_copy(update={"plant_id": _TARGET_PLANT}) for r in donor_wip]
    new_wip_records = kept_wip + relabeled_wip

    return WBDataSources(
        oee=InMemoryWBPlantOEEDataSource(build_wb_plant_oee_records()),
        bank=InMemoryWBBankDataSource(new_bank_records, snapshot_dates=new_bank_snapshot_dates),
        wip=InMemoryWBWIPDataSource(new_wip_records, snapshot_dates=wip_snapshot_dates),
        output=InMemoryWBStageOutputDataSource(build_wb_stage_output_records()),  # unchanged -- ASE07's real Output stays low in both variants
        issue=InMemoryWBIssueDataSource(build_wb_issue_records()),
    )


def test_ab1_output_rca_contributing_factor_evidence_sensitivity():
    service_a = build_deterministic_service(datasources=_variant_a_real_bank_abnormal(), goal_statement=_GOAL_STATEMENT, task_type=TaskType.RCA)
    final_a = run_golden_scenario(service_a, _REQUEST_TEXT, run_id="ab1-variant-a")
    wb_a = final_a.module_states["WB"]
    rounds_a = _round_capability_keys(wb_a)

    service_b = build_deterministic_service(datasources=_variant_b_bank_normal_wip_abnormal(), goal_statement=_GOAL_STATEMENT, task_type=TaskType.RCA)
    final_b = run_golden_scenario(service_b, _REQUEST_TEXT, run_id="ab1-variant-b")
    wb_b = final_b.module_states["WB"]
    rounds_b = _round_capability_keys(wb_b)

    print(f"\n[A/B evidence sensitivity] identical request: {_REQUEST_TEXT!r}")
    print(f"Variant A (BANK abnormal)  rounds: {rounds_a}")
    print(f"Variant A findings: {[f.statement for f in wb_a.findings]}")
    print(f"Variant B (BANK normal, WIP abnormal) rounds: {rounds_b}")
    print(f"Variant B findings: {[f.statement for f in wb_b.findings]}")

    if rounds_a == rounds_b:
        raise AssertionError(
            "FIXED-SEQUENCE BEHAVIOR DETECTED: identical round sequence "
            f"{rounds_a!r} regardless of BANK/WIP evidence -- Planner did "
            "not react to the injected evidence difference. Reporting "
            "this honestly per Phase PROD-1.3 Section XV, not hiding it."
        )

    # Variant A: BANK abnormal must be the LAST contributing-factor round
    # checked -- WIP/OEE never queried because BANK already supplied a
    # supported candidate.
    assert "wb.bank.status_summary" in rounds_a
    assert "wb.wip.hold_analysis" not in rounds_a
    assert "wb.oee.plant_status" not in rounds_a

    # Variant B: BANK checked and REJECTED (ruled out), so the Planner
    # continues to WIP and stops there -- OEE still never reached.
    assert "wb.bank.status_summary" in rounds_b
    assert "wb.wip.hold_analysis" in rounds_b
    assert "wb.oee.plant_status" not in rounds_b
    # BANK must be checked BEFORE WIP in variant B (the fixed ORDER part
    # of the design -- only the stopping point is evidence-driven, not
    # the visitation order itself).
    assert rounds_b.index("wb.bank.status_summary") < rounds_b.index("wb.wip.hold_analysis")

    # Variant B's Finding text must land on the WIP Hold explanation (the
    # contributing factor the Planner actually stopped on), proving the
    # eventual root-cause candidate itself tracks the injected evidence.
    combined_b = " ".join(f.statement for f in wb_b.findings).lower()
    assert "hold" in combined_b


# --- A second, independent A/B pair (spec requires at least TWO) ----------
#
# WBPlanningPolicy._propose_historical_rca (topic="wip") always runs the
# SAME two rounds (symptom, then trend) regardless of the trend's shape --
# so this pair proves evidence-sensitivity through a different channel:
# the deterministic FindingDescription wording itself, computed strictly
# from `metrics.recurrence_count`/`consecutive_abnormal_days`
# (`_describe_trend_finding`, wb.py line ~721), never from a hardcoded
# template. Same plant, same date, same identical request; only the
# WIP snapshot history differs.

_AB2_PLANT = SCENARIO_C_PLANT  # "ASE03" in both variants
_AB2_REQUEST_TEXT = f"請分析 {_AB2_PLANT} 最近一週至 2026-08-12 的 WB WIP Hold 是否持續異常，並找出可能原因。"
_AB2_GOAL_STATEMENT = f"Investigate whether WB WIP Hold at {_AB2_PLANT} has been persistently abnormal over the recent week up to 2026-08-12 and find a likely cause."
_AB2_WINDOW_OTHER_ABNORMAL_DAYS = (  # the real Scenario C recurring days besides the golden date itself
    GOLDEN_DATE - timedelta(days=2), GOLDEN_DATE - timedelta(days=4), GOLDEN_DATE - timedelta(days=6),
)


def _snapshot_date_of(record, mapping) -> "date":
    return mapping.get(id(record), record.source_sync_time.date())


def _ab2_variant_a_real_recurring() -> WBDataSources:
    """Unmodified golden dataset -- ASE03's real WIP Hold pattern is
    recurring-but-not-consecutive (4 of 7 trailing days)."""
    wip_records, wip_snapshot_dates = build_wb_wip_records()
    bank_records, bank_snapshot_dates = build_wb_bank_records()
    return WBDataSources(
        oee=InMemoryWBPlantOEEDataSource(build_wb_plant_oee_records()),
        bank=InMemoryWBBankDataSource(bank_records, snapshot_dates=bank_snapshot_dates),
        wip=InMemoryWBWIPDataSource(wip_records, snapshot_dates=wip_snapshot_dates),
        output=InMemoryWBStageOutputDataSource(build_wb_stage_output_records()),
        issue=InMemoryWBIssueDataSource(build_wb_issue_records()),
    )


def _ab2_variant_b_isolated_single_day() -> WBDataSources:
    """Same plant/date/golden-day symptom (still abnormal on 2026-08-12,
    unchanged), but the OTHER 3 abnormal days in the 7-day window are
    replaced with a normal donor plant's (ASE02) own same-calendar-day WIP
    records relabeled to ASE03 -- leaving only the golden date itself
    abnormal (a genuine isolated single-day spike shape)."""
    wip_records, wip_snapshot_dates = build_wb_wip_records()
    bank_records, bank_snapshot_dates = build_wb_bank_records()

    other_days_to_replace = set(_AB2_WINDOW_OTHER_ABNORMAL_DAYS)
    kept_wip = [
        r for r in wip_records
        if not (r.plant_id == _AB2_PLANT and _snapshot_date_of(r, wip_snapshot_dates) in other_days_to_replace)
    ]
    donor_wip = [
        r for r in wip_records
        if r.plant_id == SCENARIO_D_PLANT and _snapshot_date_of(r, wip_snapshot_dates) in other_days_to_replace
    ]
    assert donor_wip, "normal-control-plant WIP records must exist for the replaced days"
    relabeled_wip = [r.model_copy(update={"plant_id": _AB2_PLANT}) for r in donor_wip]
    new_wip_records = kept_wip + relabeled_wip

    return WBDataSources(
        oee=InMemoryWBPlantOEEDataSource(build_wb_plant_oee_records()),
        bank=InMemoryWBBankDataSource(bank_records, snapshot_dates=bank_snapshot_dates),
        wip=InMemoryWBWIPDataSource(new_wip_records, snapshot_dates=wip_snapshot_dates),
        output=InMemoryWBStageOutputDataSource(build_wb_stage_output_records()),
        issue=InMemoryWBIssueDataSource(build_wb_issue_records()),
    )


def test_ab2_wip_historical_trend_recurring_vs_isolated_spike():
    service_a = build_deterministic_service(datasources=_ab2_variant_a_real_recurring(), goal_statement=_AB2_GOAL_STATEMENT, task_type=TaskType.RCA)
    final_a = run_golden_scenario(service_a, _AB2_REQUEST_TEXT, run_id="ab2-variant-a")
    wb_a = final_a.module_states["WB"]

    service_b = build_deterministic_service(datasources=_ab2_variant_b_isolated_single_day(), goal_statement=_AB2_GOAL_STATEMENT, task_type=TaskType.RCA)
    final_b = run_golden_scenario(service_b, _AB2_REQUEST_TEXT, run_id="ab2-variant-b")
    wb_b = final_b.module_states["WB"]

    findings_a = [f.statement for f in wb_a.findings]
    findings_b = [f.statement for f in wb_b.findings]
    print(f"\n[A/B2 evidence sensitivity] identical request: {_AB2_REQUEST_TEXT!r}")
    print(f"Variant A (recurring 4/7 days) findings: {findings_a}")
    print(f"Variant B (isolated single-day spike) findings: {findings_b}")

    text_a = " ".join(findings_a).lower()
    text_b = " ".join(findings_b).lower()

    if text_a == text_b:
        raise AssertionError(
            "FIXED-SEQUENCE BEHAVIOR DETECTED: identical Finding text "
            "regardless of whether the WIP Hold pattern was recurring or "
            "an isolated single-day spike -- the historical trend "
            "classification did not react to the injected evidence."
        )

    # Variant A must land on the recurring/persistent wording; Variant B
    # must land on the single-day-event wording -- both are the real,
    # deterministic `_describe_trend_finding` classifications, never
    # asserted values invented by this test.
    assert "recurring" in text_a
    assert "single-day" in text_b
    assert "single-day" not in text_a
    assert "recurring" not in text_b
