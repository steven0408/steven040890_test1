"""Phase PROD-1.4 T1 -- WB Analyzer fallback routing.

PROD-1.3's own completion report claimed (Section 18, BLOCKING gap) that
"there is no deterministic, zero-LLM way to route a WB request through
the real Analyzer node." Re-verified directly this phase by reading
`agent/graph/nodes/analyzer_llm.py` and `agent/graph/nodes/analyzer_mock.py`
side by side: that finding was accurate ONLY about `analyzer_mock.py` (a
Phase-2 legacy fixture that hardcodes OEE/Output/WIP module dispatch and
is structurally UNREACHABLE in the real production graph -- see
`agent/graph/production.py`'s own `build_production_graph[_with_synthesis]`,
which requires an explicit `analyzer` argument and raises `TypeError`
without one, precisely to keep `analyzer_mock` out of production).

The Analyzer node actually used in production (`AnalyzerLLMService` via
`make_analyzer_llm_node`) has its OWN internal deterministic fallback,
`_deterministic_fallback_decision`, which reads the real `ModuleRegistry`
generically (`module_registry.available_for(factory_context)`, filtered
by `task_type in m.supported_task_types`) -- no hardcoded module list at
all. Since `agent/bootstrap.py` registers every `ModulePackage`'s own
`ModuleDefinition` into that same registry (`module_registry.register(
package.module_definition)`), WB is already visible to this fallback
whenever it's an enabled module for the factory.

This test proves that empirically, correcting the prior report's
imprecise framing rather than "fixing" a gap that does not exist on the
reachable production path."""
from agent.state.enums import TaskType

from .harness import build_fully_deterministic_service, route_sources, run_golden_scenario


def test_t1_wb_analyzer_fallback_routes_to_wb_module():
    """WB request -> Analyzer LLM failure -> deterministic fallback ->
    ModuleTask(module_type='WB') -> WB module executes. No scripted
    Analyzer stand-in anywhere in this chain (unlike every other Golden
    E2E test in this suite, which uses `build_deterministic_service`'s
    scripted Analyzer seam for goal_statement control)."""
    service = build_fully_deterministic_service()
    final_state = run_golden_scenario(service, "請查詢 2026-08-12 ASE01 的 WB OEE 狀況。", run_id="t1-analyzer-fallback")

    sources = route_sources(service, "t1-analyzer-fallback")
    print(f"\n[T1] route sources: {sources}")
    assert sources["analyzer"] == "fallback"

    assert "WB" in final_state.module_states
    wb = final_state.module_states["WB"]
    print(f"[T1] WB module status: {wb.status.value}")
    print(f"[T1] WB tool_calls: {len(wb.tool_calls)}")

    # The WB module must have genuinely EXECUTED (not merely been
    # selected) -- real Objective/Tool/Evidence, same as any other Golden
    # scenario, proving the fallback-routed ModuleTask is fully viable,
    # not just structurally present.
    assert len(wb.tool_calls) >= 1
    assert len(wb.objective_history) >= 1
    assert wb.status.value in ("complete", "partial")

    oee_calls = service.recorders["oee"].calls
    assert any(c.method == "list_oee" for c in oee_calls)


def test_t1b_non_wb_shaped_request_does_not_force_wb_selection():
    """Sanity check on the OTHER side of T1: the generic
    `_deterministic_fallback_decision` selects modules by task_type
    applicability alone (WB supports INFORMATION/ANALYSIS/RCA, i.e.
    effectively always) -- confirming this is registry-driven selection,
    not a hardcoded 'always WB' shortcut, by checking the selection
    reasoning is the documented generic fallback string, never a
    Golden-Scenario-specific keyword match."""
    service = build_fully_deterministic_service()
    final_state = run_golden_scenario(service, "請查詢 2026-08-12 ASE01 的 WB OEE 狀況。", run_id="t1b-generic-check")

    selected = final_state.selected_modules
    assert len(selected) == 1
    assert selected[0].module_type == "WB"
    assert "Deterministic fallback selection" in selected[0].reason
