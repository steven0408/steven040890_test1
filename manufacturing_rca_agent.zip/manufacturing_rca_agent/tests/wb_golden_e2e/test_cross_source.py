"""Phase PROD-1.3 Golden Scenario G8 -- CROSS-SOURCE ISSUE vs OUTPUT.

Critical per spec: verify BOTH Tools/DataSources actually executed,
business-date join, overlap reported honestly, relationship strictly
descriptive -- never causal wording ("X caused Y" is forbidden; "X
coincided with Y" / "moved in the same direction" is the only vocabulary
this Tool's own result model supports -- WBIssueOutputRelationshipResult
has no causal field at all)."""
from agent.state.enums import TaskType
from agent.state.payload import PayloadRegistry

from .harness import build_deterministic_service, run_golden_scenario

_FORBIDDEN_CAUSAL_WORDS = ("caused", "causes", "causing", "due to", "led to", "because of", "resulted in")


def test_g8_cross_source_issue_vs_output_ase07():
    """ASE07 (Scenario B) is the one golden plant where BOTH Output is low
    AND Issue genuinely declines -- the only plant that can walk
    WBPlanningPolicy's full 4-round Output-oriented historical RCA chain:
    output symptom -> output trend -> issue trend -> cross-source
    relationship. This is a real multi-round Planner loop, not a
    single scripted Tool call."""
    service = build_deterministic_service(
        goal_statement="Investigate the WB output shortfall history and trend at ASE07 over the recent two weeks up to 2026-08-12, including any related issue quantity trend.",
        task_type=TaskType.RCA,
    )
    final_state = run_golden_scenario(
        service, "請分析 2026-08-12 ASE07 最近兩週 WB Output 偏低的歷史與可能原因，並比較 Issue 投料趨勢。", run_id="g8"
    )
    wb = final_state.module_states["WB"]

    rounds = [
        (r.capability_key, r.status.value)
        for r in sorted(wb.objective_history.values(), key=lambda r: r.created_step)
    ]
    print(f"\nG8 rounds: {rounds}")
    print(f"G8 findings: {[f.statement for f in wb.findings]}")
    print(f"G8 output calls: {service.recorders['output'].summary()}")
    print(f"G8 issue calls: {service.recorders['issue'].summary()}")

    capability_keys = [ck for ck, _ in rounds]
    assert "wb.output.comparison" in capability_keys  # symptom check
    assert "wb.output.trend_analysis" in capability_keys  # output historical
    assert "wb.issue.trend_analysis" in capability_keys  # issue historical -- proves ISSUE data source actually consulted
    assert "wb.issue_output.relationship_analysis" in capability_keys  # cross-source, evidence-gated (only reached because issue ALSO declined)

    # Both underlying DataSources were genuinely queried, not just one
    # Tool run twice -- direct proof both sources were consumed.
    assert service.recorders["output"].call_count >= 1
    assert service.recorders["issue"].call_count >= 1

    # Locate the cross-source relationship evidence and inspect its
    # structured payload directly -- the strongest possible proof that no
    # causal field/language exists anywhere in the result.
    relationship_evidence = next(
        e for e in wb.evidence if e.objective_id == next(r.objective_id for r in wb.objective_history.values() if r.capability_key == "wb.issue_output.relationship_analysis")
    )
    payload = PayloadRegistry.unpack(relationship_evidence.structured_payload)
    assert not hasattr(payload, "causal") and not hasattr(payload, "causation") and not hasattr(payload, "is_cause")
    assert payload.direction_alignment.value in ("same_direction", "opposite_direction", "mixed", "insufficient_data")

    combined_text = (relationship_evidence.summary + " " + " ".join(f.statement for f in wb.findings)).lower()
    for forbidden in _FORBIDDEN_CAUSAL_WORDS:
        assert forbidden not in combined_text, f"causal wording leaked into evidence/finding text: {forbidden!r}"

    # Overlap/join must be honestly reported -- business-date aggregation,
    # never silently dropping the mismatch between Output's production_date
    # and Issue's release_date semantics.
    assert payload.overlap_observed_days >= 0

    # Synthesis must not upgrade the relationship into causation either.
    if final_state.synthesis_result is not None:
        markdown_lower = final_state.synthesis_result.markdown.lower()
        for forbidden in _FORBIDDEN_CAUSAL_WORDS:
            assert forbidden not in markdown_lower, f"causal wording leaked into synthesis markdown: {forbidden!r}"
