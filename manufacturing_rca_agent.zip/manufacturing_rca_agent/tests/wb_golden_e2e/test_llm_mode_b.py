"""Phase PROD-1.3/PROD-1.4 Mode B -- "LLM BEHAVIORAL ACCEPTANCE" (spec
Section IV / Section XXVI).

Skipped entirely (never a phase failure) unless OPENAI_API_KEY is already
present in this environment. When it IS present, this is still explicitly
an OpenAI Cloud regression environment -- NEVER formal production
internal-LLM acceptance -- and every assertion/print here is labeled
accordingly.

Phase PROD-1.4 Section XXVII hardening: a test in this file may NOT treat
a silent Planner/Reflector fallback as an LLM success. Every test that
claims to prove LLM cognitive decision-making asserts `source == LLM` on
EVERY round via `planner_decisions`/`reflection_decisions` (not just
`route_sources`' coarser "at least one llm call this run" signal) --
if any round fell back, the test FAILS loudly rather than silently
passing on deterministic-fallback behavior it never intended to exercise.
"""
import os

import pytest

from agent.llm.models import DecisionSource
from agent.state.enums import TaskType

from .harness import build_llm_service_if_available, planner_decisions, reflection_decisions, route_sources, run_golden_scenario

pytestmark = pytest.mark.skipif(
    not os.environ.get("OPENAI_API_KEY"),
    reason="Mode B (LLM Behavioral Acceptance) requires OPENAI_API_KEY -- SKIPPED, not a phase failure. "
    "NOTE even when present, this is an OpenAI Cloud regression only, never formal production internal-LLM acceptance.",
)


def _assert_all_llm_sourced(records, *, label: str) -> None:
    """Section XXVII: FAIL, don't silently pass, on any fallback round."""
    assert records, f"{label}: no decision records at all -- nothing to verify"
    fallback_rounds = [r for r in records if r.source != DecisionSource.LLM]
    assert not fallback_rounds, (
        f"{label}: {len(fallback_rounds)}/{len(records)} round(s) fell back to the deterministic policy instead of "
        f"using the LLM -- reasons: {[r.fallback_reason for r in fallback_rounds]}. Per Section XXVII this is a "
        f"test FAILURE, not a silently-accepted 'LLM success'."
    )


def test_mode_b_g1_oee_information_ase01_llm_driven():
    """OPENAI CLOUD REGRESSION ONLY -- not formal production LLM acceptance."""
    service = build_llm_service_if_available()
    assert service is not None  # guaranteed by pytestmark above
    final_state = run_golden_scenario(service, "請查詢 2026-08-12 ASE01 的 WB OEE 狀況。", run_id="mode-b-g1")

    sources = route_sources(service, "mode-b-g1")
    print(f"\n[Mode B / OpenAI Cloud regression] route sources: {sources}")

    wb = final_state.module_states["WB"]
    assert wb.status.value == "complete"
    assert len(wb.tool_calls) >= 1
    assert "ASE01" in wb.evidence[-1].summary

    _assert_all_llm_sourced(planner_decisions(service, "mode-b-g1"), label="G1 planner")
    _assert_all_llm_sourced(reflection_decisions(service, "mode-b-g1"), label="G1 reflector")
    for route in ("standardizer", "analyzer", "synthesis"):
        print(f"  route={route} source={sources.get(route)}")


def test_t7_ab_evidence_sensitivity_llm_driven():
    """T7 / Section XVIII (the most important acceptance test) --
    OPENAI CLOUD REGRESSION ONLY. Re-runs the same BANK-abnormal vs
    BANK-normal/WIP-abnormal A/B pair from test_ab_evidence_sensitivity.py
    through the REAL LLM-backed composition (not the deterministic
    fallback), hard-asserting every Planner/Reflector round in BOTH
    variants actually used the LLM (Section XXVII), then verifying the
    LLM's own chosen capability sequence/hypothesis state differs between
    variants -- i.e. Evidence genuinely changes what the LLM decides,
    not what WBPlanningPolicy would have decided."""
    from .test_ab_evidence_sensitivity import (
        _GOAL_STATEMENT,
        _REQUEST_TEXT,
        _variant_a_real_bank_abnormal,
        _variant_b_bank_normal_wip_abnormal,
    )

    service_a = build_llm_service_if_available(datasources=_variant_a_real_bank_abnormal())
    assert service_a is not None
    final_a = run_golden_scenario(service_a, _REQUEST_TEXT, run_id="t7-ab-variant-a")
    wb_a = final_a.module_states["WB"]
    rounds_a = [r.capability_key for r in sorted(wb_a.objective_history.values(), key=lambda r: r.created_step)]
    planner_records_a = planner_decisions(service_a, "t7-ab-variant-a")
    reflector_records_a = reflection_decisions(service_a, "t7-ab-variant-a")

    service_b = build_llm_service_if_available(datasources=_variant_b_bank_normal_wip_abnormal())
    final_b = run_golden_scenario(service_b, _REQUEST_TEXT, run_id="t7-ab-variant-b")
    wb_b = final_b.module_states["WB"]
    rounds_b = [r.capability_key for r in sorted(wb_b.objective_history.values(), key=lambda r: r.created_step)]
    planner_records_b = planner_decisions(service_b, "t7-ab-variant-b")
    reflector_records_b = reflection_decisions(service_b, "t7-ab-variant-b")

    # Bounded trace (Section XXVIII shape) -- printed, never asserted
    # against exact wording (an LLM's own phrasing is not reproducible
    # byte-for-byte run to run).
    print(f"\n[T7 / Mode B] identical request: {_REQUEST_TEXT!r}")
    for label, rounds, planner_records, reflector_records in (
        ("Variant A (BANK abnormal)", rounds_a, planner_records_a, reflector_records_a),
        ("Variant B (BANK normal, WIP abnormal)", rounds_b, planner_records_b, reflector_records_b),
    ):
        print(f"-- {label} --")
        print(f"   capability sequence: {rounds}")
        for i, rec in enumerate(planner_records, start=1):
            print(f"   round {i}: planner_source={rec.source.value} capability={rec.proposed_capability_key} rationale={rec.rationale_summary[:160]!r}")
        for i, rec in enumerate(reflector_records, start=1):
            print(f"   round {i}: reflector_source={rec.source.value} verdict={rec.verdict.value} should_continue={rec.should_continue} rationale={rec.rationale_summary[:160]!r}")

    # Section XXVII: hard requirement, not a soft note.
    _assert_all_llm_sourced(planner_records_a, label="Variant A planner")
    _assert_all_llm_sourced(reflector_records_a, label="Variant A reflector")
    _assert_all_llm_sourced(planner_records_b, label="Variant B planner")
    _assert_all_llm_sourced(reflector_records_b, label="Variant B reflector")

    # The central claim: genuine LLM decisions, not WBPlanningPolicy's own
    # fixed order, differ across the A/B evidence variants. An LLM is not
    # guaranteed to reproduce the exact deterministic-mode sequence, so
    # this checks for ANY observable difference (capability sequence,
    # round count, or which hypothesis got confirmed/refuted) rather than
    # asserting the precise deterministic-mode wording.
    hypotheses_a = {h.statement for h in wb_a.hypotheses}
    hypotheses_b = {h.statement for h in wb_b.hypotheses}
    observably_different = (rounds_a != rounds_b) or (len(rounds_a) != len(rounds_b)) or (hypotheses_a != hypotheses_b)
    if not observably_different:
        raise AssertionError(
            "FIXED-SEQUENCE BEHAVIOR DETECTED under genuine LLM mode: identical capability sequence AND identical "
            f"hypothesis set regardless of injected BANK/WIP evidence -- rounds_a={rounds_a}, rounds_b={rounds_b}. "
            "Reporting this honestly per Section XV/XXXVII, not hiding it."
        )
