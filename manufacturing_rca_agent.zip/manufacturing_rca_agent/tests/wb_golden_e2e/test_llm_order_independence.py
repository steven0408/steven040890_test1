"""Phase PROD-1.4 Section XIX -- proves the production LLM happy path does
NOT force `_RCA_CONTRIBUTING_ORDER = ("bank", "wip", "oee")`
(agent/planning/policies/wb.py:332) onto the LLM Planner.

This is a WIRING/STRUCTURAL proof, not a reasoning-quality proof (it uses
a scripted MockLLMClient, not a real LLM -- Mode B in test_llm_mode_b.py
is where genuine LLM reasoning is exercised, gated on OPENAI_API_KEY).
What this test can and does prove without any real provider: when the
LLM Planner's OWN decision deliberately CONTRADICTS the order
WBPlanningPolicy's fallback would have chosen (jumping straight to OEE
on a plant whose real BANK data is abnormal -- the fallback would
investigate BANK first, per `_propose_output_rca`'s own contributing-
factor walk), the system actually EXECUTES the LLM's own contradicting
choice rather than silently substituting WBPlanningPolicy's answer.
This is possible only because `LLMPlanningPolicy.propose_next_objective`'s
happy-path try-block never calls `self._baseline` at all (confirmed by
direct reading of agent/planning/policies/llm.py:306-333) -- the fixed
order exists exclusively inside the FALLBACK branch, structurally
unreachable from the LLM path unless the LLM call itself fails."""
from datetime import date

from agent.llm.client import MockLLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.models import LLMTimeoutError
from agent.llm.prompts.analyzer import AnalyzerDecision, ModuleSelection
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.state.enums import ObjectiveAction, TargetRefType, TaskType
from agent.state.models import TargetRef
from agent.state.scope import ObjectiveScope, ScopeFilter, ScopeOperator, TimeScope, TimeScopeKind

from .harness import (
    AppConfig,
    _FACTORY_ID,
    _ROUTES,
    _assemble_service,
    _single_wb_package_registry,
    bootstrap_runtime,
    golden_wb_datasources,
    route_sources,
    run_golden_scenario,
    wrap_wb_datasources,
)

_PLANT = "ASE07"  # Scenario B -- real, abnormal BANK data; the deterministic fallback would investigate BANK first
_REQUEST_TEXT = f"請分析 2026-08-12 {_PLANT} Output 偏低的原因。"
_GOAL_STATEMENT = f"Investigate why WB output was low at {_PLANT} on 2026-08-12."


def _order_defying_responder(request):
    """Analyzer: scripted WB selection (same shape as harness.py's own
    Mode A stand-in). Planner ROUND 1: scripted to jump straight to
    `wb.oee.plant_status` -- deliberately skipping `wb.output.comparison`
    (the symptom check) AND `wb.bank.status_summary` (the fallback's own
    first contributing-factor choice for this exact plant), the two moves
    WBPlanningPolicy's own deterministic order would make first. Every
    other route fails, forcing real deterministic fallback for
    Standardizer/Reflector/Synthesis -- this test isolates ONLY the
    Planner's own order-independence, nothing else."""

    def _responder(req):
        if req.route == "analyzer":
            return AnalyzerDecision(
                task_type=TaskType.RCA, confidence=0.9, reasoning_summary="deterministic stand-in",
                selected_modules=[ModuleSelection(module_type="WB", priority=0.9, confidence=0.9, rationale="WB-shaped request", goal_statement=_GOAL_STATEMENT)],
            )
        if req.route == "planner":
            return PlannerDecision(
                decision=PlannerDecisionType.DISPATCH,
                next_objective=ObjectiveProposal(
                    action=ObjectiveAction.SUMMARIZE,
                    capability_key="wb.oee.plant_status",
                    target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id=_PLANT),
                    scope=ObjectiveScope(
                        time=TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, date=date(2026, 8, 12)),
                        filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value=_PLANT)],
                    ),
                    description="LLM deliberately chose OEE first, contradicting the deterministic bank-first order.",
                    expected_output="OEE status for the plant",
                ),
                priority=0.9, rationale_summary="Order-independence test: choosing OEE first on purpose.",
            )
        raise LLMTimeoutError(f"route '{req.route}' intentionally never answered -- isolates Planner-only order independence.")

    return _responder


def test_llm_planner_choice_overrides_fixed_contributing_factor_order():
    datasources = golden_wb_datasources()
    wrapped_datasources, recorders = wrap_wb_datasources(datasources)
    module_packages_registry = _single_wb_package_registry(wrapped_datasources)

    llm_client = MockLLMClient(_order_defying_responder(None))
    app_config = AppConfig(
        factory_id=_FACTORY_ID, factory_name="Factory A", enabled_modules=["WB"],
        llm_routes={route: LLMRouteConfig(route=route, model="mock-deterministic", max_retries=0) for route in _ROUTES},
    )
    runtime_context = bootstrap_runtime(app_config, module_packages=module_packages_registry, llm_client=llm_client)
    service = _assemble_service(runtime_context, app_config)
    service.recorders = recorders

    final_state = run_golden_scenario(service, _REQUEST_TEXT, run_id="order-independence")
    wb = final_state.module_states["WB"]

    sources = route_sources(service, "order-independence")
    print(f"\n[Section XIX] route sources: {sources}")
    from .harness import planner_decisions
    planner_records = planner_decisions(service, "order-independence")
    for rec in planner_records:
        print(f"[debug] planner decision step={rec.step} source={rec.source} capability={rec.proposed_capability_key} fallback_reason={rec.fallback_reason}")

    rounds = [r.capability_key for r in sorted(wb.objective_history.values(), key=lambda r: r.created_step)]
    print(f"[Section XIX] executed capability sequence: {rounds}")

    # Round 1 legitimately falls back here: this test forces EVERY route
    # (including Standardizer) to fail, so no Request Constraint is ever
    # extracted for ASE07, and `entity_states` starts empty -- the
    # `_entity_is_known_or_named` fix (agent/planning/policies/llm.py)
    # closes that gap for a REAL Standardizer (which would extract the
    # plant from the user's own request text), but this maximally-strict
    # harness deliberately doesn't exercise that path. What this test DOES
    # prove: round 1's fallback populates `entity_states["ASE07"]`
    # (WBPlanningPolicy's own derive_state_updates), and from round 2
    # onward the LLM Planner's own scripted choice ("wb.oee.plant_status")
    # is what actually executes -- directly CONTRADICTING what
    # `_propose_output_rca`'s fixed contributing-factor order would have
    # picked next (ASE07's real BANK data IS abnormal in the golden
    # dataset, so the deterministic fallback's own next move would be
    # "wb.bank.status_summary", never "wb.oee.plant_status").
    assert planner_records[0].source.name == "FALLBACK"
    assert planner_records[1].source.name == "LLM"
    assert rounds[1] == "wb.oee.plant_status"
    assert "wb.bank.status_summary" not in rounds[:2]  # the fixed order's own next move never got a chance to run

    oee_calls = service.recorders["oee"].calls
    assert any(c.method == "list_oee" for c in oee_calls)  # the LLM's chosen capability genuinely executed a real Tool/DataSource call
