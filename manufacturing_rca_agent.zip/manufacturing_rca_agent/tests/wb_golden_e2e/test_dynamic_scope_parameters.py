"""Phase PROD-1.4 T8 / Section XX -- Tool Parameter Flexibility.

Proves the Agent produces a genuinely DYNAMIC ObjectiveScope/Tool
parameter set from the user's own request, rather than a hardcoded
plant/date -- the SAME capability (`wb.oee.plant_status`) invoked for two
DIFFERENT plants must produce two DIFFERENT `target_ref`/scope filter/
executed-scope values, each correctly reflecting its own request."""
from agent.state.enums import TaskType

from .harness import build_deterministic_service, run_golden_scenario


def test_t8_same_capability_different_plant_produces_different_scope():
    service_a = build_deterministic_service(goal_statement="Check WB OEE status for ASE01 on 2026-08-12.", task_type=TaskType.INFORMATION)
    final_a = run_golden_scenario(service_a, "請查詢 2026-08-12 ASE01 的 WB OEE 狀況。", run_id="t8-ase01")
    wb_a = final_a.module_states["WB"]

    service_b = build_deterministic_service(goal_statement="Check WB OEE status for ASE02 on 2026-08-12.", task_type=TaskType.INFORMATION)
    final_b = run_golden_scenario(service_b, "請查詢 2026-08-12 ASE02 的 WB OEE 狀況。", run_id="t8-ase02")
    wb_b = final_b.module_states["WB"]

    objective_a = next(iter(wb_a.objective_history.values()))
    objective_b = next(iter(wb_b.objective_history.values()))
    print(f"\n[T8] objective A target_ref={objective_a.target_ref} scope={objective_a.scope}")
    print(f"[T8] objective B target_ref={objective_b.target_ref} scope={objective_b.scope}")

    assert objective_a.capability_key == objective_b.capability_key == "wb.oee.plant_status"  # SAME capability
    assert objective_a.target_ref.ref_id == "ASE01"
    assert objective_b.target_ref.ref_id == "ASE02"
    assert objective_a.target_ref.ref_id != objective_b.target_ref.ref_id  # DIFFERENT scope, not hardcoded

    filters_a = {f.dimension: f.value for f in objective_a.scope.filters}
    filters_b = {f.dimension: f.value for f in objective_b.scope.filters}
    assert filters_a.get("plant") == "ASE01"
    assert filters_b.get("plant") == "ASE02"

    # Executed scope (what the Tool actually applied) echoes the SAME
    # per-request plant back on its own Evidence -- proves the dynamic
    # scope reached the real Tool call, not just the Objective record.
    from agent.state.payload import PayloadRegistry

    payload_a = PayloadRegistry.unpack(wb_a.evidence[-1].structured_payload)
    payload_b = PayloadRegistry.unpack(wb_b.evidence[-1].structured_payload)
    assert payload_a.scope.plant_id == "ASE01"
    assert payload_b.scope.plant_id == "ASE02"

    # DataSource-level proof: two genuinely separate Tool executions with
    # different resolved plant filters, not one shared/cached call.
    oee_calls_a = service_a.recorders["oee"].calls
    oee_calls_b = service_b.recorders["oee"].calls
    assert any(c.kwargs.get("production_date") == "2026-08-12" for c in oee_calls_a)
    assert any(c.kwargs.get("production_date") == "2026-08-12" for c in oee_calls_b)


def test_t8b_same_capability_different_date_produces_different_scope():
    """Same capability, same plant, DIFFERENT date -- proves the date
    dimension is equally dynamic, not just plant."""
    service_a = build_deterministic_service(goal_statement="Check WB WIP Hold status for ASE03 on 2026-08-12.", task_type=TaskType.ANALYSIS)
    final_a = run_golden_scenario(service_a, "請分析 2026-08-12 ASE03 的 WB WIP Hold 狀況。", run_id="t8b-day1")

    service_b = build_deterministic_service(goal_statement="Check WB WIP Hold status for ASE03 on 2026-08-07.", task_type=TaskType.ANALYSIS)
    final_b = run_golden_scenario(service_b, "請分析 2026-08-07 ASE03 的 WB WIP Hold 狀況。", run_id="t8b-day2")

    wip_calls_a = service_a.recorders["wip"].calls
    wip_calls_b = service_b.recorders["wip"].calls
    dates_a = {c.kwargs.get("snapshot_date") for c in wip_calls_a if c.method == "list_wip"}
    dates_b = {c.kwargs.get("snapshot_date") for c in wip_calls_b if c.method == "list_wip"}
    print(f"\n[T8b] snapshot dates queried A={dates_a} B={dates_b}")
    assert "2026-08-12" in dates_a
    assert "2026-08-07" in dates_b
    assert dates_a != dates_b
