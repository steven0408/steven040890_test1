"""Phase PROD-1.4 T14/Section IX -- proves the capability-retrieval lexical
fix (agent/llm/context/capability_retriever.py) actually matters under the
confirmed formal-environment constraint of LLM_CONTEXT_WINDOW_TOKENS=2048.

Before this phase, `DeterministicCapabilityRetriever` ranked purely
alphabetically (skill_id). WB's own capability skill_ids sort
bank < issue < oee < output < wip -- meaning under ANY token-budget
squeeze, "wip"-named capabilities were the FIRST candidates a token trim
pass would pop from the tail of `relevant_capabilities`, for a request
that is SPECIFICALLY about WIP. This test builds the real,
empirically-measured 2048-token profile (same one
test_context_budget_2048_profile.py uses) and confirms a WIP-focused RCA
goal statement's own `relevant_capabilities` list still contains a
wip-related capability, even under the tightest budget."""
from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
from agent.llm.context.evidence_selector import DeterministicEvidenceSelector
from agent.llm.context.planner_context import PlannerContextBuilder
from agent.llm.token_budget import ApproximateTokenEstimator, LLMContextProfile, RouteTokenBudget
from agent.modules.wb.package import build_wb_module_package
from agent.state.enums import TaskType
from agent.skills.registry import SkillRegistry

from .harness import golden_wb_datasources, wrap_wb_datasources

from tests.conftest import make_module_state


def _wb_skill_registry() -> SkillRegistry:
    package = build_wb_module_package(datasources=wrap_wb_datasources(golden_wb_datasources())[0])
    registry = SkillRegistry()
    for directory in package.skill_directories:
        registry.load_directory(directory)
    return registry


def _tight_2048_profile() -> LLMContextProfile:
    return LLMContextProfile(
        context_window_tokens=2048,
        route_budgets={"planner": RouteTokenBudget(max_output_tokens=450, minimum_output_tokens=200, safety_margin_tokens=64)},
    )


def test_t14_wip_focused_rca_request_keeps_wip_capability_under_2048():
    skill_registry = _wb_skill_registry()
    builder = PlannerContextBuilder(
        DeterministicEvidenceSelector(), DeterministicCapabilityRetriever(skill_registry),
        token_estimator=ApproximateTokenEstimator(), context_profile=_tight_2048_profile(),
    )
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-t14")
    module_state = module_state.model_copy(update={
        "goal": module_state.goal.model_copy(update={
            "statement": "Investigate whether WB WIP Hold has been persistently abnormal for this plant and find a likely cause.",
            "task_type": TaskType.RCA,
        }),
    })

    outcome = builder.build(module_state, run_id="run-t14")
    context = outcome.context

    capability_keys = [s.capability_key for s in context.relevant_capabilities]
    print(f"\n[T14] relevant_capabilities under 2048: {capability_keys}")
    print(f"[T14] estimated_context_characters: {outcome.record.estimated_context_characters}")

    assert any(k is not None and k.startswith("wb.wip") for k in capability_keys), (
        "WIP-focused RCA request lost every wip.* capability under the 2048 profile -- the exact "
        "alphabetical-trim bias this phase's capability-retrieval fix was meant to close."
    )


def test_t14b_bank_focused_rca_request_still_keeps_bank_capability_under_2048():
    """Sanity check the fix doesn't just favor 'wip' specifically -- a
    BANK-focused request (bank sorts FIRST alphabetically, so this always
    passed even before the fix) must still work, proving the change is a
    genuine re-ranking, not an accidental one-off special-case."""
    skill_registry = _wb_skill_registry()
    builder = PlannerContextBuilder(
        DeterministicEvidenceSelector(), DeterministicCapabilityRetriever(skill_registry),
        token_estimator=ApproximateTokenEstimator(), context_profile=_tight_2048_profile(),
    )
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-t14b")
    module_state = module_state.model_copy(update={
        "goal": module_state.goal.model_copy(update={
            "statement": "Investigate whether WB material shortage (BANK) has been a persistent problem for this plant.",
            "task_type": TaskType.RCA,
        }),
    })

    outcome = builder.build(module_state, run_id="run-t14b")
    capability_keys = [s.capability_key for s in outcome.context.relevant_capabilities]
    print(f"\n[T14b] relevant_capabilities under 2048: {capability_keys}")
    assert any(k is not None and k.startswith("wb.bank") for k in capability_keys)
