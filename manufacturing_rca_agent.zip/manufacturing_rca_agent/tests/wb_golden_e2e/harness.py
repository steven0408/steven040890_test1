"""Phase PROD-1.3: shared Golden E2E harness. Every Golden scenario enters
through the SAME seam `AgentService`/the real FastAPI app uses --
`service._app.invoke(...)`, the exact compiled production graph
`AgentService.analyze()` itself calls (accessed directly here only to
retrieve the FULL final `AgentState` for tracing/verification, since
`AgentService.analyze()`'s own public return value is deliberately
narrowed for API responses -- this is the same graph, the same request
flow, never a bypass of Standardizer/Analyzer/Planner/Executor/Reflector/
Synthesis).

Two construction modes:

  build_deterministic_service()  -- Mode A ("DETERMINISTIC / FALLBACK
      ACCEPTANCE", per the phase spec's own required label). Uses a
      MockLLMClient that provides a SCRIPTED stand-in ONLY for Analyzer
      (the one cognitive node with zero built-in deterministic fallback --
      confirmed by reading agent/graph/nodes/analyzer_llm.py; its own
      legacy deterministic sibling `analyzer_mock` hardcodes
      OEE/Output/WIP module dispatch and does not even know "WB" exists,
      confirmed by reading agent/graph/nodes/analyzer_mock.py -- a real,
      reported architecture gap, not fixed this phase). Standardizer,
      Planner, Reflector, and Synthesis are all forced to fail on every
      LLM call, so each goes through its OWN real, already-built
      deterministic fallback path (StandardizerLLMService's own fallback,
      LLMPlanningPolicy/LLMReflectionPolicy delegating to WBPlanningPolicy,
      SynthesisLLMService's own build_handoff_package fallback) --
      genuinely exercised, never stubbed out.

  build_llm_service_if_available() -- Mode B ("LLM BEHAVIORAL
      ACCEPTANCE"). Returns None (never raises) if no OPENAI_API_KEY is
      set in this environment -- callers must skip, not substitute Mock
      and call it LLM acceptance (item IV's own explicit prohibition).
"""
import os
import uuid
from dataclasses import dataclass, field
from datetime import date

from langgraph.checkpoint.memory import InMemorySaver

from agent.bootstrap import AppConfig, RuntimeContext, bootstrap_runtime
from agent.capability.resolver import CapabilityResolver
from agent.domain.wb.datasource import (
    InMemoryWBBankDataSource,
    InMemoryWBIssueDataSource,
    InMemoryWBPlantOEEDataSource,
    InMemoryWBStageOutputDataSource,
    InMemoryWBWIPDataSource,
)
from agent.domain.wb.synthetic import (
    build_wb_bank_records,
    build_wb_issue_records,
    build_wb_plant_oee_records,
    build_wb_stage_output_records,
    build_wb_wip_records,
)
from agent.graph.nodes.analyzer_llm import AnalyzerLLMService, make_analyzer_llm_node
from agent.graph.nodes.standardizer_llm import StandardizerLLMService, make_standardizer_llm_node
from agent.graph.nodes.synthesis import make_llm_synthesis_node
from agent.graph.production import build_production_graph_with_synthesis
from agent.llm.client import MockLLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.context.standardizer_context import StandardizerContextBuilder
from agent.llm.context.synthesis_context import SynthesisContextBuilder
from agent.llm.models import LLMTimeoutError
from agent.llm.prompts.analyzer import AnalyzerDecision, ModuleSelection
from agent.llm.providers.openai_adapter import OpenAICompatibleAdapter
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.modules.wb.package import build_wb_module_package
from agent.state.enums import TaskType
from agent.state.models import Budget, FactoryContext, UserRequest
from agent.state.state import AgentState
from agent.synthesis.handoff_builder import ModuleHandoffBuilder
from agent.synthesis.llm_service import SynthesisLLMService
from agent_api.runtime_events import InMemoryRuntimeEventSink
from agent_api.service import AgentService, normalize_request

from tests.helpers.recording_wb_datasource import wrap_wb_datasources

_FACTORY_ID = "factory-a"
_ROUTES = ("standardizer", "analyzer", "planner", "reflector", "synthesis")


def golden_wb_datasources():
    """The real, unmodified golden synthetic dataset -- same builder
    functions `build_wb_module_package()`'s own default uses internally."""
    from agent.tools.wb.registration import WBDataSources

    bank_records, bank_snapshot_dates = build_wb_bank_records()
    wip_records, wip_snapshot_dates = build_wb_wip_records()
    return WBDataSources(
        oee=InMemoryWBPlantOEEDataSource(build_wb_plant_oee_records()),
        bank=InMemoryWBBankDataSource(bank_records, snapshot_dates=bank_snapshot_dates),
        wip=InMemoryWBWIPDataSource(wip_records, snapshot_dates=wip_snapshot_dates),
        output=InMemoryWBStageOutputDataSource(build_wb_stage_output_records()),
        issue=InMemoryWBIssueDataSource(build_wb_issue_records()),
    )


def _analyzer_stand_in_responder(goal_statement: str, task_type: TaskType):
    """The one scripted stand-in Mode A needs (see this module's own
    docstring) -- always selects WB with the caller-supplied goal
    statement verbatim (which the caller writes to be keyword-detectable
    by WBPlanningPolicy's own deterministic `_detect_plant`/`_detect_date`/
    `_detect_topic`, exactly the same text a real Standardizer/Analyzer
    pair would be expected to preserve from the user's own request)."""

    def _responder(request):
        if request.route == "analyzer":
            return AnalyzerDecision(
                task_type=task_type, confidence=0.9, reasoning_summary="deterministic stand-in",
                selected_modules=[ModuleSelection(module_type="WB", priority=0.9, confidence=0.9, rationale="WB-shaped request", goal_statement=goal_statement)],
            )
        raise LLMTimeoutError(f"Mode A: route '{request.route}' is intentionally never answered by LLM -- forces the real deterministic fallback.")

    return _responder


def _always_fail_responder(request):
    """Phase PROD-1.4 T1: unlike `_analyzer_stand_in_responder`, this has
    NO scripted Analyzer response at all -- every route, including
    'analyzer', fails, forcing `AnalyzerLLMService`'s OWN internal
    `_deterministic_fallback_decision` (agent/graph/nodes/analyzer_llm.py)
    to run for real. That fallback reads the real `ModuleRegistry`
    (generic, registry-driven -- see bootstrap.py's own
    `module_registry.register(package.module_definition)` for every
    registered ModulePackage) rather than any hardcoded module list, so
    this is the strongest available proof that a WB request survives a
    total LLM outage with zero scripted stand-in anywhere in the chain."""
    raise LLMTimeoutError(f"T1: route '{request.route}' is intentionally never answered by LLM -- forces the real deterministic fallback end to end.")


def build_fully_deterministic_service(*, datasources=None) -> AgentService:
    """Phase PROD-1.4 T1 -- strictly stronger than `build_deterministic_service`:
    NOT EVEN Analyzer gets a scripted response. Proves
    Standardizer -> Analyzer -> WBPlanningPolicy's own real, independent
    deterministic fallbacks chain together correctly for a genuine WB
    request, with zero test-authored stand-in anywhere in the graph."""
    datasources = datasources or golden_wb_datasources()
    wrapped_datasources, recorders = wrap_wb_datasources(datasources)
    module_packages_registry = _single_wb_package_registry(wrapped_datasources)

    llm_client = MockLLMClient(_always_fail_responder)
    app_config = AppConfig(
        factory_id=_FACTORY_ID, factory_name="Factory A", enabled_modules=["WB"],
        llm_routes={route: LLMRouteConfig(route=route, model="mock-deterministic", max_retries=0) for route in _ROUTES},
    )
    runtime_context = bootstrap_runtime(app_config, module_packages=module_packages_registry, llm_client=llm_client)
    service = _assemble_service(runtime_context, app_config)
    service.recorders = recorders  # type: ignore[attr-defined]
    return service


def build_deterministic_service(*, datasources=None, goal_statement: str, task_type: TaskType) -> AgentService:
    """Mode A -- see this module's own top-level docstring. `goal_statement`/
    `task_type` are baked into the one scripted Analyzer response (there is
    no way to make this fully request-agnostic without either a real LLM
    or a real deterministic WB-aware Analyzer, neither of which exist for
    this exact seam -- see the docstring's own honest accounting)."""
    datasources = datasources or golden_wb_datasources()
    wrapped_datasources, recorders = wrap_wb_datasources(datasources)
    module_packages_registry = _single_wb_package_registry(wrapped_datasources)

    llm_client = MockLLMClient(_analyzer_stand_in_responder(goal_statement, task_type))
    app_config = AppConfig(
        factory_id=_FACTORY_ID, factory_name="Factory A", enabled_modules=["WB"],
        llm_routes={route: LLMRouteConfig(route=route, model="mock-deterministic", max_retries=0) for route in _ROUTES},
    )
    runtime_context = bootstrap_runtime(app_config, module_packages=module_packages_registry, llm_client=llm_client)
    service = _assemble_service(runtime_context, app_config)
    service.recorders = recorders  # type: ignore[attr-defined]  -- test-only attribute, see run_golden_scenario's own docstring
    return service


def build_llm_service_if_available(*, datasources=None) -> AgentService | None:
    """Mode B -- returns None (never raises) if OPENAI_API_KEY is unset.
    OpenAI Cloud, per the phase's own explicit instruction (item I): an
    OPTIONAL behavioral regression environment, NEVER formal production
    LLM acceptance -- every caller of this function must label results
    accordingly."""
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        return None

    datasources = datasources or golden_wb_datasources()
    wrapped_datasources, recorders = wrap_wb_datasources(datasources)
    module_packages_registry = _single_wb_package_registry(wrapped_datasources)

    llm_client = OpenAICompatibleAdapter(api_key=api_key, temperature=0.0, max_tokens=1500)
    app_config = AppConfig(
        factory_id=_FACTORY_ID, factory_name="Factory A", enabled_modules=["WB"],
        llm_routes={route: LLMRouteConfig(route=route, model="gpt-4o-mini", max_retries=1, timeout_seconds=30.0) for route in _ROUTES},
    )
    runtime_context = bootstrap_runtime(app_config, module_packages=module_packages_registry, llm_client=llm_client)
    service = _assemble_service(runtime_context, app_config)
    service.recorders = recorders  # type: ignore[attr-defined]
    return service


def _single_wb_package_registry(wrapped_datasources):
    from agent.modules.registry import ModulePackageRegistry

    registry = ModulePackageRegistry()
    registry.register(build_wb_module_package(datasources=wrapped_datasources))
    return registry


def _assemble_service(runtime_context: RuntimeContext, app_config: AppConfig) -> AgentService:
    """Mirrors agent_api.service.AgentService.from_settings's own
    construction exactly (minus the ApiSettings/build_llm_client layer,
    since this harness injects its own llm_client directly) -- same
    Standardizer/Analyzer/Synthesis service wiring, same
    build_production_graph_with_synthesis call, same checkpointer
    discipline."""
    standardizer_service = StandardizerLLMService(StandardizerContextBuilder(), runtime_context.llm_router)
    analyzer_service = AnalyzerLLMService(runtime_context.module_registry, runtime_context.analyzer_context_builder, runtime_context.llm_router)
    synthesis_service = SynthesisLLMService(
        SynthesisContextBuilder(ModuleHandoffBuilder(), reasoning_skill_retriever=runtime_context.reasoning_skill_retriever),
        runtime_context.llm_router,
    )
    checkpointer = InMemorySaver()
    graph = build_production_graph_with_synthesis(
        runtime_context.module_runtime, checkpointer, make_llm_synthesis_node(synthesis_service),
        analyzer=make_analyzer_llm_node(analyzer_service), standardizer=make_standardizer_llm_node(standardizer_service),
    )
    graph_app = graph.compile(checkpointer=checkpointer)

    from agent_api.config import ApiSettings
    from agent.llm.providers.provider_config import LLMProviderConfig

    settings = ApiSettings(
        llm_provider_config=LLMProviderConfig(provider="mock", model="mock"),  # never used -- llm_client already injected
        factory_id=_FACTORY_ID, factory_name="Factory A", enabled_modules=["WB"],
    )
    return AgentService(
        settings, runtime_context, graph_app, InMemoryRuntimeEventSink(),
        standardizer_service=standardizer_service, analyzer_service=analyzer_service, synthesis_service=synthesis_service,
    )


def run_golden_scenario(service: AgentService, prompt: str, run_id: str | None = None) -> AgentState:
    """The one Golden E2E entry point -- builds the initial AgentState the
    exact same way AgentService.analyze() does (via its own
    _build_initial_state, reused directly here rather than duplicated) and
    invokes the exact same compiled graph object. Returns the FULL final
    AgentState (not AnalyzeResult) for verification -- accessing
    `service._app`/`_build_initial_state` directly is test-only
    introspection into the same call `analyze()` makes internally, never a
    different code path."""
    run_id = run_id or f"golden-{uuid.uuid4().hex[:8]}"
    normalized = normalize_request(prompt=prompt, request=None, run_id=run_id, factory_id=None, metadata=None)
    _, initial_state = service._build_initial_state(normalized)
    result = service._app.invoke(initial_state, config={"configurable": {"thread_id": run_id}})
    return AgentState.model_validate(result)


def route_sources(service: AgentService, run_id: str) -> dict[str, str]:
    """Best-effort per-route source (llm/fallback/none) inferred from
    LLMUsageSink -- the only durable signal for Standardizer/Analyzer
    (StandardizerOutcome/AnalyzerOutcome are transient, not audited to a
    sink the way Planner/Reflector decisions are, see planner_sources/
    reflector_sources below for the richer audit-backed alternative)."""
    records = service.runtime_context.llm_usage_sink.list_for_run(run_id)
    sources: dict[str, str] = {}
    for route in _ROUTES:
        route_records = [r for r in records if r.route == route]
        if not route_records:
            sources[route] = "none"
        elif any(r.status.value == "success" for r in route_records):
            sources[route] = "llm"
        else:
            sources[route] = "fallback"
    return sources


def planner_decisions(service: AgentService, run_id: str) -> list:
    return service.runtime_context.decision_audit_sink.list_for_run(run_id)


def reflection_decisions(service: AgentService, run_id: str) -> list:
    sink = service.runtime_context.reflection_decision_audit_sink
    return sink.list_for_run(run_id) if sink is not None else []
