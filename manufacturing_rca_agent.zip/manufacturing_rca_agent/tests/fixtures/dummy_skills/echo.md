---
skill_id: dummy.echo
name: Dummy Echo
description: Proof fixture for Phase 5D-7 -- an EXECUTION skill onboarded with zero changes to Executor/SkillRunner/CapabilityResolver/Module Planner/LangGraph topology.
category: query
required_tools: [dummy_echo_tool]
optional_tools: []
steps:
  - tool_id: dummy_echo_tool
    parameter_mapping:
      text: objective.description
input_contract: DummyEchoInput
output_contract: DummyEchoOutput
risk_level: low
version: "1"
task_types: []
actions: [query]
---

# Skill: Dummy Echo

## Goal

Proof-of-concept EXECUTION Skill for Phase 5D-7's plug-in onboarding test.
Not a real domain capability -- just enough to run one Tool step through
the real capability layer (`Objective -> CapabilityResolver -> Skill ->
SkillRunner -> ToolExecutionManager -> ToolRegistry -> Tool`).

## Procedure

1. Call `dummy_echo_tool` with the Objective's own description as `text`.

## Output Contract

DummyEchoOutput -- the same text, uppercased.
