"""Phase 5B-1.2: Human Audit Flow Correction.

Re-runs Phase 4B-2's Case A (permission APPROVE) scenario, but replaces
`app.update_state(config, {"human_requests": ...})` with the new topology:

    Execution Gate -> interrupt(HumanRequest payload) -> RunController
    -> HumanAuditSink.record_request(...) -> (human decides)
    -> RunController.resume(...) -> HumanAuditSink.record_response(...)
    -> Command(resume=HumanResponse) -> Gate continues

with **zero** `app.update_state()` calls anywhere in this test. Physical
execution counts are measured with the same spy-tool pattern as
tests/test_resume_replay_semantics.py -- not by comparing final ModuleState,
which Phase 5B-1.1 showed cannot reveal a duplicate physical execution
(merge_by_key keeps only the latest value per key).
"""
from datetime import datetime, timezone

from langgraph.checkpoint.memory import InMemorySaver

from agent.graph.graph import build_phase2_graph
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.persistence.human_audit import InMemoryHumanAuditSink
from agent.persistence.run_controller import RunController
from agent.planning.policies.mock import DeterministicMockPolicy, PermissionSpec, Requirement
from agent.state.enums import (
    EvidenceQuality,
    HumanDecision,
    HumanReason,
    HumanRequestStatus,
    ModuleStatus,
    ObjectiveStatus,
    ObservationStatus,
    ReflectorVerdict,
    RiskLevel,
    RunTerminationStatus,
)
from agent.state.state import AgentState
from agent.tools.base import ToolResult
from agent.tools.mocks.scripted_tool import ScriptedMockTool

from .conftest import make_agent_state, make_budget


class _SpyTool:
    """Counts every *physical* call it receives -- see
    tests/test_resume_replay_semantics.py for why this, not final-state
    comparison, is the only trustworthy way to measure re-execution."""

    def __init__(self, inner, label: str, counters: dict):
        self.inner = inner
        self.label = label
        self.counters = counters

    def run(self, objective):
        self.counters[self.label] = self.counters.get(self.label, 0) + 1
        return self.inner.run(objective)


def _module_runtime(counters: dict) -> dict[str, ModuleRuntimeConfig]:
    return {
        "OEE": ModuleRuntimeConfig(
            policy=DeterministicMockPolicy(
                requirements=[
                    Requirement(
                        sources=["restricted"],
                        sufficiency_evidence_count=1,
                        restricted_sources={
                            "restricted": PermissionSpec(permission_type="maintenance_db_access", risk_level=RiskLevel.HIGH)
                        },
                    )
                ]
            ),
            tool=_SpyTool(
                ScriptedMockTool({"restricted": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}),
                "OEE",
                counters,
            ),
            budget=make_budget(max_steps=3, max_tool_calls=3, max_depth_per_entity=2),
        ),
        "Output": ModuleRuntimeConfig(
            policy=DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1),
            tool=_SpyTool(
                ScriptedMockTool({"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}),
                "Output",
                counters,
            ),
            budget=make_budget(max_steps=3, max_tool_calls=3, max_depth_per_entity=2),
        ),
        "WIP": ModuleRuntimeConfig(
            policy=DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1),
            tool=_SpyTool(
                ScriptedMockTool({"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}),
                "WIP",
                counters,
            ),
            budget=make_budget(max_steps=3, max_tool_calls=3, max_depth_per_entity=2),
        ),
    }


def test_permission_approve_via_run_controller_and_audit_sink_never_calls_update_state():
    counters: dict = {}
    checkpointer = InMemorySaver()
    audit_sink = InMemoryHumanAuditSink()

    graph = build_phase2_graph(_module_runtime(counters), checkpointer)
    app = graph.compile(checkpointer=checkpointer)
    controller = RunController(app, audit_sink)

    initial_state = make_agent_state()
    config = {"configurable": {"thread_id": initial_state.run_id}}

    result1 = controller.start(initial_state, config)

    # OEE is interrupted; Output/WIP already ran to completion in this same invoke
    assert "__interrupt__" in result1
    mid_values = app.get_state(config).values
    assert "OEE" not in mid_values["module_states"]
    assert mid_values["module_states"]["Output"].status == ModuleStatus.COMPLETE
    assert mid_values["module_states"]["WIP"].status == ModuleStatus.COMPLETE

    # physical execution counts before resume: exactly one call each so far
    assert counters == {"Output": 1, "WIP": 1}

    # HumanAuditSink -- not AgentState.human_requests -- holds the pending request
    pending_requests = audit_sink.list_for_run(initial_state.run_id)
    assert len(pending_requests) == 1
    request = pending_requests[0]
    assert request.status == HumanRequestStatus.PENDING
    assert request.reason == HumanReason.PERMISSION_REQUIRED
    assert request.permission_type == "maintenance_db_access"
    assert request.risk_level == RiskLevel.HIGH
    assert request.module_id == "OEE"
    assert request.response is None

    # AgentState.human_requests is untouched -- this flow never writes it
    assert app.get_state(config).values["human_requests"] == {}

    # process-style resume: a brand-new compiled graph + RunController, only
    # sharing the checkpointer and audit_sink (as a durable store would
    # survive a process restart), not any in-memory Python state
    graph2 = build_phase2_graph(_module_runtime(counters), checkpointer)
    app2 = graph2.compile(checkpointer=checkpointer)
    controller2 = RunController(app2, audit_sink)

    result2 = controller2.resume(
        config,
        request_id=request.request_id,
        decision=HumanDecision.APPROVE,
        responded_by="tester",
        responded_at=datetime(2026, 8, 9, tzinfo=timezone.utc),
    )
    final_state = AgentState.model_validate(result2)

    # physical execution counts after resume: OEE ran exactly once (its
    # first and only physical execution); Output/WIP are UNCHANGED -- they
    # were never re-invoked, because nothing ever called update_state()
    # while their sibling's Send task was still pending
    assert counters == {"Output": 1, "WIP": 1, "OEE": 1}

    # OEE resumed correctly through Executor/Reflector/CompletionCheck
    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.COMPLETE
    assert len(oee.observations) == 1
    assert oee.observations[0].status == ObservationStatus.SUCCESS
    assert oee.reflection_history[-1].verdict == ReflectorVerdict.CANDIDATE_COMPLETE
    assert oee.objective_history["OEE-obj-1"].status == ObjectiveStatus.COMPLETED

    # fan-in still reaches READY_FOR_SYNTHESIS -- final AgentState semantics unchanged
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS

    # HumanAuditSink lifecycle: PENDING -> RESOLVED, with a response record,
    # and this is entirely independent of AgentState/checkpoint state
    resolved = audit_sink.get_request(request.request_id)
    assert resolved.status == HumanRequestStatus.RESOLVED
    assert resolved.response.decision == HumanDecision.APPROVE
    assert resolved.response.responded_by == "tester"

    # AgentState.human_requests is STILL untouched after resume -- confirms
    # this whole flow really never called update_state() on it
    assert final_state.human_requests == {}

    # checkpoint state is otherwise normal / inspectable
    assert app2.get_state(config).values["termination_status"] == RunTerminationStatus.READY_FOR_SYNTHESIS


def test_no_update_state_calls_reach_the_checkpointer_during_the_flow():
    """Belt-and-suspenders: patches InMemorySaver.put (what update_state()
    would ultimately trigger beyond the normal per-step writes) is overkill
    here -- instead we assert the behavioral consequence Phase 5B-1.1 tied
    directly to update_state(): siblings physically re-executing. Since
    Output/WIP's counts above are proven unchanged across resume, no
    update_state()-shaped write happened to the pending superstep. This
    test exists to name that invariant explicitly and keep it from silently
    regressing if the flow is ever touched again."""
    counters: dict = {}
    checkpointer = InMemorySaver()
    audit_sink = InMemoryHumanAuditSink()
    graph = build_phase2_graph(_module_runtime(counters), checkpointer)
    app = graph.compile(checkpointer=checkpointer)
    controller = RunController(app, audit_sink)

    initial_state = make_agent_state()
    config = {"configurable": {"thread_id": initial_state.run_id}}
    controller.start(initial_state, config)
    request = audit_sink.list_for_run(initial_state.run_id)[0]

    before_resume = dict(counters)
    controller.resume(
        config,
        request_id=request.request_id,
        decision=HumanDecision.APPROVE,
        responded_by="tester",
        responded_at=datetime(2026, 8, 9, tzinfo=timezone.utc),
    )

    assert counters["Output"] == before_resume["Output"]
    assert counters["WIP"] == before_resume["WIP"]
