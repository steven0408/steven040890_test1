﻿"""Phase 5C-1: EvidenceSelector / CapabilityRetriever / KnowledgeRetriever /
history summarizer / FindingSelector -- the deterministic context services
PlannerContextBuilder composes. Each tested in isolation here; end-to-end
composition is tests/test_planner_context_oee_scenarios.py.
"""
from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever, SkillSummary
from agent.llm.context.evidence_selector import DeterministicEvidenceSelector
from agent.llm.context.history_summarizer import summarize_objective_history
from agent.llm.context.knowledge_retriever import EmptyKnowledgeRetriever, InMemoryKnowledgeRetriever, KnowledgeItem, ValidationStatus
from agent.llm.context.planner_context import select_top_findings
from agent.state.enums import (
    BranchStatus,
    EntityAnalysisStatus,
    EvidenceQuality,
    FindingStatus,
    ObjectiveAction,
    ObjectiveStatus,
    TargetRefType,
    TaskType,
)
from agent.state.models import Branch, EntityState, Evidence, ErrorRecord, ErrorType, Finding, ModuleState, ObjectiveRecord, Observation, TargetRef

from .conftest import make_module_state, make_oee_skill_registry


def _module_state_with_evidence() -> ModuleState:
    state = make_module_state()
    branches = {
        "branch-availability": Branch(
            branch_id="branch-availability", name="Availability Loss", pattern="Availability",
            status=BranchStatus.ACTIVE, priority_score=0.9, tree_node_id="n1", entity_ids=["EQ001"],
        ),
        "branch-quality": Branch(
            branch_id="branch-quality", name="Quality Loss", pattern="Quality",
            status=BranchStatus.PENDING, priority_score=0.3, tree_node_id="n2", entity_ids=["EQ009"],
        ),
    }
    entity_states = {
        "EQ001": EntityState(entity_id="EQ001", entity_type="EQUIPMENT", status=EntityAnalysisStatus.INVESTIGATING, current_tree_node_id="n3", branch_id="branch-availability", priority_score=0.9),
        "EQ009": EntityState(entity_id="EQ009", entity_type="EQUIPMENT", status=EntityAnalysisStatus.SCREENED, current_tree_node_id="n4", branch_id="branch-quality", priority_score=0.3),
    }
    objective_history = {
        "OEE-obj-1": ObjectiveRecord(objective_id="OEE-obj-1", description="screen", action=ObjectiveAction.SCREEN, target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="OEE"), status=ObjectiveStatus.COMPLETED, created_step=1, attempt_count=1),
        "OEE-obj-2": ObjectiveRecord(objective_id="OEE-obj-2", description="EQ001 detail", action=ObjectiveAction.DRILL_DOWN, target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="EQ001"), status=ObjectiveStatus.COMPLETED, created_step=2, attempt_count=1),
        "OEE-obj-3": ObjectiveRecord(objective_id="OEE-obj-3", description="EQ009 detail", action=ObjectiveAction.DRILL_DOWN, target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="EQ009"), status=ObjectiveStatus.COMPLETED, created_step=3, attempt_count=1),
    }
    evidence = [
        Evidence(evidence_id="ev-1", objective_id="OEE-obj-1", source_tool="capability:screen_equipment", summary="Screened 12 equipment; 5 abnormal.", quality=EvidenceQuality.STRONG),
        Evidence(evidence_id="ev-2", objective_id="OEE-obj-2", source_tool="capability:equipment_detail:EQ001", summary="EQ001 downtime detail: Motor Failure.", quality=EvidenceQuality.STRONG),
        Evidence(evidence_id="ev-3", objective_id="OEE-obj-3", source_tool="capability:equipment_detail:EQ009", summary="EQ009 downtime detail: Calibration Drift.", quality=EvidenceQuality.MODERATE),
    ]
    return state.model_copy(update={"branches": branches, "entity_states": entity_states, "objective_history": objective_history, "evidence": evidence})


# ============================================================================
# EvidenceSelector
# ============================================================================


def test_evidence_selector_prioritizes_entity_and_branch_match_over_quality():
    state = _module_state_with_evidence()
    selected = DeterministicEvidenceSelector().select(state, relevant_entity_ids=["EQ001"], relevant_branch_ids=["branch-availability"], limit=2)
    assert [e.evidence_id for e in selected] == ["ev-2", "ev-1"]


def test_evidence_selector_respects_limit():
    state = _module_state_with_evidence()
    selected = DeterministicEvidenceSelector().select(state, relevant_entity_ids=["EQ001"], relevant_branch_ids=["branch-availability"], limit=1)
    assert len(selected) == 1


def test_evidence_selector_returns_empty_for_no_evidence():
    state = make_module_state()
    assert DeterministicEvidenceSelector().select(state, relevant_entity_ids=[], relevant_branch_ids=[], limit=5) == []


# ============================================================================
# CapabilityRetriever
# ============================================================================


def test_capability_retriever_filters_by_domain_and_task_type_prioritizes_action_hint():
    retriever = DeterministicCapabilityRetriever(make_oee_skill_registry())
    summaries = retriever.retrieve(module_type="OEE", task_type=TaskType.RCA, action_hint=ObjectiveAction.DRILL_DOWN, limit=5)

    skill_ids = [s.skill_id for s in summaries]
    assert skill_ids[0] == "oee.rca_equipment_detail"  # action_hint match ranked first
    assert set(skill_ids) == {"oee.rca_screening", "oee.rca_equipment_detail"}  # only RCA-tagged skills


def test_capability_retriever_wip_domain_returns_no_oee_skills():
    retriever = DeterministicCapabilityRetriever(make_oee_skill_registry())
    assert retriever.retrieve(module_type="WIP", task_type=TaskType.RCA, action_hint=None, limit=5) == []


def test_capability_retriever_excludes_tool_and_step_details():
    # Phase WB-3F.2 added `accepted_scope_dimensions`; Phase WB-3F.3 added
    # `required_scope_dimensions` -- both Skill-level SCOPE metadata (which
    # ObjectiveScope.filters dimensions this capability may/must receive),
    # not a Tool implementation/step detail. `steps`/`required_tools`/
    # `optional_tools`/the markdown narrative body remain excluded -- the
    # invariant this test guards is unchanged.
    assert set(SkillSummary.model_fields.keys()) == {
        "skill_id", "name", "purpose", "supported_actions", "capability_key", "required_input_summary",
        "accepted_scope_dimensions", "required_scope_dimensions",
    }
    assert "steps" not in SkillSummary.model_fields
    assert "required_tools" not in SkillSummary.model_fields


# ============================================================================
# KnowledgeRetriever
# ============================================================================


def test_empty_knowledge_retriever_always_returns_empty():
    assert EmptyKnowledgeRetriever().retrieve(module_type="OEE", task_type=TaskType.RCA, entity_ids=[], patterns=[], limit=5) == []


def test_in_memory_knowledge_retriever_only_returns_validated():
    items = [
        KnowledgeItem(knowledge_id="k1", statement="validated rule", domains=["oee"], confidence=0.9, validation_status=ValidationStatus.VALIDATED, source_scope="global"),
        KnowledgeItem(knowledge_id="k2", statement="candidate rule", domains=["oee"], confidence=0.95, validation_status=ValidationStatus.CANDIDATE, source_scope="global"),
    ]
    result = InMemoryKnowledgeRetriever(items).retrieve(module_type="OEE", task_type=TaskType.RCA, entity_ids=[], patterns=[], limit=5)
    assert [i.knowledge_id for i in result] == ["k1"]


def test_in_memory_knowledge_retriever_filters_by_entity_overlap():
    items = [
        KnowledgeItem(knowledge_id="k1", statement="about EQ001", applicable_entities=["EQ001"], confidence=0.9, validation_status=ValidationStatus.VALIDATED, source_scope="global"),
        KnowledgeItem(knowledge_id="k2", statement="about EQ099", applicable_entities=["EQ099"], confidence=0.9, validation_status=ValidationStatus.VALIDATED, source_scope="global"),
    ]
    result = InMemoryKnowledgeRetriever(items).retrieve(module_type="OEE", task_type=TaskType.RCA, entity_ids=["EQ001"], patterns=[], limit=5)
    assert [i.knowledge_id for i in result] == ["k1"]


# ============================================================================
# History summarizer + FindingSelector
# ============================================================================


def test_summarize_objective_history_uses_evidence_summary_most_recent_first():
    state = _module_state_with_evidence()
    items = summarize_objective_history(state, limit=10)
    assert [i.target_ref_id for i in items] == ["EQ009", "EQ001", "OEE"]
    assert items[0].outcome_summary == "EQ009 downtime detail: Calibration Drift."
    assert items[0].action == ObjectiveAction.DRILL_DOWN
    assert items[0].status == ObjectiveStatus.COMPLETED


def test_summarize_objective_history_respects_limit():
    state = _module_state_with_evidence()
    assert len(summarize_objective_history(state, limit=1)) == 1


def test_summarize_objective_history_falls_back_to_observation_error_when_no_evidence():
    state = make_module_state()
    state = state.model_copy(
        update={
            "objective_history": {
                "OEE-obj-1": ObjectiveRecord(
                    objective_id="OEE-obj-1", description="screen", action=ObjectiveAction.SCREEN,
                    target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="OEE"),
                    status=ObjectiveStatus.COMPLETED, created_step=1, attempt_count=1,
                    termination_reason="observation_error_retry",
                )
            },
            "observations": [
                Observation(
                    observation_id="obs-1", objective_id="OEE-obj-1", tool_name="capability:screen_equipment",
                    status="error", error=ErrorRecord(error_type=ErrorType.DATA_NOT_FOUND, message="source unavailable", objective_id="OEE-obj-1", occurred_at_step=1),
                )
            ],
        }
    )
    items = summarize_objective_history(state, limit=10)
    assert items[0].outcome_summary == "source unavailable"


def test_select_top_findings_ranks_root_cause_confirmed_first():
    findings = [
        Finding(finding_id="f1", statement="hypothesis only", pattern="Quality", confidence=0.5, status=FindingStatus.HYPOTHESIS, is_root_cause=False),
        Finding(finding_id="f2", statement="confirmed root cause", pattern="Availability", confidence=0.9, status=FindingStatus.CONFIRMED, is_root_cause=True),
        Finding(finding_id="f3", statement="confirmed, not root cause", pattern="Performance", confidence=0.7, status=FindingStatus.CONFIRMED, is_root_cause=False),
    ]
    ranked = select_top_findings(findings, limit=3)
    assert [f.finding_id for f in ranked] == ["f2", "f3", "f1"]


def test_select_top_findings_respects_limit_and_zero():
    findings = [Finding(finding_id="f1", statement="x", pattern="Quality", confidence=0.5, status=FindingStatus.HYPOTHESIS)]
    assert len(select_top_findings(findings, limit=1)) == 1
    assert select_top_findings(findings, limit=0) == []
