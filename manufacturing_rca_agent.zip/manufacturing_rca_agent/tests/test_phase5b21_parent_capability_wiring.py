"""Phase 5B-2.1: End-to-End Capability Wiring -- the capability path
(Phase 5B-2) exercised for real through the production-style PARENT graph
(`build_phase2_graph`: Standardizer -> Analyzer -> Module Coordinator ->
Send(ModuleTask) -> Module ReAct Subgraph -> fan-in -> Global Completion
Check), not just a standalone Module ReAct Subgraph.

OEE runs `capability=` (production capability execution path); Output/WIP
keep the legacy `tool=` adapter -- exactly the coexistence
ModuleRuntimeConfig now documents. `Goal.task_type` is inferred once by
Standardizer (deterministic keyword mock, no LLM) from the raw request text
and propagated verbatim: Analyzer reads it, ModuleTask carries it,
build_initial_module_state seeds ModuleGoal.task_type from it -- nothing
downstream re-guesses.
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD, CurrentOEEStatus, RankedScreeningResult
from agent.graph.graph import build_phase2_graph
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.planning.policies.mock import DeterministicMockPolicy
from agent.planning.policies.oee import OEEPlanningPolicy
from agent.state.enums import (
    EntityAnalysisStatus,
    EvidenceQuality,
    FindingStatus,
    ModuleStatus,
    ObjectiveStatus,
    ObservationStatus,
    RunTerminationStatus,
    TaskType,
)
from agent.state.models import ModuleState
from agent.state.payload import PayloadRegistry
from agent.state.state import AgentState
from agent.tools.base import ToolResult
from agent.tools.mocks.scripted_tool import ScriptedMockTool

from .conftest import make_agent_state, make_budget, make_oee_capability_runtime


def _legacy_runtime() -> ModuleRuntimeConfig:
    """Output/WIP still run the legacy/test `tool=` adapter -- neither
    domain has a capability layer yet (explicitly out of scope, see item 6).
    """
    return ModuleRuntimeConfig(
        policy=DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1),
        tool=ScriptedMockTool({"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}),
        budget=make_budget(max_steps=3, max_tool_calls=5, max_depth_per_entity=2),
    )


def _runtime() -> dict[str, ModuleRuntimeConfig]:
    return {
        "OEE": ModuleRuntimeConfig(
            policy=OEEPlanningPolicy(),
            capability=make_oee_capability_runtime(MOCK_EQUIPMENT, OEE_THRESHOLD),
            budget=make_budget(max_steps=6, max_tool_calls=20, max_depth_per_entity=3),
        ),
        "Output": _legacy_runtime(),
        "WIP": _legacy_runtime(),
    }


def _run(raw_text: str, run_id: str) -> AgentState:
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(_runtime(), checkpointer)
    app = graph.compile(checkpointer=checkpointer)

    initial_state = make_agent_state(run_id=run_id, raw_text=raw_text)
    config = {"configurable": {"thread_id": run_id}}
    result = app.invoke(initial_state, config=config)
    return AgentState.model_validate(result)


# ============================================================================
# TaskType propagation end to end -- Goal.task_type never re-guessed
# ============================================================================


def test_information_request_propagates_task_type_end_to_end_to_module_goal():
    final_state = _run("今天平均 OEE 多少？", "run-info")
    assert final_state.global_goal.task_type == TaskType.INFORMATION
    task_by_id = {t.module_id: t for t in final_state.selected_modules}
    assert task_by_id["OEE"].task_type == TaskType.INFORMATION
    # the last hop: ModuleGoal.task_type, which OEEPlanningPolicy actually reads
    assert final_state.module_states["OEE"].goal.task_type == TaskType.INFORMATION


# ============================================================================
# INFORMATION -- parent graph end to end
# ============================================================================


def test_information_end_to_end_completes_without_deep_dive():
    final_state = _run("今天平均 OEE 多少？", "run-info-2")

    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.COMPLETE
    assert len(oee.objective_history) == 1
    only_record = next(iter(oee.objective_history.values()))
    assert only_record.target_ref.ref_id == "OEE"  # canonical MODULE target (Phase 5C-2.1)
    assert [tc.tool_id for tc in oee.tool_calls] == ["query_oee_data", "aggregate_oee_status"]

    status = PayloadRegistry.unpack(oee.evidence[0].structured_payload)
    assert isinstance(status, CurrentOEEStatus)

    assert final_state.module_states["Output"].status == ModuleStatus.COMPLETE
    assert final_state.module_states["WIP"].status == ModuleStatus.COMPLETE
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


# ============================================================================
# ANALYSIS -- parent graph end to end
# ============================================================================


def test_analysis_end_to_end_completes_without_root_cause_dive():
    final_state = _run("哪些設備 OEE 比較差？", "run-analysis")

    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.COMPLETE
    assert len(oee.objective_history) == 1
    only_record = next(iter(oee.objective_history.values()))
    assert only_record.target_ref.ref_id == "OEE"  # canonical MODULE target (Phase 5C-2.1)
    assert [tc.tool_id for tc in oee.tool_calls] == ["query_oee_data", "filter_rows", "calculate_contribution", "ranking"]

    ranked = PayloadRegistry.unpack(oee.evidence[0].structured_payload)
    assert isinstance(ranked, RankedScreeningResult)
    assert ranked.groups[0].pattern == "Availability"
    assert oee.entity_states == {}  # never entered RCA deep-dive machinery

    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


# ============================================================================
# RCA -- parent graph end to end, COMPLETE semantic unchanged
# ============================================================================


def test_rca_end_to_end_deep_dives_availability_and_finds_shared_cause():
    final_state = _run("為什麼今天 OEE 下降？", "run-rca")

    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.COMPLETE
    targets = [r.target_ref.ref_id for r in oee.objective_history.values()]
    assert targets == ["OEE", "EQ001", "EQ003"]  # canonical TargetRef (Phase 5C-2.1)
    assert all(r.status == ObjectiveStatus.COMPLETED for r in oee.objective_history.values())

    final_finding = oee.findings[-1]
    assert final_finding.status == FindingStatus.CONFIRMED
    assert final_finding.is_root_cause is True
    assert set(final_finding.entity_ids) == {"EQ001", "EQ003"}
    assert "Motor Failure" in final_finding.pattern
    assert oee.entity_states["EQ001"].status == EntityAnalysisStatus.ROOT_CAUSE_FOUND
    assert oee.entity_states["EQ003"].status == EntityAnalysisStatus.ROOT_CAUSE_FOUND

    # per-step ToolCallRecord projection + physical audit trail agree
    assert [tc.tool_id for tc in oee.tool_calls] == ["query_oee_data", "query_equipment_detail", "query_equipment_detail"]
    assert all(tc.skill_id is not None for tc in oee.tool_calls)

    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


# ============================================================================
# Checkpoint / process-style resume -- capability-backed OEE module
# ============================================================================


def test_capability_backed_run_checkpoint_survives_a_fresh_compiled_graph():
    """No interrupt in this scenario (RCA COMPLETE) -- proves checkpoint
    state written by a capability-routed module remains valid/inspectable,
    not that resume-after-interrupt specifically works (that's Phase 4B-2's
    Human Gate suite, which reruns unmodified -- tool= only, no capability
    involved yet, since no OEE objective is permission-gated)."""
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(_runtime(), checkpointer)
    app = graph.compile(checkpointer=checkpointer)

    run_id = "run-rca-checkpoint"
    config = {"configurable": {"thread_id": run_id}}
    app.invoke(make_agent_state(run_id=run_id, raw_text="為什麼今天 OEE 下降？"), config=config)

    # process-style: a brand-new compiled graph object, only sharing the
    # checkpointer + thread_id
    graph2 = build_phase2_graph(_runtime(), checkpointer)
    app2 = graph2.compile(checkpointer=checkpointer)
    values = app2.get_state(config).values

    assert values["termination_status"] == RunTerminationStatus.READY_FOR_SYNTHESIS
    assert values["module_states"]["OEE"].status == ModuleStatus.COMPLETE
    assert len(values["module_states"]["OEE"].tool_calls) == 3
