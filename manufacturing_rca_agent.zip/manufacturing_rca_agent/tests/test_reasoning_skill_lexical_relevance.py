"""Phase PROD-1.1 (item 21/26/62-64): Stage-1 lexical relevance ranking for
DeterministicReasoningSkillRetriever -- opt-in via `query_text` (a caller
that never passes it, e.g. the existing PlannerContextBuilder default call
site, keeps byte-identical alphabetical-only behavior). Uses generic
assertions on which skill_id survives, never exact "vector scores" (there
are none -- this is lexical term-overlap, not embeddings, per item 26's
own "prefer incremental complexity" instruction).
"""
from agent.llm.context.reasoning_skill_retriever import DeterministicReasoningSkillRetriever
from agent.skills.models import SkillConsumerNode, SkillDefinition, SkillType
from agent.skills.registry import SkillRegistry


def _registry_with(*specs: tuple[str, str, str, str]) -> SkillRegistry:
    """Each spec: (skill_id, name, description, body)."""
    registry = SkillRegistry()
    for skill_id, name, description, body in specs:
        registry.register(
            SkillDefinition(
                skill_id=skill_id, name=name, description=description, category="reasoning",
                input_contract="context", output_contract="guidance",
                skill_type=SkillType.REASONING, applicable_nodes=[SkillConsumerNode.PLANNER],
            ),
            body=body,
        )
    return registry


def test_relevant_skill_selected_over_irrelevant_ones():
    """Item 62: current objective is WIP persistent Hold -- the WIP/flow
    causal skill should be selected, not the unrelated management skill,
    even though both are metadata-eligible for this node."""
    registry = _registry_with(
        ("wb.wip_hold_causal_reasoning", "WIP Hold Causal Reasoning", "How to trace persistent WIP Hold to its upstream cause.", "Distinguish material-shortage Hold from equipment-blocked Hold; trace propagation through the flow."),
        ("general.budget_planning_perspective", "Annual Budget Planning Perspective", "How to prioritize capital expenditure requests.", "Weigh ROI against payback period for equipment purchase proposals."),
        ("general.customer_communication_style", "Customer Communication Style", "How to phrase updates for external stakeholders.", "Use plain language, avoid internal jargon, lead with impact."),
    )
    retriever = DeterministicReasoningSkillRetriever(registry)

    result = retriever.retrieve(node=SkillConsumerNode.PLANNER, query_text="Why is WIP Hold persistently elevated at this plant?", limit=3)

    skill_ids = [s.skill_id for s in result]
    assert "wb.wip_hold_causal_reasoning" in skill_ids
    assert "general.budget_planning_perspective" not in skill_ids
    assert "general.customer_communication_style" not in skill_ids


def test_no_relevant_skill_returns_zero_not_a_forced_top1():
    """Item 63: when NOTHING lexically overlaps the query, return zero
    skills -- never fall back to an arbitrary alphabetical Top-1."""
    registry = _registry_with(
        ("general.budget_planning_perspective", "Annual Budget Planning Perspective", "How to prioritize capital expenditure requests.", "Weigh ROI against payback period."),
        ("general.customer_communication_style", "Customer Communication Style", "How to phrase updates for external stakeholders.", "Use plain language, avoid jargon."),
    )
    retriever = DeterministicReasoningSkillRetriever(registry)

    result = retriever.retrieve(node=SkillConsumerNode.PLANNER, query_text="quantum thermodynamics harmonic oscillator", limit=3)

    assert result == []


def test_query_text_none_keeps_alphabetical_only_behavior_unchanged():
    """Backward compatibility: the DEFAULT (no query_text) shape every
    existing caller uses is untouched by this phase's own addition."""
    registry = _registry_with(
        ("z.skill", "Z Skill", "z description", "z guidance"),
        ("a.skill", "A Skill", "a description", "a guidance"),
    )
    retriever = DeterministicReasoningSkillRetriever(registry)
    result = retriever.retrieve(node=SkillConsumerNode.PLANNER, limit=2)
    assert [s.skill_id for s in result] == ["a.skill", "z.skill"]


def test_budget_trimming_when_top2_relevant_but_only_one_fits():
    """Item 64: limit=1 with two relevant matches -- one survives, and the
    caller (via len(result)) can tell it was trimmed relative to how many
    were actually relevant."""
    registry = _registry_with(
        ("wb.wip_flow_reasoning", "WIP Flow Reasoning", "How WIP moves through the line.", "Trace WIP Hold propagation across operations."),
        ("wb.wip_material_reasoning", "WIP Material Reasoning", "How material shortage causes WIP Hold.", "Check material availability before blaming equipment for WIP Hold."),
        ("general.unrelated_skill", "Unrelated Skill", "Nothing about WIP.", "Generic advice about scheduling."),
    )
    retriever = DeterministicReasoningSkillRetriever(registry)

    unbounded = retriever.retrieve(node=SkillConsumerNode.PLANNER, query_text="WIP Hold investigation", limit=10)
    bounded = retriever.retrieve(node=SkillConsumerNode.PLANNER, query_text="WIP Hold investigation", limit=1)

    assert len(unbounded) >= 2  # both WIP-relevant skills matched
    assert len(bounded) == 1
    assert bounded[0].skill_id in {"wb.wip_flow_reasoning", "wb.wip_material_reasoning"}


def test_capability_retrieval_still_finds_required_capability_among_many():
    """Item 65: with many available EXECUTION capabilities, the one the
    scenario actually needs must not be accidentally excluded by any of
    this phase's own token-budget changes -- proven via the existing
    Top-K item-count mechanism (DeterministicCapabilityRetriever, unchanged
    this phase) plus a larger candidate pool than the configured limit."""
    from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
    from agent.state.enums import ObjectiveAction, TaskType

    registry = SkillRegistry()
    for i in range(12):
        registry.register(SkillDefinition(
            skill_id=f"wb.filler_capability_{i:02d}", name=f"Filler {i}", description="filler", category="analysis",
            input_contract="x", output_contract="y", domains=["wb"], task_types=[TaskType.ANALYSIS],
            actions=[ObjectiveAction.SUMMARIZE], capability_key=f"wb.filler_{i:02d}",
        ))
    registry.register(SkillDefinition(
        skill_id="wb.output_comparison", name="WB Output Comparison", description="Compare output across plants.", category="analysis",
        input_contract="x", output_contract="y", domains=["wb"], task_types=[TaskType.ANALYSIS],
        actions=[ObjectiveAction.COMPARE], capability_key="wb.output.comparison",
    ))
    retriever = DeterministicCapabilityRetriever(registry)

    result = retriever.retrieve(module_type="WB", task_type=TaskType.ANALYSIS, action_hint=ObjectiveAction.COMPARE, limit=4)

    assert "wb.output_comparison" in {s.skill_id for s in result}
