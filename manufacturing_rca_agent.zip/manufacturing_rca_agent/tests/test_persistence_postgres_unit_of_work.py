"""Offline PostgresPersistenceUnitOfWork tests (item 10/12) against
`FakeConnection` -- proves the real-transaction contract: `commit()` runs
every staged operation then calls the connection's own `.commit()`;
an exception mid-run (or explicit `rollback()`, or exiting the `with`
block without ever calling `commit()`) calls `.rollback()` instead and
discards the queue -- no repository/sink ever commits on its own.
"""
import pytest

from agent.persistence.postgres.unit_of_work import PostgresPersistenceUnitOfWork
from tests.postgres_fake import FakeConnection


def test_commit_runs_staged_operations_then_commits_connection():
    conn = FakeConnection()
    uow = PostgresPersistenceUnitOfWork(conn)
    calls = []
    uow.stage(lambda: calls.append("a"))
    uow.stage(lambda: calls.append("b"))
    uow.commit()
    assert calls == ["a", "b"]
    assert conn.committed is True
    assert conn.rolled_back is False


def test_nothing_runs_before_commit():
    conn = FakeConnection()
    uow = PostgresPersistenceUnitOfWork(conn)
    calls = []
    uow.stage(lambda: calls.append("a"))
    assert calls == []
    assert conn.committed is False


def test_exception_mid_commit_rolls_back_connection_and_reraises():
    conn = FakeConnection()
    uow = PostgresPersistenceUnitOfWork(conn)
    calls = []
    uow.stage(lambda: calls.append("a"))

    def _boom():
        raise ValueError("mapping failure")

    uow.stage(_boom)
    uow.stage(lambda: calls.append("c"))  # never reached

    with pytest.raises(ValueError):
        uow.commit()
    assert calls == ["a"]  # "c" never ran -- stopped at the failing operation
    assert conn.rolled_back is True
    assert conn.committed is False


def test_context_manager_rolls_back_if_commit_never_called():
    conn = FakeConnection()
    with PostgresPersistenceUnitOfWork(conn) as uow:
        uow.stage(lambda: None)
        # caller forgets to call uow.commit()
    assert conn.rolled_back is True
    assert conn.committed is False


def test_context_manager_rolls_back_on_exception_and_reraises():
    conn = FakeConnection()
    with pytest.raises(RuntimeError):
        with PostgresPersistenceUnitOfWork(conn) as uow:
            uow.stage(lambda: None)
            raise RuntimeError("caller-side failure before commit")
    assert conn.rolled_back is True
    assert conn.committed is False


def test_explicit_rollback_discards_queue():
    conn = FakeConnection()
    uow = PostgresPersistenceUnitOfWork(conn)
    calls = []
    uow.stage(lambda: calls.append("a"))
    uow.rollback()
    uow.commit()  # nothing staged anymore -- a no-op commit
    assert calls == []
    assert conn.rolled_back is True


def test_repositories_never_call_commit_themselves():
    """Item 10: transaction owner is only the UoW -- a repository writing
    through this connection must never trigger a commit on its own."""
    from agent.persistence.postgres.repositories import PostgresRunRepository
    from agent.persistence.records import RunRecord
    from agent.state.enums import RunTerminationStatus
    from datetime import datetime, timezone

    conn = FakeConnection()
    uow = PostgresPersistenceUnitOfWork(conn)
    repo = PostgresRunRepository(conn)
    record = RunRecord(run_id="run-1", user_request="x", factory_id="f-a", run_status=RunTerminationStatus.READY_FOR_SYNTHESIS, created_at=datetime.now(timezone.utc))
    uow.stage(lambda: repo.save_run(record))
    assert conn.committed is False  # staged, not yet applied
    uow.commit()
    assert conn.committed is True
