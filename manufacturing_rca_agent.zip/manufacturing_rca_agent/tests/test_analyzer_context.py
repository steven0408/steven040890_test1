"""Phase 5B-3A: AnalyzerContext / AnalyzerContextBuilder -- only what
Analyzer's decision (TaskType + Module selection) needs, with a coarse,
provider-tokenizer-agnostic context budget.
"""
from agent.catalog.module_registry import ModuleDefinition, ModuleRegistry
from agent.llm.context.analyzer_context import AnalyzerContext, AnalyzerContextBuilder
from agent.state.enums import TaskType

from .conftest import make_agent_state, make_module_registry


def test_analyzer_context_excludes_execution_level_fields():
    """AnalyzerContext's schema itself (extra="forbid") makes it
    structurally impossible to smuggle in ModuleState/observations/
    evidence/findings/objective_history/skills/tools/analysis_tree."""
    fields = set(AnalyzerContext.model_fields.keys())
    forbidden = {
        "module_states", "observations", "evidence", "findings",
        "objective_history", "skills", "tools", "analysis_tree", "module_state",
    }
    assert fields.isdisjoint(forbidden)
    assert fields == {
        "role", "hard_rules", "user_request_text", "normalized_request_text",
        "factory_id", "factory_name", "available_modules", "task_type_definitions",
        "relevant_reasoning_skills", "output_contract_version",
    }


def test_builder_reads_factory_and_request_from_state():
    builder = AnalyzerContextBuilder(make_module_registry())
    context = builder.build(make_agent_state())

    assert context.factory_id == "factory-a"
    assert context.user_request_text == "為什麼今天 Output 不足？"
    assert {m.module_type for m in context.available_modules} == {"OEE", "Output", "WIP"}
    assert {d.task_type for d in context.task_type_definitions} == {TaskType.INFORMATION, TaskType.ANALYSIS, TaskType.RCA}


def test_max_module_definitions_caps_the_catalog():
    builder = AnalyzerContextBuilder(make_module_registry(), max_module_definitions=1)
    context = builder.build(make_agent_state())
    assert len(context.available_modules) == 1


def test_max_hard_rules_caps_the_rule_list():
    builder = AnalyzerContextBuilder(make_module_registry(), max_hard_rules=1)
    context = builder.build(make_agent_state())
    assert len(context.hard_rules) == 1


def test_max_context_characters_trims_trailing_modules():
    registry = ModuleRegistry()
    for i in range(50):
        registry.register(
            ModuleDefinition(
                module_type=f"MOD{i}",
                name=f"Module {i}",
                description="A" * 200,  # deliberately verbose to blow the character budget
                supported_task_types=[TaskType.RCA],
            )
        )
    state = make_agent_state()
    state = state.model_copy(
        update={"factory_context": state.factory_context.model_copy(update={"enabled_modules": [f"MOD{i}" for i in range(50)]})}
    )

    builder = AnalyzerContextBuilder(registry, max_module_definitions=50, max_context_characters=3000)
    context = builder.build(state)

    assert len(context.available_modules) < 50
    assert len(context.model_dump_json()) <= 3000 or len(context.available_modules) == 0
