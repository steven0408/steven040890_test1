"""Phase WB-3F: ReflectorContextBuilder -- proves the Reflector context is a
selected, budget-trimmed working set (never a raw ModuleState dump), and
that reasoning-skill retrieval is correctly node-scoped to REFLECTOR (a
skill declaring only `applicable_nodes: [planner]` must never leak into
Reflector's context, and vice versa)."""
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.llm.context.reflector_context import ReflectorContextBudget, ReflectorContextBuilder
from agent.llm.context.reasoning_skill_retriever import DeterministicReasoningSkillRetriever
from agent.skills.models import SkillConsumerNode
from agent.skills.registry import SkillRegistry
from agent.state.enums import EvidenceQuality, ObjectiveAction, ObservationStatus, TargetRefType, TaskType
from agent.state.models import Evidence, Limitation, ModuleTask, Objective, Observation, TargetRef

from .conftest import make_budget

_REASONING_DIR = None


def _wb_reasoning_dir():
    from pathlib import Path

    return Path(__file__).resolve().parent.parent / "agent" / "skills" / "reasoning"


def _state(module_id="WB", module_type="WB", task_type=TaskType.RCA, n_limitations=0):
    task = ModuleTask(module_id=module_id, module_type=module_type, reason="test", goal_statement="why is output low", confidence=0.9, priority=0.9, task_type=task_type)
    state = build_initial_module_state(task, make_budget(max_steps=6, max_tool_calls=6, max_depth_per_entity=2), run_id="run-ctx", task_type=task_type)
    objective = Objective(
        objective_id=f"{module_id}-obj-1", description="query bank", action=ObjectiveAction.QUERY,
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="ASE07"), expected_output="bank status", priority_score=1.0, attempt_count=1,
    )
    evidence = Evidence(evidence_id=f"{module_id}-ev-1", objective_id=objective.objective_id, source_tool="tool:bank", summary="bank shortage detected", quality=EvidenceQuality.STRONG)
    observation = Observation(observation_id=f"{module_id}-obs-1", objective_id=objective.objective_id, tool_name="tool:bank", status=ObservationStatus.SUCCESS, payload_summary="ok")
    limitations = [
        Limitation(limitation_id=f"lim-{i}", description=f"gap {i}", impacted_objective_id=objective.objective_id, impact_statement="cannot confirm")
        for i in range(n_limitations)
    ]
    return state.model_copy(update={"current_objective": objective, "evidence": [evidence], "observations": [observation], "limitations": limitations})


def test_context_is_not_a_raw_state_dump():
    state = _state(n_limitations=2)
    outcome = ReflectorContextBuilder().build(state, run_id="run-ctx")

    assert outcome.context.goal.module_type == "WB"
    assert outcome.context.objective.target_ref_id == "ASE07"
    assert outcome.context.new_evidence.evidence_id == "WB-ev-1"
    assert len(outcome.context.relevant_limitations) == 2
    # never a dump of the full ModuleState -- no raw_ref/structured_payload/tool_calls-shaped field exists on the schema at all
    assert not hasattr(outcome.context, "structured_payload")
    assert not hasattr(outcome.context, "tool_calls")


def test_character_budget_trims_limitations_first():
    state = _state(n_limitations=10)
    tiny_budget = ReflectorContextBudget(max_limitations=10, max_context_characters=900)

    outcome = ReflectorContextBuilder().build(state, run_id="run-ctx", budget=tiny_budget)

    assert len(outcome.context.relevant_limitations) < 10
    assert outcome.record.items_trimmed > 0
    assert len(outcome.context.model_dump_json()) <= 900 or outcome.context.relevant_limitations == []


def test_context_build_is_audited():
    from agent.llm.context.context_audit import InMemoryContextAuditSink

    sink = InMemoryContextAuditSink()
    state = _state()
    ReflectorContextBuilder(audit_sink=sink).build(state, run_id="run-ctx")

    records = sink.list_for_run("run-ctx")
    assert len(records) == 1
    assert records[0].node == "module_reflector"
    assert records[0].included_evidence_count == 1


def test_reasoning_skill_retrieval_is_scoped_to_reflector_node():
    registry = SkillRegistry()
    registry.load_directory(_wb_reasoning_dir())
    retriever = DeterministicReasoningSkillRetriever(registry)

    state = _state(task_type=TaskType.RCA)
    outcome = ReflectorContextBuilder(reasoning_skill_retriever=retriever).build(state, run_id="run-ctx")

    # every WB reasoning skill shipped this far declares applicable_nodes=[planner] only
    # (Phase WB-3E) -- none should leak into Reflector's context yet.
    planner_only = [s for s in registry.list() if SkillConsumerNode.PLANNER in s.applicable_nodes and SkillConsumerNode.REFLECTOR not in s.applicable_nodes]
    assert planner_only  # sanity: the WB set really is planner-scoped today
    retrieved_ids = {s.skill_id for s in outcome.context.relevant_reasoning_skills}
    assert retrieved_ids.isdisjoint({s.skill_id for s in planner_only})


def test_empty_reasoning_skill_retriever_is_the_safe_default():
    state = _state()
    outcome = ReflectorContextBuilder().build(state, run_id="run-ctx")
    assert outcome.context.relevant_reasoning_skills == []
