"""Phase WB-3B item 70: Tool-level tests for the 5 new historical trend
Tools (OEE/WIP-Hold/BANK-shortage/OUTPUT/ISSUE's own extension). The
underlying arithmetic (`compute_historical_metrics`) is already pinned
down directly in `test_wb_historical_domain.py` -- these tests instead
confirm each Tool's own WIRING: correct data fetch/filter/date-range
handling, correct `is_abnormal` predicate selection, correct scope/
metrics embedding, and each domain's own documented quirk (OEE's
worst-operation-per-day convention + limitation, WIP/BANK's per-day
snapshot selection). All offline, against InMemory DataSources (both
hand-crafted and the real frozen synthetic dataset).
"""
from datetime import date, datetime, timedelta, timezone

import pytest

from agent.domain.wb.datasource import (
    InMemoryWBBankDataSource,
    InMemoryWBPlantOEEDataSource,
    InMemoryWBStageOutputDataSource,
    InMemoryWBWIPDataSource,
)
from agent.domain.wb.historical import WBTrendDirection
from agent.domain.wb.models import WBBankRecord, WBBankStatus, WBLotStatus, WBPlantOEERecord, WBSiteGroup, WBStageOutputRecord, WBWIPRecord
from agent.domain.wb.synthetic import (
    GOLDEN_DATE,
    HISTORY_DECLINE_START,
    SCENARIO_A_PLANT,
    SCENARIO_B_PLANT,
    SCENARIO_C_PLANT,
    SCENARIO_D_PLANT,
    build_wb_bank_records,
    build_wb_plant_oee_records,
    build_wb_stage_output_records,
    build_wb_wip_records,
)
from agent.domain.wb.tool_results import (
    WBBankShortageTrendAnalysisResult,
    WBOEETrendAnalysisResult,
    WBOutputTrendAnalysisResult,
    WBWIPHoldTrendAnalysisResult,
    register_wb_tool_result_payloads,
)
from agent.state.enums import ObservationStatus
from agent.state.payload import PayloadRegistry
from agent.tools.models import ToolExecutionRequest
from agent.tools.wb.bank_tools import AnalyzeWBBankShortageTrendTool, WBBankShortageTrendAnalysisInput, register_wb_bank_input_payloads
from agent.tools.wb.oee_tools import AnalyzeWBOEETrendTool, WBOEETrendAnalysisInput, register_wb_oee_input_payloads
from agent.tools.wb.output_tools import AnalyzeWBOutputTrendTool, WBOutputTrendAnalysisInput, register_wb_output_input_payloads
from agent.tools.wb.wip_tools import AnalyzeWBWIPHoldTrendTool, WBWIPHoldTrendAnalysisInput, register_wb_wip_input_payloads

_WINDOW_START = HISTORY_DECLINE_START - timedelta(days=3)  # 7-day window ending on GOLDEN_DATE


@pytest.fixture(autouse=True)
def _register_payloads():
    register_wb_tool_result_payloads()
    register_wb_oee_input_payloads()
    register_wb_wip_input_payloads()
    register_wb_bank_input_payloads()
    register_wb_output_input_payloads()


def _request(tool_id: str, payload_type: str, params) -> ToolExecutionRequest:
    return ToolExecutionRequest(tool_id=tool_id, run_id="run-1", module_id="WB", parameters=PayloadRegistry.pack(payload_type, params))


# ============================================================================
# OEE trend (item 9) -- worst-operation-per-day convention when
# operation_id is unspecified.
# ============================================================================


def _oee_datasource() -> InMemoryWBPlantOEEDataSource:
    return InMemoryWBPlantOEEDataSource(build_wb_plant_oee_records())


def test_oee_trend_scope_and_metrics_wired_correctly():
    tool = AnalyzeWBOEETrendTool(_oee_datasource())
    result = tool.run(_request(
        "analyze_wb_oee_trend", "wb.oee_trend_analysis_input",
        WBOEETrendAnalysisInput(plant_id=SCENARIO_A_PLANT, start=_WINDOW_START, end=GOLDEN_DATE),
    ))
    assert result.status == ObservationStatus.SUCCESS
    payload = PayloadRegistry.unpack(result.payload)
    assert isinstance(payload, WBOEETrendAnalysisResult)
    assert payload.scope.plant_id == SCENARIO_A_PLANT
    assert payload.scope.production_date_start == _WINDOW_START
    assert payload.scope.production_date_end == GOLDEN_DATE
    assert payload.metrics.window_start == _WINDOW_START
    assert payload.metrics.window_end == GOLDEN_DATE


def test_oee_trend_picks_worst_operation_per_day_when_operation_unspecified():
    """Item 9: when `operation_id` is unset and a day has multiple
    operations, the Tool's daily representative value is that day's
    WORST (lowest) OEE -- the same convention AnalyzeWBOEELossTool's own
    ranking already uses -- never an invented weighted average."""
    ds = InMemoryWBPlantOEEDataSource([
        WBPlantOEERecord(production_date=GOLDEN_DATE, plant_id="ASE01", operation_id="2800", oee=90.0, productive_ratio=90.0, downtime_ratio=5.0, pm_ratio=2.0, setup_ratio=2.0, idle_ratio=1.0, engineering_ratio=None, ts_ratio=None, source_sync_time=datetime(2026, 8, 13, tzinfo=timezone.utc)),
        WBPlantOEERecord(production_date=GOLDEN_DATE, plant_id="ASE01", operation_id="2900", oee=40.0, productive_ratio=40.0, downtime_ratio=50.0, pm_ratio=5.0, setup_ratio=3.0, idle_ratio=2.0, engineering_ratio=None, ts_ratio=None, source_sync_time=datetime(2026, 8, 13, tzinfo=timezone.utc)),
    ])
    tool = AnalyzeWBOEETrendTool(ds)
    result = tool.run(_request("analyze_wb_oee_trend", "wb.oee_trend_analysis_input", WBOEETrendAnalysisInput(plant_id="ASE01", start=GOLDEN_DATE, end=GOLDEN_DATE)))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.daily_series[0].oee == 40.0
    assert payload.daily_series[0].operation_id == "2900"
    assert any("worst-performing operation" in limitation for limitation in payload.limitations)


def test_oee_trend_with_explicit_operation_id_never_emits_the_multi_op_limitation():
    ds = InMemoryWBPlantOEEDataSource([
        WBPlantOEERecord(production_date=GOLDEN_DATE, plant_id="ASE01", operation_id="2800", oee=90.0, productive_ratio=90.0, downtime_ratio=5.0, pm_ratio=2.0, setup_ratio=2.0, idle_ratio=1.0, engineering_ratio=None, ts_ratio=None, source_sync_time=datetime(2026, 8, 13, tzinfo=timezone.utc)),
        WBPlantOEERecord(production_date=GOLDEN_DATE, plant_id="ASE01", operation_id="2900", oee=40.0, productive_ratio=40.0, downtime_ratio=50.0, pm_ratio=5.0, setup_ratio=3.0, idle_ratio=2.0, engineering_ratio=None, ts_ratio=None, source_sync_time=datetime(2026, 8, 13, tzinfo=timezone.utc)),
    ])
    tool = AnalyzeWBOEETrendTool(ds)
    result = tool.run(_request("analyze_wb_oee_trend", "wb.oee_trend_analysis_input", WBOEETrendAnalysisInput(plant_id="ASE01", operation_id="2800", start=GOLDEN_DATE, end=GOLDEN_DATE)))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.daily_series[0].oee == 90.0
    assert payload.limitations == []


def test_oee_trend_golden_scenario_a_single_day_event():
    """Golden Scenario A: ASE01's OEE dip is deliberately a single-day
    event, not a recurring pattern -- confirms `consecutive_abnormal_days`
    reflects that shape via the real synthetic dataset, not a hand-crafted one."""
    tool = AnalyzeWBOEETrendTool(_oee_datasource())
    result = tool.run(_request("analyze_wb_oee_trend", "wb.oee_trend_analysis_input", WBOEETrendAnalysisInput(plant_id=SCENARIO_A_PLANT, operation_id="2800", start=_WINDOW_START, end=GOLDEN_DATE)))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.metrics.consecutive_abnormal_days <= 1


def test_oee_trend_normal_plant_ase02_no_false_positive():
    """Golden Scenario D: ASE02 is the normal-plant control -- must not be
    classified as recurring/persistently abnormal."""
    tool = AnalyzeWBOEETrendTool(_oee_datasource())
    result = tool.run(_request("analyze_wb_oee_trend", "wb.oee_trend_analysis_input", WBOEETrendAnalysisInput(plant_id=SCENARIO_D_PLANT, start=_WINDOW_START, end=GOLDEN_DATE)))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.metrics.trend_direction in (WBTrendDirection.FLAT, WBTrendDirection.INSUFFICIENT_DATA)
    assert payload.metrics.recurrence_count == 0


def test_oee_trend_missing_plant_ase08_is_insufficient_data_not_zero():
    """Golden Scenario E: ASE08 has no OEE data at all on the golden date
    -- window with no data for this plant must report None/INSUFFICIENT_DATA,
    never a fabricated 0."""
    tool = AnalyzeWBOEETrendTool(_oee_datasource())
    result = tool.run(_request("analyze_wb_oee_trend", "wb.oee_trend_analysis_input", WBOEETrendAnalysisInput(plant_id="ASE08", start=_WINDOW_START, end=GOLDEN_DATE)))
    payload = PayloadRegistry.unpack(result.payload)
    if payload.metrics.observed_days == 0:
        assert payload.metrics.current_value is None
        assert payload.metrics.baseline_value is None
        assert payload.metrics.trend_direction == WBTrendDirection.INSUFFICIENT_DATA
        assert payload.metrics.persistence_ratio is None


# ============================================================================
# WIP Hold trend (item 10) -- snapshot semantic, recurring-but-non-consecutive
# synthetic pattern (deliberately distinct shape from BANK's persistent one).
# ============================================================================


def _wip_datasource() -> InMemoryWBWIPDataSource:
    records, snapshot_dates = build_wb_wip_records()
    return InMemoryWBWIPDataSource(records, snapshot_dates=snapshot_dates)


def test_wip_hold_trend_uses_snapshot_date_never_production_date_field():
    tool = AnalyzeWBWIPHoldTrendTool(_wip_datasource())
    result = tool.run(_request("analyze_wb_wip_hold_trend", "wb.wip_hold_trend_analysis_input", WBWIPHoldTrendAnalysisInput(plant_id=SCENARIO_C_PLANT, start=_WINDOW_START, end=GOLDEN_DATE)))
    payload = PayloadRegistry.unpack(result.payload)
    assert isinstance(payload, WBWIPHoldTrendAnalysisResult)
    assert payload.scope.snapshot_date_start == _WINDOW_START
    assert payload.scope.snapshot_date_end == GOLDEN_DATE
    assert all(hasattr(p, "snapshot_date") for p in payload.daily_series)


def test_wip_hold_trend_golden_scenario_c_recurring_but_not_consecutive():
    """Golden Scenario C / item 30: ASE03's synthetic WIP Hold pattern is
    RECURRING (elevated on multiple days) but deliberately NON-consecutive
    (alternating) -- recurrence_count should exceed consecutive_abnormal_days."""
    tool = AnalyzeWBWIPHoldTrendTool(_wip_datasource())
    result = tool.run(_request("analyze_wb_wip_hold_trend", "wb.wip_hold_trend_analysis_input", WBWIPHoldTrendAnalysisInput(plant_id=SCENARIO_C_PLANT, start=_WINDOW_START, end=GOLDEN_DATE)))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.metrics.recurrence_count >= 2
    assert payload.metrics.recurrence_count > payload.metrics.consecutive_abnormal_days


def test_wip_hold_trend_preserves_exact_golden_day_ratio():
    """The golden-day WIP Hold ratio (22/30) established in earlier phases
    must survive the 14-day synthetic dataset extension byte-for-byte."""
    tool = AnalyzeWBWIPHoldTrendTool(_wip_datasource())
    result = tool.run(_request("analyze_wb_wip_hold_trend", "wb.wip_hold_trend_analysis_input", WBWIPHoldTrendAnalysisInput(plant_id=SCENARIO_C_PLANT, start=GOLDEN_DATE, end=GOLDEN_DATE)))
    payload = PayloadRegistry.unpack(result.payload)
    golden_point = next(p for p in payload.daily_series if p.snapshot_date == GOLDEN_DATE)
    assert golden_point.hold_lot_count == 22
    assert golden_point.total_lot_count == 30


def test_wip_hold_trend_one_snapshot_per_calendar_day_even_with_multiple_syncs():
    """A day with more than one same-day sync must still yield exactly ONE
    daily_series point (via the existing `select_latest_snapshot`
    convention, applied per-day) -- never double-counted."""
    d = GOLDEN_DATE
    earlier = datetime.combine(d, datetime.min.time()).replace(hour=8, tzinfo=timezone.utc)
    later = datetime.combine(d, datetime.min.time()).replace(hour=16, tzinfo=timezone.utc)
    records = [
        WBWIPRecord(plant_id="ASE99", facility_source=None, mother_batch_id="M1", child_batch_id="C1", operation_id="OP1", current_quantity=10, customer_code=None, package_code=None, lead_count=None, run_type=None, lot_status=WBLotStatus.ACTIVE, lot_status_raw="Active", source_sync_time=earlier),
        WBWIPRecord(plant_id="ASE99", facility_source=None, mother_batch_id="M2", child_batch_id="C2", operation_id="OP1", current_quantity=10, customer_code=None, package_code=None, lead_count=None, run_type=None, lot_status=WBLotStatus.HOLD, lot_status_raw="Hold", source_sync_time=later),
    ]
    ds = InMemoryWBWIPDataSource(records)  # no explicit snapshot_dates -- falls back to source_sync_time.date(), both same day
    tool = AnalyzeWBWIPHoldTrendTool(ds)
    result = tool.run(_request("analyze_wb_wip_hold_trend", "wb.wip_hold_trend_analysis_input", WBWIPHoldTrendAnalysisInput(plant_id="ASE99", start=d, end=d)))
    payload = PayloadRegistry.unpack(result.payload)
    assert len(payload.daily_series) == 1
    # only the LATER sync's single record should be reflected
    assert payload.daily_series[0].total_lot_count == 1
    assert payload.daily_series[0].hold_lot_count == 1


# ============================================================================
# BANK shortage trend (item 11) -- material_shortage specifically, never
# merged with other statuses; persistent (consecutive) synthetic pattern.
# ============================================================================


def _bank_datasource() -> InMemoryWBBankDataSource:
    records, snapshot_dates = build_wb_bank_records()
    return InMemoryWBBankDataSource(records, snapshot_dates=snapshot_dates)


def test_bank_shortage_trend_never_counts_ready_to_issue_as_bad():
    d = GOLDEN_DATE
    sync = datetime.combine(d, datetime.min.time()).replace(hour=8, minute=40, tzinfo=timezone.utc)
    records = [
        WBBankRecord(plant_id="ASE99", site_group=WBSiteGroup.A2, site_group_raw="A2", mother_batch_id="M1", customer_code=None, customer_sub_code=None, customer_group=None, device=None, package_code=None, lead_count=None, wafer_size_inch=None, wafer_quantity=None, die_quantity=None, bank_status=WBBankStatus.READY_TO_ISSUE, bank_status_raw="Ready To Issue", bank_entry_time=None, description=None, run_type=None, customer_run_type=None, unit_of_measure=None, source_sync_time=sync),
        WBBankRecord(plant_id="ASE99", site_group=WBSiteGroup.A2, site_group_raw="A2", mother_batch_id="M2", customer_code=None, customer_sub_code=None, customer_group=None, device=None, package_code=None, lead_count=None, wafer_size_inch=None, wafer_quantity=None, die_quantity=None, bank_status=WBBankStatus.READY_TO_ISSUE, bank_status_raw="Ready To Issue", bank_entry_time=None, description=None, run_type=None, customer_run_type=None, unit_of_measure=None, source_sync_time=sync),
    ]
    ds = InMemoryWBBankDataSource(records)  # no explicit snapshot_dates -- falls back to source_sync_time.date()
    tool = AnalyzeWBBankShortageTrendTool(ds)
    result = tool.run(_request("analyze_wb_bank_shortage_trend", "wb.bank_shortage_trend_analysis_input", WBBankShortageTrendAnalysisInput(plant_id="ASE99", start=d, end=d)))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.daily_series[0].shortage_count == 0
    assert payload.metrics.current_value == 0.0
    assert payload.metrics.abnormal_days == 0


def test_bank_shortage_trend_never_merges_no_wafer_in_with_material_shortage():
    d = GOLDEN_DATE
    sync = datetime.combine(d, datetime.min.time()).replace(hour=8, minute=40, tzinfo=timezone.utc)
    records = [
        WBBankRecord(plant_id="ASE99", site_group=WBSiteGroup.A2, site_group_raw="A2", mother_batch_id="M1", customer_code=None, customer_sub_code=None, customer_group=None, device=None, package_code=None, lead_count=None, wafer_size_inch=None, wafer_quantity=None, die_quantity=None, bank_status=WBBankStatus.NO_WAFER_IN, bank_status_raw="No Wafer In", bank_entry_time=None, description=None, run_type=None, customer_run_type=None, unit_of_measure=None, source_sync_time=sync),
        WBBankRecord(plant_id="ASE99", site_group=WBSiteGroup.A2, site_group_raw="A2", mother_batch_id="M2", customer_code=None, customer_sub_code=None, customer_group=None, device=None, package_code=None, lead_count=None, wafer_size_inch=None, wafer_quantity=None, die_quantity=None, bank_status=WBBankStatus.MATERIAL_SHORTAGE, bank_status_raw="Material Shortage", bank_entry_time=None, description=None, run_type=None, customer_run_type=None, unit_of_measure=None, source_sync_time=sync),
    ]
    ds = InMemoryWBBankDataSource(records)  # no explicit snapshot_dates -- falls back to source_sync_time.date()
    tool = AnalyzeWBBankShortageTrendTool(ds)
    result = tool.run(_request("analyze_wb_bank_shortage_trend", "wb.bank_shortage_trend_analysis_input", WBBankShortageTrendAnalysisInput(plant_id="ASE99", start=d, end=d)))
    payload = PayloadRegistry.unpack(result.payload)
    # only the ONE material_shortage record counts, NO_WAFER_IN is not folded in
    assert payload.daily_series[0].shortage_count == 1
    assert payload.daily_series[0].total_count == 2


def test_bank_shortage_trend_golden_scenario_b_persistent_pattern():
    """Golden Scenario B / item 30: ASE07's synthetic BANK shortage
    pattern is PERSISTENT (consecutive days up to and including the
    golden date) -- consecutive_abnormal_days should be high."""
    tool = AnalyzeWBBankShortageTrendTool(_bank_datasource())
    result = tool.run(_request("analyze_wb_bank_shortage_trend", "wb.bank_shortage_trend_analysis_input", WBBankShortageTrendAnalysisInput(plant_id=SCENARIO_B_PLANT, start=_WINDOW_START, end=GOLDEN_DATE)))
    payload = PayloadRegistry.unpack(result.payload)
    assert isinstance(payload, WBBankShortageTrendAnalysisResult)
    assert payload.metrics.consecutive_abnormal_days >= 3
    assert payload.metrics.recurrence_count == payload.metrics.consecutive_abnormal_days  # fully consecutive, not merely recurring


def test_bank_shortage_trend_preserves_exact_golden_day_ratio():
    tool = AnalyzeWBBankShortageTrendTool(_bank_datasource())
    result = tool.run(_request("analyze_wb_bank_shortage_trend", "wb.bank_shortage_trend_analysis_input", WBBankShortageTrendAnalysisInput(plant_id=SCENARIO_B_PLANT, start=GOLDEN_DATE, end=GOLDEN_DATE)))
    payload = PayloadRegistry.unpack(result.payload)
    golden_point = next(p for p in payload.daily_series if p.snapshot_date == GOLDEN_DATE)
    assert golden_point.shortage_count == 7
    assert golden_point.total_count == 10


# ============================================================================
# OUTPUT trend (item 12) -- self-baseline abnormality (like ISSUE), no
# domain-independent "low" threshold.
# ============================================================================


def _output_datasource() -> InMemoryWBStageOutputDataSource:
    return InMemoryWBStageOutputDataSource(build_wb_stage_output_records())


def test_output_trend_uses_production_date_range_and_self_baseline():
    tool = AnalyzeWBOutputTrendTool(_output_datasource())
    result = tool.run(_request("analyze_wb_output_trend", "wb.output_trend_analysis_input", WBOutputTrendAnalysisInput(plant_id=SCENARIO_B_PLANT, start=_WINDOW_START, end=GOLDEN_DATE)))
    payload = PayloadRegistry.unpack(result.payload)
    assert isinstance(payload, WBOutputTrendAnalysisResult)
    assert payload.scope.production_date_start == _WINDOW_START
    assert payload.scope.production_date_end == GOLDEN_DATE


def test_output_trend_aggregates_multiple_operations_into_one_daily_total():
    """Unlike OEE (worst-operation convention), OUTPUT is a SUM metric --
    multiple operation rows on the same day must be summed, not reduced to
    one row's value."""
    d = GOLDEN_DATE
    sync = datetime.combine(d, datetime.min.time()).replace(hour=8, minute=30, tzinfo=timezone.utc)
    records = [
        WBStageOutputRecord(production_date=d, plant_id="ASE99", location=None, operation_id="OP1", output_quantity=100, customer_code=None, device_type=None, package_code=None, lead_count=None, bond_diagram=None, source_facility=None, source_sync_time=sync),
        WBStageOutputRecord(production_date=d, plant_id="ASE99", location=None, operation_id="OP2", output_quantity=50, customer_code=None, device_type=None, package_code=None, lead_count=None, bond_diagram=None, source_facility=None, source_sync_time=sync),
    ]
    ds = InMemoryWBStageOutputDataSource(records)
    tool = AnalyzeWBOutputTrendTool(ds)
    result = tool.run(_request("analyze_wb_output_trend", "wb.output_trend_analysis_input", WBOutputTrendAnalysisInput(plant_id="ASE99", start=d, end=d)))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.daily_series[0].output_quantity == 150


def test_output_trend_normal_plant_no_false_positive():
    tool = AnalyzeWBOutputTrendTool(_output_datasource())
    result = tool.run(_request("analyze_wb_output_trend", "wb.output_trend_analysis_input", WBOutputTrendAnalysisInput(plant_id=SCENARIO_D_PLANT, start=_WINDOW_START, end=GOLDEN_DATE)))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.metrics.recurrence_count == 0
