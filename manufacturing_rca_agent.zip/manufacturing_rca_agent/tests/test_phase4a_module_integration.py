"""Phase 4A: Real Module Subgraph Integration.

Wires the Phase 2 fan-out/fan-in shell to the real Module ReAct Subgraph
(Phase 3) instead of the flat module_subgraph_mock, and checks the 12 points
from the Phase 4A review:

  OEE:    3 ReAct cycles on the same source -> COMPLETE
  Output: 1 ReAct cycle                     -> COMPLETE
  WIP:    1 success (finding) then both maintenance sources DATA_NOT_FOUND
                                             -> PARTIAL, with a Limitation
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.graph.graph import build_phase2_graph
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.planning.policies.mock import DeterministicMockPolicy, Requirement
from agent.state.enums import ErrorType, EvidenceQuality, ModuleStatus, ObservationStatus, RunTerminationStatus
from agent.state.models import Budget
from agent.state.state import AgentState
from agent.tools.base import ToolResult
from agent.tools.mocks.scripted_tool import ScriptedMockTool

from .conftest import make_agent_state, make_budget

MODULE_RUNTIME = {
    "OEE": ModuleRuntimeConfig(
        policy=DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=3),
        tool=ScriptedMockTool(
            {"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.MODERATE)}
        ),
        budget=make_budget(max_steps=5, max_tool_calls=5, max_depth_per_entity=3),
    ),
    "Output": ModuleRuntimeConfig(
        policy=DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1),
        tool=ScriptedMockTool(
            {"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}
        ),
        budget=make_budget(max_steps=5, max_tool_calls=5, max_depth_per_entity=3),
    ),
    "WIP": ModuleRuntimeConfig(
        policy=DeterministicMockPolicy(
            requirements=[
                Requirement(sources=["aging"], sufficiency_evidence_count=1),
                Requirement(sources=["bottleneck-primary", "bottleneck-alternative"], sufficiency_evidence_count=1),
            ]
        ),
        tool=ScriptedMockTool(
            {
                "aging": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="aging queue confirmed", quality=EvidenceQuality.MODERATE),
                "bottleneck-primary": ToolResult(status=ObservationStatus.ERROR, error_type=ErrorType.DATA_NOT_FOUND, error_message="no rows"),
                "bottleneck-alternative": ToolResult(status=ObservationStatus.ERROR, error_type=ErrorType.DATA_NOT_FOUND, error_message="no rows"),
            }
        ),
        budget=make_budget(max_steps=6, max_tool_calls=6, max_depth_per_entity=3),
    ),
}


def _run():
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(MODULE_RUNTIME, checkpointer)
    app = graph.compile(checkpointer=checkpointer)

    initial_state = make_agent_state()
    config = {"configurable": {"thread_id": initial_state.run_id}}

    result = app.invoke(initial_state, config=config)
    final_state = AgentState.model_validate(result)
    history = list(reversed(list(app.get_state_history(config))))
    return final_state, history


# 1 & 9: Coordinator Send() starts three real Module ReAct subgraphs; fan-in merges them
def test_coordinator_dispatches_three_real_module_subgraphs_and_merges_them():
    final_state, _ = _run()
    assert set(final_state.module_states) == {"OEE", "Output", "WIP"}


# 2 & 5: different iteration counts per module; no cross-module contamination of
# observations/evidence/findings/reflection_history
def test_modules_run_different_number_of_react_cycles_in_full_isolation():
    final_state, _ = _run()
    oee, output, wip = (final_state.module_states[m] for m in ("OEE", "Output", "WIP"))

    assert len(oee.observations) == 3
    assert len(oee.evidence) == 3
    assert len(oee.reflection_history) == 3

    assert len(output.observations) == 1
    assert len(output.evidence) == 1
    assert len(output.reflection_history) == 1

    assert len(wip.observations) == 3  # aging success + 2 bottleneck errors
    assert len(wip.evidence) == 1
    assert len(wip.reflection_history) == 3

    # nothing crossed module boundaries: every observation's tool_name only
    # ever references that module's own scripted sources
    assert all(o.tool_name == "mock_tool:primary" for o in oee.observations)
    assert all(o.tool_name == "mock_tool:primary" for o in output.observations)
    assert {o.tool_name for o in wip.observations} == {
        "mock_tool:aging",
        "mock_tool:bottleneck-primary",
        "mock_tool:bottleneck-alternative",
    }


# 3: ModuleState fully isolated (module_id/module_type correctness per key)
def test_module_state_identity_matches_its_key():
    final_state, _ = _run()
    for module_id, module_state in final_state.module_states.items():
        assert module_state.module_id == module_id
        assert module_state.module_type == module_id


# 4: objective_history is independent per module
def test_objective_history_is_independent_per_module():
    final_state, _ = _run()
    oee, output, wip = (final_state.module_states[m] for m in ("OEE", "Output", "WIP"))

    assert set(oee.objective_history) == {"OEE-obj-1", "OEE-obj-2", "OEE-obj-3"}
    assert set(output.objective_history) == {"Output-obj-1"}
    assert set(wip.objective_history) == {"WIP-obj-1", "WIP-obj-2", "WIP-obj-3"}

    all_ids = list(oee.objective_history) + list(output.objective_history) + list(wip.objective_history)
    assert len(all_ids) == len(set(all_ids))  # completely disjoint across modules


# 6: one PARTIAL module does not block the others from completing
def test_one_partial_module_does_not_block_the_others():
    final_state, _ = _run()
    assert final_state.module_states["OEE"].status == ModuleStatus.COMPLETE
    assert final_state.module_states["Output"].status == ModuleStatus.COMPLETE
    assert final_state.module_states["WIP"].status == ModuleStatus.PARTIAL
    assert len(final_state.module_states["WIP"].findings) == 1
    assert len(final_state.module_states["WIP"].limitations) == 1
    assert final_state.module_states["WIP"].limitations[0].related_error.error_type == ErrorType.DATA_NOT_FOUND


# 7: each module's *internal* ReAct depth differs (visible module-side, even
# though the nested subgraph invoke is synchronous at the parent level -- see
# report note on parent-level superstep granularity)
def test_each_module_completed_after_a_different_number_of_internal_cycles():
    final_state, _ = _run()
    assert final_state.module_states["Output"].metrics.step_count == 1
    assert final_state.module_states["WIP"].metrics.step_count == 3
    assert final_state.module_states["OEE"].metrics.step_count == 3
    assert final_state.module_states["OEE"].metrics.tool_call_count == 3


# 8: Coordinator correctly waits for all modules to reach a terminal status
def test_coordinator_drains_in_flight_only_once_all_modules_are_terminal():
    _, history = _run()
    dispatch_states = [
        snap.values["module_dispatch"] for snap in history if snap.values.get("module_dispatch") is not None
    ]
    first_with_in_flight = next(d for d in dispatch_states if d.in_flight)
    assert set(first_with_in_flight.in_flight) == {"OEE", "Output", "WIP"}

    final_dispatch = dispatch_states[-1]
    assert final_dispatch.in_flight == []
    assert final_dispatch.pending == []


# 10: Global Completion Check remains pure read-only
def test_global_completion_check_is_still_read_only():
    _, history = _run()
    before = next(snap for snap in history if snap.next == ("global_completion_check",))
    after = history[-1]

    assert before.values["module_states"] == after.values["module_states"]
    assert before.values["module_dispatch"] == after.values["module_dispatch"]
    assert before.values["termination_status"] != after.values["termination_status"]


# 11: final termination_status
def test_reaches_ready_for_synthesis():
    final_state, _ = _run()
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


# 12: checkpoint / serialization still fine with the real subgraph wired in
def test_final_state_round_trips_through_json():
    final_state, _ = _run()
    payload = final_state.model_dump_json()
    restored = AgentState.model_validate_json(payload)
    assert restored == final_state
