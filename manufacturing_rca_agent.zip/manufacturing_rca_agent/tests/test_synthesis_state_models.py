"""Phase 6A: Synthesis/handoff state model contracts -- CrossModuleRelation
and RecommendationCandidate's hard validators (never source-less, never an
unsupported CONFIRMED_CAUSAL claim), and the closed field sets for
ModuleHandoff/HandoffPackage.
"""
import pytest
from pydantic import ValidationError

from agent.state.enums import RecommendationActionType, RelationType
from agent.state.models import CrossModuleRelation, HandoffPackage, ModuleHandoff, RecommendationCandidate


def test_confirmed_causal_relation_requires_supporting_findings():
    with pytest.raises(ValidationError):
        CrossModuleRelation(
            relation_id="r1", source_modules=["OEE", "Output"], relation_type=RelationType.CONFIRMED_CAUSAL,
            statement="OEE Availability loss caused Output shortfall.", supporting_finding_ids=[], confidence=0.9,
        )


def test_confirmed_causal_relation_with_support_is_valid():
    relation = CrossModuleRelation(
        relation_id="r1", source_modules=["OEE", "Output"], relation_type=RelationType.CONFIRMED_CAUSAL,
        statement="OEE Availability loss caused Output shortfall.", supporting_finding_ids=["f1"], confidence=0.9,
    )
    assert relation.supporting_finding_ids == ["f1"]


@pytest.mark.parametrize("relation_type", [RelationType.CORRELATED, RelationType.SUPPORTS, RelationType.CAUSAL_CANDIDATE])
def test_non_confirmed_relation_types_do_not_require_support(relation_type):
    relation = CrossModuleRelation(
        relation_id="r1", source_modules=["OEE", "Output"], relation_type=relation_type,
        statement="Observed together in the same shift.", supporting_finding_ids=[], confidence=0.4,
    )
    assert relation.supporting_finding_ids == []


def test_recommendation_candidate_requires_lineage():
    with pytest.raises(ValidationError):
        RecommendationCandidate(
            recommendation_id="rec1", statement="Replace the motor.",
            based_on_finding_ids=[], based_on_root_cause_ids=[],
            action_type=RecommendationActionType.MAINTENANCE_ACTION, confidence=0.8,
        )


def test_recommendation_candidate_with_finding_lineage_is_valid():
    rec = RecommendationCandidate(
        recommendation_id="rec1", statement="Replace the motor.",
        based_on_finding_ids=["f1"], based_on_root_cause_ids=[],
        action_type=RecommendationActionType.MAINTENANCE_ACTION, confidence=0.8,
    )
    assert rec.based_on_finding_ids == ["f1"]


def test_recommendation_candidate_with_root_cause_lineage_is_valid():
    rec = RecommendationCandidate(
        recommendation_id="rec1", statement="Replace the motor.",
        based_on_finding_ids=[], based_on_root_cause_ids=["rc1"],
        action_type=RecommendationActionType.MAINTENANCE_ACTION, confidence=0.8,
    )
    assert rec.based_on_root_cause_ids == ["rc1"]


def test_module_handoff_field_set_is_closed():
    assert set(ModuleHandoff.model_fields.keys()) == {
        "module_id", "module_type", "task_type", "module_status", "module_goal", "executive_finding",
        "confirmed_findings", "hypotheses", "root_causes", "key_entities", "branch_summary",
        "evidence_summary", "limitations", "unresolved_questions", "confidence", "evidence_coverage",
    }


def test_handoff_package_field_set_is_closed():
    assert set(HandoffPackage.model_fields.keys()) == {
        "run_id", "request_summary", "task_type", "overall_status", "module_results", "key_findings",
        "root_causes", "cross_module_relations", "limitations", "unresolved_questions",
        "recommendation_candidates", "confidence_summary", "markdown",
    }


def test_handoff_package_never_embeds_raw_harness_state():
    """Same discipline as PlannerContext (Phase 5C-1) -- no reachable
    nested type is ModuleState/Observation/ToolCallRecord/ObjectiveRecord/
    LLMCallRecord/ContextBuildRecord/PlannerDecisionRecord/HumanRequest."""
    import typing

    from agent.llm.context.context_audit import ContextBuildRecord
    from agent.llm.models import LLMCallRecord
    from agent.planning.decision_audit import PlannerDecisionRecord
    from agent.state.base import RCABaseModel
    from agent.state.models import HumanRequest, ModuleState, Observation, ObjectiveRecord, ToolCallRecord

    def _nested(annotation, seen: set) -> set:
        origin = typing.get_origin(annotation)
        if origin is None:
            if isinstance(annotation, type) and issubclass(annotation, RCABaseModel) and annotation not in seen:
                seen.add(annotation)
                for field in annotation.model_fields.values():
                    seen |= _nested(field.annotation, seen)
            return seen
        for arg in typing.get_args(annotation):
            seen |= _nested(arg, seen)
        return seen

    nested = _nested(HandoffPackage, set())
    forbidden = {ModuleState, Observation, ToolCallRecord, ObjectiveRecord, HumanRequest, LLMCallRecord, ContextBuildRecord, PlannerDecisionRecord}
    assert nested.isdisjoint(forbidden)
