"""Phase WB-3B item 19-27/49/70: `AnalyzeWBIssueVsOutputTool` -- the first
cross-source WB Tool (ISSUE + OUTPUT together). Covers the phase's own
explicit regression list: daily aggregation BEFORE any join (never a
row-level many-to-many join), business-date join key (release_date/
production_date, NEVER source_sync_time), partial/insufficient overlap
handling, and the hard "no causal inflation" guarantee -- this Tool's
output must never contain a causal claim, only descriptive temporal
association. All offline, hand-crafted records for full control over
join edge cases plus the real synthetic dataset for the Golden Scenario B
narrative.
"""
from datetime import date, datetime, timedelta, timezone

import pytest

from agent.domain.wb.datasource import InMemoryWBIssueDataSource, InMemoryWBStageOutputDataSource
from agent.domain.wb.historical import WBTrendDirection
from agent.domain.wb.models import WBIssueRecord, WBStageOutputRecord
from agent.domain.wb.synthetic import GOLDEN_DATE, HISTORY_DECLINE_START, SCENARIO_B_PLANT, SCENARIO_D_PLANT, build_wb_issue_records, build_wb_stage_output_records
from agent.domain.wb.tool_results import WBDirectionAlignment, WBIssueOutputRelationshipResult, register_wb_tool_result_payloads
from agent.state.enums import ObservationStatus
from agent.state.payload import PayloadRegistry
from agent.tools.models import ToolExecutionRequest
from agent.tools.wb.cross_source_tools import AnalyzeWBIssueVsOutputTool, WBIssueOutputRelationshipInput, register_wb_cross_source_input_payloads

_WINDOW_START = HISTORY_DECLINE_START - timedelta(days=3)  # 7-day window ending on GOLDEN_DATE
_FORBIDDEN_CAUSAL_WORDS = ("caused", "causes", "causing", "proves", "root cause", "directly caused", "due to", "because of")


@pytest.fixture(autouse=True)
def _register_payloads():
    register_wb_tool_result_payloads()
    register_wb_cross_source_input_payloads()


def _request(params: WBIssueOutputRelationshipInput) -> ToolExecutionRequest:
    return ToolExecutionRequest(
        tool_id="analyze_wb_issue_vs_output", run_id="run-1", module_id="WB",
        parameters=PayloadRegistry.pack("wb.issue_output_relationship_input", params),
    )


def _issue_record(plant_id: str, release_date: date | None, quantity: int, sync: datetime) -> WBIssueRecord:
    return WBIssueRecord(
        source_sync_time=sync, plant_id=plant_id, site=None, schedule=None, customer_code=None, customer_name=None,
        device_type=None, issue_quantity=quantity, lead_count=None, package_code=None, package_type=None, region=None,
        release_date=release_date, release_date_raw=release_date.isoformat() if release_date else None, release_time=None,
        release_system=None, time_bucket=None, wafer_inch=None, year=None,
        bd_no_unknown=None, cu_flag_unknown=None, customer_run_type_unknown=None, customer_sod_unknown=None,
        internal_sod_unknown=None, routid_unknown=None, run_type_unknown=None, unit_of_measure_unknown=None,
        user_id_unknown=None, user_name_unknown=None,
    )


def _output_record(plant_id: str, production_date: date, quantity: int, sync: datetime, operation_id: str = "OP1") -> WBStageOutputRecord:
    return WBStageOutputRecord(
        production_date=production_date, plant_id=plant_id, location=None, operation_id=operation_id, output_quantity=quantity,
        customer_code=None, device_type=None, package_code=None, lead_count=None, bond_diagram=None, source_facility=None,
        source_sync_time=sync,
    )


def _real_datasources():
    return InMemoryWBIssueDataSource(build_wb_issue_records()), InMemoryWBStageOutputDataSource(build_wb_stage_output_records())


# ============================================================================
# Join semantics (item 23/24/49) -- business date, never sync_time; daily
# aggregation BEFORE the join; no many-to-many row explosion.
# ============================================================================


def test_join_uses_business_date_not_sync_time_even_when_sync_time_differs():
    """Item 49's own regression: ISSUE's release_date and OUTPUT's
    production_date are the same business day, but their source_sync_time
    values are deliberately DIFFERENT (different hour, even different
    calendar day for the sync) -- the join must still succeed via business
    date."""
    business_day = GOLDEN_DATE
    issue_sync = datetime(2026, 8, 13, 2, 0, tzinfo=timezone.utc)  # synced the NEXT day
    output_sync = datetime(2026, 8, 12, 8, 30, tzinfo=timezone.utc)  # synced same day
    issue_ds = InMemoryWBIssueDataSource([_issue_record("ASE99", business_day, 100, issue_sync)])
    output_ds = InMemoryWBStageOutputDataSource([_output_record("ASE99", business_day, 200, output_sync)])

    tool = AnalyzeWBIssueVsOutputTool(issue_ds, output_ds)
    result = tool.run(_request(WBIssueOutputRelationshipInput(plant_id="ASE99", start=business_day, end=business_day)))
    payload = PayloadRegistry.unpack(result.payload)

    assert payload.overlap_observed_days == 1
    assert payload.issue.current_value == 100.0
    assert payload.output.current_value == 200.0


def test_daily_aggregation_happens_before_join_no_many_to_many_row_explosion():
    """Item 24: multiple ISSUE rows AND multiple OUTPUT rows on the same
    day must sum to ONE total per source per day BEFORE the join -- never
    cross-multiplied into (n_issue_rows x n_output_rows) combinations."""
    d = GOLDEN_DATE
    sync = datetime.combine(d, datetime.min.time()).replace(hour=8, tzinfo=timezone.utc)
    issue_ds = InMemoryWBIssueDataSource([
        _issue_record("ASE99", d, 100, sync), _issue_record("ASE99", d, 50, sync), _issue_record("ASE99", d, 25, sync),
    ])
    output_ds = InMemoryWBStageOutputDataSource([
        _output_record("ASE99", d, 200, sync, "OP1"), _output_record("ASE99", d, 300, sync, "OP2"),
    ])

    tool = AnalyzeWBIssueVsOutputTool(issue_ds, output_ds)
    result = tool.run(_request(WBIssueOutputRelationshipInput(plant_id="ASE99", start=d, end=d)))
    payload = PayloadRegistry.unpack(result.payload)

    # 3 ISSUE rows summing to 175, 2 OUTPUT rows summing to 500 -- NOT
    # 3*2=6 joined combinations, and NOT (175*2) or (500*3) from an
    # accidental cross-multiply.
    assert payload.issue.current_value == 175.0
    assert payload.output.current_value == 500.0
    assert payload.overlap_observed_days == 1  # still exactly 1 calendar day, not 6 row-pairs


def test_partial_overlap_reports_the_smaller_overlap_not_either_sources_full_length():
    """Item 25: ISSUE has 7 days of data, OUTPUT only has 5 (2 missing) --
    overlap_observed_days must be 5, and a limitation must describe the gap."""
    start = _WINDOW_START
    end = GOLDEN_DATE
    all_days = [start + timedelta(days=i) for i in range(7)]
    missing_output_days = {all_days[0], all_days[1]}  # first 2 days have no OUTPUT
    sync = datetime.combine(end, datetime.min.time()).replace(hour=8, tzinfo=timezone.utc)

    issue_records = [_issue_record("ASE99", d, 100, sync) for d in all_days]
    output_records = [_output_record("ASE99", d, 200, sync) for d in all_days if d not in missing_output_days]

    tool = AnalyzeWBIssueVsOutputTool(InMemoryWBIssueDataSource(issue_records), InMemoryWBStageOutputDataSource(output_records))
    result = tool.run(_request(WBIssueOutputRelationshipInput(plant_id="ASE99", start=start, end=end)))
    payload = PayloadRegistry.unpack(result.payload)

    assert payload.overlap_observed_days == 5
    assert payload.overlap_observed_days != 7
    assert any("overlap" in limitation.lower() or "partial" in limitation.lower() for limitation in payload.limitations)


def test_insufficient_overlap_never_fabricates_an_association():
    """Item 25: below MIN_OVERLAP_DAYS (2), direction_alignment must be
    INSUFFICIENT_DATA and both_declining must be None -- never a guessed
    SAME_DIRECTION/OPPOSITE_DIRECTION from a single overlapping day."""
    d = GOLDEN_DATE
    sync = datetime.combine(d, datetime.min.time()).replace(hour=8, tzinfo=timezone.utc)
    issue_ds = InMemoryWBIssueDataSource([_issue_record("ASE99", d, 100, sync)])
    output_ds = InMemoryWBStageOutputDataSource([_output_record("ASE99", d, 200, sync)])

    tool = AnalyzeWBIssueVsOutputTool(issue_ds, output_ds)
    result = tool.run(_request(WBIssueOutputRelationshipInput(plant_id="ASE99", start=d, end=d)))
    payload = PayloadRegistry.unpack(result.payload)

    assert payload.overlap_observed_days == 1
    assert payload.direction_alignment == WBDirectionAlignment.INSUFFICIENT_DATA
    assert payload.both_declining is None


def test_zero_overlap_when_sources_share_no_common_business_date():
    start, end = _WINDOW_START, GOLDEN_DATE
    sync = datetime.combine(end, datetime.min.time()).replace(hour=8, tzinfo=timezone.utc)
    issue_ds = InMemoryWBIssueDataSource([_issue_record("ASE99", start, 100, sync)])
    output_ds = InMemoryWBStageOutputDataSource([_output_record("ASE99", end, 200, sync)])  # a different day entirely

    tool = AnalyzeWBIssueVsOutputTool(issue_ds, output_ds)
    result = tool.run(_request(WBIssueOutputRelationshipInput(plant_id="ASE99", start=start, end=end)))
    payload = PayloadRegistry.unpack(result.payload)

    assert payload.overlap_observed_days == 0
    assert payload.direction_alignment == WBDirectionAlignment.INSUFFICIENT_DATA


def test_records_with_no_release_date_are_never_guessed_into_a_bucket():
    """`release_date` can be None (an unparseable `rel_date`) -- such rows
    must be skipped from the daily aggregation entirely, never assigned a
    fallback date."""
    d = GOLDEN_DATE
    sync = datetime.combine(d, datetime.min.time()).replace(hour=8, tzinfo=timezone.utc)
    unparseable = _issue_record("ASE99", None, 999, sync)
    issue_ds = InMemoryWBIssueDataSource([unparseable, _issue_record("ASE99", d, 100, sync)])
    output_ds = InMemoryWBStageOutputDataSource([_output_record("ASE99", d, 200, sync)])

    tool = AnalyzeWBIssueVsOutputTool(issue_ds, output_ds)
    result = tool.run(_request(WBIssueOutputRelationshipInput(plant_id="ASE99", start=d, end=d)))
    payload = PayloadRegistry.unpack(result.payload)

    assert payload.issue.current_value == 100.0  # the 999-quantity unparseable row never got summed in


# ============================================================================
# Direction alignment classification (descriptive only, item 21)
# ============================================================================


def test_same_direction_when_both_decline():
    days = [_WINDOW_START + timedelta(days=i) for i in range(7)]
    sync = datetime.combine(GOLDEN_DATE, datetime.min.time()).replace(hour=8, tzinfo=timezone.utc)
    issue_records = [_issue_record("ASE99", d, 100, sync) for d in days[:-1]] + [_issue_record("ASE99", days[-1], 20, sync)]
    output_records = [_output_record("ASE99", d, 200, sync) for d in days[:-1]] + [_output_record("ASE99", days[-1], 40, sync)]

    tool = AnalyzeWBIssueVsOutputTool(InMemoryWBIssueDataSource(issue_records), InMemoryWBStageOutputDataSource(output_records))
    result = tool.run(_request(WBIssueOutputRelationshipInput(plant_id="ASE99", start=days[0], end=days[-1])))
    payload = PayloadRegistry.unpack(result.payload)

    assert payload.issue.trend_direction == WBTrendDirection.DOWN
    assert payload.output.trend_direction == WBTrendDirection.DOWN
    assert payload.direction_alignment == WBDirectionAlignment.SAME_DIRECTION
    assert payload.both_declining is True


def test_opposite_direction_when_one_rises_and_the_other_falls():
    days = [_WINDOW_START + timedelta(days=i) for i in range(7)]
    sync = datetime.combine(GOLDEN_DATE, datetime.min.time()).replace(hour=8, tzinfo=timezone.utc)
    issue_records = [_issue_record("ASE99", d, 100, sync) for d in days[:-1]] + [_issue_record("ASE99", days[-1], 20, sync)]  # DOWN
    output_records = [_output_record("ASE99", d, 100, sync) for d in days[:-1]] + [_output_record("ASE99", days[-1], 500, sync)]  # UP

    tool = AnalyzeWBIssueVsOutputTool(InMemoryWBIssueDataSource(issue_records), InMemoryWBStageOutputDataSource(output_records))
    result = tool.run(_request(WBIssueOutputRelationshipInput(plant_id="ASE99", start=days[0], end=days[-1])))
    payload = PayloadRegistry.unpack(result.payload)

    assert payload.direction_alignment == WBDirectionAlignment.OPPOSITE_DIRECTION
    assert payload.both_declining is False


def test_both_declining_is_false_when_alignment_is_same_direction_but_both_rising():
    days = [_WINDOW_START + timedelta(days=i) for i in range(7)]
    sync = datetime.combine(GOLDEN_DATE, datetime.min.time()).replace(hour=8, tzinfo=timezone.utc)
    issue_records = [_issue_record("ASE99", d, 100, sync) for d in days[:-1]] + [_issue_record("ASE99", days[-1], 500, sync)]  # UP
    output_records = [_output_record("ASE99", d, 100, sync) for d in days[:-1]] + [_output_record("ASE99", days[-1], 500, sync)]  # UP

    tool = AnalyzeWBIssueVsOutputTool(InMemoryWBIssueDataSource(issue_records), InMemoryWBStageOutputDataSource(output_records))
    result = tool.run(_request(WBIssueOutputRelationshipInput(plant_id="ASE99", start=days[0], end=days[-1])))
    payload = PayloadRegistry.unpack(result.payload)

    assert payload.direction_alignment == WBDirectionAlignment.SAME_DIRECTION
    assert payload.both_declining is False  # same direction, but NOT declining


# ============================================================================
# No causal inflation (item 21/29/47) -- structural + wording guarantees.
# ============================================================================


def test_result_model_has_no_causal_fields_at_all():
    """Structural guarantee: `WBIssueOutputRelationshipResult` has no
    `causal`/`cause_strength`/estimated-effect field for any wording bug
    to ever accidentally populate."""
    field_names = set(WBIssueOutputRelationshipResult.model_fields.keys())
    for forbidden in ("causal", "cause_strength", "causal_effect", "root_cause", "is_root_cause"):
        assert forbidden not in field_names


def test_association_statement_never_uses_causal_language_same_direction_case():
    tool = AnalyzeWBIssueVsOutputTool(*_real_datasources())
    result = tool.run(_request(WBIssueOutputRelationshipInput(plant_id=SCENARIO_B_PLANT, start=_WINDOW_START, end=GOLDEN_DATE)))
    payload = PayloadRegistry.unpack(result.payload)

    statement_lower = payload.association_statement.lower()
    for forbidden in _FORBIDDEN_CAUSAL_WORDS:
        assert forbidden not in statement_lower
    assert result.summary == payload.association_statement  # summary must be the same descriptive text, not embellished


def test_golden_scenario_b_both_declining_same_direction_descriptive_only():
    """Item 30/B: ASE07's own worked example -- Issue trend persistent low
    + Output trend low + cross-source both declining -> supported
    descriptive association, NEVER a causal claim ("ISSUE低造成OUTPUT低" is
    explicitly forbidden by the phase's own Final Invariants)."""
    tool = AnalyzeWBIssueVsOutputTool(*_real_datasources())
    result = tool.run(_request(WBIssueOutputRelationshipInput(plant_id=SCENARIO_B_PLANT, start=_WINDOW_START, end=GOLDEN_DATE)))
    payload = PayloadRegistry.unpack(result.payload)

    assert payload.issue.trend_direction == WBTrendDirection.DOWN
    assert payload.output.trend_direction == WBTrendDirection.DOWN
    assert payload.direction_alignment == WBDirectionAlignment.SAME_DIRECTION
    assert payload.both_declining is True
    assert "same direction" in payload.association_statement.lower()
    for forbidden in _FORBIDDEN_CAUSAL_WORDS:
        assert forbidden not in payload.association_statement.lower()


def test_normal_plant_never_shows_a_fabricated_association():
    """ASE02 (normal-plant control) should not be misclassified as having
    a strong same-direction decline association."""
    tool = AnalyzeWBIssueVsOutputTool(*_real_datasources())
    result = tool.run(_request(WBIssueOutputRelationshipInput(plant_id=SCENARIO_D_PLANT, start=_WINDOW_START, end=GOLDEN_DATE)))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.both_declining is not True


# ============================================================================
# Tool metadata (item 53/54) -- READ_ONLY, deterministic.
# ============================================================================


def test_tool_definition_is_read_only_and_deterministic():
    tool = AnalyzeWBIssueVsOutputTool(*_real_datasources())
    assert tool.definition.side_effect.value == "read_only"
    assert tool.definition.execution_type.value == "deterministic"


def test_datasource_error_maps_to_structured_error_result_not_raised():
    from agent.domain.wb.errors import WBDataSourceUnavailableError

    class _BrokenIssueDataSource:
        def list_issue(self, *, sync_date=None):
            raise WBDataSourceUnavailableError("simulated outage")

        def freshness(self):
            from agent.domain.wb.models import WB_ISSUE_FRESHNESS

            return WB_ISSUE_FRESHNESS

    _, output_ds = _real_datasources()
    tool = AnalyzeWBIssueVsOutputTool(_BrokenIssueDataSource(), output_ds)
    result = tool.run(_request(WBIssueOutputRelationshipInput(plant_id=SCENARIO_B_PLANT, start=_WINDOW_START, end=GOLDEN_DATE)))
    assert result.status == ObservationStatus.ERROR
