"""Phase 4B-2: Module Execution Gate Permission interrupt/resume.

Human is only ever raised here for PERMISSION_REQUIRED (Execution Gate),
using the native LangGraph interrupt()/Command(resume=...) mechanism
confirmed safe in Phase 4B-1 (explicit shared checkpointer + config
passthrough). No Synthesis/Evaluator/Learning, no real domain policy.
"""
from datetime import datetime, timezone

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command

from agent.graph.graph import build_phase2_graph
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.planning.policies.mock import DeterministicMockPolicy, PermissionSpec, Requirement
from agent.state.enums import (
    EvidenceQuality,
    HumanDecision,
    HumanReason,
    HumanRequestStatus,
    ModuleStatus,
    ObjectiveStatus,
    ObservationStatus,
    ReflectorVerdict,
    RiskLevel,
    RunTerminationStatus,
)
from agent.state.models import HumanRequest, HumanResponse, ModuleState, ResumeTarget
from agent.state.state import AgentState
from agent.tools.base import ToolResult
from agent.tools.mocks.scripted_tool import ScriptedMockTool

from .conftest import make_agent_state, make_budget


_EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)


def _drop_tool_call_timestamps(module_state: ModuleState) -> ModuleState:
    """Normalizes away ToolCallRecord.started_at/completed_at/duration_seconds
    and the module's own started_at/completed_at (Phase 8A-1) for equality
    comparisons -- see the sibling-re-execution note where this is used.
    Module lifecycle timestamps are stamped fresh on every physical
    invocation of module_subgraph_node/module_completion_check (Phase
    8A-1), so they carry exactly the same "legitimately differs under a
    Send-level replay" caveat as ToolCallRecord's timestamps already do."""
    return module_state.model_copy(
        update={
            "tool_calls": [
                tc.model_copy(update={"started_at": _EPOCH, "completed_at": _EPOCH, "duration_seconds": 0.0})
                for tc in module_state.tool_calls
            ],
            "started_at": _EPOCH,
            "completed_at": _EPOCH,
        }
    )


def _normal_runtime(sources=("primary",)) -> ModuleRuntimeConfig:
    return ModuleRuntimeConfig(
        policy=DeterministicMockPolicy(sources=list(sources), sufficiency_evidence_count=1),
        tool=ScriptedMockTool(
            {s: ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG) for s in sources}
        ),
        budget=make_budget(max_steps=3, max_tool_calls=3, max_depth_per_entity=2),
    )


def _human_request_from_interrupt(payload: dict, request_id: str) -> HumanRequest:
    return HumanRequest(
        request_id=request_id,
        run_id=payload["run_id"],
        module_id=payload["module_id"],
        branch_id=payload["branch_id"],
        objective_id=payload["objective_id"],
        source_node=payload["source_node"],
        reason=HumanReason(payload["reason"]),
        question=payload["question"],
        options=payload["options"],
        permission_type=payload["permission_type"],
        risk_level=RiskLevel(payload["risk_level"]) if payload["risk_level"] else None,
        resume_target=ResumeTarget(module_id=payload["module_id"], node="execution_gate", objective_id=payload["objective_id"]),
        status=HumanRequestStatus.PENDING,
        created_at_step=0,
    )


# ============================================================================
# Case A -- Permission APPROVE
# ============================================================================


def _module_runtime_case_a() -> dict[str, ModuleRuntimeConfig]:
    return {
        "OEE": ModuleRuntimeConfig(
            policy=DeterministicMockPolicy(
                requirements=[
                    Requirement(
                        sources=["restricted"],
                        sufficiency_evidence_count=1,
                        restricted_sources={
                            "restricted": PermissionSpec(permission_type="maintenance_db_access", risk_level=RiskLevel.HIGH)
                        },
                    )
                ]
            ),
            tool=ScriptedMockTool(
                {"restricted": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}
            ),
            budget=make_budget(max_steps=3, max_tool_calls=3, max_depth_per_entity=2),
        ),
        "Output": _normal_runtime(),
        "WIP": _normal_runtime(),
    }


def test_case_a_approve_resumes_oee_output_wip_semantically_unchanged():
    """Renamed from `..._others_untouched` (Phase 5B-1.1 correction): this
    test's own `update_state()` call means Output/WIP are NOT literally
    untouched -- see the note at assertion #8 below and
    test_resume_replay_semantics.py for the precise, physically-measured
    claim."""
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(_module_runtime_case_a(), checkpointer)
    app = graph.compile(checkpointer=checkpointer)

    initial_state = make_agent_state()
    config = {"configurable": {"thread_id": initial_state.run_id}}

    result1 = app.invoke(initial_state, config=config)

    # 1 & 3: OEE is recognizably interrupted, with a full HumanRequest-shaped payload
    assert "__interrupt__" in result1
    interrupts = result1["__interrupt__"]
    assert len(interrupts) == 1
    payload = interrupts[0].value
    assert payload["run_id"] == initial_state.run_id
    assert payload["module_id"] == "OEE"
    assert payload["branch_id"] is None
    assert payload["objective_id"] == "OEE-obj-1"
    assert payload["source_node"] == "execution_gate"
    assert payload["reason"] == HumanReason.PERMISSION_REQUIRED.value
    assert payload["permission_type"] == "maintenance_db_access"
    assert payload["risk_level"] == RiskLevel.HIGH.value

    # 4: Output/WIP already finished within the SAME first invoke, OEE absent
    mid_values = app.get_state(config).values
    assert "OEE" not in mid_values["module_states"]
    assert mid_values["module_states"]["Output"].status == ModuleStatus.COMPLETE
    assert mid_values["module_states"]["WIP"].status == ModuleStatus.COMPLETE
    output_before = mid_values["module_states"]["Output"]
    wip_before = mid_values["module_states"]["WIP"]

    # simulate a RunController materializing + auditing the pending HumanRequest
    request_id = str(interrupts[0].id)
    human_request = _human_request_from_interrupt(payload, request_id)
    app.update_state(config, {"human_requests": {request_id: human_request}})

    # 11 (pending half): visible in state/checkpoint audit
    audited_pending = app.get_state(config).values["human_requests"][request_id]
    assert audited_pending.status == HumanRequestStatus.PENDING

    # 12 & 5: process-style resume -- a brand-new compiled graph object, only
    # sharing the checkpointer + thread_id, not any in-memory Python state
    graph2 = build_phase2_graph(_module_runtime_case_a(), checkpointer)
    app2 = graph2.compile(checkpointer=checkpointer)
    result2 = app2.invoke(
        Command(resume={"decision": HumanDecision.APPROVE.value, "responded_by": "tester"}), config=config
    )
    final_state = AgentState.model_validate(result2)

    # 6, 7, 9: OEE resumed, went through Executor, reached Reflector/Completion.
    # ("only OEE" is deliberately not claimed here -- see the note below.)
    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.COMPLETE
    assert len(oee.observations) == 1
    assert oee.observations[0].status == ObservationStatus.SUCCESS
    assert oee.reflection_history[-1].verdict == ReflectorVerdict.CANDIDATE_COMPLETE
    assert oee.objective_history["OEE-obj-1"].status == ObjectiveStatus.COMPLETED

    # 8: Output/WIP's already-completed state is unchanged in *content* --
    # this we can and do claim. What we deliberately do NOT claim here is
    # "Output/WIP are not re-executed": this test calls `update_state()`
    # (line 146) between interrupt and resume, and Phase 5B-1.1 pinned that
    # down precisely -- `update_state()` on a checkpoint with a still-
    # pending Send task causes EVERY task in that pending superstep to
    # re-run on the next resume, siblings included, not just the
    # interrupted branch. Without an intervening `update_state()` call,
    # siblings genuinely are not re-executed (see
    # tests/test_resume_replay_semantics.py, which measures physical
    # execution counts directly instead of comparing state). Re-execution
    # here is idempotent -- same inputs, same outputs -- except for
    # ToolCallRecord's wall-clock timestamps, which legitimately differ.
    assert _drop_tool_call_timestamps(final_state.module_states["Output"]) == _drop_tool_call_timestamps(output_before)
    assert _drop_tool_call_timestamps(final_state.module_states["WIP"]) == _drop_tool_call_timestamps(wip_before)

    # 2 & 10: fan-in still reaches READY_FOR_SYNTHESIS
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS

    # 11 (resolved half)
    resolved = human_request.model_copy(
        update={
            "status": HumanRequestStatus.RESOLVED,
            "response": HumanResponse(
                decision=HumanDecision.APPROVE, responded_by="tester", responded_at=datetime(2026, 8, 9, tzinfo=timezone.utc)
            ),
        }
    )
    app2.update_state(config, {"human_requests": {request_id: resolved}})
    audited_resolved = app2.get_state(config).values["human_requests"][request_id]
    assert audited_resolved.status == HumanRequestStatus.RESOLVED
    assert audited_resolved.response.decision == HumanDecision.APPROVE


def test_case_a_oee_child_checkpoint_exists_while_interrupted():
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(_module_runtime_case_a(), checkpointer)
    app = graph.compile(checkpointer=checkpointer)
    initial_state = make_agent_state()
    config = {"configurable": {"thread_id": initial_state.run_id}}
    app.invoke(initial_state, config=config)

    entries = list(checkpointer.list({"configurable": {"thread_id": initial_state.run_id}}))
    module_namespaces = {e.config["configurable"].get("checkpoint_ns", "") for e in entries if e.config["configurable"].get("checkpoint_ns", "").startswith("module_subgraph:")}
    # exactly one nested module namespace exists yet -- OEE's (paused);
    # Output/WIP finished and folded back into the parent's own channel, not
    # left behind as a separate lingering child checkpoint namespace entry
    # with RUNNING status.
    found_running_oee = False
    for e in entries:
        ns = e.config["configurable"].get("checkpoint_ns", "")
        if not ns.startswith("module_subgraph:"):
            continue
        values = e.checkpoint.get("channel_values", {})
        if values.get("module_id") == "OEE":
            found_running_oee = True
            assert values.get("status") == ModuleStatus.RUNNING
    assert found_running_oee, "expected OEE's paused child checkpoint to exist and be inspectable"


# ============================================================================
# Case B1 -- Permission REJECT, alternative exists
# ============================================================================


def _module_runtime_case_b1() -> dict[str, ModuleRuntimeConfig]:
    return {
        "OEE": ModuleRuntimeConfig(
            policy=DeterministicMockPolicy(
                requirements=[
                    Requirement(
                        sources=["restricted", "approved-alt"],
                        sufficiency_evidence_count=1,
                        restricted_sources={
                            "restricted": PermissionSpec(permission_type="maintenance_db_access", risk_level=RiskLevel.HIGH)
                        },
                    )
                ]
            ),
            tool=ScriptedMockTool(
                {
                    "restricted": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="should never run", quality=EvidenceQuality.STRONG),
                    "approved-alt": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.MODERATE),
                }
            ),
            budget=make_budget(max_steps=4, max_tool_calls=4, max_depth_per_entity=2),
        ),
        "Output": _normal_runtime(),
        "WIP": _normal_runtime(),
    }


def test_case_b1_reject_with_alternative_completes_via_planner_not_blocked():
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(_module_runtime_case_b1(), checkpointer)
    app = graph.compile(checkpointer=checkpointer)
    initial_state = make_agent_state()
    config = {"configurable": {"thread_id": initial_state.run_id}}

    app.invoke(initial_state, config=config)
    result2 = app.invoke(Command(resume={"decision": HumanDecision.REJECT.value, "responded_by": "tester"}), config=config)
    final_state = AgentState.model_validate(result2)

    oee = final_state.module_states["OEE"]
    # module is NOT blocked by a single reject -- Planner found an alternative
    assert oee.status in (ModuleStatus.COMPLETE, ModuleStatus.PARTIAL)
    assert oee.status != ModuleStatus.BLOCKED

    # rejected objective closed out correctly, never reached Executor
    assert oee.objective_history["OEE-obj-1"].status == ObjectiveStatus.REJECTED
    assert oee.objective_history["OEE-obj-1"].termination_reason == "human_rejected_permission"
    assert len(oee.rejections) == 1
    assert oee.rejections[0].alternative_found is True

    # the alternative objective is what actually ran
    assert len(oee.observations) == 1
    assert oee.observations[0].tool_name == "mock_tool:approved-alt"
    assert oee.objective_history["OEE-obj-2"].status == ObjectiveStatus.COMPLETED

    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


# ============================================================================
# Case B2 -- Permission REJECT, no alternative -> BLOCKED
# ============================================================================


def _module_runtime_case_b2() -> dict[str, ModuleRuntimeConfig]:
    return {
        "OEE": ModuleRuntimeConfig(
            policy=DeterministicMockPolicy(
                requirements=[
                    Requirement(
                        sources=["restricted-only"],
                        sufficiency_evidence_count=1,
                        restricted_sources={
                            "restricted-only": PermissionSpec(permission_type="maintenance_db_access", risk_level=RiskLevel.HIGH)
                        },
                    )
                ]
            ),
            tool=ScriptedMockTool(
                {"restricted-only": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="should never run", quality=EvidenceQuality.STRONG)}
            ),
            budget=make_budget(max_steps=4, max_tool_calls=4, max_depth_per_entity=2),
        ),
        "Output": _normal_runtime(),
        "WIP": _normal_runtime(),
    }


def test_case_b2_reject_with_no_alternative_reaches_blocked():
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(_module_runtime_case_b2(), checkpointer)
    app = graph.compile(checkpointer=checkpointer)
    initial_state = make_agent_state()
    config = {"configurable": {"thread_id": initial_state.run_id}}

    app.invoke(initial_state, config=config)
    result2 = app.invoke(Command(resume={"decision": HumanDecision.REJECT.value, "responded_by": "tester"}), config=config)
    final_state = AgentState.model_validate(result2)

    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.BLOCKED
    assert oee.findings == []  # never executed anything
    assert oee.observations == []

    assert oee.objective_history["OEE-obj-1"].status == ObjectiveStatus.REJECTED
    assert len(oee.rejections) == 1
    assert oee.rejections[0].alternative_found is False

    assert len(oee.limitations) == 1
    assert "maintenance_db_access" in oee.limitations[0].description

    # sibling modules are unaffected by OEE being BLOCKED
    assert final_state.module_states["Output"].status == ModuleStatus.COMPLETE
    assert final_state.module_states["WIP"].status == ModuleStatus.COMPLETE
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


def test_final_states_round_trip_through_json():
    for runtime in (_module_runtime_case_a(), _module_runtime_case_b1(), _module_runtime_case_b2()):
        checkpointer = InMemorySaver()
        graph = build_phase2_graph(runtime, checkpointer)
        app = graph.compile(checkpointer=checkpointer)
        initial_state = make_agent_state()
        config = {"configurable": {"thread_id": initial_state.run_id}}
        app.invoke(initial_state, config=config)
        result = app.invoke(Command(resume={"decision": HumanDecision.APPROVE.value}), config=config)
        final_state = AgentState.model_validate(result)
        restored = AgentState.model_validate_json(final_state.model_dump_json())
        assert restored == final_state
