"""Phase 5B-3A: ModuleRegistry -- the high-level Module capability catalog
Analyzer reads instead of a prompt-hardcoded module list."""
import pytest

from agent.catalog.module_registry import (
    DuplicateModuleDefinitionError,
    ModuleDefinition,
    ModuleDefinitionNotFoundError,
    ModuleRegistry,
)
from agent.state.enums import TaskType
from agent.state.models import FactoryContext

from .conftest import make_module_registry


def _definition(module_type: str, enabled: bool = True) -> ModuleDefinition:
    return ModuleDefinition(
        module_type=module_type,
        name=module_type,
        description=f"{module_type} test definition",
        supported_task_types=[TaskType.RCA],
        enabled=enabled,
    )


def test_register_get_list():
    registry = ModuleRegistry()
    registry.register(_definition("OEE"))
    registry.register(_definition("WIP"))

    assert registry.get("OEE").module_type == "OEE"
    assert {d.module_type for d in registry.list()} == {"OEE", "WIP"}


def test_duplicate_module_type_rejected():
    registry = ModuleRegistry()
    registry.register(_definition("OEE"))
    with pytest.raises(DuplicateModuleDefinitionError):
        registry.register(_definition("OEE"))


def test_missing_module_raises_typed_error():
    registry = ModuleRegistry()
    with pytest.raises(ModuleDefinitionNotFoundError):
        registry.get("does-not-exist")


def test_available_for_filters_by_factory_enabled_modules_and_enabled_flag():
    registry = ModuleRegistry()
    registry.register(_definition("OEE"))
    registry.register(_definition("Output"))
    registry.register(_definition("WIP", enabled=False))  # disabled at catalog level

    factory = FactoryContext(factory_id="f1", factory_name="Factory 1", enabled_modules=["OEE", "WIP"])
    available = {d.module_type for d in registry.available_for(factory)}

    # WIP is in the factory's enabled_modules but disabled at catalog level -> excluded
    # Output is enabled at catalog level but not in this factory's enabled_modules -> excluded
    assert available == {"OEE"}


def test_real_oee_output_wip_catalog_contents():
    registry = make_module_registry()
    module_types = {d.module_type for d in registry.list()}
    assert module_types == {"OEE", "Output", "WIP"}
    for definition in registry.list():
        assert set(definition.supported_task_types) == {TaskType.INFORMATION, TaskType.ANALYSIS, TaskType.RCA}
        assert definition.key_questions
