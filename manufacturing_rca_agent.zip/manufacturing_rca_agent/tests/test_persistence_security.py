﻿"""Phase 8A items 23.H/23.I: persisted LLM/context audit records never
carry a full prompt, and persisted config never carries a raw secret
value (only the environment-variable *name* that would hold one) --
plus RunPersistenceWriter's own raw-tool-payload redaction default.
"""
from datetime import datetime, timezone

from agent.datasource.models import DataSourceConfig, DataSourceType
from agent.llm.models import LLMCallRecord, LLMCallStatus
from agent.llm.context.context_audit import ContextBuildRecord
from agent.persistence.audit_repository import build_default_audit_repository
from agent.persistence.human_feedback import InMemoryHumanFeedbackSink
from agent.persistence.learning_repository import LearningCandidateRepository
from agent.persistence.run_repository import InMemoryRunRepository
from agent.persistence.run_writer import RunPersistenceWriter
from agent.learning.sink import InMemoryLearningCandidateSink
from agent.state.enums import EvidenceQuality, ObjectiveAction, ObjectiveStatus, TargetRefType, TaskType
from agent.state.models import AnalysisSpace, Evidence, ModuleGoal, ModuleState, ObjectiveRecord, SuccessCriteria, TargetRef
from agent.state.payload import StructuredPayload

from .conftest import make_agent_state, make_analysis_tree, make_budget


def _now():
    return datetime.now(timezone.utc)


# ============================================================================
# H. No raw prompt
# ============================================================================


def test_llm_call_record_has_no_prompt_field_at_all():
    """Structural, not behavioral -- LLMCallRecord (agent/llm/models.py)
    was never given a prompt/response text field in the first place (Phase
    5B-3A onward); there is nothing to redact because it was never
    collectable."""
    assert "prompt" not in LLMCallRecord.model_fields
    assert "response" not in LLMCallRecord.model_fields
    assert "messages" not in LLMCallRecord.model_fields


def test_context_build_record_has_no_rendered_context_field():
    assert "context" not in ContextBuildRecord.model_fields
    assert "prompt" not in ContextBuildRecord.model_fields
    # only counts/sizes are recorded, per its own docstring
    assert "estimated_context_characters" in ContextBuildRecord.model_fields


def test_real_llm_call_record_round_trips_through_audit_repository_without_prompt_content():
    audit_repo = build_default_audit_repository()
    record = LLMCallRecord(
        llm_call_id="call-1", run_id="run-1", module_id="OEE", node="module_planner", route="planner",
        model="mock-planner-v1", input_tokens=120, output_tokens=40, latency_ms=250.0, status=LLMCallStatus.SUCCESS,
        started_at=_now(), completed_at=_now(),
    )
    audit_repo.llm_usage_sink.record(record)
    stored = audit_repo.llm_usage_sink.list_for_run("run-1")[0]
    assert stored.model_dump().keys() == record.model_dump().keys()  # exactly the declared fields -- no smuggled prompt text


# ============================================================================
# I. No secret value -- only the env-var name
# ============================================================================


def test_datasource_config_never_has_a_secret_value_field():
    config = DataSourceConfig(name="manufacturing_db", type=DataSourceType.REMOTE_SQL, endpoint_env="DB_ENDPOINT", credential_env="DB_TOKEN")
    dumped = config.model_dump()
    assert dumped["credential_env"] == "DB_TOKEN"  # the env var *name*
    assert "credential" not in dumped
    assert "password" not in dumped
    assert "secret" not in dumped
    assert "token" not in {k for k in dumped}  # no field literally named "token" either


# ============================================================================
# RunPersistenceWriter's own default redaction
# ============================================================================


def _module_state_with_structured_evidence() -> ModuleState:
    from agent.state.payload import PayloadRegistry
    from agent.state.base import RCABaseModel

    class _DummyPayload(RCABaseModel):
        value: str

    PayloadRegistry.register("test.persistence_dummy", _DummyPayload)

    evidence = Evidence(
        evidence_id="ev1", objective_id="o1", source_tool="query_oee_data", summary="raw data summary",
        quality=EvidenceQuality.STRONG, structured_payload=StructuredPayload(payload_type="test.persistence_dummy", data={"value": "sensitive-looking-raw-value"}),
    )
    return ModuleState(
        module_id="OEE", module_type="OEE", run_id="run-1",
        goal=ModuleGoal(module_id="OEE", statement="g", task_type=TaskType.RCA, success_criteria=SuccessCriteria(min_evidence_quality=EvidenceQuality.MODERATE, root_cause_coverage_threshold=0.5)),
        analysis_space=AnalysisSpace(root_dimension="OEE", dimensions={}),
        analysis_tree=make_analysis_tree("OEE"), budget=make_budget(),
        objective_history={"o1": ObjectiveRecord(objective_id="o1", description="d", action=ObjectiveAction.SUMMARIZE, target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="OEE"), status=ObjectiveStatus.COMPLETED, created_step=1, attempt_count=1)},
        evidence=[evidence],
    )


def test_raw_tool_payload_is_redacted_by_default():
    run_repo = InMemoryRunRepository()
    audit_repo = build_default_audit_repository()
    writer = RunPersistenceWriter(run_repo, audit_repo, InMemoryHumanFeedbackSink(), LearningCandidateRepository(InMemoryLearningCandidateSink()))

    state = make_agent_state(run_id="run-1").model_copy(update={"module_states": {"OEE": _module_state_with_structured_evidence()}})
    writer.persist_run(state)

    stored = run_repo.list_evidence("run-1")[0]
    assert stored.structured_payload is None  # redacted -- save_raw_tool_payload defaults to False
    assert stored.payload_type == "test.persistence_dummy"  # the type name alone is kept -- not sensitive


def test_raw_tool_payload_kept_when_explicitly_opted_in():
    from agent.persistence.settings import PersistenceSettings

    run_repo = InMemoryRunRepository()
    audit_repo = build_default_audit_repository()
    writer = RunPersistenceWriter(
        run_repo, audit_repo, InMemoryHumanFeedbackSink(), LearningCandidateRepository(InMemoryLearningCandidateSink()),
        settings=PersistenceSettings(save_raw_tool_payload=True),
    )

    state = make_agent_state(run_id="run-1").model_copy(update={"module_states": {"OEE": _module_state_with_structured_evidence()}})
    writer.persist_run(state)

    stored = run_repo.list_evidence("run-1")[0]
    assert stored.structured_payload == {"value": "sensitive-looking-raw-value"}
