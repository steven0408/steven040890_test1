import pytest
from pydantic import ValidationError

from agent.planning.priority import DefaultRulePriorityScorer, PriorityInputs


def test_default_rule_scorer_matches_formula():
    inputs = PriorityInputs(
        abnormality=0.9,
        contribution=0.8,
        business_impact=0.7,
        evidence_strength=0.6,
        data_availability=1.0,
        analysis_cost=2.0,
    )
    score = DefaultRulePriorityScorer().score(inputs)
    expected = (0.9 * 0.8 * 0.7 * 0.6 * 1.0) / 2.0
    assert score == pytest.approx(expected)


def test_analysis_cost_must_be_positive():
    with pytest.raises(ValidationError):
        PriorityInputs(
            abnormality=0.5,
            contribution=0.5,
            business_impact=0.5,
            evidence_strength=0.5,
            data_availability=0.5,
            analysis_cost=0,
        )
