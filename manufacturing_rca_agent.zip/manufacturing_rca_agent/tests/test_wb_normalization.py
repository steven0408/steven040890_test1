"""Phase "WB Real Data Onboarding" item 21: raw response-shape and
missing-value normalization.
"""
import math

import pytest

from agent.domain.wb.errors import WBDataNormalizationError
from agent.domain.wb.normalization import normalize_api_rows, normalize_missing_value, normalize_row_missing_values, normalize_rows


def test_columns_oriented_dict_normalizes_to_records():
    raw = {"DATE": {"0": "2022-01-01", "1": "2022-01-01"}, "OEE": {"0": 80.0, "1": 70.0}}
    assert normalize_api_rows(raw) == [{"DATE": "2022-01-01", "OEE": 80.0}, {"DATE": "2022-01-01", "OEE": 70.0}]


def test_records_array_passes_through_unchanged():
    raw = [{"A": 1}, {"A": 2}]
    assert normalize_api_rows(raw) is raw


def test_empty_dict_normalizes_to_empty_list():
    assert normalize_api_rows({}) == []


def test_empty_list_normalizes_to_empty_list():
    assert normalize_api_rows([]) == []


def test_none_normalizes_to_empty_list():
    assert normalize_api_rows(None) == []


def test_unsupported_shape_raises_typed_error():
    with pytest.raises(WBDataNormalizationError):
        normalize_api_rows("not a dict or list")


def test_missing_value_empty_string_becomes_none():
    assert normalize_missing_value("") is None


def test_missing_value_nan_becomes_none():
    assert normalize_missing_value(float("nan")) is None
    assert normalize_missing_value(math.nan) is None


def test_missing_value_none_stays_none():
    assert normalize_missing_value(None) is None


def test_zero_is_never_treated_as_missing():
    assert normalize_missing_value(0) == 0
    assert normalize_missing_value(0.0) == 0.0
    assert normalize_missing_value(False) is False


def test_normal_values_pass_through():
    assert normalize_missing_value("ASE01") == "ASE01"
    assert normalize_missing_value(42) == 42


def test_normalize_row_missing_values_applies_to_every_field():
    row = {"a": "", "b": 0, "c": float("nan"), "d": "keep"}
    assert normalize_row_missing_values(row) == {"a": None, "b": 0, "c": None, "d": "keep"}


def test_normalize_rows_combines_shape_and_missing_value_normalization():
    raw = {"A": {"0": "", "1": "x"}, "B": {"0": 0, "1": float("nan")}}
    assert normalize_rows(raw) == [{"A": None, "B": 0}, {"A": "x", "B": None}]
