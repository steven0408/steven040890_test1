"""Phase PROD-1: FastAPI route-level tests via TestClient -- exercises the
real `agent_api.main.app`, real lifespan (startup wiring), real routes.
`build_llm_client` is monkeypatched at its `agent_api.service` import site
to return a MockLLMClient (the production `LLM_PROVIDER=mock` guard itself
-- `build_llm_client` requiring an explicit `mock_responder=` -- is left
completely untouched; this is a test-only substitution proving the FULL
app wiring works end to end, not a weakening of that guard)."""
import pytest
from fastapi.testclient import TestClient

from agent.llm.client import MockLLMClient
from agent.llm.prompts.analyzer import AnalyzerDecision, ModuleSelection
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.llm.prompts.reflector import ObjectiveAssessment, ReflectionDecision, ReflectionVerdict
from agent.llm.prompts.standardizer import StandardizerExtraction
from agent.llm.prompts.synthesis import SynthesisDraft
from agent.domain.wb.synthetic import GOLDEN_DATE
from agent.state.enums import ObjectiveAction, TargetRefType, TaskType
from agent.state.models import TargetRef
from agent.state.scope import ObjectiveScope, TimeScope, TimeScopeKind

_GOAL_TEXT = "Compare WB output across plants."


def _mock_responder(request):
    if request.route == "standardizer":
        return StandardizerExtraction(normalized_text=_GOAL_TEXT, plant_id=None, time=None, constraints=[], reasoning_summary="test")
    if request.route == "analyzer":
        return AnalyzerDecision(
            task_type=TaskType.ANALYSIS, confidence=0.9, reasoning_summary="test",
            selected_modules=[ModuleSelection(module_type="WB", priority=0.9, confidence=0.9, rationale="test", goal_statement=_GOAL_TEXT)],
        )
    if request.route == "planner":
        return PlannerDecision(
            decision=PlannerDecisionType.DISPATCH,
            next_objective=ObjectiveProposal(
                action=ObjectiveAction.COMPARE, capability_key="wb.output.comparison",
                target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="WB"),
                scope=ObjectiveScope(time=TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, date=GOLDEN_DATE)),
                description="Compare WB output across plants.", expected_output="ranked comparison",
            ),
            priority=0.9, rationale_summary="test",
        )
    if request.route == "reflector":
        return ReflectionDecision(
            verdict=ReflectionVerdict.SUPPORTS, objective_assessment=ObjectiveAssessment.SATISFIED,
            should_continue=False, rationale_summary="test",
        )
    if request.route == "synthesis":
        return SynthesisDraft(executive_summary="WB output comparison complete.")
    raise AssertionError(f"unexpected route: {request.route}")


@pytest.fixture()
def client(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "mock")
    monkeypatch.setenv("AGENT_ENABLED_MODULES", "WB")
    monkeypatch.setattr("agent_api.service.build_llm_client", lambda config: MockLLMClient(_mock_responder))

    from agent_api.main import app

    with TestClient(app) as test_client:
        yield test_client


def test_health_endpoint(client):
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "healthy"
    assert body["llm_profile"] == "mock"
    assert "runtime_db_logging" in body
    assert "wb_remote_datasource_configured" in body
    # never leaks a credential/connection-string-shaped value
    assert "password" not in str(body).lower()


def test_ready_endpoint_reports_mock_llm(client):
    response = client.get("/ready")
    assert response.status_code == 200
    body = response.json()
    assert body["ready"] is False
    assert any("mock" in r.lower() for r in body["reasons"])


def test_analyze_prompt_mode_returns_markdown(client):
    response = client.post("/api/agent/v1/analyze", json={"prompt": "Compare WB output across plants."})
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/markdown")
    assert len(response.text) > 0


def test_analyze_json_format_mode(client):
    response = client.post("/api/agent/v1/analyze?format=json", json={"prompt": "Compare WB output across plants."})
    assert response.status_code == 200
    body = response.json()
    assert "run_id" in body and "markdown" in body and "status" in body and "module_statuses" in body


def test_analyze_structured_request_mode(client):
    response = client.post("/api/agent/v1/analyze", json={"request": {"raw_text": "Compare WB output across plants."}})
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/markdown")


def test_analyze_rejects_both_prompt_and_request(client):
    response = client.post("/api/agent/v1/analyze", json={"prompt": "x", "request": {"raw_text": "y"}})
    assert response.status_code == 422


def test_analyze_rejects_neither_prompt_nor_request(client):
    response = client.post("/api/agent/v1/analyze", json={})
    assert response.status_code == 422


def test_analyze_honors_explicit_run_id(client):
    response = client.post("/api/agent/v1/analyze?format=json", json={"prompt": "test", "run_id": "http-explicit-run-id"})
    assert response.status_code == 200
    assert response.json()["run_id"] == "http-explicit-run-id"


def test_run_events_lookup_without_configured_db_is_empty_not_error(client):
    """Honest, by-design behavior: no AGENT_RUNTIME_DB_URL means the only
    sink is StdoutRuntimeEventSink, which is deliberately not queryable
    (stdout is not a database) -- see runtime_events.py's own docstring.
    The endpoint itself must still respond cleanly, not error."""
    analyze_response = client.post("/api/agent/v1/analyze?format=json", json={"prompt": "test", "run_id": "http-events-run"})
    run_id = analyze_response.json()["run_id"]
    events_response = client.get(f"/api/agent/v1/runs/{run_id}/events")
    assert events_response.status_code == 200
    body = events_response.json()
    assert body["run_id"] == run_id
    assert body["events"] == []


def test_run_events_lookup_with_durable_sink_returns_events(client):
    """Proves the lookup path itself works once a durable (here: InMemory,
    standing in for Postgres) sink is present -- swaps the sink via the
    real app.state after construction, same seam a real deployment's
    Postgres-configured sink would occupy."""
    from agent_api.runtime_events import InMemoryRuntimeEventSink

    client.app.state.event_sink = InMemoryRuntimeEventSink()
    client.app.state.agent_service._event_sink = client.app.state.event_sink

    analyze_response = client.post("/api/agent/v1/analyze?format=json", json={"prompt": "test", "run_id": "http-events-durable-run"})
    run_id = analyze_response.json()["run_id"]
    events_response = client.get(f"/api/agent/v1/runs/{run_id}/events")
    body = events_response.json()
    assert len(body["events"]) > 0
    assert any(e["event_type"] == "run_completed" for e in body["events"])


def test_run_events_lookup_unknown_run_returns_empty_not_error(client):
    response = client.get("/api/agent/v1/runs/never-existed/events")
    assert response.status_code == 200
    assert response.json()["events"] == []


def test_stream_endpoint_returns_sse_events(client):
    with client.stream("POST", "/api/agent/v1/analyze/stream", json={"prompt": "test"}) as response:
        assert response.status_code == 200
        assert response.headers["content-type"].startswith("text/event-stream")
        body = "".join(response.iter_text())
    assert "event: run_started" in body
    assert "event: run_completed" in body


def test_cors_disabled_by_default(client):
    """Item 49 -- no AGENT_CORS_ALLOW_ORIGINS means no CORS headers at all."""
    response = client.get("/health", headers={"Origin": "http://example.com"})
    assert "access-control-allow-origin" not in {k.lower() for k in response.headers}


def test_cors_enabled_when_configured(monkeypatch):
    """CORS middleware is installed at agent_api.main IMPORT time (see its
    own comment for why -- Starlette forbids add_middleware() after the
    app has started serving), so proving it activates requires reloading
    the module with the env var already set -- module-level state is
    restored via a second reload afterward so later tests in this file
    (which rely on the `client` fixture's own fresh import) see the
    default CORS-disabled module again."""
    import importlib

    import agent_api.main as main_module

    monkeypatch.setenv("LLM_PROVIDER", "mock")
    monkeypatch.setenv("AGENT_CORS_ALLOW_ORIGINS", "http://example.com")
    monkeypatch.setattr("agent_api.service.build_llm_client", lambda config: MockLLMClient(_mock_responder))

    try:
        importlib.reload(main_module)
        with TestClient(main_module.app) as cors_client:
            response = cors_client.get("/health", headers={"Origin": "http://example.com"})
            assert response.headers.get("access-control-allow-origin") == "http://example.com"
    finally:
        monkeypatch.undo()
        importlib.reload(main_module)


def test_no_secret_or_traceback_leaks_in_health_or_error_paths(client):
    """Item 28/29/31 -- a deliberately-broken request still gets a bounded
    error, never a Python traceback string in the response body."""
    response = client.post("/api/agent/v1/analyze", json={"prompt": ""})
    assert response.status_code in (400, 422)
    assert "Traceback" not in response.text
    assert "site-packages" not in response.text
