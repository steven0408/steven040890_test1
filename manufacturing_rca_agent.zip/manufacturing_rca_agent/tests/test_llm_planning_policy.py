﻿"""Phase 5C-2: LLMPlanningPolicy core mechanics -- implements the exact same
`ModulePlanningPolicy` Protocol OEEPlanningPolicy/DeterministicMockPolicy do
(no parallel contract). DISPATCH materializes an Objective with Harness-
owned bookkeeping (objective_id/attempt_count); NO_VIABLE_OBJECTIVE returns
None; any LLM failure falls back to the wrapped baseline policy;
is_sufficient/describe_finding/derive_state_updates delegate to the
baseline unconditionally (never LLM-driven this phase).
"""
from agent.llm.models import LLMProviderError, LLMTimeoutError
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.state.enums import ObjectiveAction, TargetRefType
from agent.state.models import TargetRef

from .conftest import make_llm_planning_policy, make_module_state


def _proposal(action=ObjectiveAction.SCREEN, ref_id="OEE", ref_type=TargetRefType.MODULE, capability_key="oee.equipment_screening"):
    return ObjectiveProposal(
        action=action,
        capability_key=capability_key,
        target_ref=TargetRef(ref_type=ref_type, ref_id=ref_id),
        description="test objective",
        expected_output="test output",
    )


def test_dispatch_materializes_objective_with_harness_owned_bookkeeping():
    decision = PlannerDecision(decision=PlannerDecisionType.DISPATCH, next_objective=_proposal(), priority=0.8, rationale_summary="test")
    policy, usage_sink, client = make_llm_planning_policy(lambda req: decision)
    module_state = make_module_state()

    objective = policy.propose_next_objective(module_state)

    assert objective is not None
    assert objective.objective_id == f"{module_state.module_id}-obj-1"  # Harness-assigned, not LLM-controlled
    assert objective.attempt_count == 1
    assert objective.action == ObjectiveAction.SCREEN
    assert objective.capability_key == "oee.equipment_screening"
    assert objective.priority_score == 0.8
    assert len(usage_sink.list_for_run(module_state.run_id)) == 1
    assert len(client.calls) == 1


def test_no_viable_objective_returns_none():
    decision = PlannerDecision(decision=PlannerDecisionType.NO_VIABLE_OBJECTIVE, rationale_summary="done", stop_candidate=True)
    policy, _, _ = make_llm_planning_policy(lambda req: decision)
    assert policy.propose_next_objective(make_module_state()) is None


def _raise(exc):
    def responder(req):
        raise exc

    return responder


def test_timeout_falls_back_to_baseline_policy():
    policy, usage_sink, client = make_llm_planning_policy(_raise(LLMTimeoutError("too slow")), max_retries=0)
    module_state = make_module_state()  # empty RCA state -> baseline OEEPlanningPolicy proposes screening
    objective = policy.propose_next_objective(module_state)
    assert objective is not None
    assert objective.action == ObjectiveAction.SCREEN
    assert objective.target_ref.ref_id == "OEE"  # canonical MODULE target (Phase 5C-2.1)


def test_provider_error_falls_back_to_baseline_policy():
    policy, _, _ = make_llm_planning_policy(_raise(LLMProviderError("outage")), max_retries=0)
    objective = policy.propose_next_objective(make_module_state())
    assert objective is not None
    assert objective.action == ObjectiveAction.SCREEN


def test_invalid_structured_output_falls_back_to_baseline_policy():
    # extra field the schema rejects
    policy, _, _ = make_llm_planning_policy(lambda req: {"decision": "dispatch", "rationale_summary": "x", "tool_id": "should be rejected"}, max_retries=0)
    objective = policy.propose_next_objective(make_module_state())
    assert objective is not None
    assert objective.action == ObjectiveAction.SCREEN


def test_is_sufficient_describe_finding_derive_state_updates_delegate_to_baseline():
    class _SentinelBaseline:
        def propose_next_objective(self, module_state):
            return None

        def is_sufficient(self, module_state):
            return "SUFFICIENT-SENTINEL"

        def describe_finding(self, module_state):
            return "FINDING-SENTINEL"

        def derive_state_updates(self, module_state):
            return "UPDATES-SENTINEL"

    decision = PlannerDecision(decision=PlannerDecisionType.NO_VIABLE_OBJECTIVE, rationale_summary="x")
    policy, _, _ = make_llm_planning_policy(lambda req: decision, baseline_policy=_SentinelBaseline())
    module_state = make_module_state()

    # never LLM-driven -- these three always delegate straight through,
    # unconditionally, proven here by returning values no real
    # ModulePlanningPolicy implementation would ever produce
    assert policy.is_sufficient(module_state) == "SUFFICIENT-SENTINEL"
    assert policy.describe_finding(module_state) == "FINDING-SENTINEL"
    assert policy.derive_state_updates(module_state) == "UPDATES-SENTINEL"
