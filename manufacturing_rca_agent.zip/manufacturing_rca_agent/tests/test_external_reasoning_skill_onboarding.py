﻿"""Phase 5D-6: external reasoning skill onboarding proof. Loads a real
markdown file (agent/skills/reasoning/plant_manager_perspective.md) that
was authored exactly the way an external contributor would -- frontmatter
metadata + a narrative body, dropped into a skill directory -- and proves
it becomes retrievable for Analyzer/Planner through nothing but
`SkillRegistry.load_directory()` + `ReasoningSkillRetriever`.

No LangGraph node, Analyzer code, Planner code, CapabilityResolver, fake
Tool, or fake Domain class was touched to make this fixture work (the
taxonomy/filtering mechanism itself was built once in Phase 5D-1/5D-4/5D-5;
onboarding *this* skill required none of that to change again -- see the
Phase 5D report for the git-diff-level claim).
"""
from pathlib import Path

from agent.capability.resolver import CapabilityResolver
from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD
from agent.llm.context.analyzer_context import AnalyzerContextBuilder
from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
from agent.llm.context.reasoning_skill_retriever import DeterministicReasoningSkillRetriever
from agent.skills.models import SkillConsumerNode, SkillType
from agent.skills.registry import SkillRegistry
from agent.state.enums import TaskType

from .conftest import make_agent_state, make_module_registry, make_oee_tool_registry

REASONING_SKILLS_DIR = Path(__file__).resolve().parents[1] / "agent" / "skills" / "reasoning"


def _load_registry() -> SkillRegistry:
    registry = SkillRegistry()
    registry.load_directory(REASONING_SKILLS_DIR)
    return registry


def test_the_fixture_file_loads_with_the_declared_metadata():
    registry = _load_registry()
    skill = registry.get("reasoning.plant_manager_perspective")

    assert skill.skill_type == SkillType.REASONING
    assert set(skill.applicable_nodes) == {SkillConsumerNode.ANALYZER, SkillConsumerNode.PLANNER, SkillConsumerNode.SYNTHESIS}
    assert skill.roles == ["plant_manager"]
    assert skill.domains == []  # universally applicable -- retrievable even before a module is chosen
    assert skill.required_tools == []
    assert skill.steps == []
    assert "bottleneck" in registry.instructions("reasoning.plant_manager_perspective").lower()


def test_planner_can_retrieve_it():
    retriever = DeterministicReasoningSkillRetriever(_load_registry())
    results = retriever.retrieve(node=SkillConsumerNode.PLANNER, module_type="OEE", task_type=TaskType.RCA, limit=5)
    assert [r.skill_id for r in results] == ["reasoning.plant_manager_perspective"]


def test_analyzer_can_retrieve_it_before_any_module_is_chosen():
    retriever = DeterministicReasoningSkillRetriever(_load_registry())
    results = retriever.retrieve(node=SkillConsumerNode.ANALYZER, module_type=None, task_type=None, limit=5)
    assert [r.skill_id for r in results] == ["reasoning.plant_manager_perspective"]


def test_a_node_not_in_applicable_nodes_never_retrieves_it():
    retriever = DeterministicReasoningSkillRetriever(_load_registry())
    assert retriever.retrieve(node=SkillConsumerNode.EXECUTOR, module_type="OEE", task_type=TaskType.RCA, limit=5) == []


def test_it_flows_into_a_real_analyzer_context_end_to_end():
    reasoning_registry = _load_registry()
    builder = AnalyzerContextBuilder(make_module_registry(), reasoning_skill_retriever=DeterministicReasoningSkillRetriever(reasoning_registry))
    context = builder.build(make_agent_state())
    assert [s.skill_id for s in context.relevant_reasoning_skills] == ["reasoning.plant_manager_perspective"]


def test_it_never_reaches_capability_resolver_or_capability_retriever():
    """The other half of the taxonomy guarantee: this same fixture, loaded
    into a registry alongside real EXECUTION skills, must never be
    resolvable/executable -- proving onboarding a REASONING skill cannot
    accidentally make it runnable."""
    reasoning_registry = _load_registry()
    oee_registry = SkillRegistry()
    oee_registry.load_directory(Path(__file__).resolve().parents[1] / "agent" / "skills" / "oee")
    for skill_id in ["reasoning.plant_manager_perspective"]:
        oee_registry.register(reasoning_registry.get(skill_id), body=reasoning_registry.instructions(skill_id))

    capability_retriever = DeterministicCapabilityRetriever(oee_registry)
    results = capability_retriever.retrieve(module_type="OEE", task_type=TaskType.RCA, action_hint=None, limit=20)
    assert "reasoning.plant_manager_perspective" not in {s.skill_id for s in results}

    tool_registry = make_oee_tool_registry(MOCK_EQUIPMENT, OEE_THRESHOLD)
    resolver = CapabilityResolver(oee_registry, tool_registry)
    # every real OEE action still resolves normally with the reasoning
    # skill sitting in the same registry -- it's simply never a candidate
    from agent.state.enums import ObjectiveAction, TargetRefType
    from agent.state.models import Objective, TargetRef

    objective = Objective(
        objective_id="o1", description="d", action=ObjectiveAction.SCREEN,
        target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="OEE"), expected_output="x", priority_score=1.0,
    )
    resolved = resolver.resolve(objective, "OEE", TaskType.RCA)
    assert resolved.selected_skill.skill_id != "reasoning.plant_manager_perspective"
