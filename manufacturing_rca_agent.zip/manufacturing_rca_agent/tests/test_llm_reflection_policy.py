"""Phase WB-3F: MockLLMClient-driven regression coverage for
LLMReflectionPolicy -- the always-run counterpart to the real-provider live
tests in test_wb_reflector_llm_live.py. Covers: valid reflection (supports/
contradicts/insufficient), invalid evidence/limitation reference rejected,
invalid root-cause promotion rejected (both the generic support-required
guard and the WB-domain-specific never-confirm guard), LLM timeout/malformed
schema falling back to the deterministic baseline, hypothesis proposals
actually reaching `module_state.hypotheses`, exactly one LLM call per
Reflector round despite three protocol methods being invoked, and
`propose_next_objective` staying a pure passthrough (zero LLM calls).
"""
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.module_reflector import make_module_reflector
from agent.llm.client import MockLLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.context.reflector_context import ReflectorContextBuilder
from agent.llm.models import DecisionSource, LLMInvalidOutputError, LLMTimeoutError
from agent.llm.prompts.reflector import CausalLevel, FindingCandidate, HypothesisProposal, HypothesisUpdate, ObjectiveAssessment, ReflectionDecision, ReflectionVerdict
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.planning.policies.base import DomainStateUpdates, FindingDescription
from agent.planning.policies.llm_reflection import LLMReflectionPolicy
from agent.planning.policies.mock import DeterministicMockPolicy
from agent.planning.reflection_audit import InMemoryReflectionDecisionAuditSink
from agent.state.enums import EvidenceQuality, FindingStatus, ObjectiveAction, ObservationStatus, TargetRefType, TaskType
from agent.state.models import Evidence, ModuleState, ModuleTask, Objective, Observation, TargetRef

from .conftest import make_budget

_ROUTE = "reflector"


def _policy(responder, *, baseline=None, decision_audit_sink=None):
    usage_sink = InMemoryLLMUsageSink()
    client = MockLLMClient(responder)
    router = LLMRouter(routes={_ROUTE: LLMRouteConfig(route=_ROUTE, model="mock-model", max_retries=0)}, client=client, usage_sink=usage_sink)
    context_builder = ReflectorContextBuilder()
    baseline = baseline or DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1)
    policy = LLMReflectionPolicy(baseline, context_builder, router, decision_audit_sink=decision_audit_sink)
    return policy, client, usage_sink


def _module_state_with_evidence(*, module_id="mod", module_type="mod", task_type=TaskType.RCA, evidence_id="mod-ev-1") -> ModuleState:
    task = ModuleTask(module_id=module_id, module_type=module_type, reason="test", goal_statement="test goal", confidence=0.9, priority=0.9, task_type=task_type)
    state = build_initial_module_state(task, make_budget(max_steps=5, max_tool_calls=5, max_depth_per_entity=3), run_id="run-1", task_type=task_type)
    objective = Objective(
        objective_id=f"{module_id}-obj-1",
        description="query primary",
        action=ObjectiveAction.QUERY,
        target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="primary"),
        expected_output="evidence about primary",
        priority_score=1.0,
        attempt_count=1,
    )
    evidence = Evidence(evidence_id=evidence_id, objective_id=objective.objective_id, source_tool="tool:primary", summary="primary looks abnormal", quality=EvidenceQuality.STRONG)
    observation = Observation(observation_id=f"{module_id}-obs-1", objective_id=objective.objective_id, tool_name="tool:primary", status=ObservationStatus.SUCCESS, payload_summary="ok")
    return state.model_copy(update={"current_objective": objective, "evidence": [evidence], "observations": [observation]})


def _decision(**overrides) -> ReflectionDecision:
    base = dict(verdict=ReflectionVerdict.SUPPORTS, objective_assessment=ObjectiveAssessment.SATISFIED, should_continue=False, rationale_summary="evidence supports the objective")
    base.update(overrides)
    return ReflectionDecision(**base)


# ============================================================================
# Valid reflections -- supports / contradicts / insufficient.
# ============================================================================


def test_supports_and_satisfied_marks_sufficient():
    state = _module_state_with_evidence()
    decision = _decision(finding_candidate=FindingCandidate(statement="primary is abnormal", pattern="mock", supporting_evidence_ids=["mod-ev-1"]))
    policy, client, usage_sink = _policy(lambda req: decision)

    assert policy.is_sufficient(state) is True
    description = policy.describe_finding(state)
    assert description.statement == "primary is abnormal"
    assert description.is_root_cause is False
    assert len(client.calls) == 1  # is_sufficient + describe_finding shared one cached call


def test_contradicts_still_produces_a_finding_but_not_sufficient():
    state = _module_state_with_evidence()
    decision = _decision(
        verdict=ReflectionVerdict.CONTRADICTS,
        objective_assessment=ObjectiveAssessment.NOT_SATISFIED,
        should_continue=True,
        finding_candidate=FindingCandidate(statement="primary evidence contradicts the working hypothesis", pattern="mock", supporting_evidence_ids=["mod-ev-1"]),
    )
    policy, client, usage_sink = _policy(lambda req: decision)

    assert policy.is_sufficient(state) is False
    description = policy.describe_finding(state)
    assert "contradicts" in description.statement


def test_insufficient_verdict_maps_to_not_sufficient_with_no_finding_override():
    state = _module_state_with_evidence()
    decision = _decision(verdict=ReflectionVerdict.INSUFFICIENT, objective_assessment=ObjectiveAssessment.NOT_SATISFIED, should_continue=True, finding_candidate=None)
    policy, client, usage_sink = _policy(lambda req: decision)

    assert policy.is_sufficient(state) is False
    description = policy.describe_finding(state)  # finding_candidate=None -> falls back to baseline wording
    assert description.pattern == "mock-pattern"


# ============================================================================
# Semantic-validator rejections -- every one degrades safely to fallback.
# ============================================================================


def test_hallucinated_evidence_id_rejected_and_falls_back(monkeypatch=None):
    state = _module_state_with_evidence()
    decision = _decision(finding_candidate=FindingCandidate(statement="x", pattern="mock", supporting_evidence_ids=["does-not-exist"]))
    sink = InMemoryReflectionDecisionAuditSink()
    policy, client, usage_sink = _policy(lambda req: decision, decision_audit_sink=sink)

    assert policy.is_sufficient(state) == DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1).is_sufficient(state)
    record = sink.list_for_run("run-1")[0]
    assert record.source == DecisionSource.FALLBACK
    assert "does-not-exist" in record.fallback_reason


def test_hallucinated_limitation_ref_rejected_and_falls_back():
    state = _module_state_with_evidence()
    decision = _decision(limitation_refs=["nonexistent-limitation"])
    sink = InMemoryReflectionDecisionAuditSink()
    policy, client, usage_sink = _policy(lambda req: decision, decision_audit_sink=sink)

    policy.is_sufficient(state)
    record = sink.list_for_run("run-1")[0]
    assert record.source == DecisionSource.FALLBACK
    assert "nonexistent-limitation" in record.fallback_reason


def test_root_cause_without_support_rejected_and_falls_back():
    """causal_level=confirmed_causal but verdict/objective_assessment don't
    actually support it -- must be rejected, never silently accepted."""
    state = _module_state_with_evidence(module_type="mod")  # non-WB, so only the generic support-required guard applies
    decision = _decision(
        verdict=ReflectionVerdict.INSUFFICIENT,
        objective_assessment=ObjectiveAssessment.NOT_SATISFIED,
        finding_candidate=FindingCandidate(statement="x", pattern="mock", supporting_evidence_ids=["mod-ev-1"], causal_level=CausalLevel.CONFIRMED_CAUSAL),
    )
    sink = InMemoryReflectionDecisionAuditSink()
    policy, client, usage_sink = _policy(lambda req: decision, decision_audit_sink=sink)

    policy.is_sufficient(state)
    record = sink.list_for_run("run-1")[0]
    assert record.source == DecisionSource.FALLBACK
    assert "confirmed_causal" in record.fallback_reason


def test_root_cause_without_evidence_citation_rejected():
    state = _module_state_with_evidence(module_type="mod")
    decision = _decision(finding_candidate=FindingCandidate(statement="x", pattern="mock", supporting_evidence_ids=[], causal_level=CausalLevel.CONFIRMED_CAUSAL))
    sink = InMemoryReflectionDecisionAuditSink()
    policy, client, usage_sink = _policy(lambda req: decision, decision_audit_sink=sink)

    policy.is_sufficient(state)
    assert sink.list_for_run("run-1")[0].source == DecisionSource.FALLBACK


def test_wb_domain_never_confirms_root_cause_even_with_full_support():
    """WB-specific guard: even a fully-supported, well-evidenced claim must
    still be rejected for module_type='WB' -- matches WBPlanningPolicy's
    own deterministic ceiling exactly (agent/planning/policies/wb.py never
    sets is_root_cause=True either)."""
    state = _module_state_with_evidence(module_type="WB")
    decision = _decision(finding_candidate=FindingCandidate(statement="x", pattern="mock", supporting_evidence_ids=["mod-ev-1"], causal_level=CausalLevel.CONFIRMED_CAUSAL))
    sink = InMemoryReflectionDecisionAuditSink()
    policy, client, usage_sink = _policy(lambda req: decision, decision_audit_sink=sink)

    policy.is_sufficient(state)
    record = sink.list_for_run("run-1")[0]
    assert record.source == DecisionSource.FALLBACK
    assert "WB" in record.fallback_reason


def test_causal_candidate_level_is_the_wb_ceiling_and_is_accepted():
    """Phase WB-3F.1: causal_level=causal_candidate (the WB ceiling, one
    level short of confirmed_causal) must be ACCEPTED -- the ladder exists
    so the model has a legal, honest level to land on instead of jumping
    straight to a rejected confirmed_causal claim."""
    state = _module_state_with_evidence(module_type="WB")
    decision = _decision(finding_candidate=FindingCandidate(statement="x", pattern="mock", supporting_evidence_ids=["mod-ev-1"], causal_level=CausalLevel.CAUSAL_CANDIDATE))
    sink = InMemoryReflectionDecisionAuditSink()
    policy, client, usage_sink = _policy(lambda req: decision, decision_audit_sink=sink)

    description = policy.describe_finding(state)
    assert sink.list_for_run("run-1")[0].source == DecisionSource.LLM
    assert description.is_root_cause is False  # causal_candidate never maps to True


# ============================================================================
# Hypothesis lifecycle -- create / support / refute / reference validation.
# ============================================================================


def test_hypothesis_update_supported_requires_evidence_and_is_applied():
    state = _module_state_with_evidence()
    existing = _hypothesis(hypothesis_id="mod-hyp-existing", statement="material shortage explains it", status="open", confidence=0.4)
    state = state.model_copy(update={"hypotheses": [existing]})
    decision = _decision(
        hypothesis_updates=[HypothesisUpdate(hypothesis_id="mod-hyp-existing", status="supported", confidence=0.8, supporting_evidence_ids=["mod-ev-1"], rationale="aligned evidence")]
    )
    policy, client, usage_sink = _policy(lambda req: decision)

    updates = policy.derive_state_updates(state)

    assert len(updates.hypotheses) == 1
    updated = updates.hypotheses[0]
    assert updated.hypothesis_id == "mod-hyp-existing"
    assert updated.status.value == "supported"
    assert updated.confidence == 0.8
    assert updated.statement == "material shortage explains it"  # statement carries over unchanged


def test_hypothesis_update_supported_without_evidence_rejected():
    state = _module_state_with_evidence()
    existing = _hypothesis(hypothesis_id="mod-hyp-existing", statement="x", status="open", confidence=0.4)
    state = state.model_copy(update={"hypotheses": [existing]})
    decision = _decision(hypothesis_updates=[HypothesisUpdate(hypothesis_id="mod-hyp-existing", status="supported", confidence=0.8, rationale="no evidence cited")])
    sink = InMemoryReflectionDecisionAuditSink()
    policy, client, usage_sink = _policy(lambda req: decision, decision_audit_sink=sink)

    policy.derive_state_updates(state)
    assert sink.list_for_run("run-1")[0].source == DecisionSource.FALLBACK


def test_hypothesis_update_refuted_without_contradicting_evidence_rejected():
    state = _module_state_with_evidence()
    existing = _hypothesis(hypothesis_id="mod-hyp-existing", statement="x", status="open", confidence=0.4)
    state = state.model_copy(update={"hypotheses": [existing]})
    decision = _decision(hypothesis_updates=[HypothesisUpdate(hypothesis_id="mod-hyp-existing", status="refuted", confidence=0.1, rationale="no evidence cited")])
    sink = InMemoryReflectionDecisionAuditSink()
    policy, client, usage_sink = _policy(lambda req: decision, decision_audit_sink=sink)

    policy.derive_state_updates(state)
    assert sink.list_for_run("run-1")[0].source == DecisionSource.FALLBACK


def test_hypothesis_update_referencing_nonexistent_id_rejected():
    state = _module_state_with_evidence()
    decision = _decision(hypothesis_updates=[HypothesisUpdate(hypothesis_id="does-not-exist", status="refuted", confidence=0.1, contradicting_evidence_ids=["mod-ev-1"], rationale="x")])
    sink = InMemoryReflectionDecisionAuditSink()
    policy, client, usage_sink = _policy(lambda req: decision, decision_audit_sink=sink)

    policy.derive_state_updates(state)
    record = sink.list_for_run("run-1")[0]
    assert record.source == DecisionSource.FALLBACK
    assert "does-not-exist" in record.fallback_reason


def test_hypothesis_update_reads_latest_status_not_stale_entry():
    """Two entries for the same hypothesis_id (an earlier OPEN, a later
    SUPPORTED) -- an update must be validated/applied against the LATEST
    one, and Planner/Reflector context must only ever show the latest."""
    from agent.llm.context.planner_context import _hypothesis_summaries

    state = _module_state_with_evidence()
    older = _hypothesis(hypothesis_id="mod-hyp-existing", statement="x", status="open", confidence=0.3)
    newer = older.model_copy(update={"status": "supported", "confidence": 0.7})
    state = state.model_copy(update={"hypotheses": [older, newer]})

    summaries = _hypothesis_summaries(state)
    assert len(summaries) == 1  # deduped, not two entries
    assert summaries[0].status.value == "supported"
    assert summaries[0].confidence == 0.7


def _hypothesis(*, hypothesis_id, statement, status, confidence):
    from agent.state.enums import HypothesisStatus
    from agent.state.models import Hypothesis

    return Hypothesis(hypothesis_id=hypothesis_id, statement=statement, status=HypothesisStatus(status), confidence=confidence)


def test_llm_timeout_falls_back_to_baseline():
    state = _module_state_with_evidence()

    def _raise(req):
        raise LLMTimeoutError("simulated timeout")

    sink = InMemoryReflectionDecisionAuditSink()
    policy, client, usage_sink = _policy(_raise, decision_audit_sink=sink)

    result = policy.is_sufficient(state)
    assert result == DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1).is_sufficient(state)
    assert sink.list_for_run("run-1")[0].source == DecisionSource.FALLBACK


def test_malformed_schema_falls_back():
    state = _module_state_with_evidence()
    sink = InMemoryReflectionDecisionAuditSink()
    policy, client, usage_sink = _policy(lambda req: {"verdict": "not-a-real-verdict"}, decision_audit_sink=sink)

    policy.is_sufficient(state)
    assert sink.list_for_run("run-1")[0].source == DecisionSource.FALLBACK


# ============================================================================
# Exactly one LLM call per round; propose_next_objective never calls the LLM.
# ============================================================================


def test_exactly_one_llm_call_shared_across_all_three_protocol_methods():
    state = _module_state_with_evidence()
    decision = _decision(finding_candidate=FindingCandidate(statement="x", pattern="mock", supporting_evidence_ids=["mod-ev-1"]))
    policy, client, usage_sink = _policy(lambda req: decision)

    policy.is_sufficient(state)
    policy.describe_finding(state)
    policy.derive_state_updates(state)

    assert len(client.calls) == 1


def test_propose_next_objective_never_calls_the_llm():
    state = _module_state_with_evidence()
    baseline = DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1)
    policy, client, usage_sink = _policy(lambda req: (_ for _ in ()).throw(AssertionError("must not call the LLM")), baseline=baseline)

    result = policy.propose_next_objective(state)
    assert result == baseline.propose_next_objective(state)  # pure passthrough -- baseline already satisfied, so None here is correct
    assert len(client.calls) == 0


# ============================================================================
# Hypothesis proposals -- new capability this phase, reaching ModuleState
# via module_reflector.py's existing `extra.hypotheses` passthrough.
# ============================================================================


def test_hypothesis_proposals_flow_into_domain_state_updates():
    state = _module_state_with_evidence()
    decision = _decision(
        finding_candidate=FindingCandidate(statement="x", pattern="mock", supporting_evidence_ids=["mod-ev-1"]),
        hypothesis_proposals=[HypothesisProposal(statement="primary shortage explains the symptom", confidence=0.6, related_dimensions=["primary"])],
    )
    policy, client, usage_sink = _policy(lambda req: decision)

    updates = policy.derive_state_updates(state)

    assert len(updates.hypotheses) == 1
    assert updates.hypotheses[0].statement == "primary shortage explains the symptom"
    assert updates.hypotheses[0].confidence == 0.6
    assert updates.hypotheses[0].hypothesis_id  # mechanically assigned, never trusted from the LLM


def test_llm_hypotheses_coexist_with_baseline_domain_state_updates():
    """derive_state_updates must never let the LLM's hypotheses silently
    replace the baseline's own mechanical branches/entity_states/
    limitations -- both must survive in the same round's update."""
    from agent.state.models import Limitation

    class _BaselineWithLimitation(DeterministicMockPolicy):
        def derive_state_updates(self, module_state):
            return DomainStateUpdates(limitations=[Limitation(limitation_id="lim-1", description="gap", impacted_objective_id="obj-1", impact_statement="cannot confirm")])

    state = _module_state_with_evidence()
    decision = _decision(hypothesis_proposals=[HypothesisProposal(statement="new hypothesis", confidence=0.4)])
    baseline = _BaselineWithLimitation(sources=["primary"], sufficiency_evidence_count=1)
    policy, client, usage_sink = _policy(lambda req: decision, baseline=baseline)

    updates = policy.derive_state_updates(state)

    assert len(updates.limitations) == 1  # baseline's own mechanical bookkeeping survives
    assert len(updates.hypotheses) == 1  # LLM's addition survives alongside it


def test_hypothesis_reaches_module_state_through_the_real_reflector_node():
    """End-to-end proof through the actual (unmodified) module_reflector.py
    node function -- not just the policy in isolation."""
    state = _module_state_with_evidence()
    decision = _decision(
        finding_candidate=FindingCandidate(statement="x", pattern="mock", supporting_evidence_ids=["mod-ev-1"]),
        hypothesis_proposals=[HypothesisProposal(statement="candidate explanation", confidence=0.55)],
    )
    policy, client, usage_sink = _policy(lambda req: decision)

    reflector = make_module_reflector(policy)
    updates = reflector(state)

    assert "hypotheses" in updates
    assert updates["hypotheses"][0].statement == "candidate explanation"
    assert updates["findings"][0].statement == "x"
    assert updates["findings"][0].status == FindingStatus.CONFIRMED  # verdict/assessment default to supports+satisfied
