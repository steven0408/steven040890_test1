"""Phase 8A items 14/20: the CheckpointerProfile config contract, and the
invariant that nothing in agent/persistence/ ever constructs a
ValidatedKnowledgeRecord (future-only contract, item 14).
"""
import ast
from pathlib import Path

from agent.persistence.checkpoint_profile import CheckpointerProfile
from agent.persistence.records import ValidatedKnowledgeRecord


def test_checkpointer_profile_has_development_and_production_values():
    assert CheckpointerProfile.DEVELOPMENT_IN_MEMORY.value == "development_in_memory"
    assert CheckpointerProfile.PRODUCTION_POSTGRES.value == "production_postgres"


def test_validated_knowledge_record_schema_exists_and_is_constructible():
    """The contract exists and is usable *by a test* -- proving the schema
    itself is sound -- but that is different from any production service
    constructing one, which the next test checks nothing does."""
    from datetime import datetime, timezone

    from agent.llm.context.knowledge_retriever import ValidationStatus

    record = ValidatedKnowledgeRecord(
        knowledge_id="k1", statement="Availability loss on the bottleneck line often traces to Motor Failure.",
        knowledge_type="pattern", validation_status=ValidationStatus.CANDIDATE, confidence=0.5, scope="OEE",
        approved_at=None, version=1,
    )
    assert record.validation_status == ValidationStatus.CANDIDATE


def test_no_service_in_agent_persistence_ever_constructs_a_validated_knowledge_record():
    """AST-level regression, same pattern as Phase 7C's promotion-boundary
    test: no file under agent/persistence/ contains the expression
    `ValidatedKnowledgeRecord(...)` as a call."""
    persistence_dir = Path(__file__).resolve().parents[1] / "agent" / "persistence"
    offending = []
    for path in persistence_dir.rglob("*.py"):
        if path.name == "records.py":
            continue  # the class definition itself, not a construction
        if path.name == "mapping.py":
            # Phase 8B: row<->Record mapping plumbing, paired 1:1 with the
            # equally-inert `validated_knowledge_to_row` -- exercised only
            # by tests/test_persistence_postgres_mapping.py. Still no
            # PostgresValidatedKnowledgeRepository exists anywhere in
            # postgres/repositories.py, so nothing in a real read/write
            # path ever calls this function -- the actual invariant this
            # test guards (zero production write path) is unchanged.
            continue
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "ValidatedKnowledgeRecord":
                offending.append(str(path))
    assert offending == [], f"agent/persistence/ files construct ValidatedKnowledgeRecord: {offending}"


def test_no_postgres_repository_references_validated_knowledge():
    """The other half of mapping.py's exclusion above: proves there is no
    `PostgresValidatedKnowledgeRepository` (or any method referencing the
    `validated_knowledge` table) in postgres/repositories.py -- the actual
    write/read path stays absent, only the row<->Record mapping functions
    exist as schema-completeness plumbing."""
    repositories_path = Path(__file__).resolve().parents[1] / "agent" / "persistence" / "postgres" / "repositories.py"
    source = repositories_path.read_text(encoding="utf-8")
    assert "validated_knowledge" not in source
    assert "ValidatedKnowledge" not in source
