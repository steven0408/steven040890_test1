﻿"""Phase 5B-2 / 5B-2.1: CapabilityResolver -- deterministic/rule-based
resolution from (Objective, module_type, task_type) to a Skill, matched
against each Skill's own frontmatter-declared `actions`/`task_types`/
`domains`. Matching is on `Objective.action` (a typed, closed
ObjectiveAction) since 5B-2.1 -- never on `description` or a
`target_ref.ref_id` string convention.
"""
import pytest

from agent.capability.resolver import CapabilityResolutionError
from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD
from agent.state.enums import ObjectiveAction, TargetRefType, TaskType
from agent.state.models import Objective, TargetRef

from .conftest import make_oee_capability_runtime


def _objective(action: ObjectiveAction, target: str = "target") -> Objective:
    return Objective(
        objective_id="obj-1",
        description="test objective",
        action=action,
        target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id=target),
        expected_output="x",
        priority_score=1.0,
        attempt_count=1,
    )


def _resolver():
    return make_oee_capability_runtime(MOCK_EQUIPMENT, OEE_THRESHOLD).capability_resolver


def test_rca_equipment_screening_resolves_to_rca_screening_skill():
    resolved = _resolver().resolve(_objective(ObjectiveAction.SCREEN, "screen_equipment"), "OEE", TaskType.RCA)
    assert resolved.selected_skill.skill_id == "oee.rca_screening"
    assert {t.tool_id for t in resolved.resolved_tools} == {"query_oee_data"}


def test_analysis_equipment_screening_resolves_to_equipment_screening_skill():
    resolved = _resolver().resolve(_objective(ObjectiveAction.SCREEN, "screen_equipment"), "OEE", TaskType.ANALYSIS)
    assert resolved.selected_skill.skill_id == "oee.equipment_screening"
    assert {t.tool_id for t in resolved.resolved_tools} == {"query_oee_data", "filter_rows", "calculate_contribution", "ranking"}


def test_information_current_status_resolves_to_current_status_skill():
    resolved = _resolver().resolve(_objective(ObjectiveAction.SUMMARIZE, "current_status"), "OEE", TaskType.INFORMATION)
    assert resolved.selected_skill.skill_id == "oee.current_status"


def test_rca_equipment_detail_matches_rca_equipment_detail_skill():
    resolved = _resolver().resolve(_objective(ObjectiveAction.DRILL_DOWN, "equipment_detail:EQ001"), "OEE", TaskType.RCA)
    assert resolved.selected_skill.skill_id == "oee.rca_equipment_detail"


def test_same_action_different_task_type_resolves_to_different_skills():
    """The same Objective action (EQUIPMENT_SCREENING) must resolve
    differently purely based on TaskType -- proves TaskType actually drives
    skill resolution, not just analysis depth."""
    rca = _resolver().resolve(_objective(ObjectiveAction.SCREEN, "screen_equipment"), "OEE", TaskType.RCA)
    analysis = _resolver().resolve(_objective(ObjectiveAction.SCREEN, "screen_equipment"), "OEE", TaskType.ANALYSIS)
    assert rca.selected_skill.skill_id != analysis.selected_skill.skill_id


def test_unresolvable_action_raises_typed_capability_resolution_error():
    # GENERIC_QUERY is reserved for domain-agnostic Harness-mechanics test
    # fixtures (DeterministicMockPolicy) -- no real OEE skill declares it.
    with pytest.raises(CapabilityResolutionError) as exc_info:
        _resolver().resolve(_objective(ObjectiveAction.QUERY), "OEE", TaskType.RCA)
    assert exc_info.value.objective_action == ObjectiveAction.QUERY.value
    assert exc_info.value.module_type == "OEE"


def test_wip_module_never_resolves_an_oee_only_skill():
    with pytest.raises(CapabilityResolutionError):
        _resolver().resolve(_objective(ObjectiveAction.SCREEN, "screen_equipment"), "WIP", TaskType.RCA)
