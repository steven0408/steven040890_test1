"""Phase WB-2A item P/T.11: WB Tool layer integration --
ToolRegistry registration via `register_wb_tools`, a genuine
`Objective(-adjacent) -> ToolExecutionManager -> WB Tool -> InMemoryWBDataSource
-> typed Tool Result` trace (not direct function calls), DataSource
exception -> Harness error mapping through the manager, and Golden
Scenarios A-E re-verified at the Tool layer through the real chain.

NOTE (from prior smoke testing): `ToolExecutionIdentity.idempotency_key()`
does not include `tool_id` -- run_id/module_id/objective_id/skill_id/
skill_step_id/logical_attempt only. Every distinct logical Tool call in
this file therefore uses its own `objective_id` (via `_identity()`'s
counter), or a second call for a different tool/params would silently
receive the first call's cached result.
"""
from datetime import datetime, timezone
from itertools import count

import pytest

from agent.domain.wb.errors import WBDataSourceUnavailableError
from agent.domain.wb.synthetic import (
    GOLDEN_DATE,
    SCENARIO_A_PLANT,
    SCENARIO_B_PLANT,
    SCENARIO_C_PLANT,
    SCENARIO_D_PLANT,
    SCENARIO_E_PLANT,
    build_wb_plant_oee_records,
    build_wb_stage_output_records,
)
from agent.domain.wb.tool_results import WBHoldAnalysisResult, WBOEELossAnalysisResult, WBStageOutputSummaryResult
from agent.state.enums import ErrorType, ObservationStatus
from agent.state.payload import PayloadRegistry
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.models import ToolExecutionIdentity
from agent.tools.registry import DuplicateToolError, ToolNotFoundError, ToolRegistry
from agent.tools.wb.bank_tools import WBBankStatusSummaryInput
from agent.tools.wb.oee_tools import WBOEELossAnalysisInput, WBPlantOEEQueryInput
from agent.tools.wb.output_tools import WBStageOutputSummaryInput
from agent.tools.wb.registration import WBDataSources, register_wb_tools
from agent.tools.wb.wip_tools import WBHoldAnalysisInput

from .conftest import make_wb_datasources

_EXPECTED_TOOL_IDS = {
    "query_wb_plant_oee", "analyze_wb_oee_loss",
    "query_wb_bank", "summarize_wb_bank_status", "analyze_wb_bank_aging",
    "query_wb_wip", "summarize_wb_wip", "analyze_wb_hold",
    "query_wb_stage_output", "summarize_wb_stage_output", "compare_wb_stage_output",
    "query_wb_issue", "summarize_wb_issue", "analyze_wb_issue_trend",  # Phase WB-3A
    "analyze_wb_oee_trend", "analyze_wb_wip_hold_trend", "analyze_wb_bank_shortage_trend",
    "analyze_wb_output_trend", "analyze_wb_issue_vs_output",  # Phase WB-3B
}


@pytest.fixture
def wb_registry():
    registry = ToolRegistry()
    register_wb_tools(registry, datasources=make_wb_datasources())
    return registry


_counter = count(1)


def _identity() -> ToolExecutionIdentity:
    n = next(_counter)
    return ToolExecutionIdentity(run_id="run-integration", module_id="WB", objective_id=f"obj-{n}")


def _execute(manager, registry, tool_id, payload_type, params_model):
    tool = registry.get(tool_id)
    payload = PayloadRegistry.pack(payload_type, params_model)
    identity = _identity()
    return manager.execute(
        tool, identity, payload, tool_call_id=f"tc-{identity.objective_id}",
        started_at=datetime.now(timezone.utc), completed_at_fn=lambda: datetime.now(timezone.utc),
    )


# ============================================================================
# ToolRegistry integration (item P.13)
# ============================================================================


def test_register_wb_tools_registers_all_19_tools(wb_registry):
    tool_ids = {d.tool_id for d in wb_registry.list()}
    assert tool_ids == _EXPECTED_TOOL_IDS


def test_all_wb_tools_scoped_to_wb_domain(wb_registry):
    for definition in wb_registry.list():
        assert definition.domains == ["wb"]


def test_registering_twice_raises_duplicate_tool_error():
    registry = ToolRegistry()
    datasources = make_wb_datasources()
    register_wb_tools(registry, datasources=datasources)
    with pytest.raises(DuplicateToolError):
        register_wb_tools(registry, datasources=datasources)


def test_unregistered_tool_id_raises_tool_not_found(wb_registry):
    with pytest.raises(ToolNotFoundError):
        wb_registry.get("does_not_exist")


# ============================================================================
# Full trace: (Objective-identity) -> ToolExecutionManager -> WB Tool ->
# InMemoryWBDataSource -> typed Tool Result (item P/T.11's mandatory test)
# ============================================================================


def test_full_trace_objective_to_tool_execution_manager_to_datasource_to_result(wb_registry):
    manager = ToolExecutionManager()
    outcome = _execute(
        manager, wb_registry, "analyze_wb_oee_loss", "wb.oee_loss_analysis_input",
        WBOEELossAnalysisInput(production_date=GOLDEN_DATE, plant_id=SCENARIO_A_PLANT, operation_id="2800"),
    )
    assert outcome.result.status == ObservationStatus.SUCCESS
    assert outcome.record.tool_id == "analyze_wb_oee_loss"
    assert outcome.record.status == ObservationStatus.SUCCESS
    assert outcome.record.replayed is False
    payload = PayloadRegistry.unpack(outcome.result.payload)
    assert isinstance(payload, WBOEELossAnalysisResult)
    assert payload.ranking[0].oee == 58.0
    assert payload.ranking[0].dominant_loss_category == "downtime"


def test_idempotent_replay_with_same_identity_reuses_cached_result(wb_registry):
    manager = ToolExecutionManager()
    tool = wb_registry.get("query_wb_plant_oee")
    payload = PayloadRegistry.pack("wb.plant_oee_query_input", WBPlantOEEQueryInput(production_date=GOLDEN_DATE, plant_id=SCENARIO_A_PLANT))
    identity = ToolExecutionIdentity(run_id="run-replay", module_id="WB", objective_id="obj-replay")

    first = manager.execute(tool, identity, payload, tool_call_id="tc-1", started_at=datetime.now(timezone.utc), completed_at_fn=lambda: datetime.now(timezone.utc))
    second = manager.execute(tool, identity, payload, tool_call_id="tc-2", started_at=datetime.now(timezone.utc), completed_at_fn=lambda: datetime.now(timezone.utc))

    assert first.record.replayed is False
    assert second.record.replayed is True
    assert second.record.result_reused is True
    assert first.result.payload == second.result.payload


# ============================================================================
# DataSource-exception -> Tool -> ToolExecutionManager -> ErrorRecord mapping
# ============================================================================


class _BrokenOEEDataSource:
    def list_oee(self, *, production_date=None):
        raise WBDataSourceUnavailableError("simulated outage through the manager")

    def freshness(self):
        from agent.domain.wb.models import WB_PLANT_OEE_FRESHNESS

        return WB_PLANT_OEE_FRESHNESS


def test_datasource_exception_reaches_manager_as_typed_error_result_not_raised():
    registry = ToolRegistry()
    datasources = make_wb_datasources()
    broken = WBDataSources(oee=_BrokenOEEDataSource(), bank=datasources.bank, wip=datasources.wip, output=datasources.output, issue=datasources.issue)
    register_wb_tools(registry, datasources=broken)
    manager = ToolExecutionManager()

    outcome = _execute(manager, registry, "query_wb_plant_oee", "wb.plant_oee_query_input", WBPlantOEEQueryInput())

    assert outcome.result.status == ObservationStatus.ERROR
    assert outcome.result.error_type == ErrorType.DATA_NOT_FOUND
    assert outcome.record.status == ObservationStatus.ERROR


# ============================================================================
# Golden Scenarios A-E, re-verified through the real Tool layer (item J/T.10)
# ============================================================================


def test_golden_scenario_a_equipment_side_loss(wb_registry):
    manager = ToolExecutionManager()
    outcome = _execute(manager, wb_registry, "analyze_wb_oee_loss", "wb.oee_loss_analysis_input", WBOEELossAnalysisInput(production_date=GOLDEN_DATE, plant_id=SCENARIO_A_PLANT, operation_id="2800"))
    payload = PayloadRegistry.unpack(outcome.result.payload)
    assert payload.ranking[0].oee == 58.0
    assert payload.ranking[0].dominant_loss_category == "downtime"


def test_golden_scenario_b_material_shortage(wb_registry):
    manager = ToolExecutionManager()
    outcome = _execute(manager, wb_registry, "summarize_wb_bank_status", "wb.bank_status_summary_input", WBBankStatusSummaryInput(snapshot_date=GOLDEN_DATE, plant_id=SCENARIO_B_PLANT))
    payload = PayloadRegistry.unpack(outcome.result.payload)
    counts = {c.status.value: c.count for c in payload.by_status}
    assert counts["material_shortage"] == 7

    output_outcome = _execute(manager, wb_registry, "summarize_wb_stage_output", "wb.stage_output_summary_input", WBStageOutputSummaryInput(production_date=GOLDEN_DATE, plant_id=SCENARIO_B_PLANT, operation_id="2800"))
    output_payload = PayloadRegistry.unpack(output_outcome.result.payload)
    assert isinstance(output_payload, WBStageOutputSummaryResult)
    assert output_payload.total_output_quantity == 2400  # 1200 x 2 products -- output shortage, reported as a SEPARATE fact, not a causal claim


def test_golden_scenario_c_wip_hold_flow_issue(wb_registry):
    manager = ToolExecutionManager()
    outcome = _execute(manager, wb_registry, "analyze_wb_hold", "wb.hold_analysis_input", WBHoldAnalysisInput(snapshot_date=GOLDEN_DATE, plant_id=SCENARIO_C_PLANT))
    payload = PayloadRegistry.unpack(outcome.result.payload)
    assert isinstance(payload, WBHoldAnalysisResult)
    assert payload.hold_lot_count == 22
    assert payload.total_lot_count == 30
    assert abs(payload.hold_ratio - (22 / 30)) < 1e-9


def test_golden_scenario_d_normal_control_no_false_positive(wb_registry):
    manager = ToolExecutionManager()
    oee_outcome = _execute(manager, wb_registry, "analyze_wb_oee_loss", "wb.oee_loss_analysis_input", WBOEELossAnalysisInput(production_date=GOLDEN_DATE, plant_id=SCENARIO_D_PLANT, operation_id="2800"))
    oee_payload = PayloadRegistry.unpack(oee_outcome.result.payload)
    assert oee_payload.ranking[0].oee == 85.0  # baseline, no degradation

    hold_outcome = _execute(manager, wb_registry, "analyze_wb_hold", "wb.hold_analysis_input", WBHoldAnalysisInput(snapshot_date=GOLDEN_DATE, plant_id=SCENARIO_D_PLANT))
    hold_payload = PayloadRegistry.unpack(hold_outcome.result.payload)
    assert hold_payload.hold_ratio < 0.1  # only background Hold variety, not an elevated ratio


def test_golden_scenario_e_missing_oee_data_not_zero(wb_registry):
    manager = ToolExecutionManager()
    outcome = _execute(manager, wb_registry, "query_wb_plant_oee", "wb.plant_oee_query_input", WBPlantOEEQueryInput(production_date=GOLDEN_DATE, plant_id=SCENARIO_E_PLANT))
    payload = PayloadRegistry.unpack(outcome.result.payload)
    assert payload.records == []
    assert payload.availability.is_empty is True
    assert outcome.result.status == ObservationStatus.SUCCESS  # absence is not an error/anomaly signal at this layer


# ============================================================================
# Sanity: the synthetic-dataset sizes this file's Golden Scenario assertions
# depend on haven't silently drifted.
# ============================================================================


def test_synthetic_dataset_sizes_unchanged():
    assert len(build_wb_plant_oee_records()) == 68
    assert len(build_wb_stage_output_records()) == 140
