"""Phase 7C item 19: candidate generation examples A-F, against hand-built
`LearningRunSnapshot` fixtures (deliberately not full pipeline runs --
Learning's contract is "what does it do with a snapshot", already covered
separately by test_learning_snapshot_extraction.py's real-pipeline test).
"""
from datetime import datetime, timezone

from agent.feedback.aggregator import HumanFeedbackSummary
from agent.learning.confidence import TieredCandidateConfidenceScorer
from agent.learning.generators.capability_gap import generate_capability_gap_candidates
from agent.learning.generators.knowledge_pattern import generate_knowledge_pattern_candidates
from agent.learning.generators.planning_strategy import generate_planning_strategy_candidates
from agent.learning.generators.reasoning_skill import generate_reasoning_skill_candidates
from agent.learning.snapshot import (
    LearningRunSnapshot,
    SnapshotCapabilityGap,
    SnapshotEvaluationSummary,
    SnapshotFinding,
    SnapshotPlannerSummary,
    SnapshotRootCause,
)
from agent.state.enums import LearningCandidateType, LearningDestination, TaskType

_SCORER = TieredCandidateConfidenceScorer()


def _eval_summary(**overrides):
    base = dict(analytical_quality_score=0.9, decision_quality_score=0.9, delivery_quality_score=0.9, efficiency_score=0.9, overall_score=0.9)
    base.update(overrides)
    return SnapshotEvaluationSummary(**base)


def _planner_summary(**overrides):
    base = dict(total_decisions=1, fallback_decisions=0, objective_count=2, unnecessary_deep_dive_count=0, strategy_label=None)
    base.update(overrides)
    return SnapshotPlannerSummary(**base)


def _snapshot(run_id, findings=None, root_causes=None, capability_gaps=None, feedback_summary=None, active_reasoning_skill_ids=None, **kwargs):
    base = dict(
        run_id=run_id, factory_id="factory-a", module_types=["OEE", "Output"], task_type=TaskType.RCA,
        confirmed_findings=findings or [], root_causes=root_causes or [], evaluation_summary=_eval_summary(),
        feedback_summary=feedback_summary, planner_summary=_planner_summary(), capability_gaps=capability_gaps or [],
        active_reasoning_skill_ids=active_reasoning_skill_ids or [],
    )
    base.update(kwargs)
    return LearningRunSnapshot(**base)


def _finding(finding_id, module_type, pattern, statement=None, confidence=0.85):
    return SnapshotFinding(
        finding_id=finding_id, module_id=module_type, module_type=module_type, statement=statement or f"{module_type} {pattern} finding",
        pattern=pattern, entity_ids=[], confidence=confidence, is_root_cause=False,
    )


def _root_cause(root_cause_id, module_type, statement=None, confidence=0.9):
    return SnapshotRootCause(
        root_cause_id=root_cause_id, module_id=module_type, module_type=module_type,
        statement=statement or f"{module_type} root cause", entity_ids=[], confidence=confidence,
    )


# ============================================================================
# A. Knowledge candidate
# ============================================================================


def test_case_a_knowledge_pattern_candidate_from_three_runs():
    snapshots = [
        _snapshot("run-a", findings=[_finding("f1", "OEE", "Availability"), _finding("f2", "Output", "Downtime")]),
        _snapshot("run-b", findings=[_finding("f1", "OEE", "Availability"), _finding("f2", "Output", "Downtime")]),
        _snapshot("run-c", findings=[_finding("f1", "OEE", "Availability"), _finding("f2", "Output", "Downtime")]),
    ]
    candidates, links = generate_knowledge_pattern_candidates(snapshots, _SCORER)

    assert len(candidates) == 1
    candidate = candidates[0]
    assert candidate.candidate_type == LearningCandidateType.KNOWLEDGE_PATTERN
    assert candidate.proposed_destination == LearningDestination.KNOWLEDGE_BASE
    assert "may be associated with" in candidate.statement
    assert "causes" not in candidate.statement.lower()
    assert candidate.supporting_signal_count == 3
    assert candidate.contradicting_signal_count == 0
    assert set(candidate.source_run_ids) == {"run-a", "run-b", "run-c"}


# ============================================================================
# B. Contradiction
# ============================================================================


def test_case_b_contradicting_run_lowers_confidence_but_keeps_same_candidate():
    supporting_snapshots = [
        _snapshot("run-a", findings=[_finding("f1", "OEE", "Availability"), _finding("f2", "Output", "Downtime")]),
        _snapshot("run-b", findings=[_finding("f1", "OEE", "Availability"), _finding("f2", "Output", "Downtime")]),
        _snapshot("run-c", findings=[_finding("f1", "OEE", "Availability"), _finding("f2", "Output", "Downtime")]),
    ]
    baseline_candidates, _ = generate_knowledge_pattern_candidates(supporting_snapshots, _SCORER)
    baseline_confidence = baseline_candidates[0].confidence
    baseline_key = baseline_candidates[0].candidate_key

    contradicting_snapshot = _snapshot("run-d", findings=[_finding("f1", "OEE", "Availability"), _finding("f2", "Output", "MaterialStarvation")])
    candidates_with_contradiction, _ = generate_knowledge_pattern_candidates(supporting_snapshots + [contradicting_snapshot], _SCORER)

    assert len(candidates_with_contradiction) == 1  # same candidate, not a second one
    candidate = candidates_with_contradiction[0]
    assert candidate.candidate_key == baseline_key
    assert candidate.contradicting_signal_count == 1
    assert candidate.confidence < baseline_confidence


# ============================================================================
# C. Capability gap
# ============================================================================


def test_case_c_two_runs_merge_into_one_capability_gap_candidate():
    gap = SnapshotCapabilityGap(module_type="OEE", requested_action="maintenance_history_analysis", description="Maintenance history repeatedly required but unavailable.")
    snapshots = [_snapshot("run-a", capability_gaps=[gap]), _snapshot("run-b", capability_gaps=[gap])]

    candidates, links = generate_capability_gap_candidates(snapshots, _SCORER)

    assert len(candidates) == 1
    candidate = candidates[0]
    assert candidate.candidate_type == LearningCandidateType.CAPABILITY_GAP
    assert candidate.proposed_destination == LearningDestination.CAPABILITY_BACKLOG
    assert set(candidate.source_run_ids) == {"run-a", "run-b"}
    assert candidate.supporting_signal_count == 2


# ============================================================================
# D. Strategy
# ============================================================================


def test_case_d_planning_strategy_candidate_prefers_fewer_objectives_at_comparable_quality():
    efficient = [
        _snapshot("run-a", root_causes=[_root_cause("rc1", "OEE")], planner_summary=_planner_summary(objective_count=2, strategy_label="maintenance_history_analysis")),
        _snapshot("run-b", root_causes=[_root_cause("rc2", "OEE")], planner_summary=_planner_summary(objective_count=2, strategy_label="maintenance_history_analysis")),
    ]
    slower = [
        _snapshot("run-c", root_causes=[_root_cause("rc3", "OEE")], planner_summary=_planner_summary(objective_count=5, strategy_label="generic_equipment_detail")),
        _snapshot("run-d", root_causes=[_root_cause("rc4", "OEE")], planner_summary=_planner_summary(objective_count=5, strategy_label="generic_equipment_detail")),
    ]

    candidates, links = generate_planning_strategy_candidates(efficient + slower, _SCORER)

    assert len(candidates) == 1
    candidate = candidates[0]
    assert candidate.candidate_type == LearningCandidateType.PLANNING_STRATEGY
    assert candidate.proposed_destination == LearningDestination.PLANNER_STRATEGY
    assert "maintenance_history_analysis" in candidate.statement
    assert "generic_equipment_detail" in candidate.statement


# ============================================================================
# E. Reasoning skill
# ============================================================================


def test_case_e_reasoning_skill_candidate_from_positive_feedback_not_knowledge_base():
    positive_summary = HumanFeedbackSummary(
        run_id="x", total_feedback_count=2, thumbs_up_count=2, thumbs_down_count=0, helpful_rate=1.0,
        recommendation_useful_rate=None, target_breakdown=[], unresolved_negative_feedback_count=0,
    )
    snapshots = [
        _snapshot("run-a", feedback_summary=positive_summary, active_reasoning_skill_ids=["reasoning.plant_manager_perspective"]),
        _snapshot("run-b", feedback_summary=positive_summary, active_reasoning_skill_ids=["reasoning.plant_manager_perspective"]),
    ]

    candidates, links = generate_reasoning_skill_candidates(snapshots, _SCORER)

    assert len(candidates) == 1
    candidate = candidates[0]
    assert candidate.candidate_type == LearningCandidateType.REASONING_SKILL
    assert candidate.proposed_destination == LearningDestination.REASONING_SKILL
    assert candidate.proposed_destination != LearningDestination.KNOWLEDGE_BASE


# ============================================================================
# F. Single-run
# ============================================================================


def test_case_f_single_run_never_produces_a_knowledge_pattern_candidate():
    snapshots = [_snapshot("run-a", findings=[_finding("f1", "OEE", "Availability"), _finding("f2", "Output", "Downtime")])]
    candidates, _ = generate_knowledge_pattern_candidates(snapshots, _SCORER)
    assert candidates == []  # cross-run requirement -- one run alone is not enough


def test_case_f_single_run_can_still_produce_a_low_confidence_capability_gap():
    gap = SnapshotCapabilityGap(module_type="OEE", requested_action="maintenance_history_analysis", description="unavailable")
    candidates, _ = generate_capability_gap_candidates([_snapshot("run-a", capability_gaps=[gap])], _SCORER)

    assert len(candidates) == 1
    assert candidates[0].status.value == "candidate"  # never VALIDATED
    assert candidates[0].confidence < 0.5  # single run -- low support, per the volume dampening
