"""Phase 8A items 23.A/23.B/23.G: full RCA round-trip through
RunPersistenceWriter -> RunRepository, idempotent repeat-save, and
historical query contracts.
"""
from agent.persistence.audit_repository import build_default_audit_repository
from agent.persistence.learning_repository import LearningCandidateRepository
from agent.persistence.run_repository import InMemoryRunRepository
from agent.persistence.run_writer import RunPersistenceWriter
from agent.learning.sink import InMemoryLearningCandidateSink
from agent.persistence.human_feedback import InMemoryHumanFeedbackSink
from agent.state.enums import ModuleStatus, RunTerminationStatus, TaskType
from agent.state.models import Goal, GoalScope

from .conftest import make_agent_state, run_oee_module_state_history


def _writer():
    run_repo = InMemoryRunRepository()
    audit_repo = build_default_audit_repository()
    feedback_sink = InMemoryHumanFeedbackSink()
    learning_repo = LearningCandidateRepository(InMemoryLearningCandidateSink())
    writer = RunPersistenceWriter(run_repo, audit_repo, feedback_sink, learning_repo)
    return writer, run_repo, audit_repo, feedback_sink, learning_repo


def _rca_complete_state(run_id="run-1"):
    history = run_oee_module_state_history(TaskType.RCA)
    final = history[-1]
    assert final.status == ModuleStatus.COMPLETE
    state = make_agent_state(run_id=run_id).model_copy(
        update={
            "module_states": {"OEE": final},
            "global_goal": Goal(goal_id="g1", raw_statement="為什麼 OEE 下降？", normalized_statement="Why did OEE decline?", task_type=TaskType.RCA, scope=GoalScope()),
            "termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS,
        }
    )
    return state, final


# ============================================================================
# A. Full RCA persistence round-trip
# ============================================================================


def test_full_rca_run_round_trips_through_the_repository():
    writer, run_repo, _, _, _ = _writer()
    state, module_state = _rca_complete_state()

    writer.persist_run(state)

    run_record = run_repo.get_run("run-1")
    assert run_record is not None
    assert run_record.factory_id == state.factory_context.factory_id
    assert run_record.task_type == TaskType.RCA
    assert run_record.run_status == RunTerminationStatus.READY_FOR_SYNTHESIS

    module_records = run_repo.get_module_results("run-1")
    assert len(module_records) == 1
    assert module_records[0].module_type == "OEE"
    assert module_records[0].module_status == ModuleStatus.COMPLETE

    objectives = run_repo.list_objectives("run-1")
    assert len(objectives) == len(module_state.objective_history)

    evidence = run_repo.list_evidence("run-1")
    assert len(evidence) == len(module_state.evidence)

    findings = run_repo.list_findings("run-1")
    assert len(findings) == len(module_state.findings)

    root_causes = run_repo.list_root_causes("run-1")
    assert len(root_causes) == 1
    assert "Motor Failure" in root_causes[0].statement

    # lineage: the root cause's finding link resolves to a real, persisted finding
    finding_links = run_repo.list_finding_evidence_links(findings[0].finding_id)
    if findings[0].status.value == "confirmed":
        assert all(any(e.evidence_id == link.evidence_id for e in evidence) for link in finding_links)


def test_handoff_package_persists_when_present():
    writer, run_repo, _, _, _ = _writer()
    state, _ = _rca_complete_state()

    from agent.llm.context.synthesis_context import SynthesisContextBuilder
    from agent.synthesis.handoff_builder import ModuleHandoffBuilder
    from agent.synthesis.package import build_handoff_package

    outcome = SynthesisContextBuilder(ModuleHandoffBuilder()).build(state)
    package = build_handoff_package(outcome.context)
    state = state.model_copy(update={"synthesis_result": package})

    writer.persist_run(state)

    stored = run_repo.get_handoff_package("run-1")
    assert stored is not None
    assert stored.run_id == "run-1"
    assert "Motor Failure" in stored.markdown


# ============================================================================
# B. Idempotent repeat save
# ============================================================================


def test_persisting_the_same_run_twice_never_duplicates_logical_records():
    writer, run_repo, _, _, _ = _writer()
    state, module_state = _rca_complete_state()

    writer.persist_run(state)
    first_objective_count = len(run_repo.list_objectives("run-1"))
    first_finding_count = len(run_repo.list_findings("run-1"))
    first_evidence_count = len(run_repo.list_evidence("run-1"))
    first_run_count = len(run_repo.list_runs())

    writer.persist_run(state)  # simulate a checkpoint-replay re-persist of the same completed run

    assert len(run_repo.list_runs()) == first_run_count  # still exactly one Run row
    assert len(run_repo.list_objectives("run-1")) == first_objective_count
    assert len(run_repo.list_findings("run-1")) == first_finding_count
    assert len(run_repo.list_evidence("run-1")) == first_evidence_count
    assert len(run_repo.get_module_results("run-1")) == 1


# ============================================================================
# G. Historical query contracts
# ============================================================================


def test_list_runs_filters_by_factory_id():
    writer, run_repo, _, _, _ = _writer()
    state_a, _ = _rca_complete_state(run_id="run-a")
    writer.persist_run(state_a)

    other_state = make_agent_state(run_id="run-b")
    other_state = other_state.model_copy(update={"factory_context": other_state.factory_context.model_copy(update={"factory_id": "factory-b"})})
    writer.persist_run(other_state)

    assert {r.run_id for r in run_repo.list_runs(factory_id="factory-a")} == {"run-a"}
    assert {r.run_id for r in run_repo.list_runs(factory_id="factory-b")} == {"run-b"}
    assert {r.run_id for r in run_repo.list_runs()} == {"run-a", "run-b"}


def test_get_module_results_and_list_findings_scoped_to_run():
    writer, run_repo, _, _, _ = _writer()
    state, _ = _rca_complete_state(run_id="run-x")
    writer.persist_run(state)

    assert run_repo.get_module_results("does-not-exist") == []
    assert run_repo.list_findings("does-not-exist") == []
    assert len(run_repo.get_module_results("run-x")) == 1
