"""Phase WB-3F item 41: static (AST-level, not substring grep) regression
enforcing the Tool Ownership Invariant -- Planner chooses WHAT capability
should run, Executor is the sole Tool-execution owner, and no cognitive
node (Analyzer/Planner/Reflector/CompletionCheck/Synthesis/Coordinator/
Execution Gate) ever imports a Tool implementation module or calls `.run(`
on anything. AST-based so a docstring/comment that merely *mentions*
`agent.tools.wb` or `.run(` never trips this check -- only a real `import`
statement or a real call expression does (mirrors
test_runtime_invariants.py's own established AST-not-grep discipline).

Confirmed via a dedicated Phase WB-3F repo audit (before writing this test)
that the ONLY files calling `Tool.run(` today are agent/tools/execution_
manager.py (the sanctioned call site) and agent/graph/nodes/module/
module_executor.py (the legacy pre-Phase-5B-2 direct-tool executor, itself
part of the execution layer, not a cognitive node) -- both intentionally
excluded from the scanned set below.
"""
import ast
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parent.parent
_AGENT_ROOT = _REPO_ROOT / "agent"

# Every cognitive/orchestration node this invariant applies to. Deliberately
# excludes the execution layer (module_executor.py / capability_executor.py
# / module_subgraph.py / module_subgraph_node.py -- these legitimately
# thread a Tool/MockTool reference through to the Executor, or physically
# call Tool.run()) per the phase spec's own "Allow: Executor / execution
# services" carve-out.
_COGNITIVE_NODE_FILES = [
    "agent/graph/nodes/analyzer_llm.py",
    "agent/graph/nodes/analyzer_mock.py",
    "agent/graph/nodes/standardizer_mock.py",
    "agent/graph/nodes/standardizer_llm.py",
    "agent/graph/nodes/synthesis.py",
    "agent/graph/nodes/global_completion_check.py",
    "agent/graph/nodes/module_coordinator.py",
    "agent/graph/nodes/module/module_planner.py",
    "agent/graph/nodes/module/module_reflector.py",
    "agent/graph/nodes/module/module_completion_check.py",
    "agent/graph/nodes/module/execution_gate.py",
]

# A raw WB/OEE Tool implementation module -- importing one of these (as
# opposed to the generic agent.tools.base/models/registry/execution_manager
# Protocol/plumbing layer) is what this invariant actually forbids.
_FORBIDDEN_IMPORT_PREFIXES = ("agent.tools.wb", "agent.tools.oee", "agent.domain.wb.datasource", "agent.domain.oee.datasource")


def _parse(path: Path) -> ast.Module:
    return ast.parse(path.read_text(encoding="utf-8"), filename=str(path))


def _imported_module_names(tree: ast.Module) -> set[str]:
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            names.add(node.module)
    return names


def _run_call_sites(tree: ast.Module) -> list[int]:
    """Line numbers of every `<something>.run(...)` call expression --
    AST-level so this can never be fooled by a variable also named `run`
    that isn't a method call, nor tripped by prose mentioning `.run(`."""
    lines = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "run":
            lines.append(node.lineno)
    return lines


def test_no_cognitive_node_imports_a_raw_tool_implementation_module():
    violations = []
    for rel_path in _COGNITIVE_NODE_FILES:
        path = _REPO_ROOT / rel_path
        assert path.exists(), f"expected cognitive node file not found: {rel_path}"
        imported = _imported_module_names(_parse(path))
        for name in imported:
            if any(name == prefix or name.startswith(prefix + ".") for prefix in _FORBIDDEN_IMPORT_PREFIXES):
                violations.append(f"{rel_path} imports raw Tool/DataSource module '{name}'")
    assert not violations, "\n".join(violations)


def test_no_cognitive_node_calls_dot_run():
    violations = []
    for rel_path in _COGNITIVE_NODE_FILES:
        path = _REPO_ROOT / rel_path
        for lineno in _run_call_sites(_parse(path)):
            violations.append(f"{rel_path}:{lineno} calls `.run(...)` -- Tool execution belongs to Executor only")
    assert not violations, "\n".join(violations)


def test_the_scanned_file_list_still_matches_the_real_cognitive_node_layout():
    """Guards against this test silently going stale if a cognitive node
    file is ever renamed/moved without updating _COGNITIVE_NODE_FILES --
    every file under agent/graph/nodes/ that is NOT an execution-layer file
    must appear in the scanned list."""
    execution_layer_basenames = {
        "module_executor.py", "capability_executor.py", "module_subgraph.py", "module_subgraph_node.py",
        "__init__.py", "bootstrap.py", "routing.py",
        "module_dispatch_payload.py",  # a Send() payload model, not a node function (see agent 1's own repo-read finding)
    }
    scanned = {Path(p).name for p in _COGNITIVE_NODE_FILES}
    actual = set()
    for py_file in (_AGENT_ROOT / "graph" / "nodes").rglob("*.py"):
        if py_file.name in execution_layer_basenames:
            continue
        actual.add(py_file.name)
    missing = actual - scanned
    assert not missing, f"cognitive node file(s) not covered by the tool-boundary regression: {missing}"
