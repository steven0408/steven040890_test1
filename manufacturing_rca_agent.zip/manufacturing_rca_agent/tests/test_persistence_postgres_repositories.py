"""Offline repository-contract + SQL-construction tests (item 12) against
`FakeConnection` -- proves each repository method builds the right kind of
statement (upsert vs. append-only-ignore, delete+reinsert for junction
links) and maps parameters correctly, without a real PostgreSQL server.
Full round-trip correctness (a real INSERT reflected by a real SELECT) is
covered separately by the `@pytest.mark.postgres` integration test.
"""
from datetime import datetime, timezone

import pytest

from agent.persistence.postgres.repositories import (
    HumanRequestNotFoundError,
    LearningCandidateNotFoundError,
    PostgresHumanAuditSink,
    PostgresHumanFeedbackSink,
    PostgresLearningCandidateSink,
    PostgresLLMUsageSink,
    PostgresRunEvaluationStore,
    PostgresRunRepository,
    PostgresToolCallAuditSink,
)
from agent.persistence.records import FindingEvidenceLink, FindingRecord, RunRecord
from agent.state.enums import EvidenceQuality, FeedbackTargetType, FindingStatus, HumanDecision, HumanReason, HumanRequestStatus, ObservationStatus, RunTerminationStatus
from agent.state.models import HumanFeedback, HumanRequest, HumanResponse, ResumeTarget
from agent.tools.execution_manager import ToolCallRecord
from tests.postgres_fake import FakeConnection

_TS = datetime(2026, 8, 12, tzinfo=timezone.utc)


# ============================================================================
# RunRepository -- upsert semantics, junction-link replace-on-save
# ============================================================================


def test_save_run_issues_an_upsert_on_run_id():
    conn = FakeConnection()
    repo = PostgresRunRepository(conn)
    record = RunRecord(run_id="run-1", user_request="x", factory_id="f-a", run_status=RunTerminationStatus.READY_FOR_SYNTHESIS, created_at=_TS)
    repo.save_run(record)
    sql, params = conn.executed[0]
    assert "INSERT INTO runs" in sql
    assert "ON CONFLICT (run_id) DO UPDATE SET" in sql
    assert params["run_id"] == "run-1"


def test_save_run_twice_is_idempotent_at_the_sql_level():
    conn = FakeConnection()
    repo = PostgresRunRepository(conn)
    record = RunRecord(run_id="run-1", user_request="x", factory_id="f-a", run_status=RunTerminationStatus.READY_FOR_SYNTHESIS, created_at=_TS)
    repo.save_run(record)
    repo.save_run(record)
    assert len(conn.executed) == 2
    assert conn.executed[0][0] == conn.executed[1][0]  # same upsert statement both times


def test_get_run_returns_none_when_fake_connection_has_no_row():
    conn = FakeConnection()
    repo = PostgresRunRepository(conn)
    assert repo.get_run("missing") is None


def test_read_methods_commit_immediately_so_no_transaction_is_left_dangling():
    """Regression for a real deadlock caught during Phase 8B's local-Postgres
    verification: PostgresRunRepository's connection is shared, non-
    autocommit, with PostgresPersistenceUnitOfWork (see repositories.py's
    own class docstring) -- a read that never commits leaves an implicit
    transaction open indefinitely, which then blocks later DDL/writes on
    ANY connection waiting on the same locks. Every read method must
    commit right after fetching."""
    conn = FakeConnection()
    repo = PostgresRunRepository(conn)
    conn.set_fetchone(None)
    repo.get_run("run-1")
    assert conn.committed is True

    conn2 = FakeConnection()
    repo2 = PostgresRunRepository(conn2)
    conn2.set_fetchall([])
    repo2.list_findings("run-1")
    assert conn2.committed is True


def test_write_methods_do_not_commit_leaving_that_to_the_unit_of_work():
    conn = FakeConnection()
    repo = PostgresRunRepository(conn)
    record = RunRecord(run_id="run-1", user_request="x", factory_id="f-a", run_status=RunTerminationStatus.READY_FOR_SYNTHESIS, created_at=_TS)
    repo.save_run(record)
    assert conn.committed is False  # staged writes stay uncommitted until the UoW commits


def test_get_run_maps_canned_row_back_to_run_record():
    conn = FakeConnection()
    repo = PostgresRunRepository(conn)
    conn.set_fetchone({
        "run_id": "run-1", "user_request": "x", "normalized_request": None, "factory_id": "f-a", "task_type": None,
        "run_status": RunTerminationStatus.READY_FOR_SYNTHESIS.value, "started_at": _TS, "completed_at": _TS,
        "created_at": _TS, "schema_version": "1", "application_version": None,
    })
    record = repo.get_run("run-1")
    assert record.run_id == "run-1"
    assert record.run_status == RunTerminationStatus.READY_FOR_SYNTHESIS


def test_save_finding_replaces_evidence_links_via_delete_then_insert():
    conn = FakeConnection()
    repo = PostgresRunRepository(conn)
    finding = FindingRecord(finding_id="f-1", run_id="run-1", module_id="OEE", statement="s", pattern="p", status=FindingStatus.CONFIRMED, confidence=0.8, is_root_cause=False)
    links = [FindingEvidenceLink(finding_id="f-1", evidence_id="ev-1"), FindingEvidenceLink(finding_id="f-1", evidence_id="ev-2")]
    repo.save_finding(finding, links)
    statements = conn.sql_statements()
    assert "INSERT INTO findings" in statements[0]
    assert statements[1].startswith("DELETE FROM finding_evidence_links")
    assert statements[2].count("INSERT INTO finding_evidence_links") == 1
    assert statements[3].count("INSERT INTO finding_evidence_links") == 1
    assert len(statements) == 4  # finding upsert + delete + 2 link inserts


def test_save_finding_with_no_links_still_clears_old_ones():
    conn = FakeConnection()
    repo = PostgresRunRepository(conn)
    finding = FindingRecord(finding_id="f-1", run_id="run-1", module_id="OEE", statement="s", pattern="p", status=FindingStatus.CONFIRMED, confidence=0.8, is_root_cause=False)
    repo.save_finding(finding, [])
    statements = conn.sql_statements()
    assert len(statements) == 2  # finding upsert + delete, no link inserts


# ============================================================================
# ToolCallAuditSink -- append-only (ON CONFLICT DO NOTHING), item 9's
# logical/manager-invocation/physical-execution fields all threaded through
# ============================================================================


def test_tool_call_record_is_append_only_not_upsert():
    conn = FakeConnection()
    sink = PostgresToolCallAuditSink(conn)
    record = ToolCallRecord(
        tool_call_id="tc-1", run_id="run-1", module_id="OEE", objective_id="obj-1", tool_id="t",
        status=ObservationStatus.SUCCESS, duration_seconds=0.1, started_at=_TS, completed_at=_TS,
        idempotency_key="idem-1", logical_call_id="log-1", attempt_number=1, replayed=False, result_reused=False,
    )
    sink.record(record)
    sql, params = conn.executed[0]
    assert "ON CONFLICT (tool_call_id) DO NOTHING" in sql
    assert params["idempotency_key"] == "idem-1"
    assert params["logical_call_id"] == "log-1"
    assert params["result_reused"] is False


def test_tool_call_list_for_run_queries_by_run_id():
    conn = FakeConnection()
    sink = PostgresToolCallAuditSink(conn)
    conn.set_fetchall([])
    sink.list_for_run("run-1")
    sql, params = conn.executed[0]
    assert "run_id = %(run_id)s" in sql
    assert params == {"run_id": "run-1"}


def test_llm_usage_sink_is_append_only():
    conn = FakeConnection()
    sink = PostgresLLMUsageSink(conn)
    from agent.llm.models import LLMCallRecord, LLMCallStatus

    record = LLMCallRecord(llm_call_id="llm-1", run_id="run-1", node="planner", route="planner", model="m", input_tokens=1, output_tokens=1, latency_ms=1.0, status=LLMCallStatus.SUCCESS, started_at=_TS, completed_at=_TS)
    sink.record(record)
    assert "ON CONFLICT (llm_call_id) DO NOTHING" in conn.executed[0][0]


# ============================================================================
# HumanAuditSink -- response requires a prior request row
# ============================================================================


def _human_request():
    return HumanRequest(
        request_id="hr-1", run_id="run-1", module_id="OEE", objective_id="obj-1", source_node="execution_gate",
        reason=HumanReason.PERMISSION_REQUIRED, question="approve?",
        resume_target=ResumeTarget(module_id="OEE", node="execution_gate", objective_id="obj-1"),
        status=HumanRequestStatus.PENDING, created_at_step=1,
    )


def test_record_response_without_prior_request_raises():
    conn = FakeConnection()
    sink = PostgresHumanAuditSink(conn)
    conn.set_fetchone(None)
    response = HumanResponse(decision=HumanDecision.APPROVE, responded_by="tester", responded_at=_TS)
    with pytest.raises(HumanRequestNotFoundError):
        sink.record_response("hr-missing", response)


def test_record_request_then_record_response_updates_status():
    conn = FakeConnection()
    sink = PostgresHumanAuditSink(conn)
    request = _human_request()
    sink.record_request(request)

    conn.set_fetchone({
        "request_id": "hr-1", "run_id": "run-1", "module_id": "OEE", "branch_id": None, "objective_id": "obj-1",
        "source_node": "execution_gate", "reason": "permission_required", "question": "approve?", "options": None,
        "permission_type": None, "risk_level": None,
        "resume_target": {"module_id": "OEE", "node": "execution_gate", "objective_id": "obj-1"},
        "status": "pending", "created_at_step": 1,
    })
    response = HumanResponse(decision=HumanDecision.APPROVE, responded_by="tester", responded_at=_TS)
    sink.record_response("hr-1", response)
    statements = conn.sql_statements()
    assert any(s.startswith("INSERT INTO human_runtime_responses") for s in statements)
    assert any(s.startswith("UPDATE human_runtime_requests SET status") for s in statements)


# ============================================================================
# HumanFeedbackSink -- append-only, target_id IS NULL handled explicitly
# ============================================================================


def test_human_feedback_record_is_append_only():
    conn = FakeConnection()
    sink = PostgresHumanFeedbackSink(conn)
    feedback = HumanFeedback(feedback_id="fb-1", run_id="run-1", target_type=FeedbackTargetType.RUN, created_at=_TS)
    sink.record(feedback)
    assert "ON CONFLICT (feedback_id) DO NOTHING" in conn.executed[0][0]


def test_human_feedback_list_for_target_with_none_target_id_uses_is_null():
    conn = FakeConnection()
    sink = PostgresHumanFeedbackSink(conn)
    conn.set_fetchall([])
    sink.list_for_target("run-1", FeedbackTargetType.RUN, None)
    sql, params = conn.executed[0]
    assert "target_id IS NULL" in sql
    assert "target_id" not in params


def test_human_feedback_latest_for_target_picks_max_created_at():
    conn = FakeConnection()
    sink = PostgresHumanFeedbackSink(conn)
    older = {
        "feedback_id": "fb-1", "run_id": "run-1", "target_type": "run", "target_id": None, "user_id": None,
        "thumbs": "none", "answer_helpful": None, "root_cause_correct": None, "finding_correct": None,
        "recommendation_useful": None, "comment": None, "source": None, "session_id": None, "feedback_version": "1",
        "created_at": datetime(2026, 8, 1, tzinfo=timezone.utc),
    }
    newer = {**older, "feedback_id": "fb-2", "created_at": datetime(2026, 8, 10, tzinfo=timezone.utc)}
    conn.set_fetchall([older, newer])
    latest = sink.latest_for_target("run-1", FeedbackTargetType.RUN, None)
    assert latest.feedback_id == "fb-2"


# ============================================================================
# LearningCandidateSink -- update() requires an existing row
# ============================================================================


def _candidate_row(candidate_id="cand-1", status="candidate"):
    return {
        "candidate_id": candidate_id, "candidate_type": "capability_gap", "title": "t", "statement": "s",
        "status": status, "confidence": 0.5, "source_run_ids": [], "source_module_ids": [],
        "supporting_finding_ids": [], "supporting_root_cause_ids": [], "evaluation_issue_ids": [],
        "feedback_issue_ids": [], "planner_decision_record_ids": [], "supporting_signal_count": 0,
        "contradicting_signal_count": 0, "created_at": _TS, "updated_at": _TS, "scope": "factory-a",
        "proposed_destination": "capability_backlog", "candidate_key": "key-1", "rationale_summary": "r",
        "schema_version": "1",
    }


def test_update_nonexistent_candidate_raises():
    conn = FakeConnection()
    sink = PostgresLearningCandidateSink(conn)
    conn.set_fetchone(None)
    from agent.learning.sink import InMemoryLearningCandidateSink  # only for constructing a valid LearningCandidate below
    from agent.state.enums import LearningCandidateType, LearningDestination
    from agent.state.models import LearningCandidate

    candidate = LearningCandidate(
        candidate_id="cand-missing", candidate_type=LearningCandidateType.CAPABILITY_GAP, title="t", statement="s",
        confidence=0.5, created_at=_TS, updated_at=_TS, scope="factory-a",
        proposed_destination=LearningDestination.CAPABILITY_BACKLOG, candidate_key="key-missing", rationale_summary="r",
    )
    with pytest.raises(LearningCandidateNotFoundError):
        sink.update(candidate)


def test_record_uses_insert_ignore_update_uses_upsert():
    conn = FakeConnection()
    sink = PostgresLearningCandidateSink(conn)
    from agent.state.enums import LearningCandidateType, LearningDestination
    from agent.state.models import LearningCandidate

    candidate = LearningCandidate(
        candidate_id="cand-1", candidate_type=LearningCandidateType.CAPABILITY_GAP, title="t", statement="s",
        confidence=0.5, created_at=_TS, updated_at=_TS, scope="factory-a",
        proposed_destination=LearningDestination.CAPABILITY_BACKLOG, candidate_key="key-1", rationale_summary="r",
    )
    sink.record(candidate)
    assert "ON CONFLICT (candidate_id) DO NOTHING" in conn.executed[0][0]

    conn.set_fetchone(_candidate_row())
    sink.update(candidate)
    assert "ON CONFLICT (candidate_id) DO UPDATE SET" in conn.executed[-1][0]


# ============================================================================
# RunEvaluationStore -- upsert + issues replaced (delete+reinsert) per save()
# ============================================================================


def test_run_evaluation_save_replaces_issues():
    conn = FakeConnection()
    store = PostgresRunEvaluationStore(conn)
    from tests.test_persistence_postgres_mapping import _run_evaluation

    evaluation = _run_evaluation()
    store.save(evaluation)
    statements = conn.sql_statements()
    assert "ON CONFLICT (evaluation_id) DO UPDATE SET" in statements[0]
    assert statements[1].startswith("DELETE FROM evaluation_issues")
    assert len(statements) == 2  # no issues on this fixture -- upsert + delete only, no inserts
