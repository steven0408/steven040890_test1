"""Phase PROD-1.1: offline tests for agent/llm/token_budget.py (profile/
estimator primitives) and agent/llm/schema_compaction.py."""
import pytest

from agent.llm.schema_compaction import compact_json_schema
from agent.llm.token_budget import (
    ApproximateTokenEstimator,
    LLMContextProfile,
    RouteTokenBudget,
)
from agent.state.base import RCABaseModel


def test_approximate_estimator_is_conservative_not_exact():
    estimator = ApproximateTokenEstimator()
    text = "x" * 100
    tokens = estimator.estimate_text(text)
    # chars/3.5 rounded up -- not equal to any "exact" tokenizer's count,
    # explicitly documented as an approximation.
    assert tokens == 29
    assert estimator.estimate_text("") == 0


def test_estimate_messages_includes_per_message_overhead():
    from agent.llm.models import LLMMessage, LLMRole

    estimator = ApproximateTokenEstimator()
    messages = [LLMMessage(role=LLMRole.SYSTEM, content="hello"), LLMMessage(role=LLMRole.USER, content="world")]
    total = estimator.estimate_messages(messages)
    assert total > estimator.estimate_text("hello") + estimator.estimate_text("world")


def test_route_token_budget_rejects_minimum_exceeding_max():
    with pytest.raises(ValueError):
        RouteTokenBudget(max_output_tokens=100, minimum_output_tokens=200)


def test_context_profile_available_input_tokens():
    profile = LLMContextProfile(
        context_window_tokens=2048,
        route_budgets={"planner": RouteTokenBudget(max_output_tokens=600, minimum_output_tokens=150, safety_margin_tokens=64)},
    )
    assert profile.available_input_tokens("planner") == 2048 - 600 - 64


def test_context_profile_falls_back_to_default_route_budget():
    profile = LLMContextProfile(context_window_tokens=2048)
    # "unknown" route has no explicit entry -- uses default_route_budget
    assert profile.available_input_tokens("unknown") == 2048 - profile.default_route_budget.max_output_tokens - profile.default_route_budget.safety_margin_tokens


def test_minimum_viable_window_is_schema_independent_floor():
    profile = LLMContextProfile(
        context_window_tokens=2048,
        route_budgets={"planner": RouteTokenBudget(max_output_tokens=600, minimum_output_tokens=150, safety_margin_tokens=64)},
    )
    assert profile.minimum_viable_window("planner") == 150 + 64


# ============================================================================
# compact_json_schema
# ============================================================================


class _DocumentedModel(RCABaseModel):
    """This docstring must not leak into the compacted schema."""

    name: str
    count: int = 0


def test_compact_schema_strips_title_and_description():
    schema = compact_json_schema(_DocumentedModel)
    assert "title" not in schema
    assert "description" not in schema
    dumped = str(schema)
    assert "must not leak" not in dumped


def test_compact_schema_preserves_structural_constraints():
    schema = compact_json_schema(_DocumentedModel)
    assert schema["type"] == "object"
    assert schema["properties"]["name"]["type"] == "string"
    assert schema["properties"]["count"]["type"] == "integer"
    assert "name" in schema["required"]


def test_compact_schema_strips_nested_defs_too():
    class Inner(RCABaseModel):
        """Inner docstring, also must not leak."""

        x: int

    class Outer(RCABaseModel):
        """Outer docstring."""

        inner: Inner

    schema = compact_json_schema(Outer)
    dumped = str(schema)
    assert "must not leak" not in dumped
    assert "Outer docstring" not in dumped
    # $defs structure itself is preserved (still resolvable/valid JSON Schema)
    assert "$defs" in schema or "definitions" in schema


def test_compact_schema_accepts_a_prebuilt_dict_too():
    raw = {"title": "X", "description": "y", "type": "object", "properties": {"a": {"type": "string", "title": "A"}}}
    compacted = compact_json_schema(raw)
    assert "title" not in compacted
    assert "description" not in compacted
    assert "title" not in compacted["properties"]["a"]
    assert compacted["properties"]["a"]["type"] == "string"


def test_compact_schema_is_meaningfully_smaller():
    """Not a specific ratio requirement -- just proves compaction actually
    reduces size for a realistically-documented model (this codebase's own
    RCABaseModel subclasses tend to carry long docstrings)."""
    import json

    class VerboseModel(RCABaseModel):
        """This is a long docstring explaining design rationale across
        several sentences, exactly the shape every cognitive-output model
        in this codebase (PlannerDecision, ReflectionDecision, ...)
        actually has -- several hundred characters of prose that Pydantic
        would otherwise embed verbatim into the JSON Schema's own
        `description` field, on every request, forever."""

        field_one: str
        field_two: int

    raw_size = len(json.dumps(VerboseModel.model_json_schema()))
    compact_size = len(json.dumps(compact_json_schema(VerboseModel)))
    assert compact_size < raw_size
