"""Phase PROD-1 items 65/66: static/AST-level regression guards --
`agent_api/` must never import concrete WB/OEE Tool or Policy modules
(only the generic composition entrypoints), and no production source file
(agent/ or agent_api/) may contain a literal formal-infrastructure host/
port/credential string.
"""
import ast
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
_AGENT_API_DIR = _REPO_ROOT / "agent_api"
_AGENT_DIR = _REPO_ROOT / "agent"

_FORBIDDEN_INFRA_STRINGS = ["10.11.32.179", "10.11.33.5", "postgres:postgres", "18050", "18058", "9120"]

_FORBIDDEN_AGENT_API_IMPORT_PREFIXES = ("agent.tools.wb", "agent.planning.policies.wb", "agent.tools.oee", "agent.planning.policies.oee")


def _python_files(directory: Path):
    return list(directory.rglob("*.py"))


def test_agent_api_never_imports_concrete_wb_or_oee_tool_or_policy_modules():
    for path in _python_files(_AGENT_API_DIR):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                assert not node.module.startswith(_FORBIDDEN_AGENT_API_IMPORT_PREFIXES), f"{path} imports from '{node.module}' -- business logic leaking into the API layer"
            if isinstance(node, ast.Import):
                for alias in node.names:
                    assert not alias.name.startswith(_FORBIDDEN_AGENT_API_IMPORT_PREFIXES), f"{path} imports '{alias.name}' -- business logic leaking into the API layer"


def test_no_hardcoded_formal_infrastructure_string_in_agent_or_agent_api_source():
    for directory in (_AGENT_DIR, _AGENT_API_DIR):
        for path in _python_files(directory):
            text = path.read_text(encoding="utf-8")
            for forbidden in _FORBIDDEN_INFRA_STRINGS:
                assert forbidden not in text, f"{path} contains forbidden literal infrastructure string '{forbidden}'"


def test_no_hardcoded_formal_infrastructure_string_in_deployment_files():
    for filename in ("Dockerfile", ".env.example"):
        path = _REPO_ROOT / filename
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8")
        for forbidden in _FORBIDDEN_INFRA_STRINGS:
            assert forbidden not in text, f"{path} contains forbidden literal infrastructure string '{forbidden}'"
