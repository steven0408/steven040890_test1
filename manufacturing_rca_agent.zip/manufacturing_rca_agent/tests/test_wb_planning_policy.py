"""Phase WB-2C item D/E/F + Golden Cases A-F: WBPlanningPolicy exercised
through the REAL Module ReAct Subgraph (multi-round, real Planner/Gate/
Executor/Reflector/CompletionCheck nodes) -- not a bypassed unit call.
This is a module-subgraph-level test (below the Analyzer), so it builds
`ModuleTask.goal_statement` directly rather than going through a scripted
Analyzer decision -- the real Analyzer->ModuleTask->ModuleGoal propagation
path is proven separately by tests/test_wb_parent_graph_e2e.py (Phase
WB-2C.1). All offline.
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.domain.wb.synthetic import GOLDEN_DATE
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.modules.wb.package import build_wb_module_package
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import EntityAnalysisStatus, FindingStatus, ModuleStatus, TaskType
from agent.state.models import ModuleState, ModuleTask
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry


def _run_wb(task_type: TaskType, thread_id: str, statement: str) -> ModuleState:
    package = build_wb_module_package()
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    runtime = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)

    policy = WBPlanningPolicy()
    graph = build_module_react_subgraph(policy, capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id="WB", module_type="WB", reason="WB relevant to this request.", goal_statement=statement, confidence=0.9, priority=0.9, task_type=task_type)
    initial = build_initial_module_state(task, package.budget, run_id=f"run-{thread_id}", task_type=task_type)

    config = {"configurable": {"thread_id": thread_id}}
    result = app.invoke(initial, config=config)
    return ModuleState.model_validate(result)


# ============================================================================
# D/E: INFORMATION does minimum depth, ANALYSIS doesn't over-reach
# ============================================================================


def test_information_dispatches_exactly_one_objective():
    final_state = _run_wb(TaskType.INFORMATION, "info-min-depth", "2026-08-12 ASE01 OEE狀況")
    assert len(final_state.objective_history) == 1
    assert final_state.status == ModuleStatus.COMPLETE


def test_analysis_does_not_drill_down_to_rca_depth():
    final_state = _run_wb(TaskType.ANALYSIS, "analysis-no-rca", "2026-08-12 哪個 Plant OEE 最差？主要 loss")
    assert len(final_state.objective_history) == 1
    assert final_state.status == ModuleStatus.COMPLETE
    for record in final_state.objective_history.values():
        assert record.action.value != "drill_down"


# ============================================================================
# Golden Cases A-E (item 31)
# ============================================================================


def test_case_a_oee_information():
    final_state = _run_wb(TaskType.INFORMATION, "case-a", "2026-08-12 ASE01 OEE狀況")
    assert final_state.status == ModuleStatus.COMPLETE
    record = next(iter(final_state.objective_history.values()))
    assert record.capability_key == "wb.oee.plant_status"
    assert record.target_ref.ref_id == "ASE01"
    finding = final_state.findings[-1]
    assert "58.0" in finding.statement
    assert finding.is_root_cause is False


def test_case_b_oee_analysis():
    final_state = _run_wb(TaskType.ANALYSIS, "case-b", "2026-08-12 哪個 Plant OEE 最差？主要 loss 是什麼？")
    assert final_state.status == ModuleStatus.COMPLETE
    record = next(iter(final_state.objective_history.values()))
    assert record.capability_key == "wb.oee.status_analysis"
    finding = final_state.findings[-1]
    assert "ASE01" in finding.statement
    assert "downtime" in finding.statement
    assert finding.is_root_cause is False


def test_case_c_bank_information():
    final_state = _run_wb(TaskType.INFORMATION, "case-c", "2026-08-12 ASE07 BANK狀況")
    assert final_state.status == ModuleStatus.COMPLETE
    record = next(iter(final_state.objective_history.values()))
    assert record.capability_key == "wb.bank.status_summary"
    assert record.target_ref.ref_id == "ASE07"
    finding = final_state.findings[-1]
    assert "7" in finding.statement


def test_case_d_wip_hold_analysis():
    final_state = _run_wb(TaskType.ANALYSIS, "case-d", "2026-08-12 ASE03 Hold狀況")
    assert final_state.status == ModuleStatus.COMPLETE
    record = next(iter(final_state.objective_history.values()))
    assert record.capability_key == "wb.wip.hold_analysis"
    assert record.target_ref.ref_id == "ASE03"
    finding = final_state.findings[-1]
    assert "22/30" in finding.statement
    assert "73.3%" in finding.statement


def test_case_e_output_comparison():
    final_state = _run_wb(TaskType.ANALYSIS, "case-e", "2026-08-12 哪個 Plant Output 最低")
    assert final_state.status == ModuleStatus.COMPLETE
    record = next(iter(final_state.objective_history.values()))
    assert record.capability_key == "wb.output.comparison"
    finding = final_state.findings[-1]
    assert finding.is_root_cause is False


# ============================================================================
# Case F (item 32): missing data
# ============================================================================


def test_case_f_missing_oee_data_does_not_fake_a_zero_answer():
    final_state = _run_wb(TaskType.INFORMATION, "case-f", "2026-08-12 ASE08 OEE")

    # Never a fabricated "OEE=0" or "normal" claim
    for finding in final_state.findings:
        assert "OEE = 0" not in finding.statement
        assert "OEE=0" not in finding.statement

    last_finding = final_state.findings[-1]
    assert "No data" in last_finding.statement
    assert last_finding.is_root_cause is False

    # item 20/21: a legitimately-empty result must not silently COMPLETE
    # as if the goal were satisfied.
    assert final_state.status in (ModuleStatus.PARTIAL, ModuleStatus.FAILED)
    assert final_state.status != ModuleStatus.COMPLETE


def test_case_f_final_status_is_partial_because_a_descriptive_finding_exists():
    """See the Phase WB-2C report's explanation: `module_completion_check`'s
    existing generic rule is `PARTIAL if module_state.findings else FAILED`
    once NO_VIABLE_OBJECTIVE is reached -- and Reflector always records a
    Finding on a SUCCESS observation (even a `SUCCESS + is_empty=True`
    one), so this "we tried and there's no data" case naturally resolves
    to PARTIAL through the existing generic rule, without this phase
    touching CompletionCheck at all."""
    final_state = _run_wb(TaskType.INFORMATION, "case-f-status", "2026-08-12 ASE08 OEE")
    assert final_state.status == ModuleStatus.PARTIAL
    assert len(final_state.findings) >= 1
    assert final_state.findings[-1].status == FindingStatus.HYPOTHESIS  # never CONFIRMED for a no-data round


def test_case_f_entity_states_still_seeded_even_on_missing_data_path():
    final_state = _run_wb(TaskType.INFORMATION, "case-f-entities", "2026-08-12 ASE08 OEE")
    assert "ASE08" in final_state.entity_states
    assert final_state.entity_states["ASE08"].status == EntityAnalysisStatus.SCREENED
