"""Phase WB-2B.1: the full
`Objective -> CapabilityResolver -> Skill -> SkillRunner ->
ToolExecutionManager -> WB Tool -> WB DataSource -> Evidence` trace,
Evidence lineage, and WB Capability Routing Cases 1-5 (item U) -- all
through REAL production WB Skill definitions this time (unlike Phase
WB-2B, which needed a test-only action override since production skills
had `actions: []`; this phase gave every WB Skill a real generic action +
capability_key, so CapabilityResolver now resolves them for real).
"""
import pytest

from agent.capability.resolver import CapabilityResolutionError, CapabilityResolver
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime, make_capability_module_executor
from agent.domain.wb.synthetic import GOLDEN_DATE, SCENARIO_A_PLANT, SCENARIO_B_PLANT, SCENARIO_C_PLANT
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.planning.policies.llm import PlannerSemanticValidationError, validate_planner_decision
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.skills.wb.registration import register_wb_skills
from agent.state.enums import ErrorType, EvidenceQuality, ObjectiveAction, ObservationStatus, TargetRefType, TaskType
from agent.state.models import Objective, TargetRef
from agent.state.payload import PayloadRegistry
from agent.state.scope import ObjectiveScope, ScopeFilter, ScopeOperator, TimeScope, TimeScopeKind
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry
from agent.tools.wb.registration import register_wb_tools

from .conftest import make_module_state, make_wb_datasources


def _skill_registry() -> SkillRegistry:
    registry = SkillRegistry()
    register_wb_skills(registry)
    return registry


def _tool_registry() -> ToolRegistry:
    registry = ToolRegistry()
    register_wb_tools(registry, datasources=make_wb_datasources())
    return registry


def _entity_scope(plant: str, *, time_kind: TimeScopeKind, date_value) -> ObjectiveScope:
    return ObjectiveScope(
        time=TimeScope(kind=time_kind, date=date_value),
        filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value=plant)],
    )


def _entity_objective(objective_id: str, plant: str, *, action: ObjectiveAction, capability_key: str, time_kind: TimeScopeKind, date_value) -> Objective:
    return Objective(
        objective_id=objective_id, description=f"scoped to {plant}", action=action, capability_key=capability_key,
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id=plant),
        scope=_entity_scope(plant, time_kind=time_kind, date_value=date_value),
        expected_output="status", priority_score=1.0,
    )


def _module_objective(objective_id: str, *, action: ObjectiveAction, capability_key: str, scope: ObjectiveScope | None = None) -> Objective:
    return Objective(
        objective_id=objective_id, description="module-wide", action=action, capability_key=capability_key,
        target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="WB"), scope=scope,
        expected_output="status", priority_score=1.0,
    )


def _runtime():
    tool_registry = _tool_registry()
    resolver = CapabilityResolver(_skill_registry(), tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    return ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)


def _wb_module_state(objective, task_type: TaskType):
    """`make_module_state`'s own default goal.task_type is RCA (shared
    with the OEE test fixtures) -- WB Skills each declare a specific
    task_types list (e.g. `wb.bank_status_summary` is information-only),
    so CapabilityResolver needs the module_state's task_type to actually
    match the Skill being exercised."""
    state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    return state.model_copy(update={"current_objective": objective, "goal": state.goal.model_copy(update={"task_type": task_type})})


# ============================================================================
# WB Capability Routing -- Cases 1-4 (item U), through the REAL production
# Skill/action/capability_key definitions, via CapabilityResolver directly
# ============================================================================


def test_case1_wip_hold_resolves_to_wip_hold_analysis_only():
    resolver = CapabilityResolver(_skill_registry(), _tool_registry())
    objective = _entity_objective(
        "obj-1", SCENARIO_C_PLANT, action=ObjectiveAction.ANALYZE, capability_key="wb.wip.hold_analysis",
        time_kind=TimeScopeKind.SNAPSHOT_DATE, date_value=GOLDEN_DATE,
    )
    resolved = resolver.resolve(objective, "wb", TaskType.ANALYSIS)
    assert resolved.selected_skill.skill_id == "wb.wip_hold_analysis"


def test_case1_full_trace_produces_22_of_30_hold():
    runtime = _runtime()
    objective = _entity_objective(
        "obj-1", SCENARIO_C_PLANT, action=ObjectiveAction.ANALYZE, capability_key="wb.wip.hold_analysis",
        time_kind=TimeScopeKind.SNAPSHOT_DATE, date_value=GOLDEN_DATE,
    )
    resolved = runtime.capability_resolver.resolve(objective, "wb", TaskType.ANALYSIS)
    outcome = runtime.skill_runner.run(resolved.selected_skill, objective, make_module_state(module_id="WB", module_type="WB", run_id="run-1"))
    payload = PayloadRegistry.unpack(outcome.result.output_payload)
    assert payload.hold_lot_count == 22
    assert payload.total_lot_count == 30
    assert abs(payload.hold_ratio - 0.7333) < 0.001


def test_case2_oee_status_resolves_and_produces_58_downtime():
    """Module-wide ranking (WB-2C Case B: "哪個 Plant OEE 最差？")."""
    runtime = _runtime()
    objective = _module_objective(
        "obj-2", action=ObjectiveAction.ANALYZE, capability_key="wb.oee.status_analysis",
        scope=ObjectiveScope(time=TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, date=GOLDEN_DATE)),
    )
    resolved = runtime.capability_resolver.resolve(objective, "wb", TaskType.ANALYSIS)
    assert resolved.selected_skill.skill_id == "wb.oee_status_analysis"
    outcome = runtime.skill_runner.run(resolved.selected_skill, objective, make_module_state(module_id="WB", module_type="WB", run_id="run-1"))
    payload = PayloadRegistry.unpack(outcome.result.output_payload)
    assert payload.ranking[0].oee == 58.0
    assert payload.ranking[0].dominant_loss_category == "downtime"


def test_case2b_oee_plant_status_single_plant_lookup():
    """Entity-scoped lookup (WB-2C Case A: "2026-08-12 ASE01 OEE 是多少？")."""
    runtime = _runtime()
    objective = _entity_objective(
        "obj-2b", SCENARIO_A_PLANT, action=ObjectiveAction.SUMMARIZE, capability_key="wb.oee.plant_status",
        time_kind=TimeScopeKind.PRODUCTION_DATE, date_value=GOLDEN_DATE,
    )
    resolved = runtime.capability_resolver.resolve(objective, "wb", TaskType.INFORMATION)
    assert resolved.selected_skill.skill_id == "wb.oee_plant_status"
    outcome = runtime.skill_runner.run(resolved.selected_skill, objective, make_module_state(module_id="WB", module_type="WB", run_id="run-1"))
    payload = PayloadRegistry.unpack(outcome.result.output_payload)
    assert {r.plant_id for r in payload.ranking} == {SCENARIO_A_PLANT}
    assert payload.ranking[0].oee == 58.0


def test_case3_output_comparison_resolves_and_ranks_plants():
    runtime = _runtime()
    objective = _module_objective(
        "obj-3", action=ObjectiveAction.COMPARE, capability_key="wb.output.comparison",
        scope=ObjectiveScope(time=TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, date=GOLDEN_DATE)),
    )
    resolved = runtime.capability_resolver.resolve(objective, "wb", TaskType.ANALYSIS)
    assert resolved.selected_skill.skill_id == "wb.output_comparison"
    outcome = runtime.skill_runner.run(resolved.selected_skill, objective, make_module_state(module_id="WB", module_type="WB", run_id="run-1"))
    payload = PayloadRegistry.unpack(outcome.result.output_payload)
    assert len(payload.comparison) == 5  # every plant ranked
    assert payload.lowest is not None and payload.highest is not None


def test_case4_bank_status_resolves_and_produces_material_shortage_7_of_10():
    runtime = _runtime()
    objective = _entity_objective(
        "obj-4", SCENARIO_B_PLANT, action=ObjectiveAction.SUMMARIZE, capability_key="wb.bank.status_summary",
        time_kind=TimeScopeKind.SNAPSHOT_DATE, date_value=GOLDEN_DATE,
    )
    resolved = runtime.capability_resolver.resolve(objective, "wb", TaskType.INFORMATION)
    assert resolved.selected_skill.skill_id == "wb.bank_status_summary"
    outcome = runtime.skill_runner.run(resolved.selected_skill, objective, make_module_state(module_id="WB", module_type="WB", run_id="run-1"))
    payload = PayloadRegistry.unpack(outcome.result.output_payload)
    counts = {c.status.value: c.count for c in payload.by_status}
    assert counts["material_shortage"] == 7
    assert payload.total_count == 10


def test_capability_key_disambiguates_between_similarly_shaped_wb_skills():
    """The exact ambiguity item D warns against: an ANALYZE objective for
    `wb.wip.hold_analysis` must never resolve to `wb.bank.aging_analysis`
    (same domain, same generic action) just because both are WB/ANALYZE."""
    resolver = CapabilityResolver(_skill_registry(), _tool_registry())
    objective = _entity_objective(
        "obj-x", SCENARIO_C_PLANT, action=ObjectiveAction.ANALYZE, capability_key="wb.wip.hold_analysis",
        time_kind=TimeScopeKind.SNAPSHOT_DATE, date_value=GOLDEN_DATE,
    )
    resolved = resolver.resolve(objective, "wb", TaskType.ANALYSIS)
    assert resolved.selected_skill.skill_id not in {"wb.bank_aging_analysis", "wb.wip_status_summary"}
    assert resolved.selected_skill.skill_id == "wb.wip_hold_analysis"


# ============================================================================
# Case 5 (item U): missing date -- semantic validation rejects BEFORE Tool execution
# ============================================================================


def test_case5_missing_date_rejected_by_semantic_validation_before_tool_execution():
    proposal = ObjectiveProposal(
        action=ObjectiveAction.SUMMARIZE, capability_key="wb.oee.plant_status",
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id=SCENARIO_A_PLANT),
        scope=ObjectiveScope(filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value=SCENARIO_A_PLANT)]),  # no time!
        description="missing date", expected_output="status",
    )
    decision = PlannerDecision(decision=PlannerDecisionType.DISPATCH, next_objective=proposal, priority=1.0, rationale_summary="x")
    from agent.planning.policies.wb import build_wb_initial_entity_states

    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    module_state = module_state.model_copy(update={
        "goal": module_state.goal.model_copy(update={"task_type": TaskType.INFORMATION}),
        "entity_states": build_wb_initial_entity_states(),  # so this test isolates the scope failure, not an entity-existence failure
    })

    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=module_state, task_type=TaskType.INFORMATION, skill_registry=_skill_registry())


# ============================================================================
# Full trace via make_capability_module_executor + Evidence lineage
# ============================================================================


def test_full_trace_objective_to_capability_resolver_to_skill_to_evidence():
    runtime = _runtime()
    executor = make_capability_module_executor(runtime)
    objective = _entity_objective(
        "obj-full", SCENARIO_B_PLANT, action=ObjectiveAction.SUMMARIZE, capability_key="wb.bank.status_summary",
        time_kind=TimeScopeKind.SNAPSHOT_DATE, date_value=GOLDEN_DATE,
    )
    module_state = _wb_module_state(objective, TaskType.INFORMATION)

    updates = executor(module_state)

    assert len(updates["observations"]) == 1
    assert updates["observations"][0].status == ObservationStatus.SUCCESS

    assert len(updates["evidence"]) == 1
    evidence = updates["evidence"][0]
    assert evidence.objective_id == objective.objective_id
    assert evidence.quality == EvidenceQuality.STRONG
    assert evidence.structured_payload is not None

    payload = PayloadRegistry.unpack(evidence.structured_payload)
    assert payload.total_count == 10
    assert payload.availability.freshness is not None  # freshness/availability lineage preserved end to end
    assert payload.scope is not None

    assert len(updates["tool_calls"]) == 1  # one Skill step -> one physical Tool call, audited
    assert updates["budget"].used_tool_calls == 1


def test_evidence_never_dumps_unbounded_raw_records():
    """Item 8's own concern: since every WB Skill's single step wraps a
    Summarize/Analyze Tool (never a bare Query Tool), Evidence.structured_payload
    is always a bounded, aggregated result -- never an unfiltered raw
    record list. Confirmed here against the largest dataset (WIP, 300
    synthetic records) via the WIP Hold Skill."""
    runtime = _runtime()
    executor = make_capability_module_executor(runtime)
    objective = _entity_objective(
        "obj-wip", SCENARIO_C_PLANT, action=ObjectiveAction.ANALYZE, capability_key="wb.wip.hold_analysis",
        time_kind=TimeScopeKind.SNAPSHOT_DATE, date_value=GOLDEN_DATE,
    )
    module_state = _wb_module_state(objective, TaskType.ANALYSIS)
    updates = executor(module_state)

    payload = PayloadRegistry.unpack(updates["evidence"][0].structured_payload)
    assert not hasattr(payload, "records")  # WBHoldAnalysisResult has no raw-records field at all
    assert payload.total_lot_count > 0  # the aggregate is still fully informative


def test_evidence_quality_is_always_strong_on_success_regardless_of_tool_quality():
    """Known, pre-existing (not WB-introduced) nuance worth flagging in
    the report: `capability_executor.py`'s Evidence-building always writes
    `EvidenceQuality.STRONG` on a successful Skill run, even when the
    underlying ToolExecutionResult.quality was WEAK (empty result). The
    real "is this substantive" signal survives only inside
    `structured_payload.availability.is_empty`."""
    runtime = _runtime()
    executor = make_capability_module_executor(runtime)
    objective = _entity_objective(
        "obj-empty", "ASE99", action=ObjectiveAction.SUMMARIZE, capability_key="wb.bank.status_summary",
        time_kind=TimeScopeKind.SNAPSHOT_DATE, date_value=GOLDEN_DATE,
    )
    module_state = _wb_module_state(objective, TaskType.INFORMATION)
    updates = executor(module_state)

    evidence = updates["evidence"][0]
    payload = PayloadRegistry.unpack(evidence.structured_payload)
    assert payload.availability.is_empty is True  # genuinely empty
    assert evidence.quality == EvidenceQuality.STRONG  # yet Evidence.quality doesn't reflect that -- must read the payload


def test_capability_not_found_is_distinguishable_from_a_resolved_but_erroring_skill():
    """A missing capability (no matching Skill) and a resolved Skill whose
    Tool call failed must produce different, typed ErrorTypes at the
    Observation layer -- never conflated."""
    empty_skill_registry = SkillRegistry()  # no WB skills registered at all
    tool_registry = _tool_registry()
    resolver = CapabilityResolver(empty_skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    runtime = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)
    executor = make_capability_module_executor(runtime)

    objective = _module_objective("obj-cnf", action=ObjectiveAction.SUMMARIZE, capability_key="wb.bank.status_summary")
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1").model_copy(update={"current_objective": objective})
    updates = executor(module_state)

    observation = updates["observations"][0]
    assert observation.status == ObservationStatus.ERROR
    assert observation.error.error_type == ErrorType.CAPABILITY_NOT_FOUND
    assert "evidence" not in updates


def test_wrong_capability_key_for_domain_is_not_resolvable():
    """An OEE capability_key requested against the WB module must not
    resolve -- domain narrowing happens before capability_key matching."""
    resolver = CapabilityResolver(_skill_registry(), _tool_registry())
    objective = _module_objective("obj-wrong", action=ObjectiveAction.SUMMARIZE, capability_key="oee.current_status")
    with pytest.raises(CapabilityResolutionError):
        resolver.resolve(objective, "wb", TaskType.INFORMATION)
