"""Phase 5C-2 / WB-2B.1: validate_planner_decision -- semantic validation
beyond pydantic schema validation. Generic (DISPATCH/NO_VIABLE_OBJECTIVE
shape, priority range), state-aware (target must exist in this module,
action must match the resolved capability's target shape, no repeating an
already-closed objective), capability-aware (capability_key must resolve
to a registered Skill valid for this domain/task_type/action), and
TaskType-aware (which generic ObjectiveActions each TaskType permits)
checks.
"""
import pytest

from agent.planning.policies.llm import PlannerSemanticValidationError, validate_planner_decision
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.state.enums import EntityAnalysisStatus, ObjectiveAction, ObjectiveStatus, TargetRefType, TaskType
from agent.state.models import EntityState, ObjectiveRecord, TargetRef

from .conftest import make_module_state, make_oee_skill_registry

_SCREENING_KEY = "oee.equipment_screening"
_DETAIL_KEY = "oee.equipment_detail"
_STATUS_KEY = "oee.current_status"


def _skills():
    return make_oee_skill_registry()


def _module_state_with_eq001():
    state = make_module_state()
    entity_states = {
        "EQ001": EntityState(entity_id="EQ001", entity_type="EQUIPMENT", status=EntityAnalysisStatus.SCREENED, current_tree_node_id="n1", branch_id="branch-availability", priority_score=0.9),
    }
    return state.model_copy(update={"entity_states": entity_states})


def _proposal(action, ref_type, ref_id, capability_key=None):
    return ObjectiveProposal(action=action, capability_key=capability_key, target_ref=TargetRef(ref_type=ref_type, ref_id=ref_id), description="d", expected_output="eo")


def _dispatch(action, ref_type, ref_id, capability_key=None, priority=1.0):
    return PlannerDecision(decision=PlannerDecisionType.DISPATCH, next_objective=_proposal(action, ref_type, ref_id, capability_key), priority=priority, rationale_summary="x")


# ============================================================================
# Generic
# ============================================================================


def test_dispatch_without_next_objective_rejected():
    decision = PlannerDecision(decision=PlannerDecisionType.DISPATCH, next_objective=None, rationale_summary="x")
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=make_module_state(), task_type=TaskType.RCA, skill_registry=_skills())


def test_no_viable_objective_with_next_objective_rejected():
    decision = PlannerDecision(
        decision=PlannerDecisionType.NO_VIABLE_OBJECTIVE,
        next_objective=_proposal(ObjectiveAction.SUMMARIZE, TargetRefType.MODULE, "OEE", _STATUS_KEY),
        rationale_summary="x",
    )
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=make_module_state(), task_type=TaskType.RCA, skill_registry=_skills())


def test_priority_out_of_range_rejected():
    decision = _dispatch(ObjectiveAction.SCREEN, TargetRefType.MODULE, "OEE", _SCREENING_KEY, priority=1.5)
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=make_module_state(), task_type=TaskType.RCA, skill_registry=_skills())


def test_valid_dispatch_passes():
    decision = _dispatch(ObjectiveAction.SCREEN, TargetRefType.MODULE, "OEE", _SCREENING_KEY)
    validate_planner_decision(decision, module_state=make_module_state(), task_type=TaskType.RCA, skill_registry=_skills())  # must not raise


def test_valid_no_viable_objective_passes():
    decision = PlannerDecision(decision=PlannerDecisionType.NO_VIABLE_OBJECTIVE, rationale_summary="x")
    validate_planner_decision(decision, module_state=make_module_state(), task_type=TaskType.RCA, skill_registry=_skills())


# ============================================================================
# Capability-key-aware
# ============================================================================


def test_missing_capability_key_rejected():
    decision = _dispatch(ObjectiveAction.SCREEN, TargetRefType.MODULE, "OEE", capability_key=None)
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=make_module_state(), task_type=TaskType.RCA, skill_registry=_skills())


def test_unknown_capability_key_rejected():
    decision = _dispatch(ObjectiveAction.SCREEN, TargetRefType.MODULE, "OEE", capability_key="oee.not_a_real_capability")
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=make_module_state(), task_type=TaskType.RCA, skill_registry=_skills())


def test_capability_key_valid_for_wrong_task_type_rejected():
    # oee.equipment_detail's only Skill (oee.rca_equipment_detail) is task_types=[rca] -- not valid for ANALYSIS
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", _DETAIL_KEY)
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=_module_state_with_eq001(), task_type=TaskType.ANALYSIS, skill_registry=_skills())


def test_capability_key_shared_by_two_task_types_resolves_the_matching_one():
    # oee.equipment_screening is the capability_key for BOTH oee.equipment_screening
    # (task_types=[analysis]) and oee.rca_screening (task_types=[rca]) -- both
    # must independently validate for their own task_type.
    decision = _dispatch(ObjectiveAction.SCREEN, TargetRefType.MODULE, "OEE", _SCREENING_KEY)
    validate_planner_decision(decision, module_state=make_module_state(), task_type=TaskType.ANALYSIS, skill_registry=_skills())
    validate_planner_decision(decision, module_state=make_module_state(), task_type=TaskType.RCA, skill_registry=_skills())


# ============================================================================
# State-aware
# ============================================================================


def test_entity_target_not_in_module_state_rejected():
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ999", _DETAIL_KEY)
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=_module_state_with_eq001(), task_type=TaskType.RCA, skill_registry=_skills())


def test_entity_target_that_exists_passes():
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", _DETAIL_KEY)
    validate_planner_decision(decision, module_state=_module_state_with_eq001(), task_type=TaskType.RCA, skill_registry=_skills())


def test_action_target_shape_mismatch_rejected():
    # oee.equipment_detail's Skill declares expected_target_ref_type=entity, not MODULE
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.MODULE, "OEE", _DETAIL_KEY)
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=make_module_state(), task_type=TaskType.RCA, skill_registry=_skills())


def test_repeating_a_completed_objective_rejected():
    state = make_module_state()
    state = state.model_copy(
        update={
            "objective_history": {
                "mod-oee-obj-1": ObjectiveRecord(
                    objective_id="mod-oee-obj-1", description="screen", action=ObjectiveAction.SCREEN, capability_key=_SCREENING_KEY,
                    target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="OEE"),
                    status=ObjectiveStatus.COMPLETED, created_step=1, attempt_count=1,
                )
            }
        }
    )
    decision = _dispatch(ObjectiveAction.SCREEN, TargetRefType.MODULE, "OEE", _SCREENING_KEY)
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=state, task_type=TaskType.RCA, skill_registry=_skills())


def test_repeating_a_rejected_objective_rejected():
    state = _module_state_with_eq001().model_copy(
        update={
            "objective_history": {
                "mod-oee-obj-1": ObjectiveRecord(
                    objective_id="mod-oee-obj-1", description="detail", action=ObjectiveAction.DRILL_DOWN, capability_key=_DETAIL_KEY,
                    target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="EQ001"),
                    status=ObjectiveStatus.REJECTED, created_step=1, attempt_count=1,
                )
            }
        }
    )
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", _DETAIL_KEY)
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=state, task_type=TaskType.RCA, skill_registry=_skills())


def test_different_target_after_a_completed_objective_still_passes():
    state = make_module_state()
    state = state.model_copy(
        update={
            "objective_history": {
                "mod-oee-obj-1": ObjectiveRecord(
                    objective_id="mod-oee-obj-1", description="screen", action=ObjectiveAction.SCREEN, capability_key=_SCREENING_KEY,
                    target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="OEE"),
                    status=ObjectiveStatus.COMPLETED, created_step=1, attempt_count=1,
                )
            },
            "entity_states": _module_state_with_eq001().entity_states,
        }
    )
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", _DETAIL_KEY)
    validate_planner_decision(decision, module_state=state, task_type=TaskType.RCA, skill_registry=_skills())  # must not raise


# ============================================================================
# TaskType-aware (generic verb depth)
# ============================================================================


@pytest.mark.parametrize("action,ref_type,ref_id,capability_key", [
    (ObjectiveAction.SCREEN, TargetRefType.MODULE, "OEE", _SCREENING_KEY),
    (ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", _DETAIL_KEY),
])
def test_information_forbids_deep_rca_actions(action, ref_type, ref_id, capability_key):
    decision = _dispatch(action, ref_type, ref_id, capability_key)
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=_module_state_with_eq001(), task_type=TaskType.INFORMATION, skill_registry=_skills())


def test_information_allows_current_status():
    decision = _dispatch(ObjectiveAction.SUMMARIZE, TargetRefType.MODULE, "OEE", _STATUS_KEY)
    validate_planner_decision(decision, module_state=make_module_state(), task_type=TaskType.INFORMATION, skill_registry=_skills())


def test_analysis_forbids_equipment_detail_root_cause_dive():
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", _DETAIL_KEY)
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=_module_state_with_eq001(), task_type=TaskType.ANALYSIS, skill_registry=_skills())


def test_analysis_allows_equipment_screening():
    decision = _dispatch(ObjectiveAction.SCREEN, TargetRefType.MODULE, "OEE", _SCREENING_KEY)
    validate_planner_decision(decision, module_state=make_module_state(), task_type=TaskType.ANALYSIS, skill_registry=_skills())


def test_rca_allows_equipment_detail_deep_dive():
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", _DETAIL_KEY)
    validate_planner_decision(decision, module_state=_module_state_with_eq001(), task_type=TaskType.RCA, skill_registry=_skills())
