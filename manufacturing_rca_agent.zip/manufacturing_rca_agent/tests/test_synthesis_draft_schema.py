"""Phase 6B items 2-3: SynthesisDraft typed output contract (structurally
cannot carry a tool_id/skill_id/new Finding/new RootCause/status field) and
`validate_synthesis_draft`'s referential-integrity checks (semantic
validation beyond the schema).
"""
import pytest
from pydantic import ValidationError

from agent.llm.context.synthesis_context import SynthesisContext, SynthesisGoalContext
from agent.llm.prompts.synthesis import ModuleSummaryDraft, SynthesisDraft
from agent.state.enums import (
    FindingStatus,
    ModuleStatus,
    RecommendationActionType,
    RelationType,
    TaskType,
)
from agent.state.models import CrossModuleRelation, Finding, Limitation, ModuleHandoff, RecommendationCandidate, RootCause
from agent.synthesis.validation import SynthesisSemanticValidationError, validate_synthesis_draft


def _handoff(**overrides) -> ModuleHandoff:
    base = dict(
        module_id="OEE", module_type="OEE", task_type=TaskType.RCA, module_status=ModuleStatus.COMPLETE,
        module_goal="Why did OEE decline?", executive_finding="Motor Failure on EQ001.",
        confirmed_findings=[Finding(finding_id="f1", statement="Motor Failure on EQ001.", pattern="Availability", confidence=0.9, status=FindingStatus.CONFIRMED, is_root_cause=True)],
        root_causes=[RootCause(root_cause_id="rc1", statement="Motor Failure on EQ001.", module_id="OEE", confidence=0.9, supporting_finding_ids=["f1"])],
        limitations=[Limitation(limitation_id="lim1", description="EQ003 not investigated.", impacted_objective_id="o1", impact_statement="incomplete coverage")],
        confidence=0.9, evidence_coverage=1.0,
    )
    base.update(overrides)
    return ModuleHandoff(**base)


def _context(*, relations=None, recommendations=None, task_type=TaskType.RCA, handoffs=None) -> SynthesisContext:
    return SynthesisContext(
        run_id="run-1", request_summary="why did OEE decline", normalized_request="why did OEE decline",
        global_goal=SynthesisGoalContext(task_type=task_type, statement="Why did OEE decline?"),
        factory_summary="Factory A (factory-a)",
        module_handoffs=handoffs if handoffs is not None else [_handoff()],
        cross_module_relations=relations or [],
        recommendation_candidates=recommendations or [],
    )


def _relation(**overrides) -> CrossModuleRelation:
    base = dict(relation_id="rel1", source_modules=["OEE", "Output"], relation_type=RelationType.CORRELATED, statement="Observed together.", confidence=0.5)
    base.update(overrides)
    return CrossModuleRelation(**base)


def _recommendation(**overrides) -> RecommendationCandidate:
    base = dict(recommendation_id="rec1", statement="Replace the motor.", based_on_root_cause_ids=["rc1"], action_type=RecommendationActionType.MAINTENANCE_ACTION, confidence=0.8)
    base.update(overrides)
    return RecommendationCandidate(**base)


# ============================================================================
# Schema (item 2)
# ============================================================================


def test_synthesis_draft_field_set_is_closed():
    assert set(SynthesisDraft.model_fields.keys()) == {
        "executive_summary", "module_summaries", "key_finding_ids", "root_cause_ids", "relation_ids",
        "limitation_ids", "unresolved_question_summary", "recommendation_ids", "recommendation_wording",
        "audience_summary",
    }


@pytest.mark.parametrize("forbidden_field", ["tool_id", "skill_id", "sql", "python_code", "module_status", "overall_status", "new_finding"])
def test_synthesis_draft_rejects_execution_and_state_fields(forbidden_field):
    raw = {"executive_summary": "x", forbidden_field: "should never be accepted"}
    with pytest.raises(ValidationError):
        SynthesisDraft.model_validate(raw)


def test_valid_draft_round_trips():
    draft = SynthesisDraft(
        executive_summary="OEE declined due to a confirmed Motor Failure.",
        module_summaries=[ModuleSummaryDraft(module_id="OEE", summary_text="Availability loss traced to Motor Failure.")],
        key_finding_ids=["f1"], root_cause_ids=["rc1"],
    )
    restored = SynthesisDraft.model_validate_json(draft.model_dump_json())
    assert restored == draft


# ============================================================================
# Referential integrity (item 3)
# ============================================================================


def test_valid_references_pass():
    validate_synthesis_draft(SynthesisDraft(executive_summary="x", key_finding_ids=["f1"], root_cause_ids=["rc1"], limitation_ids=["lim1"]), context=_context())


def test_unknown_finding_id_rejected():
    with pytest.raises(SynthesisSemanticValidationError):
        validate_synthesis_draft(SynthesisDraft(executive_summary="x", key_finding_ids=["f-does-not-exist"]), context=_context())


def test_unknown_root_cause_id_rejected():
    with pytest.raises(SynthesisSemanticValidationError):
        validate_synthesis_draft(SynthesisDraft(executive_summary="x", root_cause_ids=["rc-does-not-exist"]), context=_context())


def test_unknown_limitation_id_rejected():
    with pytest.raises(SynthesisSemanticValidationError):
        validate_synthesis_draft(SynthesisDraft(executive_summary="x", limitation_ids=["lim-does-not-exist"]), context=_context())


def test_unknown_module_id_in_module_summary_rejected():
    with pytest.raises(SynthesisSemanticValidationError):
        validate_synthesis_draft(SynthesisDraft(executive_summary="x", module_summaries=[ModuleSummaryDraft(module_id="NotARealModule", summary_text="x")]), context=_context())


def test_unknown_relation_id_rejected():
    with pytest.raises(SynthesisSemanticValidationError):
        validate_synthesis_draft(SynthesisDraft(executive_summary="x", relation_ids=["rel-does-not-exist"]), context=_context())


def test_relation_id_valid_when_relation_exists_in_context():
    validate_synthesis_draft(SynthesisDraft(executive_summary="x", relation_ids=["rel1"]), context=_context(relations=[_relation()]))


def test_empty_relations_in_context_means_relation_ids_must_be_empty():
    """Item 8's explicit regression: if context.cross_module_relations == [],
    a draft that references any relation_id is rejected outright -- there
    is nothing it could legitimately be referencing."""
    with pytest.raises(SynthesisSemanticValidationError):
        validate_synthesis_draft(SynthesisDraft(executive_summary="x", relation_ids=["rel1"]), context=_context(relations=[]))


def test_unknown_recommendation_id_rejected():
    with pytest.raises(SynthesisSemanticValidationError):
        validate_synthesis_draft(SynthesisDraft(executive_summary="x", recommendation_ids=["rec-does-not-exist"]), context=_context())


def test_recommendation_wording_for_unknown_id_rejected():
    with pytest.raises(SynthesisSemanticValidationError):
        validate_synthesis_draft(SynthesisDraft(executive_summary="x", recommendation_wording={"rec-does-not-exist": "reworded"}), context=_context())


def test_recommendation_id_and_wording_valid_when_candidate_exists():
    validate_synthesis_draft(
        SynthesisDraft(executive_summary="x", recommendation_ids=["rec1"], recommendation_wording={"rec1": "Replace the failed motor as soon as possible."}),
        context=_context(recommendations=[_recommendation()]),
    )


def test_empty_recommendations_in_context_means_recommendation_ids_must_be_empty():
    with pytest.raises(SynthesisSemanticValidationError):
        validate_synthesis_draft(SynthesisDraft(executive_summary="x", recommendation_ids=["rec1"]), context=_context(recommendations=[]))


def test_root_cause_ids_must_be_empty_for_information_task_type():
    with pytest.raises(SynthesisSemanticValidationError):
        validate_synthesis_draft(SynthesisDraft(executive_summary="x", root_cause_ids=["rc1"]), context=_context(task_type=TaskType.INFORMATION))


def test_root_cause_ids_must_be_empty_for_analysis_task_type():
    with pytest.raises(SynthesisSemanticValidationError):
        validate_synthesis_draft(SynthesisDraft(executive_summary="x", root_cause_ids=["rc1"]), context=_context(task_type=TaskType.ANALYSIS))


def test_failed_module_never_offers_a_finding_id_to_reference():
    """A FAILED module's ModuleHandoff has no confirmed_findings at all
    (Phase 6A's ModuleHandoffBuilder guarantee) -- so referencing "the
    finding a FAILED module discarded" is already impossible: there is no
    such id in context to begin with."""
    failed_handoff = _handoff(
        module_status=ModuleStatus.FAILED, executive_finding="No reliable finding produced for OEE.",
        confirmed_findings=[], root_causes=[], limitations=[],
    )
    context = _context(handoffs=[failed_handoff])
    with pytest.raises(SynthesisSemanticValidationError):
        validate_synthesis_draft(SynthesisDraft(executive_summary="x", key_finding_ids=["f1"]), context=context)
