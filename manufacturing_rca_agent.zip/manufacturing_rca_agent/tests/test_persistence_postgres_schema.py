"""Offline schema tests (item 12: "schema generation"). No real Postgres --
`apply_schema()` is exercised against `FakeConnection`, so this proves the
migration file parses/splits into individual statements and every expected
table is declared, without needing a real server to execute DDL against.
"""
import re

from agent.persistence.postgres.schema import EXPECTED_TABLES, MIGRATION_FILES, apply_schema, load_migration_sql
from tests.postgres_fake import FakeConnection


def _all_migrations_sql() -> str:
    # Phase PROD-1: agent_runtime_events lives in 0002, not 0001 -- every
    # table-declaration/idempotency check below now spans ALL migration
    # files, not just the first one, so this test suite still catches a
    # missing table regardless of which migration it should live in.
    return "\n".join(load_migration_sql(filename) for filename in MIGRATION_FILES)


def test_migration_sql_declares_every_expected_table():
    sql = _all_migrations_sql()
    for table in EXPECTED_TABLES:
        assert re.search(rf"CREATE TABLE IF NOT EXISTS {table}\s*\(", sql), f"migration is missing table '{table}'"


def test_migration_sql_uses_timestamptz_not_naive_timestamp():
    sql = _all_migrations_sql()
    assert "TIMESTAMPTZ" in sql
    assert re.search(r"\bTIMESTAMP\b(?!TZ)", sql) is None  # no bare TIMESTAMP column anywhere


def test_apply_schema_executes_one_statement_per_call():
    connection = FakeConnection()
    apply_schema(connection)
    assert len(connection.executed) > len(EXPECTED_TABLES)  # tables + indexes
    for sql, _ in connection.executed:
        assert sql.count(";") == 0  # each statement already stripped of its trailing semicolon
        assert sql.strip().upper().startswith(("CREATE TABLE", "CREATE INDEX", "CREATE UNIQUE INDEX"))


def test_apply_schema_is_idempotent_text():
    # every table/index statement uses IF NOT EXISTS -- re-applying is safe
    sql = _all_migrations_sql()
    create_table_count = len(re.findall(r"CREATE TABLE", sql))
    create_table_if_not_exists_count = len(re.findall(r"CREATE TABLE IF NOT EXISTS", sql))
    assert create_table_count == create_table_if_not_exists_count
    create_index_count = len(re.findall(r"CREATE (?:UNIQUE )?INDEX", sql))
    create_index_if_not_exists_count = len(re.findall(r"CREATE (?:UNIQUE )?INDEX IF NOT EXISTS", sql))
    assert create_index_count == create_index_if_not_exists_count
