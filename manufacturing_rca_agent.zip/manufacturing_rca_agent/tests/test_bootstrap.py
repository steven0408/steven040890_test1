﻿"""Phase 5D-10/5D-11: bootstrap_runtime composition root -- assembles a
full, real OEE-module-ready RuntimeContext from AppConfig, and fails fast
(typed exceptions) on every plugin-wiring problem the spec calls out,
rather than letting a bad config surface mid-run.
"""
import pytest
from langgraph.checkpoint.memory import InMemorySaver

from agent.bootstrap import AppConfig, BootstrapConfigError, RuntimeContext, bootstrap_runtime
from agent.catalog.module_registry import DuplicateModuleDefinitionError
from agent.datasource.models import DataSourceConfig, DataSourceConfigError, DataSourceType, InMemoryDataSource
from agent.domain.oee.dataset import CurrentOEEStatus
from agent.graph.graph import build_phase2_graph
from agent.llm.client import MockLLMClient
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.skills.markdown import SkillMarkdownError
from agent.skills.registry import MissingToolForSkillError
from agent.state.enums import ModuleStatus, ObjectiveAction, TargetRefType
from agent.state.models import TargetRef
from agent.state.payload import PayloadRegistry
from agent.state.state import AgentState

from .conftest import make_agent_state


def _config(**overrides) -> AppConfig:
    base = dict(factory_id="factory-a", factory_name="Factory A")
    base.update(overrides)
    return AppConfig(**base)


def _mock_planner_client() -> MockLLMClient:
    decision = PlannerDecision(
        decision=PlannerDecisionType.DISPATCH,
        next_objective=ObjectiveProposal(
            action=ObjectiveAction.SUMMARIZE, target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="OEE"),
            description="status", expected_output="status",
        ),
        priority=1.0, rationale_summary="mock",
    )
    return MockLLMClient(lambda req: decision)


def test_happy_path_produces_a_fully_wired_runtime_context():
    ctx = bootstrap_runtime(_config(), llm_client=_mock_planner_client())

    assert isinstance(ctx, RuntimeContext)
    assert {m.module_type for m in ctx.module_registry.list()} == {"OEE"}
    assert {s.skill_id for s in ctx.skill_registry.list()} >= {"oee.current_status", "oee.rca_screening"}
    assert {t.tool_id for t in ctx.tool_registry.list()} == {
        "query_oee_data", "query_equipment_detail", "filter_rows", "calculate_contribution", "ranking", "aggregate_oee_status",
    }
    assert "OEE" in ctx.module_runtime


def test_reasoning_skill_directory_is_included_and_retrievable():
    ctx = bootstrap_runtime(_config(), llm_client=_mock_planner_client())
    from agent.skills.models import SkillConsumerNode
    from agent.state.enums import TaskType

    results = ctx.reasoning_skill_retriever.retrieve(node=SkillConsumerNode.PLANNER, module_type="OEE", task_type=TaskType.RCA, limit=5)
    assert "reasoning.plant_manager_perspective" in {r.skill_id for r in results}


def test_unknown_enabled_module_raises_typed_config_error():
    with pytest.raises(BootstrapConfigError):
        bootstrap_runtime(_config(enabled_modules=["OEE", "NotARealModule"]), llm_client=_mock_planner_client())


def test_missing_required_tool_raises_typed_error():
    import dataclasses

    from agent.modules.oee.package import build_oee_module_package
    from agent.modules.registry import ModulePackageRegistry

    broken_oee = dataclasses.replace(build_oee_module_package(), tool_registrations=lambda registry: None)
    packages = ModulePackageRegistry()
    packages.register(broken_oee)
    with pytest.raises(MissingToolForSkillError):
        bootstrap_runtime(_config(), llm_client=_mock_planner_client(), module_packages=packages)


def test_malformed_skill_directory_raises_typed_error(tmp_path):
    bad_file = tmp_path / "bad.md"
    bad_file.write_text("no frontmatter here at all", encoding="utf-8")
    config = _config(skill_directories=[str(tmp_path)])
    with pytest.raises(SkillMarkdownError):
        bootstrap_runtime(config, llm_client=_mock_planner_client())


def test_misconfigured_datasource_raises_typed_error():
    config = _config(datasources={"manufacturing_db": DataSourceConfig(name="manufacturing_db", type=DataSourceType.REMOTE_SQL)})
    with pytest.raises(DataSourceConfigError):
        bootstrap_runtime(config, llm_client=_mock_planner_client())


def test_valid_in_memory_datasource_registers_successfully():
    config = _config(datasources={"scratch": DataSourceConfig(name="scratch", type=DataSourceType.IN_MEMORY)})
    ctx = bootstrap_runtime(
        config, llm_client=_mock_planner_client(),
        in_memory_datasource_factory=lambda c: InMemoryDataSource({"ping": lambda p: [{"ok": True}]}),
    )
    assert ctx.datasource_registry.names() == ["scratch"]


def test_duplicate_module_registration_would_be_caught():
    """Phase 8B-1: the duplicate-module-type fail-fast moved one layer
    earlier, from bootstrap_runtime's own catalog-building loop to
    `ModulePackageRegistry.register()` itself -- see
    tests/test_modules_registry.py::test_duplicate_module_package_registration_fails_fast
    for the direct test. This test proves the OLD symptom
    (DuplicateModuleDefinitionError) is now structurally unreachable via
    bootstrap_runtime, because two ModulePackages can never share a
    module_type once ModulePackageRegistry itself rejects the second one."""
    from agent.modules.oee.package import build_oee_module_package
    from agent.modules.registry import DuplicateModulePackageError, ModulePackageRegistry

    packages = ModulePackageRegistry()
    packages.register(build_oee_module_package())
    with pytest.raises(DuplicateModulePackageError):
        packages.register(build_oee_module_package())


def test_module_runtime_from_bootstrap_actually_runs_end_to_end():
    """The composition root's output isn't just structurally plausible --
    it runs a real INFORMATION request through the real parent graph."""
    ctx = bootstrap_runtime(_config(), llm_client=_mock_planner_client())
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(ctx.module_runtime, checkpointer, analyzer=_single_oee_analyzer_node())
    app = graph.compile(checkpointer=checkpointer)

    run_id = "bootstrap-e2e"
    result = app.invoke(make_agent_state(run_id=run_id, raw_text="今天平均 OEE 多少？"), config={"configurable": {"thread_id": run_id}})
    final_state = AgentState.model_validate(result)

    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.COMPLETE
    status = PayloadRegistry.unpack(oee.evidence[0].structured_payload)
    assert isinstance(status, CurrentOEEStatus)


def test_reflector_route_present_wraps_policy_in_llm_reflection_policy():
    """Phase PROD-1: bootstrap_runtime must wire real LLM Reflector
    reasoning (not stay silently deterministic) whenever the caller's own
    AppConfig.llm_routes configures a "reflector" route -- the one signal
    this composition root has for "is Reflector LLM reasoning configured"."""
    from agent.llm.config import LLMRouteConfig
    from agent.planning.policies.llm import LLMPlanningPolicy
    from agent.planning.policies.llm_reflection import LLMReflectionPolicy

    config = _config(llm_routes={
        "analyzer": LLMRouteConfig(route="analyzer", model="mock"),
        "planner": LLMRouteConfig(route="planner", model="mock"),
        "reflector": LLMRouteConfig(route="reflector", model="mock"),
    })
    ctx = bootstrap_runtime(config, llm_client=_mock_planner_client())
    assert isinstance(ctx.module_runtime["OEE"].policy, LLMReflectionPolicy)


def test_reflector_route_absent_keeps_bare_llm_planning_policy():
    """Backward compatibility: every pre-PROD-1 caller (no "reflector" in
    llm_routes, e.g. this file's own `_config()` default) keeps the exact
    same policy type as before -- byte-identical behavior."""
    from agent.planning.policies.llm import LLMPlanningPolicy
    from agent.planning.policies.llm_reflection import LLMReflectionPolicy

    ctx = bootstrap_runtime(_config(), llm_client=_mock_planner_client())
    assert isinstance(ctx.module_runtime["OEE"].policy, LLMPlanningPolicy)
    assert not isinstance(ctx.module_runtime["OEE"].policy, LLMReflectionPolicy)


def _single_oee_analyzer_node():
    from agent.state.models import Goal, GoalScope, ModuleTask
    from agent.state.enums import TaskType

    def node(state: AgentState) -> dict:
        goal = Goal(
            goal_id=f"{state.run_id}-goal", raw_statement=state.user_request.raw_text,
            normalized_statement=state.user_request.raw_text, task_type=TaskType.INFORMATION, scope=GoalScope(),
        )
        task = ModuleTask(module_id="OEE", module_type="OEE", reason="bootstrap smoke", goal_statement="Bootstrap smoke goal.", confidence=1.0, priority=1.0, task_type=TaskType.INFORMATION)
        return {"global_goal": goal, "selected_modules": [task]}

    return node
