"""Phase 6B items 9/12/16/17: SynthesisLLMService -- Mock LLM traces for
every TaskType/status combination the spec calls out, deterministic
fallback on LLM failure, and Context/LLM/Synthesis audit lineage
correlation (item 11).
"""
from agent.llm.context.synthesis_context import SynthesisContextBuilder
from agent.llm.models import LLMTimeoutError
from agent.llm.prompts.synthesis import ModuleSummaryDraft, SynthesisDraft
from agent.state.enums import (
    ErrorType,
    FindingStatus,
    ModuleStatus,
    SynthesisOverallStatus,
    TaskType,
)
from agent.state.models import ErrorRecord, Finding, Goal, GoalScope, Limitation, RejectionRecord
from agent.synthesis.decision_audit import InMemorySynthesisGenerationAuditSink, SynthesisSource
from agent.synthesis.handoff_builder import ModuleHandoffBuilder

from .conftest import make_agent_state, make_module_state, make_synthesis_llm_service, run_oee_module_state_history


def _state_with(*, task_type: TaskType, **module_states):
    state = make_agent_state()
    return state.model_copy(
        update={
            "module_states": module_states,
            "global_goal": Goal(goal_id="g1", raw_statement="test request", normalized_statement="test request", task_type=task_type, scope=GoalScope()),
        }
    )


def _peek_context(state, **kwargs):
    return SynthesisContextBuilder(ModuleHandoffBuilder()).build(state, **kwargs).context


# ============================================================================
# INFORMATION (item 12)
# ============================================================================


def test_information_trace_no_root_cause():
    history = run_oee_module_state_history(TaskType.INFORMATION)
    state = _state_with(task_type=TaskType.INFORMATION, OEE=history[-1])
    context = _peek_context(state)
    finding_ids = [f.finding_id for h in context.module_handoffs for f in h.confirmed_findings]

    draft = SynthesisDraft(executive_summary="Current OEE status is within expected range today.", key_finding_ids=finding_ids)
    service, usage_sink, client = make_synthesis_llm_service(lambda req: draft)

    outcome = service.synthesize(state)
    assert outcome.source == SynthesisSource.LLM, outcome.fallback_reason
    assert outcome.package.root_causes == []
    assert outcome.package.overall_status == SynthesisOverallStatus.COMPLETE
    assert "Current OEE status is within expected range today." in outcome.package.markdown


# ============================================================================
# ANALYSIS (item 12)
# ============================================================================


def test_analysis_trace_no_root_cause():
    history = run_oee_module_state_history(TaskType.ANALYSIS)
    state = _state_with(task_type=TaskType.ANALYSIS, OEE=history[-1])
    context = _peek_context(state)
    finding_ids = [f.finding_id for h in context.module_handoffs for f in h.confirmed_findings]

    draft = SynthesisDraft(executive_summary="Availability is the dominant loss pattern across abnormal equipment.", key_finding_ids=finding_ids)
    service, _, _ = make_synthesis_llm_service(lambda req: draft)

    outcome = service.synthesize(state)
    assert outcome.source == SynthesisSource.LLM
    assert outcome.package.root_causes == []
    assert "## Root Causes" not in outcome.package.markdown


def test_analysis_draft_claiming_a_root_cause_is_rejected_and_falls_back():
    """A misbehaving LLM tries to smuggle in an RCA-flavored root_cause_id
    reference for an ANALYSIS request -- semantic validation must reject it
    even though the id doesn't exist (root_cause_ids must be empty for
    ANALYSIS regardless)."""
    history = run_oee_module_state_history(TaskType.ANALYSIS)
    state = _state_with(task_type=TaskType.ANALYSIS, OEE=history[-1])
    bad_draft = SynthesisDraft(executive_summary="x", root_cause_ids=["hallucinated-root-cause"])
    service, _, _ = make_synthesis_llm_service(lambda req: bad_draft, max_retries=0)

    outcome = service.synthesize(state)
    assert outcome.source == SynthesisSource.FALLBACK
    assert outcome.package.root_causes == []


# ============================================================================
# RCA COMPLETE / PARTIAL (item 12)
# ============================================================================


def test_rca_complete_trace_root_cause_referenced_and_manager_worded():
    history = run_oee_module_state_history(TaskType.RCA)
    state = _state_with(task_type=TaskType.RCA, OEE=history[-1])
    context = _peek_context(state)
    root_cause_ids = [rc.root_cause_id for h in context.module_handoffs for rc in h.root_causes]
    assert root_cause_ids

    draft = SynthesisDraft(
        executive_summary="Production impact: confirmed Motor Failure is driving Availability loss on the bottleneck line.",
        root_cause_ids=root_cause_ids,
        audience_summary="Plant Manager View",
    )
    service, _, _ = make_synthesis_llm_service(lambda req: draft)

    outcome = service.synthesize(state)
    assert outcome.source == SynthesisSource.LLM
    assert len(outcome.package.root_causes) == 1
    assert "Motor Failure" in outcome.package.markdown
    assert "Plant Manager View" in outcome.package.markdown


def test_rca_partial_trace_never_outputs_motor_failure():
    module_state = make_module_state().model_copy(
        update={
            "status": ModuleStatus.PARTIAL,
            "findings": [Finding(finding_id="f1", statement="Availability is the dominant loss pattern.", pattern="Availability", confidence=0.7, status=FindingStatus.CONFIRMED, is_root_cause=False)],
            "limitations": [Limitation(limitation_id="lim1", description="EQ001 downtime detail unavailable.", impacted_objective_id="o1", impact_statement="failure mechanism unknown", related_error=ErrorRecord(error_type=ErrorType.DATA_NOT_FOUND, message="x", objective_id="o1", occurred_at_step=1))],
        }
    )
    state = _state_with(task_type=TaskType.RCA, OEE=module_state)

    # even a well-intentioned but overreaching draft naming "Motor Failure"
    # in prose (not as a valid root_cause_id) must not be allowed to imply
    # a confirmed root cause -- the schema-level fields are what's checked,
    # not the executive_summary's free text, so this specific test confirms
    # the *structured* channel stays empty; the free-text channel is
    # covered by test_synthesis_hostile_data.py instead
    draft = SynthesisDraft(executive_summary="Availability loss confirmed; exact failure mechanism not yet determined.", key_finding_ids=["f1"])
    service, _, _ = make_synthesis_llm_service(lambda req: draft)

    outcome = service.synthesize(state)
    assert outcome.source == SynthesisSource.LLM
    assert outcome.package.root_causes == []
    assert "Motor Failure" not in outcome.package.markdown


def test_rca_partial_draft_referencing_a_nonexistent_root_cause_falls_back():
    module_state = make_module_state().model_copy(
        update={"status": ModuleStatus.PARTIAL, "findings": [Finding(finding_id="f1", statement="Availability dominant.", pattern="Availability", confidence=0.7, status=FindingStatus.CONFIRMED, is_root_cause=False)]}
    )
    state = _state_with(task_type=TaskType.RCA, OEE=module_state)
    bad_draft = SynthesisDraft(executive_summary="Motor Failure confirmed.", root_cause_ids=["rc-hallucinated"])
    service, _, _ = make_synthesis_llm_service(lambda req: bad_draft, max_retries=0)

    outcome = service.synthesize(state)
    assert outcome.source == SynthesisSource.FALLBACK
    assert outcome.package.root_causes == []
    assert "Motor Failure" not in outcome.package.markdown


# ============================================================================
# Multi-module (item 12)
# ============================================================================


def test_multi_module_trace_keeps_deterministic_overall_status():
    oee = make_module_state(module_id="OEE", module_type="OEE").model_copy(
        update={"status": ModuleStatus.COMPLETE, "findings": [Finding(finding_id="f1", statement="OEE Motor Failure.", pattern="Availability", confidence=0.9, status=FindingStatus.CONFIRMED, is_root_cause=True)]}
    )
    output = make_module_state(module_id="Output", module_type="Output").model_copy(
        update={"status": ModuleStatus.COMPLETE, "findings": [Finding(finding_id="f1", statement="Output on target.", pattern="none", confidence=0.9, status=FindingStatus.CONFIRMED, is_root_cause=False)]}
    )
    wip = make_module_state(module_id="WIP", module_type="WIP").model_copy(update={"status": ModuleStatus.PARTIAL})
    state = _state_with(task_type=TaskType.RCA, OEE=oee, Output=output, WIP=wip)
    context = _peek_context(state)
    root_cause_ids = [rc.root_cause_id for h in context.module_handoffs for rc in h.root_causes]

    draft = SynthesisDraft(
        executive_summary="OEE and Output are healthy; WIP coverage remains partial.",
        module_summaries=[
            ModuleSummaryDraft(module_id="OEE", summary_text="Motor Failure confirmed and addressed."),
            ModuleSummaryDraft(module_id="Output", summary_text="On target."),
            ModuleSummaryDraft(module_id="WIP", summary_text="Investigation incomplete."),
        ],
        root_cause_ids=root_cause_ids,
    )
    service, _, _ = make_synthesis_llm_service(lambda req: draft)

    outcome = service.synthesize(state)
    assert outcome.source == SynthesisSource.LLM
    assert outcome.package.overall_status == SynthesisOverallStatus.PARTIAL  # still deterministic, never LLM-decided
    assert {m.module_id for m in outcome.package.module_results} == {"OEE", "Output", "WIP"}


# ============================================================================
# BLOCKED (item 12)
# ============================================================================


def test_blocked_trace_wording_stays_authorization_not_data_missing():
    blocked = make_module_state().model_copy(
        update={"status": ModuleStatus.BLOCKED, "rejections": [RejectionRecord(objective_id="o1", permission_type="restricted_query", reason="operator denied", alternative_found=False)]}
    )
    state = _state_with(task_type=TaskType.RCA, OEE=blocked)
    context = _peek_context(state)
    limitation_ids = [lim.limitation_id for h in context.module_handoffs for lim in h.limitations]
    assert limitation_ids

    draft = SynthesisDraft(executive_summary="OEE analysis is blocked pending authorization approval.", limitation_ids=limitation_ids)
    service, _, _ = make_synthesis_llm_service(lambda req: draft)

    outcome = service.synthesize(state)
    assert outcome.source == SynthesisSource.LLM
    oee_handoff = next(m for m in outcome.package.module_results if m.module_id == "mod-oee")
    assert "Authorization" in oee_handoff.limitations[0].description
    assert oee_handoff.limitations[0].related_error is None
    assert "authorization" in outcome.package.markdown.lower()


# ============================================================================
# Fallback (item 16) + audit lineage (item 11)
# ============================================================================


def test_timeout_falls_back_to_deterministic_synthesis():
    history = run_oee_module_state_history(TaskType.RCA)
    state = _state_with(task_type=TaskType.RCA, OEE=history[-1])
    service, usage_sink, _ = make_synthesis_llm_service(lambda req: (_ for _ in ()).throw(LLMTimeoutError("simulated timeout")), max_retries=0)

    outcome = service.synthesize(state)
    assert outcome.source == SynthesisSource.FALLBACK
    assert outcome.fallback_reason is not None
    assert "Motor Failure" in outcome.package.markdown  # deterministic synthesis still produces a full, correct result
    assert len(usage_sink.list_for_run(state.run_id)) >= 1


def test_context_llm_and_synthesis_records_correlate():
    history = run_oee_module_state_history(TaskType.RCA)
    state = _state_with(task_type=TaskType.RCA, OEE=history[-1])
    context = _peek_context(state)
    root_cause_ids = [rc.root_cause_id for h in context.module_handoffs for rc in h.root_causes]

    decision_sink = InMemorySynthesisGenerationAuditSink()
    from agent.llm.context.synthesis_context_audit import InMemorySynthesisContextAuditSink

    context_sink = InMemorySynthesisContextAuditSink()
    service, usage_sink, _ = make_synthesis_llm_service(
        lambda req: SynthesisDraft(executive_summary="x", root_cause_ids=root_cause_ids),
        decision_audit_sink=decision_sink, context_audit_sink=context_sink,
    )

    outcome = service.synthesize(state)
    record = decision_sink.list_for_run(state.run_id)[0]
    assert record.source == SynthesisSource.LLM
    assert record.referenced_root_cause_ids == root_cause_ids
    assert record.included_module_ids == ["OEE"]

    context_records = context_sink.list_for_run(state.run_id)
    assert record.context_build_record_id in {r.context_build_record_id for r in context_records}
    llm_records = usage_sink.list_for_run(state.run_id)
    assert record.llm_call_id in {r.llm_call_id for r in llm_records}


def test_fallback_record_has_no_llm_call_id_but_has_context_correlation():
    history = run_oee_module_state_history(TaskType.RCA)
    state = _state_with(task_type=TaskType.RCA, OEE=history[-1])
    decision_sink = InMemorySynthesisGenerationAuditSink()
    service, _, _ = make_synthesis_llm_service(
        lambda req: (_ for _ in ()).throw(LLMTimeoutError("x")), max_retries=0, decision_audit_sink=decision_sink,
    )

    service.synthesize(state)
    record = decision_sink.list_for_run(state.run_id)[0]
    assert record.source == SynthesisSource.FALLBACK
    assert record.llm_call_id is None
    assert record.context_build_record_id is not None
    assert record.fallback_reason is not None
