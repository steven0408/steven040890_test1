"""Phase 5D-1/5D-2: SkillType taxonomy -- EXECUTION vs REASONING is a real,
enforced split, not just documentation. A REASONING skill that declares an
executable-steps contract (steps/required_tools/optional_tools/actions) is
a load-time (pydantic ValidationError) failure, never a silent no-op.
"""
import pytest
from pydantic import ValidationError

from agent.skills.models import SkillConsumerNode, SkillDefinition, SkillStep, SkillType


def _base_kwargs(**overrides) -> dict:
    base = dict(
        skill_id="test.skill", name="Test Skill", description="d", category="test",
        input_contract="x", output_contract="y",
    )
    base.update(overrides)
    return base


def test_default_skill_type_is_execution_backward_compatible():
    skill = SkillDefinition(**_base_kwargs(required_tools=["some_tool"], actions=[]))
    assert skill.skill_type == SkillType.EXECUTION
    assert skill.applicable_nodes == []
    assert skill.roles == []
    assert skill.enabled is True


def test_reasoning_skill_allows_empty_execution_fields():
    skill = SkillDefinition(**_base_kwargs(skill_type=SkillType.REASONING, applicable_nodes=[SkillConsumerNode.ANALYZER, SkillConsumerNode.PLANNER]))
    assert skill.required_tools == []
    assert skill.steps == []
    assert skill.actions == []


@pytest.mark.parametrize(
    "bad_field,bad_value",
    [
        ("required_tools", ["some_tool"]),
        ("optional_tools", ["some_tool"]),
        ("steps", [SkillStep(tool_id="some_tool")]),
        ("actions", ["equipment_screening"]),
    ],
)
def test_reasoning_skill_rejects_executable_steps_contract(bad_field, bad_value):
    with pytest.raises(ValidationError):
        SkillDefinition(**_base_kwargs(skill_type=SkillType.REASONING, **{bad_field: bad_value}))


def test_applicable_nodes_rejects_unknown_node_name():
    with pytest.raises(ValidationError):
        SkillDefinition.model_validate(_base_kwargs(skill_type="reasoning", applicable_nodes=["not_a_real_node"]))


def test_skill_type_rejects_unknown_value():
    with pytest.raises(ValidationError):
        SkillDefinition.model_validate(_base_kwargs(skill_type="not_a_real_type"))
