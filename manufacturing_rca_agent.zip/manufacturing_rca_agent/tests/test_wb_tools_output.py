"""Phase WB-2A item P: WB Stage Output Tools -- Query + Summarize +
Compare, production_date vs sync_time semantics, unknown-field
preservation, deterministic ranking, DataSource exception mapping.
"""
from agent.domain.wb.datasource import InMemoryWBStageOutputDataSource
from agent.domain.wb.errors import WBDataSourceUnavailableError
from agent.domain.wb.synthetic import (
    GOLDEN_DATE,
    SCENARIO_A_PLANT,
    SCENARIO_B_PLANT,
    SCENARIO_D_PLANT,
    build_wb_stage_output_records,
)
from agent.domain.wb.tool_results import (
    WBStageOutputComparisonResult,
    WBStageOutputQueryResult,
    WBStageOutputSummaryResult,
    register_wb_tool_result_payloads,
)
from agent.state.enums import ErrorType, ObservationStatus
from agent.state.payload import PayloadRegistry
from agent.tools.models import ToolExecutionRequest
from agent.tools.wb.output_tools import (
    CompareWBStageOutputTool,
    QueryWBStageOutputTool,
    SummarizeWBStageOutputTool,
    WBStageOutputComparisonInput,
    WBStageOutputQueryInput,
    WBStageOutputSummaryInput,
    register_wb_output_input_payloads,
)


def setup_module(module):
    register_wb_output_input_payloads()
    register_wb_tool_result_payloads()


def _output_datasource():
    return InMemoryWBStageOutputDataSource(build_wb_stage_output_records())


def _run(tool, payload_type, params):
    request = ToolExecutionRequest(
        tool_id=tool.definition.tool_id, parameters=PayloadRegistry.pack(payload_type, params),
        run_id="run-1", module_id="WB",
    )
    return tool.run(request)


# ============================================================================
# Query -- production_date semantics
# ============================================================================


def test_query_filters_by_production_date_not_sync_time():
    tool = QueryWBStageOutputTool(_output_datasource())
    result = _run(tool, "wb.stage_output_query_input", WBStageOutputQueryInput(production_date=GOLDEN_DATE, plant_id=SCENARIO_A_PLANT, operation_id="2800"))
    payload = PayloadRegistry.unpack(result.payload)
    assert isinstance(payload, WBStageOutputQueryResult)
    assert len(payload.records) == 2  # 2 products
    assert all(r.production_date == GOLDEN_DATE for r in payload.records)
    # sync_time is the day AFTER production_date is not assumed -- OUTPUT sync_time == same day 08:30 per synthetic builder
    assert all(r.source_sync_time.date() == GOLDEN_DATE for r in payload.records)


def test_unknown_field_source_facility_and_bond_diagram_preserved_not_interpreted():
    tool = QueryWBStageOutputTool(_output_datasource())
    result = _run(tool, "wb.stage_output_query_input", WBStageOutputQueryInput(production_date=GOLDEN_DATE, plant_id=SCENARIO_A_PLANT))
    payload = PayloadRegistry.unpack(result.payload)
    for record in payload.records:
        assert record.source_facility == SCENARIO_A_PLANT  # raw SUP_FAC value preserved verbatim
        assert record.bond_diagram == "BOND_DIAG_01"  # raw TT_BOND_DIAG preserved verbatim


def test_unknown_plant_or_date_returns_empty_not_error():
    tool = QueryWBStageOutputTool(_output_datasource())
    result = _run(tool, "wb.stage_output_query_input", WBStageOutputQueryInput(production_date=GOLDEN_DATE, plant_id="ASE99"))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.records == []
    assert payload.availability.is_empty is True
    assert result.status == ObservationStatus.SUCCESS


# ============================================================================
# Summarize
# ============================================================================


def test_summarize_golden_scenario_a_output_shortage_on_2800():
    tool = SummarizeWBStageOutputTool(_output_datasource())
    result = _run(tool, "wb.stage_output_summary_input", WBStageOutputSummaryInput(production_date=GOLDEN_DATE, plant_id=SCENARIO_A_PLANT, operation_id="2800"))
    payload = PayloadRegistry.unpack(result.payload)
    assert isinstance(payload, WBStageOutputSummaryResult)
    assert payload.total_output_quantity == 2300  # 1150 x 2 products, Golden Scenario A shortage


def test_summarize_normal_day_baseline_quantity():
    tool = SummarizeWBStageOutputTool(_output_datasource())
    result = _run(tool, "wb.stage_output_summary_input", WBStageOutputSummaryInput(production_date=GOLDEN_DATE, plant_id=SCENARIO_D_PLANT, operation_id="2800"))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.total_output_quantity == 4000  # ASE02 (Golden D control) -- no shortage, baseline 2000 x 2


def test_summarize_grouping_keys_sorted():
    tool = SummarizeWBStageOutputTool(_output_datasource())
    result = _run(tool, "wb.stage_output_summary_input", WBStageOutputSummaryInput(production_date=GOLDEN_DATE))
    payload = PayloadRegistry.unpack(result.payload)
    assert list(payload.by_plant.keys()) == sorted(payload.by_plant.keys())
    assert list(payload.by_product.keys()) == sorted(payload.by_product.keys())


# ============================================================================
# Compare -- deterministic ranking
# ============================================================================


def test_compare_ranks_plants_descending_by_output():
    tool = CompareWBStageOutputTool(_output_datasource())
    result = _run(tool, "wb.stage_output_comparison_input", WBStageOutputComparisonInput(production_date=GOLDEN_DATE, operation_id="2800"))
    payload = PayloadRegistry.unpack(result.payload)
    assert isinstance(payload, WBStageOutputComparisonResult)
    quantities = [e.output_quantity for e in payload.comparison]
    assert quantities == sorted(quantities, reverse=True)
    assert payload.highest.output_quantity == quantities[0]
    assert payload.lowest.output_quantity == quantities[-1]


def test_compare_golden_scenario_a_and_b_are_lower_than_control():
    tool = CompareWBStageOutputTool(_output_datasource())
    result = _run(tool, "wb.stage_output_comparison_input", WBStageOutputComparisonInput(production_date=GOLDEN_DATE, operation_id="2800"))
    payload = PayloadRegistry.unpack(result.payload)
    by_plant = {e.plant_id: e.output_quantity for e in payload.comparison}
    assert by_plant[SCENARIO_A_PLANT] < by_plant[SCENARIO_D_PLANT]
    assert by_plant[SCENARIO_B_PLANT] < by_plant[SCENARIO_D_PLANT]


def test_compare_restricted_to_explicit_plant_ids():
    tool = CompareWBStageOutputTool(_output_datasource())
    result = _run(tool, "wb.stage_output_comparison_input", WBStageOutputComparisonInput(production_date=GOLDEN_DATE, operation_id="2800", plant_ids=[SCENARIO_A_PLANT, SCENARIO_D_PLANT]))
    payload = PayloadRegistry.unpack(result.payload)
    assert {e.plant_id for e in payload.comparison} == {SCENARIO_A_PLANT, SCENARIO_D_PLANT}


def test_compare_deterministic_across_repeated_calls():
    tool = CompareWBStageOutputTool(_output_datasource())
    r1 = PayloadRegistry.unpack(_run(tool, "wb.stage_output_comparison_input", WBStageOutputComparisonInput(production_date=GOLDEN_DATE)).payload)
    r2 = PayloadRegistry.unpack(_run(tool, "wb.stage_output_comparison_input", WBStageOutputComparisonInput(production_date=GOLDEN_DATE)).payload)
    assert [e.plant_id for e in r1.comparison] == [e.plant_id for e in r2.comparison]


def test_compare_empty_scope_has_no_highest_or_lowest():
    tool = CompareWBStageOutputTool(_output_datasource())
    result = _run(tool, "wb.stage_output_comparison_input", WBStageOutputComparisonInput(production_date=GOLDEN_DATE, plant_ids=["ASE99"]))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.comparison == []
    assert payload.highest is None
    assert payload.lowest is None
    assert payload.availability.is_empty is True


# ============================================================================
# DataSource exception mapping
# ============================================================================


class _BrokenOutputDataSource:
    def list_output(self, *, production_date=None, sync_time=None):
        raise WBDataSourceUnavailableError("output source down")

    def freshness(self):
        from agent.domain.wb.models import WB_STAGE_OUTPUT_FRESHNESS

        return WB_STAGE_OUTPUT_FRESHNESS


def test_datasource_error_maps_to_error_result():
    tool = QueryWBStageOutputTool(_BrokenOutputDataSource())
    result = _run(tool, "wb.stage_output_query_input", WBStageOutputQueryInput())
    assert result.status == ObservationStatus.ERROR
    assert result.error_type == ErrorType.DATA_NOT_FOUND
