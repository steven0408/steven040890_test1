"""Phase 5C-2 / WB-2B.1: PlannerDecisionRecord -- typed decision audit
(item 10) and its correlation back to exactly which ContextBuildRecord and
LLMCallRecord produced it (item 11).
"""
from agent.llm.models import DecisionSource, LLMTimeoutError
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.planning.decision_audit import InMemoryPlannerDecisionAuditSink, PlannerDecisionRecord
from agent.llm.context.context_audit import InMemoryContextAuditSink
from agent.state.enums import ObjectiveAction, ObjectiveStatus, TargetRefType
from agent.state.models import ObjectiveRecord, TargetRef

from .conftest import make_llm_planning_policy, make_module_state

_SCREENING_KEY = "oee.equipment_screening"


def _proposal():
    # RCA (make_module_state's default task_type) needs a capability whose
    # own Skill actually declares task_types=[rca] -- oee.current_status
    # (SUMMARIZE) is information-only, so this uses SCREEN/oee.equipment_screening
    # (resolves to oee.rca_screening for RCA) instead.
    return ObjectiveProposal(
        action=ObjectiveAction.SCREEN,
        capability_key=_SCREENING_KEY,
        target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="OEE"),
        description="Screen equipment",
        expected_output="status",
    )


def test_planner_decision_record_has_no_chain_of_thought_field():
    assert set(PlannerDecisionRecord.model_fields.keys()) == {
        "decision_record_id", "run_id", "module_id", "step", "decision", "proposed_action", "proposed_capability_key",
        "target_ref", "priority", "source", "rationale_summary", "context_build_record_id", "llm_call_id",
        "fallback_reason", "created_at",
    }


def test_llm_success_decision_record_fields_and_correlation():
    decision = PlannerDecision(decision=PlannerDecisionType.DISPATCH, next_objective=_proposal(), priority=0.9, rationale_summary="x")
    decision_sink = InMemoryPlannerDecisionAuditSink()
    context_sink = InMemoryContextAuditSink()
    policy, usage_sink, client = make_llm_planning_policy(
        lambda req: decision, decision_audit_sink=decision_sink, context_audit_sink=context_sink
    )
    module_state = make_module_state()

    objective = policy.propose_next_objective(module_state)

    records = decision_sink.list_for_run(module_state.run_id)
    assert len(records) == 1
    record = records[0]
    assert record.module_id == module_state.module_id
    assert record.step == 1
    assert record.decision == PlannerDecisionType.DISPATCH
    assert record.proposed_action == ObjectiveAction.SCREEN
    assert record.proposed_capability_key == _SCREENING_KEY
    assert record.target_ref.ref_id == "OEE"  # canonical MODULE target (Phase 5C-2.1)
    assert record.priority == 0.9
    assert record.source == DecisionSource.LLM
    assert record.fallback_reason is None
    assert record.rationale_summary == "x"
    assert objective is not None and objective.action == ObjectiveAction.SCREEN

    # correlation (item 11): this decision's ids resolve to real records
    context_records = context_sink.list_for_run(module_state.run_id)
    assert record.context_build_record_id is not None
    assert record.context_build_record_id in {r.context_build_record_id for r in context_records}

    llm_records = usage_sink.list_for_run(module_state.run_id)
    assert record.llm_call_id is not None
    assert record.llm_call_id in {r.llm_call_id for r in llm_records}


def test_fallback_decision_record_has_no_llm_call_id_but_has_context_correlation():
    decision_sink = InMemoryPlannerDecisionAuditSink()
    context_sink = InMemoryContextAuditSink()
    policy, usage_sink, client = make_llm_planning_policy(
        lambda req: (_ for _ in ()).throw(LLMTimeoutError("simulated timeout")),
        max_retries=0,
        decision_audit_sink=decision_sink,
        context_audit_sink=context_sink,
    )
    module_state = make_module_state()

    objective = policy.propose_next_objective(module_state)

    record = decision_sink.list_for_run(module_state.run_id)[0]
    assert record.source == DecisionSource.FALLBACK
    assert record.llm_call_id is None  # no successful LLM call to correlate to
    assert record.fallback_reason is not None
    assert record.context_build_record_id is not None  # Context was still built even though the LLM call failed
    assert objective is not None and objective.action == ObjectiveAction.SCREEN  # baseline's own proposal
    assert record.proposed_capability_key == _SCREENING_KEY

    # the failed attempt(s) are still in LLMUsageSink, just not referenced by this decision
    assert len(usage_sink.list_for_run(module_state.run_id)) >= 1


def test_decision_record_step_increments_across_rounds():
    decision_sink = InMemoryPlannerDecisionAuditSink()
    policy, _, _ = make_llm_planning_policy(
        lambda req: PlannerDecision(decision=PlannerDecisionType.NO_VIABLE_OBJECTIVE, rationale_summary="x"), decision_audit_sink=decision_sink
    )
    module_state = make_module_state()
    policy.propose_next_objective(module_state)

    module_state_round_2 = module_state.model_copy(
        update={
            "objective_history": {
                "x": ObjectiveRecord(
                    objective_id="x", description="d", action=ObjectiveAction.SCREEN, capability_key=_SCREENING_KEY,
                    target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="OEE"), status=ObjectiveStatus.COMPLETED,
                    created_step=1, attempt_count=1,
                )
            }
        }
    )
    policy.propose_next_objective(module_state_round_2)

    steps = [r.step for r in decision_sink.list_for_run(module_state.run_id)]
    assert steps == [1, 2]
