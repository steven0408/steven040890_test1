"""FakeHttpClient -- a minimal stand-in for `agent.domain.wb.remote.HttpClient`,
used by every offline WB Remote-adapter test so `RemoteWB*DataSource` is
exercised (request building, response normalization, error mapping)
WITHOUT any HTTP library installed and WITHOUT ever reaching the real
`10.11.32.179:18058` host. Not itself a test module (no `test_` prefix).
"""
from typing import Any


class FakeHttpResponse:
    def __init__(self, status_code: int, payload: Any):
        self.status_code = status_code
        self._payload = payload

    def json(self) -> Any:
        if self._payload is _RAISE_ON_JSON:
            raise ValueError("not valid JSON")
        return self._payload


_RAISE_ON_JSON = object()


class FakeHttpClient:
    """Records every `.get()` call (`self.requests`) and returns
    pre-configured canned responses in order, or a callable's own
    computed response if `respond_with` is a function."""

    def __init__(self, *, respond_with=None):
        self.requests: list[dict[str, Any]] = []
        self._respond_with = respond_with
        self._queue: list[FakeHttpResponse] = []

    def queue_response(self, status_code: int, payload: Any) -> None:
        self._queue.append(FakeHttpResponse(status_code, payload))

    def queue_invalid_json(self, status_code: int = 200) -> None:
        self._queue.append(FakeHttpResponse(status_code, _RAISE_ON_JSON))

    def queue_connection_error(self) -> None:
        self._queue.append(_RAISE_CONNECTION_ERROR)

    def get(self, url: str, *, params: dict[str, Any], timeout: float) -> FakeHttpResponse:
        self.requests.append({"url": url, "params": params, "timeout": timeout})
        if self._respond_with is not None:
            return self._respond_with(url, params, timeout)
        if not self._queue:
            raise AssertionError("FakeHttpClient.get() called with no queued response")
        next_item = self._queue.pop(0)
        if next_item is _RAISE_CONNECTION_ERROR:
            raise ConnectionError("simulated network failure")
        return next_item


_RAISE_CONNECTION_ERROR = object()
