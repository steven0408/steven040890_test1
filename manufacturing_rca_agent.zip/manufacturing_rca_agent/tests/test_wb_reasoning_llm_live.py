"""Phase WB-3E: the core deliverable -- real OpenAI-provider WB reasoning
validation. Answers the phase's own required question (item BD): "is the
Agent actually reasoning from evidence, or just executing a Python
decision tree?"

Skipped entirely (not failed) when OPENAI_API_KEY is not set, exactly
matching the established `ANTHROPIC_API_KEY`-gated pattern
(test_phase5c3_real_planner_smoke.py) -- the rest of the suite always
passes without a secret.

Two categories of assertion, deliberately not conflated (matching the
existing Anthropic smoke tests' own discipline):
  - HARD gate: `validate_planner_decision` must pass (enforced by
    `LLMPlanningPolicy` itself via the Router's `validate=` hook) -- a
    real LLM is not exempt from producing a legal Objective.
  - SOFT signal: `evaluate_planner_decision_quality` is recorded/printed
    for the comparison report, never a hard test failure on its own -- a
    real LLM legitimately choosing a path the deterministic baseline
    never explicitly encoded is not a bug (this is exactly the phenomenon
    item N asks this phase to allow for).

Controlled bad/novel-shape datasets only (never the golden dataset
mutated in place) -- built the same way WB-3C/WB-3D's own test files
already do (a small `WBDataSources` override for exactly the source(s) a
given scenario needs to differ on).
"""
import os
from datetime import datetime, timedelta
from pathlib import Path

import pytest
from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.domain.wb.datasource import InMemoryWBBankDataSource, InMemoryWBIssueDataSource, InMemoryWBPlantOEEDataSource, InMemoryWBStageOutputDataSource, InMemoryWBWIPDataSource
from agent.domain.wb.models import WBBankRecord, WBBankStatus, WBIssueRecord, WBLotStatus, WBPlantOEERecord, WBSiteGroup, WBStageOutputRecord, WBWIPRecord
from agent.domain.wb.synthetic import GOLDEN_DATE, HISTORY_DECLINE_START, SCENARIO_B_PLANT, build_wb_issue_records, build_wb_plant_oee_records
from agent.state.models import Budget
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.llm.config import LLMRouteConfig
from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
from agent.llm.context.context_audit import InMemoryContextAuditSink
from agent.llm.context.evidence_selector import DeterministicEvidenceSelector
from agent.llm.context.planner_context import PlannerContextBuilder
from agent.llm.context.reasoning_skill_retriever import DeterministicReasoningSkillRetriever
from agent.llm.models import DecisionSource, LLMCallStatus
from agent.llm.providers.openai_adapter import OpenAICompatibleAdapter
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.modules.wb.package import build_wb_module_package
from agent.planning.decision_audit import InMemoryPlannerDecisionAuditSink
from agent.planning.decision_quality import evaluate_planner_decision_quality
from agent.planning.policies.llm import LLMPlanningPolicy, decision_from_objective
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import ModuleStatus, TaskType
from agent.state.models import ModuleState, ModuleTask
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry
from agent.tools.wb.registration import WBDataSources

from .conftest import make_wb_datasources

pytestmark = pytest.mark.skipif(
    not os.environ.get("OPENAI_API_KEY"),
    reason="OPENAI_API_KEY not set -- real OpenAI-provider WB reasoning tests skipped (not failed) without a secret",
)

_MODEL = "gpt-4o-mini"


def _sync():
    return datetime(2026, 8, 13, 8, 30)


# ============================================================================
# Wiring helpers
# ============================================================================


def _wb_registries(datasources: WBDataSources | None = None):
    package = build_wb_module_package(datasources=datasources)
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.load_directory(Path(__file__).resolve().parent.parent / "agent" / "skills" / "reasoning")
    skill_registry.validate_required_tools(tool_registry)
    return package, skill_registry, tool_registry


def _real_wb_planner_policy(*, datasources=None, decision_audit_sink=None, context_audit_sink=None):
    package, skill_registry, tool_registry = _wb_registries(datasources)
    usage_sink = InMemoryLLMUsageSink()
    router = LLMRouter(
        routes={"planner": LLMRouteConfig(route="planner", model=_MODEL, timeout_seconds=30.0, max_retries=1)},
        client=OpenAICompatibleAdapter(temperature=0.0, max_tokens=1500),
        usage_sink=usage_sink,
    )
    context_builder = PlannerContextBuilder(
        DeterministicEvidenceSelector(), DeterministicCapabilityRetriever(skill_registry),
        audit_sink=context_audit_sink, reasoning_skill_retriever=DeterministicReasoningSkillRetriever(skill_registry),
    )
    policy = LLMPlanningPolicy(WBPlanningPolicy(), context_builder, router, skill_registry, decision_audit_sink=decision_audit_sink)
    resolver = CapabilityResolver(skill_registry, tool_registry)
    return policy, usage_sink, resolver, skill_registry, package, tool_registry


def _bootstrap_module_state(task_type: TaskType, goal_statement: str, run_id: str, budget):
    task = ModuleTask(module_id="WB", module_type="WB", reason="WB-3E real reasoning smoke", goal_statement=goal_statement, confidence=0.9, priority=0.9, task_type=task_type)
    state = build_initial_module_state(task, budget, run_id=run_id, task_type=task_type)
    return state.model_copy(update={"goal": state.goal.model_copy(update={"statement": goal_statement})})


def _assert_real_usage_recorded(usage_sink: InMemoryLLMUsageSink, run_id: str) -> None:
    records = usage_sink.list_for_run(run_id)
    assert records
    record = records[-1]
    assert record.route == "planner"
    assert record.model == _MODEL
    assert record.status in (LLMCallStatus.SUCCESS, LLMCallStatus.INVALID_OUTPUT, LLMCallStatus.TIMEOUT, LLMCallStatus.PROVIDER_ERROR)
    assert record.latency_ms >= 0


def _print_row(scenario: str, objective, quality, note: str = "") -> None:
    action = objective.action.value if objective is not None else "NONE"
    capability = objective.capability_key if objective is not None else "-"
    target = objective.target_ref.ref_id if objective is not None else "-"
    q = f"{quality.overall_score:.2f}" if quality is not None else "n/a"
    print(f"| {scenario:<28} | {action:<10} {capability:<40} -> {target:<8} | quality={q} | {note} |")


def _run_wb_graph(task_type: TaskType, goal_statement: str, run_id: str, policy, capability_runtime, budget) -> ModuleState:
    graph = build_module_react_subgraph(policy, capability=capability_runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)
    initial = _bootstrap_module_state(task_type, goal_statement, run_id, budget)
    result = app.invoke(initial, config={"configurable": {"thread_id": run_id}})
    return ModuleState.model_validate(result)


def _capability_runtime(skill_registry, tool_registry):
    resolver = CapabilityResolver(skill_registry, tool_registry)
    return ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=SkillRunner(tool_registry, ToolExecutionManager()))


# ============================================================================
# Scenario dataset builders (controlled, never the mutated golden dataset)
# ============================================================================


def _oee_record(plant_id, day, oee, operation="2800") -> WBPlantOEERecord:
    return WBPlantOEERecord(production_date=day, plant_id=plant_id, operation_id=operation, oee=oee, productive_ratio=max(0.0, oee - 5), downtime_ratio=100 - oee if oee < 100 else 0, pm_ratio=1.0, setup_ratio=2.0, idle_ratio=1.0, engineering_ratio=None, ts_ratio=None, source_sync_time=_sync())


def _issue_record(plant_id, release_date, quantity) -> WBIssueRecord:
    return WBIssueRecord(
        source_sync_time=_sync(), plant_id=plant_id, site=None, schedule=None, customer_code=None, customer_name=None,
        device_type=None, issue_quantity=quantity, lead_count=None, package_code=None, package_type=None, region=None,
        release_date=release_date, release_date_raw=release_date.isoformat() if release_date else None, release_time=None,
        release_system=None, time_bucket=None, wafer_inch=None, year=None,
        bd_no_unknown=None, cu_flag_unknown=None, customer_run_type_unknown=None, customer_sod_unknown=None,
        internal_sod_unknown=None, routid_unknown=None, run_type_unknown=None, unit_of_measure_unknown=None,
        user_id_unknown=None, user_name_unknown=None,
    )


def _normal_bank_records(plant_id: str) -> list[WBBankRecord]:
    """All READY_TO_ISSUE -- a genuinely normal BANK reading, independent
    of whatever story the golden dataset happens to tell for `plant_id`
    (ASE07/SCENARIO_B_PLANT's OWN golden data already has a persistent
    material-shortage signal baked in -- item R/Q's "same goal, different
    evidence" proof requires an ACTUALLY isolated baseline, not one that
    silently carries a pre-existing abnormal signal from the frozen
    synthetic dataset into every scenario that doesn't explicitly
    override it)."""
    return [
        WBBankRecord(plant_id=plant_id, site_group=WBSiteGroup.A2, site_group_raw="A2", mother_batch_id=f"M{i}", customer_code=None, customer_sub_code=None, customer_group=None, device=None, package_code=None, lead_count=None, wafer_size_inch=None, wafer_quantity=5, die_quantity=100, bank_status=WBBankStatus.READY_TO_ISSUE, bank_status_raw="Ready To Issue", bank_entry_time=None, description=None, run_type=None, customer_run_type=None, unit_of_measure=None, source_sync_time=_sync())
        for i in range(10)
    ]


def _normal_wip_records(plant_id: str) -> list[WBWIPRecord]:
    return [
        WBWIPRecord(plant_id=plant_id, facility_source=None, mother_batch_id=f"M{i}", child_batch_id=f"C{i}", operation_id="OP1", current_quantity=10, customer_code=None, package_code=None, lead_count=None, run_type=None, lot_status=WBLotStatus.ACTIVE, lot_status_raw="Active", source_sync_time=_sync())
        for i in range(10)
    ]


def _normal_issue_records(plant_id: str) -> list[WBIssueRecord]:
    days = [HISTORY_DECLINE_START - timedelta(days=i) for i in range(-3, 4)]
    return [_issue_record(plant_id, d, 700) for d in days]  # flat 700/day -- no decline, no baseline gap


def _controlled_normal_datasources(plant_id: str) -> WBDataSources:
    """The isolated baseline every scenario below starts from -- BANK/WIP/
    ISSUE fully controlled to genuinely normal for `plant_id` (never the
    golden dataset's own possibly-abnormal defaults), OEE/OUTPUT reused
    from the golden dataset unchanged (OEE is already at its own normal
    85.0 baseline for every plant except ASE01/ASE08's own golden
    stories; OUTPUT is what keeps the "Output is low" symptom real and
    confirmable for ASE07 specifically)."""
    base = make_wb_datasources()
    return WBDataSources(
        oee=base.oee, bank=InMemoryWBBankDataSource(_normal_bank_records(plant_id)),
        wip=InMemoryWBWIPDataSource(_normal_wip_records(plant_id)), output=base.output,
        issue=InMemoryWBIssueDataSource(_normal_issue_records(plant_id)),
    )


def _bank_severe_shortage_datasources(plant_id: str) -> WBDataSources:
    """State A for the same-goal/different-evidence proof: BANK severe
    shortage, everything else controlled-normal."""
    normal = _controlled_normal_datasources(plant_id)
    bank_records = [
        WBBankRecord(plant_id=plant_id, site_group=WBSiteGroup.A2, site_group_raw="A2", mother_batch_id=f"M{i}", customer_code=None, customer_sub_code=None, customer_group=None, device=None, package_code=None, lead_count=None, wafer_size_inch=None, wafer_quantity=5, die_quantity=100, bank_status=WBBankStatus.MATERIAL_SHORTAGE if i < 9 else WBBankStatus.READY_TO_ISSUE, bank_status_raw="Material Shortage", bank_entry_time=None, description=None, run_type=None, customer_run_type=None, unit_of_measure=None, source_sync_time=_sync())
        for i in range(10)
    ]
    return WBDataSources(oee=normal.oee, bank=InMemoryWBBankDataSource(bank_records), wip=normal.wip, output=normal.output, issue=normal.issue)


def _issue_severe_decline_datasources(plant_id: str) -> WBDataSources:
    """State B for the same-goal/different-evidence proof: BANK normal,
    ISSUE severely declining over the historical window, everything else
    controlled-normal."""
    normal = _controlled_normal_datasources(plant_id)
    days = [HISTORY_DECLINE_START - timedelta(days=i) for i in range(-3, 4)]
    records = [_issue_record(plant_id, d, 1000) for d in days[:-1]] + [_issue_record(plant_id, days[-1], 100)]
    return WBDataSources(oee=normal.oee, bank=normal.bank, wip=normal.wip, output=normal.output, issue=InMemoryWBIssueDataSource(records))


def _wip_hold_high_datasources(plant_id: str) -> WBDataSources:
    normal = _controlled_normal_datasources(plant_id)
    records = [
        WBWIPRecord(plant_id=plant_id, facility_source=None, mother_batch_id=f"M{i}", child_batch_id=f"C{i}", operation_id="OP1", current_quantity=10, customer_code=None, package_code=None, lead_count=None, run_type=None, lot_status=WBLotStatus.HOLD if i < 8 else WBLotStatus.ACTIVE, lot_status_raw="Hold", source_sync_time=_sync())
        for i in range(10)
    ]
    return WBDataSources(oee=normal.oee, bank=normal.bank, wip=InMemoryWBWIPDataSource(records), output=normal.output, issue=normal.issue)


def _oee_poor_datasources(plant_id: str) -> WBDataSources:
    normal = _controlled_normal_datasources(plant_id)
    records = [r for r in build_wb_plant_oee_records() if r.plant_id != plant_id] + [_oee_record(plant_id, GOLDEN_DATE, 35.0)]
    return WBDataSources(oee=InMemoryWBPlantOEEDataSource(records), bank=normal.bank, wip=normal.wip, output=normal.output, issue=normal.issue)


def _all_normal_datasources(plant_id: str) -> WBDataSources:
    return _controlled_normal_datasources(plant_id)


def _issue_invalid_bank_shortage_datasources(plant_id: str) -> WBDataSources:
    """Novel combination: BANK shortage high (real signal) AND ISSUE data
    contains an invalid negative record -- tests data-quality-aware
    reasoning INSIDE an RCA chain, a shape WBPlanningPolicy's deterministic
    branches don't specifically special-case."""
    normal = _controlled_normal_datasources(plant_id)
    bank_records = [
        WBBankRecord(plant_id=plant_id, site_group=WBSiteGroup.A2, site_group_raw="A2", mother_batch_id=f"M{i}", customer_code=None, customer_sub_code=None, customer_group=None, device=None, package_code=None, lead_count=None, wafer_size_inch=None, wafer_quantity=5, die_quantity=100, bank_status=WBBankStatus.MATERIAL_SHORTAGE if i < 9 else WBBankStatus.READY_TO_ISSUE, bank_status_raw="Material Shortage", bank_entry_time=None, description=None, run_type=None, customer_run_type=None, unit_of_measure=None, source_sync_time=_sync())
        for i in range(10)
    ]
    issue_records = _normal_issue_records(plant_id) + [_issue_record(plant_id, GOLDEN_DATE, -9999)]
    return WBDataSources(oee=normal.oee, bank=InMemoryWBBankDataSource(bank_records), wip=normal.wip, output=normal.output, issue=InMemoryWBIssueDataSource(issue_records))


def _multi_signal_ambiguous_datasources(plant_id: str) -> WBDataSources:
    """Novel combination: BANK moderately elevated (just above threshold),
    WIP slightly elevated (just above threshold), OEE normal -- two
    borderline signals at once, neither overwhelming, genuinely testing
    whether the Planner weighs relative strength rather than just
    checking a fixed priority order."""
    normal = _controlled_normal_datasources(plant_id)
    bank_records = [
        WBBankRecord(plant_id=plant_id, site_group=WBSiteGroup.A2, site_group_raw="A2", mother_batch_id=f"M{i}", customer_code=None, customer_sub_code=None, customer_group=None, device=None, package_code=None, lead_count=None, wafer_size_inch=None, wafer_quantity=5, die_quantity=100, bank_status=WBBankStatus.MATERIAL_SHORTAGE if i < 5 else WBBankStatus.READY_TO_ISSUE, bank_status_raw="Material Shortage", bank_entry_time=None, description=None, run_type=None, customer_run_type=None, unit_of_measure=None, source_sync_time=_sync())
        for i in range(10)
    ]
    wip_records = [
        WBWIPRecord(plant_id=plant_id, facility_source=None, mother_batch_id=f"M{i}", child_batch_id=f"C{i}", operation_id="OP1", current_quantity=10, customer_code=None, package_code=None, lead_count=None, run_type=None, lot_status=WBLotStatus.HOLD if i < 4 else WBLotStatus.ACTIVE, lot_status_raw="Hold", source_sync_time=_sync())
        for i in range(10)
    ]
    return WBDataSources(oee=normal.oee, bank=InMemoryWBBankDataSource(bank_records), wip=InMemoryWBWIPDataSource(wip_records), output=normal.output, issue=normal.issue)


_BUDGET_ARGS = dict(max_steps=6, max_tool_calls=20, max_depth_per_entity=2)


def _budget():
    from agent.state.models import Budget
    return Budget(**_BUDGET_ARGS)


# ============================================================================
# Section AK/AL minimums -- single real Planner call, INFORMATION/ANALYSIS/RCA.
# ============================================================================


def test_real_wb_information_decision_is_legal():
    policy, usage_sink, resolver, skill_registry, *_ = _real_wb_planner_policy()
    module_state = _bootstrap_module_state(TaskType.INFORMATION, "2026-08-12 ASE07 的投料狀況如何", "wb-real-info", _budget())

    objective = policy.propose_next_objective(module_state)

    assert objective is not None
    _assert_real_usage_recorded(usage_sink, module_state.run_id)
    decision = decision_from_objective(objective, rationale="n/a")
    quality = evaluate_planner_decision_quality(decision, module_state=module_state, task_type=TaskType.INFORMATION, capability_resolver=resolver, skill_registry=skill_registry)
    _print_row("INFORMATION single-round", objective, quality)


def test_real_wb_analysis_decision_is_legal():
    policy, usage_sink, resolver, skill_registry, *_ = _real_wb_planner_policy()
    module_state = _bootstrap_module_state(TaskType.ANALYSIS, "2026-08-12 ASE07 這週投料是不是一直偏低？", "wb-real-analysis", _budget())

    objective = policy.propose_next_objective(module_state)

    assert objective is not None
    _assert_real_usage_recorded(usage_sink, module_state.run_id)
    decision = decision_from_objective(objective, rationale="n/a")
    quality = evaluate_planner_decision_quality(decision, module_state=module_state, task_type=TaskType.ANALYSIS, capability_resolver=resolver, skill_registry=skill_registry)
    _print_row("ANALYSIS single-round", objective, quality)


def test_real_wb_rca_round_1_decision_is_legal():
    policy, usage_sink, resolver, skill_registry, *_ = _real_wb_planner_policy()
    module_state = _bootstrap_module_state(TaskType.RCA, "2026-08-12 為什麼 ASE07 Output 偏低？", "wb-real-rca-1", _budget())

    objective = policy.propose_next_objective(module_state)

    assert objective is not None
    _assert_real_usage_recorded(usage_sink, module_state.run_id)
    decision = decision_from_objective(objective, rationale="n/a")
    quality = evaluate_planner_decision_quality(decision, module_state=module_state, task_type=TaskType.RCA, capability_resolver=resolver, skill_registry=skill_registry)
    _print_row("RCA round 1", objective, quality)


# ============================================================================
# Item AM -- full multi-round real LLM trace through the Module ReAct Loop.
# ============================================================================


def test_real_wb_multi_round_trace_reaches_terminal_status():
    policy, usage_sink, resolver, skill_registry, package, tool_registry = _real_wb_planner_policy()
    runtime = _capability_runtime(skill_registry, tool_registry)

    final_state = _run_wb_graph(TaskType.RCA, "2026-08-12 為什麼 ASE07 Output 偏低？", "wb-real-multiround", policy, runtime, _budget())

    print("\n=== Multi-round real LLM trace: 為什麼 ASE07 Output 偏低？ ===")
    for i, record in enumerate(final_state.objective_history.values(), start=1):
        print(f"Round {i}: capability={record.capability_key} action={record.action.value} target={record.target_ref.ref_id} status={record.status.value}")
    for finding in final_state.findings:
        print(f"Finding: {finding.statement} (is_root_cause={finding.is_root_cause})")

    assert final_state.status in (ModuleStatus.COMPLETE, ModuleStatus.PARTIAL)
    assert len(final_state.objective_history) >= 1
    # no fabricated root cause -- WB plant-level data ceiling (causal_inference_guard's own rule)
    assert all(f.is_root_cause is False for f in final_state.findings)
    _assert_real_usage_recorded(usage_sink, "wb-real-multiround")


# ============================================================================
# Item Q -- same goal, different evidence -> materially different decisions.
# At least 4 cases.
# ============================================================================


def test_same_goal_different_evidence_case_1_bank_vs_issue():
    """State A: BANK severe shortage, ISSUE normal. State B: BANK normal,
    ISSUE severely declining. Same goal statement both times."""
    goal = "2026-08-12 為什麼 ASE07 Output 偏低？"

    policy_a, usage_a, resolver_a, sr_a, package_a, tr_a = _real_wb_planner_policy(datasources=_bank_severe_shortage_datasources(SCENARIO_B_PLANT))
    state_a = _run_wb_graph(TaskType.RCA, goal, "wb-diff-ev-1a", policy_a, _capability_runtime(sr_a, tr_a), _budget())

    policy_b, usage_b, resolver_b, sr_b, package_b, tr_b = _real_wb_planner_policy(datasources=_issue_severe_decline_datasources(SCENARIO_B_PLANT))
    state_b = _run_wb_graph(TaskType.RCA, goal, "wb-diff-ev-1b", policy_b, _capability_runtime(sr_b, tr_b), _budget())

    caps_a = [r.capability_key for r in state_a.objective_history.values()]
    caps_b = [r.capability_key for r in state_b.objective_history.values()]
    print(f"\nState A (BANK severe): {caps_a} -> {state_a.findings[-1].statement if state_a.findings else 'NONE'}")
    print(f"State B (ISSUE severe): {caps_b} -> {state_b.findings[-1].statement if state_b.findings else 'NONE'}")

    assert caps_a != caps_b or (state_a.findings and state_b.findings and state_a.findings[-1].statement != state_b.findings[-1].statement)


def test_same_goal_different_evidence_case_2_wip_vs_oee():
    goal = "2026-08-12 為什麼 ASE07 Output 偏低？"

    policy_a, usage_a, resolver_a, sr_a, package_a, tr_a = _real_wb_planner_policy(datasources=_wip_hold_high_datasources(SCENARIO_B_PLANT))
    state_a = _run_wb_graph(TaskType.RCA, goal, "wb-diff-ev-2a", policy_a, _capability_runtime(sr_a, tr_a), _budget())

    policy_b, usage_b, resolver_b, sr_b, package_b, tr_b = _real_wb_planner_policy(datasources=_oee_poor_datasources(SCENARIO_B_PLANT))
    state_b = _run_wb_graph(TaskType.RCA, goal, "wb-diff-ev-2b", policy_b, _capability_runtime(sr_b, tr_b), _budget())

    caps_a = [r.capability_key for r in state_a.objective_history.values()]
    caps_b = [r.capability_key for r in state_b.objective_history.values()]
    print(f"\nState A (WIP Hold high): {caps_a} -> {state_a.findings[-1].statement if state_a.findings else 'NONE'}")
    print(f"State B (OEE poor): {caps_b} -> {state_b.findings[-1].statement if state_b.findings else 'NONE'}")

    assert caps_a != caps_b or (state_a.findings and state_b.findings and state_a.findings[-1].statement != state_b.findings[-1].statement)


def test_same_goal_different_evidence_case_3_all_normal_vs_bank_shortage():
    goal = "2026-08-12 為什麼 ASE07 Output 偏低？"

    policy_a, usage_a, resolver_a, sr_a, package_a, tr_a = _real_wb_planner_policy(datasources=_all_normal_datasources(SCENARIO_B_PLANT))
    state_a = _run_wb_graph(TaskType.RCA, goal, "wb-diff-ev-3a", policy_a, _capability_runtime(sr_a, tr_a), _budget())

    policy_b, usage_b, resolver_b, sr_b, package_b, tr_b = _real_wb_planner_policy(datasources=_bank_severe_shortage_datasources(SCENARIO_B_PLANT))
    state_b = _run_wb_graph(TaskType.RCA, goal, "wb-diff-ev-3b", policy_b, _capability_runtime(sr_b, tr_b), _budget())

    print(f"\nState A (all normal): {state_a.findings[-1].statement if state_a.findings else 'NONE'}")
    print(f"State B (BANK shortage): {state_b.findings[-1].statement if state_b.findings else 'NONE'}")

    assert not state_a.findings or not state_b.findings or state_a.findings[-1].statement != state_b.findings[-1].statement


def test_same_goal_different_evidence_case_4_multi_signal_vs_single_signal():
    goal = "2026-08-12 為什麼 ASE07 Output 偏低？"

    policy_a, usage_a, resolver_a, sr_a, package_a, tr_a = _real_wb_planner_policy(datasources=_multi_signal_ambiguous_datasources(SCENARIO_B_PLANT))
    state_a = _run_wb_graph(TaskType.RCA, goal, "wb-diff-ev-4a", policy_a, _capability_runtime(sr_a, tr_a), _budget())

    policy_b, usage_b, resolver_b, sr_b, package_b, tr_b = _real_wb_planner_policy(datasources=_wip_hold_high_datasources(SCENARIO_B_PLANT))
    state_b = _run_wb_graph(TaskType.RCA, goal, "wb-diff-ev-4b", policy_b, _capability_runtime(sr_b, tr_b), _budget())

    caps_a = [r.capability_key for r in state_a.objective_history.values()]
    caps_b = [r.capability_key for r in state_b.objective_history.values()]
    print(f"\nState A (multi-signal ambiguous): {caps_a} -> {state_a.findings[-1].statement if state_a.findings else 'NONE'}")
    print(f"State B (WIP Hold high only): {caps_b} -> {state_b.findings[-1].statement if state_b.findings else 'NONE'}")

    assert caps_a != caps_b or (state_a.findings and state_b.findings and state_a.findings[-1].statement != state_b.findings[-1].statement)


# ============================================================================
# Item R -- novel scenarios, no deterministic-policy branch added for them.
# At least 3.
# ============================================================================


def test_novel_scenario_1_bank_shortage_with_invalid_issue_data():
    """Data-quality-aware reasoning INSIDE an RCA chain -- WBPlanningPolicy
    has no special-cased branch for "contributing factor + concurrent
    invalid data on an unrelated source"."""
    policy, usage_sink, resolver, skill_registry, package, tool_registry = _real_wb_planner_policy(
        datasources=_issue_invalid_bank_shortage_datasources(SCENARIO_B_PLANT)
    )
    final_state = _run_wb_graph(TaskType.RCA, "2026-08-12 為什麼 ASE07 Output 偏低？這週 trend", "wb-novel-1", policy, _capability_runtime(skill_registry, tool_registry), _budget())

    print(f"\n=== Novel scenario 1: BANK shortage + invalid ISSUE data ===")
    caps = [r.capability_key for r in final_state.objective_history.values()]
    print(f"Capability chain: {caps}")
    if final_state.findings:
        print(f"Finding: {final_state.findings[-1].statement}")

    assert final_state.status in (ModuleStatus.COMPLETE, ModuleStatus.PARTIAL)
    assert all(f.is_root_cause is False for f in final_state.findings)
    if final_state.findings:
        assert "-9999" not in final_state.findings[-1].statement  # invalid value never surfaces as if trustworthy


def test_novel_scenario_2_multi_signal_borderline_ambiguity():
    """Two borderline signals (BANK moderately elevated, WIP slightly
    elevated) at once -- WBPlanningPolicy's deterministic priority order
    just checks BANK then WIP in a fixed sequence and stops at the first
    abnormal one; this tests whether the real Planner's choice is still
    legal/relevant/evidence-supported when both are only mildly abnormal."""
    policy, usage_sink, resolver, skill_registry, package, tool_registry = _real_wb_planner_policy(
        datasources=_multi_signal_ambiguous_datasources(SCENARIO_B_PLANT)
    )
    final_state = _run_wb_graph(TaskType.RCA, "2026-08-12 為什麼 ASE07 Output 偏低？", "wb-novel-2", policy, _capability_runtime(skill_registry, tool_registry), _budget())

    print(f"\n=== Novel scenario 2: multi-signal borderline ambiguity ===")
    caps = [r.capability_key for r in final_state.objective_history.values()]
    print(f"Capability chain: {caps}")
    if final_state.findings:
        print(f"Finding: {final_state.findings[-1].statement}")

    assert final_state.status in (ModuleStatus.COMPLETE, ModuleStatus.PARTIAL)
    assert all(f.is_root_cause is False for f in final_state.findings)
    assert len(final_state.objective_history) <= _BUDGET_ARGS["max_steps"]  # budget-aware, never runaway


def test_novel_scenario_3_historical_insufficient_coverage_during_rca():
    """RCA that also needs to reason about historical insufficiency --
    ISSUE has only 1 day of usable data within the requested window.
    WBPlanningPolicy's historical chain doesn't special-case "insufficient
    coverage discovered mid-RCA-chain" beyond the generic Limitation
    machinery; this tests whether the real Planner still reaches an
    honest terminal state without fabricating a trend conclusion."""
    base = make_wb_datasources()
    sparse_issue = InMemoryWBIssueDataSource([_issue_record(SCENARIO_B_PLANT, GOLDEN_DATE, 100)])
    datasources = WBDataSources(oee=base.oee, bank=base.bank, wip=base.wip, output=base.output, issue=sparse_issue)

    policy, usage_sink, resolver, skill_registry, package, tool_registry = _real_wb_planner_policy(datasources=datasources)
    final_state = _run_wb_graph(TaskType.RCA, "2026-08-12 ASE07 output 偏低 這週 trend root cause", "wb-novel-3", policy, _capability_runtime(skill_registry, tool_registry), _budget())

    print(f"\n=== Novel scenario 3: insufficient historical coverage during RCA ===")
    caps = [r.capability_key for r in final_state.objective_history.values()]
    print(f"Capability chain: {caps}")
    print(f"Limitations: {[l.description for l in final_state.limitations]}")
    if final_state.findings:
        print(f"Finding: {final_state.findings[-1].statement}")

    assert final_state.status in (ModuleStatus.COMPLETE, ModuleStatus.PARTIAL)
    assert all(f.is_root_cause is False for f in final_state.findings)


# ============================================================================
# Fallback -- OpenAI adapter failure still degrades safely (offline, no
# real network call needed for THIS test -- mirrors
# test_real_planner_fallback_wiring.py's own pattern exactly, just for the
# new provider).
# ============================================================================


class _AlwaysFailingCompletions:
    def create(self, **kwargs):
        raise RuntimeError("simulated OpenAI network failure -- never a real API call")


class _AlwaysFailingChat:
    def __init__(self):
        self.completions = _AlwaysFailingCompletions()


class _AlwaysFailingOpenAIClient:
    def __init__(self):
        self.chat = _AlwaysFailingChat()


def test_openai_provider_failure_falls_back_to_deterministic_wb_baseline():
    package, skill_registry, tool_registry = _wb_registries()
    adapter = OpenAICompatibleAdapter(client=_AlwaysFailingOpenAIClient())
    usage_sink = InMemoryLLMUsageSink()
    router = LLMRouter(routes={"planner": LLMRouteConfig(route="planner", model=_MODEL, max_retries=1)}, client=adapter, usage_sink=usage_sink)
    context_builder = PlannerContextBuilder(DeterministicEvidenceSelector(), DeterministicCapabilityRetriever(skill_registry))
    decision_sink = InMemoryPlannerDecisionAuditSink()
    policy = LLMPlanningPolicy(WBPlanningPolicy(), context_builder, router, skill_registry, decision_audit_sink=decision_sink)

    module_state = _bootstrap_module_state(TaskType.RCA, "2026-08-12 ASE01 OEE 表現差 root cause", "wb-openai-fallback", _budget())
    objective = policy.propose_next_objective(module_state)

    assert objective is not None  # the deterministic WB baseline still proposes something
    record = decision_sink.list_for_run(module_state.run_id)[0]
    assert record.source == DecisionSource.FALLBACK
    assert record.fallback_reason is not None
