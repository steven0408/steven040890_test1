"""Phase 5B-3A: LLM Runtime (LLMRouter + MockLLMClient + LLMUsageSink) --
model selection, timeout, retry, typed-output validation, usage logging.
Fallback-model-chain retry is contract-only this phase (LLMRouteConfig.
fallback_models exists but isn't wired into retry behavior yet).
"""
import pytest

from agent.llm.client import MockLLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.models import LLMCallStatus, LLMInvalidOutputError, LLMMessage, LLMProviderError, LLMRole, LLMTimeoutError
from agent.llm.router import LLMRouteNotFoundError, LLMRouter, LLMRouterError
from agent.llm.usage import InMemoryLLMUsageSink
from agent.state.base import RCABaseModel

_MESSAGES = [LLMMessage(role=LLMRole.USER, content="hello world")]


class _Echo(RCABaseModel):
    value: str


def _router(responder, *, max_retries: int = 1) -> tuple[LLMRouter, InMemoryLLMUsageSink, MockLLMClient]:
    client = MockLLMClient(responder)
    sink = InMemoryLLMUsageSink()
    router = LLMRouter(
        routes={"test-route": LLMRouteConfig(route="test-route", model="mock-1", max_retries=max_retries)},
        client=client,
        usage_sink=sink,
    )
    return router, sink, client


def test_successful_call_returns_typed_output_and_records_usage():
    router, sink, client = _router(lambda req: _Echo(value="ok"))
    outcome = router.call("test-route", _MESSAGES, _Echo, run_id="run-1", module_id=None, node="analyzer")

    assert outcome.parsed_output == _Echo(value="ok")
    assert len(client.calls) == 1
    records = sink.list_for_run("run-1")
    assert len(records) == 1
    assert records[0].status == LLMCallStatus.SUCCESS
    assert records[0].retry_count == 0
    assert records[0].route == "test-route"
    assert records[0].model == "mock-1"
    # the returned outcome's own call_record IS that same audited record --
    # this is the correlation seam PlannerDecisionRecord.llm_call_id uses
    assert outcome.call_record == records[0]


def test_retry_succeeds_after_one_failure():
    attempts = {"n": 0}

    def responder(req):
        attempts["n"] += 1
        if attempts["n"] == 1:
            raise LLMProviderError("simulated provider hiccup")
        return _Echo(value="recovered")

    router, sink, client = _router(responder, max_retries=1)
    outcome = router.call("test-route", _MESSAGES, _Echo, run_id="run-2", module_id=None, node="analyzer")

    assert outcome.parsed_output == _Echo(value="recovered")
    assert len(client.calls) == 2
    records = sink.list_for_run("run-2")
    assert [r.status for r in records] == [LLMCallStatus.PROVIDER_ERROR, LLMCallStatus.SUCCESS]
    assert [r.retry_count for r in records] == [0, 1]


def test_timeout_exhausts_retries_and_raises_typed_router_error():
    router, sink, client = _router(lambda req: (_ for _ in ()).throw(LLMTimeoutError("too slow")), max_retries=1)

    with pytest.raises(LLMRouterError):
        router.call("test-route", _MESSAGES, _Echo, run_id="run-3", module_id=None, node="analyzer")

    assert len(client.calls) == 2  # initial attempt + 1 retry
    records = sink.list_for_run("run-3")
    assert [r.status for r in records] == [LLMCallStatus.TIMEOUT, LLMCallStatus.TIMEOUT]


def test_invalid_structured_output_is_rejected_and_recorded():
    # extra field not in _Echo's schema -- RCABaseModel's extra="forbid" rejects it
    router, sink, client = _router(lambda req: {"value": "ok", "unexpected_extra_field": "should be rejected"}, max_retries=0)

    with pytest.raises(LLMRouterError):
        router.call("test-route", _MESSAGES, _Echo, run_id="run-4", module_id=None, node="analyzer")

    records = sink.list_for_run("run-4")
    assert records[0].status == LLMCallStatus.INVALID_OUTPUT


def test_unknown_route_raises_typed_error():
    router, _, _ = _router(lambda req: _Echo(value="ok"))
    with pytest.raises(LLMRouteNotFoundError):
        router.call("no-such-route", _MESSAGES, _Echo, run_id="run-5", module_id=None, node="analyzer")


def test_usage_sink_scopes_records_by_run_id():
    router, sink, _ = _router(lambda req: _Echo(value="ok"))
    router.call("test-route", _MESSAGES, _Echo, run_id="run-a", module_id=None, node="analyzer")
    router.call("test-route", _MESSAGES, _Echo, run_id="run-b", module_id=None, node="analyzer")

    assert len(sink.list_for_run("run-a")) == 1
    assert len(sink.list_for_run("run-b")) == 1
    assert sink.list_for_run("run-c") == []
