"""Phase PROD-1: symmetric guard to test_analyzer_mock_production_boundary.py.
Before this phase, `build_phase2_graph`/`build_phase6_graph` hardcoded
`standardizer_mock` with no override at all -- there was no way to reach
the real `standardizer_llm` node in "the" production graph, even via
`build_production_graph`. This phase added an optional `standardizer`
parameter (mirroring `analyzer`'s existing shape exactly) and made it
REQUIRED on the two `build_production_graph*` wrappers specifically, so a
real deployment entrypoint cannot forget it and silently get
`standardizer_mock`.
"""
import ast
from pathlib import Path

import pytest
from langgraph.checkpoint.memory import InMemorySaver

from agent.graph.production import build_production_graph, build_production_graph_with_synthesis

_AGENT_DIR = Path(__file__).resolve().parents[1] / "agent"


def _custom_analyzer(state):
    return {}


def _custom_standardizer(state):
    return {}


def test_bootstrap_never_imports_standardizer_mock():
    tree = ast.parse((_AGENT_DIR / "bootstrap.py").read_text(encoding="utf-8"), filename="bootstrap.py")
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module is not None and "standardizer_mock" in node.module:
            pytest.fail(f"agent/bootstrap.py imports from '{node.module}'")
        if isinstance(node, ast.Import):
            for alias in node.names:
                if "standardizer_mock" in alias.name:
                    pytest.fail(f"agent/bootstrap.py imports '{alias.name}'")


def test_production_graph_requires_explicit_standardizer():
    with pytest.raises(TypeError):
        build_production_graph({}, InMemorySaver(), analyzer=_custom_analyzer)  # type: ignore[call-arg]


def test_production_graph_with_synthesis_requires_explicit_standardizer():
    with pytest.raises(TypeError):
        build_production_graph_with_synthesis({}, InMemorySaver(), lambda state: {}, analyzer=_custom_analyzer)  # type: ignore[call-arg]


def test_production_graph_delegates_with_given_standardizer():
    """Proves the override is a pure pass-through -- no new topology."""
    from agent.graph.graph import build_phase2_graph

    expected = build_phase2_graph({}, InMemorySaver(), analyzer=_custom_analyzer, standardizer=_custom_standardizer)
    actual = build_production_graph({}, InMemorySaver(), analyzer=_custom_analyzer, standardizer=_custom_standardizer)
    assert set(actual.nodes) == set(expected.nodes)


def test_default_phase2_graph_still_uses_standardizer_mock_when_omitted():
    """Backward compatibility: the ~90 existing Harness-mechanics tests
    that call build_phase2_graph without a `standardizer=` kwarg must keep
    getting standardizer_mock, unchanged."""
    from agent.graph.graph import build_phase2_graph
    from agent.graph.nodes.standardizer_mock import standardizer_mock

    graph = build_phase2_graph({}, InMemorySaver())
    node = graph.nodes["standardizer"]
    # LangGraph wraps the raw callable -- compare by identity through the
    # node spec's own `.runnable.func` when available, else fall back to a
    # structural smoke check that the graph still builds with the same
    # node set as an explicit standardizer_mock call.
    explicit = build_phase2_graph({}, InMemorySaver(), standardizer=standardizer_mock)
    assert set(graph.nodes) == set(explicit.nodes)
