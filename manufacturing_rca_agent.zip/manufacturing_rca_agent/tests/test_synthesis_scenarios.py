"""Phase 6A items 9-12/14: end-to-end ModuleState(s) -> SynthesisContext ->
HandoffPackage -> Markdown scenarios, covering every TaskType, PARTIAL/
BLOCKED/FAILED module statuses, and multi-module aggregation -- the
overall-status rule (item 8) exercised against real and hand-built
ModuleState fixtures.
"""
from agent.llm.context.synthesis_context import SynthesisContextBuilder
from agent.state.enums import (
    ErrorType,
    EvidenceQuality,
    FindingStatus,
    ModuleStatus,
    SynthesisOverallStatus,
    TaskType,
)
from agent.state.models import ErrorRecord, Evidence, Finding, Goal, GoalScope, Limitation, RejectionRecord
from agent.synthesis.handoff_builder import ModuleHandoffBuilder
from agent.synthesis.package import build_handoff_package
from agent.synthesis.renderer import render_markdown

from .conftest import make_agent_state, make_module_state, run_oee_module_state_history


def _state_with_modules(*, task_type: TaskType, **module_states) -> "AgentState":
    state = make_agent_state()
    return state.model_copy(
        update={
            "module_states": module_states,
            "global_goal": Goal(goal_id="g1", raw_statement="test request", normalized_statement="test request", task_type=task_type, scope=GoalScope()),
        }
    )


def _package_for(state, *, budget=None):
    outcome = SynthesisContextBuilder(ModuleHandoffBuilder()).build(state, budget=budget)
    return build_handoff_package(outcome.context)


# ============================================================================
# INFORMATION (item 9)
# ============================================================================


def test_information_scenario_has_status_summary_no_rca():
    history = run_oee_module_state_history(TaskType.INFORMATION)
    final = history[-1]
    assert final.status == ModuleStatus.COMPLETE

    state = _state_with_modules(task_type=TaskType.INFORMATION, OEE=final)
    package = _package_for(state)

    assert package.overall_status == SynthesisOverallStatus.COMPLETE
    assert package.root_causes == []
    assert "Root Causes" not in package.markdown


# ============================================================================
# ANALYSIS (item 10)
# ============================================================================


def test_analysis_scenario_has_ranking_no_root_cause():
    history = run_oee_module_state_history(TaskType.ANALYSIS)
    final = history[-1]
    assert final.status == ModuleStatus.COMPLETE
    assert final.findings and final.findings[-1].is_root_cause is False

    state = _state_with_modules(task_type=TaskType.ANALYSIS, OEE=final)
    package = _package_for(state)

    assert package.overall_status == SynthesisOverallStatus.COMPLETE
    assert package.root_causes == []
    assert package.key_findings  # the screening/ranking finding is present
    assert "Root Causes" not in package.markdown
    assert "Key Findings" in package.markdown


# ============================================================================
# RCA COMPLETE (item 11's baseline) + PARTIAL (item 11)
# ============================================================================


def test_rca_complete_scenario_has_correct_root_cause():
    history = run_oee_module_state_history(TaskType.RCA)
    final = history[-1]
    assert final.status == ModuleStatus.COMPLETE

    state = _state_with_modules(task_type=TaskType.RCA, OEE=final)
    package = _package_for(state)

    assert package.overall_status == SynthesisOverallStatus.COMPLETE
    assert package.root_causes
    assert "Motor Failure" in package.root_causes[0].statement
    assert "Motor Failure" in package.markdown


def test_rca_partial_scenario_availability_confirmed_detail_unavailable():
    module_state = make_module_state().model_copy(
        update={
            "status": ModuleStatus.PARTIAL,
            "findings": [Finding(finding_id="f1", statement="Availability is the dominant loss pattern.", pattern="Availability", confidence=0.7, status=FindingStatus.CONFIRMED, is_root_cause=False)],
            "limitations": [
                Limitation(
                    limitation_id="lim1", description="EQ001 downtime detail unavailable.", impacted_objective_id="obj-2",
                    impact_statement="exact failure mechanism unknown",
                    related_error=ErrorRecord(error_type=ErrorType.DATA_NOT_FOUND, message="x", objective_id="obj-2", occurred_at_step=2),
                )
            ],
        }
    )
    state = _state_with_modules(task_type=TaskType.RCA, OEE=module_state)
    package = _package_for(state)

    assert package.overall_status == SynthesisOverallStatus.PARTIAL
    assert package.root_causes == []  # root cause genuinely unresolved -- must not be fabricated
    assert package.unresolved_questions
    assert package.limitations
    assert "Root Causes" not in package.markdown
    assert "Unresolved Questions" in package.markdown


# ============================================================================
# Multi-module (item 12)
# ============================================================================


def test_multi_module_oee_complete_output_complete_wip_partial():
    oee = make_module_state(module_id="OEE", module_type="OEE").model_copy(
        update={"status": ModuleStatus.COMPLETE, "findings": [Finding(finding_id="f1", statement="OEE Motor Failure.", pattern="Availability", confidence=0.9, status=FindingStatus.CONFIRMED, is_root_cause=True)]}
    )
    output = make_module_state(module_id="Output", module_type="Output").model_copy(
        update={"status": ModuleStatus.COMPLETE, "findings": [Finding(finding_id="f1", statement="Output shortfall traced to line stoppage.", pattern="Downtime", confidence=0.85, status=FindingStatus.CONFIRMED, is_root_cause=True)]}
    )
    wip = make_module_state(module_id="WIP", module_type="WIP").model_copy(
        update={
            "status": ModuleStatus.PARTIAL,
            "findings": [Finding(finding_id="f1", statement="WIP congestion observed near Station 3.", pattern="Congestion", confidence=0.5, status=FindingStatus.CONFIRMED, is_root_cause=False)],
            "limitations": [Limitation(limitation_id="lim1", description="Upstream buffer data unavailable.", impacted_objective_id="obj-1", impact_statement="cannot confirm root cause")],
        }
    )
    state = _state_with_modules(task_type=TaskType.RCA, OEE=oee, Output=output, WIP=wip)
    package = _package_for(state)

    assert package.overall_status == SynthesisOverallStatus.PARTIAL
    assert {m.module_id for m in package.module_results} == {"OEE", "Output", "WIP"}
    # all three modules' results are fully preserved, not collapsed/dropped
    assert len(package.module_results) == 3
    assert len(package.root_causes) == 2  # OEE + Output, not WIP (still PARTIAL/unconfirmed)


# ============================================================================
# BLOCKED (item 13)
# ============================================================================


def test_blocked_module_permission_limitation_separated_from_data_limitation_overall_partial():
    blocked = make_module_state(module_id="OEE", module_type="OEE").model_copy(
        update={"status": ModuleStatus.BLOCKED, "rejections": [RejectionRecord(objective_id="obj-2", permission_type="restricted_query", reason="operator denied", alternative_found=False)]}
    )
    complete = make_module_state(module_id="Output", module_type="Output").model_copy(
        update={"status": ModuleStatus.COMPLETE, "findings": [Finding(finding_id="f1", statement="Output on target.", pattern="none", confidence=0.9, status=FindingStatus.CONFIRMED, is_root_cause=False)]}
    )
    state = _state_with_modules(task_type=TaskType.RCA, OEE=blocked, Output=complete)
    package = _package_for(state)

    assert package.overall_status == SynthesisOverallStatus.PARTIAL  # Output still answers part of the goal
    oee_handoff = next(m for m in package.module_results if m.module_id == "OEE")
    assert oee_handoff.module_status == ModuleStatus.BLOCKED
    assert "Authorization" in oee_handoff.limitations[0].description
    assert oee_handoff.limitations[0].related_error is None


# ============================================================================
# FAILED (item 13)
# ============================================================================


def test_all_modules_failed_overall_failed():
    oee = make_module_state(module_id="OEE", module_type="OEE").model_copy(update={"status": ModuleStatus.FAILED})
    output = make_module_state(module_id="Output", module_type="Output").model_copy(update={"status": ModuleStatus.FAILED})
    state = _state_with_modules(task_type=TaskType.RCA, OEE=oee, Output=output)
    package = _package_for(state)

    assert package.overall_status == SynthesisOverallStatus.FAILED
    assert package.root_causes == []
    assert package.key_findings == []


# ============================================================================
# Markdown example (item 14)
# ============================================================================


def test_markdown_output_has_the_expected_section_structure():
    history = run_oee_module_state_history(TaskType.RCA)
    state = _state_with_modules(task_type=TaskType.RCA, OEE=history[-1])
    package = _package_for(state)

    assert package.markdown.startswith("# Analysis Summary")
    assert "## Executive Summary" in package.markdown
    assert "## Module Results" in package.markdown
    assert "### OEE" in package.markdown
    assert "## Root Causes" in package.markdown
    # renderer never emits an empty section heading with nothing under it
    assert "## Cross-Module Relationships" not in package.markdown  # none this phase
    assert "## Recommendations" not in package.markdown  # none this phase
