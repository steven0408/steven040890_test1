"""Phase 5D-8: DataSource integration boundary -- config schema, a working
in-memory adapter, typed config errors for a remote type's env vars, and
the explicit "not connected" stop for every remote type. No real DB
connection anywhere in this file.
"""
import pytest

from agent.datasource.models import (
    DataSourceConfig,
    DataSourceConfigError,
    DataSourceNotConnectedError,
    DataSourceQuery,
    DataSourceQueryNotRegisteredError,
    DataSourceType,
    InMemoryDataSource,
    build_datasource,
)
from agent.datasource.registry import DataSourceNotFoundError, DataSourceRegistry, DuplicateDataSourceError


def test_in_memory_datasource_answers_a_registered_query():
    source = InMemoryDataSource({"list_equipment": lambda params: [{"equipment_id": "EQ001"}, {"equipment_id": "EQ002"}]})
    result = source.query(DataSourceQuery(query_name="list_equipment"))
    assert result.rows == [{"equipment_id": "EQ001"}, {"equipment_id": "EQ002"}]


def test_in_memory_datasource_unregistered_query_raises_typed_error():
    source = InMemoryDataSource({})
    with pytest.raises(DataSourceQueryNotRegisteredError):
        source.query(DataSourceQuery(query_name="does_not_exist"))


def test_build_datasource_in_memory_delegates_to_factory():
    config = DataSourceConfig(name="mock_equipment", type=DataSourceType.IN_MEMORY)
    source = build_datasource(config, in_memory_factory=lambda c: InMemoryDataSource({"ping": lambda p: [{"ok": True}]}))
    assert source.query(DataSourceQuery(query_name="ping")).rows == [{"ok": True}]


def test_build_datasource_in_memory_without_factory_raises_typed_error():
    config = DataSourceConfig(name="mock_equipment", type=DataSourceType.IN_MEMORY)
    with pytest.raises(DataSourceConfigError):
        build_datasource(config)


def test_build_datasource_remote_missing_endpoint_env_raises_typed_error():
    config = DataSourceConfig(name="manufacturing_db", type=DataSourceType.REMOTE_SQL)  # no endpoint_env declared
    with pytest.raises(DataSourceConfigError):
        build_datasource(config)


def test_build_datasource_remote_endpoint_env_not_set_raises_typed_error(monkeypatch):
    monkeypatch.delenv("MANUFACTURING_DB_ENDPOINT", raising=False)
    config = DataSourceConfig(name="manufacturing_db", type=DataSourceType.REMOTE_SQL, endpoint_env="MANUFACTURING_DB_ENDPOINT")
    with pytest.raises(DataSourceConfigError):
        build_datasource(config)


def test_build_datasource_remote_valid_config_stops_at_not_connected(monkeypatch):
    """The key guarantee: env vars resolve correctly (config boundary is
    real), but no network call is ever attempted -- construction stops at
    a clearly-typed NotImplementedError instead."""
    monkeypatch.setenv("MANUFACTURING_DB_ENDPOINT", "https://example.internal/db")
    monkeypatch.setenv("MANUFACTURING_DB_TOKEN", "fake-token-for-test-only")
    config = DataSourceConfig(
        name="manufacturing_db", type=DataSourceType.REMOTE_SQL,
        endpoint_env="MANUFACTURING_DB_ENDPOINT", credential_env="MANUFACTURING_DB_TOKEN",
    )
    with pytest.raises(DataSourceNotConnectedError):
        build_datasource(config)


def test_datasource_registry_duplicate_and_missing():
    registry = DataSourceRegistry()
    registry.register("mock_equipment", InMemoryDataSource({}))
    with pytest.raises(DuplicateDataSourceError):
        registry.register("mock_equipment", InMemoryDataSource({}))
    with pytest.raises(DataSourceNotFoundError):
        registry.get("does_not_exist")
