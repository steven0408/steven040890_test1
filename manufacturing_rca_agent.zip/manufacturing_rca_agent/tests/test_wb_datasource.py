"""Phase "WB Real Data Onboarding" item 21: canonical parsing for each of
the 4 real WB sources (using the exact representative raw rows the phase
spec supplied), InMemory DataSource query behavior, and Freshness
semantics (item 7's daily-vs-snapshot distinction).
"""
from datetime import date, datetime

from agent.domain.wb.datasource import (
    InMemoryWBBankDataSource,
    InMemoryWBPlantOEEDataSource,
    InMemoryWBStageOutputDataSource,
    InMemoryWBWIPDataSource,
    parse_wb_bank_row,
    parse_wb_plant_oee_row,
    parse_wb_stage_output_row,
    parse_wb_wip_row,
)
from agent.domain.wb.models import WBBankStatus, WBLotStatus, WBSourceName, WBUpdateFrequency
from agent.domain.wb.synthetic import build_wb_bank_records, build_wb_plant_oee_records, build_wb_stage_output_records, build_wb_wip_records

# ============================================================================
# OEE
# ============================================================================


def test_oee_representative_row_parses_to_canonical():
    row = {
        "DATE": "2022-01-01", "DOWN": 5.0, "ENG": 2.0, "IDLE": 4.0, "OEE": 80.0, "OPER": "1000",
        "PLANT": "[FAB_A]", "PM": 0.5, "PRODUCTIVE": 85.0, "SETUP": 6.0, "SYNC_TIME": "2022-01-01 08:00:00", "TS": 4.0,
    }
    record = parse_wb_plant_oee_row(row)
    assert record.production_date == date(2022, 1, 1)
    assert record.plant_id == "[FAB_A]"  # unmapped -- stays explicit, per mappings test
    assert record.operation_id == "1000"
    assert record.oee == 80.0
    assert record.downtime_ratio == 5.0
    assert record.engineering_ratio == 2.0  # UNKNOWN field, value still preserved
    assert record.ts_ratio == 4.0
    assert record.source_sync_time == datetime(2022, 1, 1, 8, 0, 0)


def test_synthetic_oee_rows_have_correct_plant_operation_date():
    records = build_wb_plant_oee_records()
    assert len(records) > 0
    for record in records:
        assert record.plant_id in {"ASE01", "ASE02", "ASE03", "ASE07", "ASE08"}
        assert record.operation_id in {"2600", "2800"}
        assert date(2026, 8, 6) <= record.production_date <= date(2026, 8, 12)


def test_oee_freshness_is_daily_not_snapshot():
    ds = InMemoryWBPlantOEEDataSource(build_wb_plant_oee_records())
    freshness = ds.freshness()
    assert freshness.source_name == WBSourceName.PLANT_OEE
    assert freshness.update_frequency == WBUpdateFrequency.DAILY
    assert freshness.is_snapshot is False


# ============================================================================
# BANK
# ============================================================================


def test_bank_representative_row_parses_to_canonical():
    row = {
        "SYNC_TIME": "2026-08-05-22-40-00", "cust_2_code": "CUSTOMER_01", "cust_3_code": "CUSTOMER_01_SUB",
        "cust_grp": "CUSTOMER_GROUP_01", "cust_runtype": "N", "data_cdt": "20260805205037", "description": "",
        "device": "DEVICE_A", "die_qty": 10000, "lc": "1026", "pkg": "RY2N", "plant": "A01001", "plant_1": "A01001",
        "run_type": "N", "schedule": "SCHEDULE_01", "site": "A1", "status": "Ready To Issue", "status_50": "20260804185344",
        "uom": "P", "wafer_inch": "12", "wafer_qty": 150, "year": "6",
    }
    record = parse_wb_bank_row(row)
    assert record.plant_id == "ASE01"  # A01001 resolved via plant mapping
    assert record.site_group.value == "a1"
    assert record.mother_batch_id == "SCHEDULE_01"
    assert record.bank_status == WBBankStatus.READY_TO_ISSUE
    assert record.bank_status_raw == "Ready To Issue"
    assert record.bank_entry_time == datetime(2026, 8, 4, 18, 53, 44)
    assert record.wafer_quantity == 150
    assert record.die_quantity == 10000
    assert record.run_type == "N"  # UNKNOWN field, preserved
    assert record.customer_run_type == "N"  # UNKNOWN field, preserved
    assert record.source_sync_time == datetime(2026, 8, 5, 22, 40, 0)


def test_bank_parent_batch_semantics():
    record = parse_wb_bank_row({
        "SYNC_TIME": "2026-08-05-22-40-00", "schedule": "MOTHER01", "plant": "A01002", "site": "A1",
        "status": "Ready To Issue", "cust_2_code": None, "cust_3_code": None, "cust_grp": None, "cust_runtype": None,
        "description": None, "device": None, "die_qty": None, "lc": None, "pkg": None, "plant_1": None,
        "run_type": None, "status_50": None, "uom": None, "wafer_inch": None, "wafer_qty": None,
    })
    assert record.mother_batch_id == "MOTHER01"


def test_synthetic_bank_has_material_shortage_scenario_present():
    records, _ = build_wb_bank_records()
    assert any(r.bank_status == WBBankStatus.MATERIAL_SHORTAGE for r in records)


def test_bank_freshness_is_snapshot_even_two_hours():
    records, snapshot_dates = build_wb_bank_records()
    ds = InMemoryWBBankDataSource(records, snapshot_dates=snapshot_dates)
    freshness = ds.freshness()
    assert freshness.source_name == WBSourceName.BANK
    assert freshness.update_frequency == WBUpdateFrequency.EVERY_TWO_HOURS_EVEN
    assert freshness.is_snapshot is True


def test_bank_snapshot_date_filter():
    records, snapshot_dates = build_wb_bank_records()
    ds = InMemoryWBBankDataSource(records, snapshot_dates=snapshot_dates)
    golden = ds.list_bank(snapshot_date=date(2026, 8, 12))
    assert len(golden) > 0
    assert all(snapshot_dates[id(r)] == date(2026, 8, 12) for r in golden)


# ============================================================================
# WIP
# ============================================================================


def test_wip_representative_row_parses_to_canonical():
    row = {
        "CURRENT_QTY": "100", "CUST": "CUSTOMER_A", "FACILITY_SOURCE": "ASE01", "LC": "100", "LOT_NO": "LOT_01",
        "OPER": "2800", "PKG": "PKG_X", "PLANT": "ASE01", "RUN_TYPE": "N", "SCHEDULE": "SCH_01", "STATUS": "Active",
        "SYNC_TIME": "2026-01-01 00:00:00",
    }
    record = parse_wb_wip_row(row)
    assert record.plant_id == "ASE01"
    assert record.mother_batch_id == "LOT_01"
    assert record.child_batch_id == "SCH_01"
    assert record.current_quantity == 100
    assert record.lot_status == WBLotStatus.ACTIVE
    assert record.run_type == "N"  # UNKNOWN field, preserved
    assert record.source_sync_time == datetime(2026, 1, 1, 0, 0, 0)


def test_wip_active_hold_normalization():
    active = parse_wb_wip_row({"CURRENT_QTY": "1", "CUST": "C", "FACILITY_SOURCE": "ASE01", "LC": "1", "LOT_NO": "L1",
                                "OPER": "2800", "PKG": "P", "PLANT": "ASE01", "RUN_TYPE": "N", "SCHEDULE": "S1",
                                "STATUS": "Active", "SYNC_TIME": "2026-01-01 00:00:00"})
    hold = parse_wb_wip_row({**{"CURRENT_QTY": "1", "CUST": "C", "FACILITY_SOURCE": "ASE01", "LC": "1", "LOT_NO": "L1",
                                 "OPER": "2800", "PKG": "P", "PLANT": "ASE01", "RUN_TYPE": "N", "SCHEDULE": "S1",
                                 "SYNC_TIME": "2026-01-01 00:00:00"}, "STATUS": "Hold"})
    assert active.lot_status == WBLotStatus.ACTIVE
    assert hold.lot_status == WBLotStatus.HOLD


def test_wip_child_lot_and_mother_batch_are_distinct_fields():
    record = parse_wb_wip_row({"CURRENT_QTY": "1", "CUST": "C", "FACILITY_SOURCE": "ASE01", "LC": "1", "LOT_NO": "MOTHER_X",
                                "OPER": "2800", "PKG": "P", "PLANT": "ASE01", "RUN_TYPE": "N", "SCHEDULE": "CHILD_Y",
                                "STATUS": "Active", "SYNC_TIME": "2026-01-01 00:00:00"})
    assert record.mother_batch_id == "MOTHER_X"
    assert record.child_batch_id == "CHILD_Y"
    assert record.mother_batch_id != record.child_batch_id


def test_synthetic_wip_has_hold_scenario_present():
    records, _ = build_wb_wip_records()
    assert any(r.lot_status == WBLotStatus.HOLD for r in records)


def test_wip_freshness_is_snapshot_odd_two_hours():
    records, snapshot_dates = build_wb_wip_records()
    ds = InMemoryWBWIPDataSource(records, snapshot_dates=snapshot_dates)
    freshness = ds.freshness()
    assert freshness.update_frequency == WBUpdateFrequency.EVERY_TWO_HOURS_ODD
    assert freshness.is_snapshot is True


def test_wip_limit_parameter_respected():
    records, snapshot_dates = build_wb_wip_records()
    ds = InMemoryWBWIPDataSource(records, snapshot_dates=snapshot_dates)
    limited = ds.list_wip(limit=5)
    assert len(limited) == 5


# ============================================================================
# OUTPUT
# ============================================================================


def test_output_representative_row_parses_to_canonical():
    row = {
        "DATA_DATE": "2026-08-04", "FAC": "ASE01", "LOCATION": "LOC_1", "OPER": 2800, "QTY_OUT": 2000,
        "SUP_FAC": "ASE01", "SYNC_TIME": "2026-08-05-08-30-00", "TT_BOND_DIAG": "BOND_DIAG_01",
        "TT_CUSTOMER": "CUSTOMER_X", "TT_DEVICE_TYPE": "DEVICE_TYPE_X", "TT_LC": "100", "TT_PKG": "PKG_X",
    }
    record = parse_wb_stage_output_row(row)
    assert record.production_date == date(2026, 8, 4)
    assert record.plant_id == "ASE01"
    assert record.operation_id == "2800"  # int OPER coerced to str
    assert record.output_quantity == 2000
    assert record.bond_diagram == "BOND_DIAG_01"  # UNKNOWN field, preserved
    assert record.source_facility == "ASE01"  # UNKNOWN field, preserved
    assert record.source_sync_time == datetime(2026, 8, 5, 8, 30, 0)


def test_synthetic_output_has_correct_product_operation_grain():
    records = build_wb_stage_output_records()
    assert len(records) > 0
    keys = {(r.production_date, r.plant_id, r.operation_id, r.device_type) for r in records}
    assert len(keys) > 1  # genuinely multiple distinct grain combinations, not all collapsed


def test_output_freshness_is_daily():
    ds = InMemoryWBStageOutputDataSource(build_wb_stage_output_records())
    freshness = ds.freshness()
    assert freshness.update_frequency == WBUpdateFrequency.DAILY
    assert freshness.is_snapshot is False
