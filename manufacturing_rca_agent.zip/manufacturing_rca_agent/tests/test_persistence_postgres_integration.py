"""PostgreSQL integration test (item 19) -- the only test file in this
package that talks to a real database. Skipped entirely unless
`TEST_POSTGRES_DSN` is set (item 12); when it IS set, `allow_test_database_only`-
style checks below still refuse a production-looking database name (item
13) -- this is a safety net, not a substitute for the caller supplying a
genuinely test-only DSN.

This file is intentionally never pointed at the user's own remote
PostgreSQL host -- Phase 8B's own scope guard forbids that. It exists so a
developer (or CI, with its own throwaway Postgres service container) can
opt in locally: `TEST_POSTGRES_DSN=postgresql://user:pass@localhost:5432/rca_test pytest -m postgres`.
"""
import os

import pytest

pytestmark = pytest.mark.postgres

_DSN = os.environ.get("TEST_POSTGRES_DSN")

if _DSN is None:
    pytest.skip("TEST_POSTGRES_DSN not set -- PostgreSQL integration tests skipped", allow_module_level=True)

psycopg = pytest.importorskip("psycopg")

from psycopg.conninfo import conninfo_to_dict  # noqa: E402

from agent.persistence.factory import PersistenceBackend, PersistenceBackendConfig, build_persistence_layer  # noqa: E402
from agent.persistence.postgres.config import PostgresSettings  # noqa: E402
from agent.persistence.postgres.connection import allow_test_database_only  # noqa: E402
from agent.persistence.postgres.schema import apply_schema  # noqa: E402
from agent.persistence.records import EvidenceRecord, FindingRecord, ModuleRunRecord, RunRecord  # noqa: E402
from agent.persistence.run_writer import RunPersistenceWriter  # noqa: E402
from agent.state.enums import EvidenceQuality, FindingStatus, ModuleStatus, RunTerminationStatus, TaskType  # noqa: E402


def _guarded_connection_factory():
    dbname = conninfo_to_dict(_DSN).get("dbname", "")
    fake_settings = PostgresSettings(host_env="_", database_env="_", user_env="_", password_env="_", require_test_database=True)
    allow_test_database_only(fake_settings, resolved_database_name=dbname)  # raises if this doesn't look like a test DB
    return psycopg.connect(_DSN)


@pytest.fixture()
def layer():
    setup_conn = _guarded_connection_factory()
    apply_schema(setup_conn)
    setup_conn.commit()
    for table in [
        "candidate_status_history", "candidate_reviews", "learning_evidence_links", "learning_candidates",
        "human_feedback", "evaluation_issues", "run_evaluations", "human_runtime_responses", "human_runtime_requests",
        "evaluation_records", "tool_calls", "synthesis_generations", "synthesis_context_builds", "context_builds",
        "llm_calls", "planner_decisions", "handoff_packages", "root_cause_finding_links", "root_causes",
        "finding_evidence_links", "findings", "evidence", "objectives", "module_runs", "runs",
    ]:
        setup_conn.execute(f"TRUNCATE TABLE {table} CASCADE")
    setup_conn.commit()
    setup_conn.close()

    return build_persistence_layer(
        PersistenceBackendConfig(backend=PersistenceBackend.POSTGRES, postgres=PostgresSettings(host_env="_", database_env="_", user_env="_", password_env="_")),
        connection_factory=_guarded_connection_factory,
    )


def test_run_aggregate_round_trips_through_real_postgres(layer):
    writer = RunPersistenceWriter(layer.run_repository, layer.audit_repository, layer.feedback_sink, layer.learning_repository)

    from tests.conftest import make_agent_state, make_module_state

    final_state = make_agent_state(run_id="pg-it-run-1")
    final_state = final_state.model_copy(update={"termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS})

    module_state = make_module_state(module_id="OEE", module_type="OEE", run_id="pg-it-run-1")
    module_state = module_state.model_copy(update={"status": ModuleStatus.COMPLETE})
    final_state = final_state.model_copy(update={"module_states": {"OEE": module_state}})

    writer.persist_run(final_state)

    stored_run = layer.run_repository.get_run("pg-it-run-1")
    assert stored_run is not None
    assert stored_run.run_status == RunTerminationStatus.READY_FOR_SYNTHESIS

    stored_modules = layer.run_repository.get_module_results("pg-it-run-1")
    assert len(stored_modules) == 1
    assert stored_modules[0].module_id == "OEE"
    assert stored_modules[0].module_status == ModuleStatus.COMPLETE


def test_evidence_finding_lineage_round_trips_through_real_postgres(layer):
    layer.run_repository.save_run(RunRecord(run_id="pg-it-run-2", user_request="x", factory_id="f-a", run_status=RunTerminationStatus.READY_FOR_SYNTHESIS, created_at=__import__("datetime").datetime.now(__import__("datetime").timezone.utc)))
    layer.run_repository.save_module_run(ModuleRunRecord(run_id="pg-it-run-2", module_id="OEE", module_type="OEE", task_type=TaskType.RCA, module_status=ModuleStatus.COMPLETE, goal="g", step_count=1, tool_call_count=1, limitation_count=0, finding_count=1))
    layer.run_repository.save_evidence(EvidenceRecord(evidence_id="pg-ev-1", run_id="pg-it-run-2", module_id="OEE", objective_id="obj-1", source_tool="t", quality=EvidenceQuality.STRONG, summary="s"))
    finding = FindingRecord(finding_id="pg-f-1", run_id="pg-it-run-2", module_id="OEE", statement="s", pattern="p", status=FindingStatus.CONFIRMED, confidence=0.9, is_root_cause=False)

    from agent.persistence.records import FindingEvidenceLink

    layer.run_repository.save_finding(finding, [FindingEvidenceLink(finding_id="pg-f-1", evidence_id="pg-ev-1")])

    stored_findings = layer.run_repository.list_findings("pg-it-run-2")
    assert len(stored_findings) == 1
    links = layer.run_repository.list_finding_evidence_links("pg-f-1")
    assert links == [FindingEvidenceLink(finding_id="pg-f-1", evidence_id="pg-ev-1")]


def test_tool_call_audit_persists_through_real_postgres(layer):
    from datetime import datetime, timezone

    from agent.state.enums import ObservationStatus
    from agent.tools.execution_manager import ToolCallRecord

    now = datetime.now(timezone.utc)
    record = ToolCallRecord(
        tool_call_id="pg-tc-1", run_id="pg-it-run-3", module_id="OEE", objective_id="obj-1", tool_id="t",
        status=ObservationStatus.SUCCESS, duration_seconds=0.2, started_at=now, completed_at=now,
        idempotency_key="idem-1", logical_call_id="log-1",
    )
    layer.audit_repository.tool_call_sink.record(record)
    stored = layer.audit_repository.tool_call_sink.list_for_run("pg-it-run-3")
    assert len(stored) == 1
    assert stored[0].idempotency_key == "idem-1"


def test_learning_candidate_upsert_and_evidence_links_through_real_postgres(layer):
    from datetime import datetime, timezone

    from agent.state.enums import LearningCandidateType, LearningDestination
    from agent.state.models import LearningCandidate

    candidate = LearningCandidate(
        candidate_id="pg-cand-1", candidate_type=LearningCandidateType.CAPABILITY_GAP, title="t", statement="s",
        confidence=0.5, created_at=datetime.now(timezone.utc), updated_at=datetime.now(timezone.utc),
        scope="factory-a", proposed_destination=LearningDestination.CAPABILITY_BACKLOG, candidate_key="pg-key-1",
        rationale_summary="r",
    )
    layer.learning_repository.record(candidate)
    fetched = layer.learning_repository.get("pg-cand-1")
    assert fetched == candidate

    updated = candidate.model_copy(update={"confidence": 0.9})
    layer.learning_repository.update(updated)
    assert layer.learning_repository.get("pg-cand-1").confidence == 0.9
