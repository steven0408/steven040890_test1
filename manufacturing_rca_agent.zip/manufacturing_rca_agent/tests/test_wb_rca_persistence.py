"""Phase WB-2D item 27/52: RCA objective/finding/evidence lineage survives
the existing WB-2B.2 persistence path (RunPersistenceWriter ->
InMemoryRunRepository) without modification -- multi-round RCA objective
history included. All offline.
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.learning.sink import InMemoryLearningCandidateSink
from agent.modules.wb.package import build_wb_module_package
from agent.persistence.audit_repository import build_default_audit_repository
from agent.persistence.human_feedback import InMemoryHumanFeedbackSink
from agent.persistence.learning_repository import LearningCandidateRepository
from agent.persistence.run_repository import InMemoryRunRepository
from agent.persistence.run_writer import RunPersistenceWriter
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import ModuleStatus, RunTerminationStatus, TaskType
from agent.state.models import Goal, GoalScope, ModuleState, ModuleTask
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry

from .conftest import make_agent_state


def _run_wb_rca(thread_id: str, statement: str) -> ModuleState:
    package = build_wb_module_package()
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    runtime = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)

    graph = build_module_react_subgraph(WBPlanningPolicy(), capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id="WB", module_type="WB", reason=statement, goal_statement=statement, confidence=0.9, priority=0.9, task_type=TaskType.RCA)
    initial = build_initial_module_state(task, package.budget, run_id=f"run-{thread_id}", task_type=TaskType.RCA)
    result = app.invoke(initial, config={"configurable": {"thread_id": thread_id}})
    return ModuleState.model_validate(result)


def _writer():
    run_repo = InMemoryRunRepository()
    audit_repo = build_default_audit_repository()
    feedback_sink = InMemoryHumanFeedbackSink()
    learning_repo = LearningCandidateRepository(InMemoryLearningCandidateSink())
    return RunPersistenceWriter(run_repo, audit_repo, feedback_sink, learning_repo), run_repo


def test_multi_round_rca_objective_history_persists_with_full_lineage():
    module_state = _run_wb_rca("rca-persist", "2026-08-12 ASE07 output 偏低 root cause")
    assert module_state.status == ModuleStatus.COMPLETE
    assert len(module_state.objective_history) == 2

    writer, run_repo = _writer()
    state = make_agent_state(run_id="run-rca-persist").model_copy(update={
        "module_states": {"WB": module_state},
        "global_goal": Goal(goal_id="g1", raw_statement="ASE07 output low?", normalized_statement="ASE07 output low root cause", task_type=TaskType.RCA, scope=GoalScope()),
        "termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS,
    })
    writer.persist_run(state)

    reloaded_objectives = run_repo.list_objectives("run-rca-persist")
    assert len(reloaded_objectives) == 2
    capability_keys = {r.capability_key for r in reloaded_objectives}
    assert capability_keys == {"wb.output.comparison", "wb.bank.status_summary"}

    reloaded_evidence = run_repo.list_evidence("run-rca-persist")
    assert len(reloaded_evidence) == 2
    objective_ids = {r.objective_id for r in reloaded_objectives}
    assert all(e.objective_id in objective_ids for e in reloaded_evidence)  # lineage intact across every round


def test_postgres_mapping_round_trips_a_real_wb_rca_produced_record():
    from agent.persistence.postgres import mapping as m

    module_state = _run_wb_rca("rca-persist-pg", "2026-08-12 ASE03 WIP hold 異常 root cause")
    record = next(iter(module_state.objective_history.values()))

    row = m.objective_to_row("run-rca-persist-pg", "WB", record)
    restored = m.objective_from_row(row)

    assert restored == record
    assert restored.capability_key == "wb.wip.hold_analysis"
