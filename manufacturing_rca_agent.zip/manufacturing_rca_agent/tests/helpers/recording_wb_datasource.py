"""Phase PROD-1.3 (§VII): a test-only recording proxy around any of the 5
existing WB InMemory DataSource instances -- proves `Agent -> Tool ->
DataSource` genuinely occurred, with bounded telemetry (method name,
scalar kwargs, returned record COUNT), never a dump of raw rows.

Generic (`__getattr__`-based) so one class serves all 5 Protocols
(`WBPlantOEEDataSource`/`WBBankDataSource`/`WBWIPDataSource`/
`WBStageOutputDataSource`/`WBIssueDataSource`) without duplicating five
near-identical wrapper classes, and without touching any production
domain semantics -- it only ever delegates to the real wrapped instance.
"""
from dataclasses import dataclass, field
from typing import Any


@dataclass
class DataSourceCall:
    method: str
    kwargs: dict[str, str]
    record_count: int | None


class RecordingWBDataSource:
    """Wraps one already-constructed InMemoryWB*DataSource instance.
    `source_name` is a human label (e.g. "WBPlantOEEDataSource") for
    trace output -- never inferred from a private attribute."""

    def __init__(self, wrapped: Any, source_name: str):
        self._wrapped = wrapped
        self.source_name = source_name
        self.calls: list[DataSourceCall] = []

    def __getattr__(self, name: str):
        original = getattr(self._wrapped, name)
        if not callable(original):
            return original

        def _recording_method(*args, **kwargs):
            result = original(*args, **kwargs)
            record_count = len(result) if isinstance(result, list) else None
            self.calls.append(DataSourceCall(
                method=name,
                kwargs={k: str(v) for k, v in kwargs.items()},
                record_count=record_count,
            ))
            return result

        return _recording_method

    @property
    def call_count(self) -> int:
        return len(self.calls)

    def summary(self) -> list[dict]:
        """Bounded, print-safe summary -- never raw rows."""
        return [{"source": self.source_name, "method": c.method, "kwargs": c.kwargs, "record_count": c.record_count} for c in self.calls]


def wrap_wb_datasources(datasources) -> tuple[Any, dict[str, RecordingWBDataSource]]:
    """Wraps every field of a `WBDataSources` dataclass instance
    (agent/tools/wb/registration.py) in a `RecordingWBDataSource`, returning
    a NEW `WBDataSources` (same dataclass, wrapped fields) plus a dict of
    the 5 recorders keyed by field name, for tests to inspect after a run."""
    from agent.tools.wb.registration import WBDataSources

    recorders = {
        "oee": RecordingWBDataSource(datasources.oee, "WBPlantOEEDataSource"),
        "bank": RecordingWBDataSource(datasources.bank, "WBBankDataSource"),
        "wip": RecordingWBDataSource(datasources.wip, "WBWIPDataSource"),
        "output": RecordingWBDataSource(datasources.output, "WBStageOutputDataSource"),
        "issue": RecordingWBDataSource(datasources.issue, "WBIssueDataSource"),
    }
    wrapped = WBDataSources(**recorders)
    return wrapped, recorders
