"""Phase WB-3A Test 9: full capability-layer trace for ISSUE --
Objective -> CapabilityResolver -> SkillRunner -> ToolExecutionManager ->
ISSUE Tool -> InMemoryWBIssueDataSource -> typed Result -> Evidence. All
offline, via the real generic capability layer (never a bypassed direct
Tool call).
"""
from agent.capability.resolver import CapabilityResolver
from agent.planning.policies.wb import build_wb_initial_entity_states
from agent.skills.models import SkillExecutionStatus
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.skills.wb.registration import WB_SKILLS_DIR
from agent.state.enums import ObjectiveAction, TargetRefType, TaskType
from agent.state.models import ModuleState, Objective, TargetRef
from agent.state.scope import ObjectiveScope, ScopeFilter, ScopeOperator, TimeScope, TimeScopeKind
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry
from agent.tools.wb.registration import register_wb_tools

from .conftest import make_module_state, make_wb_datasources
from agent.domain.wb.synthetic import GOLDEN_DATE, ISSUE_DAYS, SCENARIO_B_PLANT


def _wb_registries():
    tool_registry = ToolRegistry()
    register_wb_tools(tool_registry, datasources=make_wb_datasources())
    skill_registry = SkillRegistry()
    skill_registry.load_directory(WB_SKILLS_DIR)
    skill_registry.validate_required_tools(tool_registry)
    return skill_registry, tool_registry


def _module_state(task_type: TaskType) -> ModuleState:
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    return module_state.model_copy(update={
        "goal": module_state.goal.model_copy(update={"task_type": task_type}),
        "entity_states": build_wb_initial_entity_states(),
    })


def test_issue_status_summary_skill_resolves_executes_and_produces_evidence():
    skill_registry, tool_registry = _wb_registries()
    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    module_state = _module_state(TaskType.INFORMATION)

    objective = Objective(
        objective_id="obj-1", description="ASE07 issue status", action=ObjectiveAction.SUMMARIZE,
        capability_key="wb.issue.status_summary",
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id=SCENARIO_B_PLANT),
        scope=ObjectiveScope(time=TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, date=GOLDEN_DATE), filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value=SCENARIO_B_PLANT)]),
        expected_output="issue status", priority_score=1.0,
    )

    resolved = resolver.resolve(objective, "wb", TaskType.INFORMATION)
    assert resolved.selected_skill.skill_id == "wb.issue_status_summary"

    outcome = runner.run(resolved.selected_skill, objective, module_state)
    assert outcome.result.status == SkillExecutionStatus.SUCCESS
    assert outcome.result.output_payload is not None

    from agent.state.payload import PayloadRegistry

    result = PayloadRegistry.unpack(outcome.result.output_payload)
    assert result.total_issue_quantity == 400
    assert result.scope.plant_id == SCENARIO_B_PLANT
    assert result.scope.release_date == GOLDEN_DATE
    assert result.availability.is_empty is False


def test_issue_trend_analysis_skill_resolves_and_executes_with_range_scope():
    """Proves `objective.scope.time.start`/`.end` parameter_mapping works
    end to end through the real generic SkillRunner (item Q/R -- no Core
    change was needed for this range-scoped Skill)."""
    skill_registry, tool_registry = _wb_registries()
    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    module_state = _module_state(TaskType.ANALYSIS)

    objective = Objective(
        objective_id="obj-1", description="ASE07 issue trend", action=ObjectiveAction.ANALYZE,
        capability_key="wb.issue.trend_analysis",
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id=SCENARIO_B_PLANT),
        scope=ObjectiveScope(
            time=TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, start=ISSUE_DAYS[0], end=GOLDEN_DATE),
            filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value=SCENARIO_B_PLANT)],
        ),
        expected_output="issue trend", priority_score=1.0,
    )

    resolved = resolver.resolve(objective, "wb", TaskType.ANALYSIS)
    assert resolved.selected_skill.skill_id == "wb.issue_trend_analysis"

    outcome = runner.run(resolved.selected_skill, objective, module_state)
    assert outcome.result.status == SkillExecutionStatus.SUCCESS

    from agent.state.payload import PayloadRegistry

    result = PayloadRegistry.unpack(outcome.result.output_payload)
    # current_period_days isn't scope-mapped (defaults to 1, per the
    # Skill's own documented note) -- this test proves Skill routing/
    # range-scope plumbing, not the Tool's own math (already covered by
    # tests/test_wb_issue_tools.py).
    assert result.trend_direction.value == "down"
    assert result.percentage_difference is not None and result.percentage_difference < 0
