"""Phase WB-2B.1 item T: Core Contract tests -- ObjectiveScope/TimeScope/
ScopeFilter schema, JSON/round-trip serialization, capability_key
validation (via `validate_planner_decision`, the actual consumer of these
contracts), and TaskType/action depth validation. All offline.
"""
from datetime import date

import pytest
from pydantic import ValidationError

from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.planning.policies.llm import PlannerSemanticValidationError, validate_planner_decision
from agent.skills.registry import SkillRegistry
from agent.skills.wb.registration import register_wb_skills
from agent.state.enums import ObjectiveAction, ObjectiveStatus, TargetRefType, TaskType
from agent.state.models import Objective, ObjectiveRecord, TargetRef
from agent.state.scope import ObjectiveScope, ScopeFilter, ScopeOperator, TimeScope, TimeScopeKind

from .conftest import make_module_state, make_oee_skill_registry


def _wb_skills() -> SkillRegistry:
    registry = SkillRegistry()
    register_wb_skills(registry)
    return registry


# ============================================================================
# 1. ObjectiveScope schema
# ============================================================================


def test_objective_scope_defaults_to_empty():
    scope = ObjectiveScope()
    assert scope.time is None
    assert scope.filters == []
    assert scope.group_by == []


def test_objective_scope_with_time_and_filters():
    scope = ObjectiveScope(
        time=TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, date=date(2026, 8, 12)),
        filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE01")],
        group_by=["operation"],
    )
    assert scope.time.date == date(2026, 8, 12)
    assert scope.filters[0].dimension == "plant"
    assert scope.group_by == ["operation"]


def test_objective_scope_extra_field_forbidden():
    with pytest.raises(ValidationError):
        ObjectiveScope.model_validate({"time": None, "filters": [], "group_by": [], "sql": "SELECT *"})


# ============================================================================
# 2/3. TimeScope -- production date vs snapshot date
# ============================================================================


def test_time_scope_production_date():
    ts = TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, date=date(2026, 8, 12))
    assert ts.kind == TimeScopeKind.PRODUCTION_DATE
    assert ts.date == date(2026, 8, 12)


def test_time_scope_snapshot_date():
    ts = TimeScope(kind=TimeScopeKind.SNAPSHOT_DATE, date=date(2026, 8, 12))
    assert ts.kind == TimeScopeKind.SNAPSHOT_DATE


def test_time_scope_production_and_snapshot_are_distinct_kinds_never_conflated():
    production = TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, date=date(2026, 8, 12))
    snapshot = TimeScope(kind=TimeScopeKind.SNAPSHOT_DATE, date=date(2026, 8, 12))
    assert production != snapshot
    assert production.kind != snapshot.kind


def test_time_scope_range_without_point_date():
    ts = TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, start=date(2026, 8, 6), end=date(2026, 8, 12))
    assert ts.date is None


def test_time_scope_rejects_both_point_and_range():
    with pytest.raises(ValidationError):
        TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, date=date(2026, 8, 12), start=date(2026, 8, 6))


def test_time_scope_rejects_neither_point_nor_range():
    with pytest.raises(ValidationError):
        TimeScope(kind=TimeScopeKind.PRODUCTION_DATE)


def test_time_scope_rejects_start_after_end():
    with pytest.raises(ValidationError):
        TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, start=date(2026, 8, 12), end=date(2026, 8, 6))


# ============================================================================
# 4/5. ScopeFilter -- EQ, invalid operator
# ============================================================================


def test_scope_filter_eq_with_scalar_value():
    f = ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE01")
    assert f.value == "ASE01"


def test_scope_filter_in_with_list_value():
    f = ScopeFilter(dimension="plant", operator=ScopeOperator.IN, value=["ASE01", "ASE07"])
    assert f.value == ["ASE01", "ASE07"]


def test_scope_filter_eq_rejects_list_value():
    with pytest.raises(ValidationError):
        ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value=["ASE01", "ASE07"])


def test_scope_filter_in_rejects_scalar_value():
    with pytest.raises(ValidationError):
        ScopeFilter(dimension="plant", operator=ScopeOperator.IN, value="ASE01")


def test_scope_filter_invalid_operator_rejected():
    with pytest.raises(ValidationError):
        ScopeFilter.model_validate({"dimension": "plant", "operator": "gte", "value": "ASE01"})


def test_scope_filter_value_is_json_scalar_never_an_expression():
    """item S: no eval/exec/SQL fragment -- value is always a plain typed
    scalar or list of scalars, never re-interpreted as code anywhere in
    this contract."""
    f = ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE01' OR '1'='1")
    assert f.value == "ASE01' OR '1'='1"  # stored verbatim as inert string data, never executed


# ============================================================================
# 6. JSON serialization
# ============================================================================


def test_objective_scope_json_round_trip():
    scope = ObjectiveScope(
        time=TimeScope(kind=TimeScopeKind.SNAPSHOT_DATE, date=date(2026, 8, 12)),
        filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.IN, value=["ASE01", "ASE03"])],
        group_by=["status"],
    )
    restored = ObjectiveScope.model_validate_json(scope.model_dump_json())
    assert restored == scope


# ============================================================================
# 7/8/9. Objective / ObjectiveRecord / PlannerDecision round-trips
# ============================================================================


def test_objective_round_trip_with_capability_key_and_scope():
    objective = Objective(
        objective_id="obj-1", description="d", action=ObjectiveAction.ANALYZE, capability_key="wb.wip.hold_analysis",
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="ASE03"),
        scope=ObjectiveScope(time=TimeScope(kind=TimeScopeKind.SNAPSHOT_DATE, date=date(2026, 8, 12)), filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE03")]),
        expected_output="status", priority_score=1.0,
    )
    restored = Objective.model_validate_json(objective.model_dump_json())
    assert restored == objective


def test_objective_round_trip_without_scope_stays_none():
    objective = Objective(
        objective_id="obj-2", description="d", action=ObjectiveAction.QUERY,
        target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="WB"), expected_output="status", priority_score=1.0,
    )
    restored = Objective.model_validate_json(objective.model_dump_json())
    assert restored.scope is None
    assert restored.capability_key is None


def test_objective_record_round_trip_with_capability_key():
    record = ObjectiveRecord(
        objective_id="obj-3", description="d", action=ObjectiveAction.ANALYZE, capability_key="wb.wip.hold_analysis",
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="ASE03"), status=ObjectiveStatus.COMPLETED,
        created_step=1, attempt_count=1,
    )
    restored = ObjectiveRecord.model_validate_json(record.model_dump_json())
    assert restored == record
    assert restored.capability_key == "wb.wip.hold_analysis"


def test_planner_decision_round_trip_with_capability_key_and_scope():
    decision = PlannerDecision(
        decision=PlannerDecisionType.DISPATCH,
        next_objective=ObjectiveProposal(
            action=ObjectiveAction.ANALYZE, capability_key="wb.oee.status_analysis",
            target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="ASE01"),
            scope=ObjectiveScope(time=TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, date=date(2026, 8, 12)), filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE01")]),
            description="d", expected_output="e",
        ),
        priority=0.9, rationale_summary="r",
    )
    restored = PlannerDecision.model_validate_json(decision.model_dump_json())
    assert restored == decision


# ============================================================================
# 10/11. capability_key validation -- valid / duplicate / unknown
# ============================================================================


def _dispatch(action, capability_key, ref_type, ref_id, scope=None):
    return PlannerDecision(
        decision=PlannerDecisionType.DISPATCH,
        next_objective=ObjectiveProposal(action=action, capability_key=capability_key, target_ref=TargetRef(ref_type=ref_type, ref_id=ref_id), scope=scope, description="d", expected_output="e"),
        priority=1.0, rationale_summary="r",
    )


def test_capability_key_validation_passes_for_a_real_wb_capability():
    from agent.state.enums import EntityAnalysisStatus
    from agent.state.models import EntityState

    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    module_state = module_state.model_copy(update={
        "goal": module_state.goal.model_copy(update={"task_type": TaskType.INFORMATION}),
        # WB has no Module/Policy yet (out of scope this phase) to populate
        # entity_states for plants the way OEE's does for equipment -- the
        # generic "ENTITY target must exist in entity_states" hallucination
        # check (agent/planning/policies/llm.py) still applies, so this test
        # populates it directly, matching the OEE test fixtures' own pattern.
        "entity_states": {"ASE07": EntityState(entity_id="ASE07", entity_type="PLANT", status=EntityAnalysisStatus.SCREENED, current_tree_node_id="n1", branch_id="b1", priority_score=0.5)},
    })
    decision = _dispatch(
        # wb.bank.status_summary only accepts a `plant` filter -- it
        # deliberately does not wire snapshot_date scoping (Phase WB-2B.1's
        # own decision: the underlying Tool's `latest_snapshot_only=True`
        # default already resolves to "current status" correctly).
        ObjectiveAction.SUMMARIZE, "wb.bank.status_summary", TargetRefType.ENTITY, "ASE07",
        scope=ObjectiveScope(filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE07")]),
    )
    validate_planner_decision(decision, module_state=module_state, task_type=TaskType.INFORMATION, skill_registry=_wb_skills())  # must not raise


def test_unknown_capability_key_rejected():
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    decision = _dispatch(ObjectiveAction.SUMMARIZE, "wb.not_a_real.capability", TargetRefType.MODULE, "WB")
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=module_state, task_type=TaskType.INFORMATION, skill_registry=_wb_skills())


def test_duplicate_capability_key_across_task_types_resolves_independently():
    """Two OEE Skills share capability_key='oee.equipment_screening'
    (ANALYSIS vs RCA) -- each must independently validate for its own
    task_type without the other interfering."""
    module_state = make_module_state()  # module_type=OEE, task_type=RCA default
    decision = _dispatch(ObjectiveAction.SCREEN, "oee.equipment_screening", TargetRefType.MODULE, "OEE")
    validate_planner_decision(decision, module_state=module_state, task_type=TaskType.ANALYSIS, skill_registry=make_oee_skill_registry())
    validate_planner_decision(decision, module_state=module_state, task_type=TaskType.RCA, skill_registry=make_oee_skill_registry())


# ============================================================================
# 12/13. required scope missing / unsupported scope dimension
# ============================================================================


def test_required_scope_missing_rejected_before_tool_execution():
    from agent.planning.policies.wb import build_wb_initial_entity_states

    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    module_state = module_state.model_copy(update={"entity_states": build_wb_initial_entity_states()})
    decision = _dispatch(ObjectiveAction.SUMMARIZE, "wb.oee.plant_status", TargetRefType.ENTITY, "ASE01", scope=None)
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=module_state, task_type=TaskType.INFORMATION, skill_registry=_wb_skills())


def test_partially_missing_required_scope_rejected():
    """wb.wip.hold_analysis requires BOTH snapshot_date and plant -- only
    plant present must still fail."""
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    decision = _dispatch(
        ObjectiveAction.ANALYZE, "wb.wip.hold_analysis", TargetRefType.ENTITY, "ASE03",
        scope=ObjectiveScope(filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE03")]),
    )
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=module_state, task_type=TaskType.ANALYSIS, skill_registry=_wb_skills())


def test_unsupported_scope_dimension_rejected():
    """wb.bank.status_summary only accepts `plant` -- a hallucinated
    `operation` filter must be rejected, not silently ignored."""
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    decision = _dispatch(
        ObjectiveAction.SUMMARIZE, "wb.bank.status_summary", TargetRefType.ENTITY, "ASE07",
        scope=ObjectiveScope(filters=[
            ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE07"),
            ScopeFilter(dimension="operation", operator=ScopeOperator.EQ, value="2800"),
        ]),
    )
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=module_state, task_type=TaskType.INFORMATION, skill_registry=_wb_skills())


# ============================================================================
# 14. TaskType/action depth validation
# ============================================================================


def test_information_forbids_drill_down_verb():
    module_state = make_module_state()
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, "oee.equipment_detail", TargetRefType.ENTITY, "EQ001")
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=module_state, task_type=TaskType.INFORMATION, skill_registry=make_oee_skill_registry())


def test_analysis_forbids_drill_down_verb():
    module_state = make_module_state()
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, "oee.equipment_detail", TargetRefType.ENTITY, "EQ001")
    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=module_state, task_type=TaskType.ANALYSIS, skill_registry=make_oee_skill_registry())


def test_rca_allows_drill_down_verb():
    from agent.state.enums import EntityAnalysisStatus
    from agent.state.models import EntityState

    module_state = make_module_state().model_copy(update={
        "entity_states": {"EQ001": EntityState(entity_id="EQ001", entity_type="EQUIPMENT", status=EntityAnalysisStatus.SCREENED, current_tree_node_id="n1", branch_id="b1", priority_score=0.9)},
    })
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, "oee.equipment_detail", TargetRefType.ENTITY, "EQ001")
    validate_planner_decision(decision, module_state=module_state, task_type=TaskType.RCA, skill_registry=make_oee_skill_registry())  # must not raise


def test_analysis_allows_compare_and_analyze_verbs_for_wb():
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    compare_decision = _dispatch(
        ObjectiveAction.COMPARE, "wb.output.comparison", TargetRefType.MODULE, "WB",
        scope=ObjectiveScope(time=TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, date=date(2026, 8, 12))),
    )
    validate_planner_decision(compare_decision, module_state=module_state, task_type=TaskType.ANALYSIS, skill_registry=_wb_skills())  # must not raise
