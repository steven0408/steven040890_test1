"""Phase WB-3F.1 (item 22-31): Tool-level proof that `summarize_wb_bank_status`
genuinely supports a customer_code pre-filter and an allow-listed `group_by`
selection -- both additive, backward-compatible fields on
`WBBankStatusSummaryInput` (agent/tools/wb/bank_tools.py).

Deliberately Tool-level, NOT through SkillRunner/a Skill's parameter_mapping:
this phase's own repo audit found `_resolve_param`'s `objective.scope.
filter.<dim>` source has no "optional, default-if-absent" resolution mode --
every `parameter_mapping` key is mandatory, so mapping an OPTIONAL scope
dimension (customer/operation) the same way `plant`/`production_date`
(REQUIRED dimensions) already are wired breaks every existing call that
doesn't supply it. See the completion report's own Stop-Gate section for the
exact blocker and minimal proposal -- this phase reverted the Skill-markdown
wiring rather than ship that regression, and these tests instead prove the
Tool layer itself is ready for whenever that SkillRunner gap is closed.
"""
from datetime import date

from agent.domain.wb.datasource import InMemoryWBBankDataSource
from agent.domain.wb.models import WBBankRecord, WBBankStatus, WBSiteGroup
from agent.state.base import RCABaseModel
from agent.state.enums import ObservationStatus
from agent.state.payload import PayloadRegistry
from agent.tools.wb.bank_tools import SummarizeWBBankStatusTool, WBBankStatusSummaryInput, register_wb_bank_input_payloads
from agent.tools.wb.registration import register_wb_tools
from agent.tools.registry import ToolRegistry
from agent.tools.models import ToolExecutionRequest

from .conftest import make_wb_datasources

_DATE = date(2026, 8, 12)


def _record(customer_code: str, package_code: str, device: str, status: WBBankStatus) -> WBBankRecord:
    return WBBankRecord(
        plant_id="ASE07", site_group=WBSiteGroup.A2, site_group_raw="A2", mother_batch_id=f"M-{customer_code}-{package_code}-{device}",
        customer_code=customer_code, customer_sub_code=None, customer_group=None, device=device, package_code=package_code,
        lead_count=None, wafer_size_inch=None, wafer_quantity=5, die_quantity=100, bank_status=status, bank_status_raw=status.value,
        bank_entry_time=None, description=None, run_type=None, customer_run_type=None, unit_of_measure=None,
        source_sync_time=__import__("datetime").datetime(2026, 8, 12, 8, 0),
    )


def _tool() -> SummarizeWBBankStatusTool:
    # ensures payload types are registered (side effect of register_wb_tools) --
    # a lightweight, throwaway registry, never used for lookup below.
    register_wb_tools(ToolRegistry(), datasources=make_wb_datasources())
    records = [
        _record("CUST_A", "PKG_X", "DEV_1", WBBankStatus.MATERIAL_SHORTAGE),
        _record("CUST_A", "PKG_X", "DEV_1", WBBankStatus.READY_TO_ISSUE),
        _record("CUST_B", "PKG_Y", "DEV_2", WBBankStatus.READY_TO_ISSUE),
        _record("CUST_B", "PKG_Y", "DEV_2", WBBankStatus.READY_TO_ISSUE),
    ]
    return SummarizeWBBankStatusTool(InMemoryWBBankDataSource(records))


def _run(tool: SummarizeWBBankStatusTool, params: WBBankStatusSummaryInput):
    request = ToolExecutionRequest(
        tool_id="summarize_wb_bank_status", parameters=PayloadRegistry.pack("wb.bank_status_summary_input", params),
        run_id="run-1", module_id="WB",
    )
    result = tool.run(request)
    assert result.status == ObservationStatus.SUCCESS or result.status == ObservationStatus.ERROR
    return result


def test_customer_filter_narrows_to_the_requested_customer_only():
    tool = _tool()
    result_a = _run(tool, WBBankStatusSummaryInput(plant_id="ASE07", customer_code="CUST_A"))
    result_b = _run(tool, WBBankStatusSummaryInput(plant_id="ASE07", customer_code="CUST_B"))

    payload_a = PayloadRegistry.unpack(result_a.payload)
    payload_b = PayloadRegistry.unpack(result_b.payload)

    assert payload_a.total_count == 2  # CUST_A's own 2 records only
    assert payload_b.total_count == 2  # CUST_B's own 2 records only
    assert payload_a.by_status != payload_b.by_status  # CUST_A has a shortage record, CUST_B doesn't -- genuinely different result


def test_no_customer_filter_sees_all_records():
    tool = _tool()
    result = _run(tool, WBBankStatusSummaryInput(plant_id="ASE07"))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.total_count == 4


def test_group_by_empty_computes_all_three_breakdowns_unchanged():
    """Backward-compatibility proof -- every pre-existing caller (no
    group_by field at all before this phase) must see identical behavior."""
    tool = _tool()
    result = _run(tool, WBBankStatusSummaryInput(plant_id="ASE07"))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.by_plant  # {"ASE07": 4}
    assert payload.by_package  # {"PKG_X": 2, "PKG_Y": 2}
    assert payload.by_device  # {"DEV_1": 2, "DEV_2": 2}


def test_group_by_package_only_narrows_the_other_two_breakdowns_to_empty():
    tool = _tool()
    result = _run(tool, WBBankStatusSummaryInput(plant_id="ASE07", group_by=["package"]))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.by_package  # still populated
    assert payload.by_plant == {}
    assert payload.by_device == {}


def test_group_by_device_only_narrows_the_other_two_breakdowns_to_empty():
    tool = _tool()
    result = _run(tool, WBBankStatusSummaryInput(plant_id="ASE07", group_by=["device"]))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.by_device
    assert payload.by_plant == {}
    assert payload.by_package == {}


def test_unsupported_group_by_dimension_is_rejected_not_silently_dropped():
    """item 34: an unsupported dimension must produce an ERROR, never a
    silently-empty-but-successful result."""
    tool = _tool()
    result = _run(tool, WBBankStatusSummaryInput(plant_id="ASE07", group_by=["customer"]))
    assert result.status == ObservationStatus.ERROR
    assert "customer" in result.error_message
