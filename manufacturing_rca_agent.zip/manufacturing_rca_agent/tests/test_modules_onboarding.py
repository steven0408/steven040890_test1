﻿"""Phase 8B-1 Parts J/K/L: onboarding + removal acceptance tests.

`DummyYield` (Part J) is a fixture-only fake domain -- no real Yield
business logic -- built ENTIRELY inside this test file (not under
`agent/`) to prove the claim: onboarding a brand-new Domain via
`ModulePackage` touches ZERO existing files under `agent/`. This test
file itself is the only new file; no other file in the repository needed
to change to make `DummyYield` a real, bootable, end-to-end-runnable
module.

Reuses `ObjectiveAction.QUERY` (the existing domain-agnostic
action already used by `DeterministicMockPolicy` Harness-mechanics tests)
so this fixture needs no new `ObjectiveAction` member either -- see
`docs/architecture_review/objective_action_design_review.md` for why that
enum stays frozen this phase.
"""
import dataclasses

from langgraph.checkpoint.memory import InMemorySaver

from agent.bootstrap import AppConfig, bootstrap_runtime
from agent.capability.resolver import CapabilityResolver
from agent.catalog.module_registry import ModuleDefinition
from agent.graph.graph import build_phase2_graph
from agent.llm.client import MockLLMClient
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.modules.models import ModulePackage
from agent.modules.oee.package import build_oee_module_package
from agent.modules.registry import ModulePackageRegistry
from agent.planning.policies.base import DomainStateUpdates, FindingDescription
from agent.skills.registry import SkillRegistry
from agent.state.enums import ModuleStatus, ObjectiveAction, TargetRefType, TaskType
from agent.state.models import ModuleState, Objective, TargetRef
from agent.state.state import AgentState
from agent.tools.registry import ToolRegistry

from .conftest import make_agent_state, make_budget

# ============================================================================
# Part J: DummyYield -- a whole fake domain, defined only in this test file
# ============================================================================


class DummyYieldPolicy:
    """Never proposes an objective -- the module reaches NO_VIABLE_OBJECTIVE
    immediately, with zero findings (-> FAILED). Deliberately the simplest
    possible policy that still satisfies the real `ModulePlanningPolicy`
    Protocol -- proving the generic Module ReAct loop (Planner -> Gate ->
    Executor -> Reflector -> Completion Check) handles a brand-new,
    never-seen-before policy with no special-casing anywhere."""

    def propose_next_objective(self, module_state: ModuleState) -> Objective | None:
        return None

    def is_sufficient(self, module_state: ModuleState) -> bool:
        return True

    def describe_finding(self, module_state: ModuleState) -> FindingDescription:
        return FindingDescription(statement="DummyYield never produces a finding.", pattern="DummyYield")

    def derive_state_updates(self, module_state: ModuleState) -> DomainStateUpdates:
        return DomainStateUpdates()


def _dummy_yield_package() -> ModulePackage:
    return ModulePackage(
        module_definition=ModuleDefinition(
            module_type="DummyYield",
            name="Dummy Yield (test fixture)",
            description="Onboarding proof fixture -- not a real domain.",
            supported_task_types=[TaskType.RCA],
        ),
        policy_factory=DummyYieldPolicy,
        tool_registrations=lambda registry: None,  # no Tool needed -- DummyYield never proposes an objective
        skill_directories=(),  # no Skill needed either
        budget=make_budget(max_steps=3, max_tool_calls=3, max_depth_per_entity=2),
    )


def _oee_and_dummy_yield_registry() -> ModulePackageRegistry:
    registry = ModulePackageRegistry()
    registry.register(build_oee_module_package())
    registry.register(_dummy_yield_package())
    return registry


def _config(**overrides) -> AppConfig:
    base = dict(factory_id="factory-a", factory_name="Factory A", enabled_modules=["OEE", "DummyYield"])
    base.update(overrides)
    return AppConfig(**base)


def _mock_planner_client() -> MockLLMClient:
    decision = PlannerDecision(
        decision=PlannerDecisionType.DISPATCH,
        next_objective=ObjectiveProposal(
            action=ObjectiveAction.SUMMARIZE, target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="OEE"),
            description="status", expected_output="status",
        ),
        priority=1.0, rationale_summary="mock",
    )
    return MockLLMClient(lambda req: decision)


def test_dummy_yield_boots_through_bootstrap_alongside_oee():
    """Proves: 0 files under agent/ needed to change for this to work --
    ModulePackageRegistry + bootstrap_runtime(module_packages=...) is
    sufficient."""
    ctx = bootstrap_runtime(_config(), llm_client=_mock_planner_client(), module_packages=_oee_and_dummy_yield_registry())

    assert {m.module_type for m in ctx.module_registry.list()} == {"OEE", "DummyYield"}
    assert "DummyYield" in ctx.module_runtime
    assert "OEE" in ctx.module_runtime


def test_dummy_yield_alone_boots_with_no_oee_at_all():
    """A stronger form of the same proof: DummyYield doesn't need OEE to
    exist at all."""
    registry = ModulePackageRegistry()
    registry.register(_dummy_yield_package())
    ctx = bootstrap_runtime(
        _config(enabled_modules=["DummyYield"]), llm_client=_mock_planner_client(), module_packages=registry
    )
    assert {m.module_type for m in ctx.module_registry.list()} == {"DummyYield"}
    assert list(ctx.module_runtime.keys()) == ["DummyYield"]


def _dummy_yield_only_analyzer():
    from agent.state.models import Goal, GoalScope, ModuleTask

    def node(state: AgentState) -> dict:
        goal = Goal(
            goal_id=f"{state.run_id}-goal", raw_statement=state.user_request.raw_text,
            normalized_statement=state.user_request.raw_text, task_type=TaskType.RCA, scope=GoalScope(),
        )
        task = ModuleTask(module_id="DummyYield", module_type="DummyYield", reason="onboarding smoke", goal_statement="Onboarding smoke goal.", confidence=1.0, priority=1.0, task_type=TaskType.RCA)
        return {"global_goal": goal, "selected_modules": [task]}

    return node


def test_dummy_yield_runs_end_to_end_through_the_real_generic_harness():
    """Not just structurally plausible -- a real request runs through the
    real parent graph, real Module ReAct subgraph, real Module Completion
    Check, with zero changes to any of them."""
    registry = ModulePackageRegistry()
    registry.register(_dummy_yield_package())
    ctx = bootstrap_runtime(_config(enabled_modules=["DummyYield"]), llm_client=_mock_planner_client(), module_packages=registry)

    checkpointer = InMemorySaver()
    graph = build_phase2_graph(ctx.module_runtime, checkpointer, analyzer=_dummy_yield_only_analyzer())
    app = graph.compile(checkpointer=checkpointer)

    run_id = "dummy-yield-e2e"
    result = app.invoke(make_agent_state(run_id=run_id), config={"configurable": {"thread_id": run_id}})
    final_state = AgentState.model_validate(result)

    dummy = final_state.module_states["DummyYield"]
    assert dummy.status == ModuleStatus.FAILED  # no objective ever proposed, zero findings -- the expected terminal state
    assert dummy.findings == []


# ============================================================================
# Part K: Tool / Execution Skill / Reasoning Skill onboarding regressions
# ============================================================================


def test_new_tool_onboarding_touches_only_its_own_module_package():
    """Adding a brand-new Tool to an existing domain: only that domain's
    own ModulePackage.tool_registrations changes (here, simulated via
    dataclasses.replace -- a real onboarding would edit exactly one line
    inside agent/modules/oee/package.py's own _register_oee_tools, per
    the Phase 8B-1 report). No Node, State, or Persistence file needed."""

    class DummyExtraTool:
        def __init__(self):
            from agent.tools.models import ExecutionType, ToolCategory, ToolDefinition, ToolIOSchema, ToolSideEffect

            self.definition = ToolDefinition(
                tool_id="dummy_extra_tool", name="Dummy Extra Tool", description="onboarding proof only",
                category=ToolCategory.QUERY, domains=["oee"],
                input_schema=ToolIOSchema(model_name="OEEQueryInput"), output_schema=ToolIOSchema(model_name="ScreeningResult"),
                execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
                input_payload_type="oee.query_input", output_payload_type="oee.screening_result",
            )

        def run(self, request):
            raise NotImplementedError("never invoked by this test")

    base_package = build_oee_module_package()

    def _extended_registrations(tool_registry: ToolRegistry) -> None:
        base_package.tool_registrations(tool_registry)
        tool_registry.register(DummyExtraTool())

    extended = dataclasses.replace(base_package, tool_registrations=_extended_registrations)
    registry = ToolRegistry()
    extended.tool_registrations(registry)
    assert "dummy_extra_tool" in {t.tool_id for t in registry.list()}
    assert "query_oee_data" in {t.tool_id for t in registry.list()}  # existing tools still present, untouched


def test_new_execution_skill_onboarding_is_a_pure_file_add(tmp_path):
    """0 existing-file modification -- only a new .md file in a directory
    SkillRegistry.load_directory() already knows how to glob-load."""
    skill_dir = tmp_path / "skills"
    skill_dir.mkdir()
    (skill_dir / "dummy_new_skill.md").write_text(
        """---
skill_id: oee.dummy_new_skill
name: Dummy New Skill
description: onboarding proof only
domains: [oee]
category: proof
required_tools: []
optional_tools: []
steps: []
input_contract: none
output_contract: none
task_types: [information]
actions: [query]
---

# Skill: Dummy New Skill
""",
        encoding="utf-8",
    )
    registry = SkillRegistry()
    registry.load_directory(skill_dir)
    assert "oee.dummy_new_skill" in {s.skill_id for s in registry.list()}


def test_new_reasoning_skill_onboarding_is_a_pure_file_add_no_tool_needed(tmp_path):
    """0 existing-file modification, 0 Tool -- exactly the
    Industrial-Engineering-Management-Perspective shape from the Phase 8B
    architecture review's Scenario 4."""
    skill_dir = tmp_path / "reasoning"
    skill_dir.mkdir()
    (skill_dir / "ie_management_perspective.md").write_text(
        """---
skill_id: reasoning.ie_management_perspective
name: Industrial Engineering Management Perspective
description: onboarding proof only
category: perspective
input_contract: AnalyzerContext / PlannerContext
output_contract: guidance text
skill_type: reasoning
applicable_nodes: [planner]
domains: []
task_types: []
version: "1"
---

# Skill: Industrial Engineering Management Perspective

## Guidance
Favor process-standardization root causes over one-off equipment blame.
""",
        encoding="utf-8",
    )
    registry = SkillRegistry()
    registry.load_directory(skill_dir)
    skill = registry.get("reasoning.ie_management_perspective")
    assert skill.steps == []
    assert skill.required_tools == []


# ============================================================================
# Part L: OEE removal -- core has no hard dependency on OEE existing
# ============================================================================


def test_core_bootstrap_works_with_an_empty_module_package_registry():
    """No ModulePackage registered at all, enabled_modules=[] -- proves
    bootstrap_runtime/ModuleRegistry/SkillRegistry/ToolRegistry/
    CapabilityResolver/DataSourceRegistry/PersistenceLayer all construct
    successfully with zero domains wired in."""
    ctx = bootstrap_runtime(_config(enabled_modules=[]), llm_client=_mock_planner_client(), module_packages=ModulePackageRegistry())
    assert ctx.module_registry.list() == []
    assert ctx.module_runtime == {}
    assert ctx.tool_registry.list() == []
    assert isinstance(ctx.capability_resolver, CapabilityResolver)
    assert ctx.persistence_layer is not None  # persistence still initializes with zero domains


def test_removing_oee_package_leaves_no_oee_payload_types_registered():
    """Payload registration is explicit (Phase 8B-1 Part F) -- if the OEE
    ModulePackage is never enabled, `oee.*` payload types are never
    registered, proving no import-time residue leaks across runs."""
    from agent.state.payload import PayloadRegistry

    saved = dict(PayloadRegistry._types)
    try:
        PayloadRegistry._types.clear()
        bootstrap_runtime(_config(enabled_modules=[]), llm_client=_mock_planner_client(), module_packages=ModulePackageRegistry())
        assert "oee.screening_result" not in PayloadRegistry._types
        assert "oee.query_input" not in PayloadRegistry._types
    finally:
        PayloadRegistry._types.clear()
        PayloadRegistry._types.update(saved)


def test_analyzer_llm_sees_only_other_enabled_modules_when_oee_absent():
    """ModuleRegistry (what AnalyzerLLMService reads) only ever contains
    what module_packages + enabled_modules actually wired in."""
    registry = ModulePackageRegistry()
    registry.register(_dummy_yield_package())
    ctx = bootstrap_runtime(_config(enabled_modules=["DummyYield"]), llm_client=_mock_planner_client(), module_packages=registry)
    assert [m.module_type for m in ctx.module_registry.list()] == ["DummyYield"]  # "OEE" nowhere in sight
