"""Phase WB-3D item 69/70: unit tests for `agent/domain/wb/validation.py`
-- the deterministic detect layer. Pure-function tests against hand-built
records, independent of any Tool/Policy wiring (that integration is
covered separately in `test_wb_validation_policy_integration.py`). All
offline.
"""
from datetime import date, datetime, timedelta

from agent.domain.wb.models import WBBankRecord, WBIssueRecord, WBPlantOEERecord, WBSiteGroup, WBStageOutputRecord, WBWIPRecord, WBLotStatus, WBBankStatus
from agent.domain.wb.validation import (
    WBValidationSeverity,
    check_negative_quantity,
    check_scope_plant_mismatch,
    check_stale_relative_to_request,
    check_suspected_duplicates,
    check_truncation_risk,
    check_value_range,
    validate_bank_records,
    validate_issue_records,
    validate_oee_records,
    validate_output_records,
    validate_wip_records,
)

_DAY = date(2026, 8, 12)
_SYNC = datetime(2026, 8, 13, 8, 30)


def _oee(plant="ASE01", oee=85.0, day=_DAY, operation="2800") -> WBPlantOEERecord:
    return WBPlantOEERecord(production_date=day, plant_id=plant, operation_id=operation, oee=oee, productive_ratio=80.0, downtime_ratio=5.0, pm_ratio=2.0, setup_ratio=4.0, idle_ratio=3.0, engineering_ratio=None, ts_ratio=None, source_sync_time=_SYNC)


def _issue(plant="ASE07", qty=100, day=_DAY, schedule="SCH1", customer="CUST1") -> WBIssueRecord:
    return WBIssueRecord(
        source_sync_time=_SYNC, plant_id=plant, site=None, schedule=schedule, customer_code=customer, customer_name=None,
        device_type="DEV1", issue_quantity=qty, lead_count=None, package_code=None, package_type=None, region=None,
        release_date=day, release_date_raw=day.isoformat() if day else None, release_time=None, release_system=None, time_bucket=None, wafer_inch=None,
        year=None, bd_no_unknown=None, cu_flag_unknown=None, customer_run_type_unknown=None, customer_sod_unknown=None,
        internal_sod_unknown=None, routid_unknown=None, run_type_unknown=None, unit_of_measure_unknown=None, user_id_unknown=None, user_name_unknown=None,
    )


def _wip(plant="ASE03", qty=10, mother="M1", child="C1", operation="OP1", status=WBLotStatus.ACTIVE) -> WBWIPRecord:
    return WBWIPRecord(plant_id=plant, facility_source=None, mother_batch_id=mother, child_batch_id=child, operation_id=operation, current_quantity=qty, customer_code=None, package_code=None, lead_count=None, run_type=None, lot_status=status, lot_status_raw=status.value, source_sync_time=_SYNC)


def _bank(plant="ASE07", wafer_qty=5, die_qty=100, status=WBBankStatus.READY_TO_ISSUE) -> WBBankRecord:
    return WBBankRecord(plant_id=plant, site_group=WBSiteGroup.A2, site_group_raw="A2", mother_batch_id="M1", customer_code=None, customer_sub_code=None, customer_group=None, device=None, package_code=None, lead_count=None, wafer_size_inch=None, wafer_quantity=wafer_qty, die_quantity=die_qty, bank_status=status, bank_status_raw=status.value, bank_entry_time=None, description=None, run_type=None, customer_run_type=None, unit_of_measure=None, source_sync_time=_SYNC)


def _output(plant="ASE07", qty=100, day=_DAY, operation="OP1") -> WBStageOutputRecord:
    return WBStageOutputRecord(production_date=day, plant_id=plant, location=None, operation_id=operation, output_quantity=qty, customer_code=None, device_type=None, package_code=None, lead_count=None, bond_diagram=None, source_facility=None, source_sync_time=_SYNC)


# ============================================================================
# Items 41: OEE range boundaries
# ============================================================================


def test_oee_range_boundaries_are_valid():
    usable, outcome = validate_oee_records([_oee(oee=0.0, operation="2600"), _oee(oee=100.0, operation="2800")])
    assert len(usable) == 2
    assert outcome.issues == []


def test_oee_range_below_zero_is_invalid():
    usable, outcome = validate_oee_records([_oee(oee=-1.0)])
    assert usable == []
    assert outcome.has_errors
    assert outcome.invalid_record_count == 1


def test_oee_range_above_100_is_invalid():
    usable, outcome = validate_oee_records([_oee(oee=101.0)])
    assert usable == []
    assert outcome.has_errors


def test_oee_missing_value_is_never_flagged_as_invalid():
    """None is missing, not invalid -- must never be range-checked."""
    record = _oee(oee=None)
    usable, outcome = validate_oee_records([record])
    assert usable == [record]
    assert outcome.issues == []


def test_engineering_and_ts_ratio_are_never_range_checked():
    """Their business meaning is documented UNKNOWN -- applying a 0-100
    assumption to them would be exactly the guess item 5/7 forbids."""
    record = _oee(oee=85.0).model_copy(update={"engineering_ratio": 999.0, "ts_ratio": -50.0})
    usable, outcome = validate_oee_records([record])
    assert usable == [record]
    assert outcome.issues == []


# ============================================================================
# Item 40: negative quantity across all 4 sources; zero stays valid
# ============================================================================


def test_issue_negative_quantity_is_invalid():
    usable, outcome = validate_issue_records([_issue(qty=-100)])
    assert usable == []
    assert outcome.has_errors


def test_issue_zero_quantity_is_valid():
    record = _issue(qty=0)
    usable, outcome = validate_issue_records([record])
    assert usable == [record]
    assert outcome.issues == []


def test_wip_negative_quantity_is_invalid():
    bad, issues = check_negative_quantity([_wip(qty=-20)], get_quantity=lambda r: r.current_quantity, field_name="current_quantity")
    assert bad == {0}
    assert issues and issues[0].severity == WBValidationSeverity.ERROR


def test_bank_negative_wafer_and_die_quantity_is_invalid():
    usable, outcome = validate_bank_records([_bank(wafer_qty=-1, die_qty=100)])
    assert usable == []
    assert outcome.has_errors
    usable2, outcome2 = validate_bank_records([_bank(wafer_qty=5, die_qty=-1)])
    assert usable2 == []
    assert outcome2.has_errors


def test_output_negative_quantity_is_invalid():
    usable, outcome = validate_output_records([_output(qty=-1000)])
    assert usable == []
    assert outcome.has_errors


def test_missing_quantity_is_never_flagged_negative():
    record = _issue(qty=None)
    usable, outcome = validate_issue_records([record])
    assert usable == [record]
    assert outcome.issues == []


# ============================================================================
# Item 8/9/37: scope mismatch (validator-level, independent of Tool wiring)
# ============================================================================


def test_scope_mismatch_detected_when_requested_plant_given():
    bad, issues = check_scope_plant_mismatch([_oee(plant="ASE99")], get_plant_id=lambda r: r.plant_id, requested_plant="ASE01")
    assert bad == {0}
    assert issues and issues[0].severity == WBValidationSeverity.ERROR


def test_scope_mismatch_not_checked_when_no_plant_requested():
    """item 9: only meaningful when the caller actually requested one
    plant -- a module-wide call has nothing to mismatch against."""
    bad, issues = check_scope_plant_mismatch([_oee(plant="ASE99")], get_plant_id=lambda r: r.plant_id, requested_plant=None)
    assert bad == set()
    assert issues == []


def test_scope_match_produces_no_issue():
    bad, issues = check_scope_plant_mismatch([_oee(plant="ASE01")], get_plant_id=lambda r: r.plant_id, requested_plant="ASE01")
    assert bad == set()
    assert issues == []


# ============================================================================
# Item 10/38: date mismatch (business date only, never sync_time)
# ============================================================================


def test_date_mismatch_detected_outside_requested_range():
    from agent.domain.wb.validation import check_date_mismatch

    bad, issues = check_date_mismatch([_oee(day=date(2026, 8, 1))], get_business_date=lambda r: r.production_date, requested_start=date(2026, 8, 10), requested_end=date(2026, 8, 12))
    assert bad == {0}
    assert issues


def test_date_mismatch_none_business_date_is_never_flagged():
    """ISSUE's own unparseable release_date=None is a documented "skip,
    never guess" case, not a date mismatch."""
    from agent.domain.wb.validation import check_date_mismatch

    bad, issues = check_date_mismatch([_issue(day=None)], get_business_date=lambda r: r.release_date, requested_start=date(2026, 8, 10), requested_end=date(2026, 8, 12))
    assert bad == set()
    assert issues == []


# ============================================================================
# Item 11/12/13: duplicate detection -- suspected only, never destructive;
# repeated VALUE (not identity) is never flagged.
# ============================================================================


def test_suspected_duplicate_detected_by_composite_key():
    r1 = _oee(plant="ASE01", operation="2800", day=_DAY)
    r2 = _oee(plant="ASE01", operation="2800", day=_DAY)  # same key -- suspected duplicate
    _, outcome = validate_oee_records([r1, r2])
    assert any(i.code == "suspected_duplicate" for i in outcome.issues)
    assert outcome.issues[[i.code for i in outcome.issues].index("suspected_duplicate")].severity == WBValidationSeverity.WARNING


def test_suspected_duplicate_never_excludes_a_record():
    """item 12: WARNING severity -- both records stay usable, never
    destructively deduped."""
    r1 = _oee(plant="ASE01", operation="2800", day=_DAY)
    r2 = _oee(plant="ASE01", operation="2800", day=_DAY)
    usable, _ = validate_oee_records([r1, r2])
    assert len(usable) == 2


def test_same_value_different_identity_is_never_a_suspected_duplicate():
    """item 13's own explicit regression: two records with the same
    quantity but a DIFFERENT lot are never flagged."""
    r1 = _wip(mother="M1", child="C1", qty=10)
    r2 = _wip(mother="M2", child="C2", qty=10)  # same quantity, different lot identity
    issues = check_suspected_duplicates([r1, r2], get_key=lambda r: (r.mother_batch_id, r.child_batch_id, r.operation_id, r.source_sync_time))
    assert issues == []


def test_bank_duplicate_detection_is_not_attempted_category_c():
    """item 12's own explicit caution: BANK may legitimately have multiple
    real records for the same batch/snapshot -- Category C, no duplicate
    check at all (never a false positive on legitimate repeats)."""
    r1 = _bank()
    r2 = _bank()  # a second, legitimately-real record for the same batch/snapshot
    _, outcome = validate_bank_records([r1, r2])
    assert not any(i.code == "suspected_duplicate" for i in outcome.issues)


# ============================================================================
# Item 14/15: truncation risk -- risk signal only, never proof
# ============================================================================


def test_truncation_risk_flagged_when_returned_equals_limit():
    issue = check_truncation_risk(5000, 5000)
    assert issue is not None
    assert issue.severity == WBValidationSeverity.WARNING


def test_no_truncation_risk_when_returned_below_limit():
    issue = check_truncation_risk(4999, 5000)
    assert issue is None


def test_truncation_risk_never_claims_certainty_in_wording():
    issue = check_truncation_risk(5000, 5000)
    assert "may be" in issue.message.lower() or "may" in issue.message.lower()
    assert "definitely" not in issue.message.lower()


# ============================================================================
# Item 16/17: freshness / staleness -- never wall-clock, source-specific
# ============================================================================


def test_stale_data_flagged_when_latest_available_before_requested_end():
    issue = check_stale_relative_to_request(latest_available_business_date=date(2026, 8, 10), requested_end=date(2026, 8, 12), source_label="OUTPUT")
    assert issue is not None
    assert issue.severity == WBValidationSeverity.WARNING
    assert "2026-08-10" in issue.message and "2026-08-12" in issue.message


def test_no_staleness_when_latest_available_meets_requested_end():
    issue = check_stale_relative_to_request(latest_available_business_date=date(2026, 8, 12), requested_end=date(2026, 8, 12), source_label="OUTPUT")
    assert issue is None


def test_no_staleness_check_when_no_data_at_all():
    """item 16: None (no data) is a NO_DATA concern, not staleness."""
    issue = check_stale_relative_to_request(latest_available_business_date=None, requested_end=date(2026, 8, 12), source_label="OUTPUT")
    assert issue is None


# ============================================================================
# Item 31/32: usable/invalid record counts never redefine record_count
# ============================================================================


def test_usable_and_invalid_counts_sum_to_raw_count():
    usable, outcome = validate_issue_records([_issue(qty=100), _issue(qty=-50), _issue(qty=200)])
    assert outcome.raw_record_count == 3
    assert outcome.usable_record_count == 2
    assert outcome.invalid_record_count == 1
    assert len(usable) == 2


def test_full_valid_batch_has_zero_invalid_count():
    usable, outcome = validate_issue_records([_issue(qty=100), _issue(qty=200)])
    assert outcome.invalid_record_count == 0
    assert outcome.usable_record_count == 2


# ============================================================================
# Item 67: never auto-correct
# ============================================================================


def test_negative_value_is_never_clamped_or_absed():
    """Confirms exclusion, never repair -- the excluded record's own value
    is untouched (never mutated to abs() or 0)."""
    record = _issue(qty=-500)
    usable, outcome = validate_issue_records([record])
    assert record.issue_quantity == -500  # never mutated
    assert usable == []  # excluded, not repaired-and-kept


def test_out_of_range_oee_is_never_clamped_to_100():
    record = _oee(oee=180.0)
    usable, outcome = validate_oee_records([record])
    assert record.oee == 180.0  # never mutated
    assert usable == []
