"""Regression guardrail for a real LangGraph behavior found while building
Phase 4B-1 (native parent/child subgraph integration).

Symptom: when a node function wraps a nested `.invoke()` call into a
compiled child graph that was itself compiled with `checkpointer=True`
(LangGraph's "inherit from context" sentinel), and that node is reached via
Send() so multiple children share one parent thread under different
checkpoint_ns values, resuming an interrupted branch can silently return
*another* branch's stale result instead of its own -- not an error, wrong
data. Confirmed by hand with several variants (shared vs. fresh-compiled
child object, `get_state()`-gated resume, etc.) -- all reproduced the bug.
The fix that avoids it: compile every child with the *same explicit*
checkpointer instance as the parent (not `checkpointer=True`), and thread
`config` through to `child_app.invoke(state, config)`.

Our production code (agent/graph/nodes/module_subgraph_node.py) uses the
fix, never `checkpointer=True`. This file pins both halves of that finding
with a minimal, schema-independent reproduction (not our ModuleState/
AgentState) so it keeps working as a regression signal across LangGraph
upgrades:

  - if `test_checkpointer_true_corrupts_sibling_branch_state_on_resume`
    ever starts FAILING, that's good news -- LangGraph fixed the
    underlying bug, and `checkpointer=True` may be safe to reconsider.
  - `test_explicit_shared_checkpointer_avoids_sibling_branch_corruption`
    must always pass; it pins the pattern our production code depends on.

Keep both tests even after upgrading LangGraph.
"""
from typing import Annotated

import pytest
from langchain_core.runnables import RunnableConfig
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command, Send, interrupt
from pydantic import BaseModel


def _append(existing: list, update: list) -> list:
    return [*existing, *update]


def _merge(existing: dict, update: dict) -> dict:
    return {**existing, **update}


class _ChildState(BaseModel):
    child_id: str
    log: Annotated[list, _append] = []


class _ParentState(BaseModel):
    model_config = {"extra": "forbid"}
    child_ids: list[str] = []
    results: Annotated[dict, _merge] = {}


def _child_step1(state: _ChildState) -> dict:
    return {"log": [f"{state.child_id}-step1"]}


def _child_step2(state: _ChildState) -> dict:
    if state.child_id == "A":
        answer = interrupt({"question": f"approve {state.child_id}?"})
        return {"log": [f"{state.child_id}-step2-resumed-with-{answer}"]}
    return {"log": [f"{state.child_id}-step2-noninterrupt"]}


def _build_child_graph() -> StateGraph:
    g = StateGraph(_ChildState)
    g.add_node("step1", _child_step1)
    g.add_node("step2", _child_step2)
    g.add_edge(START, "step1")
    g.add_edge("step1", "step2")
    g.add_edge("step2", END)
    return g


def _dispatch(state: _ParentState):
    return [Send("child_wrapper", {"child_id": cid}) for cid in state.child_ids]


def _entry(state: _ParentState) -> dict:
    return {}


def _build_parent_app(*, use_checkpointer_true: bool, thread_id: str):
    explicit_checkpointer = InMemorySaver()

    def child_wrapper(payload: dict, config: RunnableConfig) -> dict:
        child_checkpointer = True if use_checkpointer_true else explicit_checkpointer
        compiled_child = _build_child_graph().compile(checkpointer=child_checkpointer)
        result = compiled_child.invoke(_ChildState(child_id=payload["child_id"]), config)
        return {"results": {payload["child_id"]: result}}

    parent_graph = StateGraph(_ParentState)
    parent_graph.add_node("entry", _entry)
    parent_graph.add_node("child_wrapper", child_wrapper)
    parent_graph.add_edge(START, "entry")
    parent_graph.add_conditional_edges("entry", _dispatch, ["child_wrapper"])
    parent_graph.add_edge("child_wrapper", END)

    parent_checkpointer = InMemorySaver() if use_checkpointer_true else explicit_checkpointer
    app = parent_graph.compile(checkpointer=parent_checkpointer)
    config = {"configurable": {"thread_id": thread_id}}
    return app, config


def test_checkpointer_true_corrupts_sibling_branch_state_on_resume():
    """Known LangGraph limitation, not our bug -- pinned so a future
    LangGraph version that fixes it makes this test fail loudly (which is
    the signal to revisit whether checkpointer=True is safe to use)."""
    app, config = _build_parent_app(use_checkpointer_true=True, thread_id="regression-true")

    result1 = app.invoke(_ParentState(child_ids=["A", "B"]), config=config)
    assert "__interrupt__" in result1
    assert result1["results"]["B"]["child_id"] == "B"  # B completed correctly

    result2 = app.invoke(Command(resume="approved"), config=config)

    # this is the corruption: A's resumed branch reads back B's data
    assert result2["results"]["A"]["child_id"] != "A", (
        "checkpointer=True stopped corrupting sibling branch state on resume -- "
        "this LangGraph version may have fixed the bug; if so, it is safe to "
        "reconsider using checkpointer=True in production and this assertion "
        "should be updated/removed."
    )


def test_explicit_shared_checkpointer_avoids_sibling_branch_corruption():
    """Pins the pattern our production code (module_subgraph_node.py)
    actually depends on: must always pass."""
    app, config = _build_parent_app(use_checkpointer_true=False, thread_id="regression-fixed")

    result1 = app.invoke(_ParentState(child_ids=["A", "B"]), config=config)
    assert "__interrupt__" in result1
    assert result1["results"]["B"]["child_id"] == "B"
    b_result_before_resume = result1["results"]["B"]

    result2 = app.invoke(Command(resume="approved"), config=config)

    assert result2["results"]["A"]["child_id"] == "A"
    assert result2["results"]["A"]["log"] == ["A-step1", "A-step2-resumed-with-approved"]
    # B's already-completed result is untouched by A's resume
    assert result2["results"]["B"] == b_result_before_resume
