"""Phase WB-2A item P: WB Plant OEE Tools -- Query + Analysis layers,
filter semantics, empty/missing-data distinction, percentage semantics,
freshness metadata, deterministic ranking, DataSource exception mapping.
"""
from datetime import date, datetime, timezone

from agent.domain.wb.datasource import InMemoryWBPlantOEEDataSource
from agent.domain.wb.errors import WBDataSourceUnavailableError
from agent.domain.wb.models import WBPlantOEERecord
from agent.domain.wb.synthetic import GOLDEN_DATE, SCENARIO_A_PLANT, SCENARIO_E_PLANT, build_wb_plant_oee_records
from agent.domain.wb.tool_results import WBOEELossAnalysisResult, WBPlantOEEQueryResult
from agent.state.enums import ErrorType, ObservationStatus
from agent.state.payload import PayloadRegistry
from agent.tools.models import ToolExecutionRequest
from agent.tools.wb.oee_tools import (
    AnalyzeWBOEELossTool,
    QueryWBPlantOEETool,
    WBOEELossAnalysisInput,
    WBPlantOEEQueryInput,
    register_wb_oee_input_payloads,
)
from agent.domain.wb.tool_results import register_wb_tool_result_payloads


def setup_module(module):
    register_wb_oee_input_payloads()
    register_wb_tool_result_payloads()


def _oee_datasource():
    return InMemoryWBPlantOEEDataSource(build_wb_plant_oee_records())


def _run(tool, payload_type, params):
    request = ToolExecutionRequest(
        tool_id=tool.definition.tool_id, parameters=PayloadRegistry.pack(payload_type, params),
        run_id="run-1", module_id="WB",
    )
    return tool.run(request)


# ============================================================================
# Query tool
# ============================================================================


def test_query_tool_definition_is_query_category():
    tool = QueryWBPlantOEETool(_oee_datasource())
    assert tool.definition.tool_id == "query_wb_plant_oee"
    assert tool.definition.category.value == "query"
    assert tool.definition.domains == ["wb"]


def test_query_filters_by_date_plant_operation():
    tool = QueryWBPlantOEETool(_oee_datasource())
    result = _run(tool, "wb.plant_oee_query_input", WBPlantOEEQueryInput(production_date=GOLDEN_DATE, plant_id=SCENARIO_A_PLANT, operation_id="2800"))
    assert result.status == ObservationStatus.SUCCESS
    payload = PayloadRegistry.unpack(result.payload)
    assert isinstance(payload, WBPlantOEEQueryResult)
    assert len(payload.records) == 1
    assert payload.records[0].plant_id == SCENARIO_A_PLANT


def test_query_with_no_filters_returns_everything():
    tool = QueryWBPlantOEETool(_oee_datasource())
    result = _run(tool, "wb.plant_oee_query_input", WBPlantOEEQueryInput())
    payload = PayloadRegistry.unpack(result.payload)
    assert len(payload.records) == len(build_wb_plant_oee_records())


def test_query_scope_echoes_filters_verbatim():
    tool = QueryWBPlantOEETool(_oee_datasource())
    result = _run(tool, "wb.plant_oee_query_input", WBPlantOEEQueryInput(production_date=GOLDEN_DATE, plant_id="ASE01"))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.scope.production_date == GOLDEN_DATE
    assert payload.scope.plant_id == "ASE01"
    assert payload.scope.operation_id is None


# ============================================================================
# Missing data vs. empty vs. zero
# ============================================================================


def test_missing_plant_on_golden_date_is_empty_not_zero():
    """Golden Scenario E: ASE08's OEE is missing on the golden date --
    must be an EMPTY result (is_empty=True, record_count=0), never a
    fabricated zero-OEE row."""
    tool = QueryWBPlantOEETool(_oee_datasource())
    result = _run(tool, "wb.plant_oee_query_input", WBPlantOEEQueryInput(production_date=GOLDEN_DATE, plant_id=SCENARIO_E_PLANT))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.records == []
    assert payload.availability.is_empty is True
    assert payload.availability.record_count == 0
    assert payload.availability.latest_source_sync_time is None
    assert result.status == ObservationStatus.SUCCESS  # a legitimate empty result is not an error


def test_real_zero_ratio_is_preserved_not_confused_with_missing():
    ds = InMemoryWBPlantOEEDataSource([WBPlantOEERecord(
        production_date=GOLDEN_DATE, plant_id="ASE01", operation_id="2800", oee=0.0, productive_ratio=0.0,
        downtime_ratio=100.0, pm_ratio=0.0, setup_ratio=0.0, idle_ratio=0.0, engineering_ratio=None, ts_ratio=None,
        source_sync_time=datetime(2026, 8, 13, 8, 30, tzinfo=timezone.utc),
    )])
    tool = QueryWBPlantOEETool(ds)
    result = _run(tool, "wb.plant_oee_query_input", WBPlantOEEQueryInput())
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.availability.is_empty is False
    assert payload.records[0].oee == 0.0  # real zero, not dropped/coerced to None


def test_missing_ratio_field_stays_none_not_zero():
    ds = InMemoryWBPlantOEEDataSource([WBPlantOEERecord(
        production_date=GOLDEN_DATE, plant_id="ASE01", operation_id="2800", oee=None, productive_ratio=None,
        downtime_ratio=None, pm_ratio=None, setup_ratio=None, idle_ratio=None, engineering_ratio=None, ts_ratio=None,
        source_sync_time=datetime(2026, 8, 13, 8, 30, tzinfo=timezone.utc),
    )])
    tool = AnalyzeWBOEELossTool(ds)
    result = _run(tool, "wb.oee_loss_analysis_input", WBOEELossAnalysisInput(production_date=GOLDEN_DATE))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.ranking[0].oee is None
    assert payload.ranking[0].dominant_loss_category is None  # no known ratios -- no guess


# ============================================================================
# Percentage semantics (item L)
# ============================================================================


def test_oee_values_are_0_to_100_scale_not_0_to_1():
    """The synthetic dataset's baseline is oee=85.0 -- confirms the
    canonical model preserves the source's 0-100 percentage scale (Phase
    WB Data Layer V1's own finding), never silently rescaled to 0-1."""
    tool = QueryWBPlantOEETool(_oee_datasource())
    result = _run(tool, "wb.plant_oee_query_input", WBPlantOEEQueryInput(production_date=date(2026, 8, 6)))
    payload = PayloadRegistry.unpack(result.payload)
    assert any(r.oee is not None and r.oee > 1.0 for r in payload.records)  # would be impossible on a 0-1 scale


# ============================================================================
# Analysis tool: deterministic ranking + loss breakdown
# ============================================================================


def test_analyze_loss_ranks_worst_oee_first():
    tool = AnalyzeWBOEELossTool(_oee_datasource())
    result = _run(tool, "wb.oee_loss_analysis_input", WBOEELossAnalysisInput(production_date=GOLDEN_DATE))
    payload = PayloadRegistry.unpack(result.payload)
    assert isinstance(payload, WBOEELossAnalysisResult)
    oees = [r.oee for r in payload.ranking if r.oee is not None]
    assert oees == sorted(oees)  # ascending -- worst (lowest) first


def test_analyze_loss_identifies_dominant_category_for_golden_scenario_a():
    tool = AnalyzeWBOEELossTool(_oee_datasource())
    result = _run(tool, "wb.oee_loss_analysis_input", WBOEELossAnalysisInput(production_date=GOLDEN_DATE, plant_id=SCENARIO_A_PLANT, operation_id="2800"))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.ranking[0].dominant_loss_category == "downtime"  # DOWN=19.0 > SETUP=13.0 in the synthetic scenario


def test_ranking_is_deterministic_across_repeated_calls():
    tool = AnalyzeWBOEELossTool(_oee_datasource())
    result1 = _run(tool, "wb.oee_loss_analysis_input", WBOEELossAnalysisInput(production_date=GOLDEN_DATE))
    result2 = _run(tool, "wb.oee_loss_analysis_input", WBOEELossAnalysisInput(production_date=GOLDEN_DATE))
    payload1 = PayloadRegistry.unpack(result1.payload)
    payload2 = PayloadRegistry.unpack(result2.payload)
    assert [r.plant_id for r in payload1.ranking] == [r.plant_id for r in payload2.ranking]


def test_ranking_tie_break_is_plant_then_operation():
    ds = InMemoryWBPlantOEEDataSource([
        WBPlantOEERecord(production_date=GOLDEN_DATE, plant_id="ASE02", operation_id="2800", oee=80.0, productive_ratio=80.0, downtime_ratio=5.0, pm_ratio=2.0, setup_ratio=4.0, idle_ratio=3.0, engineering_ratio=None, ts_ratio=None, source_sync_time=datetime(2026, 8, 13, 8, 30, tzinfo=timezone.utc)),
        WBPlantOEERecord(production_date=GOLDEN_DATE, plant_id="ASE01", operation_id="2800", oee=80.0, productive_ratio=80.0, downtime_ratio=5.0, pm_ratio=2.0, setup_ratio=4.0, idle_ratio=3.0, engineering_ratio=None, ts_ratio=None, source_sync_time=datetime(2026, 8, 13, 8, 30, tzinfo=timezone.utc)),
    ])
    tool = AnalyzeWBOEELossTool(ds)
    result = _run(tool, "wb.oee_loss_analysis_input", WBOEELossAnalysisInput(production_date=GOLDEN_DATE))
    payload = PayloadRegistry.unpack(result.payload)
    assert [r.plant_id for r in payload.ranking] == ["ASE01", "ASE02"]  # equal OEE -- alphabetical tie-break


# ============================================================================
# Freshness metadata (item G)
# ============================================================================


def test_query_result_carries_freshness_metadata():
    tool = QueryWBPlantOEETool(_oee_datasource())
    result = _run(tool, "wb.plant_oee_query_input", WBPlantOEEQueryInput(production_date=GOLDEN_DATE))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.availability.freshness.update_frequency.value == "daily"
    assert payload.availability.freshness.is_snapshot is False


# ============================================================================
# DataSource exception mapping (item O)
# ============================================================================


class _BrokenOEEDataSource:
    def list_oee(self, *, production_date=None):
        raise WBDataSourceUnavailableError("simulated outage")

    def freshness(self):
        from agent.domain.wb.models import WB_PLANT_OEE_FRESHNESS

        return WB_PLANT_OEE_FRESHNESS


def test_datasource_unavailable_error_maps_to_tool_error_result_not_raised():
    tool = QueryWBPlantOEETool(_BrokenOEEDataSource())
    result = _run(tool, "wb.plant_oee_query_input", WBPlantOEEQueryInput())
    assert result.status == ObservationStatus.ERROR
    assert result.error_type == ErrorType.DATA_NOT_FOUND
    assert "simulated outage" in result.error_message
