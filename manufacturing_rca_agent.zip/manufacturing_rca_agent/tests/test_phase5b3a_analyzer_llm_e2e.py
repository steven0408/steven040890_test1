"""Phase 5B-3A end-to-end: MockLLM Analyzer wired into the production-style
parent graph (Standardizer -> Analyzer(LLM) -> Coordinator -> Send -> Module
ReAct -> CapabilityResolver -> SkillRunner -> ToolExecutionManager -> Tool ->
fan-in -> Global Completion Check) -- proving the LLM-backed Analyzer plugs
into the exact same Harness/Capability semantics Phase 5B-2.1 already
verified with the deterministic analyzer_mock, unchanged.
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD, CurrentOEEStatus
from agent.graph.graph import build_phase2_graph
from agent.graph.nodes.analyzer_llm import make_analyzer_llm_node
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.llm.prompts.analyzer import AnalyzerDecision, ModuleSelection
from agent.planning.policies.mock import DeterministicMockPolicy
from agent.planning.policies.oee import OEEPlanningPolicy
from agent.state.enums import (
    EntityAnalysisStatus,
    EvidenceQuality,
    FindingStatus,
    ModuleStatus,
    ObservationStatus,
    RunTerminationStatus,
    TaskType,
)
from agent.state.payload import PayloadRegistry
from agent.state.state import AgentState
from agent.tools.base import ToolResult
from agent.tools.mocks.scripted_tool import ScriptedMockTool

from .conftest import make_agent_state, make_analyzer_llm_service, make_budget, make_oee_capability_runtime


def _legacy_runtime() -> ModuleRuntimeConfig:
    return ModuleRuntimeConfig(
        policy=DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1),
        tool=ScriptedMockTool({"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}),
        budget=make_budget(max_steps=3, max_tool_calls=5, max_depth_per_entity=2),
    )


def _module_runtime() -> dict[str, ModuleRuntimeConfig]:
    return {
        "OEE": ModuleRuntimeConfig(
            policy=OEEPlanningPolicy(),
            capability=make_oee_capability_runtime(MOCK_EQUIPMENT, OEE_THRESHOLD),
            budget=make_budget(max_steps=6, max_tool_calls=20, max_depth_per_entity=3),
        ),
        "Output": _legacy_runtime(),
        "WIP": _legacy_runtime(),
    }


def test_mock_llm_analyzer_information_reaches_oee_current_status_complete():
    canned = AnalyzerDecision(
        task_type=TaskType.INFORMATION,
        selected_modules=[ModuleSelection(module_type="OEE", priority=0.9, confidence=0.9, rationale="OEE status directly requested.", goal_statement="Report today's average OEE.")],
        reasoning_summary="User asked for current OEE only.",
        confidence=0.9,
    )
    service, usage_sink, _ = make_analyzer_llm_service(lambda req: canned)

    checkpointer = InMemorySaver()
    graph = build_phase2_graph(_module_runtime(), checkpointer, analyzer=make_analyzer_llm_node(service))
    app = graph.compile(checkpointer=checkpointer)

    initial_state = make_agent_state(run_id="run-llm-info", raw_text="今天平均 OEE 多少？")
    config = {"configurable": {"thread_id": "run-llm-info"}}
    result = app.invoke(initial_state, config=config)
    final_state = AgentState.model_validate(result)

    assert final_state.global_goal.task_type == TaskType.INFORMATION
    assert {t.module_id for t in final_state.selected_modules} == {"OEE"}
    assert "Output" not in final_state.module_states  # never dispatched -- Analyzer selected OEE only

    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.COMPLETE
    assert [tc.tool_id for tc in oee.tool_calls] == ["query_oee_data", "aggregate_oee_status"]
    status = PayloadRegistry.unpack(oee.evidence[0].structured_payload)
    assert isinstance(status, CurrentOEEStatus)

    # Phase WB-2C.1 item 21 (OEE regression): the real Analyzer-produced
    # goal_statement now reaches ModuleGoal.statement -- never the old
    # hardcoded "Mock goal for OEE" placeholder.
    assert oee.goal.statement == "Report today's average OEE."

    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS
    assert len(usage_sink.list_for_run("run-llm-info")) == 1  # LLM call audited, independent of AgentState


def test_mock_llm_analyzer_rca_reaches_motor_failure_complete():
    canned = AnalyzerDecision(
        task_type=TaskType.RCA,
        selected_modules=[ModuleSelection(module_type="OEE", priority=0.9, confidence=0.9, rationale="OEE decline requires root cause analysis.", goal_statement="Determine the root cause of today's OEE decline.")],
        reasoning_summary="User asked why OEE declined.",
        confidence=0.9,
    )
    service, usage_sink, _ = make_analyzer_llm_service(lambda req: canned)

    checkpointer = InMemorySaver()
    graph = build_phase2_graph(_module_runtime(), checkpointer, analyzer=make_analyzer_llm_node(service))
    app = graph.compile(checkpointer=checkpointer)

    initial_state = make_agent_state(run_id="run-llm-rca", raw_text="為什麼今天 OEE 下降？")
    config = {"configurable": {"thread_id": "run-llm-rca"}}
    result = app.invoke(initial_state, config=config)
    final_state = AgentState.model_validate(result)

    assert final_state.global_goal.task_type == TaskType.RCA
    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.COMPLETE

    final_finding = oee.findings[-1]
    assert final_finding.status == FindingStatus.CONFIRMED
    assert final_finding.is_root_cause is True
    assert set(final_finding.entity_ids) == {"EQ001", "EQ003"}
    assert "Motor Failure" in final_finding.pattern
    assert oee.entity_states["EQ001"].status == EntityAnalysisStatus.ROOT_CAUSE_FOUND
    assert oee.entity_states["EQ003"].status == EntityAnalysisStatus.ROOT_CAUSE_FOUND

    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS
    assert len(usage_sink.list_for_run("run-llm-rca")) == 1
