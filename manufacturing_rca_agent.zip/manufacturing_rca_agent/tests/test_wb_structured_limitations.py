"""Phase WB-3C: WBPlanningPolicy's `derive_state_updates` now surfaces
domain-interpreted evidence gaps as structured `Limitation` records (the
generic `agent.state.models.Limitation` model, reused verbatim -- no
parallel WB-specific schema, item 3). Covers the phase's 5 bounded
categories (NO_DATA / INSUFFICIENT_HISTORY / PARTIAL_SOURCE_OVERLAP /
DATASOURCE_UNAVAILABLE / UNSUPPORTED_ANALYSIS_GRAIN), the Error vs.
Limitation and Finding vs. Limitation distinctions, objective lineage,
deterministic dedup, lifecycle (retained after a later success),
COMPLETE/PARTIAL/FAILED coexistence, and the "normal data disproving the
user's premise is a Finding, never a fake Limitation" regression. All via
the real Module ReAct Subgraph. All offline.
"""
from datetime import datetime, timedelta, timezone

from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.domain.wb.datasource import InMemoryWBIssueDataSource, InMemoryWBStageOutputDataSource
from agent.domain.wb.errors import WBDataSourceUnavailableError
from agent.domain.wb.models import WBIssueRecord
from agent.domain.wb.synthetic import GOLDEN_DATE, HISTORY_DECLINE_START, SCENARIO_A_PLANT, SCENARIO_B_PLANT, SCENARIO_D_PLANT, SCENARIO_E_PLANT, build_wb_stage_output_records
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.modules.wb.package import build_wb_module_package
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import ErrorType, ModuleStatus, TaskType
from agent.state.models import ModuleState, ModuleTask
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry
from agent.tools.wb.registration import WBDataSources

from .conftest import make_wb_datasources

_WINDOW_START = HISTORY_DECLINE_START - timedelta(days=3)  # 7-day window ending on GOLDEN_DATE


def _run_wb(task_type: TaskType, thread_id: str, statement: str, *, datasources: WBDataSources | None = None) -> ModuleState:
    package = build_wb_module_package(datasources=datasources)
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    runtime = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)

    policy = WBPlanningPolicy()
    graph = build_module_react_subgraph(policy, capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id="WB", module_type="WB", reason=statement, goal_statement=statement, confidence=0.9, priority=0.9, task_type=task_type)
    initial = build_initial_module_state(task, package.budget, run_id=f"run-{thread_id}", task_type=task_type)
    result = app.invoke(initial, config={"configurable": {"thread_id": thread_id}})
    return ModuleState.model_validate(result)


def _issue_record(plant_id: str, release_date, quantity: int, sync: datetime) -> WBIssueRecord:
    return WBIssueRecord(
        source_sync_time=sync, plant_id=plant_id, site=None, schedule=None, customer_code=None, customer_name=None,
        device_type=None, issue_quantity=quantity, lead_count=None, package_code=None, package_type=None, region=None,
        release_date=release_date, release_date_raw=release_date.isoformat() if release_date else None, release_time=None,
        release_system=None, time_bucket=None, wafer_inch=None, year=None,
        bd_no_unknown=None, cu_flag_unknown=None, customer_run_type_unknown=None, customer_sod_unknown=None,
        internal_sod_unknown=None, routid_unknown=None, run_type_unknown=None, unit_of_measure_unknown=None,
        user_id_unknown=None, user_name_unknown=None,
    )


class _BrokenBankDataSource:
    def list_bank(self, *, snapshot_date=None):
        raise WBDataSourceUnavailableError("simulated bank outage")

    def freshness(self):
        from agent.domain.wb.models import WB_BANK_FRESHNESS
        return WB_BANK_FRESHNESS


# ============================================================================
# 1/2. NO_DATA: valid empty scope -> Limitation; a real zero value is NOT
# treated the same as no data.
# ============================================================================


def test_no_data_creates_a_structured_limitation():
    final_state = _run_wb(TaskType.RCA, "lim-no-data", "2026-08-12 ASE08 OEE 異常 root cause")
    assert final_state.status == ModuleStatus.PARTIAL
    assert len(final_state.limitations) == 1
    lim = final_state.limitations[0]
    assert "no_data" in lim.limitation_id
    assert SCENARIO_E_PLANT in lim.description
    assert lim.related_error is None  # SUCCESS + is_empty, never an ERROR
    assert lim.impacted_objective_id in final_state.objective_history


def test_real_zero_value_never_produces_a_limitation():
    """A real, non-empty result with a genuinely zero/normal reading (e.g.
    ASE02's own normal OEE) must never be confused with "no data"."""
    final_state = _run_wb(TaskType.RCA, "lim-real-zero", "2026-08-12 ASE02 OEE 異常 root cause")
    assert final_state.status == ModuleStatus.COMPLETE
    assert final_state.limitations == []


# ============================================================================
# 3/4. INSUFFICIENT_HISTORY: partial/zero historical coverage -> Limitation;
# full coverage -> none.
# ============================================================================


def test_insufficient_history_creates_a_limitation_issue_flat_shape():
    """Controlled fixture: only a single day of ISSUE data, nothing in the
    baseline range at all -- `trend_direction=UNKNOWN` (ISSUE's own
    pre-existing signal, item 8) must surface as INSUFFICIENT_HISTORY."""
    sync = datetime.combine(GOLDEN_DATE, datetime.min.time()).replace(hour=8, tzinfo=timezone.utc)
    base = make_wb_datasources()
    custom = WBDataSources(oee=base.oee, bank=base.bank, wip=base.wip, output=base.output, issue=InMemoryWBIssueDataSource([_issue_record(SCENARIO_B_PLANT, GOLDEN_DATE, 100, sync)]))

    final_state = _run_wb(TaskType.ANALYSIS, "lim-insufficient-hist", "2026-08-12 ASE07 這週投料是不是一直偏低？", datasources=custom)
    assert final_state.status == ModuleStatus.COMPLETE
    assert len(final_state.limitations) == 1
    lim = final_state.limitations[0]
    assert "insufficient_history" in lim.limitation_id
    assert "1 observed day" in lim.description
    # Finding still exists -- current low issue is still reportable
    assert final_state.findings
    assert "100" in final_state.findings[-1].statement


def test_full_history_coverage_creates_no_insufficient_history_limitation():
    """The real synthetic dataset's own ASE01 OEE trend has full 7-day
    coverage -- no INSUFFICIENT_HISTORY limitation should appear (an
    UNSUPPORTED_GRAIN one may still appear -- a different, orthogonal
    concern, see the dedicated test below)."""
    final_state = _run_wb(TaskType.RCA, "lim-full-hist", "2026-08-12 ASE01 OEE 表現差 這週 trend root cause")
    assert final_state.status == ModuleStatus.COMPLETE
    assert not any("insufficient_history" in lim.limitation_id for lim in final_state.limitations)


# ============================================================================
# 5/6. PARTIAL_SOURCE_OVERLAP: partial cross-source overlap -> Limitation;
# full overlap -> none.
# ============================================================================


def test_partial_cross_source_overlap_creates_a_limitation_and_finding_still_exists():
    """Controlled fixture: OUTPUT restricted to only 4 of the 7 window days
    for ASE07 -- the cross-source Tool's own partial-overlap detection
    (WB-3B) must surface as a formal PARTIAL_SOURCE_OVERLAP Limitation,
    WITHOUT deleting the Finding that's still legitimately supported by
    the available overlap (item 22's coexistence requirement)."""
    base = make_wb_datasources()
    restricted_output = [
        r for r in build_wb_stage_output_records()
        if not (r.plant_id == SCENARIO_B_PLANT and r.production_date < GOLDEN_DATE - timedelta(days=3))
    ]
    custom = WBDataSources(oee=base.oee, bank=base.bank, wip=base.wip, output=InMemoryWBStageOutputDataSource(restricted_output), issue=base.issue)

    final_state = _run_wb(TaskType.RCA, "lim-partial-overlap", "2026-08-12 ASE07 output 偏低 這週 trend root cause", datasources=custom)
    assert final_state.status == ModuleStatus.COMPLETE
    overlap_lims = [lim for lim in final_state.limitations if "partial_overlap" in lim.limitation_id]
    assert len(overlap_lims) == 1
    assert "4 overlapping business date" in overlap_lims[0].description
    relationship_record = next(r for r in final_state.objective_history.values() if r.capability_key == "wb.issue_output.relationship_analysis")
    assert overlap_lims[0].impacted_objective_id == relationship_record.objective_id  # item 19: lineage points at the RIGHT (relationship) objective

    # Finding coexists -- not deleted by the limitation
    assert final_state.findings
    assert final_state.findings[-1].statement


def test_full_cross_source_overlap_creates_no_overlap_limitation():
    """The real synthetic dataset's own ASE07 ISSUE/OUTPUT both cover the
    full 7-day window -- no PARTIAL_SOURCE_OVERLAP limitation should appear."""
    final_state = _run_wb(TaskType.RCA, "lim-full-overlap", "2026-08-12 ASE07 output 偏低 這週 trend root cause")
    assert final_state.status == ModuleStatus.COMPLETE
    assert not any("partial_overlap" in lim.limitation_id for lim in final_state.limitations)


# ============================================================================
# 7/8. DATASOURCE_UNAVAILABLE: Limitation + alternative path continues, no
# Human escalation.
# ============================================================================


def test_datasource_unavailable_creates_a_limitation_with_related_error():
    base = make_wb_datasources()
    custom = WBDataSources(oee=base.oee, bank=_BrokenBankDataSource(), wip=base.wip, output=base.output, issue=base.issue)

    final_state = _run_wb(TaskType.RCA, "lim-ds-unavailable", "2026-08-12 ASE07 output 偏低 root cause", datasources=custom)
    assert final_state.status == ModuleStatus.COMPLETE  # alternative contributing factors still resolved it

    ds_lims = [lim for lim in final_state.limitations if "datasource_unavailable" in lim.limitation_id]
    assert len(ds_lims) == 1
    assert ds_lims[0].related_error is not None
    assert ds_lims[0].related_error.error_type == ErrorType.DATA_NOT_FOUND
    assert "simulated bank outage" in ds_lims[0].description


def test_datasource_unavailable_planner_continues_to_alternative_capability_no_human():
    """item 12/40: BANK unavailable must never immediately fail the whole
    RCA or escalate to Human -- the Planner should still check WIP/OEE."""
    base = make_wb_datasources()
    custom = WBDataSources(oee=base.oee, bank=_BrokenBankDataSource(), wip=base.wip, output=base.output, issue=base.issue)

    final_state = _run_wb(TaskType.RCA, "lim-ds-alt-path", "2026-08-12 ASE07 output 偏低 root cause", datasources=custom)
    caps = [r.capability_key for r in final_state.objective_history.values()]
    assert "wb.wip.hold_analysis" in caps or "wb.oee.plant_status" in caps  # continued past the BANK failure
    assert final_state.control.gate_decision is None or final_state.control.gate_decision.value != "rejected"


# ============================================================================
# 9. UNSUPPORTED_ANALYSIS_GRAIN
# ============================================================================


def test_unsupported_grain_creates_a_limitation_for_multi_operation_oee_trend():
    """item 13: the OEE trend Tool's own worst-operation-per-day limitation
    (WB-3B) is promoted verbatim into a formal Limitation whenever a plant
    genuinely had multiple operations on a trend day and no `operation_id`
    was specified."""
    final_state = _run_wb(TaskType.RCA, "lim-unsupported-grain", "2026-08-12 ASE01 OEE 表現差 這週 trend root cause")
    grain_lims = [lim for lim in final_state.limitations if "unsupported_grain" in lim.limitation_id]
    assert len(grain_lims) == 1
    assert "worst-performing operation" in grain_lims[0].description
    assert SCENARIO_A_PLANT in grain_lims[0].description


# ============================================================================
# 10. Deterministic dedup -- never a free-text hash, always
# (module_id, objective_id, category).
# ============================================================================


def test_limitation_dedup_is_deterministic_and_id_based():
    """Simulates a checkpoint replay: `derive_state_updates` is called
    twice against states that differ only in whether the FIRST call's own
    result has already been applied to `module_state.limitations` -- the
    second call must return nothing new."""
    final_state = _run_wb(TaskType.RCA, "lim-dedup-base", "2026-08-12 ASE08 OEE 異常 root cause")
    assert len(final_state.limitations) == 1

    policy = WBPlanningPolicy()
    # Re-derive against a state that ALREADY has the limitation applied
    # (module_reflector.py's own post-round state) -- must be filtered out.
    updates = policy.derive_state_updates(final_state)
    assert updates.limitations == []


def test_limitation_id_is_stable_across_repeated_derivation():
    final_state = _run_wb(TaskType.RCA, "lim-stable-id", "2026-08-12 ASE08 OEE 異常 root cause")
    first_id = final_state.limitations[0].limitation_id

    # Re-run the exact same scenario under a different thread/run id --
    # the CONTENT of the id (module_id-lim-objective_id-category) should
    # follow the same deterministic shape, not a random UUID.
    final_state_2 = _run_wb(TaskType.RCA, "lim-stable-id-2", "2026-08-12 ASE08 OEE 異常 root cause")
    second_id = final_state_2.limitations[0].limitation_id
    assert first_id.endswith("-no_data")
    assert second_id.endswith("-no_data")


# ============================================================================
# 11. Lifecycle -- a Limitation established early survives to the final
# state even after a later round succeeds via an alternative path.
# ============================================================================


def test_limitation_is_retained_after_a_later_successful_alternative_path():
    base = make_wb_datasources()
    custom = WBDataSources(oee=base.oee, bank=_BrokenBankDataSource(), wip=base.wip, output=base.output, issue=base.issue)
    final_state = _run_wb(TaskType.RCA, "lim-lifecycle", "2026-08-12 ASE07 output 偏低 root cause", datasources=custom)

    assert final_state.status == ModuleStatus.COMPLETE  # a later round DID succeed
    assert any("datasource_unavailable" in lim.limitation_id for lim in final_state.limitations)  # but the earlier gap is still visible
    assert final_state.findings  # and a real Finding still exists alongside it


# ============================================================================
# 12. Finding + Limitation coexistence (already exercised above; this test
# makes the coexistence itself the explicit assertion).
# ============================================================================


def test_finding_and_limitation_coexist_never_one_deleting_the_other():
    final_state = _run_wb(TaskType.RCA, "lim-coexist", "2026-08-12 ASE01 OEE 表現差 這週 trend root cause")
    assert final_state.findings  # single-day-event Finding
    assert final_state.limitations  # unsupported-grain Limitation
    assert len(final_state.findings) > 0 and len(final_state.limitations) > 0


# ============================================================================
# 13. Wrong user premise / normal data -- Finding, never a fake Limitation.
# ============================================================================


def test_wrong_premise_normal_data_produces_finding_not_limitation():
    """item 21/42's own critical regression: "Why is ASE02 OEE bad?" against
    genuinely normal, sufficient data must produce a Finding rejecting the
    premise -- NEVER a Limitation (the data was sufficient; there's simply
    nothing wrong)."""
    final_state = _run_wb(TaskType.RCA, "lim-wrong-premise", "2026-08-12 ASE02 OEE 異常 root cause")
    assert final_state.status == ModuleStatus.COMPLETE
    assert final_state.limitations == []
    assert final_state.findings
    assert "No abnormal" in final_state.findings[-1].statement or "normal" in final_state.findings[-1].statement.lower()


# ============================================================================
# 14/15/16. COMPLETE / PARTIAL / FAILED coexistence with Limitation.
# ============================================================================


def test_complete_status_with_limitation_is_allowed_when_core_goal_still_answered():
    """item 17: a peripheral gap (OEE trend's own grain limitation) doesn't
    block COMPLETE when the goal itself was still meaningfully answered."""
    final_state = _run_wb(TaskType.RCA, "lim-complete", "2026-08-12 ASE01 OEE 表現差 這週 trend root cause")
    assert final_state.status == ModuleStatus.COMPLETE
    assert final_state.limitations


def test_partial_status_with_limitation_when_core_evidence_missing():
    final_state = _run_wb(TaskType.RCA, "lim-partial", "2026-08-12 ASE08 OEE 異常 root cause")
    assert final_state.status == ModuleStatus.PARTIAL
    assert final_state.limitations


def test_failed_status_can_carry_a_limitation_too():
    """A single-capability INFORMATION-style topic that errors out with no
    alternative path reaches FAILED via the PRE-EXISTING generic
    `module_planner.py` write path (not WB-3C's own) -- confirms the two
    Limitation sources (generic Planner's own "no alternative source" path,
    and WB's own domain-derived one) can coexist without conflicting."""
    base = make_wb_datasources()
    custom = WBDataSources(oee=base.oee, bank=_BrokenBankDataSource(), wip=base.wip, output=base.output, issue=base.issue)
    final_state = _run_wb(TaskType.INFORMATION, "lim-failed", "2026-08-12 ASE07 的 bank 狀況", datasources=custom)

    assert final_state.status in (ModuleStatus.FAILED, ModuleStatus.PARTIAL)
    assert len(final_state.limitations) >= 1


# ============================================================================
# 18/19. Objective lineage.
# ============================================================================


def test_limitation_impacted_objective_id_points_at_the_real_dispatched_objective():
    final_state = _run_wb(TaskType.RCA, "lim-lineage", "2026-08-12 ASE08 OEE 異常 root cause")
    lim = final_state.limitations[0]
    assert lim.impacted_objective_id in final_state.objective_history
    record = final_state.objective_history[lim.impacted_objective_id]
    assert record.capability_key == "wb.oee.plant_status"


# ============================================================================
# 27/28/29. INFORMATION / ANALYSIS / RCA regressions.
# ============================================================================


def test_information_no_data_creates_limitation_never_a_fabricated_zero():
    final_state = _run_wb(TaskType.INFORMATION, "lim-info", "2026-08-12 ASE08 的 OEE 是多少")
    assert final_state.limitations
    assert not any("0" == f.statement.strip() for f in final_state.findings)


def test_analysis_regression_module_wide_missing_plant_still_completes():
    """item 49: comparing plants' OEE when one plant has no data for that
    date should still COMPLETE among the plants that DO have data --
    WBPlanningPolicy never manually sets status, so this remains whatever
    the generic CompletionCheck decides."""
    final_state = _run_wb(TaskType.ANALYSIS, "lim-analysis", "2026-08-12 哪個 plant 的 OEE 最差")
    assert final_state.status == ModuleStatus.COMPLETE


def test_rca_regression_wb2d_scenario_a_unaffected_by_wb3c():
    """WB-2D's own Golden Scenario A must still behave identically --
    WBPlanningPolicy never manually sets `status=PARTIAL` inside the
    policy (item 50), only Limitations/Findings/EntityStates."""
    final_state = _run_wb(TaskType.RCA, "lim-rca-regression", "2026-08-12 ASE01 OEE 表現差 root cause")
    assert final_state.status == ModuleStatus.COMPLETE
    assert len(final_state.objective_history) == 1
    finding = final_state.findings[-1]
    assert "58.0" in finding.statement
    assert finding.is_root_cause is False
