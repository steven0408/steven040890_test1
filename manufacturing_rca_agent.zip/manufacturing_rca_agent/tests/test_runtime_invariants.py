"""Harness-wide runtime invariants that apply across every phase, not just
one persistence/learning domain -- see docs/architecture.md section 11 for
the full rationale.
"""
import ast
from pathlib import Path

_AGENT_DIR = Path(__file__).resolve().parents[1] / "agent"


def test_production_code_never_calls_update_state_on_a_pending_superstep():
    """Phase 5B-1.1 / Phase 8A-1 finding: `app.update_state()` on a
    checkpoint with a still-pending Send task re-executes every task in
    that pending superstep on resume, siblings included -- not just the
    interrupted branch. This is a forbidden runtime pattern in production
    code, not a general-purpose API. `RunController`
    (agent/persistence/run_controller.py) is the sole Human-interrupt
    bridge and resumes exclusively via `Command(resume=...)`.

    AST-level (not substring grep), so docstrings/comments across the
    codebase that merely *mention* `update_state()` -- and there are many,
    documenting exactly this invariant -- never trip this check; only an
    actual `.update_state(...)` call expression does.
    """
    offending = []
    for path in _AGENT_DIR.rglob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute)
                and node.func.attr == "update_state"
            ):
                offending.append(f"{path}:{node.lineno}")
    assert offending == [], f"forbidden app.update_state() call(s) found in production code: {offending}"
