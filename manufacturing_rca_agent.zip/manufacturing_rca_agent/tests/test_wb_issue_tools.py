"""Phase WB-3A Tests 5/6/7/8: query_wb_issue/summarize_wb_issue/
analyze_wb_issue_trend Tool-level behavior -- scope+availability echo,
deterministic aggregation, SUCCESS+is_empty (never ERROR) for a
well-formed no-data query, and a genuine DataSource failure mapped to a
structured ERROR (never a fabricated payload). All offline.
"""
from datetime import date

import pytest

from agent.domain.wb.datasource import InMemoryWBIssueDataSource
from agent.domain.wb.errors import WBDataSourceUnavailableError
from agent.domain.wb.models import WB_ISSUE_FRESHNESS
from agent.domain.wb.synthetic import GOLDEN_DATE, ISSUE_DAYS, SCENARIO_B_PLANT, build_wb_issue_records
from agent.state.enums import ObservationStatus
from agent.state.payload import PayloadRegistry
from agent.tools.models import ToolExecutionRequest
from agent.tools.wb.issue_tools import (
    AnalyzeWBIssueTrendTool,
    QueryWBIssueTool,
    SummarizeWBIssueTool,
    WBIssueQueryInput,
    WBIssueSummaryInput,
    WBIssueTrendAnalysisInput,
    register_wb_issue_input_payloads,
)
from agent.domain.wb.tool_results import register_wb_tool_result_payloads


@pytest.fixture(autouse=True)
def _register_payloads():
    register_wb_tool_result_payloads()
    register_wb_issue_input_payloads()


def _datasource() -> InMemoryWBIssueDataSource:
    return InMemoryWBIssueDataSource(build_wb_issue_records())


def _request(tool_id: str, payload_type: str, params) -> ToolExecutionRequest:
    return ToolExecutionRequest(tool_id=tool_id, run_id="run-1", module_id="WB", parameters=PayloadRegistry.pack(payload_type, params))


# ============================================================================
# Test 5: Query Tool
# ============================================================================


def test_query_wb_issue_returns_scope_and_availability_and_records():
    tool = QueryWBIssueTool(_datasource())
    result = tool.run(_request("query_wb_issue", "wb.issue_query_input", WBIssueQueryInput(release_date=GOLDEN_DATE, plant_id=SCENARIO_B_PLANT)))

    assert result.status == ObservationStatus.SUCCESS
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.scope.plant_id == SCENARIO_B_PLANT
    assert payload.scope.release_date == GOLDEN_DATE
    assert payload.availability.is_empty is False
    assert payload.availability.freshness == WB_ISSUE_FRESHNESS
    assert len(payload.records) == 4
    assert all(r.plant_id == SCENARIO_B_PLANT and r.release_date == GOLDEN_DATE for r in payload.records)


def test_query_wb_issue_filters_by_customer_and_device():
    tool = QueryWBIssueTool(_datasource())
    result = tool.run(_request("query_wb_issue", "wb.issue_query_input", WBIssueQueryInput(release_date=GOLDEN_DATE, plant_id="ASE01", device_type="DEVICE_A")))
    payload = PayloadRegistry.unpack(result.payload)
    assert all(r.device_type == "DEVICE_A" for r in payload.records)


# ============================================================================
# Test 6: Summary Tool
# ============================================================================


def test_summarize_wb_issue_computes_deterministic_total_and_breakdowns():
    tool = SummarizeWBIssueTool(_datasource())
    result = tool.run(_request("summarize_wb_issue", "wb.issue_summary_input", WBIssueSummaryInput(release_date=GOLDEN_DATE, plant_id="ASE01")))

    assert result.status == ObservationStatus.SUCCESS
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.total_issue_quantity == 1000  # 4 records x 250 baseline
    assert payload.record_count == 4
    assert payload.by_plant == {"ASE01": 1000}


def test_summarize_wb_issue_ase07_golden_date_reflects_the_declined_total():
    tool = SummarizeWBIssueTool(_datasource())
    result = tool.run(_request("summarize_wb_issue", "wb.issue_summary_input", WBIssueSummaryInput(release_date=GOLDEN_DATE, plant_id=SCENARIO_B_PLANT)))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.total_issue_quantity == 400  # observed fact only -- no causal claim here


# ============================================================================
# Test 7: No Data -- SUCCESS + is_empty=True, never ERROR, never fabricated
# ============================================================================


def test_unknown_plant_returns_success_with_empty_availability_not_error():
    tool = SummarizeWBIssueTool(_datasource())
    result = tool.run(_request("summarize_wb_issue", "wb.issue_summary_input", WBIssueSummaryInput(release_date=GOLDEN_DATE, plant_id="ASE99")))

    assert result.status == ObservationStatus.SUCCESS
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.availability.is_empty is True
    assert payload.availability.record_count == 0
    assert payload.total_issue_quantity == 0  # zero because there is nothing to sum, not because data was hidden


def test_date_outside_synthetic_range_returns_success_with_empty_availability():
    tool = QueryWBIssueTool(_datasource())
    result = tool.run(_request("query_wb_issue", "wb.issue_query_input", WBIssueQueryInput(release_date=date(2099, 1, 1))))
    assert result.status == ObservationStatus.SUCCESS
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.availability.is_empty is True


# ============================================================================
# Test 8: DataSource failure -> structured ERROR, never a fabricated payload
# ============================================================================


class _FailingIssueDataSource:
    def list_issue(self, *, sync_date=None):
        raise WBDataSourceUnavailableError("simulated WB Issue outage")

    def freshness(self):
        return WB_ISSUE_FRESHNESS


def test_datasource_unavailable_maps_to_structured_error_not_raised():
    tool = SummarizeWBIssueTool(_FailingIssueDataSource())
    result = tool.run(_request("summarize_wb_issue", "wb.issue_summary_input", WBIssueSummaryInput(release_date=GOLDEN_DATE, plant_id="ASE07")))
    assert result.status == ObservationStatus.ERROR
    assert result.payload is None  # never a fabricated payload alongside an error
    assert result.error_message is not None


# ============================================================================
# Trend Tool
# ============================================================================


def test_analyze_wb_issue_trend_detects_the_ase07_decline():
    tool = AnalyzeWBIssueTrendTool(_datasource())
    result = tool.run(_request(
        "analyze_wb_issue_trend", "wb.issue_trend_analysis_input",
        WBIssueTrendAnalysisInput(plant_id=SCENARIO_B_PLANT, start=ISSUE_DAYS[0], end=GOLDEN_DATE, current_period_days=4),
    ))
    assert result.status == ObservationStatus.SUCCESS
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.current_period_average_daily == 400.0
    assert payload.baseline_period_average_daily == 1000.0
    assert payload.percentage_difference == -60.0
    assert payload.trend_direction.value == "down"
    assert len(payload.daily_series) == 14


def test_analyze_wb_issue_trend_flat_for_a_stable_plant():
    tool = AnalyzeWBIssueTrendTool(_datasource())
    result = tool.run(_request(
        "analyze_wb_issue_trend", "wb.issue_trend_analysis_input",
        WBIssueTrendAnalysisInput(plant_id="ASE01", start=ISSUE_DAYS[0], end=GOLDEN_DATE, current_period_days=4),
    ))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.trend_direction.value == "flat"
    assert payload.percentage_difference == 0.0


def test_analyze_wb_issue_trend_never_asserts_a_cause():
    """Regression guard for item C/W: the Tool's own summary/result text
    never claims a cause for the trend it reports."""
    tool = AnalyzeWBIssueTrendTool(_datasource())
    result = tool.run(_request(
        "analyze_wb_issue_trend", "wb.issue_trend_analysis_input",
        WBIssueTrendAnalysisInput(plant_id=SCENARIO_B_PLANT, start=ISSUE_DAYS[0], end=GOLDEN_DATE, current_period_days=4),
    ))
    assert "material shortage" not in result.summary.lower()
    assert "caused" not in result.summary.lower()
    assert "because" not in result.summary.lower()


def test_analyze_wb_issue_trend_no_baseline_reports_unknown_direction():
    tool = AnalyzeWBIssueTrendTool(_datasource())
    result = tool.run(_request(
        "analyze_wb_issue_trend", "wb.issue_trend_analysis_input",
        WBIssueTrendAnalysisInput(plant_id="ASE01", start=GOLDEN_DATE, end=GOLDEN_DATE, current_period_days=1),
    ))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.baseline_period_average_daily is None
    assert payload.trend_direction.value == "unknown"
