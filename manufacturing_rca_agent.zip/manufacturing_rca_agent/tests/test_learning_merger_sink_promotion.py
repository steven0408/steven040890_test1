"""Phase 7C items 14/16/17/20: CandidateMerger + LearningCandidateSink
cross-batch merging, the promotion-boundary invariant, and the read-only
upstream guarantee.
"""
import ast
from pathlib import Path

import pytest

from agent.learning.confidence import TieredCandidateConfidenceScorer
from agent.learning.generator import LearningCandidateGenerator
from agent.learning.generators.capability_gap import generate_capability_gap_candidates
from agent.learning.merger import CandidateMerger
from agent.learning.promotion import NoAutoPromotionPolicy
from agent.learning.sink import InMemoryLearningCandidateSink, LearningCandidateNotFoundError
from agent.learning.snapshot import LearningRunSnapshot, SnapshotCapabilityGap, SnapshotEvaluationSummary, SnapshotPlannerSummary
from agent.state.enums import LearningCandidateStatus, TaskType

_SCORER = TieredCandidateConfidenceScorer()


def _snapshot(run_id, capability_gaps=None):
    return LearningRunSnapshot(
        run_id=run_id, factory_id="factory-a", module_types=["OEE"], task_type=TaskType.RCA,
        confirmed_findings=[], root_causes=[],
        evaluation_summary=SnapshotEvaluationSummary(analytical_quality_score=0.9, decision_quality_score=0.9, delivery_quality_score=0.9, efficiency_score=0.9, overall_score=None),
        planner_summary=SnapshotPlannerSummary(total_decisions=1, fallback_decisions=0, objective_count=2, unnecessary_deep_dive_count=0),
        capability_gaps=capability_gaps or [],
    )


def _gap():
    return SnapshotCapabilityGap(module_type="OEE", requested_action="maintenance_history_analysis", description="unavailable")


# ============================================================================
# CandidateMerger / cross-batch sink merging (item 14)
# ============================================================================


def test_merging_a_second_batch_updates_the_same_candidate_not_a_duplicate():
    sink = InMemoryLearningCandidateSink()
    merger = CandidateMerger(_SCORER)

    batch1_candidates, batch1_links = generate_capability_gap_candidates([_snapshot("run-a", [_gap()])], _SCORER)
    merger.merge_into_sink(sink, batch1_candidates, batch1_links)
    assert len(sink.list()) == 1
    first_confidence = sink.list()[0].confidence

    batch2_candidates, batch2_links = generate_capability_gap_candidates([_snapshot("run-b", [_gap()])], _SCORER)
    merger.merge_into_sink(sink, batch2_candidates, batch2_links)

    assert len(sink.list()) == 1  # still one candidate, not two
    merged = sink.list()[0]
    assert set(merged.source_run_ids) == {"run-a", "run-b"}
    assert merged.confidence >= first_confidence  # more evidence, same or higher confidence
    assert merged.supporting_signal_count == 2


def test_evidence_links_accumulate_append_only_across_merges():
    sink = InMemoryLearningCandidateSink()
    merger = CandidateMerger(_SCORER)

    c1, l1 = generate_capability_gap_candidates([_snapshot("run-a", [_gap()])], _SCORER)
    merger.merge_into_sink(sink, c1, l1)
    candidate_id = sink.list()[0].candidate_id
    assert len(sink.list_evidence_links(candidate_id)) == 1

    c2, l2 = generate_capability_gap_candidates([_snapshot("run-b", [_gap()])], _SCORER)
    merger.merge_into_sink(sink, c2, l2)
    assert len(sink.list_evidence_links(candidate_id)) == 2  # appended, not replaced


# ============================================================================
# LearningCandidateSink (item 16)
# ============================================================================


def test_sink_list_by_type_and_status():
    sink = InMemoryLearningCandidateSink()
    candidates, links = generate_capability_gap_candidates([_snapshot("run-a", [_gap()])], _SCORER)
    CandidateMerger(_SCORER).merge_into_sink(sink, candidates, links)

    from agent.state.enums import LearningCandidateType

    assert len(sink.list_by_type(LearningCandidateType.CAPABILITY_GAP)) == 1
    assert len(sink.list_by_type(LearningCandidateType.KNOWLEDGE_PATTERN)) == 0
    assert len(sink.list_by_status(LearningCandidateStatus.CANDIDATE)) == 1
    assert len(sink.list_by_status(LearningCandidateStatus.VALIDATED)) == 0


def test_sink_update_requires_a_prior_record():
    sink = InMemoryLearningCandidateSink()
    candidates, _ = generate_capability_gap_candidates([_snapshot("run-a", [_gap()])], _SCORER)
    with pytest.raises(LearningCandidateNotFoundError):
        sink.update(candidates[0])


def test_generator_end_to_end_with_sink():
    sink = InMemoryLearningCandidateSink()
    generator = LearningCandidateGenerator(candidate_sink=sink)
    generator.generate([_snapshot("run-a", [_gap()]), _snapshot("run-b", [_gap()])])
    assert len(sink.list()) == 1
    assert sink.list()[0].status == LearningCandidateStatus.CANDIDATE


# ============================================================================
# Promotion boundary (item 17) -- the critical invariant
# ============================================================================


def test_no_auto_promotion_policy_never_recommends_promotion():
    from datetime import datetime, timezone

    candidates, _ = generate_capability_gap_candidates([_snapshot("run-a", [_gap()])], _SCORER)
    recommendation = NoAutoPromotionPolicy().evaluate(candidates[0], [], now=datetime.now(timezone.utc))
    assert recommendation.recommended is False


def test_no_service_in_agent_learning_ever_constructs_a_validated_candidate():
    """AST-level regression (item 20): no file under agent/learning/
    contains the actual expression `LearningCandidateStatus.VALIDATED` in
    code (docstrings/comments mentioning "VALIDATED" in prose are fine and
    expected -- this checks real attribute-access nodes, not substring
    text, so it isn't fooled by either false positive)."""
    learning_dir = Path(__file__).resolve().parents[1] / "agent" / "learning"
    offending = []
    for path in learning_dir.rglob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Attribute) and node.attr == "VALIDATED" and isinstance(node.value, ast.Name) and node.value.id == "LearningCandidateStatus":
                offending.append(str(path))
    assert offending == [], f"agent/learning/ files construct LearningCandidateStatus.VALIDATED: {offending}"


def test_no_promote_method_exists_anywhere_in_agent_learning():
    """A second, structural form of the same invariant: no function/method
    named `promote` exists anywhere under agent/learning/."""
    learning_dir = Path(__file__).resolve().parents[1] / "agent" / "learning"
    offending = []
    for path in learning_dir.rglob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == "promote":
                offending.append(str(path))
    assert offending == [], f"a promote() method exists in: {offending}"


# ============================================================================
# Read-only upstream guarantee (item 20)
# ============================================================================


def test_generation_never_mutates_input_snapshots():
    snapshots = [_snapshot("run-a", [_gap()]), _snapshot("run-b", [_gap()])]
    before = [s.model_copy(deep=True) for s in snapshots]

    LearningCandidateGenerator().generate(snapshots)

    assert snapshots == before
