"""Phase WB-3B item 62/63/70: Synthesis/Evaluator compatibility smoke for
historical/cross-source findings -- no Synthesis/Evaluator code changes,
just confirming a real WB historical/cross-source RCA ModuleState flows
through `ModuleHandoffBuilder`/`RunEvaluator` without crashing, and --
the important hallucination guard, item 62's own explicit concern -- that
a descriptive cross-source "association" finding never gets promoted
into `ModuleHandoff.root_causes`, and its wording never gets upgraded
into a causal claim anywhere along the way. All offline.
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.modules.wb.package import build_wb_module_package
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import ModuleStatus, TaskType
from agent.state.models import ModuleState, ModuleTask
from agent.synthesis.handoff_builder import ModuleHandoffBuilder
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry

_FORBIDDEN_CAUSAL_WORDS = ("caused", "causes", "causing", "proves", "root cause", "directly caused", "due to", "because of")


def _run_wb(task_type: TaskType, thread_id: str, statement: str) -> ModuleState:
    package = build_wb_module_package()
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    runtime = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)

    policy = WBPlanningPolicy()
    graph = build_module_react_subgraph(policy, capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id="WB", module_type="WB", reason=statement, goal_statement=statement, confidence=0.9, priority=0.9, task_type=task_type)
    initial = build_initial_module_state(task, package.budget, run_id=f"run-{thread_id}", task_type=task_type)
    result = app.invoke(initial, config={"configurable": {"thread_id": thread_id}})
    return ModuleState.model_validate(result)


def test_cross_source_association_finding_never_becomes_a_synthesis_root_cause():
    """Item 62's own explicit guard: "association" wording must never get
    upgraded to a root cause anywhere in the Synthesis handoff path."""
    module_state = _run_wb(TaskType.RCA, "hist-synth-crosssource", "2026-08-12 ASE07 output 偏低 這週 trend root cause")
    assert module_state.status == ModuleStatus.COMPLETE
    assert any(f.is_root_cause for f in module_state.findings) is False  # precondition

    handoff = ModuleHandoffBuilder().build(module_state)

    assert handoff.root_causes == []
    assert handoff.confirmed_findings
    for finding in handoff.confirmed_findings:
        statement_lower = finding.statement.lower()
        for forbidden in _FORBIDDEN_CAUSAL_WORDS:
            assert forbidden not in statement_lower


def test_historical_wip_recurrence_finding_never_becomes_a_synthesis_root_cause():
    module_state = _run_wb(TaskType.RCA, "hist-synth-wip", "2026-08-12 ASE03 Hold 這週已經發生幾次 trend root cause")
    handoff = ModuleHandoffBuilder().build(module_state)
    assert handoff.root_causes == []


def test_historical_analysis_finding_builds_a_handoff_without_crashing():
    module_state = _run_wb(TaskType.ANALYSIS, "hist-synth-analysis", "2026-08-12 ASE07 這週投料是不是一直偏低？")
    handoff = ModuleHandoffBuilder().build(module_state)
    assert handoff.module_status == ModuleStatus.COMPLETE


def test_run_evaluator_does_not_crash_on_a_historical_crosssource_wb_run():
    """Item 63: not an acceptance blocker, just a crash-smoke -- no
    recurrence-metric addition needed this phase (impact/priority scoring
    deferred, item 46)."""
    from agent.evaluation.evaluator import RunEvaluator
    from agent.state.enums import RunTerminationStatus
    from agent.state.models import Goal, GoalScope

    from .conftest import make_agent_state

    module_state = _run_wb(TaskType.RCA, "hist-synth-eval", "2026-08-12 ASE07 output 偏低 這週 trend root cause")
    final_state = make_agent_state(run_id="run-hist-synth-eval").model_copy(update={
        "module_states": {"WB": module_state},
        "global_goal": Goal(goal_id="g1", raw_statement="ASE07 output low, historical?", normalized_statement="ASE07 output low historical root cause", task_type=TaskType.RCA, scope=GoalScope()),
        "termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS,
    })

    evaluator = RunEvaluator()
    report = evaluator.evaluate(final_state)
    assert report is not None
