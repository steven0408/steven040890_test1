"""Phase WB-2A item P: WB Bank Tools -- Query + Summarize + Aging,
snapshot selection (latest vs all), status canonicalization, aging
known/unknown split, DataSource exception mapping.
"""
from datetime import datetime

from agent.domain.wb.datasource import InMemoryWBBankDataSource
from agent.domain.wb.errors import WBDataSourceUnavailableError
from agent.domain.wb.models import WBBankRecord, WBBankStatus, WBSiteGroup
from agent.domain.wb.synthetic import BANK_SNAPSHOTS, GOLDEN_DATE, SCENARIO_B_PLANT, build_wb_bank_records
from agent.domain.wb.tool_results import WBBankAgingAnalysisResult, WBBankQueryResult, WBBankStatusSummaryResult, register_wb_tool_result_payloads
from agent.state.enums import ErrorType, ObservationStatus
from agent.state.payload import PayloadRegistry
from agent.tools.models import ToolExecutionRequest
from agent.tools.wb.bank_tools import (
    AnalyzeWBBankAgingTool,
    QueryWBBankTool,
    SummarizeWBBankStatusTool,
    WBBankAgingAnalysisInput,
    WBBankQueryInput,
    WBBankStatusSummaryInput,
    register_wb_bank_input_payloads,
)


def setup_module(module):
    register_wb_bank_input_payloads()
    register_wb_tool_result_payloads()


def _bank_datasource():
    records, snapshot_dates = build_wb_bank_records()
    return InMemoryWBBankDataSource(records, snapshot_dates=snapshot_dates)


def _run(tool, payload_type, params):
    request = ToolExecutionRequest(
        tool_id=tool.definition.tool_id, parameters=PayloadRegistry.pack(payload_type, params),
        run_id="run-1", module_id="WB",
    )
    return tool.run(request)


# ============================================================================
# Query tool + snapshot selection
# ============================================================================


def test_query_filters_by_snapshot_date_and_plant():
    tool = QueryWBBankTool(_bank_datasource())
    result = _run(tool, "wb.bank_query_input", WBBankQueryInput(snapshot_date=GOLDEN_DATE, plant_id=SCENARIO_B_PLANT))
    payload = PayloadRegistry.unpack(result.payload)
    assert isinstance(payload, WBBankQueryResult)
    assert len(payload.records) == 10
    assert all(r.plant_id == SCENARIO_B_PLANT for r in payload.records)


def test_latest_snapshot_only_default_true_collapses_to_single_sync_time():
    tool = QueryWBBankTool(_bank_datasource())
    result = _run(tool, "wb.bank_query_input", WBBankQueryInput(plant_id=SCENARIO_B_PLANT))  # no snapshot_date -- across both days
    payload = PayloadRegistry.unpack(result.payload)
    sync_times = {r.source_sync_time for r in payload.records}
    assert len(sync_times) == 1
    assert sync_times.pop() == BANK_SNAPSHOTS[-1]  # the latest of the 2 known snapshots


def test_latest_snapshot_only_false_returns_all_snapshots():
    """Phase WB-3B: BANK_SNAPSHOTS extended from 2 to 14 (one per day
    across HISTORY_DAYS, for historical/recurrence analysis) -- counts
    updated accordingly, same regression intent."""
    tool = QueryWBBankTool(_bank_datasource())
    result = _run(tool, "wb.bank_query_input", WBBankQueryInput(plant_id=SCENARIO_B_PLANT, latest_snapshot_only=False))
    payload = PayloadRegistry.unpack(result.payload)
    sync_times = {r.source_sync_time for r in payload.records}
    assert len(sync_times) == len(BANK_SNAPSHOTS)
    assert len(payload.records) == 10 * len(BANK_SNAPSHOTS)  # 10 rows x N snapshots


def test_query_scope_echoes_latest_snapshot_only_flag():
    tool = QueryWBBankTool(_bank_datasource())
    result = _run(tool, "wb.bank_query_input", WBBankQueryInput(snapshot_date=GOLDEN_DATE, latest_snapshot_only=False))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.scope.latest_snapshot_only is False
    assert payload.scope.snapshot_date == GOLDEN_DATE


def test_query_by_status_filter():
    tool = QueryWBBankTool(_bank_datasource())
    result = _run(tool, "wb.bank_query_input", WBBankQueryInput(snapshot_date=GOLDEN_DATE, plant_id=SCENARIO_B_PLANT, status=WBBankStatus.MATERIAL_SHORTAGE.value))
    payload = PayloadRegistry.unpack(result.payload)
    assert len(payload.records) == 7  # Golden Scenario B: 7/10 shortage
    assert all(r.bank_status == WBBankStatus.MATERIAL_SHORTAGE for r in payload.records)


# ============================================================================
# Empty data
# ============================================================================


def test_unknown_plant_returns_empty_not_error():
    tool = QueryWBBankTool(_bank_datasource())
    result = _run(tool, "wb.bank_query_input", WBBankQueryInput(snapshot_date=GOLDEN_DATE, plant_id="ASE99"))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.records == []
    assert payload.availability.is_empty is True
    assert result.status == ObservationStatus.SUCCESS


# ============================================================================
# Status summary -- Golden Scenario B
# ============================================================================


def test_summarize_status_golden_scenario_b_material_shortage_dominant():
    tool = SummarizeWBBankStatusTool(_bank_datasource())
    result = _run(tool, "wb.bank_status_summary_input", WBBankStatusSummaryInput(snapshot_date=GOLDEN_DATE, plant_id=SCENARIO_B_PLANT))
    payload = PayloadRegistry.unpack(result.payload)
    assert isinstance(payload, WBBankStatusSummaryResult)
    assert payload.total_count == 10
    counts = {c.status: c.count for c in payload.by_status}
    assert counts[WBBankStatus.MATERIAL_SHORTAGE] == 7
    ratios = {c.status: c.ratio for c in payload.by_status}
    assert ratios[WBBankStatus.MATERIAL_SHORTAGE] == 0.7


def test_summarize_status_by_status_is_in_enum_declaration_order():
    tool = SummarizeWBBankStatusTool(_bank_datasource())
    result = _run(tool, "wb.bank_status_summary_input", WBBankStatusSummaryInput(snapshot_date=GOLDEN_DATE, plant_id=SCENARIO_B_PLANT))
    payload = PayloadRegistry.unpack(result.payload)
    statuses = [c.status for c in payload.by_status]
    enum_order = [s for s in WBBankStatus if s in statuses]
    assert statuses == enum_order


def test_summarize_status_deterministic_across_repeated_calls():
    tool = SummarizeWBBankStatusTool(_bank_datasource())
    r1 = PayloadRegistry.unpack(_run(tool, "wb.bank_status_summary_input", WBBankStatusSummaryInput(snapshot_date=GOLDEN_DATE)).payload)
    r2 = PayloadRegistry.unpack(_run(tool, "wb.bank_status_summary_input", WBBankStatusSummaryInput(snapshot_date=GOLDEN_DATE)).payload)
    assert r1.by_plant == r2.by_plant
    assert list(r1.by_plant.keys()) == sorted(r1.by_plant.keys())


# ============================================================================
# Aging -- known vs. unknown split (item M's own caution)
# ============================================================================


def test_aging_computed_for_records_with_known_entry_time():
    tool = AnalyzeWBBankAgingTool(_bank_datasource())
    result = _run(tool, "wb.bank_aging_analysis_input", WBBankAgingAnalysisInput(snapshot_date=GOLDEN_DATE, plant_id=SCENARIO_B_PLANT))
    payload = PayloadRegistry.unpack(result.payload)
    assert isinstance(payload, WBBankAgingAnalysisResult)
    assert payload.records_with_known_aging == 10  # synthetic dataset always sets status_50
    assert payload.records_with_unknown_aging == 0
    assert payload.average_aging_hours is not None
    assert payload.average_aging_hours > 0


def test_aging_unknown_entry_time_excluded_from_average_and_flagged_as_limitation():
    records, snapshot_dates = build_wb_bank_records()
    target = next(r for r in records if r.plant_id == SCENARIO_B_PLANT and r.source_sync_time.date() == GOLDEN_DATE)
    stripped = target.model_copy(update={"bank_entry_time": None})
    others = [r for r in records if r is not target]
    all_records = others + [stripped]
    snapshot_dates[id(stripped)] = snapshot_dates[id(target)]
    ds = InMemoryWBBankDataSource(all_records, snapshot_dates=snapshot_dates)
    tool = AnalyzeWBBankAgingTool(ds)
    result = _run(tool, "wb.bank_aging_analysis_input", WBBankAgingAnalysisInput(snapshot_date=GOLDEN_DATE, plant_id=SCENARIO_B_PLANT))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.records_with_unknown_aging == 1
    assert payload.records_with_known_aging == 9
    assert any("bank_entry_time" in msg for msg in payload.limitations)
    unknown_entries = [e for e in payload.longest_aging_entries if e.aging_hours is None]
    assert all(e.plant_id == SCENARIO_B_PLANT for e in unknown_entries) or not unknown_entries  # top_n may exclude it


def test_aging_average_is_none_when_zero_known_records():
    now = datetime(2026, 8, 12, 8, 40, tzinfo=None)
    records = [WBBankRecord(
        plant_id="ASE01", site_group=WBSiteGroup.A1, site_group_raw="A1", mother_batch_id="M1",
        customer_code=None, customer_sub_code=None, customer_group=None, device=None, package_code=None,
        lead_count=None, wafer_size_inch=None, wafer_quantity=None, die_quantity=None,
        bank_status=WBBankStatus.READY_TO_ISSUE, bank_status_raw="Ready To Issue", bank_entry_time=None,
        description=None, run_type=None, customer_run_type=None, unit_of_measure=None, source_sync_time=now,
    )]
    ds = InMemoryWBBankDataSource(records, snapshot_dates={id(records[0]): now.date()})
    tool = AnalyzeWBBankAgingTool(ds)
    result = _run(tool, "wb.bank_aging_analysis_input", WBBankAgingAnalysisInput(snapshot_date=now.date()))
    payload = PayloadRegistry.unpack(result.payload)
    assert payload.average_aging_hours is None
    assert payload.max_aging_hours is None
    assert payload.records_with_known_aging == 0
    assert payload.records_with_unknown_aging == 1


def test_aging_ranking_sorted_descending_ties_broken_by_mother_batch_id():
    tool = AnalyzeWBBankAgingTool(_bank_datasource())
    result = _run(tool, "wb.bank_aging_analysis_input", WBBankAgingAnalysisInput(snapshot_date=GOLDEN_DATE, top_n=100))
    payload = PayloadRegistry.unpack(result.payload)
    known = [e.aging_hours for e in payload.longest_aging_entries if e.aging_hours is not None]
    assert known == sorted(known, reverse=True)


# ============================================================================
# DataSource exception mapping
# ============================================================================


class _BrokenBankDataSource:
    def list_bank(self, *, snapshot_date=None):
        raise WBDataSourceUnavailableError("bank source down")

    def freshness(self):
        from agent.domain.wb.models import WB_BANK_FRESHNESS

        return WB_BANK_FRESHNESS


def test_datasource_error_maps_to_error_result():
    tool = QueryWBBankTool(_BrokenBankDataSource())
    result = _run(tool, "wb.bank_query_input", WBBankQueryInput())
    assert result.status == ObservationStatus.ERROR
    assert result.error_type == ErrorType.DATA_NOT_FOUND
