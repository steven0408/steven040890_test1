"""Phase PROD-1.2 (item G/81): pytest entrypoint into
scripts/production_calibration.py -- SKIPPED, not failed, everywhere this
suite runs without a real internal LLM configured (this sandbox, CI). On
the formal environment, with INTERNAL_LLM_* env vars set and
WB_DATASOURCE_PROFILE left unset/'in_memory', this test un-skips and
exercises the exact same calibration functions the standalone script uses
-- one more way to run the same calibration, not a second implementation
of it.
"""
import os

import pytest

pytestmark = pytest.mark.skipif(
    os.environ.get("LLM_PROVIDER") not in ("internal_openai",) or not os.environ.get("INTERNAL_LLM_BASE_URL"),
    reason="SKIPPED / NOT EXECUTED -- FORMAL ENVIRONMENT REQUIRED (needs LLM_PROVIDER=internal_openai + INTERNAL_LLM_BASE_URL pointing at the real internal gpt-oss-120b deployment)",
)


def test_production_calibration_full_run():
    """Runs the exact same orchestration scripts/production_calibration.py's
    own `main()` does, so `pytest -k production_calibration_live -s` is a
    second valid way to invoke it (in addition to `python -m
    scripts.production_calibration`) -- same functions, same output."""
    from scripts.production_calibration import main

    main()  # prints the full calibration report to stdout; nothing to assert
    # beyond "it completed without raising" -- this IS the calibration run,
    # not a pass/fail check (item 66: this phase evaluates whether the
    # cognitive path can operate, not business correctness).
