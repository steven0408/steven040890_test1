"""Phase WB-3A Test 10: full parent graph trace for an ISSUE INFORMATION
request -- `User -> Analyzer -> WB ModuleTask -> ModuleGoal ->
WBPlanningPolicy -> Objective -> CapabilityResolver -> ISSUE Skill -> Tool
-> InMemoryWBIssueDataSource -> Evidence -> Finding -> CompletionCheck`,
through the real `build_phase2_graph` composition. Reuses the exact
goal_statement propagation pattern Phase WB-2C.1 established -- no
`model_copy(update={"goal": ...})` injection, no direct Skill selection,
no bypassing the Planner. All offline.
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.graph.graph import build_phase2_graph
from agent.graph.nodes.analyzer_llm import AnalyzerLLMService, make_analyzer_llm_node
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.llm.client import MockLLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.context.analyzer_context import AnalyzerContextBuilder
from agent.llm.prompts.analyzer import AnalyzerDecision, ModuleSelection
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.modules.wb.package import build_wb_module_package
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import ModuleStatus, RunTerminationStatus, TaskType
from agent.state.state import AgentState
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry

from .conftest import make_agent_state, make_module_registry


def _make_wb_enabled_state(run_id: str, raw_text: str) -> AgentState:
    state = make_agent_state(run_id=run_id, raw_text=raw_text)
    return state.model_copy(update={"factory_context": state.factory_context.model_copy(update={"enabled_modules": ["WB"]})})


def _wb_module_runtime_config() -> ModuleRuntimeConfig:
    package = build_wb_module_package()
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner_capability = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=SkillRunner(tool_registry, ToolExecutionManager()))
    return ModuleRuntimeConfig(policy=WBPlanningPolicy(), capability=runner_capability, budget=package.budget)


def _analyzer_node_selecting_wb(task_type: TaskType, goal_statement: str):
    def responder(request):
        return AnalyzerDecision(
            task_type=task_type,
            selected_modules=[ModuleSelection(module_type="WB", priority=0.9, confidence=0.9, rationale="WB owns Issue/material-release data relevant to this request.", goal_statement=goal_statement)],
            reasoning_summary="Mock decision.",
            confidence=0.9,
        )

    registry = make_module_registry()
    registry.register(build_wb_module_package().module_definition)
    router = LLMRouter(routes={"analyzer": LLMRouteConfig(route="analyzer", model="mock-analyzer")}, client=MockLLMClient(responder), usage_sink=InMemoryLLMUsageSink())
    service = AnalyzerLLMService(registry, AnalyzerContextBuilder(registry), router)
    return make_analyzer_llm_node(service)


def test_parent_graph_issue_information_reaches_ready_for_synthesis():
    runtime = {"WB": _wb_module_runtime_config()}
    checkpointer = InMemorySaver()
    analyzer_node = _analyzer_node_selecting_wb(TaskType.INFORMATION, "Report ASE07 WB Issue (material release) status for 2026-08-12.")
    graph = build_phase2_graph(runtime, checkpointer, analyzer=analyzer_node)
    app = graph.compile(checkpointer=checkpointer)

    initial_state = _make_wb_enabled_state("wb-issue-parent-info", "2026-08-12 ASE07 的投料狀況如何？")
    result = app.invoke(initial_state, config={"configurable": {"thread_id": "wb-issue-parent-info"}})
    final_state = AgentState.model_validate(result)

    wb = final_state.module_states["WB"]
    assert wb.status == ModuleStatus.COMPLETE
    assert len(wb.objective_history) == 1
    record = next(iter(wb.objective_history.values()))
    assert record.capability_key == "wb.issue.status_summary"
    assert record.target_ref.ref_id == "ASE07"

    assert len(wb.evidence) == 1
    finding = wb.findings[-1]
    assert "400" in finding.statement
    assert finding.is_root_cause is False

    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS
