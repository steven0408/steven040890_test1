"""Phase WB-2D item 34/35: LLMPlanningPolicy(baseline_policy=WBPlanningPolicy())
RCA compatibility via MockLLMClient, and PlannerContext RCA visibility
(entity_states/findings/objective history/relevant capabilities -- bounded
typed summaries, never a raw dataset dump). Not exhaustive multi-round LLM
behavior -- proves WB RCA can use the generic LLM Planner infrastructure.
All offline.
"""
from datetime import date

from agent.capability.resolver import CapabilityResolver
from agent.llm.client import MockLLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
from agent.llm.context.evidence_selector import DeterministicEvidenceSelector
from agent.llm.context.planner_context import PlannerContextBuilder
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.modules.wb.package import build_wb_module_package
from agent.planning.policies.llm import LLMPlanningPolicy
from agent.planning.policies.wb import WBPlanningPolicy, build_wb_initial_entity_states
from agent.skills.registry import SkillRegistry
from agent.state.enums import ObjectiveAction, TargetRefType, TaskType
from agent.state.models import TargetRef
from agent.state.scope import ObjectiveScope, ScopeFilter, ScopeOperator, TimeScope, TimeScopeKind
from agent.tools.registry import ToolRegistry

from .conftest import make_module_state


def _wb_skill_registry() -> SkillRegistry:
    package = build_wb_module_package()
    registry = SkillRegistry()
    for directory in package.skill_directories:
        registry.load_directory(directory)
    return registry


def _wb_tool_registry() -> ToolRegistry:
    package = build_wb_module_package()
    registry = ToolRegistry()
    package.tool_registrations(registry)
    return registry


def _make_wb_llm_planning_policy(responder):
    skill_registry = _wb_skill_registry()
    tool_registry = _wb_tool_registry()
    context_builder = PlannerContextBuilder(DeterministicEvidenceSelector(), DeterministicCapabilityRetriever(skill_registry))
    usage_sink = InMemoryLLMUsageSink()
    client = MockLLMClient(responder)
    router = LLMRouter(routes={"planner": LLMRouteConfig(route="planner", model="mock-planner-v1", max_retries=1)}, client=client, usage_sink=usage_sink)
    policy = LLMPlanningPolicy(WBPlanningPolicy(), context_builder, router, skill_registry)
    return policy, skill_registry, tool_registry, context_builder


def _rca_module_state():
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    return module_state.model_copy(update={
        "goal": module_state.goal.model_copy(update={"task_type": TaskType.RCA, "statement": "2026-08-12 ASE07 output 偏低 root cause"}),
        "entity_states": build_wb_initial_entity_states(),
    })


# ============================================================================
# Item 34: LLMPlanningPolicy(baseline_policy=WBPlanningPolicy()) RCA
# ============================================================================


def test_llm_planning_policy_dispatches_a_valid_wb_rca_proposal():
    decision = PlannerDecision(
        decision=PlannerDecisionType.DISPATCH,
        next_objective=ObjectiveProposal(
            action=ObjectiveAction.COMPARE, capability_key="wb.output.comparison",
            target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="WB"),
            scope=ObjectiveScope(time=TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, date=date(2026, 8, 12)), filters=[]),
            description="ASE07 output symptom check", expected_output="output comparison",
        ),
        priority=0.9, rationale_summary="Checking whether ASE07's output is actually low before investigating further.",
    )
    policy, _, _, _ = _make_wb_llm_planning_policy(lambda req: decision)
    module_state = _rca_module_state()

    objective = policy.propose_next_objective(module_state)

    assert objective is not None
    assert objective.action == ObjectiveAction.COMPARE
    assert objective.capability_key == "wb.output.comparison"


def test_llm_planning_policy_falls_back_to_wb_rca_deterministic_baseline_on_llm_failure():
    from agent.llm.models import LLMTimeoutError

    def responder(req):
        raise LLMTimeoutError("simulated timeout")

    policy, _, _, _ = _make_wb_llm_planning_policy(responder)
    module_state = _rca_module_state()

    objective = policy.propose_next_objective(module_state)

    assert objective is not None
    assert objective.capability_key == "wb.output.comparison"  # WBPlanningPolicy's own deterministic RCA baseline


def test_llm_proposal_rejecting_a_non_rca_capability_key_falls_back():
    """A proposal naming a capability_key never extended to RCA
    (wb.bank.aging_analysis is analysis-only, item 37) must fail semantic
    validation and fall back -- never silently dispatched under the wrong
    TaskType."""
    decision = PlannerDecision(
        decision=PlannerDecisionType.DISPATCH,
        next_objective=ObjectiveProposal(
            action=ObjectiveAction.ANALYZE, capability_key="wb.bank.aging_analysis",
            target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="WB"),
            scope=None, description="x", expected_output="x",
        ),
        priority=0.9, rationale_summary="x",
    )
    policy, _, _, _ = _make_wb_llm_planning_policy(lambda req: decision)
    module_state = _rca_module_state()

    objective = policy.propose_next_objective(module_state)

    assert objective is not None
    assert objective.capability_key == "wb.output.comparison"  # fell back to the deterministic baseline, not the bad proposal


# ============================================================================
# Item 35: PlannerContext RCA visibility
# ============================================================================


def test_planner_context_rca_shows_entity_states_findings_and_capabilities():
    _, skill_registry, _, context_builder = _make_wb_llm_planning_policy(lambda req: None)
    module_state = _rca_module_state()
    # `relevant_entity_states` is scoped to the CURRENT objective's own
    # entity target (agent/llm/context/planner_context.py::_relevant_scope)
    # -- simulate a just-dispatched entity-scoped Bank check for ASE07 to
    # exercise the RCA-only entity_states gating (ANALYSIS has it off
    # entirely, regardless of current_objective).
    from agent.state.models import Objective

    module_state = module_state.model_copy(update={
        "current_objective": Objective(
            objective_id="obj-1", description="ASE07 bank check", action=ObjectiveAction.SUMMARIZE,
            capability_key="wb.bank.status_summary", target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="ASE07"),
            scope=None, expected_output="x", priority_score=1.0,
        )
    })

    outcome = context_builder.build(module_state, run_id="run-1")

    assert outcome.context.goal.task_type == TaskType.RCA
    assert outcome.context.goal.module_goal_statement == "2026-08-12 ASE07 output 偏低 root cause"
    # entity_states gating is True for RCA (unlike ANALYSIS) -- ASE07's
    # plant entity should be visible in context.
    entity_ids = {e.entity_id for e in outcome.context.current_state.relevant_entity_states}
    assert "ASE07" in entity_ids

    capability_keys = {s.capability_key for s in outcome.context.relevant_capabilities}
    # Phase WB-3B: WB now registers 10 RCA-capable skills (up from 4 in
    # WB-2D). Phase WB-3F.3 bumped PlannerContext's RCA budget's
    # `max_skills` from 6 to 10 (agent/llm/context/planner_context.py,
    # empirically justified -- see that file's own comment: the old
    # cap of 6 alphabetically excluded `wb.output.comparison` from ever
    # reaching the Planner on a fresh RCA round, a real live-observed
    # bug this phase fixed) -- WB's own RCA-capable catalog now fits
    # within budget in full. Still asserting a bound (never unbounded)
    # to keep this test meaningful if the catalog grows again.
    assert 0 < len(capability_keys) <= 10
    assert capability_keys <= {
        "wb.oee.plant_status", "wb.bank.status_summary", "wb.wip.hold_analysis", "wb.output.comparison",
        "wb.issue.trend_analysis", "wb.oee.trend_analysis", "wb.wip.hold_trend_analysis",
        "wb.bank.shortage_trend_analysis", "wb.output.trend_analysis", "wb.issue_output.relationship_analysis",
    }


def test_planner_context_rca_capabilities_never_include_information_only_skills():
    """wb.output_status_summary/wb.wip_status_summary/wb.bank_aging_analysis/
    wb.oee_status_analysis were never extended to RCA (item 37: only the
    Skills a real investigation needs) -- confirms the retriever genuinely
    reflects each Skill's own declared task_types, not "every WB skill is
    available once RCA is enabled". Phase WB-3B adds `rca` to
    wb.issue_trend_analysis's task_types plus 5 new historical/
    cross-source Skills (all declared `task_types: [analysis, rca]`)."""
    skill_registry = _wb_skill_registry()
    retriever = DeterministicCapabilityRetriever(skill_registry)
    summaries = retriever.retrieve(module_type="WB", task_type=TaskType.RCA, action_hint=None, limit=10)
    capability_keys = {s.capability_key for s in summaries}

    assert capability_keys == {
        "wb.oee.plant_status", "wb.bank.status_summary", "wb.wip.hold_analysis", "wb.output.comparison",
        "wb.issue.trend_analysis", "wb.oee.trend_analysis", "wb.wip.hold_trend_analysis",
        "wb.bank.shortage_trend_analysis", "wb.output.trend_analysis", "wb.issue_output.relationship_analysis",
    }


def test_planner_context_builder_does_not_dump_raw_datasets():
    """Bounded typed summaries only (item 35's own explicit prohibition on
    a raw 300-row WIP dump) -- the context object's evidence/capability
    fields are small, structured summaries, not raw payload lists."""
    _, skill_registry, _, context_builder = _make_wb_llm_planning_policy(lambda req: None)
    module_state = _rca_module_state()
    outcome = context_builder.build(module_state, run_id="run-1")

    assert len(outcome.context.relevant_capabilities) <= 10
    assert len(outcome.context.current_state.relevant_entity_states) <= len(module_state.entity_states)
