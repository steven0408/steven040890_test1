"""Phase WB-3A item U: WBPlanningPolicy routes an ISSUE-topic INFORMATION
request to `wb.issue.status_summary` via topic keyword detection -- never
a hardcoded "if this exact question then this Tool" mapping (same
mechanism WB-2C already established for OEE/BANK/WIP/OUTPUT). Also
confirms the ANALYSIS+"issue" topic without historical intent still fails
closed (no crash, no viable objective) rather than silently guessing a
date range. Phase WB-3B item 14 adds the historical-intent counterpart:
ANALYSIS+"issue"+a historical keyword (e.g. "trend") now routes to
`wb.issue.trend_analysis` over a deterministic default window. All via
the real Module ReAct Subgraph. All offline.
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.modules.wb.package import build_wb_module_package
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import ModuleStatus, TaskType
from agent.state.models import ModuleState, ModuleTask
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry


def _run_wb(task_type: TaskType, thread_id: str, statement: str) -> ModuleState:
    package = build_wb_module_package()
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    runtime = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)

    policy = WBPlanningPolicy()
    graph = build_module_react_subgraph(policy, capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id="WB", module_type="WB", reason=statement, goal_statement=statement, confidence=0.9, priority=0.9, task_type=task_type)
    initial = build_initial_module_state(task, package.budget, run_id=f"run-{thread_id}", task_type=task_type)
    result = app.invoke(initial, config={"configurable": {"thread_id": thread_id}})
    return ModuleState.model_validate(result)


def test_information_issue_question_dispatches_status_summary():
    final_state = _run_wb(TaskType.INFORMATION, "issue-info", "2026-08-12 ASE07 的投料狀況如何")

    assert final_state.status == ModuleStatus.COMPLETE
    assert len(final_state.objective_history) == 1
    record = next(iter(final_state.objective_history.values()))
    assert record.capability_key == "wb.issue.status_summary"
    assert record.target_ref.ref_id == "ASE07"

    finding = final_state.findings[-1]
    assert "400" in finding.statement
    assert finding.is_root_cause is False


def test_information_issue_question_english_keyword_also_routes():
    final_state = _run_wb(TaskType.INFORMATION, "issue-info-en", "2026-08-12 ASE01 issue quantity")
    record = next(iter(final_state.objective_history.values()))
    assert record.capability_key == "wb.issue.status_summary"
    assert record.target_ref.ref_id == "ASE01"


def test_analysis_issue_topic_with_historical_intent_now_wired_wb3b():
    """Phase WB-3A's own documented boundary (ANALYSIS+"issue" had no
    wired capability, since trend needs a date range WBPlanningPolicy
    could not yet derive from a single detected date) is exactly what
    Phase WB-3B item 14 wires up: the "trend" keyword signals historical
    intent (item 60's bounded keyword set), so the deterministic 7-day
    default window (item 60) now yields a real `wb.issue.trend_analysis`
    Objective/Finding instead of failing closed."""
    final_state = _run_wb(TaskType.ANALYSIS, "issue-analysis-historical", "2026-08-12 ASE07 investigate issue trend")
    assert final_state.status == ModuleStatus.COMPLETE
    assert len(final_state.objective_history) == 1
    record = next(iter(final_state.objective_history.values()))
    assert record.capability_key == "wb.issue.trend_analysis"
    assert record.target_ref.ref_id == "ASE07"
    assert final_state.findings[-1].is_root_cause is False


def test_analysis_issue_topic_without_historical_intent_still_fails_closed():
    """Without a historical keyword, ANALYSIS+"issue" still has no wired
    non-historical capability this phase (item 59's "avoid capability
    overuse" -- historical must be request/policy-driven, never implicit)
    -- must fail closed, never crash, never guess a range."""
    final_state = _run_wb(TaskType.ANALYSIS, "issue-analysis-unwired", "2026-08-12 ASE07 investigate issue quantity")
    assert final_state.status == ModuleStatus.FAILED
    assert len(final_state.objective_history) == 0


def test_issue_missing_data_does_not_fabricate_a_zero():
    final_state = _run_wb(TaskType.INFORMATION, "issue-missing", "2099-01-01 ASE07 的投料狀況如何")
    assert final_state.status == ModuleStatus.PARTIAL
    finding = final_state.findings[-1]
    assert "No data" in finding.statement
