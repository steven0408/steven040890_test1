"""Offline tests for PostgresSettings/connection resolution/test-DB guard
(items 3/13). No `psycopg` required -- `connection.py` only imports it
lazily inside `PostgresConnectionFactory.connect()`, which none of these
tests call.
"""
import pytest

from agent.persistence.postgres.config import PostgresSettings
from agent.persistence.postgres.connection import allow_test_database_only, resolve_connection_params
from agent.persistence.postgres.errors import DatabaseConfigurationError, MissingDatabaseEnvironmentVariable


def _settings(**overrides) -> PostgresSettings:
    base = dict(host_env="RCA_PG_HOST", database_env="RCA_PG_DB", user_env="RCA_PG_USER", password_env="RCA_PG_PASSWORD")
    base.update(overrides)
    return PostgresSettings(**base)


def test_postgres_settings_never_holds_a_literal_secret_value():
    settings = _settings()
    dumped = settings.model_dump()
    # only env-var *names* are ever present -- no field is a password/secret value itself
    assert set(dumped.keys()) == {"host_env", "port", "database_env", "user_env", "password_env", "ssl_mode", "connect_timeout", "require_test_database"}
    assert dumped["password_env"] == "RCA_PG_PASSWORD"  # a name, not a value


def test_resolve_connection_params_reads_env_at_call_time(monkeypatch):
    monkeypatch.setenv("RCA_PG_HOST", "db.internal")
    monkeypatch.setenv("RCA_PG_DB", "rca")
    monkeypatch.setenv("RCA_PG_USER", "rca_app")
    monkeypatch.setenv("RCA_PG_PASSWORD", "s3cr3t")
    params = resolve_connection_params(_settings())
    assert params == {
        "host": "db.internal", "port": 5432, "dbname": "rca", "user": "rca_app", "password": "s3cr3t",
        "sslmode": "require", "connect_timeout": 10,
    }


def test_resolve_connection_params_raises_on_missing_env_var(monkeypatch):
    monkeypatch.delenv("RCA_PG_PASSWORD", raising=False)
    monkeypatch.setenv("RCA_PG_HOST", "db.internal")
    monkeypatch.setenv("RCA_PG_DB", "rca")
    monkeypatch.setenv("RCA_PG_USER", "rca_app")
    with pytest.raises(MissingDatabaseEnvironmentVariable):
        resolve_connection_params(_settings())


def test_resolve_connection_params_never_leaks_env_var_name_confusion(monkeypatch):
    # a config that names an empty env var string is a config error, not a
    # missing-env-var error -- caught earlier, more specifically
    monkeypatch.setenv("RCA_PG_HOST", "db.internal")
    monkeypatch.setenv("RCA_PG_DB", "rca")
    monkeypatch.setenv("RCA_PG_USER", "rca_app")
    with pytest.raises(DatabaseConfigurationError):
        resolve_connection_params(_settings(password_env=""))


def test_allow_test_database_only_rejects_when_flag_not_set():
    settings = _settings(require_test_database=False)
    with pytest.raises(DatabaseConfigurationError):
        allow_test_database_only(settings, resolved_database_name="rca_test")


def test_allow_test_database_only_accepts_test_named_database():
    settings = _settings(require_test_database=True)
    allow_test_database_only(settings, resolved_database_name="rca_test")  # does not raise


def test_allow_test_database_only_rejects_production_looking_name_even_with_flag():
    settings = _settings(require_test_database=True)
    with pytest.raises(DatabaseConfigurationError):
        allow_test_database_only(settings, resolved_database_name="rca_production")


def test_allow_test_database_only_rejects_name_with_no_test_marker():
    settings = _settings(require_test_database=True)
    with pytest.raises(DatabaseConfigurationError):
        allow_test_database_only(settings, resolved_database_name="rca_manufacturing")
