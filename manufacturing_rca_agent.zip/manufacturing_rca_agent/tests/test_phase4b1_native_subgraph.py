"""Phase 4B-1: Native Parent/Child Subgraph Integration.

Re-runs the exact Phase 4A scenario (OEE 3 cycles / Output 1 cycle / WIP
partial) through the corrected checkpointer wiring -- an explicit shared
`BaseCheckpointSaver` instance passed to both the parent graph and every
module subgraph, with `config` threaded through the wrapper's `.invoke()`
call -- instead of the old checkpointer-less / `checkpointer=True` wiring.

No Human interrupt yet (Execution Gate is still pass-through). The point of
this phase is solely to confirm the *runtime plumbing* needed for Phase
4B-2's interrupt/resume work is actually correct, verified empirically
(see the Phase 4B-1 report for how the checkpointer=True bug was found).
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.graph.graph import build_phase2_graph
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.planning.policies.mock import DeterministicMockPolicy, Requirement
from agent.state.enums import ErrorType, EvidenceQuality, ModuleStatus, ObservationStatus, RunTerminationStatus
from agent.state.state import AgentState
from agent.tools.base import ToolResult
from agent.tools.mocks.scripted_tool import ScriptedMockTool

from .conftest import make_agent_state, make_budget

MODULE_RUNTIME = {
    "OEE": ModuleRuntimeConfig(
        policy=DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=3),
        tool=ScriptedMockTool(
            {"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.MODERATE)}
        ),
        budget=make_budget(max_steps=5, max_tool_calls=5, max_depth_per_entity=3),
    ),
    "Output": ModuleRuntimeConfig(
        policy=DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1),
        tool=ScriptedMockTool(
            {"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}
        ),
        budget=make_budget(max_steps=5, max_tool_calls=5, max_depth_per_entity=3),
    ),
    "WIP": ModuleRuntimeConfig(
        policy=DeterministicMockPolicy(
            requirements=[
                Requirement(sources=["aging"], sufficiency_evidence_count=1),
                Requirement(sources=["bottleneck-primary", "bottleneck-alternative"], sufficiency_evidence_count=1),
            ]
        ),
        tool=ScriptedMockTool(
            {
                "aging": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="aging queue confirmed", quality=EvidenceQuality.MODERATE),
                "bottleneck-primary": ToolResult(status=ObservationStatus.ERROR, error_type=ErrorType.DATA_NOT_FOUND, error_message="no rows"),
                "bottleneck-alternative": ToolResult(status=ObservationStatus.ERROR, error_type=ErrorType.DATA_NOT_FOUND, error_message="no rows"),
            }
        ),
        budget=make_budget(max_steps=6, max_tool_calls=6, max_depth_per_entity=3),
    ),
}


def _run():
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(MODULE_RUNTIME, checkpointer)
    app = graph.compile(checkpointer=checkpointer)

    initial_state = make_agent_state()
    config = {"configurable": {"thread_id": initial_state.run_id}}

    result = app.invoke(initial_state, config=config)
    final_state = AgentState.model_validate(result)
    return app, config, final_state


# 1: final AgentState is semantically identical to Phase 4A's
def test_final_state_matches_phase4a_semantics():
    _, _, final_state = _run()

    assert final_state.module_states["OEE"].status == ModuleStatus.COMPLETE
    assert final_state.module_states["Output"].status == ModuleStatus.COMPLETE
    assert final_state.module_states["WIP"].status == ModuleStatus.PARTIAL
    assert len(final_state.module_states["OEE"].observations) == 3
    assert len(final_state.module_states["Output"].observations) == 1
    assert len(final_state.module_states["WIP"].limitations) == 1
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


# 2: modules remain fully isolated
def test_module_states_remain_isolated():
    _, _, final_state = _run()
    for module_id, module_state in final_state.module_states.items():
        assert module_state.module_id == module_id
        assert module_state.module_type == module_id
    all_objective_ids = [
        oid for m in final_state.module_states.values() for oid in m.objective_history
    ]
    assert len(all_objective_ids) == len(set(all_objective_ids))


# 3: fan-out/fan-in reducer behavior unchanged (module_states merges all 3)
def test_reducer_behavior_unchanged():
    _, _, final_state = _run()
    assert set(final_state.module_states) == {"OEE", "Output", "WIP"}


# 4: Coordinator responsibility unchanged (dispatch/drain)
def test_coordinator_still_drains_in_flight():
    app, config, _ = _run()
    history = list(reversed(list(app.get_state_history(config))))
    dispatch_states = [
        snap.values["module_dispatch"] for snap in history if snap.values.get("module_dispatch") is not None
    ]
    first_with_in_flight = next(d for d in dispatch_states if d.in_flight)
    assert set(first_with_in_flight.in_flight) == {"OEE", "Output", "WIP"}
    assert dispatch_states[-1].in_flight == []
    assert dispatch_states[-1].pending == []


# 5: Global Completion Check remains read-only
def test_global_completion_check_still_read_only():
    app, config, _ = _run()
    history = list(reversed(list(app.get_state_history(config))))
    before = next(snap for snap in history if snap.next == ("global_completion_check",))
    after = history[-1]
    assert before.values["module_states"] == after.values["module_states"]
    assert before.values["module_dispatch"] == after.values["module_dispatch"]


# 6: parent can inspect child execution/checkpoint state -- proven directly
# against the shared checkpointer's own storage, since a *completed* run's
# get_state()/get_state_history() only exposes pending tasks, not the full
# nested history (that's naturally exercised once Phase 4B-2 adds a real
# mid-run interrupt to inspect).
def test_child_checkpoints_are_stored_under_their_own_namespace_in_the_shared_checkpointer():
    app, config, final_state = _run()
    checkpointer = app.checkpointer

    entries = list(checkpointer.list({"configurable": {"thread_id": config["configurable"]["thread_id"]}}))
    namespaces = {e.config["configurable"].get("checkpoint_ns", "") for e in entries}

    module_namespaces = [ns for ns in namespaces if ns.startswith("module_subgraph:")]
    # one distinct nested namespace per dispatched module
    assert len(module_namespaces) == 3

    # each nested namespace's checkpoint channel_values is a genuine,
    # inspectable ModuleState -- not an opaque blob
    seen_module_ids = set()
    for entry in entries:
        ns = entry.config["configurable"].get("checkpoint_ns", "")
        if not ns.startswith("module_subgraph:"):
            continue
        channel_values = entry.checkpoint.get("channel_values", {})
        if "module_id" in channel_values:
            seen_module_ids.add(channel_values["module_id"])
    assert seen_module_ids == {"OEE", "Output", "WIP"}


def test_final_state_round_trips_through_json():
    _, _, final_state = _run()
    payload = final_state.model_dump_json()
    restored = AgentState.model_validate_json(payload)
    assert restored == final_state
