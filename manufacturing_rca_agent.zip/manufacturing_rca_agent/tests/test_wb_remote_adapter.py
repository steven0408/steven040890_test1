"""Phase "WB Real Data Onboarding" item 19/20/21: Remote*DataSource
skeletons -- request building, response normalization, and error mapping,
all via `FakeHttpClient` (tests/wb_fake_http_client.py). **Never contacts
`10.11.32.179` or any real host** -- `WBApiConfig.base_url_env` is
resolved from a `monkeypatch`-set env var pointing at a fake placeholder
URL string, never a real one.
"""
from datetime import date

import pytest

from agent.domain.wb.errors import WBDataSourceUnavailableError, WBInvalidAPIResponseError
from agent.domain.wb.remote import (
    RemoteWBBankDataSource,
    RemoteWBIssueDataSource,
    RemoteWBPlantOEEDataSource,
    RemoteWBStageOutputDataSource,
    RemoteWBWIPDataSource,
    WBApiConfig,
)

from .wb_fake_http_client import FakeHttpClient

_FAKE_BASE_URL = "http://fake-wb-host.invalid:18058"


@pytest.fixture()
def config(monkeypatch):
    monkeypatch.setenv("WB_API_BASE_URL_TEST", _FAKE_BASE_URL)
    return WBApiConfig(base_url_env="WB_API_BASE_URL_TEST")


def test_base_url_never_hardcoded_resolves_from_env(config):
    client = FakeHttpClient()
    client.queue_response(200, {"status": "success", "count": 0, "data": {}})
    ds = RemoteWBPlantOEEDataSource(config, http_client=client)
    ds.list_oee()
    assert client.requests[0]["url"] == f"{_FAKE_BASE_URL}/api/wb/oeedata"


def test_missing_base_url_env_raises_typed_error():
    config = WBApiConfig(base_url_env="WB_API_BASE_URL_NOT_SET_ANYWHERE")
    client = FakeHttpClient()
    ds = RemoteWBPlantOEEDataSource(config, http_client=client)
    with pytest.raises(WBDataSourceUnavailableError):
        ds.list_oee()
    assert client.requests == []  # never even attempted the call


def test_oee_request_building_includes_date_param(config):
    client = FakeHttpClient()
    client.queue_response(200, {"status": "success", "count": 0, "data": {}})
    ds = RemoteWBPlantOEEDataSource(config, http_client=client)
    ds.list_oee(production_date=date(2026, 8, 12))
    assert client.requests[0]["params"] == {"date": "2026-08-12"}


def test_oee_response_normalization_columns_oriented(config):
    client = FakeHttpClient()
    client.queue_response(200, {
        "status": "success", "count": 1,
        "data": {"DATE": {"0": "2026-08-12"}, "PLANT": {"0": "ASE01"}, "OPER": {"0": "2800"}, "OEE": {"0": 85.0},
                 "DOWN": {"0": 5.0}, "SETUP": {"0": 4.0}, "PM": {"0": 2.0}, "IDLE": {"0": 3.0},
                 "PRODUCTIVE": {"0": 80.0}, "ENG": {"0": 1.0}, "TS": {"0": 1.0}, "SYNC_TIME": {"0": "2026-08-13 08:30:00"}},
    })
    ds = RemoteWBPlantOEEDataSource(config, http_client=client)
    records = ds.list_oee(production_date=date(2026, 8, 12))
    assert len(records) == 1
    assert records[0].plant_id == "ASE01"
    assert records[0].oee == 85.0


def test_wip_request_building_includes_limit_param(config):
    client = FakeHttpClient()
    client.queue_response(200, {"status": "success", "count": 0, "data": []})
    ds = RemoteWBWIPDataSource(config, http_client=client)
    ds.list_wip(limit=500)
    assert client.requests[0]["params"]["limit"] == 500


def test_wip_response_normalization_records_oriented(config):
    client = FakeHttpClient()
    client.queue_response(200, {
        "status": "success", "count": 1,
        "data": [{"CURRENT_QTY": "1", "CUST": "C", "FACILITY_SOURCE": "ASE01", "LC": "1", "LOT_NO": "L1",
                   "OPER": "2800", "PKG": "P", "PLANT": "ASE01", "RUN_TYPE": "N", "SCHEDULE": "S1",
                   "STATUS": "Active", "SYNC_TIME": "2026-08-12 09:30:00"}],
    })
    ds = RemoteWBWIPDataSource(config, http_client=client)
    records = ds.list_wip()
    assert len(records) == 1
    assert records[0].lot_status.value == "active"


def test_output_request_building_prefers_time_over_date(config):
    client = FakeHttpClient()
    client.queue_response(200, {"status": "success", "count": 0, "data": {}})
    ds = RemoteWBStageOutputDataSource(config, http_client=client)
    ds.list_output(production_date=date(2026, 8, 12), sync_time="2026-08-12-08-30-00")
    assert client.requests[0]["params"] == {"time": "2026-08-12-08-30-00"}


def test_bank_response_normalization_columns_oriented(config):
    client = FakeHttpClient()
    client.queue_response(200, {
        "status": "success", "count": 1,
        "data": {"SYNC_TIME": {"0": "2026-08-12-08-40-00"}, "plant": {"0": "A01007"}, "site": {"0": "A2"},
                 "status": {"0": "MTL Shortage"}, "schedule": {"0": "SCH1"}, "cust_2_code": {"0": "C1"},
                 "cust_3_code": {"0": None}, "cust_grp": {"0": None}, "cust_runtype": {"0": None}, "description": {"0": ""},
                 "device": {"0": None}, "die_qty": {"0": None}, "lc": {"0": None}, "pkg": {"0": None}, "plant_1": {"0": None},
                 "run_type": {"0": None}, "status_50": {"0": None}, "uom": {"0": None}, "wafer_inch": {"0": None}, "wafer_qty": {"0": None}},
    })
    ds = RemoteWBBankDataSource(config, http_client=client)
    records = ds.list_bank()
    assert len(records) == 1
    assert records[0].plant_id == "ASE07"
    assert records[0].bank_status.value == "material_shortage"


def test_issue_request_building_includes_date_param_named_after_sync_semantics(config):
    """Item V: the real API's `date` param filters SYNC_TIME, not
    rel_date -- `list_issue(sync_date=...)` sends exactly `{"date": ...}`,
    matching the real endpoint's own parameter name, but the PYTHON-side
    parameter is deliberately named `sync_date` (not `release_date`) so
    nothing here pretends this filters by release date."""
    client = FakeHttpClient()
    client.queue_response(200, {"status": "success", "count": 0, "data": {}})
    ds = RemoteWBIssueDataSource(config, http_client=client)
    ds.list_issue(sync_date=date(2026, 8, 13))
    assert client.requests[0]["url"] == f"{_FAKE_BASE_URL}/api/wb/issue"
    assert client.requests[0]["params"] == {"date": "2026-08-13"}


def test_issue_request_building_omits_date_param_when_unscoped(config):
    client = FakeHttpClient()
    client.queue_response(200, {"status": "success", "count": 0, "data": {}})
    ds = RemoteWBIssueDataSource(config, http_client=client)
    ds.list_issue()
    assert client.requests[0]["params"] == {}


def test_issue_response_normalization_columns_oriented(config):
    client = FakeHttpClient()
    client.queue_response(200, {
        "status": "success", "count": 1,
        "data": {
            "SYNC_TIME": {"0": "2026-08-13 08:40:00"}, "bd_no": {"0": ""}, "cu_flag": {"0": "Y"},
            "cust_2_code": {"0": "C1"}, "cust_runtype": {"0": "N"}, "customer_name": {"0": "CUSTOMER_ONE"},
            "customer_sod": {"0": ""}, "dev_type": {"0": "DEVICE_A"}, "internal_sod": {"0": ""},
            "iss_qty": {"0": 0}, "lead_count": {"0": "100"}, "pack_code": {"0": "RY2N"}, "pack_typ": {"0": "STANDARD"},
            "prctr": {"0": "A01007"}, "region": {"0": "TW"}, "rel_date": {"0": "2026-08-12"}, "rel_sys": {"0": "MES"},
            "rel_time": {"0": "08:00:00"}, "routid": {"0": ""}, "run_type": {"0": "N"}, "schedule": {"0": "SCH0001"},
            "site": {"0": "A2"}, "time": {"0": "AM"}, "uom": {"0": "P"}, "user_id": {"0": ""}, "user_name": {"0": ""},
            "wafer_inch": {"0": "12"}, "year": {"0": "6"},
        },
    })
    ds = RemoteWBIssueDataSource(config, http_client=client)
    records = ds.list_issue(sync_date=date(2026, 8, 13))
    assert len(records) == 1
    assert records[0].plant_id == "ASE07"
    assert records[0].release_date == date(2026, 8, 12)
    assert records[0].issue_quantity == 0  # normalize_rows' "" -> None never touches this real 0
    assert records[0].bd_no_unknown is None  # "" -> None applied before parsing


def test_issue_empty_response_normalizes_to_zero_records(config):
    client = FakeHttpClient()
    client.queue_response(200, {"status": "success", "count": 0, "data": {}})
    ds = RemoteWBIssueDataSource(config, http_client=client)
    records = ds.list_issue()
    assert records == []


def test_issue_connection_error_maps_to_typed_unavailable_error(config):
    client = FakeHttpClient()
    client.queue_connection_error()
    ds = RemoteWBIssueDataSource(config, http_client=client)
    with pytest.raises(WBDataSourceUnavailableError):
        ds.list_issue()


def test_connection_error_maps_to_typed_unavailable_error(config):
    client = FakeHttpClient()
    client.queue_connection_error()
    ds = RemoteWBPlantOEEDataSource(config, http_client=client)
    with pytest.raises(WBDataSourceUnavailableError):
        ds.list_oee()


def test_5xx_status_maps_to_typed_unavailable_error(config):
    client = FakeHttpClient()
    client.queue_response(503, {"status": "error", "message": "service unavailable"})
    ds = RemoteWBPlantOEEDataSource(config, http_client=client)
    with pytest.raises(WBDataSourceUnavailableError):
        ds.list_oee()


def test_4xx_status_maps_to_typed_invalid_response_error(config):
    client = FakeHttpClient()
    client.queue_response(404, {"status": "error", "message": "not found"})
    ds = RemoteWBPlantOEEDataSource(config, http_client=client)
    with pytest.raises(WBInvalidAPIResponseError):
        ds.list_oee()


def test_error_status_in_200_body_maps_to_typed_error(config):
    """Flask's own pattern (per the phase spec's example code) returns
    HTTP 500 alongside `{"status": "error", ...}` -- but this adapter
    also defends against a well-formed-looking `status: "error"` body
    arriving with a 200."""
    client = FakeHttpClient()
    client.queue_response(200, {"status": "error", "message": "query failed"})
    ds = RemoteWBPlantOEEDataSource(config, http_client=client)
    with pytest.raises(WBInvalidAPIResponseError):
        ds.list_oee()


def test_invalid_json_maps_to_typed_error(config):
    client = FakeHttpClient()
    client.queue_invalid_json(200)
    ds = RemoteWBPlantOEEDataSource(config, http_client=client)
    with pytest.raises(WBInvalidAPIResponseError):
        ds.list_oee()


def test_missing_envelope_keys_maps_to_typed_error(config):
    client = FakeHttpClient()
    client.queue_response(200, {"unexpected": "shape"})
    ds = RemoteWBPlantOEEDataSource(config, http_client=client)
    with pytest.raises(WBInvalidAPIResponseError):
        ds.list_oee()


def test_never_contacts_a_real_host():
    """The literal real host never appears anywhere this adapter can
    reach at import/construction time -- it is only ever an env var
    VALUE an operator would set, never present in this codebase."""
    import agent.domain.wb.remote as remote_module

    source = remote_module.__file__
    with open(source, encoding="utf-8") as f:
        content = f.read()
    assert "10.11.32.179" not in content
    assert "18058" not in content
