"""Phase PROD-1.1 (item 90/91/93/94): per-route 2048-profile fit checks for
Standardizer/Analyzer/Reflector/Synthesis (Planner has its own dedicated,
more extensive file -- test_context_budget_2048_profile.py -- since it was
the route the production logs specifically flagged as worst)."""
from agent.llm.context.analyzer_context import AnalyzerContextBuilder
from agent.llm.context.reflector_context import ReflectorContextBuilder
from agent.llm.context.standardizer_context import StandardizerContextBuilder
from agent.llm.context.synthesis_context import SynthesisContextBuilder
from agent.llm.prompts.analyzer import AnalyzerDecision, build_analyzer_messages
from agent.llm.prompts.reflector import ReflectionDecision, build_reflector_messages
from agent.llm.prompts.standardizer import StandardizerExtraction, build_standardizer_messages
from agent.llm.prompts.synthesis import SynthesisDraft, build_synthesis_messages
from agent.llm.schema_compaction import compact_json_schema
from agent.llm.token_budget import ApproximateTokenEstimator, LLMContextProfile, RouteTokenBudget
from agent.state.enums import EvidenceQuality, ObservationStatus, TaskType
from agent.state.models import Evidence, Observation
from agent.synthesis.handoff_builder import ModuleHandoffBuilder

from .conftest import make_agent_state, make_module_registry, make_module_state

_PROFILE = LLMContextProfile(
    context_window_tokens=2048,
    route_budgets={
        "standardizer": RouteTokenBudget(max_output_tokens=400, minimum_output_tokens=150, safety_margin_tokens=64),
        "analyzer": RouteTokenBudget(max_output_tokens=400, minimum_output_tokens=150, safety_margin_tokens=64),
        "reflector": RouteTokenBudget(max_output_tokens=420, minimum_output_tokens=200, safety_margin_tokens=64),
        "synthesis": RouteTokenBudget(max_output_tokens=500, minimum_output_tokens=200, safety_margin_tokens=64),
    },
)
_ESTIMATOR = ApproximateTokenEstimator()


def _estimate(messages, output_model) -> int:
    return _ESTIMATOR.estimate_messages(messages) + _ESTIMATOR.estimate_schema(compact_json_schema(output_model))


def test_standardizer_fits_2048_profile():
    ctx = StandardizerContextBuilder().build(raw_text="Compare WB output for operation 2800 across plants on 2026-08-12.", factory_id="factory-a")
    messages = build_standardizer_messages(ctx)
    estimated = _estimate(messages, StandardizerExtraction)
    print(f"\nStandardizer estimated={estimated} available={_PROFILE.available_input_tokens('standardizer')}")
    assert estimated <= _PROFILE.available_input_tokens("standardizer")


def test_analyzer_fits_2048_profile():
    registry = make_module_registry()
    builder = AnalyzerContextBuilder(registry, context_profile=_PROFILE)
    ctx = builder.build(make_agent_state(raw_text="Compare WB output for operation 2800 across plants."))
    messages = build_analyzer_messages(ctx)
    estimated = _estimate(messages, AnalyzerDecision)
    print(f"\nAnalyzer estimated={estimated} available={_PROFILE.available_input_tokens('analyzer')}")
    assert estimated <= _PROFILE.available_input_tokens("analyzer")


def _reflector_module_state():
    module_state = make_module_state(module_type="WB")
    return module_state.model_copy(update={
        "observations": [Observation(observation_id="o1", objective_id="obj-1", tool_name="tool", status=ObservationStatus.SUCCESS)],
        "evidence": [Evidence(evidence_id="e1", objective_id="obj-1", source_tool="tool", summary="WB output at ASE07 was 12400 units on 2026-08-12, aggregated across all customers.", quality=EvidenceQuality.MODERATE)],
    })


def test_reflector_context_shrinks_and_reports_honest_fit_status():
    """Item 93: measures actual fit rather than forcing a specific pass --
    Reflector's own Causal Reasoning Ladder (a large, semantically load-
    bearing, deliberately NOT compacted-away block, item 43/75/76) makes it
    the second-tightest route after Planner. Reports the real number either
    way, matching item 82's own 'not maximum compression' principle."""
    builder = ReflectorContextBuilder(context_profile=_PROFILE)
    outcome = builder.build(_reflector_module_state(), run_id="r1")
    messages = build_reflector_messages(outcome.context)
    estimated = _estimate(messages, ReflectionDecision)
    available = _PROFILE.available_input_tokens("reflector")
    print(f"\nReflector estimated={estimated} available={available} items_trimmed={outcome.record.items_trimmed}")
    # P0 (Objective, New Evidence) must survive regardless of fit outcome.
    assert outcome.context.new_evidence.evidence_summary is not None
    assert outcome.context.hard_rules


def test_synthesis_fits_2048_profile():
    module_state = _reflector_module_state()
    state = make_agent_state(raw_text="Compare WB output for operation 2800 across plants.").model_copy(update={"module_states": {"WB": module_state}})
    builder = SynthesisContextBuilder(ModuleHandoffBuilder(), context_profile=_PROFILE)
    outcome = builder.build(state)
    messages = build_synthesis_messages(outcome.context)
    estimated = _estimate(messages, SynthesisDraft)
    print(f"\nSynthesis estimated={estimated} available={_PROFILE.available_input_tokens('synthesis')}")
    assert estimated <= _PROFILE.available_input_tokens("synthesis")
