"""Phase "WB Real Data Onboarding" item 21: Plant/site/operation/status
mapping -- known values resolve, unknown values stay explicit (never
silently reinterpreted).
"""
from agent.domain.wb.mappings import (
    is_known_plant_id,
    operation_label,
    resolve_bank_status,
    resolve_lot_status,
    resolve_plant_id,
    resolve_site_group,
)
from agent.domain.wb.models import WBBankStatus, WBLotStatus, WBSiteGroup


def test_a01001_maps_to_ase01():
    assert resolve_plant_id("A01001") == "ASE01"


def test_a01008_maps_to_ase08():
    assert resolve_plant_id("A01008") == "ASE08"


def test_all_five_plants_map_correctly():
    assert resolve_plant_id("A01002") == "ASE02"
    assert resolve_plant_id("A01003") == "ASE03"
    assert resolve_plant_id("A01007") == "ASE07"


def test_already_canonical_plant_id_passes_through():
    assert resolve_plant_id("ASE01") == "ASE01"


def test_unknown_plant_id_stays_unchanged_not_guessed():
    assert resolve_plant_id("[FAB_A]") == "[FAB_A]"
    assert is_known_plant_id("[FAB_A]") is False
    assert is_known_plant_id("ASE01") is True


def test_site_group_resolves_known_values():
    canonical, raw = resolve_site_group("A1")
    assert canonical == WBSiteGroup.A1
    assert raw == "A1"
    canonical, raw = resolve_site_group("A2")
    assert canonical == WBSiteGroup.A2


def test_site_group_unknown_value_stays_explicit():
    canonical, raw = resolve_site_group("A9-not-real")
    assert canonical == WBSiteGroup.UNKNOWN
    assert raw == "A9-not-real"  # preserved, not discarded


def test_operation_label_known_values():
    assert operation_label("2600") == "DA"
    assert operation_label("2800") == "WB"


def test_operation_label_unknown_returns_none_not_a_guess():
    assert operation_label("9999") is None


def test_bank_status_canonicalization():
    assert resolve_bank_status("Ready To Issue") == (WBBankStatus.READY_TO_ISSUE, "Ready To Issue")
    assert resolve_bank_status("MTL Shortage") == (WBBankStatus.MATERIAL_SHORTAGE, "MTL Shortage")
    assert resolve_bank_status("No Wafer In") == (WBBankStatus.NO_WAFER_IN, "No Wafer In")


def test_bank_status_unknown_raw_value_stays_explicit():
    canonical, raw = resolve_bank_status("Some New Status")
    assert canonical == WBBankStatus.UNKNOWN
    assert raw == "Some New Status"


def test_lot_status_canonicalization():
    assert resolve_lot_status("Active") == (WBLotStatus.ACTIVE, "Active")
    assert resolve_lot_status("Hold") == (WBLotStatus.HOLD, "Hold")


def test_lot_status_unknown_raw_value_stays_explicit():
    canonical, raw = resolve_lot_status("Scrapped")
    assert canonical == WBLotStatus.UNKNOWN
    assert raw == "Scrapped"
