"""Phase WB-2D item 26/53/54: Synthesis/Evaluator compatibility smoke --
no Synthesis/Evaluator code changes, just confirming a real WB RCA
ModuleState flows through `ModuleHandoffBuilder`/`RunEvaluator` without
crashing, and -- the important hallucination guard -- that a supported
causal CANDIDATE (`is_root_cause=False`) never gets promoted into
`ModuleHandoff.root_causes`. All offline.
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.modules.wb.package import build_wb_module_package
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import ModuleStatus, TaskType
from agent.state.models import ModuleState, ModuleTask
from agent.synthesis.handoff_builder import ModuleHandoffBuilder
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry


def _run_wb_rca(thread_id: str, statement: str) -> ModuleState:
    package = build_wb_module_package()
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    runtime = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)

    policy = WBPlanningPolicy()
    graph = build_module_react_subgraph(policy, capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id="WB", module_type="WB", reason=statement, goal_statement=statement, confidence=0.9, priority=0.9, task_type=TaskType.RCA)
    initial = build_initial_module_state(task, package.budget, run_id=f"run-{thread_id}", task_type=TaskType.RCA)
    result = app.invoke(initial, config={"configurable": {"thread_id": thread_id}})
    return ModuleState.model_validate(result)


def test_material_shortage_candidate_never_becomes_a_synthesis_root_cause():
    module_state = _run_wb_rca("synth-b", "2026-08-12 ASE07 output 偏低 root cause")
    assert module_state.status == ModuleStatus.COMPLETE
    assert any(f.is_root_cause for f in module_state.findings) is False  # precondition

    handoff = ModuleHandoffBuilder().build(module_state)

    assert handoff.root_causes == []  # the hallucination guard: no CONFIRMED+is_root_cause=True finding exists
    assert handoff.confirmed_findings  # the candidate still surfaces as a confirmed FINDING, just not a root cause
    assert any("material shortage" in f.statement.lower() for f in handoff.confirmed_findings)


def test_oee_pattern_finding_never_becomes_a_synthesis_root_cause():
    module_state = _run_wb_rca("synth-a", "2026-08-12 ASE01 OEE 表現差 root cause")
    handoff = ModuleHandoffBuilder().build(module_state)
    assert handoff.root_causes == []


def test_wip_hold_pattern_finding_never_becomes_a_synthesis_root_cause():
    module_state = _run_wb_rca("synth-c", "2026-08-12 ASE03 WIP hold 異常 root cause")
    handoff = ModuleHandoffBuilder().build(module_state)
    assert handoff.root_causes == []


def test_missing_data_partial_state_builds_a_handoff_without_crashing():
    """Phase WB-3A/WB-3B's own documented gap ("no formal Limitation this
    phase") is exactly what Phase WB-3C closes: ASE08's empty OEE result
    now produces a real, structured `Limitation`, propagated through to
    the Synthesis handoff."""
    module_state = _run_wb_rca("synth-e", "2026-08-12 ASE08 OEE 異常 root cause")
    assert module_state.status == ModuleStatus.PARTIAL
    handoff = ModuleHandoffBuilder().build(module_state)
    assert handoff.root_causes == []
    assert len(handoff.limitations) == 1
    assert handoff.limitations[0].limitation_id == "WB-lim-WB-obj-1-no_data"
    assert "ASE08" in handoff.limitations[0].description
    assert handoff.module_status == ModuleStatus.PARTIAL


def test_run_evaluator_does_not_crash_on_a_wb_rca_run():
    """Item 54: not an acceptance blocker, just a crash-smoke."""
    from agent.evaluation.evaluator import RunEvaluator
    from agent.state.enums import RunTerminationStatus
    from agent.state.models import Goal, GoalScope

    from .conftest import make_agent_state

    module_state = _run_wb_rca("synth-eval", "2026-08-12 ASE07 output 偏低 root cause")
    final_state = make_agent_state(run_id="run-synth-eval").model_copy(update={
        "module_states": {"WB": module_state},
        "global_goal": Goal(goal_id="g1", raw_statement="ASE07 output low?", normalized_statement="ASE07 output low root cause", task_type=TaskType.RCA, scope=GoalScope()),
        "termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS,
    })

    evaluator = RunEvaluator()
    report = evaluator.evaluate(final_state)
    assert report is not None
