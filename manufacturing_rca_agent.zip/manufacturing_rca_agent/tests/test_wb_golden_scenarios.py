"""Phase "WB Real Data Onboarding" items 12-16/21: Golden Scenarios A-E --
data-level consistency checks only. No RCA rule, causal inference, Skill,
or Policy is exercised here (none exist yet, by design this phase) -- see
docs/wb_data_layer.md section 7 for the full scenario table.
"""
from datetime import date

from agent.domain.wb.datasource import (
    InMemoryWBBankDataSource,
    InMemoryWBPlantOEEDataSource,
    InMemoryWBStageOutputDataSource,
    InMemoryWBWIPDataSource,
)
from agent.domain.wb.models import WBBankStatus, WBLotStatus
from agent.domain.wb.synthetic import (
    GOLDEN_DATE,
    SCENARIO_A_PLANT,
    SCENARIO_B_PLANT,
    SCENARIO_C_PLANT,
    SCENARIO_D_PLANT,
    SCENARIO_E_PLANT,
    build_wb_bank_records,
    build_wb_plant_oee_records,
    build_wb_stage_output_records,
    build_wb_wip_records,
)


def _datasources():
    oee = InMemoryWBPlantOEEDataSource(build_wb_plant_oee_records())
    output = InMemoryWBStageOutputDataSource(build_wb_stage_output_records())
    bank_records, bank_snap = build_wb_bank_records()
    bank = InMemoryWBBankDataSource(bank_records, snapshot_dates=bank_snap)
    wip_records, wip_snap = build_wb_wip_records()
    wip = InMemoryWBWIPDataSource(wip_records, snapshot_dates=wip_snap)
    return oee, output, bank, wip


def test_scenario_a_equipment_side_loss():
    oee, output, bank, wip = _datasources()

    oee_rows = [r for r in oee.list_oee(production_date=GOLDEN_DATE) if r.plant_id == SCENARIO_A_PLANT and r.operation_id == "2800"]
    assert len(oee_rows) == 1
    assert oee_rows[0].oee < 70.0  # clearly degraded vs. the 85.0 baseline
    assert oee_rows[0].downtime_ratio > 10.0
    assert oee_rows[0].setup_ratio > 10.0

    output_rows = [r for r in output.list_output(production_date=GOLDEN_DATE) if r.plant_id == SCENARIO_A_PLANT and r.operation_id == "2800"]
    assert output_rows
    assert all(r.output_quantity < 2000 for r in output_rows)  # shortage vs. the 2000 baseline

    bank_rows = [r for r in bank.list_bank(snapshot_date=GOLDEN_DATE) if r.plant_id == SCENARIO_A_PLANT]
    shortage_ratio = sum(1 for r in bank_rows if r.bank_status == WBBankStatus.MATERIAL_SHORTAGE) / len(bank_rows)
    assert shortage_ratio < 0.3  # BANK input is normal -- the shortage story belongs to Scenario B, not A


def test_scenario_b_material_input_shortage():
    oee, output, bank, wip = _datasources()

    bank_rows = [r for r in bank.list_bank(snapshot_date=GOLDEN_DATE) if r.plant_id == SCENARIO_B_PLANT]
    shortage_ratio = sum(1 for r in bank_rows if r.bank_status == WBBankStatus.MATERIAL_SHORTAGE) / len(bank_rows)
    assert shortage_ratio > 0.5  # most BANK rows are MATERIAL_SHORTAGE

    oee_rows = [r for r in oee.list_oee(production_date=GOLDEN_DATE) if r.plant_id == SCENARIO_B_PLANT and r.operation_id == "2800"]
    assert oee_rows[0].oee >= 80.0  # OEE stays normal -- NOT an equipment-loss story

    output_rows = [r for r in output.list_output(production_date=GOLDEN_DATE) if r.plant_id == SCENARIO_B_PLANT and r.operation_id == "2800"]
    assert all(r.output_quantity < 2000 for r in output_rows)  # output still down, despite normal OEE


def test_scenario_c_wip_hold_flow_issue():
    oee, output, bank, wip = _datasources()

    wip_rows = [r for r in wip.list_wip(snapshot_date=GOLDEN_DATE) if r.plant_id == SCENARIO_C_PLANT]
    hold_ratio = sum(1 for r in wip_rows if r.lot_status == WBLotStatus.HOLD) / len(wip_rows)
    assert hold_ratio > 0.5  # Hold ratio sharply elevated

    bank_rows = [r for r in bank.list_bank(snapshot_date=GOLDEN_DATE) if r.plant_id == SCENARIO_C_PLANT]
    bank_shortage_ratio = sum(1 for r in bank_rows if r.bank_status == WBBankStatus.MATERIAL_SHORTAGE) / len(bank_rows)
    assert bank_shortage_ratio < 0.3  # BANK normal -- not a material story

    oee_rows = [r for r in oee.list_oee(production_date=GOLDEN_DATE) if r.plant_id == SCENARIO_C_PLANT]
    assert all(r.oee >= 80.0 for r in oee_rows)  # OEE normal -- not an equipment story

    output_rows = [r for r in output.list_output(production_date=GOLDEN_DATE) if r.plant_id == SCENARIO_C_PLANT]
    assert all(r.output_quantity < 2000 for r in output_rows)  # output still down


def test_scenario_d_normal_false_positive_control():
    oee, output, bank, wip = _datasources()

    oee_rows = [r for r in oee.list_oee(production_date=GOLDEN_DATE) if r.plant_id == SCENARIO_D_PLANT]
    assert all(r.oee >= 80.0 for r in oee_rows)

    bank_rows = [r for r in bank.list_bank(snapshot_date=GOLDEN_DATE) if r.plant_id == SCENARIO_D_PLANT]
    assert sum(1 for r in bank_rows if r.bank_status == WBBankStatus.MATERIAL_SHORTAGE) / len(bank_rows) < 0.3

    wip_rows = [r for r in wip.list_wip(snapshot_date=GOLDEN_DATE) if r.plant_id == SCENARIO_D_PLANT]
    assert sum(1 for r in wip_rows if r.lot_status == WBLotStatus.HOLD) / len(wip_rows) < 0.3

    output_rows = [r for r in output.list_output(production_date=GOLDEN_DATE) if r.plant_id == SCENARIO_D_PLANT]
    assert all(r.output_quantity >= 2000 for r in output_rows)  # no shortage signal anywhere


def test_scenario_e_missing_data_gap_stays_explicit():
    oee, output, bank, wip = _datasources()

    oee_rows = [r for r in oee.list_oee(production_date=GOLDEN_DATE) if r.plant_id == SCENARIO_E_PLANT]
    assert oee_rows == []  # the gap is an empty list, never a fabricated zero-value row

    # other plants on the same day are unaffected by ASE08's missing OEE
    other_plants_oee = [r for r in oee.list_oee(production_date=GOLDEN_DATE) if r.plant_id != SCENARIO_E_PLANT]
    assert len(other_plants_oee) > 0

    # ASE08 itself has data on non-golden days -- only the golden day is missing
    earlier_day_oee = [r for r in oee.list_oee(production_date=date(2026, 8, 11)) if r.plant_id == SCENARIO_E_PLANT]
    assert len(earlier_day_oee) > 0
