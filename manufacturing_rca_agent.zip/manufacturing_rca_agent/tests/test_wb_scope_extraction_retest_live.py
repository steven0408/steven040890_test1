"""Phase WB-3F.3 (item 10/11/12/48/53): re-tests WB-3F.2's own GAP 1 finding
(live LLM reliably omitting an explicitly-named OPTIONAL scope filter) now
that the Planner prompt has been hardened with: (a) an explicit required-
vs-optional scope-dimension split per capability (agent/llm/context/
capability_retriever.py's `required_scope_dimensions`), (b) a generic
(non-test-value) JSON-shape example for how to represent a named filter,
(c) an explicit target-vs-filter and filter-vs-group_by distinction.

Reuses test_wb_dynamic_parameter_wiring_live.py's own wiring helpers.
Deliberately does NOT retry until a scenario passes -- each scenario runs
ONCE per model and reports the observed outcome honestly, matching every
other live-behavior finding in this project's history.
"""
import os

import pytest

from agent.state.enums import TaskType

from .test_wb_dynamic_parameter_wiring_live import _bootstrap_state, _budget, _dynamic_wiring_datasources
from .test_wb_reasoning_llm_live import _wb_registries

pytestmark = pytest.mark.skipif(
    not os.environ.get("OPENAI_API_KEY"),
    reason="OPENAI_API_KEY not set -- real OpenAI-provider scope-extraction retest skipped (not failed) without a secret",
)

_SCENARIOS = [
    ("A: generic output comparison", TaskType.ANALYSIS, "2026-08-12 比較各廠 Output", "wb.output.comparison", None, None),
    ("B: operation-specific output comparison", TaskType.ANALYSIS, "2026-08-12 比較 operation WB1 各廠 Output", "wb.output.comparison", "operation", "WB1"),
    ("C: generic BANK status", TaskType.INFORMATION, "2026-08-12 ASE07 的 BANK 狀況如何？", "wb.bank.status_summary", None, None),
    ("D: customer-specific BANK status", TaskType.INFORMATION, "2026-08-12 ASE07 客戶 CUST_A 的 BANK 狀況如何？", "wb.bank.status_summary", "customer", "CUST_A"),
]


def _planner_policy_for_model(model: str):
    from agent.llm.config import LLMRouteConfig
    from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
    from agent.llm.context.evidence_selector import DeterministicEvidenceSelector
    from agent.llm.context.planner_context import PlannerContextBuilder
    from agent.llm.context.reasoning_skill_retriever import DeterministicReasoningSkillRetriever
    from agent.llm.providers.openai_adapter import OpenAICompatibleAdapter
    from agent.llm.router import LLMRouter
    from agent.llm.usage import InMemoryLLMUsageSink
    from agent.planning.decision_audit import InMemoryPlannerDecisionAuditSink
    from agent.planning.policies.llm import LLMPlanningPolicy
    from agent.planning.policies.wb import WBPlanningPolicy

    package, skill_registry, tool_registry = _wb_registries(_dynamic_wiring_datasources())
    usage_sink = InMemoryLLMUsageSink()
    router = LLMRouter(
        routes={"planner": LLMRouteConfig(route="planner", model=model, timeout_seconds=30.0, max_retries=1)},
        client=OpenAICompatibleAdapter(temperature=0.0, max_tokens=1200), usage_sink=usage_sink,
    )
    context_builder = PlannerContextBuilder(
        DeterministicEvidenceSelector(), DeterministicCapabilityRetriever(skill_registry),
        reasoning_skill_retriever=DeterministicReasoningSkillRetriever(skill_registry),
    )
    decision_sink = InMemoryPlannerDecisionAuditSink()
    policy = LLMPlanningPolicy(WBPlanningPolicy(), context_builder, router, skill_registry, decision_audit_sink=decision_sink)
    return policy, decision_sink


def _run_scenario_table(model: str) -> list[dict]:
    rows = []
    for label, task_type, text, expected_capability, dim, expected_value in _SCENARIOS:
        policy, decision_sink = _planner_policy_for_model(model)
        module_state = _bootstrap_state(task_type, text, f"retest-{model}-{label[:1]}", _budget())
        objective = policy.propose_next_objective(module_state)

        capability_ok = objective is not None and objective.capability_key == expected_capability
        dims = {f.dimension: f.value for f in (objective.scope.filters if objective and objective.scope else [])}
        filter_present = dim is None or dim in dims
        filter_correct = dim is None or dims.get(dim) == expected_value
        record = decision_sink.list_for_run(module_state.run_id)[0] if decision_sink.list_for_run(module_state.run_id) else None

        row = {
            "model": model, "scenario": label, "capability_correct": capability_ok,
            "filter_present": filter_present if dim else "n/a (no filter expected)",
            "filter_correct": filter_correct if dim else "n/a",
            "source": record.source.value if record else "n/a",
        }
        rows.append(row)
        print(f"\n[{model}] {row}")
    return rows


def test_scope_extraction_retest_gpt_4o_mini():
    rows = _run_scenario_table("gpt-4o-mini")
    print("\n=== gpt-4o-mini scope extraction retest ===")
    for r in rows:
        print(r)
    # HARD invariant only -- capability_key correctness (same capability regardless of optional filter)
    assert all(r["capability_correct"] for r in rows)


def test_scope_extraction_retest_gpt_4o():
    rows = _run_scenario_table("gpt-4o")
    print("\n=== gpt-4o scope extraction retest ===")
    for r in rows:
        print(r)
    assert all(r["capability_correct"] for r in rows)
