"""Phase WB-2D item 55/56/57: a genuine multi-cycle PARENT graph RCA
trace -- `User -> Analyzer -> WB ModuleTask -> Send -> WB module subgraph
(multiple Planner/Gate/Executor/Reflector rounds) -> Coordinator fan-in ->
Global Completion Check -> READY_FOR_SYNTHESIS`, through the real
`build_phase2_graph` composition. Reuses the exact goal_statement
propagation pattern Phase WB-2C.1 established (no `model_copy(update=
{"goal": ...})` injection hack -- the scripted Analyzer's own
`goal_statement` is the only source of truth). All offline.
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.graph.graph import build_phase2_graph
from agent.graph.nodes.analyzer_llm import AnalyzerLLMService, make_analyzer_llm_node
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.llm.client import MockLLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.context.analyzer_context import AnalyzerContextBuilder
from agent.llm.prompts.analyzer import AnalyzerDecision, ModuleSelection
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.modules.wb.package import build_wb_module_package
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import ModuleStatus, RunTerminationStatus, TaskType
from agent.state.state import AgentState
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry

from .conftest import make_agent_state, make_module_registry


def _make_wb_enabled_state(run_id: str, raw_text: str) -> AgentState:
    state = make_agent_state(run_id=run_id, raw_text=raw_text)
    return state.model_copy(update={"factory_context": state.factory_context.model_copy(update={"enabled_modules": ["WB"]})})


def _wb_module_runtime_config() -> ModuleRuntimeConfig:
    package = build_wb_module_package()
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner_capability = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=SkillRunner(tool_registry, ToolExecutionManager()))
    return ModuleRuntimeConfig(policy=WBPlanningPolicy(), capability=runner_capability, budget=package.budget)


def _analyzer_node_selecting_wb_rca(goal_statement: str):
    def responder(request):
        return AnalyzerDecision(
            task_type=TaskType.RCA,
            selected_modules=[ModuleSelection(module_type="WB", priority=0.9, confidence=0.9, rationale="WB owns the operational data relevant to this request.", goal_statement=goal_statement)],
            reasoning_summary="Mock decision.",
            confidence=0.9,
        )

    registry = make_module_registry()
    registry.register(build_wb_module_package().module_definition)
    router = LLMRouter(routes={"analyzer": LLMRouteConfig(route="analyzer", model="mock-analyzer")}, client=MockLLMClient(responder), usage_sink=InMemoryLLMUsageSink())
    service = AnalyzerLLMService(registry, AnalyzerContextBuilder(registry), router)
    return make_analyzer_llm_node(service)


def _invoke(goal_statement: str, raw_text: str, run_id: str) -> AgentState:
    runtime = {"WB": _wb_module_runtime_config()}
    checkpointer = InMemorySaver()
    analyzer_node = _analyzer_node_selecting_wb_rca(goal_statement)
    graph = build_phase2_graph(runtime, checkpointer, analyzer=analyzer_node)
    app = graph.compile(checkpointer=checkpointer)

    initial_state = _make_wb_enabled_state(run_id, raw_text)
    result = app.invoke(initial_state, config={"configurable": {"thread_id": run_id}})
    return AgentState.model_validate(result)


# ============================================================================
# Item 55/56: multi-cycle RCA parent trace (Scenario B -- material shortage
# candidate, 2 rounds through the real parent graph)
# ============================================================================


def test_parent_graph_rca_multi_cycle_ase07_output_reaches_ready_for_synthesis():
    final_state = _invoke(
        goal_statement="Investigate the low WB output for ASE07 on 2026-08-12 and determine the best-supported explanation using available WB operational evidence.",
        raw_text="Why was ASE07 output low on 2026-08-12?",
        run_id="wb-rca-parent-ase07",
    )

    wb = final_state.module_states["WB"]
    assert wb.status == ModuleStatus.COMPLETE
    chain = [r.capability_key for r in wb.objective_history.values()]
    assert chain == ["wb.output.comparison", "wb.bank.status_summary"]  # genuine multi-round ReAct, not a single-shot call

    finding = wb.findings[-1]
    assert "material shortage" in finding.statement.lower()
    assert finding.is_root_cause is False

    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


def test_parent_graph_rca_reports_the_full_investigation_trace():
    """Item 56's own required trace listing -- proves each round really
    happened (Evidence per round, not just a final answer)."""
    final_state = _invoke(
        goal_statement="Investigate the low WB output for ASE07 on 2026-08-12 and determine the best-supported explanation using available WB operational evidence.",
        raw_text="Why was ASE07 output low on 2026-08-12?",
        run_id="wb-rca-parent-trace",
    )
    wb = final_state.module_states["WB"]
    assert len(wb.evidence) == 2
    assert len(wb.observations) == 2
    assert len(wb.findings) == 2  # one interim (symptom confirmed), one final (candidate found)
    assert "output was confirmed low" in wb.findings[0].statement.lower()


# ============================================================================
# Item 57: normal-premise RCA parent trace -- efficiency regression
# ============================================================================


def test_parent_graph_rca_normal_premise_stops_early():
    final_state = _invoke(
        goal_statement="Investigate whether ASE02's OEE was abnormal on 2026-08-12.",
        raw_text="Why was ASE02 OEE abnormal on 2026-08-12?",
        run_id="wb-rca-parent-normal",
    )

    wb = final_state.module_states["WB"]
    assert wb.status == ModuleStatus.COMPLETE
    assert len(wb.objective_history) == 1  # symptom check only -- premise rejected, no deep dive
    assert "no abnormal" in wb.findings[-1].statement.lower()
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


def test_parent_graph_rca_normal_premise_uses_fewer_objectives_than_multi_cycle_case():
    normal_state = _invoke(
        goal_statement="Investigate whether ASE02's OEE was abnormal on 2026-08-12.",
        raw_text="Why was ASE02 OEE abnormal on 2026-08-12?",
        run_id="wb-rca-parent-normal-eff",
    )
    multi_cycle_state = _invoke(
        goal_statement="Investigate the low WB output for ASE07 on 2026-08-12 and determine the best-supported explanation using available WB operational evidence.",
        raw_text="Why was ASE07 output low on 2026-08-12?",
        run_id="wb-rca-parent-multi-eff",
    )
    assert len(normal_state.module_states["WB"].objective_history) < len(multi_cycle_state.module_states["WB"].objective_history)
