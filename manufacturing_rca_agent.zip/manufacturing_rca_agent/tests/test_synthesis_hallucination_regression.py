"""Phase 6A item 11 -- the explicit hallucination regression the spec
calls out by name: if `HandoffPackage.root_causes` does not contain "Motor
Failure", the Markdown renderer must never print it; and if every finding
is still HYPOTHESIS-status, the renderer must never present it as a
confirmed root cause.
"""
from agent.llm.context.synthesis_context import SynthesisContextBuilder
from agent.state.enums import FindingStatus, ModuleStatus, TaskType
from agent.state.models import Finding, Goal, GoalScope
from agent.synthesis.handoff_builder import ModuleHandoffBuilder
from agent.synthesis.package import build_handoff_package
from agent.synthesis.renderer import render_markdown

from .conftest import make_agent_state, make_module_state


def _package_for(module_state):
    state = make_agent_state().model_copy(
        update={
            "module_states": {"OEE": module_state},
            "global_goal": Goal(goal_id="g1", raw_statement="why", normalized_statement="why", task_type=TaskType.RCA, scope=GoalScope()),
        }
    )
    outcome = SynthesisContextBuilder(ModuleHandoffBuilder()).build(state)
    return build_handoff_package(outcome.context)


def test_motor_failure_never_appears_when_not_a_confirmed_root_cause():
    """The finding text mentions "Motor Failure" but is never confirmed as
    a root cause (e.g. still under investigation, or explicitly rejected)
    -- it must not leak into root_causes or the rendered Markdown's Root
    Causes section."""
    module_state = make_module_state().model_copy(
        update={
            "status": ModuleStatus.PARTIAL,
            "findings": [
                Finding(finding_id="f1", statement="Motor Failure suspected but not yet confirmed.", pattern="Availability", confidence=0.4, status=FindingStatus.HYPOTHESIS, is_root_cause=False),
            ],
        }
    )
    package = _package_for(module_state)

    assert package.root_causes == []
    assert "Motor Failure" not in package.markdown


def test_confirmed_but_not_root_cause_finding_never_appears_in_root_causes():
    """CONFIRMED status alone is not enough -- is_root_cause must also be
    True, or it stays a Key Finding, never a Root Cause."""
    module_state = make_module_state().model_copy(
        update={
            "status": ModuleStatus.COMPLETE,
            "findings": [
                Finding(finding_id="f1", statement="Motor Failure pattern observed on EQ001.", pattern="Availability", confidence=0.8, status=FindingStatus.CONFIRMED, is_root_cause=False),
            ],
        }
    )
    package = _package_for(module_state)

    assert package.root_causes == []
    assert "## Root Causes" not in package.markdown
    # it's still legitimately a key finding -- not suppressed entirely, just not promoted
    assert any("Motor Failure" in f.statement for f in package.key_findings)
    assert "## Key Findings" in package.markdown


def test_rejected_finding_never_appears_anywhere():
    module_state = make_module_state().model_copy(
        update={
            "status": ModuleStatus.PARTIAL,
            "findings": [
                Finding(finding_id="f1", statement="Motor Failure -- ruled out after further review.", pattern="Availability", confidence=0.1, status=FindingStatus.REJECTED, is_root_cause=False),
            ],
        }
    )
    package = _package_for(module_state)

    assert package.root_causes == []
    assert package.key_findings == []
    assert "Motor Failure" not in package.markdown


def test_all_hypothesis_findings_module_never_produces_a_confirmed_root_cause_in_markdown():
    module_state = make_module_state().model_copy(
        update={
            "status": ModuleStatus.PARTIAL,
            "findings": [
                Finding(finding_id="f1", statement="Belt Wear hypothesis.", pattern="Availability", confidence=0.3, status=FindingStatus.HYPOTHESIS, is_root_cause=True),
            ],
        }
    )
    package = _package_for(module_state)

    # is_root_cause=True alone is not enough either -- status must be CONFIRMED
    assert package.root_causes == []
    assert "## Root Causes" not in package.markdown


def test_a_genuinely_confirmed_root_cause_does_appear_positive_control():
    """Positive control for the three tests above -- proves the guard is
    actually discriminating, not just always empty."""
    module_state = make_module_state().model_copy(
        update={
            "status": ModuleStatus.COMPLETE,
            "findings": [
                Finding(finding_id="f1", statement="Motor Failure on EQ001 confirmed as root cause.", pattern="Availability", confidence=0.9, status=FindingStatus.CONFIRMED, is_root_cause=True),
            ],
        }
    )
    package = _package_for(module_state)

    assert len(package.root_causes) == 1
    assert "Motor Failure" in package.markdown
    assert "## Root Causes" in package.markdown
