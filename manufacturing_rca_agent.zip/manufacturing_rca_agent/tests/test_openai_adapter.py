"""Phase WB-3E: OpenAICompatibleAdapter -- fully offline, no network/API
key needed. Mirrors `tests/test_anthropic_adapter.py`'s own exact
discipline: everything here injects a fake `client=` (any object shaped
like `openai.OpenAI().chat.completions`) so adapter logic (request
building, both structured-output tiers, usage extraction, exception
mapping) is tested deterministically. Real end-to-end network calls are
this phase's separate skip-marked smoke tests
(test_openai_cloud_live_smoke.py / test_internal_llm_live_smoke.py).
"""
import json

import httpx
import pytest

openai = pytest.importorskip("openai")

from agent.llm.models import LLMInvalidOutputError, LLMMessage, LLMProviderError, LLMRequest, LLMRole, LLMTimeoutError
from agent.llm.providers.openai_adapter import OpenAIAdapterConfigError, OpenAICompatibleAdapter
from agent.state.base import RCABaseModel

_REQUEST = LLMRequest(
    route="planner",
    model="gpt-test-model",
    messages=[LLMMessage(role=LLMRole.SYSTEM, content="be helpful"), LLMMessage(role=LLMRole.USER, content="hello")],
    output_schema_name="_Echo",
    timeout_seconds=10.0,
    run_id="run-1",
    module_id=None,
    node="module_planner",
)


class _Echo(RCABaseModel):
    value: str


class _FakeFunction:
    def __init__(self, name: str, arguments: str):
        self.name = name
        self.arguments = arguments


class _FakeToolCall:
    def __init__(self, name: str, arguments_dict: dict):
        self.function = _FakeFunction(name, json.dumps(arguments_dict))


class _FakeMessage:
    def __init__(self, content: str | None = None, tool_calls: list | None = None):
        self.content = content
        self.tool_calls = tool_calls


class _FakeChoice:
    def __init__(self, message: _FakeMessage, finish_reason: str | None = None):
        self.message = message
        self.finish_reason = finish_reason


class _FakeUsage:
    def __init__(self, prompt_tokens: int, completion_tokens: int):
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens


class _FakeChatCompletion:
    def __init__(self, choices: list, usage: _FakeUsage | None = None):
        self.choices = choices
        self.usage = usage


class _FakeCompletionsEndpoint:
    def __init__(self, responder):
        self._responder = responder
        self.calls: list[dict] = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return self._responder(kwargs)


class _FakeChatEndpoint:
    def __init__(self, responder):
        self.completions = _FakeCompletionsEndpoint(responder)


class _FakeOpenAIClient:
    def __init__(self, responder):
        self.chat = _FakeChatEndpoint(responder)


def _http_request() -> httpx.Request:
    return httpx.Request("POST", "https://api.openai.com/v1/chat/completions")


# ============================================================================
# Config / secret handling
# ============================================================================


def test_no_api_key_and_no_client_raises_typed_config_error(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    with pytest.raises(OpenAIAdapterConfigError):
        OpenAICompatibleAdapter()


def test_injected_client_bypasses_api_key_requirement(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion([_FakeChoice(_FakeMessage(tool_calls=[_FakeToolCall("emit_decision", {"value": "ok"})]))], _FakeUsage(5, 3)))
    adapter = OpenAICompatibleAdapter(client=fake)  # must not raise
    completion = adapter.complete(_REQUEST, _Echo)
    assert completion.parsed_output == _Echo(value="ok")


def test_config_error_message_never_echoes_any_key_value(monkeypatch):
    """Even though no key was ever supplied here, guard the error message
    shape itself -- it must describe WHAT'S missing, never any value."""
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    with pytest.raises(OpenAIAdapterConfigError) as exc_info:
        OpenAICompatibleAdapter()
    assert "sk-" not in str(exc_info.value)


# ============================================================================
# Tier 1: forced tool-calling -- happy path + usage extraction
# ============================================================================


def test_tool_calling_structured_output_parses_and_extracts_usage():
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion([_FakeChoice(_FakeMessage(tool_calls=[_FakeToolCall("emit_decision", {"value": "hello"})]))], _FakeUsage(42, 7)))
    adapter = OpenAICompatibleAdapter(client=fake)

    completion = adapter.complete(_REQUEST, _Echo)

    assert completion.parsed_output == _Echo(value="hello")
    assert completion.input_tokens == 42
    assert completion.output_tokens == 7
    assert completion.latency_ms >= 0

    call = fake.chat.completions.calls[0]
    assert call["model"] == "gpt-test-model"
    assert call["tool_choice"] == {"type": "function", "function": {"name": "emit_decision"}}
    # Phase PROD-1.1: the schema sent is COMPACT (title/description
    # stripped, see agent/llm/schema_compaction.py), not the raw Pydantic
    # schema -- structure/constraints are preserved (checked below).
    from agent.llm.schema_compaction import compact_json_schema

    assert call["tools"][0]["function"]["parameters"] == compact_json_schema(_Echo)
    assert "title" not in call["tools"][0]["function"]["parameters"]
    assert call["tools"][0]["function"]["parameters"]["properties"] == {"value": {"type": "string"}}
    assert call["timeout"] == 10.0
    assert call["messages"][0] == {"role": "system", "content": "be helpful"}
    assert call["messages"][1] == {"role": "user", "content": "hello"}


def test_missing_usage_object_yields_zero_not_fabricated_tokens():
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion([_FakeChoice(_FakeMessage(tool_calls=[_FakeToolCall("emit_decision", {"value": "x"})]))], usage=None))
    adapter = OpenAICompatibleAdapter(client=fake)
    completion = adapter.complete(_REQUEST, _Echo)
    assert completion.input_tokens == 0
    assert completion.output_tokens == 0


def test_temperature_and_max_tokens_are_adapter_level_not_per_request():
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion([_FakeChoice(_FakeMessage(tool_calls=[_FakeToolCall("emit_decision", {"value": "x"})]))]))
    adapter = OpenAICompatibleAdapter(client=fake, temperature=0.2, max_tokens=500)
    adapter.complete(_REQUEST, _Echo)
    call = fake.chat.completions.calls[0]
    assert call["temperature"] == 0.2
    assert call["max_tokens"] == 500


def test_no_tool_call_raises_invalid_output():
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion([_FakeChoice(_FakeMessage(content="I refuse to use the tool."))]))
    adapter = OpenAICompatibleAdapter(client=fake)
    with pytest.raises(LLMInvalidOutputError):
        adapter.complete(_REQUEST, _Echo)


def test_tool_call_arguments_failing_schema_validation_raises_invalid_output():
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion([_FakeChoice(_FakeMessage(tool_calls=[_FakeToolCall("emit_decision", {"value": "ok", "unexpected_extra": "x"})]))]))
    adapter = OpenAICompatibleAdapter(client=fake)
    with pytest.raises(LLMInvalidOutputError):
        adapter.complete(_REQUEST, _Echo)


class _MalformedToolCall:
    """Arguments is a raw, deliberately-invalid JSON string -- unlike
    `_FakeToolCall`, which always `json.dumps`'s a real dict."""

    def __init__(self, raw_arguments: str):
        self.function = _FakeFunction("emit_decision", raw_arguments)


def test_tool_call_arguments_not_valid_json_raises_invalid_output():
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion([_FakeChoice(_FakeMessage(tool_calls=[_MalformedToolCall("{not valid json")]))]))
    adapter = OpenAICompatibleAdapter(client=fake)
    with pytest.raises(LLMInvalidOutputError):
        adapter.complete(_REQUEST, _Echo)


# ============================================================================
# Tier 2: plain JSON-mode fallback (item G/AF/H -- deployment without tool
# calling support)
# ============================================================================


def test_json_prompt_mode_happy_path_never_uses_tool_calling():
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion([_FakeChoice(_FakeMessage(content='{"value": "hello"}'))], _FakeUsage(10, 4)))
    adapter = OpenAICompatibleAdapter(client=fake, use_tool_calling=False)

    completion = adapter.complete(_REQUEST, _Echo)

    assert completion.parsed_output == _Echo(value="hello")
    call = fake.chat.completions.calls[0]
    assert "tools" not in call
    assert "tool_choice" not in call
    assert output_schema_embedded_in_prompt(call, _Echo)


def output_schema_embedded_in_prompt(call: dict, model: type[RCABaseModel]) -> bool:
    system_message = call["messages"][0]["content"]
    return "value" in system_message  # the schema's own property name appears in the embedded JSON schema


def test_json_prompt_mode_strips_markdown_code_fence():
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion([_FakeChoice(_FakeMessage(content='```json\n{"value": "fenced"}\n```'))]))
    adapter = OpenAICompatibleAdapter(client=fake, use_tool_calling=False)
    completion = adapter.complete(_REQUEST, _Echo)
    assert completion.parsed_output == _Echo(value="fenced")


def test_json_prompt_mode_invalid_json_raises_invalid_output():
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion([_FakeChoice(_FakeMessage(content="not json at all"))]))
    adapter = OpenAICompatibleAdapter(client=fake, use_tool_calling=False)
    with pytest.raises(LLMInvalidOutputError):
        adapter.complete(_REQUEST, _Echo)


def test_json_prompt_mode_empty_content_raises_invalid_output():
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion([_FakeChoice(_FakeMessage(content=None))]))
    adapter = OpenAICompatibleAdapter(client=fake, use_tool_calling=False)
    with pytest.raises(LLMInvalidOutputError):
        adapter.complete(_REQUEST, _Echo)


def test_json_prompt_mode_schema_violation_raises_invalid_output():
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion([_FakeChoice(_FakeMessage(content='{"wrong_field": 1}'))]))
    adapter = OpenAICompatibleAdapter(client=fake, use_tool_calling=False)
    with pytest.raises(LLMInvalidOutputError):
        adapter.complete(_REQUEST, _Echo)


def test_json_prompt_mode_embeds_compact_schema_not_raw_pydantic_schema():
    """Phase PROD-1.1 (item 42/43): title/description stripped."""
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion([_FakeChoice(_FakeMessage(content='{"value": "hello"}'))]))
    adapter = OpenAICompatibleAdapter(client=fake, use_tool_calling=False)
    adapter.complete(_REQUEST, _Echo)
    system_message = fake.chat.completions.calls[0]["messages"][0]["content"]
    assert '"title"' not in system_message
    assert '"description"' not in system_message
    assert '"value"' in system_message  # the real property name still present


# ============================================================================
# Phase PROD-1.1 (item 55): finish_reason=length is a first-class,
# distinguishable signal -- reproduces the exact production log shape
# (prompt_tokens/completion_tokens present, finish_reason=length, no
# usable content -- the reasoning model's own reasoning_content, item 10,
# consumed the whole output budget).
# ============================================================================


def test_json_prompt_mode_finish_reason_length_raises_output_truncated_not_generic_invalid():
    from agent.llm.models import LLMOutputTruncatedError

    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion(
        [_FakeChoice(_FakeMessage(content=None), finish_reason="length")], _FakeUsage(1761, 200),
    ))
    adapter = OpenAICompatibleAdapter(client=fake, use_tool_calling=False)
    with pytest.raises(LLMOutputTruncatedError):
        adapter.complete(_REQUEST, _Echo)


def test_tool_calling_mode_finish_reason_length_raises_output_truncated_not_generic_invalid():
    from agent.llm.models import LLMOutputTruncatedError

    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion(
        [_FakeChoice(_FakeMessage(tool_calls=None), finish_reason="length")], _FakeUsage(5352, 200),
    ))
    adapter = OpenAICompatibleAdapter(client=fake)
    with pytest.raises(LLMOutputTruncatedError):
        adapter.complete(_REQUEST, _Echo)


def test_finish_reason_stop_with_no_content_still_raises_generic_invalid_output():
    """Not every empty-content case is a truncation -- only finish_reason=length is."""
    from agent.llm.models import LLMOutputTruncatedError

    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion(
        [_FakeChoice(_FakeMessage(content=None), finish_reason="stop")],
    ))
    adapter = OpenAICompatibleAdapter(client=fake, use_tool_calling=False)
    with pytest.raises(LLMInvalidOutputError) as exc_info:
        adapter.complete(_REQUEST, _Echo)
    assert not isinstance(exc_info.value, LLMOutputTruncatedError)


def test_llm_output_truncated_error_is_a_subclass_of_invalid_output_error():
    from agent.llm.models import LLMOutputTruncatedError

    assert issubclass(LLMOutputTruncatedError, LLMInvalidOutputError)


# ============================================================================
# Provider exception mapping -- real openai SDK exception instances, no
# network needed
# ============================================================================


def test_api_timeout_error_maps_to_llm_timeout_error():
    def raise_timeout(kwargs):
        raise openai.APITimeoutError(request=_http_request())

    adapter = OpenAICompatibleAdapter(client=_FakeOpenAIClient(raise_timeout))
    with pytest.raises(LLMTimeoutError):
        adapter.complete(_REQUEST, _Echo)


def test_authentication_error_maps_to_llm_provider_error_without_leaking_credential():
    def raise_auth(kwargs):
        response = httpx.Response(status_code=401, request=_http_request())
        raise openai.AuthenticationError("invalid api key sk-secret-value-should-never-appear", response=response, body=None)

    adapter = OpenAICompatibleAdapter(client=_FakeOpenAIClient(raise_auth))
    with pytest.raises(LLMProviderError) as exc_info:
        adapter.complete(_REQUEST, _Echo)
    assert "sk-secret-value-should-never-appear" not in str(exc_info.value)


def test_server_error_maps_to_llm_provider_error():
    def raise_server_error(kwargs):
        response = httpx.Response(status_code=500, request=_http_request())
        raise openai.APIStatusError("internal server error", response=response, body=None)

    adapter = OpenAICompatibleAdapter(client=_FakeOpenAIClient(raise_server_error))
    with pytest.raises(LLMProviderError):
        adapter.complete(_REQUEST, _Echo)


def test_unrecognized_exception_still_maps_to_llm_provider_error_never_leaks():
    def raise_unexpected(kwargs):
        raise RuntimeError("some completely unrelated bug")

    adapter = OpenAICompatibleAdapter(client=_FakeOpenAIClient(raise_unexpected))
    with pytest.raises(LLMProviderError):
        adapter.complete(_REQUEST, _Echo)


# ============================================================================
# base_url wiring -- item C/D/E: one class serves both provider modes
# ============================================================================


def test_base_url_is_passed_through_to_the_real_sdk_client(monkeypatch):
    """Confirms the adapter constructs `openai.OpenAI(base_url=...)` when
    NOT injecting a fake client -- the one mechanism that differentiates
    OpenAI Cloud (base_url=None, SDK default) from an internal
    OpenAI-compatible endpoint (a real base_url)."""
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test-key-never-a-real-secret")
    adapter = OpenAICompatibleAdapter(base_url="http://10.11.33.5:9120/v1/")
    assert str(adapter._client.base_url) == "http://10.11.33.5:9120/v1/"


def test_no_base_url_uses_sdk_own_default(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test-key-never-a-real-secret")
    adapter = OpenAICompatibleAdapter()
    assert "api.openai.com" in str(adapter._client.base_url)
