"""Phase WB-3B item 70: unit tests for the shared deterministic historical-
analysis computation layer (`agent/domain/wb/historical.py`). Every WB
trend Tool computes through `compute_historical_metrics` -- these tests
pin down its exact arithmetic/semantics directly, independent of any
Tool/Skill/Policy wiring. All offline, pure functions, no fixtures beyond
plain dicts.
"""
from datetime import date, timedelta

from agent.domain.wb.historical import (
    BANK_SHORTAGE_ABNORMAL_MIN,
    FLAT_BAND_PERCENT,
    OEE_ABNORMAL_MAX,
    SELF_BASELINE_LOW_RATIO,
    WIP_HOLD_ABNORMAL_MIN,
    WBTrendDirection,
    bank_shortage_ratio_is_abnormal,
    below_self_baseline_is_abnormal,
    compute_historical_metrics,
    oee_is_abnormal,
    wip_hold_ratio_is_abnormal,
)

_CURRENT = date(2026, 8, 12)
_WINDOW_START = _CURRENT - timedelta(days=6)  # 7-day window: 08-06..08-12


def _never_abnormal(_value: float, _baseline: float | None) -> bool:
    return False


def _always_abnormal(_value: float, _baseline: float | None) -> bool:
    return True


# ============================================================================
# Baseline exclusion (item 5) -- current_date is NEVER part of the baseline
# average, even when it is a wildly different value.
# ============================================================================


def test_baseline_excludes_current_date_worked_example():
    """Item 5's own worked example: current=2026-08-12, 7-day baseline is
    2026-08-05..08-11 (NOT including 08-12)."""
    daily_values = {_WINDOW_START + timedelta(days=i): 100.0 for i in range(6)}  # 08-06..08-11
    daily_values[_CURRENT] = 400.0  # today's value, wildly different

    metrics = compute_historical_metrics(daily_values, current_date=_CURRENT, window_start=_WINDOW_START, is_abnormal=_never_abnormal)

    assert metrics.current_value == 400.0
    assert metrics.baseline_value == 100.0  # NOT (100*6 + 400) / 7
    assert metrics.absolute_deviation == 300.0


def test_baseline_leakage_regression_current_value_must_not_shift_baseline():
    """Item 50's explicit regression: if current leaked into the baseline
    average, baseline would become ~914.3 instead of 1000; assert the
    correct, un-leaked value."""
    daily_values = {_WINDOW_START + timedelta(days=i): 1000.0 for i in range(6)}
    daily_values[_CURRENT] = 400.0

    metrics = compute_historical_metrics(daily_values, current_date=_CURRENT, window_start=_WINDOW_START, is_abnormal=_never_abnormal)

    assert metrics.baseline_value == 1000.0
    leaked_baseline = (1000.0 * 6 + 400.0) / 7
    assert metrics.baseline_value != leaked_baseline


# ============================================================================
# No-data semantics (item 5/18/48) -- absence must never be fabricated as
# zero/normal.
# ============================================================================


def test_completely_no_data_yields_none_and_insufficient_data_not_zero():
    metrics = compute_historical_metrics({}, current_date=_CURRENT, window_start=_WINDOW_START, is_abnormal=_never_abnormal)

    assert metrics.current_value is None
    assert metrics.baseline_value is None
    assert metrics.absolute_deviation is None
    assert metrics.relative_deviation is None
    assert metrics.trend_direction == WBTrendDirection.INSUFFICIENT_DATA
    assert metrics.observed_days == 0
    assert metrics.abnormal_days == 0
    assert metrics.recurrence_count == 0
    assert metrics.persistence_ratio is None  # never 0/0 == 0
    assert metrics.consecutive_abnormal_days == 0


def test_no_current_value_but_baseline_present_is_insufficient_data():
    daily_values = {_WINDOW_START + timedelta(days=i): 100.0 for i in range(6)}  # no entry for _CURRENT
    metrics = compute_historical_metrics(daily_values, current_date=_CURRENT, window_start=_WINDOW_START, is_abnormal=_never_abnormal)

    assert metrics.current_value is None
    assert metrics.baseline_value == 100.0
    assert metrics.trend_direction == WBTrendDirection.INSUFFICIENT_DATA
    assert metrics.relative_deviation is None


def test_current_value_present_but_no_baseline_days_is_insufficient_data():
    daily_values = {_CURRENT: 400.0}  # only today, nothing in the baseline range
    metrics = compute_historical_metrics(daily_values, current_date=_CURRENT, window_start=_WINDOW_START, is_abnormal=_never_abnormal)

    assert metrics.current_value == 400.0
    assert metrics.baseline_value is None
    assert metrics.trend_direction == WBTrendDirection.INSUFFICIENT_DATA
    assert metrics.observed_days == 1


def test_observed_days_reflects_only_real_data_days_not_window_length():
    """Item 18: a 7-day window with only 5 real data days -> observed_days
    is 5, never the window's calendar length of 7; a missing day must
    never silently count as "normal"."""
    dates_with_data = [_WINDOW_START + timedelta(days=i) for i in (0, 1, 3, 4, 6)]  # 5 of the 7 days, gaps at +2/+5
    daily_values = {d: 500.0 for d in dates_with_data}
    daily_values[_CURRENT] = 500.0  # +6 is _CURRENT itself, already included above

    metrics = compute_historical_metrics(daily_values, current_date=_CURRENT, window_start=_WINDOW_START, is_abnormal=_never_abnormal)

    assert metrics.observed_days == 5
    assert metrics.observed_days != 7


def test_zero_baseline_yields_none_relative_deviation_never_divides_by_zero():
    daily_values = {_WINDOW_START + timedelta(days=i): 0.0 for i in range(6)}
    daily_values[_CURRENT] = 10.0
    metrics = compute_historical_metrics(daily_values, current_date=_CURRENT, window_start=_WINDOW_START, is_abnormal=_never_abnormal)

    assert metrics.baseline_value == 0.0
    assert metrics.absolute_deviation == 10.0  # absolute deviation still computable
    assert metrics.relative_deviation is None  # but relative must not divide by zero
    assert metrics.trend_direction == WBTrendDirection.INSUFFICIENT_DATA


# ============================================================================
# Recurrence / persistence / consecutive (item 5/17/18)
# ============================================================================


def test_recurrence_count_comes_from_data_not_objective_history():
    """Item 17's own worked example: abnormal on 4 of 7 days -> recurrence
    count is 4, entirely derived from `daily_values`/`is_abnormal`, with
    no notion of "objective retry count" anywhere in this function's
    signature -- the regression is structural (no such parameter exists)."""
    abnormal_dates = {_WINDOW_START, _WINDOW_START + timedelta(days=2), _WINDOW_START + timedelta(days=4), _CURRENT}
    daily_values = {_WINDOW_START + timedelta(days=i): 100.0 for i in range(7)}

    def is_abnormal_by_date(value, _baseline):
        return value == 999.0

    for d in abnormal_dates:
        daily_values[d] = 999.0

    metrics = compute_historical_metrics(daily_values, current_date=_CURRENT, window_start=_WINDOW_START, is_abnormal=is_abnormal_by_date)

    assert metrics.recurrence_count == 4
    assert metrics.abnormal_days == 4


def test_persistence_ratio_is_abnormal_days_over_observed_days():
    dates = [_WINDOW_START + timedelta(days=i) for i in range(7)]
    daily_values = {d: 100.0 for d in dates}
    # mark 2 of the 7 abnormal
    daily_values[dates[0]] = 999.0
    daily_values[dates[1]] = 999.0

    metrics = compute_historical_metrics(daily_values, current_date=_CURRENT, window_start=_WINDOW_START, is_abnormal=lambda v, b: v == 999.0)

    assert metrics.observed_days == 7
    assert metrics.abnormal_days == 2
    assert metrics.persistence_ratio == 2 / 7


def test_persistence_ratio_is_none_when_observed_days_is_zero():
    metrics = compute_historical_metrics({}, current_date=_CURRENT, window_start=_WINDOW_START, is_abnormal=_never_abnormal)
    assert metrics.observed_days == 0
    assert metrics.persistence_ratio is None


def test_consecutive_abnormal_days_counts_backward_from_current_and_stops_at_first_normal_day():
    dates = [_WINDOW_START + timedelta(days=i) for i in range(7)]  # 08-06..08-12, index 6 == _CURRENT
    daily_values = {d: 100.0 for d in dates}
    # 08-09, 08-10, 08-11, 08-12 (indices 3,4,5,6) abnormal; 08-06..08-08 normal
    for i in (3, 4, 5, 6):
        daily_values[dates[i]] = 999.0

    metrics = compute_historical_metrics(daily_values, current_date=_CURRENT, window_start=_WINDOW_START, is_abnormal=lambda v, b: v == 999.0)

    assert metrics.consecutive_abnormal_days == 4
    assert metrics.recurrence_count == 4  # same 4 days, but a semantically distinct concept


def test_consecutive_abnormal_days_stops_at_a_missing_day_not_just_a_normal_one():
    dates = [_WINDOW_START + timedelta(days=i) for i in range(7)]
    daily_values = {d: 999.0 for d in dates}
    del daily_values[dates[4]]  # 08-10 has no data at all -- a gap, two days before current

    metrics = compute_historical_metrics(daily_values, current_date=_CURRENT, window_start=_WINDOW_START, is_abnormal=lambda v, b: v == 999.0)

    # walking back from 08-12 (idx6): idx6 abnormal, idx5 abnormal, idx4 MISSING -> stop
    assert metrics.consecutive_abnormal_days == 2


def test_recurrence_and_consecutive_are_distinct_for_a_non_consecutive_recurring_pattern():
    """Item 17/30's own "recurring but non-consecutive" shape (mirrors the
    synthetic WIP Hold pattern this phase deliberately built): abnormal on
    alternating days should have a HIGH recurrence_count but a LOW/zero
    consecutive_abnormal_days if the day immediately before current is
    normal."""
    dates = [_WINDOW_START + timedelta(days=i) for i in range(7)]  # idx6 == current
    daily_values = {d: 100.0 for d in dates}
    for i in (0, 2, 4):  # alternating abnormal days, none adjacent to current
        daily_values[dates[i]] = 999.0

    metrics = compute_historical_metrics(daily_values, current_date=_CURRENT, window_start=_WINDOW_START, is_abnormal=lambda v, b: v == 999.0)

    assert metrics.recurrence_count == 3
    assert metrics.consecutive_abnormal_days == 0  # current_date itself (idx6) is normal


# ============================================================================
# Trend direction / FLAT band (pre-existing WB-3A threshold, now shared)
# ============================================================================


def test_trend_direction_flat_within_band():
    daily_values = {_WINDOW_START + timedelta(days=i): 100.0 for i in range(6)}
    daily_values[_CURRENT] = 100.0 * (1 + (FLAT_BAND_PERCENT / 100) / 2)  # well within the +/-5% band

    metrics = compute_historical_metrics(daily_values, current_date=_CURRENT, window_start=_WINDOW_START, is_abnormal=_never_abnormal)
    assert metrics.trend_direction == WBTrendDirection.FLAT


def test_trend_direction_down_beyond_band():
    daily_values = {_WINDOW_START + timedelta(days=i): 100.0 for i in range(6)}
    daily_values[_CURRENT] = 50.0  # -50%, well beyond the band

    metrics = compute_historical_metrics(daily_values, current_date=_CURRENT, window_start=_WINDOW_START, is_abnormal=_never_abnormal)
    assert metrics.trend_direction == WBTrendDirection.DOWN
    assert metrics.relative_deviation == -50.0


def test_trend_direction_up_beyond_band():
    daily_values = {_WINDOW_START + timedelta(days=i): 100.0 for i in range(6)}
    daily_values[_CURRENT] = 150.0  # +50%

    metrics = compute_historical_metrics(daily_values, current_date=_CURRENT, window_start=_WINDOW_START, is_abnormal=_never_abnormal)
    assert metrics.trend_direction == WBTrendDirection.UP


def test_window_start_and_window_end_are_reported_verbatim():
    daily_values = {_CURRENT: 1.0}
    metrics = compute_historical_metrics(daily_values, current_date=_CURRENT, window_start=_WINDOW_START, is_abnormal=_never_abnormal)
    assert metrics.window_start == _WINDOW_START
    assert metrics.window_end == _CURRENT


# ============================================================================
# Domain-specific abnormality predicates (item 6) -- direction differs per
# metric; never a universal "value < baseline" rule.
# ============================================================================


def test_oee_is_abnormal_low_is_bad():
    assert oee_is_abnormal(OEE_ABNORMAL_MAX - 0.1, None) is True
    assert oee_is_abnormal(OEE_ABNORMAL_MAX, None) is False  # boundary: not abnormal at exactly the threshold
    assert oee_is_abnormal(OEE_ABNORMAL_MAX + 10, None) is False


def test_wip_hold_ratio_is_abnormal_high_is_bad():
    assert wip_hold_ratio_is_abnormal(WIP_HOLD_ABNORMAL_MIN, None) is True  # boundary: abnormal AT the threshold (>=)
    assert wip_hold_ratio_is_abnormal(WIP_HOLD_ABNORMAL_MIN - 0.01, None) is False
    assert wip_hold_ratio_is_abnormal(0.9, None) is True


def test_bank_shortage_ratio_is_abnormal_high_is_bad():
    assert bank_shortage_ratio_is_abnormal(BANK_SHORTAGE_ABNORMAL_MIN, None) is True
    assert bank_shortage_ratio_is_abnormal(BANK_SHORTAGE_ABNORMAL_MIN - 0.01, None) is False


def test_below_self_baseline_is_abnormal_relative_to_its_own_baseline():
    baseline = 1000.0
    assert below_self_baseline_is_abnormal(baseline * SELF_BASELINE_LOW_RATIO - 1, baseline) is True
    assert below_self_baseline_is_abnormal(baseline * SELF_BASELINE_LOW_RATIO, baseline) is False  # boundary: not < threshold
    assert below_self_baseline_is_abnormal(baseline, baseline) is False


def test_below_self_baseline_is_abnormal_never_flags_when_baseline_is_none():
    """No baseline to compare against -> never treated as abnormal (item 5's
    own explicit "no data != abnormal" boundary, mirrored at the predicate
    level, not just at the aggregate-summary level)."""
    assert below_self_baseline_is_abnormal(0.0, None) is False
    assert below_self_baseline_is_abnormal(-100.0, None) is False


def test_different_metrics_would_disagree_on_the_same_raw_value():
    """Item 6's own core point: there is no universal "value < baseline"
    rule -- a high WIP Hold ratio is bad, but a high OEE is good, so the
    SAME numeric relationship (value below vs. above some threshold) means
    opposite things depending on which predicate is used."""
    baseline = None
    assert wip_hold_ratio_is_abnormal(0.8, baseline) is True  # Hold ratio 0.8 (0..1 scale): high, bad
    assert oee_is_abnormal(80.0, baseline) is False  # OEE 80.0 (0..100 scale): high, not bad
