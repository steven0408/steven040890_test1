"""Phase WB-2C item 36/M: Objective persistence lineage regression for a
REAL WB module run (via WBPlanningPolicy + the real Module ReAct
Subgraph), reusing the Phase WB-2B.2 `Objective -> ObjectiveRecord ->
RunPersistenceWriter -> InMemoryRunRepository -> historical query` path.
Not re-testing PostgreSQL mapping exhaustively (WB-2B.2 already does) --
just confirming the WB Module's own real output flows through it intact.
All offline.
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.learning.sink import InMemoryLearningCandidateSink
from agent.modules.wb.package import build_wb_module_package
from agent.persistence.audit_repository import build_default_audit_repository
from agent.persistence.human_feedback import InMemoryHumanFeedbackSink
from agent.persistence.learning_repository import LearningCandidateRepository
from agent.persistence.run_repository import InMemoryRunRepository
from agent.persistence.run_writer import RunPersistenceWriter
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import ModuleStatus, RunTerminationStatus, TaskType
from agent.state.models import Goal, GoalScope, ModuleState, ModuleTask
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry

from .conftest import make_agent_state


def _run_wb_module(task_type: TaskType, thread_id: str, statement: str) -> ModuleState:
    package = build_wb_module_package()
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    runtime = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)

    graph = build_module_react_subgraph(WBPlanningPolicy(), capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id="WB", module_type="WB", reason="WB relevant to this request.", goal_statement=statement, confidence=0.9, priority=0.9, task_type=task_type)
    initial = build_initial_module_state(task, package.budget, run_id=f"run-{thread_id}", task_type=task_type)
    result = app.invoke(initial, config={"configurable": {"thread_id": thread_id}})
    return ModuleState.model_validate(result)


def _writer():
    run_repo = InMemoryRunRepository()
    audit_repo = build_default_audit_repository()
    feedback_sink = InMemoryHumanFeedbackSink()
    learning_repo = LearningCandidateRepository(InMemoryLearningCandidateSink())
    return RunPersistenceWriter(run_repo, audit_repo, feedback_sink, learning_repo), run_repo


def test_wb_wip_hold_objective_persists_and_reloads_with_full_lineage():
    """Item 36's own required Case: reuses WB-2B.2's exact path, this time
    fed by a genuine WBPlanningPolicy-produced Objective, not a hand-built
    ObjectiveRecord."""
    module_state = _run_wb_module(TaskType.ANALYSIS, "lineage-wip-hold", "2026-08-12 ASE03 Hold狀況")
    assert module_state.status == ModuleStatus.COMPLETE

    writer, run_repo = _writer()
    state = make_agent_state(run_id="run-lineage-wip-hold").model_copy(update={
        "module_states": {"WB": module_state},
        "global_goal": Goal(goal_id="g1", raw_statement="ASE03 hold?", normalized_statement="ASE03 hold status", task_type=TaskType.ANALYSIS, scope=GoalScope()),
        "termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS,
    })
    writer.persist_run(state)

    reloaded_objectives = run_repo.list_objectives("run-lineage-wip-hold")
    assert len(reloaded_objectives) == 1
    record = reloaded_objectives[0]
    assert record.capability_key == "wb.wip.hold_analysis"
    assert record.action.value == "analyze"
    assert record.target_ref.ref_id == "ASE03"
    assert record.scope is not None
    assert record.scope.time.kind.value == "snapshot_date"
    assert record.scope.filters[0].dimension == "plant"
    assert record.scope.filters[0].value == "ASE03"

    reloaded_evidence = run_repo.list_evidence("run-lineage-wip-hold")
    assert len(reloaded_evidence) == 1
    assert reloaded_evidence[0].objective_id == record.objective_id  # lineage intact


def test_wb_oee_information_objective_persists_with_capability_key_and_scope():
    module_state = _run_wb_module(TaskType.INFORMATION, "lineage-oee-info", "2026-08-12 ASE01 OEE狀況")
    assert module_state.status == ModuleStatus.COMPLETE

    writer, run_repo = _writer()
    state = make_agent_state(run_id="run-lineage-oee-info").model_copy(update={
        "module_states": {"WB": module_state},
        "global_goal": Goal(goal_id="g1", raw_statement="ASE01 OEE?", normalized_statement="ASE01 OEE status", task_type=TaskType.INFORMATION, scope=GoalScope()),
        "termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS,
    })
    writer.persist_run(state)

    record = run_repo.list_objectives("run-lineage-oee-info")[0]
    assert record.capability_key == "wb.oee.plant_status"
    assert record.scope.time.kind.value == "production_date"
    assert record.scope.time.date.isoformat() == "2026-08-12"


def test_wb_missing_data_objective_still_persists_with_scope_intact():
    """Even the "no data" round (Case F) must persist its full scope --
    the historical record of WHAT was asked matters especially when the
    answer was "nothing found"."""
    module_state = _run_wb_module(TaskType.INFORMATION, "lineage-missing", "2026-08-12 ASE08 OEE")
    assert module_state.status == ModuleStatus.PARTIAL

    writer, run_repo = _writer()
    state = make_agent_state(run_id="run-lineage-missing").model_copy(update={
        "module_states": {"WB": module_state},
        "global_goal": Goal(goal_id="g1", raw_statement="ASE08 OEE?", normalized_statement="ASE08 OEE status", task_type=TaskType.INFORMATION, scope=GoalScope()),
        "termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS,
    })
    writer.persist_run(state)

    record = run_repo.list_objectives("run-lineage-missing")[0]
    assert record.capability_key == "wb.oee.plant_status"
    assert record.target_ref.ref_id == "ASE08"
    assert record.scope.time.date.isoformat() == "2026-08-12"


def test_postgres_mapping_round_trips_a_real_wb_produced_objective_record():
    """One targeted PostgreSQL-mapping check (offline, FakeConnection) --
    not re-running WB-2B.2's whole suite, just confirming a genuinely
    WBPlanningPolicy-produced record survives the same mapping path."""
    from agent.persistence.postgres import mapping as m

    module_state = _run_wb_module(TaskType.ANALYSIS, "lineage-pg", "2026-08-12 ASE03 Hold狀況")
    record = next(iter(module_state.objective_history.values()))

    row = m.objective_to_row("run-lineage-pg", "WB", record)
    restored = m.objective_from_row(row)

    assert restored == record
    assert restored.scope.filters[0].value == "ASE03"
