"""Phase WB-3D item 69/70: Tool-level exclusion behavior + WBPlanningPolicy
interpretation (validation -> structured Limitation) + parent-graph traces,
exercised through the real Module ReAct Subgraph. Controlled bad-data
fixtures only (item 59) -- the golden synthetic dataset itself is never
polluted; every scenario here injects a small, purpose-built custom
`WBDataSources` override for exactly one source. All offline.
"""
from datetime import datetime, timedelta

from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.domain.wb.datasource import InMemoryWBIssueDataSource, InMemoryWBPlantOEEDataSource, InMemoryWBStageOutputDataSource, InMemoryWBWIPDataSource
from agent.domain.wb.models import WBIssueRecord, WBPlantOEERecord, WBStageOutputRecord, WBWIPRecord, WBLotStatus
from agent.domain.wb.synthetic import GOLDEN_DATE, HISTORY_DECLINE_START, SCENARIO_A_PLANT, SCENARIO_B_PLANT, SCENARIO_D_PLANT, build_wb_issue_records, build_wb_plant_oee_records, build_wb_stage_output_records
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.modules.wb.package import build_wb_module_package
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import ModuleStatus, TaskType
from agent.state.models import ModuleState, ModuleTask
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry
from agent.tools.wb.registration import WBDataSources

from .conftest import make_wb_datasources

_WINDOW_START = HISTORY_DECLINE_START - timedelta(days=3)  # 7-day window ending on GOLDEN_DATE
_SYNC = datetime(2026, 8, 13, 8, 30)


def _run_wb(task_type: TaskType, thread_id: str, statement: str, *, datasources: WBDataSources | None = None) -> ModuleState:
    package = build_wb_module_package(datasources=datasources)
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    runtime = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)

    policy = WBPlanningPolicy()
    graph = build_module_react_subgraph(policy, capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id="WB", module_type="WB", reason=statement, goal_statement=statement, confidence=0.9, priority=0.9, task_type=task_type)
    initial = build_initial_module_state(task, package.budget, run_id=f"run-{thread_id}", task_type=task_type)
    result = app.invoke(initial, config={"configurable": {"thread_id": thread_id}})
    return ModuleState.model_validate(result)


def _issue_record(plant_id, release_date, quantity, sync=_SYNC) -> WBIssueRecord:
    return WBIssueRecord(
        source_sync_time=sync, plant_id=plant_id, site=None, schedule=None, customer_code=None, customer_name=None,
        device_type=None, issue_quantity=quantity, lead_count=None, package_code=None, package_type=None, region=None,
        release_date=release_date, release_date_raw=release_date.isoformat() if release_date else None, release_time=None,
        release_system=None, time_bucket=None, wafer_inch=None, year=None,
        bd_no_unknown=None, cu_flag_unknown=None, customer_run_type_unknown=None, customer_sod_unknown=None,
        internal_sod_unknown=None, routid_unknown=None, run_type_unknown=None, unit_of_measure_unknown=None,
        user_id_unknown=None, user_name_unknown=None,
    )


def _oee_record(plant_id, day, oee, operation="2800", sync=_SYNC) -> WBPlantOEERecord:
    return WBPlantOEERecord(production_date=day, plant_id=plant_id, operation_id=operation, oee=oee, productive_ratio=80.0, downtime_ratio=5.0, pm_ratio=2.0, setup_ratio=4.0, idle_ratio=3.0, engineering_ratio=None, ts_ratio=None, source_sync_time=sync)


def _output_record(plant_id, day, qty, operation="OP1", sync=_SYNC) -> WBStageOutputRecord:
    return WBStageOutputRecord(production_date=day, plant_id=plant_id, location=None, operation_id=operation, output_quantity=qty, customer_code=None, device_type=None, package_code=None, lead_count=None, bond_diagram=None, source_facility=None, source_sync_time=sync)


# ============================================================================
# Item 47: invalid symptom data -- no abnormality conclusion, no root
# cause, Limitation instead.
# ============================================================================


def test_invalid_oee_symptom_never_produces_a_high_or_low_finding():
    """OEE=180 must never surface as "OEE is high" or feed a downtime/
    abnormality conclusion -- it's excluded, and the Limitation says so."""
    base = make_wb_datasources()
    bad_records = list(build_wb_plant_oee_records())
    bad_records.append(_oee_record(SCENARIO_A_PLANT, GOLDEN_DATE, 180.0, operation="9999"))
    custom = WBDataSources(oee=InMemoryWBPlantOEEDataSource(bad_records), bank=base.bank, wip=base.wip, output=base.output, issue=base.issue)

    final_state = _run_wb(TaskType.RCA, "val-invalid-oee", "2026-08-12 ASE01 OEE 表現差 root cause", datasources=custom)
    assert final_state.status == ModuleStatus.COMPLETE
    assert "180" not in final_state.findings[-1].statement
    assert final_state.findings[-1].is_root_cause is False
    assert any("invalid_value_range" in lim.limitation_id for lim in final_state.limitations)


# ============================================================================
# Item 48: invalid supporting data -- doesn't poison the whole RCA chain.
# ============================================================================


def test_invalid_issue_data_does_not_poison_output_rca_chain():
    """Output symptom confirmed, historical cross-source chain reaches
    ISSUE trend which contains an invalid negative row -- Output Finding
    still exists; ISSUE contribution is limited but doesn't crash or
    corrupt the whole chain. ISSUE only enters this chain via the
    historical/cross-source path (item 45), so the goal statement must
    carry a historical keyword ("這週 trend") for ISSUE to be queried at all."""
    base = make_wb_datasources()
    bad_issue = list(build_wb_issue_records())
    bad_issue.append(_issue_record(SCENARIO_B_PLANT, GOLDEN_DATE, -9999))
    custom = WBDataSources(oee=base.oee, bank=base.bank, wip=base.wip, output=base.output, issue=InMemoryWBIssueDataSource(bad_issue))

    final_state = _run_wb(TaskType.RCA, "val-invalid-issue-rca", "2026-08-12 ASE07 output 偏低 這週 trend root cause", datasources=custom)
    assert final_state.status == ModuleStatus.COMPLETE
    assert final_state.findings  # a real Finding still exists
    assert any("negative_quantity" in lim.limitation_id for lim in final_state.limitations)
    assert "-9999" not in final_state.findings[-1].statement


# ============================================================================
# Item 42/43: historical invalid-day exclusion; recurrence denominator uses
# valid observed days only.
# ============================================================================


def test_historical_invalid_day_excluded_from_observed_days_and_baseline():
    """A 7-day OEE trend window with one invalid day (OEE=180) -- that day
    must not count as an observed day, must not enter the baseline, and
    must not be treated as normal OR abnormal."""
    base = make_wb_datasources()
    bad_records = list(build_wb_plant_oee_records())
    bad_records.append(_oee_record(SCENARIO_A_PLANT, GOLDEN_DATE - timedelta(days=2), 180.0, operation="9999"))
    custom = WBDataSources(oee=InMemoryWBPlantOEEDataSource(bad_records), bank=base.bank, wip=base.wip, output=base.output, issue=base.issue)

    final_state = _run_wb(TaskType.RCA, "val-hist-invalid-day", "2026-08-12 ASE01 OEE 表現差 這週 trend root cause", datasources=custom)
    assert final_state.status == ModuleStatus.COMPLETE
    assert any("invalid_value_range" in lim.limitation_id for lim in final_state.limitations)
    # the invalid-value Limitation and the trend Finding coexist -- the
    # invalid day doesn't silently vanish without a trace, nor does it
    # crash or corrupt the whole trend calculation.
    assert final_state.findings


# ============================================================================
# Item 44/45: cross-source invalid-day exclusion; partial overlap +
# invalid data coexist as two SEPARATE limitations.
# ============================================================================


def test_cross_source_invalid_issue_day_excluded_from_overlap():
    """A negative-quantity ISSUE day must never enter the cross-source
    join -- the overlap is computed from USABLE business dates only."""
    base = make_wb_datasources()
    bad_issue = list(build_wb_issue_records())
    bad_issue.append(_issue_record(SCENARIO_B_PLANT, GOLDEN_DATE - timedelta(days=1), -500))
    custom = WBDataSources(oee=base.oee, bank=base.bank, wip=base.wip, output=base.output, issue=InMemoryWBIssueDataSource(bad_issue))

    final_state = _run_wb(TaskType.RCA, "val-crosssource-invalid", "2026-08-12 ASE07 output 偏低 這週 trend root cause", datasources=custom)
    assert final_state.status == ModuleStatus.COMPLETE
    assert any("negative_quantity" in lim.limitation_id for lim in final_state.limitations)
    relationship_finding = final_state.findings[-1]
    assert "-500" not in relationship_finding.statement
    assert relationship_finding.is_root_cause is False


def test_partial_overlap_and_invalid_data_coexist_as_separate_limitations():
    """Both a PARTIAL_SOURCE_OVERLAP-style limitation (from restricted
    OUTPUT coverage) AND a validation-derived limitation (from an invalid
    ISSUE row) can exist at once -- neither suppresses the other."""
    base = make_wb_datasources()
    bad_issue = list(build_wb_issue_records())
    bad_issue.append(_issue_record(SCENARIO_B_PLANT, GOLDEN_DATE - timedelta(days=1), -500))
    restricted_output = [
        r for r in build_wb_stage_output_records()
        if not (r.plant_id == SCENARIO_B_PLANT and r.production_date < GOLDEN_DATE - timedelta(days=3))
    ]
    custom = WBDataSources(oee=base.oee, bank=base.bank, wip=base.wip, output=InMemoryWBStageOutputDataSource(restricted_output), issue=InMemoryWBIssueDataSource(bad_issue))

    final_state = _run_wb(TaskType.RCA, "val-partial-and-invalid", "2026-08-12 ASE07 output 偏低 這週 trend root cause", datasources=custom)
    assert final_state.status == ModuleStatus.COMPLETE
    limitation_ids = [lim.limitation_id for lim in final_state.limitations]
    assert any("partial_overlap" in lid for lid in limitation_ids)
    assert any("negative_quantity" in lid for lid in limitation_ids)
    assert len(final_state.limitations) >= 2


# ============================================================================
# Item 52/29: false premise on genuinely valid data -- zero validation
# issues, zero limitations.
# ============================================================================


def test_wrong_premise_on_valid_data_produces_no_validation_limitation():
    final_state = _run_wb(TaskType.RCA, "val-wrong-premise", "2026-08-12 ASE02 OEE 異常 root cause")
    assert final_state.status == ModuleStatus.COMPLETE
    assert final_state.limitations == []
    assert "No abnormal" in final_state.findings[-1].statement


# ============================================================================
# Item 30/51: COMPLETE + quality Limitation is allowed; not automatically
# PARTIAL.
# ============================================================================


def test_complete_status_with_quality_limitation_when_core_answer_still_valid():
    base = make_wb_datasources()
    bad_records = list(build_wb_plant_oee_records())
    bad_records.append(_oee_record(SCENARIO_A_PLANT, GOLDEN_DATE, 180.0, operation="9999"))
    custom = WBDataSources(oee=InMemoryWBPlantOEEDataSource(bad_records), bank=base.bank, wip=base.wip, output=base.output, issue=base.issue)

    final_state = _run_wb(TaskType.RCA, "val-complete-with-limitation", "2026-08-12 ASE01 OEE 表現差 root cause", datasources=custom)
    assert final_state.status == ModuleStatus.COMPLETE
    assert final_state.limitations  # a quality limitation exists but didn't force PARTIAL


# ============================================================================
# Item 26/34/54: Synthesis propagation + no root-cause inflation from
# invalid data.
# ============================================================================


def test_synthesis_markdown_shows_validation_derived_limitation():
    from agent.llm.context.synthesis_context import SynthesisContextBuilder
    from agent.state.models import Goal, GoalScope
    from agent.synthesis.handoff_builder import ModuleHandoffBuilder
    from agent.synthesis.package import build_handoff_package
    from .conftest import make_agent_state

    base = make_wb_datasources()
    bad_records = list(build_wb_plant_oee_records())
    bad_records.append(_oee_record(SCENARIO_A_PLANT, GOLDEN_DATE, 180.0, operation="9999"))
    custom = WBDataSources(oee=InMemoryWBPlantOEEDataSource(bad_records), bank=base.bank, wip=base.wip, output=base.output, issue=base.issue)
    module_state = _run_wb(TaskType.RCA, "val-synth-md", "2026-08-12 ASE01 OEE 表現差 root cause", datasources=custom)

    state = make_agent_state(run_id="run-val-synth-md").model_copy(update={
        "module_states": {"WB": module_state},
        "global_goal": Goal(goal_id="g1", raw_statement="q", normalized_statement="q", task_type=TaskType.RCA, scope=GoalScope()),
    })
    outcome = SynthesisContextBuilder(ModuleHandoffBuilder()).build(state)
    package = build_handoff_package(outcome.context)

    assert "## Limitations / Missing Information" in package.markdown
    assert "outside the expected" in package.markdown
    for rc in package.root_causes:
        assert "180" not in rc.statement


# ============================================================================
# Item 35/55: Evaluator + Persistence smoke.
# ============================================================================


def test_evaluator_does_not_crash_on_a_quality_limitation_bearing_run():
    from agent.evaluation.evaluator import RunEvaluator
    from agent.state.enums import RunTerminationStatus
    from agent.state.models import Goal, GoalScope
    from .conftest import make_agent_state

    base = make_wb_datasources()
    bad_records = list(build_wb_plant_oee_records())
    bad_records.append(_oee_record(SCENARIO_A_PLANT, GOLDEN_DATE, 180.0, operation="9999"))
    custom = WBDataSources(oee=InMemoryWBPlantOEEDataSource(bad_records), bank=base.bank, wip=base.wip, output=base.output, issue=base.issue)
    module_state = _run_wb(TaskType.RCA, "val-eval", "2026-08-12 ASE01 OEE 表現差 root cause", datasources=custom)

    final_state = make_agent_state(run_id="run-val-eval").model_copy(update={
        "module_states": {"WB": module_state},
        "global_goal": Goal(goal_id="g1", raw_statement="q", normalized_statement="q", task_type=TaskType.RCA, scope=GoalScope()),
        "termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS,
    })
    report = RunEvaluator().evaluate(final_state)
    assert report is not None


def test_persistence_smoke_for_a_quality_limitation_bearing_run():
    from agent.learning.sink import InMemoryLearningCandidateSink
    from agent.persistence.audit_repository import build_default_audit_repository
    from agent.persistence.human_feedback import InMemoryHumanFeedbackSink
    from agent.persistence.learning_repository import LearningCandidateRepository
    from agent.persistence.run_repository import InMemoryRunRepository
    from agent.persistence.run_writer import RunPersistenceWriter
    from agent.state.enums import RunTerminationStatus
    from agent.state.models import Goal, GoalScope
    from .conftest import make_agent_state

    base = make_wb_datasources()
    bad_records = list(build_wb_plant_oee_records())
    bad_records.append(_oee_record(SCENARIO_A_PLANT, GOLDEN_DATE, 180.0, operation="9999"))
    custom = WBDataSources(oee=InMemoryWBPlantOEEDataSource(bad_records), bank=base.bank, wip=base.wip, output=base.output, issue=base.issue)
    module_state = _run_wb(TaskType.RCA, "val-persist", "2026-08-12 ASE01 OEE 表現差 root cause", datasources=custom)
    assert len(module_state.limitations) == 1

    run_repo = InMemoryRunRepository()
    writer = RunPersistenceWriter(run_repo, build_default_audit_repository(), InMemoryHumanFeedbackSink(), LearningCandidateRepository(InMemoryLearningCandidateSink()))
    state = make_agent_state(run_id="run-val-persist").model_copy(update={
        "module_states": {"WB": module_state},
        "global_goal": Goal(goal_id="g1", raw_statement="q", normalized_statement="q", task_type=TaskType.RCA, scope=GoalScope()),
        "termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS,
    })
    writer.persist_run(state)
    module_runs = run_repo.get_module_results("run-val-persist")
    wb_run = next(r for r in module_runs if r.module_id == "WB")
    assert wb_run.limitation_count == 1


# ============================================================================
# Item 60/61: Parent graph invalid-OEE trace.
# ============================================================================


def test_parent_graph_invalid_oee_trace_reaches_ready_for_synthesis_without_fabrication():
    from agent.graph.graph import build_phase2_graph
    from agent.graph.nodes.analyzer_llm import AnalyzerLLMService, make_analyzer_llm_node
    from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
    from agent.llm.client import MockLLMClient
    from agent.llm.config import LLMRouteConfig
    from agent.llm.context.analyzer_context import AnalyzerContextBuilder
    from agent.llm.prompts.analyzer import AnalyzerDecision, ModuleSelection
    from agent.llm.router import LLMRouter
    from agent.llm.usage import InMemoryLLMUsageSink
    from agent.state.enums import RunTerminationStatus
    from agent.state.state import AgentState
    from .conftest import make_agent_state, make_module_registry

    base = make_wb_datasources()
    bad_records = list(build_wb_plant_oee_records())
    bad_records.append(_oee_record(SCENARIO_A_PLANT, GOLDEN_DATE, 180.0, operation="9999"))
    custom = WBDataSources(oee=InMemoryWBPlantOEEDataSource(bad_records), bank=base.bank, wip=base.wip, output=base.output, issue=base.issue)

    package = build_wb_module_package(datasources=custom)
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)
    resolver = CapabilityResolver(skill_registry, tool_registry)
    runtime_config = ModuleRuntimeConfig(
        policy=WBPlanningPolicy(),
        capability=ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=SkillRunner(tool_registry, ToolExecutionManager())),
        budget=package.budget,
    )

    def responder(request):
        return AnalyzerDecision(
            task_type=TaskType.RCA,
            selected_modules=[ModuleSelection(module_type="WB", priority=0.9, confidence=0.9, rationale="WB owns OEE data.", goal_statement="2026-08-12 ASE01 OEE 表現差 root cause")],
            reasoning_summary="Mock decision.", confidence=0.9,
        )

    registry = make_module_registry()
    registry.register(package.module_definition)
    router = LLMRouter(routes={"analyzer": LLMRouteConfig(route="analyzer", model="mock-analyzer")}, client=MockLLMClient(responder), usage_sink=InMemoryLLMUsageSink())
    analyzer_node = make_analyzer_llm_node(AnalyzerLLMService(registry, AnalyzerContextBuilder(registry), router))

    runtime = {"WB": runtime_config}
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(runtime, checkpointer, analyzer=analyzer_node)
    app = graph.compile(checkpointer=checkpointer)

    initial_state = make_agent_state(run_id="wb-invalid-oee-parent", raw_text="Why was ASE01 OEE abnormal on 2026-08-12?")
    initial_state = initial_state.model_copy(update={"factory_context": initial_state.factory_context.model_copy(update={"enabled_modules": ["WB"]})})
    result = app.invoke(initial_state, config={"configurable": {"thread_id": "wb-invalid-oee-parent"}})
    final_state = AgentState.model_validate(result)

    wb = final_state.module_states["WB"]
    assert wb.status == ModuleStatus.COMPLETE
    assert "180" not in wb.findings[-1].statement
    assert wb.findings[-1].is_root_cause is False
    assert any("invalid_value_range" in lim.limitation_id for lim in wb.limitations)
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


# ============================================================================
# Item 13/14/49: potential truncation (WIP-only -- the only WB DataSource
# with a `limit` parameter) -- warning, never certainty; evidence stays
# usable.
# ============================================================================


class _LimitHittingWIPDataSource:
    """Returns exactly `limit` records regardless of what's asked --
    simulates a WIP fetch that hit its own configured `_FETCH_LIMIT`
    (50_000). Reuses ONE real record reference repeated, so this stays
    cheap to construct (no need to build 50,000 distinct Pydantic objects)."""

    def __init__(self, template: WBWIPRecord):
        self._template = template

    def list_wip(self, *, snapshot_date=None, limit=5000):
        return [self._template] * limit

    def freshness(self):
        from agent.domain.wb.models import WB_WIP_FRESHNESS
        return WB_WIP_FRESHNESS


def test_potential_truncation_warning_when_wip_fetch_hits_the_limit():
    template = WBWIPRecord(plant_id=SCENARIO_D_PLANT, facility_source=None, mother_batch_id="M1", child_batch_id="C1", operation_id="OP1", current_quantity=10, customer_code=None, package_code=None, lead_count=None, run_type=None, lot_status=WBLotStatus.ACTIVE, lot_status_raw="Active", source_sync_time=_SYNC)
    base = make_wb_datasources()
    custom = WBDataSources(oee=base.oee, bank=base.bank, wip=_LimitHittingWIPDataSource(template), output=base.output, issue=base.issue)

    final_state = _run_wb(TaskType.RCA, "val-truncation", "2026-08-12 ASE02 WIP hold 異常 root cause", datasources=custom)
    assert any("potential_truncation" in lim.limitation_id for lim in final_state.limitations)
    # WARNING severity -- evidence stays usable, a real Finding still exists
    assert final_state.findings


def test_no_truncation_warning_when_wip_count_stays_below_limit():
    final_state = _run_wb(TaskType.RCA, "val-no-truncation", "2026-08-12 ASE03 WIP hold 異常 root cause")
    assert not any("potential_truncation" in lim.limitation_id for lim in final_state.limitations)


# ============================================================================
# Item 27/35/36: validation-derived Limitation dedup -- deterministic id,
# never a free-text hash, never duplicated across a checkpoint replay.
# ============================================================================


def test_validation_derived_limitation_dedup_on_repeated_derivation():
    base = make_wb_datasources()
    bad_records = list(build_wb_plant_oee_records())
    bad_records.append(_oee_record(SCENARIO_A_PLANT, GOLDEN_DATE, 180.0, operation="9999"))
    custom = WBDataSources(oee=InMemoryWBPlantOEEDataSource(bad_records), bank=base.bank, wip=base.wip, output=base.output, issue=base.issue)
    final_state = _run_wb(TaskType.RCA, "val-dedup", "2026-08-12 ASE01 OEE 表現差 root cause", datasources=custom)
    assert len(final_state.limitations) == 1

    policy = WBPlanningPolicy()
    updates = policy.derive_state_updates(final_state)
    assert updates.limitations == []  # re-deriving against the already-updated state produces nothing new
