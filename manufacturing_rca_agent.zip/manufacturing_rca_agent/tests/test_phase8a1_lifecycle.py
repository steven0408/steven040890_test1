"""Phase 8A-1: Runtime Lifecycle Instrumentation.

Closes the two honest gaps Phase 8A itself reported (see docs/persistence.md
section 4, pre-8A-1 version): `ModuleState` had no module-level
`started_at`/`completed_at`, and `AgentState` had no run-level
`completed_at` (only `UserRequest.submitted_at` as a weak `started_at`
proxy). No new LangGraph nodes, no change to routing/decision semantics --
only lifecycle telemetry stamped by existing nodes
(standardizer_mock/global_completion_check/module_subgraph_node/
module_completion_check).

Design actually shipped (see module_subgraph_node.py's own docstring for
the rejected alternative): both timestamps are stamped fresh on every
*physical* invocation of the owning node, with no read-before-write
preservation attempt. This is provably stable for every case that matters:

  - A sibling module untouched by an interrupt: its wrapper simply never
    runs again (tests/test_resume_replay_semantics.py), so nothing
    re-stamps its timestamps.
  - The module that owns a pending interrupt: its wrapper genuinely runs
    again on resume, but LangGraph's own resume machinery continues the
    child subgraph from its checkpoint rather than from the freshly-passed
    `initial_state` -- so the reassignment is computed but never lands (see
    `test_sibling_and_interrupted_module_timestamps_stable_across_normal_resume`
    below, which proves this empirically via the raw child checkpoint).
  - Only the pathological case Phase 5B-1.1 already documented -- an
    explicit `app.update_state()` call on a checkpoint with a still-pending
    Send task -- causes a full re-stamp, with the exact same "legitimately
    differs" status `ToolCallRecord` timestamps already have there (see
    test_phase4b2_human_gate.py's `_drop_tool_call_timestamps`).
"""
from datetime import datetime, timedelta, timezone

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command

from agent.evaluation.efficiency_metrics import compute_efficiency_metrics
from agent.graph.graph import build_phase2_graph
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module_dispatch_payload import ModuleDispatchPayload
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig, make_module_subgraph_node
from agent.learning.sink import InMemoryLearningCandidateSink
from agent.persistence.audit_repository import build_default_audit_repository
from agent.persistence.human_feedback import InMemoryHumanFeedbackSink
from agent.persistence.learning_repository import LearningCandidateRepository
from agent.persistence.run_repository import InMemoryRunRepository
from agent.persistence.run_writer import RunPersistenceWriter
from agent.planning.policies.mock import DeterministicMockPolicy, PermissionSpec, Requirement
from agent.state.enums import ErrorType, EvidenceQuality, HumanDecision, ModuleStatus, ObservationStatus, RiskLevel, RunTerminationStatus
from agent.state.lifecycle import module_duration_ms, run_duration_ms
from agent.state.models import ModuleState, ModuleTask
from agent.state.state import AgentState
from agent.tools.base import ToolResult
from agent.tools.mocks.scripted_tool import ScriptedMockTool

from .conftest import make_agent_state, make_budget, make_module_state


# ============================================================================
# 1. Duration projection helpers -- pure, derived-never-stored
# ============================================================================


def test_run_duration_ms_none_while_run_in_flight():
    state = make_agent_state()
    assert state.started_at is None and state.completed_at is None
    assert run_duration_ms(state) is None

    started = state.model_copy(update={"started_at": datetime(2026, 8, 9, 0, 0, 0, tzinfo=timezone.utc)})
    assert run_duration_ms(started) is None  # completed_at still missing


def test_run_duration_ms_computed_once_both_timestamps_present():
    start = datetime(2026, 8, 9, 0, 0, 0, tzinfo=timezone.utc)
    end = start + timedelta(milliseconds=1500)
    state = make_agent_state().model_copy(update={"started_at": start, "completed_at": end})
    assert run_duration_ms(state) == 1500.0


def test_module_duration_ms_none_for_skipped_module():
    # Option A semantics (ModuleState.completed_at docstring): SKIPPED means
    # never actually started -- started_at stays None even though
    # completed_at (the skip-decision time) is set.
    skipped = make_module_state().model_copy(
        update={"status": ModuleStatus.SKIPPED, "started_at": None, "completed_at": datetime.now(timezone.utc)}
    )
    assert module_duration_ms(skipped) is None


def test_module_duration_ms_computed_once_both_timestamps_present():
    start = datetime(2026, 8, 9, 0, 0, 0, tzinfo=timezone.utc)
    end = start + timedelta(milliseconds=250)
    state = make_module_state().model_copy(update={"started_at": start, "completed_at": end})
    assert module_duration_ms(state) == 250.0


# ============================================================================
# 2. Normal run trace -- Run + Module lifecycle, ordering invariant
# ============================================================================


def _all_normal_runtime() -> dict[str, ModuleRuntimeConfig]:
    def _one(source: str) -> ModuleRuntimeConfig:
        return ModuleRuntimeConfig(
            policy=DeterministicMockPolicy(sources=[source], sufficiency_evidence_count=1),
            tool=ScriptedMockTool({source: ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}),
            budget=make_budget(max_steps=3, max_tool_calls=3, max_depth_per_entity=2),
        )

    return {"OEE": _one("oee-primary"), "Output": _one("output-primary"), "WIP": _one("wip-primary")}


def _run_to_completion(raw_text: str = "為什麼今天 Output 不足？") -> AgentState:
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(_all_normal_runtime(), checkpointer)
    app = graph.compile(checkpointer=checkpointer)
    initial_state = make_agent_state(raw_text=raw_text)
    config = {"configurable": {"thread_id": initial_state.run_id}}
    result = app.invoke(initial_state, config=config)
    return AgentState.model_validate(result)


def test_normal_rca_run_stamps_run_and_module_lifecycle_timestamps():
    final_state = _run_to_completion()  # default raw_text triggers RCA (為什麼/why)

    assert final_state.started_at is not None
    assert final_state.completed_at is not None
    assert final_state.completed_at >= final_state.started_at
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS

    assert len(final_state.module_states) == 3
    for module_state in final_state.module_states.values():
        assert module_state.status == ModuleStatus.COMPLETE
        assert module_state.started_at is not None
        assert module_state.completed_at is not None
        assert module_state.completed_at >= module_state.started_at
        # every module's lifecycle window falls within the run's own
        assert module_state.started_at >= final_state.started_at


def test_information_task_run_stamps_lifecycle_timestamps_too():
    # "what is" triggers TaskType.INFORMATION in the deterministic inferer
    # (agent/planning/task_type_inference.py) -- lifecycle stamping doesn't
    # depend on which TaskType Standardizer/Analyzer inferred.
    final_state = _run_to_completion(raw_text="what is the current output status?")

    assert final_state.started_at is not None
    assert final_state.completed_at is not None
    assert final_state.completed_at >= final_state.started_at
    for module_state in final_state.module_states.values():
        assert module_state.started_at is not None
        assert module_state.completed_at is not None


def test_efficiency_metrics_total_duration_ms_populated_from_run_timestamps():
    final_state = _run_to_completion()
    bundle_modules = list(final_state.module_states.values())
    from .conftest import make_run_audit_bundle_from_modules

    bundle = make_run_audit_bundle_from_modules(bundle_modules)
    metrics = compute_efficiency_metrics(final_state, bundle)
    assert metrics.total_duration_ms is not None
    assert metrics.total_duration_ms >= 0


# ============================================================================
# 3. Module status timestamps: PARTIAL / FAILED / BLOCKED
# ============================================================================


def _mixed_runtime(oee_policy, oee_tool, oee_budget=None) -> dict[str, ModuleRuntimeConfig]:
    runtime = _all_normal_runtime()
    runtime["OEE"] = ModuleRuntimeConfig(policy=oee_policy, tool=oee_tool, budget=oee_budget or make_budget(max_steps=4, max_tool_calls=4, max_depth_per_entity=2))
    return runtime


def test_partial_module_gets_completed_at_stamped():
    policy = DeterministicMockPolicy(
        requirements=[
            Requirement(sources=["availability"], sufficiency_evidence_count=1),
            Requirement(sources=["maintenance-primary"], sufficiency_evidence_count=1),
        ]
    )
    tool = ScriptedMockTool(
        {
            "availability": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG),
            "maintenance-primary": ToolResult(status=ObservationStatus.ERROR, error_type=ErrorType.DATA_NOT_FOUND, error_message="no rows"),
        }
    )
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(_mixed_runtime(policy, tool), checkpointer)
    app = graph.compile(checkpointer=checkpointer)
    initial_state = make_agent_state()
    config = {"configurable": {"thread_id": initial_state.run_id}}
    result = app.invoke(initial_state, config=config)
    final_state = AgentState.model_validate(result)

    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.PARTIAL
    assert oee.started_at is not None and oee.completed_at is not None
    assert oee.completed_at >= oee.started_at


def test_failed_module_gets_completed_at_stamped():
    policy = DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1)
    tool = ScriptedMockTool({"primary": ToolResult(status=ObservationStatus.ERROR, error_type=ErrorType.DATA_NOT_FOUND, error_message="no rows")})
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(_mixed_runtime(policy, tool), checkpointer)
    app = graph.compile(checkpointer=checkpointer)
    initial_state = make_agent_state()
    config = {"configurable": {"thread_id": initial_state.run_id}}
    result = app.invoke(initial_state, config=config)
    final_state = AgentState.model_validate(result)

    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.FAILED
    assert oee.started_at is not None and oee.completed_at is not None
    assert oee.completed_at >= oee.started_at


def _blocked_runtime() -> dict[str, ModuleRuntimeConfig]:
    return _mixed_runtime(
        DeterministicMockPolicy(
            requirements=[
                Requirement(
                    sources=["restricted-only"],
                    sufficiency_evidence_count=1,
                    restricted_sources={"restricted-only": PermissionSpec(permission_type="maintenance_db_access", risk_level=RiskLevel.HIGH)},
                )
            ]
        ),
        ScriptedMockTool({"restricted-only": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="should never run", quality=EvidenceQuality.STRONG)}),
    )


def test_blocked_module_gets_completed_at_stamped():
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(_blocked_runtime(), checkpointer)
    app = graph.compile(checkpointer=checkpointer)
    initial_state = make_agent_state()
    config = {"configurable": {"thread_id": initial_state.run_id}}
    app.invoke(initial_state, config=config)
    result2 = app.invoke(Command(resume={"decision": HumanDecision.REJECT.value, "responded_by": "tester"}), config=config)
    final_state = AgentState.model_validate(result2)

    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.BLOCKED
    assert oee.started_at is not None and oee.completed_at is not None
    assert oee.completed_at >= oee.started_at


def test_skipped_module_semantics_hand_constructed():
    """No node in this codebase currently produces ModuleStatus.SKIPPED
    (confirmed in Phase 6A and unchanged since) -- this is a documented,
    tested shape for the future, not a real code path. Option A: SKIPPED
    means never actually started."""
    skip_time = datetime.now(timezone.utc)
    skipped = make_module_state().model_copy(update={"status": ModuleStatus.SKIPPED, "started_at": None, "completed_at": skip_time})
    assert skipped.started_at is None
    assert skipped.completed_at == skip_time
    assert module_duration_ms(skipped) is None


# ============================================================================
# 4. Interrupt/resume + process-style resume stability (no update_state())
# ============================================================================


def test_sibling_and_interrupted_module_timestamps_stable_across_normal_resume():
    """Mirrors test_phase4b2_human_gate.py's Case A, but this test's own
    focus is lifecycle timestamps, and it deliberately does NOT call
    `app.update_state()` between interrupt and resume -- so, per
    test_resume_replay_semantics.py's finding, siblings are never
    physically re-invoked and OEE's own wrapper re-invocation is a no-op
    for state purposes (LangGraph resumes the child from its checkpoint,
    not from the freshly-built `initial_state` module_subgraph_node passes
    it). Both are therefore provably stable here, unlike in the
    update_state()-triggered case test_phase4b2_human_gate.py documents."""
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(_blocked_runtime(), checkpointer)
    app = graph.compile(checkpointer=checkpointer)
    initial_state = make_agent_state()
    config = {"configurable": {"thread_id": initial_state.run_id}}
    app.invoke(initial_state, config=config)

    mid_values = app.get_state(config).values
    output_before = mid_values["module_states"]["Output"]
    wip_before = mid_values["module_states"]["WIP"]

    # OEE's own started_at, read directly off its paused child checkpoint
    # (mirrors test_case_a_oee_child_checkpoint_exists_while_interrupted).
    entries = list(checkpointer.list({"configurable": {"thread_id": initial_state.run_id}}))
    oee_paused_started_at = None
    for e in entries:
        ns = e.config["configurable"].get("checkpoint_ns", "")
        if not ns.startswith("module_subgraph:"):
            continue
        values = e.checkpoint.get("channel_values", {})
        if values.get("module_id") == "OEE":
            oee_paused_started_at = values.get("started_at")
    assert oee_paused_started_at is not None

    # process-style resume: a brand-new compiled graph object -- no update_state()
    graph2 = build_phase2_graph(_blocked_runtime(), checkpointer)
    app2 = graph2.compile(checkpointer=checkpointer)
    result2 = app2.invoke(Command(resume={"decision": HumanDecision.REJECT.value, "responded_by": "tester"}), config=config)
    final_state = AgentState.model_validate(result2)

    assert final_state.module_states["Output"].started_at == output_before.started_at
    assert final_state.module_states["Output"].completed_at == output_before.completed_at
    assert final_state.module_states["WIP"].started_at == wip_before.started_at
    assert final_state.module_states["WIP"].completed_at == wip_before.completed_at

    # OEE's started_at is unchanged by the resume-triggered wrapper re-invocation
    assert final_state.module_states["OEE"].started_at == oee_paused_started_at


# ============================================================================
# 5. Fan-out modules have independent lifecycles
# ============================================================================


def test_fan_out_modules_get_independently_invoked_now_fn_calls():
    """Each Send-dispatched module_subgraph_node call is an independent
    physical invocation -- proven directly here (bypassing the full graph)
    by injecting a deterministic incrementing clock via `now_fn` and
    confirming each of two separately-dispatched modules gets a distinct
    call, not one shared/stale timestamp."""
    calls: list[datetime] = []

    def counting_now_fn() -> datetime:
        calls.append(datetime(2026, 8, 9, tzinfo=timezone.utc) + timedelta(seconds=len(calls)))
        return calls[-1]

    runtime_by_type = {
        "OEE": ModuleRuntimeConfig(
            policy=DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1),
            tool=ScriptedMockTool({"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}),
            budget=make_budget(max_steps=3, max_tool_calls=3, max_depth_per_entity=2),
        ),
        "Output": ModuleRuntimeConfig(
            policy=DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1),
            tool=ScriptedMockTool({"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}),
            budget=make_budget(max_steps=3, max_tool_calls=3, max_depth_per_entity=2),
        ),
    }
    node = make_module_subgraph_node(runtime_by_type, InMemorySaver(), now_fn=counting_now_fn)

    oee_task = ModuleTask(module_id="OEE", module_type="OEE", reason="test", goal_statement="test goal", confidence=0.9, priority=0.9)
    output_task = ModuleTask(module_id="Output", module_type="Output", reason="test", goal_statement="test goal", confidence=0.9, priority=0.9)

    result_oee = node(ModuleDispatchPayload(module_task=oee_task, run_id="run-fanout"), {"configurable": {"thread_id": "run-fanout-OEE"}})
    result_output = node(ModuleDispatchPayload(module_task=output_task, run_id="run-fanout"), {"configurable": {"thread_id": "run-fanout-Output"}})

    assert len(calls) == 2  # one now_fn() call per independent module dispatch
    oee_state = result_oee["module_states"]["OEE"]
    output_state = result_output["module_states"]["Output"]
    assert oee_state.started_at != output_state.started_at
    assert oee_state.started_at == calls[0]
    assert output_state.started_at == calls[1]


# ============================================================================
# 6. Persistence projection correctness + duplicate persistence idempotency
# ============================================================================


def _writer():
    run_repo = InMemoryRunRepository()
    audit_repo = build_default_audit_repository()
    feedback_sink = InMemoryHumanFeedbackSink()
    learning_repo = LearningCandidateRepository(InMemoryLearningCandidateSink())
    return RunPersistenceWriter(run_repo, audit_repo, feedback_sink, learning_repo), run_repo


def test_persistence_projects_real_run_and_module_timestamps_not_proxies():
    final_state = _run_to_completion()
    writer, run_repo = _writer()
    writer.persist_run(final_state)

    run_record = run_repo.get_run(final_state.run_id)
    assert run_record.started_at == final_state.started_at
    assert run_record.completed_at == final_state.completed_at
    # no longer a proxy -- this is the actual gap Phase 8A-1 closes
    assert run_record.started_at != final_state.user_request.submitted_at

    module_records = {r.module_id: r for r in run_repo.get_module_results(final_state.run_id)}
    for module_id, module_state in final_state.module_states.items():
        assert module_records[module_id].started_at == module_state.started_at
        assert module_records[module_id].completed_at == module_state.completed_at


def test_duplicate_persistence_does_not_change_stamped_timestamps():
    final_state = _run_to_completion()
    writer, run_repo = _writer()
    writer.persist_run(final_state)
    first = run_repo.get_run(final_state.run_id)

    writer.persist_run(final_state)  # same final_state persisted again -- upsert, not append
    second = run_repo.get_run(final_state.run_id)

    assert first.started_at == second.started_at
    assert first.completed_at == second.completed_at
    assert len(run_repo.list_runs()) == 1
