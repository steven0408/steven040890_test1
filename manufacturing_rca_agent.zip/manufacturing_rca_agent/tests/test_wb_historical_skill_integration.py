"""Phase WB-3B item 43/70: full capability-layer trace for the 5 new
historical/cross-source Skills -- Objective -> CapabilityResolver ->
SkillRunner -> ToolExecutionManager -> Tool -> InMemory DataSource ->
typed Result -> Evidence. All offline, via the real generic capability
layer (never a bypassed direct Tool call). Confirms `objective.scope.
time.start`/`.end` parameter_mapping resolves for every new range-scoped
Skill (item 43's own confirmed convention -- `objective.<dotted.path>`
already supports nested paths, no SkillRunner change needed).
"""
from datetime import timedelta

import pytest

from agent.capability.resolver import CapabilityResolver
from agent.planning.policies.wb import build_wb_initial_entity_states
from agent.skills.models import SkillExecutionStatus
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.skills.wb.registration import WB_SKILLS_DIR
from agent.state.enums import ObjectiveAction, TargetRefType, TaskType
from agent.state.models import ModuleState, Objective, TargetRef
from agent.state.payload import PayloadRegistry
from agent.state.scope import ObjectiveScope, ScopeFilter, ScopeOperator, TimeScope, TimeScopeKind
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry
from agent.tools.wb.registration import register_wb_tools

from .conftest import make_module_state, make_wb_datasources
from agent.domain.wb.synthetic import GOLDEN_DATE, HISTORY_DECLINE_START, SCENARIO_A_PLANT, SCENARIO_B_PLANT, SCENARIO_C_PLANT

_WINDOW_START = HISTORY_DECLINE_START - timedelta(days=3)  # 7-day window ending on GOLDEN_DATE


def _wb_registries():
    tool_registry = ToolRegistry()
    register_wb_tools(tool_registry, datasources=make_wb_datasources())
    skill_registry = SkillRegistry()
    skill_registry.load_directory(WB_SKILLS_DIR)
    skill_registry.validate_required_tools(tool_registry)
    return skill_registry, tool_registry


def _module_state(task_type: TaskType) -> ModuleState:
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    return module_state.model_copy(update={
        "goal": module_state.goal.model_copy(update={"task_type": task_type}),
        "entity_states": build_wb_initial_entity_states(),
    })


def _range_objective(capability_key: str, action: ObjectiveAction, plant: str, kind: TimeScopeKind) -> Objective:
    return Objective(
        objective_id="obj-1", description=f"{plant} {capability_key}", action=action,
        capability_key=capability_key, target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id=plant),
        scope=ObjectiveScope(
            time=TimeScope(kind=kind, start=_WINDOW_START, end=GOLDEN_DATE),
            filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value=plant)],
        ),
        expected_output="historical trend", priority_score=1.0,
    )


def _run(task_type: TaskType, objective: Objective, expected_skill_id: str):
    skill_registry, tool_registry = _wb_registries()
    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    module_state = _module_state(task_type)

    resolved = resolver.resolve(objective, "wb", task_type)
    assert resolved.selected_skill.skill_id == expected_skill_id

    outcome = runner.run(resolved.selected_skill, objective, module_state)
    assert outcome.result.status == SkillExecutionStatus.SUCCESS
    return PayloadRegistry.unpack(outcome.result.output_payload)


def test_oee_trend_analysis_skill_resolves_and_executes():
    objective = _range_objective("wb.oee.trend_analysis", ObjectiveAction.ANALYZE, SCENARIO_A_PLANT, TimeScopeKind.PRODUCTION_DATE)
    result = _run(TaskType.ANALYSIS, objective, "wb.oee_trend_analysis")
    assert result.scope.plant_id == SCENARIO_A_PLANT
    assert result.metrics.window_start == _WINDOW_START
    assert result.metrics.window_end == GOLDEN_DATE


def test_oee_trend_analysis_skill_resolves_for_rca_task_type_too():
    objective = _range_objective("wb.oee.trend_analysis", ObjectiveAction.ANALYZE, SCENARIO_A_PLANT, TimeScopeKind.PRODUCTION_DATE)
    result = _run(TaskType.RCA, objective, "wb.oee_trend_analysis")
    assert result.scope.plant_id == SCENARIO_A_PLANT


def test_wip_hold_trend_analysis_skill_resolves_with_snapshot_date_scope():
    objective = _range_objective("wb.wip.hold_trend_analysis", ObjectiveAction.ANALYZE, SCENARIO_C_PLANT, TimeScopeKind.SNAPSHOT_DATE)
    result = _run(TaskType.ANALYSIS, objective, "wb.wip_hold_trend_analysis")
    assert result.scope.snapshot_date_start == _WINDOW_START
    assert result.scope.snapshot_date_end == GOLDEN_DATE
    # Golden Scenario C: recurring-but-non-consecutive pattern
    assert result.metrics.recurrence_count >= 2


def test_bank_shortage_trend_analysis_skill_resolves_with_snapshot_date_scope():
    objective = _range_objective("wb.bank.shortage_trend_analysis", ObjectiveAction.ANALYZE, SCENARIO_B_PLANT, TimeScopeKind.SNAPSHOT_DATE)
    result = _run(TaskType.RCA, objective, "wb.bank_shortage_trend_analysis")
    assert result.scope.snapshot_date_start == _WINDOW_START
    # Golden Scenario B: persistent (consecutive) pattern
    assert result.metrics.consecutive_abnormal_days >= 3


def test_output_trend_analysis_skill_resolves_with_production_date_scope():
    objective = _range_objective("wb.output.trend_analysis", ObjectiveAction.ANALYZE, SCENARIO_B_PLANT, TimeScopeKind.PRODUCTION_DATE)
    result = _run(TaskType.RCA, objective, "wb.output_trend_analysis")
    assert result.scope.production_date_start == _WINDOW_START
    assert result.metrics.trend_direction.value in ("down", "flat", "up", "insufficient_data")


def test_issue_output_relationship_analysis_skill_resolves_and_executes():
    objective = _range_objective("wb.issue_output.relationship_analysis", ObjectiveAction.ANALYZE, SCENARIO_B_PLANT, TimeScopeKind.PRODUCTION_DATE)
    result = _run(TaskType.RCA, objective, "wb.issue_output_relationship_analysis")
    assert result.scope.plant_id == SCENARIO_B_PLANT
    assert result.overlap_observed_days > 0
    # Golden Scenario B narrative
    assert result.direction_alignment.value == "same_direction"
    assert result.both_declining is True


def test_issue_output_relationship_analysis_skill_never_resolves_for_information():
    """Item 27: this Skill's `task_types` are `[analysis, rca]` only --
    never `information` -- a cross-source association is never surfaced
    as a plain status lookup."""
    from agent.capability.resolver import CapabilityResolutionError

    skill_registry, tool_registry = _wb_registries()
    resolver = CapabilityResolver(skill_registry, tool_registry)
    objective = _range_objective("wb.issue_output.relationship_analysis", ObjectiveAction.ANALYZE, SCENARIO_B_PLANT, TimeScopeKind.PRODUCTION_DATE)
    with pytest.raises(CapabilityResolutionError):
        resolver.resolve(objective, "wb", TaskType.INFORMATION)
