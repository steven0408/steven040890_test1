"""Phase 8B-1 Part B: ModulePackageRegistry -- register/get/list/duplicate
fail-fast, mirroring every other registry's shape in this codebase.
"""
import pytest

from agent.modules.oee.package import build_oee_module_package
from agent.modules.registry import DuplicateModulePackageError, ModulePackageNotFoundError, ModulePackageRegistry


def test_register_then_get_returns_the_same_package():
    registry = ModulePackageRegistry()
    package = build_oee_module_package()
    registry.register(package)
    assert registry.get("OEE") is package


def test_get_missing_module_type_raises_typed_error():
    registry = ModulePackageRegistry()
    with pytest.raises(ModulePackageNotFoundError):
        registry.get("NotRegistered")


def test_duplicate_module_package_registration_fails_fast():
    registry = ModulePackageRegistry()
    registry.register(build_oee_module_package())
    with pytest.raises(DuplicateModulePackageError):
        registry.register(build_oee_module_package())


def test_list_returns_every_registered_package():
    registry = ModulePackageRegistry()
    package = build_oee_module_package()
    registry.register(package)
    assert registry.list() == [package]


def test_empty_registry_lists_nothing():
    assert ModulePackageRegistry().list() == []
