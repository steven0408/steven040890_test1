"""Phase 6A item 14: the reusable Synthesis node function -- exercised
directly (not through build_phase2_graph, which this phase deliberately
leaves untouched) against a real end-of-run AgentState."""
from agent.graph.nodes.synthesis import make_synthesis_node
from agent.state.enums import ModuleStatus, SynthesisOverallStatus, TaskType
from agent.state.models import Goal, GoalScope, HandoffPackage

from .conftest import make_agent_state, run_oee_module_state_history


def test_synthesis_node_produces_a_handoff_package_from_agent_state():
    history = run_oee_module_state_history(TaskType.RCA)
    final = history[-1]
    assert final.status == ModuleStatus.COMPLETE

    state = make_agent_state().model_copy(
        update={
            "module_states": {"OEE": final},
            "global_goal": Goal(goal_id="g1", raw_statement="為什麼 OEE 下降？", normalized_statement="Why did OEE decline?", task_type=TaskType.RCA, scope=GoalScope()),
        }
    )

    node = make_synthesis_node()
    result = node(state)

    assert "synthesis_result" in result
    package = result["synthesis_result"]
    assert isinstance(package, HandoffPackage)
    assert package.overall_status == SynthesisOverallStatus.COMPLETE
    assert "Motor Failure" in package.markdown


def test_synthesis_node_does_not_mutate_module_states():
    history = run_oee_module_state_history(TaskType.RCA)
    final = history[-1]
    state = make_agent_state().model_copy(
        update={"module_states": {"OEE": final}, "global_goal": Goal(goal_id="g1", raw_statement="x", normalized_statement="x", task_type=TaskType.RCA, scope=GoalScope())}
    )

    node = make_synthesis_node()
    result = node(state)

    assert set(result.keys()) == {"synthesis_result"}  # never touches module_states/anything else
