import pytest
from pydantic import ValidationError

from agent.state.enums import FindingStatus, GateDecision, ModuleStatus
from agent.state.models import Finding

from .conftest import make_agent_state, make_module_state


def test_gate_decision_has_no_dead_needs_human_value():
    """GateDecision.NEEDS_HUMAN was removed once Human handling moved fully
    to interrupt()/Command(resume=...) (Phase 4B-2 review) -- Gate only ever
    resolves to PASS or REJECTED. Regression guard against reintroducing an
    unused routing value."""
    assert {member.value for member in GateDecision} == {"pass", "rejected"}
    assert not hasattr(GateDecision, "NEEDS_HUMAN")


def test_agent_state_round_trips_through_json():
    state = make_agent_state()
    state.module_states["mod-oee"] = make_module_state()
    state.module_states["mod-oee"].findings.append(
        Finding(
            finding_id="f1",
            statement="Availability loss on EQ007 driven by unplanned downtime.",
            entity_ids=["EQ007"],
            pattern="Availability Loss",
            confidence=0.82,
            status=FindingStatus.CONFIRMED,
            is_root_cause=True,
        )
    )

    payload = state.model_dump_json()
    restored = type(state).model_validate_json(payload)

    assert restored == state
    assert restored.module_states["mod-oee"].findings[0].is_root_cause is True


def test_module_state_defaults_to_pending():
    module_state = make_module_state()
    assert module_state.status == ModuleStatus.PENDING
    assert module_state.findings == []
    assert module_state.branches == {}


def test_extra_fields_are_rejected():
    with pytest.raises(ValidationError):
        Finding(
            finding_id="f1",
            statement="x",
            pattern="Availability Loss",
            confidence=0.5,
            unexpected_field="should not be allowed",
        )


def test_agent_state_never_reintroduces_global_plan_or_objective():
    state = make_agent_state()
    assert not hasattr(state, "current_plan")
    assert not hasattr(state, "current_objective")
