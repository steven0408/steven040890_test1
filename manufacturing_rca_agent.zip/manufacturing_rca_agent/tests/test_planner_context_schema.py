"""Phase 5C-1: PlannerContext must never be able to smuggle in full
AgentState / sibling ModuleState / the full ToolRegistry / raw ToolCall
history / Human audit history / LLM usage history / Evaluator history /
unrelated evidence / unrelated domain skills. This is checked two ways:
(1) no field anywhere in the PlannerContext schema tree is named like one
of those, and (2) no nested model class *is* one of the raw Harness-audit/
full-state classes those come from -- so someone could not smuggle the
forbidden information in a field renamed to something innocuous.
"""
import typing

from agent.llm.context.planner_context import PlannerContext
from agent.state.base import RCABaseModel
from agent.state.models import (
    HumanRequest,
    ModuleState,
    Objective,
    ObjectiveRecord,
    Observation,
    ReflectionRecord,
    ToolCallRecord,
)
from agent.state.state import AgentState


def _nested_model_classes(annotation, seen: set) -> set[type]:
    origin = typing.get_origin(annotation)
    if origin is None:
        if isinstance(annotation, type) and issubclass(annotation, RCABaseModel) and annotation not in seen:
            seen.add(annotation)
            for field in annotation.model_fields.values():
                seen |= _nested_model_classes(field.annotation, seen)
        return seen
    for arg in typing.get_args(annotation):
        seen |= _nested_model_classes(arg, seen)
    return seen


def _all_field_names(model_classes: set[type]) -> set[str]:
    names: set[str] = set()
    for cls in model_classes:
        names |= set(cls.model_fields.keys())
    return names


def test_planner_context_never_embeds_raw_harness_state_classes():
    """The strong version: not just "no field named X", but "no reachable
    nested type IS the raw class X" -- renaming a field could dodge a
    name-based check, but not a type-identity check."""
    nested = _nested_model_classes(PlannerContext, set())
    forbidden_classes = {
        AgentState,       # full run state
        ModuleState,      # full module runtime memory -- the whole point of this phase
        Observation,      # raw per-tool-call observation
        ToolCallRecord,   # raw per-tool-call audit entry
        ObjectiveRecord,  # raw audit trail entry (history_summary is the projection, not this)
        ReflectionRecord, # raw step-level reflection audit
        HumanRequest,     # Human audit belongs in HumanAuditSink, not here
        Objective,        # the live mechanical Objective (with objective_id/status/attempt_count) -- CurrentObjectiveSummary is the projection
    }
    assert nested.isdisjoint(forbidden_classes)


def test_planner_context_has_no_field_named_like_forbidden_information():
    nested = _nested_model_classes(PlannerContext, set())
    field_names = _all_field_names(nested)
    forbidden_names = {
        "module_states", "sibling_module_states", "tool_registry", "tools",
        "tool_calls", "human_requests", "llm_usage", "llm_call_records",
        "run_evaluation", "learning_candidates", "execution_history",
        "observations", "skills",
    }
    assert field_names.isdisjoint(forbidden_names)


def test_planner_context_top_level_fields_are_exactly_the_designed_set():
    # Phase WB-3F.4 added `request_constraints` -- explicit user-stated
    # boundaries (agent/state/scope.py's RequestConstraint), threaded from
    # ModuleGoal.constraints. Bounded, small, load-bearing for scope-
    # preservation guidance (agent/llm/prompts/planner.py).
    assert set(PlannerContext.model_fields.keys()) == {
        "role", "hard_rules", "goal", "current_state", "relevant_evidence",
        "relevant_capabilities", "relevant_knowledge", "relevant_reasoning_skills",
        "history_summary", "request_constraints", "budget", "output_contract_version",
    }
