"""Phase PROD-1: offline tests for agent_api/config.py -- structural
validation only, no network call, no real secret ever required."""
import pytest

from agent_api.config import ApiConfigError, ApiSettings


def test_from_env_requires_llm_provider(monkeypatch):
    monkeypatch.delenv("LLM_PROVIDER", raising=False)
    with pytest.raises(ApiConfigError):
        ApiSettings.from_env()


def test_from_env_succeeds_with_internal_openai_profile(monkeypatch):
    # INTERNAL_LLM_MODEL is the only required env var at THIS layer --
    # INTERNAL_LLM_BASE_URL/INTERNAL_LLM_API_KEY are resolved later, only
    # when build_llm_client() actually constructs the adapter (never here).
    monkeypatch.setenv("LLM_PROVIDER", "internal_openai")
    monkeypatch.setenv("INTERNAL_LLM_MODEL", "/model/gpt-oss-120b")
    settings = ApiSettings.from_env()
    assert settings.llm_provider_config.provider == "internal_openai"
    assert settings.llm_provider_config.base_url_env == "INTERNAL_LLM_BASE_URL"
    assert settings.wb_datasource_profile == "in_memory"  # default


def test_from_env_rejects_invalid_wb_datasource_profile(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "mock")
    monkeypatch.setenv("WB_DATASOURCE_PROFILE", "not_a_real_profile")
    with pytest.raises(ApiConfigError):
        ApiSettings.from_env()


def test_from_env_remote_wb_profile_requires_base_url(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "mock")
    monkeypatch.setenv("WB_DATASOURCE_PROFILE", "remote")
    monkeypatch.delenv("WB_API_BASE_URL", raising=False)
    with pytest.raises(ApiConfigError):
        ApiSettings.from_env()


def test_from_env_remote_wb_profile_succeeds_with_base_url(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "mock")
    monkeypatch.setenv("WB_DATASOURCE_PROFILE", "remote")
    monkeypatch.setenv("WB_API_BASE_URL", "http://placeholder-wb-host:18058")
    settings = ApiSettings.from_env()
    assert settings.wb_datasource_profile == "remote"


def test_llm_routes_covers_every_cognitive_node(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "mock")
    settings = ApiSettings.from_env()
    routes = settings.llm_routes()
    assert set(routes.keys()) == {"standardizer", "analyzer", "planner", "reflector", "synthesis"}


def test_runtime_db_url_resolves_from_named_env_var(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "mock")
    monkeypatch.delenv("AGENT_RUNTIME_DB_URL", raising=False)
    settings = ApiSettings.from_env()
    assert settings.runtime_db_url() is None

    monkeypatch.setenv("AGENT_RUNTIME_DB_URL", "postgresql://user:pass@placeholder-host:5432/db")
    assert settings.runtime_db_url() == "postgresql://user:pass@placeholder-host:5432/db"


def test_is_mock_llm_flag(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "mock")
    assert ApiSettings.from_env().is_mock_llm() is True

    monkeypatch.setenv("LLM_PROVIDER", "internal_openai")
    monkeypatch.setenv("INTERNAL_LLM_MODEL", "/model/gpt-oss-120b")
    assert ApiSettings.from_env().is_mock_llm() is False


def test_enabled_modules_env_override(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "mock")
    monkeypatch.setenv("AGENT_ENABLED_MODULES", "WB,OEE")
    settings = ApiSettings.from_env()
    assert settings.enabled_modules == ["WB", "OEE"]


def test_cors_defaults_to_disabled(monkeypatch):
    monkeypatch.setenv("LLM_PROVIDER", "mock")
    monkeypatch.delenv("AGENT_CORS_ALLOW_ORIGINS", raising=False)
    settings = ApiSettings.from_env()
    assert settings.cors_allow_origins == []
