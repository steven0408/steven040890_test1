"""Phase WB-3B item 70: WBPlanningPolicy's historical ANALYSIS/RCA
branches, exercised through the REAL Module ReAct Subgraph (multi-round,
real Planner/Gate/Executor/Reflector/CompletionCheck nodes) -- not a
bypassed unit call. Covers the phase's own Golden Scenarios (items
30-34), the dynamic-replanning requirement (item 45: same goal, different
evidence -> different next objective/finding), the recurrence-from-data
(never from ObjectiveHistory) regression (item 17), the no-causal-
inflation regression (item 47), and INFORMATION/ANALYSIS scope-creep
regressions (item 58-60). All offline.
"""
from datetime import datetime, timedelta, timezone

from langgraph.checkpoint.memory import InMemorySaver

from agent.capability.resolver import CapabilityResolver
from agent.domain.wb.datasource import InMemoryWBIssueDataSource
from agent.domain.wb.models import WBIssueRecord
from agent.domain.wb.synthetic import GOLDEN_DATE, HISTORY_DECLINE_START, SCENARIO_A_PLANT, SCENARIO_B_PLANT, SCENARIO_C_PLANT, SCENARIO_D_PLANT
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.modules.wb.package import build_wb_module_package
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.enums import ModuleStatus, TaskType
from agent.state.models import ModuleState, ModuleTask
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry
from agent.tools.wb.registration import WBDataSources, register_wb_tools
from tests.conftest import make_wb_datasources

_WINDOW_START = HISTORY_DECLINE_START - timedelta(days=3)  # 7-day window ending on GOLDEN_DATE
_FORBIDDEN_CAUSAL_WORDS = ("caused", "causes", "causing", "proves", "root cause", "directly caused", "due to", "because of")


def _run_wb(task_type: TaskType, thread_id: str, statement: str, *, datasources: WBDataSources | None = None) -> ModuleState:
    package = build_wb_module_package(datasources=datasources)
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    skill_registry.validate_required_tools(tool_registry)

    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    runtime = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)

    policy = WBPlanningPolicy()
    graph = build_module_react_subgraph(policy, capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id="WB", module_type="WB", reason=statement, goal_statement=statement, confidence=0.9, priority=0.9, task_type=task_type)
    initial = build_initial_module_state(task, package.budget, run_id=f"run-{thread_id}", task_type=task_type)
    result = app.invoke(initial, config={"configurable": {"thread_id": thread_id}})
    return ModuleState.model_validate(result)


# ============================================================================
# Golden Scenarios (items 30-34)
# ============================================================================


def test_historical_analysis_issue_trend_persistent_low():
    """Target capability A: "ASE07 這週投料是不是一直偏低？" -- a single-round
    ANALYSIS historical Objective, deterministic 7-day default window."""
    final_state = _run_wb(TaskType.ANALYSIS, "hist-a", "2026-08-12 ASE07 這週投料是不是一直偏低？")
    assert final_state.status == ModuleStatus.COMPLETE
    assert len(final_state.objective_history) == 1
    record = next(iter(final_state.objective_history.values()))
    assert record.capability_key == "wb.issue.trend_analysis"
    finding = final_state.findings[-1]
    assert finding.is_root_cause is False


def test_historical_rca_wip_hold_recurrence_count_this_week():
    """Target capability B: "ASE03 Hold 這週已經發生幾次？" -- Golden Scenario
    C's recurring-but-non-consecutive pattern."""
    final_state = _run_wb(TaskType.RCA, "hist-b", "2026-08-12 ASE03 Hold 這週已經發生幾次 trend root cause")
    assert final_state.status == ModuleStatus.COMPLETE
    caps = [r.capability_key for r in final_state.objective_history.values()]
    assert "wb.wip.hold_trend_analysis" in caps
    finding = final_state.findings[-1]
    assert "4 of 7" in finding.statement
    assert "recurring" in finding.statement.lower()
    assert finding.is_root_cause is False


def test_historical_rca_oee_single_day_vs_recurring():
    """Target capability C: "ASE01 OEE 下降是單日事件還是持續問題？" -- Golden
    Scenario A's deliberately single-day (not recurring) pattern."""
    final_state = _run_wb(TaskType.RCA, "hist-c", "2026-08-12 ASE01 OEE 表現差 這週 trend root cause")
    assert final_state.status == ModuleStatus.COMPLETE
    caps = [r.capability_key for r in final_state.objective_history.values()]
    assert "wb.oee.trend_analysis" in caps
    finding = final_state.findings[-1]
    assert "single-day event" in finding.statement
    assert finding.is_root_cause is False


def test_historical_rca_output_crosssource_full_chain_ase07():
    """Target capability D: "ASE07 Output低的同時，ISSUE是不是也持續偏低？" --
    Golden Scenario B's full 4-round chain: output symptom -> output trend
    -> issue trend -> issue/output relationship (only because issue trend
    is ALSO declining)."""
    final_state = _run_wb(TaskType.RCA, "hist-d", "2026-08-12 ASE07 output 偏低 這週 trend root cause")
    assert final_state.status == ModuleStatus.COMPLETE
    caps = [r.capability_key for r in final_state.objective_history.values()]
    assert caps == ["wb.output.comparison", "wb.output.trend_analysis", "wb.issue.trend_analysis", "wb.issue_output.relationship_analysis"]

    finding = final_state.findings[-1]
    assert finding.is_root_cause is False
    statement_lower = finding.statement.lower()
    assert "same direction" in statement_lower
    for forbidden in _FORBIDDEN_CAUSAL_WORDS:
        assert forbidden not in statement_lower


def test_historical_rca_normal_plant_ase02_no_false_positive():
    """Golden Scenario D (normal, false-positive control): must not
    classify random/normal noise as a recurring abnormality."""
    final_state = _run_wb(TaskType.RCA, "hist-normal", "2026-08-12 ASE02 OEE 異常 這週 trend root cause")
    assert final_state.status == ModuleStatus.COMPLETE
    finding = final_state.findings[-1]
    assert "normal historical range" in finding.statement
    assert finding.is_root_cause is False


def test_historical_rca_missing_plant_ase08_insufficient_data_not_fabricated():
    """Golden Scenario E: ASE08 has no OEE data at all -- the historical
    chain must report an honest INSUFFICIENT_DATA outcome, never a
    fabricated specific value or a false "normal" claim."""
    final_state = _run_wb(TaskType.RCA, "hist-missing", "2026-08-12 ASE08 OEE 異常 這週 trend root cause")
    # PARTIAL (unresolved, no fabricated evidence) or COMPLETE with an
    # honest "insufficient data" finding are both acceptable outcomes --
    # what's forbidden is a confident, specific claim built on absent data.
    assert final_state.status in (ModuleStatus.COMPLETE, ModuleStatus.PARTIAL)
    if final_state.findings:
        finding = final_state.findings[-1]
        assert "58.0" not in finding.statement  # ASE01's own golden OEE value must never leak in
        assert finding.is_root_cause is False


# ============================================================================
# Item 17: recurrence must come from DATA, never from ObjectiveHistory
# retry count.
# ============================================================================


def test_recurrence_count_reflects_data_not_the_single_objective_dispatch():
    """ASE03's WIP Hold trend capability is dispatched exactly ONCE in the
    objective_history (one Objective, one round) -- yet the resulting
    Finding reports a recurrence of 4 (of 7 observed days), proving
    recurrence is computed from the underlying daily data, never confused
    with "this objective was retried N times" (item 17's own explicit
    regression concern)."""
    final_state = _run_wb(TaskType.RCA, "hist-recurrence", "2026-08-12 ASE03 Hold 這週已經發生幾次 trend root cause")
    wip_trend_dispatches = [r for r in final_state.objective_history.values() if r.capability_key == "wb.wip.hold_trend_analysis"]
    assert len(wip_trend_dispatches) == 1  # dispatched exactly once
    assert "4 of 7" in final_state.findings[-1].statement  # but recurrence is 4, not 1


# ============================================================================
# Item 45: dynamic replanning -- same goal, different evidence -> different
# next objective/finding.
# ============================================================================


def _flat_issue_datasource_for_ase07() -> InMemoryWBIssueDataSource:
    """A hand-crafted ISSUE dataset where ASE07's Issue quantity is FLAT
    (not declining) across the whole historical window -- the controlled
    counterpart to the real synthetic dataset's own declining pattern,
    used to prove the RCA chain genuinely branches on the Evidence it
    observes rather than following a hardcoded sequence."""
    records = []
    for i in range(7):
        d = _WINDOW_START + timedelta(days=i)
        sync = datetime.combine(d, datetime.min.time()).replace(hour=8, tzinfo=timezone.utc)
        records.append(WBIssueRecord(
            source_sync_time=sync, plant_id=SCENARIO_B_PLANT, site=None, schedule=None, customer_code=None, customer_name=None,
            device_type=None, issue_quantity=700, lead_count=None, package_code=None, package_type=None, region=None,
            release_date=d, release_date_raw=d.isoformat(), release_time=None, release_system=None, time_bucket=None, wafer_inch=None,
            year=None, bd_no_unknown=None, cu_flag_unknown=None, customer_run_type_unknown=None, customer_sod_unknown=None,
            internal_sod_unknown=None, routid_unknown=None, run_type_unknown=None, unit_of_measure_unknown=None,
            user_id_unknown=None, user_name_unknown=None,
        ))
    return InMemoryWBIssueDataSource(records)


def test_dynamic_replanning_flat_issue_trend_skips_relationship_capability():
    """Item 45's own worked example, Scenario 2: same goal ("Why was
    ASE07 output low?"), but with ASE07's Issue trend now FLAT (not
    declining, via a controlled DataSource override) -- the Planner must
    NOT dispatch the Issue-vs-Output relationship capability, and the
    final Finding must not claim an issue/output association. Contrast
    this with `test_historical_rca_output_crosssource_full_chain_ase07`
    above (Scenario 1, real dataset, declining Issue trend), which DOES
    reach the relationship capability -- same goal, different evidence,
    different next objective/finding."""
    base = make_wb_datasources()
    custom = WBDataSources(oee=base.oee, bank=base.bank, wip=base.wip, output=base.output, issue=_flat_issue_datasource_for_ase07())

    final_state = _run_wb(TaskType.RCA, "hist-replan-flat", "2026-08-12 ASE07 output 偏低 這週 trend root cause", datasources=custom)

    caps = [r.capability_key for r in final_state.objective_history.values()]
    assert "wb.issue_output.relationship_analysis" not in caps
    assert caps == ["wb.output.comparison", "wb.output.trend_analysis", "wb.issue.trend_analysis"]

    finding = final_state.findings[-1]
    assert "issue" not in finding.statement.lower() or "output" not in finding.statement.lower() or "relationship" not in finding.statement.lower()
    assert finding.is_root_cause is False


# ============================================================================
# Item 47: no causal inflation regression (structural, across scenarios).
# ============================================================================


def test_no_causal_inflation_across_all_historical_rca_findings():
    for thread_id, statement in [
        ("causal-a", "2026-08-12 ASE01 OEE 表現差 這週 trend root cause"),
        ("causal-b", "2026-08-12 ASE03 Hold 這週已經發生幾次 trend root cause"),
        ("causal-d", "2026-08-12 ASE07 output 偏低 這週 trend root cause"),
    ]:
        final_state = _run_wb(TaskType.RCA, thread_id, statement)
        for finding in final_state.findings:
            assert finding.is_root_cause is False
            statement_lower = finding.statement.lower()
            for forbidden in _FORBIDDEN_CAUSAL_WORDS:
                assert forbidden not in statement_lower


# ============================================================================
# Item 58/59: INFORMATION/ANALYSIS scope-creep regressions.
# ============================================================================


def test_information_never_triggers_a_historical_objective_even_with_keywords():
    """Item 58: INFORMATION must never auto-trigger historical analysis,
    even when the request text contains historical keywords -- historical
    capabilities are ANALYSIS/RCA only (item 13's own task_types design)."""
    final_state = _run_wb(TaskType.INFORMATION, "info-no-hist", "2026-08-12 ASE07 這週 trend 投料狀況如何")
    caps = [r.capability_key for r in final_state.objective_history.values()]
    assert "wb.issue.trend_analysis" not in caps


def test_14_day_window_keyword_is_detected_and_produces_a_wider_window():
    """Item 51: the Tool contract supports an arbitrary bounded range, not
    just the 7-day default -- confirms the "14天" keyword actually widens
    the proposed Objective's scope, not just the default path."""
    final_state = _run_wb(TaskType.ANALYSIS, "hist-14day", "2026-08-12 ASE07 過去14天投料是不是一直偏低？")
    assert final_state.status == ModuleStatus.COMPLETE
    record = next(iter(final_state.objective_history.values()))
    assert record.capability_key == "wb.issue.trend_analysis"
    window_length_days = (record.scope.time.end - record.scope.time.start).days + 1
    assert window_length_days == 14


def test_analysis_without_historical_keyword_uses_the_plain_capability():
    """Item 59: a plain ANALYSIS request (no historical keyword) for a
    topic that HAS both a plain and a historical capability must still
    resolve to the plain one -- historical is never the silent default."""
    final_state = _run_wb(TaskType.ANALYSIS, "analysis-plain", "2026-08-12 哪個 plant 的 OEE 最差")
    caps = [r.capability_key for r in final_state.objective_history.values()]
    assert "wb.oee.trend_analysis" not in caps
