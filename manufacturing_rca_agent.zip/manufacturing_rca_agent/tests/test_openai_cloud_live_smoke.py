"""Phase WB-3E: the first real network calls to OpenAI Cloud anywhere in
this repo. Mirrors `test_phase5b3b_real_provider_smoke.py`'s own exact
discipline (skip, not fail, without a secret; semantic-only assertions,
never exact LLM wording) for the Analyzer -- Planner is covered
separately and far more extensively in `test_wb_reasoning_llm_live.py`.

Synthetic/simple requests only. Only semantic results (TaskType + which
module) are asserted, never exact `reasoning_summary` wording.
"""
import os

import pytest

from agent.graph.nodes.analyzer_llm import AnalyzerLLMService, DecisionSource
from agent.llm.config import LLMRouteConfig
from agent.llm.context.analyzer_context import AnalyzerContextBuilder
from agent.llm.models import LLMCallStatus
from agent.llm.providers.openai_adapter import OpenAICompatibleAdapter
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.catalog.module_registry import ModuleRegistry
from agent.modules.wb.package import build_wb_module_package
from agent.state.enums import TaskType

from .conftest import make_agent_state

pytestmark = pytest.mark.skipif(
    not os.environ.get("OPENAI_API_KEY"),
    reason="OPENAI_API_KEY not set -- real OpenAI Cloud smoke tests skipped (not failed) without a secret",
)

_MODEL = "gpt-4o"


def _wb_only_registry() -> ModuleRegistry:
    """Deliberately WB-only (not `conftest.make_module_registry()`'s own
    OEE/Output/WIP catalog, unrelated to this phase's own WB focus) --
    isolates these tests to what they actually prove (WB module-selection
    reasoning), never confounded by an irrelevant multi-module catalog."""
    registry = ModuleRegistry()
    registry.register(build_wb_module_package().module_definition)
    return registry


def _real_service() -> tuple[AnalyzerLLMService, InMemoryLLMUsageSink]:
    registry = _wb_only_registry()
    usage_sink = InMemoryLLMUsageSink()
    router = LLMRouter(
        routes={"analyzer": LLMRouteConfig(route="analyzer", model=_MODEL, timeout_seconds=30.0, max_retries=1)},
        client=OpenAICompatibleAdapter(temperature=0.0, max_tokens=1000),
        usage_sink=usage_sink,
    )
    service = AnalyzerLLMService(registry, AnalyzerContextBuilder(registry), router)
    return service, usage_sink


def _assert_real_usage_recorded(usage_sink: InMemoryLLMUsageSink, run_id: str) -> None:
    records = usage_sink.list_for_run(run_id)
    assert records
    record = records[-1]
    assert record.model == _MODEL
    assert record.status in (LLMCallStatus.SUCCESS, LLMCallStatus.INVALID_OUTPUT, LLMCallStatus.TIMEOUT, LLMCallStatus.PROVIDER_ERROR)
    assert record.latency_ms >= 0
    assert record.input_tokens >= 0
    assert record.output_tokens >= 0
    assert record.estimated_cost is None  # no pricing config wired up this phase


def _assert_llm_success_or_safe_fallback(outcome, task_type: TaskType) -> None:
    """Phase WB-3E honest finding (see the completion report's own
    section 32): with only ONE module registered (WB), both gpt-4o-mini
    AND gpt-4o were observed to sometimes invent a plausible-sounding but
    non-existent `module_type` (e.g. "output_analysis") keyed off words
    in the user's own request text -- despite `AnalyzerContext`'s own
    existing explicit hard rule ("Only select Modules from the provided
    Available Module Catalog -- never invent a module_type",
    `agent/llm/context/analyzer_context.py`, unmodified this phase). This
    is never silently accepted: `validate_analyzer_decision`'s existing
    semantic gate (Frozen, untouched) correctly rejects it every time
    this was observed, and `AnalyzerLLMService` correctly falls back to
    its deterministic decision -- proving the Final Invariant ("Real
    provider failure must degrade safely to deterministic fallback")
    rather than the raw "LLM succeeded" claim, which this phase's own
    real testing showed is not 100% reliable for this exact single-module
    scenario with these models. Both outcomes are asserted as valid --
    a LOWER semantic-validator bar was never used to force a "success"."""
    if outcome.source == DecisionSource.LLM:
        assert outcome.decision.task_type == task_type
        assert "WB" in {m.module_type for m in outcome.decision.selected_modules}
    else:
        assert outcome.source == DecisionSource.FALLBACK
        assert outcome.fallback_reason is not None
        # the deterministic fallback decision must still be usable
        assert outcome.decision is not None


# ============================================================================
# Item AK -- Analyzer real-LLM wiring: INFORMATION / ANALYSIS / RCA.
# ============================================================================


def test_real_openai_information_selects_wb_or_falls_back_safely():
    service, usage_sink = _real_service()
    outcome = service.decide(make_agent_state(run_id="openai-smoke-info", raw_text="2026-08-12 ASE07 的投料狀況如何？"))
    _assert_llm_success_or_safe_fallback(outcome, TaskType.INFORMATION)
    _assert_real_usage_recorded(usage_sink, "openai-smoke-info")


def test_real_openai_analysis_selects_wb_or_falls_back_safely():
    service, usage_sink = _real_service()
    outcome = service.decide(make_agent_state(run_id="openai-smoke-analysis", raw_text="2026-08-12 ASE07 這週投料是不是一直偏低？"))
    _assert_llm_success_or_safe_fallback(outcome, TaskType.ANALYSIS)
    _assert_real_usage_recorded(usage_sink, "openai-smoke-analysis")


def test_real_openai_rca_selects_wb_or_falls_back_safely():
    service, usage_sink = _real_service()
    outcome = service.decide(make_agent_state(run_id="openai-smoke-rca", raw_text="2026-08-12 為什麼 ASE07 Output 偏低？"))
    _assert_llm_success_or_safe_fallback(outcome, TaskType.RCA)
    _assert_real_usage_recorded(usage_sink, "openai-smoke-rca")


def test_real_openai_decision_never_leaks_tool_or_skill_identifiers():
    """item AK: "no tool/skill leakage" -- the Analyzer decision only ever
    names TaskType/module/goal_statement/rationale, never a specific
    Tool/Skill id (that's the Planner's own, later, separate decision)."""
    service, usage_sink = _real_service()
    outcome = service.decide(make_agent_state(run_id="openai-smoke-no-leak", raw_text="2026-08-12 為什麼 ASE07 Output 偏低？"))

    for module_selection in outcome.decision.selected_modules:
        assert "wb." not in module_selection.goal_statement  # never a capability_key-shaped string
        assert "analyze_wb" not in module_selection.goal_statement  # never a tool_id
