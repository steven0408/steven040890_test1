﻿"""Phase 5C-3: real-provider Planner smoke -- the only tests in this file
make a real network call to a real LLM provider (Anthropic), and only for
the Module Planner (`LLMPlanningPolicy`); the Analyzer stays a small,
deterministic, non-LLM test double (`_single_oee_analyzer_node`) so this
phase controls exactly one variable at a time, per the spec's "先只做 OEE,
不要同時驅動 Output/OEE/WIP" instruction. Reflector/Synthesis/Evaluator/
Learning are untouched and out of scope.

Skipped entirely (not failed) when `ANTHROPIC_API_KEY` is not set -- same
policy as test_phase5b3b_real_provider_smoke.py, so the rest of the suite
always passes without a secret. In this project's own Docker-based test
environment, `ANTHROPIC_API_KEY` has never been set, so every test in this
file has only ever been verified to *skip cleanly*, never to observe a real
model's actual output -- see the Phase 5C-3 report for the honest status.

Phase WB-3E note: activating a real provider (OpenAI) for the first time
in this project's history surfaced exactly the kind of latent bug this
file's own skip-without-a-secret discipline can hide -- `LLMPlanningPolicy(...)`
and `evaluate_planner_decision_quality(...)` had both grown a new required
`skill_registry` argument in a later phase, silently un-caught here since
this file's body never actually executes without `ANTHROPIC_API_KEY`.
Fixed opportunistically (both call sites now pass `make_oee_skill_registry()`),
verified to at least import/construct correctly, but still NOT verified
against a real Anthropic call in this environment (no `ANTHROPIC_API_KEY`
available here either) -- see the Phase WB-3E report's own "before-state"
section for the full finding.

Two categories of assertion appear here, deliberately not conflated (item
10 of the spec):
  - HARD gate: `validate_planner_decision` must pass, or the test fails --
    a real LLM is not exempt from producing a legal Objective.
  - SOFT signal: `evaluate_planner_decision_quality` is recorded and
    printed for the comparison table, but a lower score never fails a test
    on its own -- a real LLM legitimately choosing a target the
    deterministic baseline never defined is not a bug (Phase 5C-2.1
    architecture note).
"""
import os

import pytest
from langgraph.checkpoint.memory import InMemorySaver

from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD
from agent.graph.graph import build_phase2_graph
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.llm.config import LLMRouteConfig
from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
from agent.llm.context.context_audit import InMemoryContextAuditSink
from agent.llm.context.evidence_selector import DeterministicEvidenceSelector
from agent.llm.context.planner_context import PlannerContextBuilder
from agent.llm.models import DecisionSource, LLMCallStatus
from agent.llm.providers.anthropic_adapter import AnthropicAdapter
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.planning.decision_audit import InMemoryPlannerDecisionAuditSink
from agent.planning.decision_quality import evaluate_planner_decision_quality
from agent.planning.policies.llm import LLMPlanningPolicy, decision_from_objective
from agent.planning.policies.oee import OEEPlanningPolicy
from agent.state.enums import ModuleStatus, ObjectiveAction, RunTerminationStatus, TargetRefType, TaskType
from agent.state.models import Goal, GoalScope, ModuleTask
from agent.state.state import AgentState

from .conftest import make_agent_state, make_budget, make_oee_capability_runtime, make_oee_skill_registry, run_oee_module_state_history

pytestmark = pytest.mark.skipif(
    not os.environ.get("ANTHROPIC_API_KEY"),
    reason="ANTHROPIC_API_KEY not set -- real-provider Planner smoke tests skipped (not failed) without a secret",
)

_MODEL = "claude-haiku-4-5-20251001"


# ============================================================================
# Wiring helpers
# ============================================================================


def _real_planner_policy(*, decision_audit_sink=None, context_audit_sink=None) -> tuple[LLMPlanningPolicy, InMemoryLLMUsageSink]:
    usage_sink = InMemoryLLMUsageSink()
    router = LLMRouter(
        routes={"planner": LLMRouteConfig(route="planner", model=_MODEL, timeout_seconds=30.0, max_retries=1)},
        client=AnthropicAdapter(),
        usage_sink=usage_sink,
    )
    context_builder = PlannerContextBuilder(
        DeterministicEvidenceSelector(), DeterministicCapabilityRetriever(make_oee_skill_registry()), audit_sink=context_audit_sink
    )
    policy = LLMPlanningPolicy(OEEPlanningPolicy(), context_builder, router, make_oee_skill_registry(), decision_audit_sink=decision_audit_sink)
    return policy, usage_sink


def _bootstrap_module_state(task_type: TaskType, goal_statement: str):
    task = ModuleTask(module_id="OEE", module_type="OEE", reason="Phase 5C-3 real Planner smoke", goal_statement=goal_statement, confidence=0.9, priority=0.9, task_type=task_type)
    budget = make_budget(max_steps=6, max_tool_calls=20, max_depth_per_entity=3)
    state = build_initial_module_state(task, budget, run_id=f"smoke-planner-{task_type.value}", task_type=task_type)
    return state.model_copy(update={"goal": state.goal.model_copy(update={"statement": goal_statement})})


def _assert_real_usage_recorded(usage_sink: InMemoryLLMUsageSink, run_id: str) -> None:
    records = usage_sink.list_for_run(run_id)
    assert records
    record = records[-1]
    assert record.route == "planner"
    assert record.model == _MODEL
    assert record.status in (LLMCallStatus.SUCCESS, LLMCallStatus.INVALID_OUTPUT, LLMCallStatus.TIMEOUT, LLMCallStatus.PROVIDER_ERROR)
    assert record.latency_ms >= 0
    assert record.retry_count >= 0
    assert record.input_tokens >= 0
    assert record.output_tokens >= 0


def _print_row(scenario: str, objective, semantic_valid: bool, quality, baseline: str) -> None:
    action = objective.action.value if objective is not None else "NONE"
    target = objective.target_ref.ref_id if objective is not None else "-"
    print(f"| {scenario:<14} | {action:<20}-> {target:<8} | valid={semantic_valid!s:<5} | quality={quality.overall_score:.2f} | baseline={baseline} |")


def _capability_resolver():
    return make_oee_capability_runtime(MOCK_EQUIPMENT, OEE_THRESHOLD).capability_resolver


def _single_oee_analyzer_node(task_type: TaskType):
    """A small, deterministic, non-LLM test double for the Analyzer -- this
    phase's variable under test is the Planner, not the Analyzer (already
    covered by test_phase5b3b_real_provider_smoke.py). Directly sets
    global_goal.task_type and selects OEE only, so a real Planner call is
    never made under a multi-module fan-out."""

    def node(state: AgentState) -> dict:
        goal = Goal(
            goal_id=f"{state.run_id}-goal",
            raw_statement=state.user_request.raw_text,
            normalized_statement=state.user_request.raw_text,
            task_type=task_type,
            scope=GoalScope(),
        )
        task = ModuleTask(module_id="OEE", module_type="OEE", reason="Phase 5C-3 smoke -- OEE only", goal_statement=state.user_request.raw_text, confidence=1.0, priority=1.0, task_type=task_type)
        return {"global_goal": goal, "selected_modules": [task]}

    return node


def _run_real_planner_e2e(task_type: TaskType, raw_text: str, run_id: str, planner_policy: LLMPlanningPolicy) -> AgentState:
    runtime = {
        "OEE": ModuleRuntimeConfig(
            policy=planner_policy, capability=make_oee_capability_runtime(MOCK_EQUIPMENT, OEE_THRESHOLD),
            budget=make_budget(max_steps=6, max_tool_calls=20, max_depth_per_entity=3),
        ),
    }
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(runtime, checkpointer, analyzer=_single_oee_analyzer_node(task_type))
    app = graph.compile(checkpointer=checkpointer)
    result = app.invoke(make_agent_state(run_id=run_id, raw_text=raw_text), config={"configurable": {"thread_id": run_id}})
    return AgentState.model_validate(result)


# ============================================================================
# Smoke Case A -- INFORMATION (item 4)
# ============================================================================


def test_real_information_decision_is_current_status():
    decision_sink = InMemoryPlannerDecisionAuditSink()
    context_sink = InMemoryContextAuditSink()
    policy, usage_sink = _real_planner_policy(decision_audit_sink=decision_sink, context_audit_sink=context_sink)
    module_state = _bootstrap_module_state(TaskType.INFORMATION, "今天平均 OEE 多少？")

    objective = policy.propose_next_objective(module_state)

    assert objective is not None
    assert objective.action == ObjectiveAction.SUMMARIZE
    assert objective.target_ref.ref_type == TargetRefType.MODULE
    assert objective.target_ref.ref_id == "OEE"

    record = decision_sink.list_for_run(module_state.run_id)[0]
    assert record.source == DecisionSource.LLM, record.fallback_reason
    _assert_real_usage_recorded(usage_sink, module_state.run_id)

    # correlation (items 11/12/13/14): PlannerDecisionRecord -> LLMCallRecord / ContextBuildRecord
    assert record.llm_call_id in {r.llm_call_id for r in usage_sink.list_for_run(module_state.run_id)}
    context_records = context_sink.list_for_run(module_state.run_id)
    assert record.context_build_record_id in {r.context_build_record_id for r in context_records}
    context_record = next(r for r in context_records if r.context_build_record_id == record.context_build_record_id)
    assert context_record.included_evidence_count >= 0
    assert context_record.included_skills_count >= 1

    decision = decision_from_objective(objective, rationale=record.rationale_summary)
    quality = evaluate_planner_decision_quality(decision, module_state=module_state, task_type=TaskType.INFORMATION, capability_resolver=_capability_resolver(), skill_registry=make_oee_skill_registry())
    _print_row("INFORMATION", objective, True, quality, "CURRENT_STATUS")


def test_real_information_end_to_end_reaches_ready_for_synthesis():
    policy, _ = _real_planner_policy()
    final_state = _run_real_planner_e2e(TaskType.INFORMATION, "今天平均 OEE 多少？", "smoke-planner-info-e2e", policy)

    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.COMPLETE
    assert [r.action for r in oee.objective_history.values()] == [ObjectiveAction.SUMMARIZE]
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


# ============================================================================
# Smoke Case B -- ANALYSIS (item 5)
# ============================================================================


def test_real_analysis_decision_is_equipment_screening():
    decision_sink = InMemoryPlannerDecisionAuditSink()
    policy, usage_sink = _real_planner_policy(decision_audit_sink=decision_sink)
    module_state = _bootstrap_module_state(TaskType.ANALYSIS, "哪些設備 OEE 比較差？")

    objective = policy.propose_next_objective(module_state)

    assert objective is not None
    assert objective.action == ObjectiveAction.SCREEN
    assert objective.target_ref.ref_type == TargetRefType.MODULE
    assert objective.target_ref.ref_id == "OEE"

    record = decision_sink.list_for_run(module_state.run_id)[0]
    assert record.source == DecisionSource.LLM, record.fallback_reason
    _assert_real_usage_recorded(usage_sink, module_state.run_id)

    decision = decision_from_objective(objective, rationale=record.rationale_summary)
    quality = evaluate_planner_decision_quality(decision, module_state=module_state, task_type=TaskType.ANALYSIS, capability_resolver=_capability_resolver(), skill_registry=make_oee_skill_registry())
    _print_row("ANALYSIS", objective, True, quality, "EQUIPMENT_SCREENING")


def test_real_analysis_end_to_end_never_produces_equipment_detail():
    policy, _ = _real_planner_policy()
    final_state = _run_real_planner_e2e(TaskType.ANALYSIS, "哪些設備 OEE 比較差？", "smoke-planner-analysis-e2e", policy)

    oee = final_state.module_states["OEE"]
    assert oee.status == ModuleStatus.COMPLETE
    assert oee.findings[-1].is_root_cause is False
    actions = {r.action for r in oee.objective_history.values()}
    assert ObjectiveAction.DRILL_DOWN not in actions
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


# ============================================================================
# Smoke Case C -- RCA Round 1, no screening evidence yet (item 6)
# ============================================================================


def test_real_rca_round_1_decision_is_equipment_screening():
    decision_sink = InMemoryPlannerDecisionAuditSink()
    policy, usage_sink = _real_planner_policy(decision_audit_sink=decision_sink)
    module_state = _bootstrap_module_state(TaskType.RCA, "為什麼今天 OEE 下降？")

    objective = policy.propose_next_objective(module_state)

    assert objective is not None
    assert objective.action == ObjectiveAction.SCREEN
    assert objective.target_ref.ref_type == TargetRefType.MODULE
    assert objective.target_ref.ref_id == "OEE"

    record = decision_sink.list_for_run(module_state.run_id)[0]
    assert record.source == DecisionSource.LLM, record.fallback_reason
    _assert_real_usage_recorded(usage_sink, module_state.run_id)

    decision = decision_from_objective(objective, rationale=record.rationale_summary)
    quality = evaluate_planner_decision_quality(decision, module_state=module_state, task_type=TaskType.RCA, capability_resolver=_capability_resolver(), skill_registry=make_oee_skill_registry())
    _print_row("RCA Round 1", objective, True, quality, "EQUIPMENT_SCREENING")


# ============================================================================
# Smoke Case D -- RCA mid-run: screening complete, no entity deep-dived yet
# (item 7)
# ============================================================================


def _find_post_screening_snapshot(history):
    candidates = [snapshot for snapshot in history if len(snapshot.objective_history) == 1 and snapshot.branches]
    assert candidates, "expected a snapshot right after screening completes, before any deep-dive"
    return candidates[-1]


def test_real_rca_post_screening_decision_picks_a_relevant_unexplored_availability_entity():
    baseline_history = run_oee_module_state_history(TaskType.RCA)  # deterministic -- zero real LLM calls
    module_state = _find_post_screening_snapshot(baseline_history)
    assert module_state.branches["branch-availability"].status.value == "active"

    decision_sink = InMemoryPlannerDecisionAuditSink()
    policy, usage_sink = _real_planner_policy(decision_audit_sink=decision_sink)

    objective = policy.propose_next_objective(module_state)

    assert objective is not None, "real Planner must propose SOMETHING at this stage -- screening evidence exists"
    assert objective.action == ObjectiveAction.DRILL_DOWN
    assert objective.target_ref.ref_type == TargetRefType.ENTITY
    availability_entities = {eid for eid, e in module_state.entity_states.items() if e.branch_id == "branch-availability"}
    assert objective.target_ref.ref_id in availability_entities  # never EQ009 (Quality branch), never a hallucinated id
    assert objective.target_ref.ref_id != "EQ009"

    record = decision_sink.list_for_run(module_state.run_id)[0]
    assert record.source == DecisionSource.LLM, record.fallback_reason
    _assert_real_usage_recorded(usage_sink, module_state.run_id)

    decision = decision_from_objective(objective, rationale=record.rationale_summary)
    quality = evaluate_planner_decision_quality(decision, module_state=module_state, task_type=TaskType.RCA, capability_resolver=_capability_resolver(), skill_registry=make_oee_skill_registry())
    assert quality.target_relevant and quality.target_unexplored
    _print_row("RCA Round 2", objective, True, quality, "EQ001 (or another Availability entity)")


# ============================================================================
# Smoke Case E -- RCA subsequent: EQ001 done (Motor Failure), EQ003 not yet
# (item 8)
# ============================================================================


def _find_mid_rca_snapshot(history):
    candidates = [
        snapshot for snapshot in history
        if len(snapshot.objective_history) == 2 and any(e.objective_id == "OEE-obj-2" for e in snapshot.evidence)
    ]
    assert candidates, "expected a snapshot with EQ001 investigated but EQ003 not yet dispatched"
    return candidates[-1]


def test_real_rca_subsequent_decision_picks_an_unexplored_availability_entity():
    baseline_history = run_oee_module_state_history(TaskType.RCA)  # deterministic -- zero real LLM calls
    module_state = _find_mid_rca_snapshot(baseline_history)

    decision_sink = InMemoryPlannerDecisionAuditSink()
    policy, usage_sink = _real_planner_policy(decision_audit_sink=decision_sink)

    objective = policy.propose_next_objective(module_state)

    assert objective is not None
    assert objective.action == ObjectiveAction.DRILL_DOWN
    assert objective.target_ref.ref_type == TargetRefType.ENTITY
    assert objective.target_ref.ref_id != "EQ001"  # already investigated -- repeating it has no retry justification
    assert objective.target_ref.ref_id != "EQ009"  # Quality branch -- never the dominant Availability branch

    record = decision_sink.list_for_run(module_state.run_id)[0]
    assert record.source == DecisionSource.LLM, record.fallback_reason
    _assert_real_usage_recorded(usage_sink, module_state.run_id)

    decision = decision_from_objective(objective, rationale=record.rationale_summary)
    quality = evaluate_planner_decision_quality(decision, module_state=module_state, task_type=TaskType.RCA, capability_resolver=_capability_resolver(), skill_registry=make_oee_skill_registry())
    assert quality.target_relevant and quality.target_unexplored
    # not an automatic failure if the real Planner picks a different-but-
    # reasonable unexplored Availability entity than EQ003 -- recorded for
    # the comparison report either way (item 8's explicit instruction)
    _print_row("RCA Round 3", objective, True, quality, "EQ003 (or another unexplored Availability entity)")
