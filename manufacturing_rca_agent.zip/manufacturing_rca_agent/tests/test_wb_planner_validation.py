"""Phase WB-2C Cases G/H/I: entity validation, required-scope validation,
and CapabilityResolver uniqueness -- all via the REAL generic validation
path (`validate_planner_decision`/`CapabilityResolver.resolve`), never a
direct `SkillRegistry.get(...)` bypass. All offline.
"""
import pytest

from agent.capability.resolver import CapabilityResolver
from agent.domain.wb.synthetic import GOLDEN_DATE
from agent.planning.policies.llm import PlannerSemanticValidationError, validate_planner_decision
from agent.planning.policies.wb import build_wb_initial_entity_states
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.modules.wb.package import build_wb_module_package
from agent.skills.registry import SkillRegistry
from agent.state.enums import ObjectiveAction, TargetRefType, TaskType
from agent.state.models import TargetRef
from agent.state.scope import ObjectiveScope, ScopeFilter, ScopeOperator, TimeScope, TimeScopeKind
from agent.tools.registry import ToolRegistry

from .conftest import make_module_state


def _wb_registries():
    package = build_wb_module_package()
    tool_registry = ToolRegistry()
    package.tool_registrations(tool_registry)
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    return skill_registry, tool_registry


def _wb_module_state(task_type: TaskType, *, with_entities: bool = True):
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    updates = {"goal": module_state.goal.model_copy(update={"task_type": task_type})}
    if with_entities:
        updates["entity_states"] = build_wb_initial_entity_states()
    return module_state.model_copy(update=updates)


# ============================================================================
# Case G: invalid entity rejected BEFORE Tool execution
# ============================================================================


def test_case_g_invalid_entity_rejected_by_semantic_validation():
    skill_registry, _ = _wb_registries()
    module_state = _wb_module_state(TaskType.ANALYSIS)  # ASE99 deliberately never seeded -- not a real WB plant

    proposal = ObjectiveProposal(
        action=ObjectiveAction.ANALYZE, capability_key="wb.wip.hold_analysis",
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="ASE99"),
        scope=ObjectiveScope(time=TimeScope(kind=TimeScopeKind.SNAPSHOT_DATE, date=GOLDEN_DATE), filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE99")]),
        description="invalid plant", expected_output="status",
    )
    decision = PlannerDecision(decision=PlannerDecisionType.DISPATCH, next_objective=proposal, priority=1.0, rationale_summary="x")

    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=module_state, task_type=TaskType.ANALYSIS, skill_registry=skill_registry)


def test_case_g_rejection_is_not_a_tool_level_empty_result():
    """Distinguishes Case G from Case B (WB-2C item 33's own point): an
    unknown target is a semantic-validation failure, never a Tool query
    that merely returns []."""
    skill_registry, _ = _wb_registries()
    module_state = _wb_module_state(TaskType.ANALYSIS)

    proposal = ObjectiveProposal(
        action=ObjectiveAction.ANALYZE, capability_key="wb.wip.hold_analysis",
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="ASE99"),
        scope=ObjectiveScope(time=TimeScope(kind=TimeScopeKind.SNAPSHOT_DATE, date=GOLDEN_DATE), filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE99")]),
        description="invalid plant", expected_output="status",
    )
    decision = PlannerDecision(decision=PlannerDecisionType.DISPATCH, next_objective=proposal, priority=1.0, rationale_summary="x")

    try:
        validate_planner_decision(decision, module_state=module_state, task_type=TaskType.ANALYSIS, skill_registry=skill_registry)
        assert False, "expected PlannerSemanticValidationError"
    except PlannerSemanticValidationError as exc:
        assert "entity_states" in str(exc) or "does not exist" in str(exc)  # target-existence failure, not a query result


# ============================================================================
# Case H: missing required scope rejected BEFORE Tool execution, zero
# physical Tool calls
# ============================================================================


def test_case_h_missing_production_date_rejected_before_tool_execution():
    skill_registry, tool_registry = _wb_registries()
    module_state = _wb_module_state(TaskType.ANALYSIS)

    proposal = ObjectiveProposal(
        action=ObjectiveAction.COMPARE, capability_key="wb.output.comparison",
        target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="WB"),
        scope=None,  # no production_date at all
        description="missing date", expected_output="status",
    )
    decision = PlannerDecision(decision=PlannerDecisionType.DISPATCH, next_objective=proposal, priority=1.0, rationale_summary="x")

    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=module_state, task_type=TaskType.ANALYSIS, skill_registry=skill_registry)


def test_case_h_zero_physical_tool_calls_when_scope_validation_rejects():
    """The whole point of a pre-execution semantic gate: ToolExecutionManager
    is never even reached."""
    from agent.tools.execution_manager import InMemoryToolCallAuditSink, ToolExecutionManager

    skill_registry, tool_registry = _wb_registries()
    audit_sink = InMemoryToolCallAuditSink()
    manager = ToolExecutionManager(audit_sink=audit_sink)
    module_state = _wb_module_state(TaskType.ANALYSIS)

    proposal = ObjectiveProposal(
        action=ObjectiveAction.COMPARE, capability_key="wb.output.comparison",
        target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="WB"), scope=None,
        description="missing date", expected_output="status",
    )
    decision = PlannerDecision(decision=PlannerDecisionType.DISPATCH, next_objective=proposal, priority=1.0, rationale_summary="x")

    with pytest.raises(PlannerSemanticValidationError):
        validate_planner_decision(decision, module_state=module_state, task_type=TaskType.ANALYSIS, skill_registry=skill_registry)

    assert len(audit_sink.list_for_run(module_state.run_id)) == 0  # ToolExecutionManager never touched


# ============================================================================
# Case I: CapabilityResolver resolves uniquely, never bypassed
# ============================================================================


def test_case_i_capability_resolver_uniquely_resolves_wip_hold_analysis():
    skill_registry, tool_registry = _wb_registries()
    resolver = CapabilityResolver(skill_registry, tool_registry)
    module_state = _wb_module_state(TaskType.ANALYSIS)

    from agent.state.models import Objective

    objective = Objective(
        objective_id="obj-1", description="d", action=ObjectiveAction.ANALYZE, capability_key="wb.wip.hold_analysis",
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="ASE03"),
        scope=ObjectiveScope(time=TimeScope(kind=TimeScopeKind.SNAPSHOT_DATE, date=GOLDEN_DATE), filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE03")]),
        expected_output="status", priority_score=1.0,
    )

    resolved = resolver.resolve(objective, "wb", TaskType.ANALYSIS)

    assert resolved.selected_skill.skill_id == "wb.wip_hold_analysis"
    # never bypassable-equivalent to a raw SkillRegistry.get() -- resolution
    # depends on domain+task_type+action+capability_key all matching, not
    # just the skill_id string.
    assert resolved.selected_skill.capability_key == "wb.wip.hold_analysis"


def test_case_i_resolver_never_confuses_wip_hold_with_other_wb_analysis_skills():
    skill_registry, tool_registry = _wb_registries()
    resolver = CapabilityResolver(skill_registry, tool_registry)

    from agent.state.models import Objective

    objective = Objective(
        objective_id="obj-1", description="d", action=ObjectiveAction.ANALYZE, capability_key="wb.wip.hold_analysis",
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="ASE03"),
        scope=ObjectiveScope(time=TimeScope(kind=TimeScopeKind.SNAPSHOT_DATE, date=GOLDEN_DATE), filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE03")]),
        expected_output="status", priority_score=1.0,
    )
    resolved = resolver.resolve(objective, "wb", TaskType.ANALYSIS)
    assert resolved.selected_skill.skill_id not in {"wb.bank_aging_analysis", "wb.oee_status_analysis", "wb.output_comparison"}
