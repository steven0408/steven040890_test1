﻿"""Phase 6A: ModuleHandoffBuilder -- per-ModuleStatus handling (item 2),
against hand-built ModuleState fixtures (not requiring a full policy run to
hit e.g. a genuine PARTIAL/BLOCKED terminal state).
"""
from agent.state.enums import (
    BranchStatus,
    EntityAnalysisStatus,
    ErrorType,
    EvidenceQuality,
    FindingStatus,
    HypothesisStatus,
    ModuleStatus,
    ObjectiveAction,
    ObjectiveStatus,
    TargetRefType,
    TaskType,
)
from agent.state.models import (
    Branch,
    ErrorRecord,
    Evidence,
    Finding,
    Hypothesis,
    Limitation,
    ObjectiveRecord,
    RejectionRecord,
    TargetRef,
)
from agent.synthesis.handoff_builder import ModuleHandoffBuilder

from .conftest import make_module_state


def _with_task_type(state, task_type: TaskType):
    return state.model_copy(update={"goal": state.goal.model_copy(update={"task_type": task_type})})


def test_complete_with_confirmed_root_cause():
    state = make_module_state()  # task_type=RCA by default
    state = state.model_copy(
        update={
            "status": ModuleStatus.COMPLETE,
            "findings": [
                Finding(
                    finding_id="f1", statement="Motor Failure on EQ001 caused Availability loss.", entity_ids=["EQ001"],
                    pattern="Availability", supporting_evidence_ids=["ev1"], confidence=0.9,
                    status=FindingStatus.CONFIRMED, is_root_cause=True,
                )
            ],
        }
    )
    handoff = ModuleHandoffBuilder().build(state)

    assert handoff.module_status == ModuleStatus.COMPLETE
    assert len(handoff.confirmed_findings) == 1
    assert len(handoff.root_causes) == 1
    assert handoff.root_causes[0].statement == "Motor Failure on EQ001 caused Availability loss."
    assert handoff.executive_finding == "Motor Failure on EQ001 caused Availability loss."
    assert handoff.unresolved_questions == []


def test_complete_without_root_cause_analysis_task_type():
    state = _with_task_type(make_module_state(), TaskType.ANALYSIS)
    state = state.model_copy(
        update={
            "status": ModuleStatus.COMPLETE,
            "findings": [
                Finding(
                    finding_id="f1", statement="5 abnormal equipment found; Availability is the dominant pattern.",
                    pattern="Availability", confidence=0.8, status=FindingStatus.CONFIRMED, is_root_cause=False,
                )
            ],
        }
    )
    handoff = ModuleHandoffBuilder().build(state)

    assert handoff.root_causes == []
    assert len(handoff.confirmed_findings) == 1
    assert handoff.executive_finding == "5 abnormal equipment found; Availability is the dominant pattern."
    # ANALYSIS never asks the RCA "root cause not yet confirmed" question
    assert handoff.unresolved_questions == []


def test_partial_availability_confirmed_detail_unavailable():
    state = make_module_state()  # RCA
    state = state.model_copy(
        update={
            "status": ModuleStatus.PARTIAL,
            "findings": [
                Finding(
                    finding_id="f1", statement="Availability is the dominant loss pattern for EQ001/EQ003.",
                    pattern="Availability", confidence=0.7, status=FindingStatus.CONFIRMED, is_root_cause=False,
                )
            ],
            "limitations": [
                Limitation(
                    limitation_id="lim1", description="EQ001 downtime detail unavailable after exhausting sources.",
                    impacted_objective_id="obj-2", impact_statement="Cannot confirm exact failure mechanism.",
                    related_error=ErrorRecord(error_type=ErrorType.DATA_NOT_FOUND, message="source unavailable", objective_id="obj-2", occurred_at_step=2),
                )
            ],
        }
    )
    handoff = ModuleHandoffBuilder().build(state)

    assert handoff.module_status == ModuleStatus.PARTIAL
    assert len(handoff.confirmed_findings) == 1
    assert handoff.root_causes == []
    assert len(handoff.limitations) == 1
    assert handoff.limitations[0].related_error is not None  # a real data gap, not an authorization gap
    assert "Root cause not yet confirmed" in handoff.unresolved_questions[-1]
    assert "Partial" in handoff.executive_finding


def test_failed_never_surfaces_findings_even_if_present():
    state = make_module_state()
    state = state.model_copy(
        update={
            "status": ModuleStatus.FAILED,
            # even if a stray CONFIRMED finding somehow existed, FAILED must not present it as a reliable outcome
            "findings": [Finding(finding_id="f1", statement="should never surface", pattern="x", confidence=0.9, status=FindingStatus.CONFIRMED, is_root_cause=True)],
            "limitations": [Limitation(limitation_id="lim1", description="no data available at all", impacted_objective_id="obj-1", impact_statement="nothing could be gathered")],
        }
    )
    handoff = ModuleHandoffBuilder().build(state)

    assert handoff.confirmed_findings == []
    assert handoff.root_causes == []
    assert handoff.executive_finding == "No reliable finding produced for OEE."
    assert handoff.confidence == 0.0
    # limitations are still reported for FAILED (unlike SKIPPED) -- a
    # reader needs to know *why* it failed
    assert len(handoff.limitations) == 1


def test_blocked_separates_authorization_limitation_from_data_limitation():
    state = make_module_state()
    state = state.model_copy(
        update={
            "status": ModuleStatus.BLOCKED,
            "rejections": [RejectionRecord(objective_id="obj-2", permission_type="restricted_query", reason="operator denied access", alternative_found=False)],
            "limitations": [
                Limitation(
                    limitation_id="lim-data", description="EQ003 detail unavailable.", impacted_objective_id="obj-1",
                    impact_statement="data gap", related_error=ErrorRecord(error_type=ErrorType.DATA_NOT_FOUND, message="x", objective_id="obj-1", occurred_at_step=1),
                )
            ],
        }
    )
    handoff = ModuleHandoffBuilder().build(state)

    assert handoff.module_status == ModuleStatus.BLOCKED
    assert len(handoff.limitations) == 2
    auth_limitations = [lim for lim in handoff.limitations if lim.related_error is None]
    data_limitations = [lim for lim in handoff.limitations if lim.related_error is not None]
    assert len(auth_limitations) == 1
    assert len(data_limitations) == 1
    assert "Authorization" in auth_limitations[0].description
    assert "restricted_query" in auth_limitations[0].description
    assert "Authorization" in handoff.executive_finding


def test_blocked_with_alternative_found_has_no_authorization_limitation():
    state = make_module_state()
    state = state.model_copy(
        update={"status": ModuleStatus.BLOCKED, "rejections": [RejectionRecord(objective_id="obj-2", permission_type="x", reason="denied", alternative_found=True)]}
    )
    handoff = ModuleHandoffBuilder().build(state)
    assert handoff.limitations == []


def test_skipped_reports_no_execution_with_no_fabricated_content():
    state = make_module_state()
    state = state.model_copy(update={"status": ModuleStatus.SKIPPED})
    handoff = ModuleHandoffBuilder().build(state)

    assert handoff.confirmed_findings == []
    assert handoff.root_causes == []
    assert handoff.limitations == []
    assert handoff.unresolved_questions == []
    assert handoff.confidence == 0.0
    assert handoff.evidence_coverage == 0.0
    assert handoff.executive_finding == "OEE was not executed this run."


def test_open_hypotheses_become_unresolved_questions():
    state = make_module_state()
    state = state.model_copy(
        update={
            "status": ModuleStatus.PARTIAL,
            "hypotheses": [
                Hypothesis(hypothesis_id="h1", statement="Could also be Belt Wear.", status=HypothesisStatus.OPEN, confidence=0.4),
                Hypothesis(hypothesis_id="h2", statement="Refuted alternative.", status=HypothesisStatus.REFUTED, confidence=0.1),
            ],
        }
    )
    handoff = ModuleHandoffBuilder().build(state)
    assert len(handoff.hypotheses) == 1
    assert handoff.hypotheses[0].hypothesis_id == "h1"
    assert any("Could also be Belt Wear." in q for q in handoff.unresolved_questions)


def test_key_entities_prefers_entities_with_findings():
    from agent.state.models import EntityState

    state = make_module_state()
    state = state.model_copy(
        update={
            "status": ModuleStatus.COMPLETE,
            "entity_states": {
                "EQ001": EntityState(entity_id="EQ001", entity_type="EQUIPMENT", status=EntityAnalysisStatus.ROOT_CAUSE_FOUND, current_tree_node_id="n1", finding_ids=["f1"]),
                "EQ003": EntityState(entity_id="EQ003", entity_type="EQUIPMENT", status=EntityAnalysisStatus.INVESTIGATING, current_tree_node_id="n2", finding_ids=[]),
            },
        }
    )
    handoff = ModuleHandoffBuilder().build(state)
    assert handoff.key_entities == ["EQ001"]


def test_evidence_coverage_and_confidence_are_deterministic():
    state = make_module_state()
    state = state.model_copy(
        update={
            "status": ModuleStatus.COMPLETE,
            "objective_history": {
                "o1": ObjectiveRecord(objective_id="o1", description="d", action=ObjectiveAction.SCREEN, target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="OEE"), status=ObjectiveStatus.COMPLETED, created_step=1, attempt_count=1),
                "o2": ObjectiveRecord(objective_id="o2", description="d", action=ObjectiveAction.DRILL_DOWN, target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="EQ001"), status=ObjectiveStatus.COMPLETED, created_step=2, attempt_count=1),
            },
            "evidence": [Evidence(evidence_id="ev1", objective_id="o1", source_tool="x", summary="s", quality=EvidenceQuality.STRONG)],
            "findings": [Finding(finding_id="f1", statement="x", pattern="Availability", confidence=0.6, status=FindingStatus.CONFIRMED, is_root_cause=False)],
        }
    )
    handoff = ModuleHandoffBuilder().build(state)
    assert handoff.evidence_coverage == 0.5  # 1 evidence / 2 objectives
    assert handoff.confidence == 0.6


def test_branch_summary_is_sorted_by_priority_and_compact():
    state = make_module_state()
    state = state.model_copy(
        update={
            "status": ModuleStatus.RUNNING,
            "branches": {
                "b-low": Branch(branch_id="b-low", name="Quality", pattern="Quality", status=BranchStatus.PENDING, priority_score=0.2, tree_node_id="n2", entity_ids=["EQ009"]),
                "b-high": Branch(branch_id="b-high", name="Availability", pattern="Availability", status=BranchStatus.ACTIVE, priority_score=0.9, tree_node_id="n1", entity_ids=["EQ001"]),
            },
        }
    )
    handoff = ModuleHandoffBuilder().build(state)
    assert [b.branch_id for b in handoff.branch_summary] == ["b-high", "b-low"]
