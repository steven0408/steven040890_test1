"""Phase WB-2B.2: Objective Scope persistence/audit lineage closure --
`Objective.scope -> ObjectiveRecord.scope -> RunPersistenceWriter ->
InMemoryRunRepository/PostgreSQL -> historical query`. All offline; the
PostgreSQL-facing tests exercise `agent/persistence/postgres/mapping.py`
and `PostgresRunRepository` against `FakeConnection` only (no real DB --
the `@pytest.mark.postgres`-gated integration test stays skipped without
TEST_POSTGRES_DSN, unchanged from Phase 8B).
"""
from datetime import date, datetime, timezone

import pytest
from pydantic import ValidationError

from agent.capability.resolver import CapabilityResolver
from agent.domain.wb.synthetic import GOLDEN_DATE, SCENARIO_C_PLANT
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime, make_capability_module_executor
from agent.graph.nodes.module.module_planner import _build_dispatch_update
from agent.persistence.audit_repository import build_default_audit_repository
from agent.persistence.human_feedback import InMemoryHumanFeedbackSink
from agent.persistence.learning_repository import LearningCandidateRepository
from agent.learning.sink import InMemoryLearningCandidateSink
from agent.persistence.postgres import mapping as m
from agent.persistence.postgres.repositories import PostgresRunRepository
from agent.persistence.run_repository import InMemoryRunRepository
from agent.persistence.run_writer import RunPersistenceWriter
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.skills.wb.registration import register_wb_skills
from agent.state.enums import ObjectiveAction, ObjectiveStatus, RunTerminationStatus, TargetRefType, TaskType
from agent.state.models import Goal, GoalScope, Objective, ObjectiveRecord, TargetRef
from agent.state.payload import PayloadRegistry
from agent.state.scope import ObjectiveScope, ScopeFilter, ScopeOperator, TimeScope, TimeScopeKind
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry
from agent.tools.wb.registration import register_wb_tools
from tests.postgres_fake import FakeConnection

from .conftest import make_agent_state, make_module_state, make_wb_datasources

_TS = datetime(2026, 8, 12, tzinfo=timezone.utc)


def _base_record(**overrides) -> ObjectiveRecord:
    base = dict(
        objective_id="obj-1", description="d", action=ObjectiveAction.ANALYZE,
        target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="ASE03"),
        status=ObjectiveStatus.COMPLETED, created_step=1, attempt_count=1,
    )
    base.update(overrides)
    return ObjectiveRecord(**base)


# ============================================================================
# 1/2/3. ObjectiveRecord accepts ObjectiveScope; None vs empty scope
# ============================================================================


def test_objective_record_accepts_a_scope():
    scope = ObjectiveScope(filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE03")])
    record = _base_record(scope=scope)
    assert record.scope == scope


def test_none_scope_round_trips_as_none():
    record = _base_record(scope=None)
    restored = ObjectiveRecord.model_validate_json(record.model_dump_json())
    assert restored.scope is None


def test_empty_scope_round_trips_distinct_from_none():
    """`ObjectiveScope()` (all fields default/empty) is a real, present
    value -- NOT collapsed to None by this model's own semantics (Phase
    WB-2B.2 item L)."""
    empty_scope = ObjectiveScope()
    record = _base_record(scope=empty_scope)
    assert record.scope is not None
    assert record.scope != None  # noqa: E711 -- explicit: scope is a real ObjectiveScope, not falsy-None
    restored = ObjectiveRecord.model_validate_json(record.model_dump_json())
    assert restored.scope is not None
    assert restored.scope == empty_scope
    assert restored.scope.time is None
    assert restored.scope.filters == []


def test_default_objective_record_has_no_scope():
    """A record constructed the old way (no `scope=` kwarg at all) --
    proves the new field is additive/optional, never required."""
    record = _base_record()
    assert record.scope is None


# ============================================================================
# 4-13. TimeScope / ScopeFilter / group_by round-trips (pure Python level)
# ============================================================================


def _round_trip(record: ObjectiveRecord) -> ObjectiveRecord:
    return ObjectiveRecord.model_validate_json(record.model_dump_json())


def test_production_date_scope_round_trip():
    scope = ObjectiveScope(time=TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, date=date(2026, 8, 12)))
    restored = _round_trip(_base_record(scope=scope))
    assert restored.scope.time.kind == TimeScopeKind.PRODUCTION_DATE
    assert restored.scope.time.date == date(2026, 8, 12)


def test_snapshot_date_scope_round_trip():
    scope = ObjectiveScope(time=TimeScope(kind=TimeScopeKind.SNAPSHOT_DATE, date=date(2026, 8, 12)))
    restored = _round_trip(_base_record(scope=scope))
    assert restored.scope.time.kind == TimeScopeKind.SNAPSHOT_DATE


def test_date_range_scope_round_trip():
    scope = ObjectiveScope(time=TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, start=date(2026, 8, 6), end=date(2026, 8, 12)))
    restored = _round_trip(_base_record(scope=scope))
    assert restored.scope.time.start == date(2026, 8, 6)
    assert restored.scope.time.end == date(2026, 8, 12)
    assert restored.scope.time.date is None


def test_eq_filter_round_trip():
    scope = ObjectiveScope(filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE03")])
    restored = _round_trip(_base_record(scope=scope))
    assert restored.scope.filters[0].operator == ScopeOperator.EQ
    assert restored.scope.filters[0].value == "ASE03"


def test_in_filter_round_trip():
    scope = ObjectiveScope(filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.IN, value=["ASE01", "ASE07"])])
    restored = _round_trip(_base_record(scope=scope))
    assert restored.scope.filters[0].operator == ScopeOperator.IN
    assert restored.scope.filters[0].value == ["ASE01", "ASE07"]


def test_multiple_filters_round_trip():
    scope = ObjectiveScope(filters=[
        ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE03"),
        ScopeFilter(dimension="operation", operator=ScopeOperator.EQ, value="2800"),
    ])
    restored = _round_trip(_base_record(scope=scope))
    assert len(restored.scope.filters) == 2
    assert {f.dimension for f in restored.scope.filters} == {"plant", "operation"}


def test_group_by_round_trip():
    scope = ObjectiveScope(group_by=["plant", "status"])
    restored = _round_trip(_base_record(scope=scope))
    assert restored.scope.group_by == ["plant", "status"]


def test_combined_time_filters_group_by_round_trip():
    """The Phase WB-2B.2 prompt's own worked example."""
    scope = ObjectiveScope(
        time=TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, date=date(2026, 8, 12)),
        filters=[
            ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE03"),
            ScopeFilter(dimension="operation", operator=ScopeOperator.EQ, value="2800"),
        ],
        group_by=["plant"],
    )
    record = _base_record(scope=scope)
    restored = _round_trip(record)
    assert restored.scope == scope
    assert restored == record


def test_operation_opaque_dimension_round_trip():
    """Item S: persistence must be able to store `dimension="operation"`
    even though no Tool currently consumes it for wb.wip_hold_analysis --
    that's a future Tool-capability question, not a persistence gap."""
    scope = ObjectiveScope(filters=[ScopeFilter(dimension="operation", operator=ScopeOperator.EQ, value="2800")])
    restored = _round_trip(_base_record(scope=scope))
    assert restored.scope.filters[0].dimension == "operation"


def test_unknown_custom_opaque_dimension_round_trip():
    """Core persistence has no opinion on dimension names -- a brand-new
    domain's never-before-seen dimension must still round-trip cleanly."""
    scope = ObjectiveScope(filters=[ScopeFilter(dimension="product_family", operator=ScopeOperator.EQ, value="XYZ-9000")])
    restored = _round_trip(_base_record(scope=scope))
    assert restored.scope.filters[0].dimension == "product_family"
    assert restored.scope.filters[0].value == "XYZ-9000"


# ============================================================================
# 14. PostgreSQL mapping to_row / from_row
# ============================================================================


def test_postgres_mapping_objective_scope_round_trip():
    scope = ObjectiveScope(
        time=TimeScope(kind=TimeScopeKind.SNAPSHOT_DATE, date=date(2026, 8, 12)),
        filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE03")],
        group_by=["plant"],
    )
    record = _base_record(scope=scope, capability_key="wb.wip.hold_analysis")
    row = m.objective_to_row("run-1", "WB", record)
    assert row["scope"] == scope.model_dump(mode="json")  # psycopg not installed in this test env -- _jsonb() degrades to a plain dict
    assert row["capability_key"] == "wb.wip.hold_analysis"
    restored = m.objective_from_row(row)
    assert restored == record


def test_postgres_mapping_none_scope_stays_null():
    record = _base_record(scope=None)
    row = m.objective_to_row("run-1", "OEE", record)
    assert row["scope"] is None
    restored = m.objective_from_row(row)
    assert restored.scope is None


def test_postgres_mapping_empty_scope_is_not_null():
    record = _base_record(scope=ObjectiveScope())
    row = m.objective_to_row("run-1", "OEE", record)
    assert row["scope"] is not None  # a real (empty) dict, never coerced to NULL
    restored = m.objective_from_row(row)
    assert restored.scope == ObjectiveScope()


# ============================================================================
# 15/16. InMemoryRunRepository save/get + duplicate idempotency
# ============================================================================


def test_in_memory_run_repository_save_and_list_preserves_scope():
    repo = InMemoryRunRepository()
    scope = ObjectiveScope(time=TimeScope(kind=TimeScopeKind.SNAPSHOT_DATE, date=date(2026, 8, 12)), filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE03")])
    record = _base_record(scope=scope, capability_key="wb.wip.hold_analysis")
    repo.save_objective("run-1", "WB", record)

    reloaded = repo.list_objectives("run-1")
    assert len(reloaded) == 1
    assert reloaded[0].scope == scope
    assert reloaded[0].capability_key == "wb.wip.hold_analysis"


def test_duplicate_persistence_is_idempotent_not_a_double_write():
    repo = InMemoryRunRepository()
    scope = ObjectiveScope(filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE03")])
    record = _base_record(scope=scope)
    repo.save_objective("run-1", "WB", record)
    repo.save_objective("run-1", "WB", record)  # simulates a checkpoint-replay re-save
    assert len(repo.list_objectives("run-1")) == 1
    assert repo.list_objectives("run-1")[0].scope == scope


# ============================================================================
# PostgresRunRepository (FakeConnection) -- SQL construction + reload simulation
# ============================================================================


def test_postgres_repository_save_objective_includes_scope_and_capability_key_columns():
    """Regression: Phase WB-2B.1 added `capability_key`/`scope` to
    `objective_to_row`/the SQL schema but NOT to `_OBJECTIVE_COLUMNS` --
    the real upsert SQL silently never wrote them. Fixed this phase."""
    conn = FakeConnection()
    repo = PostgresRunRepository(conn)
    scope = ObjectiveScope(time=TimeScope(kind=TimeScopeKind.SNAPSHOT_DATE, date=date(2026, 8, 12)), filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE03")])
    record = _base_record(scope=scope, capability_key="wb.wip.hold_analysis")

    repo.save_objective("run-1", "WB", record)

    sql, params = conn.executed[0]
    assert "capability_key" in sql
    assert "scope" in sql
    assert params["capability_key"] == "wb.wip.hold_analysis"
    assert params["scope"] is not None


def test_postgres_repository_reload_simulation_preserves_scope():
    """FakeConnection doesn't interpret SQL -- simulate "reload" by feeding
    the exact params a real INSERT would have written back as the SELECT
    result, proving `list_objectives` reconstructs the same ObjectiveRecord."""
    conn = FakeConnection()
    repo = PostgresRunRepository(conn)
    scope = ObjectiveScope(
        time=TimeScope(kind=TimeScopeKind.SNAPSHOT_DATE, date=date(2026, 8, 12)),
        filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE03")],
        group_by=["plant"],
    )
    record = _base_record(scope=scope, capability_key="wb.wip.hold_analysis")
    repo.save_objective("run-1", "WB", record)
    _, written_params = conn.executed[0]

    conn.set_fetchall([written_params])
    reloaded = repo.list_objectives("run-1")

    assert len(reloaded) == 1
    assert reloaded[0] == record
    assert reloaded[0].scope == scope


def test_planner_decision_record_repository_includes_proposed_capability_key_column():
    """Same regression class as the objective one above, for planner_decisions."""
    from agent.llm.models import DecisionSource
    from agent.llm.prompts.planner import PlannerDecisionType
    from agent.persistence.postgres.repositories import PostgresPlannerDecisionAuditSink
    from agent.planning.decision_audit import PlannerDecisionRecord

    conn = FakeConnection()
    sink = PostgresPlannerDecisionAuditSink(conn)
    record = PlannerDecisionRecord(
        decision_record_id="pd-1", run_id="run-1", module_id="WB", step=1, decision=PlannerDecisionType.DISPATCH,
        proposed_action=ObjectiveAction.ANALYZE, proposed_capability_key="wb.wip.hold_analysis",
        source=DecisionSource.LLM, rationale_summary="x", created_at=_TS,
    )
    sink.record(record)
    sql, params = conn.executed[0]
    assert "proposed_capability_key" in sql
    assert params["proposed_capability_key"] == "wb.wip.hold_analysis"


# ============================================================================
# 17. RunPersistenceWriter preserves scope exactly (no re-derivation)
# ============================================================================


def _writer():
    run_repo = InMemoryRunRepository()
    audit_repo = build_default_audit_repository()
    feedback_sink = InMemoryHumanFeedbackSink()
    learning_repo = LearningCandidateRepository(InMemoryLearningCandidateSink())
    writer = RunPersistenceWriter(run_repo, audit_repo, feedback_sink, learning_repo)
    return writer, run_repo


def test_run_persistence_writer_never_re_derives_scope_pure_projection():
    """Builds an ObjectiveRecord with an ARBITRARY, deliberately-unusual
    scope (nothing a real WB Objective would produce) and confirms the
    writer reproduces it byte-for-byte -- proving it's a projection, never
    an interpretation/re-derivation (item G)."""
    writer, run_repo = _writer()
    scope = ObjectiveScope(
        time=TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, start=date(2026, 1, 1), end=date(2026, 12, 31)),
        filters=[ScopeFilter(dimension="totally_custom_dimension", operator=ScopeOperator.IN, value=["a", "b", "c"])],
        group_by=["whatever"],
    )
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-scope")
    module_state = module_state.model_copy(update={
        "objective_history": {"obj-x": _base_record(objective_id="obj-x", scope=scope)},
    })
    state = make_agent_state(run_id="run-scope").model_copy(update={
        "module_states": {"WB": module_state},
        "global_goal": Goal(goal_id="g1", raw_statement="x", normalized_statement="x", task_type=TaskType.ANALYSIS, scope=GoalScope()),
        "termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS,
    })

    writer.persist_run(state)

    reloaded = run_repo.list_objectives("run-scope")
    assert len(reloaded) == 1
    assert reloaded[0].scope == scope  # exact, unmodified projection


# ============================================================================
# 18. WB WIP Hold end-to-end: Objective -> Skill -> Tool -> Evidence -> Persistence -> Reload
# ============================================================================


def test_wb_wip_hold_full_lineage_objective_to_evidence_to_persistence_reload():
    """Item J's mandated Case: proves semantic query intent -> execution ->
    historical persistence has no broken link. NOT re-testing the Hold
    calculation itself (already covered by WB-2A/2B tests) -- the point
    here is that the reloaded ObjectiveRecord.scope, after a full
    Skill/Tool/Evidence round trip and a real persistence write+reload,
    still matches exactly what was dispatched, and Evidence still points
    at the same objective_id."""
    tool_registry = ToolRegistry()
    register_wb_tools(tool_registry, datasources=make_wb_datasources())
    skill_registry = SkillRegistry()
    register_wb_skills(skill_registry)
    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    runtime = ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)

    scope = ObjectiveScope(
        time=TimeScope(kind=TimeScopeKind.SNAPSHOT_DATE, date=GOLDEN_DATE),
        filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value=SCENARIO_C_PLANT)],
    )
    objective = Objective(
        objective_id="WB-obj-1", description="ASE03 WIP Hold status", action=ObjectiveAction.ANALYZE,
        capability_key="wb.wip.hold_analysis", target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id=SCENARIO_C_PLANT),
        scope=scope, expected_output="hold status", priority_score=1.0,
    )

    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-lineage")
    module_state = module_state.model_copy(update={"goal": module_state.goal.model_copy(update={"task_type": TaskType.ANALYSIS})})

    # Module Planner's real dispatch projection (agent/graph/nodes/module/module_planner.py)
    dispatch_update = _build_dispatch_update(module_state, objective)
    module_state = module_state.model_copy(update=dispatch_update)
    dispatched_record = module_state.objective_history["WB-obj-1"]
    assert dispatched_record.scope == scope  # dispatched correctly, before any execution

    # Module Executor's real capability-routed execution (agent/graph/nodes/module/capability_executor.py)
    executor = make_capability_module_executor(runtime)
    exec_update = executor(module_state)
    module_state = module_state.model_copy(update=exec_update)

    assert len(module_state.evidence) == 1
    evidence = module_state.evidence[0]
    assert evidence.objective_id == "WB-obj-1"
    payload = PayloadRegistry.unpack(evidence.structured_payload)
    assert payload.hold_lot_count == 22
    assert payload.total_lot_count == 30
    assert abs(payload.hold_ratio - (22 / 30)) < 1e-9

    # Persist the whole run, then reload from the repository -- the historical query path.
    writer, run_repo = _writer()
    state = make_agent_state(run_id="run-lineage").model_copy(update={
        "module_states": {"WB": module_state},
        "global_goal": Goal(goal_id="g1", raw_statement="ASE03 hold?", normalized_statement="ASE03 hold status", task_type=TaskType.ANALYSIS, scope=GoalScope()),
        "termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS,
    })
    writer.persist_run(state)

    reloaded_objectives = run_repo.list_objectives("run-lineage")
    assert len(reloaded_objectives) == 1
    reloaded = reloaded_objectives[0]
    assert reloaded.capability_key == "wb.wip.hold_analysis"
    assert reloaded.action == ObjectiveAction.ANALYZE
    assert reloaded.scope.time.kind == TimeScopeKind.SNAPSHOT_DATE
    assert reloaded.scope.time.date == GOLDEN_DATE
    assert reloaded.scope.filters[0].dimension == "plant"
    assert reloaded.scope.filters[0].value == SCENARIO_C_PLANT

    reloaded_evidence = run_repo.list_evidence("run-lineage")
    assert len(reloaded_evidence) == 1
    assert reloaded_evidence[0].objective_id == reloaded.objective_id == "WB-obj-1"  # lineage intact end to end


# ============================================================================
# 19. Old OEE objective without scope -- regression
# ============================================================================


def test_old_oee_objective_without_scope_persists_and_reloads_unaffected():
    from .conftest import run_oee_module_state_history

    history = run_oee_module_state_history(TaskType.RCA)
    final = history[-1]
    writer, run_repo = _writer()
    state = make_agent_state(run_id="run-oee-regress").model_copy(update={
        "module_states": {"OEE": final},
        "global_goal": Goal(goal_id="g1", raw_statement="x", normalized_statement="x", task_type=TaskType.RCA, scope=GoalScope()),
        "termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS,
    })

    writer.persist_run(state)

    reloaded = run_repo.list_objectives("run-oee-regress")
    assert len(reloaded) == len(final.objective_history)
    assert all(r.scope is None for r in reloaded)  # OEE never sets scope -- must not break or get a fabricated value
    assert any(r.capability_key == "oee.equipment_screening" for r in reloaded)  # capability_key (WB-2B.1) still round-trips too


# ============================================================================
# 20. Security/type validation remains intact through persistence
# ============================================================================


def test_scope_filter_value_stays_inert_data_through_persistence_not_reinterpreted():
    """A ScopeFilter.value containing SQL-injection-shaped text must
    survive persistence as an inert string -- never parsed/executed,
    never used to build a WHERE clause (item M/N)."""
    dangerous_value = "ASE03'; DROP TABLE objectives; --"
    scope = ObjectiveScope(filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value=dangerous_value)])
    record = _base_record(scope=scope)

    row = m.objective_to_row("run-1", "WB", record)
    assert row["scope"]["filters"][0]["value"] == dangerous_value  # stored verbatim as JSON string data

    restored = m.objective_from_row(row)
    assert restored.scope.filters[0].value == dangerous_value  # round-trips unchanged, never executed


def test_scope_filter_still_rejects_non_scalar_value_after_persistence_changes():
    """Regression guard: this phase's persistence work must not have
    loosened ScopeFilter's own EQ/IN value-shape validator."""
    with pytest.raises(ValidationError):
        ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value=["not", "a", "scalar"])


def test_no_scope_to_sql_where_clause_converter_exists_in_this_codebase():
    """Item N's explicit boundary -- confirms no generic scope->SQL
    translator was added anywhere in the persistence layer this phase."""
    import ast
    from pathlib import Path

    persistence_dir = Path(__file__).resolve().parents[1] / "agent" / "persistence"
    for path in persistence_dir.rglob("*.py"):
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and "where" in node.name.lower() and "scope" in node.name.lower():
                pytest.fail(f"found a scope->WHERE-clause-shaped function: {path}::{node.name}")
