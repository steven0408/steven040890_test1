"""Phase WB-2B.1/WB-2C: WB Skill loading -- markdown parsing/schema
validation, required_tools/optional_tools resolution against a
ToolRegistry (including the fail-fast MissingToolForSkillError path),
capability_key/scope metadata shape, and enable/disable ("removal")
semantics. All offline -- no real API/DB/LLM; loads only from the real
`agent/skills/wb/*.md` files on disk.

Phase WB-2C inventory correction: an earlier report (WB-2B) listed 8
skills; WB-2B.1's consolidation reduced this to 7 (merging
`wb.oee_plant_status` into `wb.oee_status_analysis`). Implementing this
phase's own Golden Cases A (single-plant OEE lookup) and B (module-wide
OEE ranking) concretely proved that ONE skill cannot serve both: a
Skill's `parameter_mapping` cannot conditionally include/omit `plant_id`
depending on whether the Objective happens to supply one. `wb.oee_plant_status`
was therefore revived (entity-scoped, INFORMATION) alongside
`wb.oee_status_analysis` (module-wide, ANALYSIS) -- back to 8, for a
functional reason discovered while implementing WB-2C's own examples,
not to match the stale WB-2B count. See the Phase WB-2C report.
"""
import pytest

from agent.skills.models import SkillType
from agent.skills.registry import DuplicateSkillError, MissingToolForSkillError, SkillNotFoundError, SkillRegistry
from agent.skills.wb.registration import WB_SKILLS_DIR, register_wb_skills
from agent.state.enums import TargetRefType
from agent.tools.registry import ToolRegistry
from agent.tools.wb.registration import register_wb_tools

from .conftest import make_wb_datasources

_EXPECTED_SKILL_IDS = {
    "wb.oee_plant_status", "wb.oee_status_analysis",
    "wb.bank_status_summary", "wb.bank_aging_analysis",
    "wb.wip_status_summary", "wb.wip_hold_analysis",
    "wb.output_status_summary", "wb.output_comparison",
    "wb.issue_status_summary", "wb.issue_trend_analysis",  # Phase WB-3A
    # Phase WB-3B: historical trend + first cross-source skill
    "wb.oee_trend_analysis", "wb.wip_hold_trend_analysis",
    "wb.bank_shortage_trend_analysis", "wb.output_trend_analysis",
    "wb.issue_output_relationship_analysis",
}

_EXPECTED_CAPABILITY_KEYS = {
    "wb.oee_plant_status": "wb.oee.plant_status",
    "wb.oee_status_analysis": "wb.oee.status_analysis",
    "wb.bank_status_summary": "wb.bank.status_summary",
    "wb.bank_aging_analysis": "wb.bank.aging_analysis",
    "wb.wip_status_summary": "wb.wip.status_summary",
    "wb.wip_hold_analysis": "wb.wip.hold_analysis",
    "wb.output_status_summary": "wb.output.status_summary",
    "wb.output_comparison": "wb.output.comparison",
    "wb.issue_status_summary": "wb.issue.status_summary",
    "wb.issue_trend_analysis": "wb.issue.trend_analysis",
    "wb.oee_trend_analysis": "wb.oee.trend_analysis",
    "wb.wip_hold_trend_analysis": "wb.wip.hold_trend_analysis",
    "wb.bank_shortage_trend_analysis": "wb.bank.shortage_trend_analysis",
    "wb.output_trend_analysis": "wb.output.trend_analysis",
    "wb.issue_output_relationship_analysis": "wb.issue_output.relationship_analysis",
}

# Skills whose parameter_mapping genuinely reads objective.scope -- the
# rest are module-wide and never touch scope/target_ref at all.
_SCOPED_SKILLS = {
    "wb.oee_plant_status", "wb.oee_status_analysis", "wb.bank_status_summary", "wb.wip_hold_analysis", "wb.output_comparison",
    "wb.issue_status_summary", "wb.issue_trend_analysis",
    "wb.oee_trend_analysis", "wb.wip_hold_trend_analysis", "wb.bank_shortage_trend_analysis",
    "wb.output_trend_analysis", "wb.issue_output_relationship_analysis",
}
_ENTITY_SCOPED_SKILLS = {
    "wb.oee_plant_status", "wb.bank_status_summary", "wb.wip_hold_analysis", "wb.issue_status_summary", "wb.issue_trend_analysis",
    "wb.oee_trend_analysis", "wb.wip_hold_trend_analysis", "wb.bank_shortage_trend_analysis",
    "wb.output_trend_analysis", "wb.issue_output_relationship_analysis",
}


def _wb_tool_registry() -> ToolRegistry:
    registry = ToolRegistry()
    register_wb_tools(registry, datasources=make_wb_datasources())
    return registry


def test_register_wb_skills_loads_all_15_skill_files():
    registry = SkillRegistry()
    loaded = register_wb_skills(registry)
    assert {s.skill_id for s in loaded} == _EXPECTED_SKILL_IDS


def test_wb_skills_directory_contains_exactly_15_markdown_files():
    assert sorted(p.name for p in WB_SKILLS_DIR.glob("*.md")) == sorted(
        f"{skill_id.split('.', 1)[1]}.md" for skill_id in _EXPECTED_SKILL_IDS
    )


def test_all_wb_skills_are_execution_type_and_wb_domain():
    registry = SkillRegistry()
    register_wb_skills(registry)
    for skill in registry.list():
        assert skill.skill_type == SkillType.EXECUTION
        assert skill.domains == ["wb"]
        assert skill.enabled is True


def test_every_wb_skill_has_exactly_one_step_and_matching_required_tool():
    """Confirms the Tool Design Review finding (Phase WB-2B): WB Tools are
    independently self-querying (never consume a previous step's `prev.`
    output), so every WB Skill is a single-step wrapper."""
    registry = SkillRegistry()
    register_wb_skills(registry)
    for skill in registry.list():
        assert len(skill.steps) == 1
        assert skill.required_tools == [skill.steps[0].tool_id]
        assert skill.optional_tools == []  # no conditional-step runtime exists (Phase WB-2B finding)


def test_every_wb_skill_has_a_unique_namespaced_capability_key():
    registry = SkillRegistry()
    register_wb_skills(registry)
    keys = {s.skill_id: s.capability_key for s in registry.list()}
    assert keys == _EXPECTED_CAPABILITY_KEYS
    # namespaced wb.<source>.<capability>, never bare/global
    for key in keys.values():
        assert key.startswith("wb.")
        assert key.count(".") == 2


def test_task_types_split_information_vs_analysis():
    """Item 10: capability metadata alone must let a future Planner tell
    INFORMATION apart from ANALYSIS, without building a Planner this phase."""
    from agent.state.enums import TaskType

    registry = SkillRegistry()
    register_wb_skills(registry)
    information_skills = {s.skill_id for s in registry.list() if TaskType.INFORMATION in s.task_types}
    analysis_skills = {s.skill_id for s in registry.list() if TaskType.ANALYSIS in s.task_types}
    assert information_skills == {"wb.oee_plant_status", "wb.bank_status_summary", "wb.wip_status_summary", "wb.output_status_summary", "wb.issue_status_summary"}
    assert analysis_skills == {
        "wb.oee_status_analysis", "wb.bank_aging_analysis", "wb.wip_hold_analysis", "wb.output_comparison", "wb.issue_trend_analysis",
        "wb.oee_trend_analysis", "wb.wip_hold_trend_analysis", "wb.bank_shortage_trend_analysis",
        "wb.output_trend_analysis", "wb.issue_output_relationship_analysis",
    }
    assert information_skills.isdisjoint(analysis_skills)


def test_scoped_skills_declare_required_scope_dimensions_subset_of_accepted():
    registry = SkillRegistry()
    register_wb_skills(registry)
    for skill in registry.list():
        if skill.skill_id in _SCOPED_SKILLS:
            assert skill.required_scope_dimensions  # non-empty
            assert set(skill.required_scope_dimensions) <= set(skill.accepted_scope_dimensions)
        else:
            assert skill.required_scope_dimensions == []
            assert skill.accepted_scope_dimensions == []


def test_entity_scoped_skills_declare_expected_target_ref_type_entity():
    registry = SkillRegistry()
    register_wb_skills(registry)
    for skill in registry.list():
        expected = TargetRefType.ENTITY if skill.skill_id in _ENTITY_SCOPED_SKILLS else TargetRefType.MODULE
        assert skill.expected_target_ref_type == expected


def test_oee_status_analysis_never_maps_plant_module_wide_only():
    """The Case A/B split's own regression guard: wb.oee_status_analysis
    (module-wide ranking) must never require or accept a plant filter --
    that's wb.oee_plant_status's job."""
    registry = SkillRegistry()
    register_wb_skills(registry)
    skill = registry.get("wb.oee_status_analysis")
    assert "plant" not in skill.accepted_scope_dimensions
    assert "plant_id" not in skill.steps[0].parameter_mapping


def test_validate_required_tools_passes_when_all_wb_tools_registered():
    skill_registry = SkillRegistry()
    register_wb_skills(skill_registry)
    tool_registry = _wb_tool_registry()
    skill_registry.validate_required_tools(tool_registry)  # must not raise


def test_validate_required_tools_fails_fast_when_a_required_tool_is_missing():
    skill_registry = SkillRegistry()
    register_wb_skills(skill_registry)
    empty_tool_registry = ToolRegistry()  # no WB tools registered at all
    with pytest.raises(MissingToolForSkillError):
        skill_registry.validate_required_tools(empty_tool_registry)


def test_registering_same_skill_twice_raises_duplicate_error():
    registry = SkillRegistry()
    register_wb_skills(registry)
    with pytest.raises(DuplicateSkillError):
        register_wb_skills(registry)


def test_unregistered_skill_id_raises_skill_not_found():
    registry = SkillRegistry()
    register_wb_skills(registry)
    with pytest.raises(SkillNotFoundError):
        registry.get("wb.does_not_exist")


# ============================================================================
# Skill removal / disable semantics
# ============================================================================


def test_disabled_skill_excluded_from_default_listing_but_still_resolvable_by_id():
    registry = SkillRegistry()
    loaded = register_wb_skills(registry)
    original = registry.get("wb.wip_hold_analysis")
    disabled_registry = SkillRegistry()
    for skill in loaded:
        definition = skill.model_copy(update={"enabled": False}) if skill.skill_id == original.skill_id else skill
        disabled_registry.register(definition)

    assert "wb.wip_hold_analysis" not in {s.skill_id for s in disabled_registry.list()}
    assert "wb.wip_hold_analysis" in {s.skill_id for s in disabled_registry.list(enabled_only=False)}
    assert disabled_registry.get("wb.wip_hold_analysis").enabled is False


def test_removing_one_wb_skill_leaves_the_others_fully_functional():
    """Proves no hidden coupling between WB skills."""
    registry = SkillRegistry()
    loaded = register_wb_skills(registry)
    reduced = SkillRegistry()
    for skill in loaded:
        if skill.skill_id != "wb.oee_status_analysis":
            reduced.register(skill)

    tool_registry = _wb_tool_registry()
    reduced.validate_required_tools(tool_registry)  # still resolves fine without the removed skill
    assert len(reduced.list()) == 14
    assert "wb.oee_status_analysis" not in {s.skill_id for s in reduced.list()}
