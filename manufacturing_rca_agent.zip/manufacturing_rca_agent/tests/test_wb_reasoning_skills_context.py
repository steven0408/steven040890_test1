"""Phase WB-3E item AA: the 7 new WB-scoped reasoning skills
(`agent/skills/reasoning/*.md`) actually load, and actually get
retrieved (or correctly excluded) through the real `PlannerContextBuilder`
+ `DeterministicReasoningSkillRetriever` pipeline for real WB module
states -- relevant included, irrelevant excluded, budget trimming works.
Loads the REAL global reasoning directory (the same one `AppConfig`'s
own default `skill_directories` points at), not an isolated fixture
registry -- this is deliberately an integration-level test of the actual
shipped files, not just their frontmatter shape. All offline.
"""
from pathlib import Path

from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
from agent.llm.context.evidence_selector import DeterministicEvidenceSelector
from agent.llm.context.planner_context import PlannerContextBudget, PlannerContextBuilder
from agent.llm.context.reasoning_skill_retriever import DeterministicReasoningSkillRetriever
from agent.skills.models import SkillType
from agent.skills.registry import SkillRegistry
from agent.skills.wb.registration import WB_SKILLS_DIR
from agent.state.enums import TaskType

from .conftest import make_module_state

_REASONING_DIR = Path(__file__).resolve().parent.parent / "agent" / "skills" / "reasoning"

_NEW_WB_REASONING_SKILL_IDS = {
    "reasoning.wb_manufacturing_flow_reasoning",
    "reasoning.historical_recurrence_reasoning",
    "reasoning.cross_source_evidence_reasoning",
    "reasoning.causal_inference_guard",
    "reasoning.data_quality_aware_reasoning",
    "reasoning.alternative_hypothesis_reasoning",
    "reasoning.analysis_stopping_reasoning",
}


def _wb_skill_registry() -> SkillRegistry:
    registry = SkillRegistry()
    registry.load_directory(_REASONING_DIR)
    registry.load_directory(WB_SKILLS_DIR)
    return registry


def _wb_module_state(task_type: TaskType):
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    return module_state.model_copy(update={"goal": module_state.goal.model_copy(update={"task_type": task_type})})


def _oee_module_state(task_type: TaskType):
    module_state = make_module_state(module_id="OEE", module_type="OEE", run_id="run-1")
    return module_state.model_copy(update={"goal": module_state.goal.model_copy(update={"task_type": task_type})})


def _builder(skill_registry: SkillRegistry, budget: PlannerContextBudget | None = None) -> PlannerContextBuilder:
    return PlannerContextBuilder(
        DeterministicEvidenceSelector(), DeterministicCapabilityRetriever(skill_registry),
        reasoning_skill_retriever=DeterministicReasoningSkillRetriever(skill_registry),
    )


# ============================================================================
# Load smoke -- all 7 new files parse as valid REASONING skills.
# ============================================================================


def test_all_7_new_wb_reasoning_skills_load_as_reasoning_type():
    registry = SkillRegistry()
    registry.load_directory(_REASONING_DIR)
    reasoning_skills = {s.skill_id: s for s in registry.list(skill_type=SkillType.REASONING)}
    for skill_id in _NEW_WB_REASONING_SKILL_IDS:
        assert skill_id in reasoning_skills
        assert reasoning_skills[skill_id].domains == ["wb"]
        assert reasoning_skills[skill_id].skill_type == SkillType.REASONING
        # structurally forbidden fields (item T's own "not a workflow" rule,
        # enforced at the schema level by SkillDefinition's own validator)
        assert reasoning_skills[skill_id].steps == []
        assert reasoning_skills[skill_id].required_tools == []
        assert reasoning_skills[skill_id].capability_key is None


def test_plant_manager_perspective_still_loads_universal():
    registry = SkillRegistry()
    registry.load_directory(_REASONING_DIR)
    skill = registry.get("reasoning.plant_manager_perspective")
    assert skill.domains == []
    assert skill.task_types == []


# ============================================================================
# Relevant included -- WB RCA/ANALYSIS planner calls retrieve WB-scoped
# reasoning skills.
# ============================================================================


def test_wb_rca_planner_context_includes_wb_reasoning_skills():
    registry = _wb_skill_registry()
    outcome = _builder(registry).build(_wb_module_state(TaskType.RCA), run_id="run-1")
    retrieved_ids = {s.skill_id for s in outcome.context.relevant_reasoning_skills}
    # at least some genuinely WB-scoped RCA skills made it in (budget=6 for RCA)
    assert retrieved_ids & _NEW_WB_REASONING_SKILL_IDS


def test_wb_analysis_planner_context_includes_wb_reasoning_skills():
    registry = _wb_skill_registry()
    outcome = _builder(registry).build(_wb_module_state(TaskType.ANALYSIS), run_id="run-1")
    retrieved_ids = {s.skill_id for s in outcome.context.relevant_reasoning_skills}
    assert retrieved_ids & _NEW_WB_REASONING_SKILL_IDS


# ============================================================================
# Irrelevant excluded.
# ============================================================================


def test_wb_information_planner_context_excludes_all_new_wb_reasoning_skills():
    """None of the 7 new skills declare `task_types` including INFORMATION
    -- an INFORMATION-tier WB call must never see them."""
    registry = _wb_skill_registry()
    outcome = _builder(registry).build(_wb_module_state(TaskType.INFORMATION), run_id="run-1")
    retrieved_ids = {s.skill_id for s in outcome.context.relevant_reasoning_skills}
    assert retrieved_ids.isdisjoint(_NEW_WB_REASONING_SKILL_IDS)


def test_oee_planner_context_excludes_wb_scoped_reasoning_skills():
    """domains=["wb"] means an OEE module call must never see these,
    regardless of TaskType -- proves domain scoping actually isolates
    WB's own reasoning content from OEE's context (no unintended
    cross-module effect from this phase's own additions)."""
    registry = SkillRegistry()
    registry.load_directory(_REASONING_DIR)
    outcome = _builder(registry).build(_oee_module_state(TaskType.RCA), run_id="run-1")
    retrieved_ids = {s.skill_id for s in outcome.context.relevant_reasoning_skills}
    assert retrieved_ids.isdisjoint(_NEW_WB_REASONING_SKILL_IDS)


def test_cross_source_and_alternative_hypothesis_skills_excluded_for_analysis():
    """`cross_source_evidence_reasoning`/`alternative_hypothesis_reasoning`/
    `causal_inference_guard` are `task_types: [rca]` only -- must never
    appear in an ANALYSIS-tier context, even with a generous budget."""
    registry = _wb_skill_registry()
    generous_budget = PlannerContextBudget(max_reasoning_skills=20, max_context_characters=100_000)
    outcome = _builder(registry).build(_wb_module_state(TaskType.ANALYSIS), run_id="run-1", budget=generous_budget)
    retrieved_ids = {s.skill_id for s in outcome.context.relevant_reasoning_skills}
    assert "reasoning.cross_source_evidence_reasoning" not in retrieved_ids
    assert "reasoning.alternative_hypothesis_reasoning" not in retrieved_ids
    assert "reasoning.causal_inference_guard" not in retrieved_ids


# ============================================================================
# Budget trimming works.
# ============================================================================


def test_budget_trims_reasoning_skills_to_the_configured_limit():
    registry = _wb_skill_registry()
    tight_budget = PlannerContextBudget(max_reasoning_skills=2, max_context_characters=100_000)
    outcome = _builder(registry).build(_wb_module_state(TaskType.RCA), run_id="run-1", budget=tight_budget)
    assert len(outcome.context.relevant_reasoning_skills) == 2


def test_generous_budget_surfaces_more_reasoning_skills_than_the_tight_one():
    registry = _wb_skill_registry()
    tight_budget = PlannerContextBudget(max_reasoning_skills=1, max_context_characters=100_000)
    generous_budget = PlannerContextBudget(max_reasoning_skills=20, max_context_characters=100_000)

    tight_outcome = _builder(registry).build(_wb_module_state(TaskType.RCA), run_id="run-1", budget=tight_budget)
    generous_outcome = _builder(registry).build(_wb_module_state(TaskType.RCA), run_id="run-2", budget=generous_budget)

    assert len(tight_outcome.context.relevant_reasoning_skills) == 1
    assert len(generous_outcome.context.relevant_reasoning_skills) > len(tight_outcome.context.relevant_reasoning_skills)


def test_default_rca_budget_surfaces_more_than_the_old_pre_tuning_default():
    """Item AA's own regression: with the OLD class default
    (`max_reasoning_skills=2`, `max_context_characters=6000`), only ONE
    reasoning skill survives the character-budget trim (verified
    empirically, not guessed). Confirms the Phase WB-3E
    `_DEFAULT_BUDGETS[TaskType.RCA]` tuning (`max_reasoning_skills=6`,
    `max_context_characters=14000`) raised the effective count to 4 --
    a real, positive effect, deliberately still short of the raw
    `max_reasoning_skills=6` ceiling (context stays bounded even for a
    densely reasoning-skill-populated domain like WB, per this
    builder's own documented "count cap, then a character-budget trim
    pass" design)."""
    registry = _wb_skill_registry()
    old_default_budget = PlannerContextBudget(max_reasoning_skills=2)  # the pre-WB-3E class-default values (also max_context_characters=6000)
    tuned_outcome = _builder(registry).build(_wb_module_state(TaskType.RCA), run_id="run-1")  # default budget, no override -- uses the new tuned value
    old_default_outcome = _builder(registry).build(_wb_module_state(TaskType.RCA), run_id="run-2", budget=old_default_budget)

    assert len(tuned_outcome.context.relevant_reasoning_skills) > len(old_default_outcome.context.relevant_reasoning_skills)
    assert len(tuned_outcome.context.relevant_reasoning_skills) >= 3
