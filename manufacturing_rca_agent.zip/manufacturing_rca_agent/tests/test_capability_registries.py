"""Phase 5B-2: ToolRegistry + SkillRegistry, independent of any Skill
execution -- pure lookup/allow-list/validation behavior."""
import pytest

from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD
from agent.skills.registry import DuplicateSkillError, MissingToolForSkillError, SkillNotFoundError, SkillRegistry
from agent.state.base import RCABaseModel
from agent.state.enums import ObservationStatus
from agent.state.payload import PayloadRegistry
from agent.tools.models import ExecutionType, ToolCategory, ToolDefinition, ToolExecutionResult, ToolIOSchema, ToolSideEffect
from agent.tools.registry import DuplicateToolError, ToolNotFoundError, ToolRegistry

from .conftest import OEE_SKILLS_DIR, make_oee_skill_registry, make_oee_tool_registry


class _DummyPayload(RCABaseModel):
    pass


PayloadRegistry.register("test.registry_dummy", _DummyPayload)


class _DummyTool:
    def __init__(self, tool_id: str, domains: list[str]):
        self.definition = ToolDefinition(
            tool_id=tool_id,
            name=tool_id,
            description="dummy tool for registry tests",
            category=ToolCategory.QUERY,
            domains=domains,
            input_schema=ToolIOSchema(model_name="Dummy"),
            output_schema=ToolIOSchema(model_name="Dummy"),
            execution_type=ExecutionType.DETERMINISTIC,
            side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="test.registry_dummy",
            output_payload_type="test.registry_dummy",
        )

    def run(self, request) -> ToolExecutionResult:
        return ToolExecutionResult(status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("test.registry_dummy", _DummyPayload()))


# ============================================================================
# ToolRegistry
# ============================================================================


def test_oee_module_can_use_shared_and_oee_tools_but_not_wip_only_tool():
    registry = ToolRegistry()
    registry.register(_DummyTool("shared_tool", []))
    registry.register(_DummyTool("oee_tool", ["oee"]))
    registry.register(_DummyTool("wip_tool", ["wip"]))

    allowed = {d.tool_id for d in registry.allowed_for("OEE")}
    assert allowed == {"shared_tool", "oee_tool"}
    assert "wip_tool" not in allowed


def test_wip_module_allow_list_is_disjoint_from_oee_only_tools():
    registry = ToolRegistry()
    registry.register(_DummyTool("shared_tool", []))
    registry.register(_DummyTool("oee_tool", ["oee"]))
    registry.register(_DummyTool("wip_tool", ["wip"]))

    allowed = {d.tool_id for d in registry.allowed_for("WIP")}
    assert allowed == {"shared_tool", "wip_tool"}


def test_duplicate_tool_id_rejected():
    registry = ToolRegistry()
    registry.register(_DummyTool("t1", []))
    with pytest.raises(DuplicateToolError):
        registry.register(_DummyTool("t1", []))


def test_missing_tool_raises_typed_error():
    registry = ToolRegistry()
    with pytest.raises(ToolNotFoundError):
        registry.get("does-not-exist")


def test_real_oee_tool_registry_contents():
    registry = make_oee_tool_registry(MOCK_EQUIPMENT, OEE_THRESHOLD)
    tool_ids = {d.tool_id for d in registry.list()}
    assert tool_ids == {
        "query_oee_data",
        "query_equipment_detail",
        "filter_rows",
        "calculate_contribution",
        "ranking",
        "aggregate_oee_status",
    }
    # every OEE capability tool declares domains=["oee"] -- none are shared
    assert {d.tool_id for d in registry.allowed_for("OEE")} == tool_ids
    assert registry.allowed_for("WIP") == []


# ============================================================================
# SkillRegistry
# ============================================================================


def test_load_directory_loads_all_oee_skill_markdown_files():
    registry = make_oee_skill_registry()
    assert {s.skill_id for s in registry.list()} == {
        "oee.equipment_screening",
        "oee.current_status",
        "oee.rca_screening",
        "oee.rca_equipment_detail",
    }


def test_instructions_returns_the_markdown_narrative_body():
    registry = make_oee_skill_registry()
    body = registry.instructions("oee.equipment_screening")
    assert "## Goal" in body
    assert "query_oee_data" in body


def test_get_missing_skill_raises_typed_error():
    registry = SkillRegistry()
    with pytest.raises(SkillNotFoundError):
        registry.get("does.not.exist")


def test_duplicate_skill_id_rejected():
    registry = SkillRegistry()
    registry.load_markdown_file(OEE_SKILLS_DIR / "current_status.md")
    with pytest.raises(DuplicateSkillError):
        registry.load_markdown_file(OEE_SKILLS_DIR / "current_status.md")


def test_list_filters_by_domain_and_category():
    registry = make_oee_skill_registry()
    screening = registry.list(domain="oee", category="screening")
    assert {s.skill_id for s in screening} == {"oee.equipment_screening"}
    information = registry.list(category="information")
    assert {s.skill_id for s in information} == {"oee.current_status"}


def test_validate_required_tools_passes_when_every_tool_is_registered():
    tool_registry = make_oee_tool_registry(MOCK_EQUIPMENT, OEE_THRESHOLD)
    skill_registry = make_oee_skill_registry()
    skill_registry.validate_required_tools(tool_registry)  # must not raise


def test_validate_required_tools_raises_typed_error_when_a_tool_is_missing():
    empty_tool_registry = ToolRegistry()
    skill_registry = make_oee_skill_registry()
    with pytest.raises(MissingToolForSkillError):
        skill_registry.validate_required_tools(empty_tool_registry)
