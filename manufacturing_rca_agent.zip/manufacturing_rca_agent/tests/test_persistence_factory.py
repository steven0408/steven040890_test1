"""Offline tests for the backend-selection factory (item 14). No real
PostgreSQL: the "postgres" branch is exercised with a `connection_factory`
that hands back `FakeConnection` instances, proving the wiring shape (which
connection each repository/sink gets, and that `run_repository` shares its
connection with `make_unit_of_work()`) without `psycopg` installed.
"""
from agent.persistence.factory import PersistenceBackend, PersistenceBackendConfig, build_persistence_layer
from agent.persistence.postgres.config import PostgresSettings
from agent.persistence.postgres.repositories import PostgresHumanFeedbackSink, PostgresRunRepository
from agent.persistence.postgres.unit_of_work import PostgresPersistenceUnitOfWork
from agent.persistence.run_repository import InMemoryRunRepository
from agent.persistence.unit_of_work import PersistenceUnitOfWork
from tests.postgres_fake import FakeConnection


def test_memory_backend_returns_in_memory_implementations():
    layer = build_persistence_layer(PersistenceBackendConfig(backend=PersistenceBackend.MEMORY))
    assert isinstance(layer.run_repository, InMemoryRunRepository)
    uow = layer.make_unit_of_work()
    assert isinstance(uow, PersistenceUnitOfWork)


def test_memory_backend_is_the_default():
    layer = build_persistence_layer(PersistenceBackendConfig())
    assert isinstance(layer.run_repository, InMemoryRunRepository)


def _settings() -> PostgresSettings:
    return PostgresSettings(host_env="H", database_env="D", user_env="U", password_env="P")


def test_postgres_backend_returns_postgres_implementations():
    connections: list[FakeConnection] = []

    def factory() -> FakeConnection:
        conn = FakeConnection()
        connections.append(conn)
        return conn

    layer = build_persistence_layer(
        PersistenceBackendConfig(backend=PersistenceBackend.POSTGRES, postgres=_settings()), connection_factory=factory
    )
    assert isinstance(layer.run_repository, PostgresRunRepository)
    assert isinstance(layer.feedback_sink, PostgresHumanFeedbackSink)
    uow = layer.make_unit_of_work()
    assert isinstance(uow, PostgresPersistenceUnitOfWork)


def test_postgres_backend_run_repository_shares_connection_with_unit_of_work():
    """The critical wiring invariant (see factory.py's own docstring): a
    write staged through the UoW must land on the SAME connection the UoW
    itself commits/rolls back -- otherwise commit() would be a no-op for
    whatever the repository actually wrote."""
    connections: list[FakeConnection] = []

    def factory() -> FakeConnection:
        conn = FakeConnection()
        connections.append(conn)
        return conn

    layer = build_persistence_layer(
        PersistenceBackendConfig(backend=PersistenceBackend.POSTGRES, postgres=_settings()), connection_factory=factory
    )
    run_repo_conn = layer.run_repository._conn
    uow = layer.make_unit_of_work()
    assert uow._connection is run_repo_conn  # same object the run_repository writes through

    uow.stage(lambda: run_repo_conn.execute("SELECT 1"))
    uow.commit()
    assert run_repo_conn.committed is True

    uow2 = layer.make_unit_of_work()
    assert uow2._connection is run_repo_conn  # reused across multiple persist_run() calls, not recreated each time


def test_postgres_backend_missing_settings_raises():
    import pytest

    with pytest.raises(ValueError):
        build_persistence_layer(PersistenceBackendConfig(backend=PersistenceBackend.POSTGRES, postgres=None))


def test_postgres_backend_audit_sinks_share_one_connection_distinct_from_run_repository():
    connections: list[FakeConnection] = []

    def factory() -> FakeConnection:
        conn = FakeConnection()
        connections.append(conn)
        return conn

    layer = build_persistence_layer(
        PersistenceBackendConfig(backend=PersistenceBackend.POSTGRES, postgres=_settings()), connection_factory=factory
    )
    audit_conn = layer.audit_repository.llm_usage_sink._conn
    assert layer.audit_repository.planner_context_sink._conn is audit_conn
    assert layer.audit_repository.tool_call_sink._conn is audit_conn
    assert layer.run_repository._conn is not audit_conn
    assert audit_conn.autocommit is True
    assert layer.run_repository._conn.autocommit is False
