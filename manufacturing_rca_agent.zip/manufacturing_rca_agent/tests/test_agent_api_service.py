"""Phase PROD-1: offline (MockLLMClient) tests for agent_api/service.py --
proves AgentService can build a real production graph (real Standardizer/
Analyzer/Planner/Synthesis nodes, real WB capability/Tool execution) end
to end, with a mocked LLM client (bootstrap_runtime itself never
constructs a real network client -- see agent/bootstrap.py's own
docstring), and that `analyze()`/`stream()` produce the expected bounded
output/events.
"""
from datetime import date

from langgraph.checkpoint.memory import InMemorySaver

from agent.bootstrap import AppConfig, bootstrap_runtime
from agent.domain.wb.synthetic import GOLDEN_DATE
from agent.graph.nodes.analyzer_llm import make_analyzer_llm_node, AnalyzerLLMService
from agent.graph.nodes.standardizer_llm import make_standardizer_llm_node, StandardizerLLMService
from agent.graph.nodes.synthesis import make_llm_synthesis_node
from agent.graph.production import build_production_graph_with_synthesis
from agent.llm.client import MockLLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.context.standardizer_context import StandardizerContextBuilder
from agent.llm.prompts.analyzer import AnalyzerDecision, ModuleSelection
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.llm.prompts.standardizer import StandardizerExtraction
from agent.llm.prompts.synthesis import SynthesisDraft
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.state.enums import ObjectiveAction, TargetRefType, TaskType
from agent.state.models import TargetRef
from agent.state.scope import ObjectiveScope, TimeScope, TimeScopeKind
from agent.synthesis.handoff_builder import ModuleHandoffBuilder
from agent.llm.context.synthesis_context import SynthesisContextBuilder
from agent.synthesis.llm_service import SynthesisLLMService

from agent_api.config import ApiSettings
from agent_api.runtime_events import InMemoryRuntimeEventSink, RuntimeEventType
from agent_api.service import AgentService, normalize_request

_GOAL_TEXT = "Compare WB output across plants."


def _mock_responder(request):
    if request.route == "standardizer":
        return StandardizerExtraction(normalized_text=_GOAL_TEXT, plant_id=None, time=None, constraints=[], reasoning_summary="test")
    if request.route == "analyzer":
        return AnalyzerDecision(
            task_type=TaskType.ANALYSIS, confidence=0.9, reasoning_summary="test",
            selected_modules=[ModuleSelection(module_type="WB", priority=0.9, confidence=0.9, rationale="test", goal_statement=_GOAL_TEXT)],
        )
    if request.route == "planner":
        return PlannerDecision(
            decision=PlannerDecisionType.DISPATCH,
            next_objective=ObjectiveProposal(
                action=ObjectiveAction.COMPARE, capability_key="wb.output.comparison",
                target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="WB"),
                scope=ObjectiveScope(time=TimeScope(kind=TimeScopeKind.PRODUCTION_DATE, date=GOLDEN_DATE)),
                description="Compare WB output across plants.", expected_output="ranked comparison",
            ),
            priority=0.9, rationale_summary="test",
        )
    if request.route == "synthesis":
        return SynthesisDraft(executive_summary="WB output comparison complete.")
    raise AssertionError(f"unexpected route: {request.route}")


def _build_test_service(*, request_timeout_seconds: float | None = None) -> AgentService:
    settings = ApiSettings(
        llm_provider_config=None,  # not used -- test builds runtime_context directly, bypassing from_env()/build_llm_client()
        enabled_modules=["WB"], request_timeout_seconds=request_timeout_seconds,
    )
    # bootstrap_runtime builds its own LLMRouter from app_config.llm_routes
    # + llm_client -- this mirrors exactly how AgentService.from_settings
    # wires a real deployment, just with a MockLLMClient in place of
    # build_llm_client()'s real provider adapter.
    app_config = AppConfig(
        factory_id="factory-a", factory_name="Factory A", enabled_modules=["WB"],
        llm_routes={
            "standardizer": LLMRouteConfig(route="standardizer", model="mock"),
            "analyzer": LLMRouteConfig(route="analyzer", model="mock"),
            "planner": LLMRouteConfig(route="planner", model="mock"),
            "synthesis": LLMRouteConfig(route="synthesis", model="mock"),
        },
    )
    runtime_context = bootstrap_runtime(app_config, llm_client=MockLLMClient(_mock_responder))

    standardizer_service = StandardizerLLMService(StandardizerContextBuilder(), runtime_context.llm_router)
    analyzer_service = AnalyzerLLMService(runtime_context.module_registry, runtime_context.analyzer_context_builder, runtime_context.llm_router)
    synthesis_service = SynthesisLLMService(
        SynthesisContextBuilder(ModuleHandoffBuilder(), reasoning_skill_retriever=runtime_context.reasoning_skill_retriever),
        runtime_context.llm_router,
    )
    checkpointer = InMemorySaver()
    graph = build_production_graph_with_synthesis(
        runtime_context.module_runtime, checkpointer, make_llm_synthesis_node(synthesis_service),
        analyzer=make_analyzer_llm_node(analyzer_service), standardizer=make_standardizer_llm_node(standardizer_service),
    )
    graph_app = graph.compile(checkpointer=checkpointer)
    return AgentService(settings, runtime_context, graph_app, InMemoryRuntimeEventSink())


def test_analyze_produces_markdown_and_complete_status():
    service = _build_test_service()
    result = service.analyze(normalize_request(prompt="Compare WB output across plants.", request=None, run_id=None, factory_id=None, metadata=None))

    assert result.run_id
    assert result.status in ("complete", "partial")
    assert "output" in result.markdown.lower() or len(result.markdown) > 0
    assert "WB" in result.module_statuses


def test_analyze_generates_run_id_when_absent():
    service = _build_test_service()
    result = service.analyze(normalize_request(prompt="test", request=None, run_id=None, factory_id=None, metadata=None))
    assert result.run_id is not None and len(result.run_id) > 0


def test_analyze_honors_explicit_run_id():
    service = _build_test_service()
    result = service.analyze(normalize_request(prompt="test", request=None, run_id="my-custom-run-id", factory_id=None, metadata=None))
    assert result.run_id == "my-custom-run-id"


def test_two_runs_do_not_mix_events():
    """Item 61 -- structural concurrency isolation proof: two runs
    against the same AgentService produce two disjoint event streams."""
    service = _build_test_service()
    sink = service._event_sink  # InMemoryRuntimeEventSink injected above

    service.analyze(normalize_request(prompt="run one", request=None, run_id="run-alpha", factory_id=None, metadata=None))
    service.analyze(normalize_request(prompt="run two", request=None, run_id="run-beta", factory_id=None, metadata=None))

    alpha_events = sink.list_for_run("run-alpha")
    beta_events = sink.list_for_run("run-beta")
    assert alpha_events and beta_events
    assert all(e.run_id == "run-alpha" for e in alpha_events)
    assert all(e.run_id == "run-beta" for e in beta_events)
    # sequences are per-run, both starting at 1 -- no shared/global counter
    assert alpha_events[0].sequence == 1
    assert beta_events[0].sequence == 1


def test_analyze_publishes_run_started_and_run_completed():
    service = _build_test_service()
    sink = service._event_sink
    result = service.analyze(normalize_request(prompt="test", request=None, run_id="run-events-smoke", factory_id=None, metadata=None))
    events = sink.list_for_run(result.run_id)
    types = [e.event_type for e in events]
    assert RuntimeEventType.RUN_STARTED in types
    assert RuntimeEventType.RUN_COMPLETED in types
    assert RuntimeEventType.PLANNER_DECISION in types
    assert RuntimeEventType.TOOL_COMPLETED in types or RuntimeEventType.TOOL_FAILED in types


def test_stream_yields_run_started_and_final_events():
    service = _build_test_service()
    events = list(service.stream(normalize_request(prompt="test", request=None, run_id="run-stream-smoke", factory_id=None, metadata=None)))
    types = [e.event_type for e in events]
    assert types[0] == RuntimeEventType.RUN_STARTED
    assert RuntimeEventType.RUN_COMPLETED in types


def test_stream_events_never_contain_raw_prompt_or_chain_of_thought():
    """Item 13/45 -- structural check: no event field ever contains
    obviously-prompt-shaped content (the literal DATA boundary markers
    every cognitive prompt uses)."""
    service = _build_test_service()
    events = list(service.stream(normalize_request(prompt="test", request=None, run_id="run-cot-smoke", factory_id=None, metadata=None)))
    for event in events:
        dumped = event.model_dump_json()
        assert "BEGIN DATA" not in dumped
        assert "Hard rules" not in dumped
