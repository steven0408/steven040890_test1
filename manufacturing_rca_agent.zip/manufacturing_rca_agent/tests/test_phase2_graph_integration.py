from langgraph.checkpoint.memory import InMemorySaver

from agent.graph.graph import build_phase2_graph
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.planning.policies.mock import DeterministicMockPolicy
from agent.state.enums import EvidenceQuality, ModuleStatus, ObservationStatus, RunTerminationStatus
from agent.state.models import Budget
from agent.state.state import AgentState
from agent.tools.base import ToolResult
from agent.tools.mocks.scripted_tool import ScriptedMockTool

from .conftest import make_agent_state, make_budget

# Simple single-source runtime per module_type; OEE/Output succeed
# immediately, WIP is deliberately budget-capped before it can gather
# enough evidence -> PARTIAL. This exercises the real Module ReAct
# Subgraph (Phase 3/4A), not a flat status mock like the original Phase 2
# milestone did.
MODULE_RUNTIME = {
    "OEE": ModuleRuntimeConfig(
        policy=DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1),
        tool=ScriptedMockTool({"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}),
        budget=make_budget(max_steps=3, max_tool_calls=5, max_depth_per_entity=2),
    ),
    "Output": ModuleRuntimeConfig(
        policy=DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1),
        tool=ScriptedMockTool({"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}),
        budget=make_budget(max_steps=3, max_tool_calls=5, max_depth_per_entity=2),
    ),
    "WIP": ModuleRuntimeConfig(
        policy=DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=999),  # unreachable
        tool=ScriptedMockTool({"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="partial", quality=EvidenceQuality.WEAK)}),
        budget=make_budget(max_steps=1, max_tool_calls=3, max_depth_per_entity=2),  # cut off after 1 round
    ),
}


def _run_phase2_graph():
    """Runs the real multi-module LangGraph graph (not the reducer functions
    directly) through a checkpointer, and returns both the final state and
    the full state history for inspecting intermediate coordinator/gate
    behavior.
    """
    checkpointer = InMemorySaver()
    graph = build_phase2_graph(MODULE_RUNTIME, checkpointer)
    app = graph.compile(checkpointer=checkpointer)

    initial_state = make_agent_state()
    config = {"configurable": {"thread_id": initial_state.run_id}}

    result = app.invoke(initial_state, config=config)
    final_state = AgentState.model_validate(result)

    chronological_history = list(reversed(list(app.get_state_history(config))))
    return final_state, chronological_history


def test_all_three_modules_get_independent_module_states():
    final_state, _ = _run_phase2_graph()

    assert set(final_state.module_states) == {"OEE", "Output", "WIP"}
    for module_id, module_state in final_state.module_states.items():
        assert module_state.module_id == module_id
        assert module_state.module_type == module_id


def test_parallel_send_execution_does_not_clobber_sibling_module_state():
    final_state, _ = _run_phase2_graph()

    # objective_history is populated for every module regardless of terminal
    # path (unlike current_objective, which Planner nulls when it gives up
    # -- see WIP below), so it's the robust way to prove each module's own
    # objectives never leaked into a sibling's ModuleState.
    history_keys = {
        module_id: set(module_state.objective_history) for module_id, module_state in final_state.module_states.items()
    }
    assert history_keys["OEE"] == {"OEE-obj-1"}
    assert history_keys["Output"] == {"Output-obj-1"}
    assert history_keys["WIP"] == {"WIP-obj-1"}
    # all disjoint -- proves no branch overwrote another's payload
    all_ids = [oid for ids in history_keys.values() for oid in ids]
    assert len(all_ids) == len(set(all_ids)) == 3


def test_module_states_reducer_merges_all_three_concurrent_send_branches():
    final_state, _ = _run_phase2_graph()
    # module_states has no custom reducer -> default LangGraph behavior for
    # a dict channel written by 3 concurrent Send branches in the same
    # superstep is to *error* ("Can receive only one value per step"), not
    # silently drop data. Reaching this assertion at all already proves
    # merge_by_key is doing its job.
    assert len(final_state.module_states) == 3


def test_plan_and_objective_are_module_scoped_only():
    final_state, _ = _run_phase2_graph()

    assert not hasattr(final_state, "current_plan")
    assert not hasattr(final_state, "current_objective")
    # COMPLETE modules keep the objective that triggered CANDIDATE_COMPLETE;
    # WIP's Planner nulled current_objective when it gave up on budget --
    # objective_history (checked above) is what stays populated regardless.
    assert final_state.module_states["OEE"].current_objective is not None
    assert final_state.module_states["Output"].current_objective is not None
    assert final_state.module_states["WIP"].current_objective is None


def test_coordinator_tracks_in_flight_then_drains_it():
    _, history = _run_phase2_graph()

    # LangGraph reconstructs `module_dispatch` as a real ModuleDispatchState
    # instance (not a plain dict) in each history snapshot -- confirmed
    # empirically, see Phase 2 report.
    dispatch_states = [
        snap.values["module_dispatch"] for snap in history if snap.values.get("module_dispatch") is not None
    ]

    first_with_in_flight = next(d for d in dispatch_states if d.in_flight)
    assert set(first_with_in_flight.in_flight) == {"OEE", "Output", "WIP"}
    assert first_with_in_flight.pending == []

    final_dispatch = dispatch_states[-1]
    assert final_dispatch.in_flight == []
    assert final_dispatch.pending == []


def test_global_completion_check_is_read_only():
    _, history = _run_phase2_graph()

    before = next(snap for snap in history if snap.next == ("global_completion_check",))
    after = history[-1]  # terminal snapshot, next == ()

    assert before.values["module_states"] == after.values["module_states"]
    assert before.values["module_dispatch"] == after.values["module_dispatch"]
    assert before.values["termination_status"] != after.values["termination_status"]


def test_complete_and_partial_are_both_terminal():
    final_state, _ = _run_phase2_graph()

    assert final_state.module_states["OEE"].status == ModuleStatus.COMPLETE
    assert final_state.module_states["Output"].status == ModuleStatus.COMPLETE
    assert final_state.module_states["WIP"].status == ModuleStatus.PARTIAL


def test_all_modules_terminal_reaches_ready_for_synthesis():
    final_state, _ = _run_phase2_graph()
    assert final_state.termination_status == RunTerminationStatus.READY_FOR_SYNTHESIS


def test_final_state_round_trips_through_json_after_real_graph_execution():
    final_state, _ = _run_phase2_graph()
    payload = final_state.model_dump_json()
    restored = AgentState.model_validate_json(payload)
    assert restored == final_state
