"""Phase WB-3F.4: live proof of the Standardizer LLM constraint extraction
(§22/23/24) and the full Request Constraint -> Planner -> Skill -> Tool ->
Executed Scope -> Reflector chain (§60/61), using real OpenAI calls. Uses
generic synthetic ids DIFFERENT from the Planner prompt's own generic
placeholder example (which uses no real values at all), per item 22's own
"use different values in prompt examples vs tests" instruction.

Skipped entirely (not failed) when OPENAI_API_KEY is not set.
"""
import os

import pytest

from agent.llm.config import LLMRouteConfig
from agent.llm.context.standardizer_context import StandardizerContextBuilder
from agent.llm.models import DecisionSource
from agent.llm.providers.openai_adapter import OpenAICompatibleAdapter
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.graph.nodes.standardizer_llm import StandardizerLLMService

from .conftest import make_agent_state, make_module_state

pytestmark = pytest.mark.skipif(
    not os.environ.get("OPENAI_API_KEY"),
    reason="OPENAI_API_KEY not set -- real OpenAI-provider Standardizer/constraint tests skipped (not failed) without a secret",
)

_MODEL = "gpt-4o-mini"

_SCENARIOS = [
    ("A: plant only", "Check BANK status at ASE03.", "ASE03", None, None),
    ("B: plant + customer", "Check BANK status for customer CUSTX9 at ASE03.", "ASE03", "customer", "CUSTX9"),
    ("C: operation + date", "Compare output for operation OPZ7 across plants on 2026-08-12.", None, "operation", "OPZ7"),
    ("D: no operation", "Compare output across plants on 2026-08-12.", None, None, None),
    ("E: WIP Hold plant only", "Check WIP Hold at ASE07.", "ASE07", None, None),
]


def _service(model: str) -> StandardizerLLMService:
    usage_sink = InMemoryLLMUsageSink()
    router = LLMRouter(
        routes={"standardizer": LLMRouteConfig(route="standardizer", model=model, timeout_seconds=30.0, max_retries=1)},
        client=OpenAICompatibleAdapter(temperature=0.0, max_tokens=800), usage_sink=usage_sink,
    )
    return StandardizerLLMService(StandardizerContextBuilder(), router)


def _run_scenarios(model: str) -> list[dict]:
    rows = []
    for label, text, expected_plant, expected_dim, expected_value in _SCENARIOS:
        state = make_agent_state(raw_text=text)
        outcome = _service(model).decide(state)
        dims = {c.dimension: c.value for c in outcome.extraction.constraints}
        row = {
            "model": model, "scenario": label, "source": outcome.source.value,
            "plant_id": outcome.extraction.plant_id, "plant_correct": outcome.extraction.plant_id == expected_plant if expected_plant else "n/a (none expected)",
            "constraints": dims,
            "expected_dim_present": (expected_dim in dims) if expected_dim else "n/a (none expected)",
            "expected_dim_correct": (dims.get(expected_dim) == expected_value) if expected_dim else "n/a",
        }
        rows.append(row)
        print(f"\n[{model}] {row}")
    return rows


def test_standardizer_live_extraction_gpt_4o_mini():
    rows = _run_scenarios("gpt-4o-mini")
    print("\n=== Standardizer live extraction (gpt-4o-mini) ===")
    for r in rows:
        print(r)
    # HARD invariant only: every call produces SOME outcome (LLM or safe fallback), never a crash.
    assert all(r["source"] in ("llm", "fallback") for r in rows)


def test_standardizer_live_extraction_gpt_4o():
    rows = _run_scenarios("gpt-4o")
    print("\n=== Standardizer live extraction (gpt-4o) ===")
    for r in rows:
        print(r)
    assert all(r["source"] in ("llm", "fallback") for r in rows)


def test_standardizer_ambiguous_value_not_guessed():
    """item 58: an ambiguous token with no clear dimension cue should not
    be confidently assigned -- soft/honest reporting, not a hard demand."""
    state = make_agent_state(raw_text="Check ABC situation.")
    outcome = _service(_MODEL).decide(state)
    print(f"\nAmbiguous value smoke -> source={outcome.source.value} constraints={[(c.dimension, c.value) for c in outcome.extraction.constraints]}")
    assert outcome.source in (DecisionSource.LLM, DecisionSource.FALLBACK)


# ============================================================================
# Full chain: Request Constraint -> Planner -> Skill -> Tool -> Executed
# Scope -> Reflector, real LLM at every cognitive step.
# ============================================================================


def test_full_chain_customer_constraint_live():
    from agent.capability.resolver import CapabilityResolver
    from agent.graph.nodes.module.bootstrap import build_initial_module_state
    from agent.llm.context.reflector_context import ReflectorContextBuilder
    from agent.planning.policies.llm_reflection import LLMReflectionPolicy
    from agent.planning.reflection_audit import InMemoryReflectionDecisionAuditSink
    from agent.state.enums import ModuleStatus, TaskType
    from agent.state.models import Budget, ModuleState, ModuleTask
    from agent.state.scope import ConstraintSource, RequestConstraint
    from langgraph.checkpoint.memory import InMemorySaver

    from .test_wb_reasoning_llm_live import _capability_runtime, _wb_registries

    # wb.output.comparison is MODULE-targeted (no ENTITY pre-registration
    # needed, unlike wb.bank.status_summary) and its `operation` scope
    # dimension was wired end-to-end in WB-3F.2 -- uses the real golden
    # dataset's own GOLDEN_DATE/operation "2800" so there is real matching
    # evidence, not just an empty result.
    goal_statement = "Compare output for operation 2800 across plants on 2026-08-12."

    # Real Standardizer extraction feeds the ModuleTask's own constraints,
    # exactly the way agent/graph/nodes/analyzer_llm.py's real dispatch does.
    standardizer_service = _service(_MODEL)
    state = make_agent_state(raw_text=goal_statement)
    standardizer_outcome = standardizer_service.decide(state)
    print(f"\nStandardizer source: {standardizer_outcome.source.value}")
    constraints = [
        RequestConstraint(dimension=c.dimension, operator=c.operator, value=c.value, source=ConstraintSource.USER_EXPLICIT)
        for c in standardizer_outcome.extraction.constraints
    ]
    print(f"Extracted constraints: {[(c.dimension, c.value) for c in constraints]}")

    usage_sink = InMemoryLLMUsageSink()
    router = LLMRouter(
        routes={
            "planner": LLMRouteConfig(route="planner", model=_MODEL, timeout_seconds=30.0, max_retries=1),
            "reflector": LLMRouteConfig(route="reflector", model=_MODEL, timeout_seconds=30.0, max_retries=1),
        },
        client=OpenAICompatibleAdapter(temperature=0.0, max_tokens=1500), usage_sink=usage_sink,
    )
    from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
    from agent.llm.context.evidence_selector import DeterministicEvidenceSelector
    from agent.llm.context.planner_context import PlannerContextBuilder
    from agent.llm.context.reasoning_skill_retriever import DeterministicReasoningSkillRetriever
    from agent.planning.policies.llm import LLMPlanningPolicy
    from agent.planning.policies.wb import WBPlanningPolicy

    _package, skill_registry, tool_registry = _wb_registries()
    planner_ctx = PlannerContextBuilder(
        DeterministicEvidenceSelector(), DeterministicCapabilityRetriever(skill_registry),
        reasoning_skill_retriever=DeterministicReasoningSkillRetriever(skill_registry),
    )
    from agent.planning.decision_audit import InMemoryPlannerDecisionAuditSink

    planner_sink = InMemoryPlannerDecisionAuditSink()
    llm_planner = LLMPlanningPolicy(WBPlanningPolicy(), planner_ctx, router, skill_registry, decision_audit_sink=planner_sink)
    reflection_sink = InMemoryReflectionDecisionAuditSink()
    reflector_ctx = ReflectorContextBuilder(reasoning_skill_retriever=DeterministicReasoningSkillRetriever(skill_registry))
    policy = LLMReflectionPolicy(llm_planner, reflector_ctx, router, decision_audit_sink=reflection_sink)
    runtime = _capability_runtime(skill_registry, tool_registry)

    # wb.output.comparison's task_types are [analysis, rca] only.
    task = ModuleTask(module_id="WB", module_type="WB", reason="WB-3F.4 full chain smoke", goal_statement=goal_statement, confidence=0.9, priority=0.9, task_type=TaskType.ANALYSIS, constraints=constraints)
    initial = build_initial_module_state(task, Budget(max_steps=6, max_tool_calls=20, max_depth_per_entity=2), run_id="wb-full-chain", task_type=TaskType.ANALYSIS)

    from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph

    graph = build_module_react_subgraph(policy, capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)
    result = app.invoke(initial, config={"configurable": {"thread_id": "wb-full-chain"}})
    final_state = ModuleState.model_validate(result)

    print("\n=== Full chain: Request Constraint -> Planner -> Tool -> Reflector ===")
    for i, (oid, record) in enumerate(final_state.objective_history.items(), start=1):
        scope_dims = {f.dimension: f.value for f in (record.scope.filters if record.scope else [])}
        print(f"Round {i}: capability={record.capability_key} target={record.target_ref.ref_id} scope={scope_dims} status={record.status.value}")
    for d in planner_sink.list_for_run("wb-full-chain"):
        print(f"Planner decision: source={d.source.value} decision={d.decision.value} action={d.proposed_action.value if d.proposed_action else None} capability={d.proposed_capability_key} fallback_reason={d.fallback_reason} rationale={d.rationale_summary[:300]}")
    for r in reflection_sink.list_for_run("wb-full-chain"):
        print(f"Reflection: verdict={r.verdict.value} source={r.source.value}")
    if final_state.evidence:
        print(f"Evidence: {final_state.evidence[-1].summary}")
    if final_state.findings:
        print(f"Finding: {final_state.findings[-1].statement}")
    print(f"Final status: {final_state.status.value}")

    assert final_state.status in (ModuleStatus.COMPLETE, ModuleStatus.PARTIAL)
    first_record = next(iter(final_state.objective_history.values()))
    assert first_record.capability_key == "wb.output.comparison"


# ============================================================================
# Synthesis grounding regression (item 39/44): a scope-mismatched result must
# never be presented by Synthesis as if it were scope-specific. Complements
# the WB-3F.3 Reflector-level grounding fix one node further downstream --
# Synthesis's `executive_summary`/`summary_text` are free prose with no
# id-referencing validation (unlike key_finding_ids etc.), so this is a real,
# separate risk surface: the raw user Request text (which may name a
# customer) is visible to Synthesis alongside a plant-wide, unscoped Finding.
# ============================================================================


def _synthesis_state_with_unscoped_finding(raw_text: str, finding_statement: str, task_type):
    from agent.state.enums import FindingStatus, ModuleStatus as MS
    from agent.state.models import Finding, Goal, GoalScope

    module_state = make_module_state(module_id="WB", module_type="WB").model_copy(
        update={
            "status": MS.COMPLETE,
            "findings": [
                Finding(finding_id="f1", statement=finding_statement, pattern="descriptive", confidence=0.9, status=FindingStatus.CONFIRMED, is_root_cause=False)
            ],
        }
    )
    state = make_agent_state(raw_text=raw_text)
    return state.model_copy(
        update={
            "module_states": {"WB": module_state},
            "global_goal": Goal(goal_id="g1", raw_statement=raw_text, normalized_statement=raw_text, task_type=task_type, scope=GoalScope()),
        }
    )


def test_synthesis_never_narrows_unscoped_finding_to_a_requested_customer_live():
    from agent.llm.context.synthesis_context import SynthesisContextBuilder
    from agent.state.enums import TaskType as _TaskType
    from agent.synthesis.decision_audit import SynthesisSource
    from agent.synthesis.llm_service import SynthesisLLMService

    raw_text = "Check WB output for customer CUSTX9 at ASE07."
    unscoped_statement = "WB output at ASE07 was 12,400 units on 2026-08-12, aggregated across all customers (no per-customer breakdown was available)."
    state = _synthesis_state_with_unscoped_finding(raw_text, unscoped_statement, _TaskType.ANALYSIS)

    usage_sink = InMemoryLLMUsageSink()
    router = LLMRouter(
        routes={"synthesis": LLMRouteConfig(route="synthesis", model=_MODEL, timeout_seconds=30.0, max_retries=1)},
        client=OpenAICompatibleAdapter(temperature=0.0, max_tokens=1200), usage_sink=usage_sink,
    )
    service = SynthesisLLMService(SynthesisContextBuilder(), router)
    outcome = service.synthesize(state)

    print(f"\nSynthesis source: {outcome.source.value}")
    print(f"Markdown:\n{outcome.package.markdown}")

    assert outcome.source == SynthesisSource.LLM, outcome.fallback_reason
    # The "## Request" section is a verbatim, Harness-rendered echo of the
    # raw user text (never LLM-authored) -- exclude it so this checks only
    # the LLM's own prose (Executive Summary / Module Results / Key Findings).
    llm_authored_text = outcome.package.markdown.split("## Executive Summary", 1)[-1].upper()
    # SOFT signal only (never a hard failure on its own): flag if CUSTX9 is
    # asserted as if the (unscoped) evidence actually covered it -- honest
    # reporting per this session's own established discipline, not a forced pass.
    if "CUSTX9" in llm_authored_text:
        print("SOFT WARNING: Synthesis's own prose (outside the verbatim Request echo) mentions CUSTX9 even though the underlying finding is explicitly unscoped/aggregated.")
    else:
        print("Grounding held: Synthesis's own prose never asserts CUSTX9-specific coverage for an unscoped finding.")


def test_synthesis_positive_control_correctly_scoped_finding_live():
    """Positive control for the test above: when the finding genuinely IS
    customer-specific, Synthesis should say so -- proving the negative
    control isn't just "the model never mentions specifics"."""
    from agent.llm.context.synthesis_context import SynthesisContextBuilder
    from agent.state.enums import TaskType as _TaskType
    from agent.synthesis.decision_audit import SynthesisSource
    from agent.synthesis.llm_service import SynthesisLLMService

    raw_text = "Check WB output for customer CUSTX9 at ASE07."
    scoped_statement = "WB output for customer CUSTX9 at ASE07 was 3,100 units on 2026-08-12."
    state = _synthesis_state_with_unscoped_finding(raw_text, scoped_statement, _TaskType.ANALYSIS)

    usage_sink = InMemoryLLMUsageSink()
    router = LLMRouter(
        routes={"synthesis": LLMRouteConfig(route="synthesis", model=_MODEL, timeout_seconds=30.0, max_retries=1)},
        client=OpenAICompatibleAdapter(temperature=0.0, max_tokens=1200), usage_sink=usage_sink,
    )
    service = SynthesisLLMService(SynthesisContextBuilder(), router)
    outcome = service.synthesize(state)

    print(f"\nSynthesis source: {outcome.source.value}")
    print(f"Markdown:\n{outcome.package.markdown}")
    assert outcome.source == SynthesisSource.LLM, outcome.fallback_reason
    llm_authored_text = outcome.package.markdown.split("## Executive Summary", 1)[-1].upper()
    assert "CUSTX9" in llm_authored_text, "positive control: a genuinely customer-scoped finding should be described as such"
