﻿"""Phase 5D-4: ReasoningSkillRetriever -- deterministic metadata filtering
by node/domain/task_type/role, and the two negative guarantees the spec
calls out explicitly: an EXECUTION skill is never surfaced as reasoning
guidance, and a REASONING skill never reaches CapabilityResolver/
DeterministicCapabilityRetriever (the EXECUTION-only retrieval path).
"""
from agent.capability.resolver import CapabilityResolver
from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD
from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
from agent.llm.context.reasoning_skill_retriever import DeterministicReasoningSkillRetriever, EmptyReasoningSkillRetriever
from agent.skills.models import SkillConsumerNode, SkillDefinition, SkillType
from agent.skills.registry import SkillRegistry
from agent.state.enums import ObjectiveAction, TargetRefType, TaskType
from agent.state.models import Objective, TargetRef

from .conftest import make_oee_tool_registry


def _reasoning_skill(**overrides) -> SkillDefinition:
    base = dict(
        skill_id="oee.plant_manager_perspective", name="Plant Manager Perspective",
        description="Judge findings the way a plant manager would prioritize them.",
        category="perspective", input_contract="PlannerContext / AnalyzerContext", output_contract="guidance text",
        skill_type=SkillType.REASONING, domains=["oee"], task_types=[TaskType.RCA],
        applicable_nodes=[SkillConsumerNode.ANALYZER, SkillConsumerNode.PLANNER], roles=["plant_manager"],
    )
    base.update(overrides)
    return SkillDefinition(**base)


def _execution_skill(**overrides) -> SkillDefinition:
    base = dict(
        skill_id="oee.rca_screening", name="Screen", description="d", category="query",
        required_tools=["query_oee_data"], input_contract="x", output_contract="y",
        domains=["oee"], task_types=[TaskType.RCA], actions=[ObjectiveAction.SCREEN],
    )
    base.update(overrides)
    return SkillDefinition(**base)


def _registry_with_both() -> SkillRegistry:
    registry = SkillRegistry()
    registry.register(_reasoning_skill(), body="Think like a plant manager: prioritize throughput impact over cosmetic metrics.")
    registry.register(_execution_skill())
    return registry


def test_empty_retriever_always_returns_empty():
    assert EmptyReasoningSkillRetriever().retrieve(node=SkillConsumerNode.PLANNER, limit=5) == []


def test_retrieves_applicable_reasoning_skill_for_declared_node():
    retriever = DeterministicReasoningSkillRetriever(_registry_with_both())
    results = retriever.retrieve(node=SkillConsumerNode.PLANNER, module_type="OEE", task_type=TaskType.RCA, limit=5)
    assert [r.skill_id for r in results] == ["oee.plant_manager_perspective"]
    assert "plant manager" in results[0].guidance.lower()


def test_analyzer_can_also_retrieve_the_same_skill():
    retriever = DeterministicReasoningSkillRetriever(_registry_with_both())
    results = retriever.retrieve(node=SkillConsumerNode.ANALYZER, module_type="OEE", task_type=TaskType.RCA, limit=5)
    assert [r.skill_id for r in results] == ["oee.plant_manager_perspective"]


def test_node_not_in_applicable_nodes_never_retrieves_it():
    retriever = DeterministicReasoningSkillRetriever(_registry_with_both())
    assert retriever.retrieve(node=SkillConsumerNode.EXECUTOR, module_type="OEE", task_type=TaskType.RCA, limit=5) == []


def test_domain_mismatch_never_retrieves_it():
    retriever = DeterministicReasoningSkillRetriever(_registry_with_both())
    assert retriever.retrieve(node=SkillConsumerNode.PLANNER, module_type="WIP", task_type=TaskType.RCA, limit=5) == []


def test_task_type_mismatch_never_retrieves_it():
    retriever = DeterministicReasoningSkillRetriever(_registry_with_both())
    assert retriever.retrieve(node=SkillConsumerNode.PLANNER, module_type="OEE", task_type=TaskType.INFORMATION, limit=5) == []


def test_module_type_none_only_matches_universally_applicable_skills():
    """Analyzer's scenario: it runs before any module/TaskType is chosen,
    so it passes module_type=task_type=None -- only a skill with no
    domains/task_types declared can be relevant yet."""
    registry = SkillRegistry()
    registry.register(_reasoning_skill(skill_id="oee.plant_manager_perspective"), body="OEE-specific guidance.")
    registry.register(
        _reasoning_skill(skill_id="general.rca_reasoning_framework", domains=[], task_types=[]),
        body="General RCA reasoning framework guidance.",
    )
    retriever = DeterministicReasoningSkillRetriever(registry)

    results = retriever.retrieve(node=SkillConsumerNode.ANALYZER, module_type=None, task_type=None, limit=5)
    assert [r.skill_id for r in results] == ["general.rca_reasoning_framework"]


def test_role_mismatch_never_retrieves_it():
    retriever = DeterministicReasoningSkillRetriever(_registry_with_both())
    assert retriever.retrieve(node=SkillConsumerNode.PLANNER, module_type="OEE", task_type=TaskType.RCA, role="operations_manager", limit=5) == []


def test_execution_skill_never_surfaced_as_reasoning_guidance():
    retriever = DeterministicReasoningSkillRetriever(_registry_with_both())
    results = retriever.retrieve(node=SkillConsumerNode.PLANNER, module_type="OEE", task_type=TaskType.RCA, limit=10)
    assert "oee.rca_screening" not in {r.skill_id for r in results}


def test_reasoning_skill_never_reaches_capability_resolver():
    registry = _registry_with_both()
    tools = make_oee_tool_registry(MOCK_EQUIPMENT, OEE_THRESHOLD)
    resolver = CapabilityResolver(registry, tools)
    objective = Objective(
        objective_id="o1", description="d", action=ObjectiveAction.SCREEN,
        target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="OEE"), expected_output="x", priority_score=1.0,
    )
    # resolves via the EXECUTION skill only -- proves the REASONING skill in
    # the same registry was never a candidate (it has actions=[], so it
    # could never match anyway, but this proves the explicit skill_type
    # filter in CapabilityResolver.resolve() is what's doing the work, not
    # a coincidence of empty actions)
    resolved = resolver.resolve(objective, "OEE", TaskType.RCA)
    assert resolved.selected_skill.skill_id == "oee.rca_screening"


def test_reasoning_skill_never_reaches_capability_retriever():
    registry = _registry_with_both()
    retriever = DeterministicCapabilityRetriever(registry)
    results = retriever.retrieve(module_type="OEE", task_type=TaskType.RCA, action_hint=None, limit=10)
    assert "oee.plant_manager_perspective" not in {s.skill_id for s in results}
