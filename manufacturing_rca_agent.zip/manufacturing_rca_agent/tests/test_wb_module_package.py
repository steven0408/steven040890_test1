"""Phase WB-2C item A/B/26/28: WB ModulePackage + ModuleDefinition +
budget + registration wiring. All offline.
"""
from agent.bootstrap import default_module_package_registry
from agent.modules.wb.package import build_wb_module_package
from agent.state.enums import TaskType
from agent.tools.registry import ToolRegistry


def test_wb_module_definition_fields():
    package = build_wb_module_package()
    definition = package.module_definition
    assert definition.module_type == "WB"
    assert definition.name == "Wire Bond Operations"
    # Phase WB-2D: RCA is now declared (single-module, plant-level only --
    # see test_wb_rca_policy.py). INFORMATION/ANALYSIS unchanged.
    assert definition.supported_task_types == [TaskType.INFORMATION, TaskType.ANALYSIS, TaskType.RCA]
    assert len(definition.key_questions) > 0
    assert definition.enabled is True


def test_wb_module_definition_key_questions_are_descriptive_not_rca():
    """The original INFORMATION/ANALYSIS key questions (Phase WB-2C) stay
    non-causal. Phase WB-2D's own RCA key questions are deliberately
    scoped to "best-supported explanation", never "true causal root
    cause" (item 38) -- see test_wb_rca_policy.py::
    test_wb_rca_key_questions_never_promise_a_definitive_root_cause for
    that guarantee; a "why" word alone is not the thing being guarded
    against here."""
    package = build_wb_module_package()
    information_analysis_questions = package.module_definition.key_questions[:9]
    for question in information_analysis_questions:
        assert "why" not in question.lower()


def test_wb_module_package_has_all_required_components():
    package = build_wb_module_package()
    assert package.module_type == "WB"
    assert package.policy_factory is not None
    assert package.tool_registrations is not None
    assert len(package.skill_directories) == 1
    assert package.skill_directories[0].name == "wb"
    assert package.budget is not None


def test_wb_module_package_policy_factory_returns_raw_wb_planning_policy():
    from agent.planning.policies.wb import WBPlanningPolicy

    package = build_wb_module_package()
    policy = package.policy_factory()
    assert isinstance(policy, WBPlanningPolicy)


def test_wb_module_package_tool_registrations_populates_all_19_wb_tools():
    """Phase WB-3A: 11 -> 14 (ISSUE). Phase WB-3B: 14 -> 19 (5 historical
    trend Tools + the first cross-source Tool)."""
    package = build_wb_module_package()
    registry = ToolRegistry()
    package.tool_registrations(registry)
    tool_ids = {t.tool_id for t in registry.list()}
    assert len(tool_ids) == 19
    assert "analyze_wb_hold" in tool_ids
    assert "analyze_wb_oee_loss" in tool_ids
    assert "query_wb_issue" in tool_ids
    assert "summarize_wb_issue" in tool_ids
    assert "analyze_wb_issue_trend" in tool_ids
    assert "analyze_wb_oee_trend" in tool_ids
    assert "analyze_wb_wip_hold_trend" in tool_ids
    assert "analyze_wb_bank_shortage_trend" in tool_ids
    assert "analyze_wb_output_trend" in tool_ids
    assert "analyze_wb_issue_vs_output" in tool_ids


def test_wb_module_package_skill_directory_loads_all_15_wb_skills():
    """Phase WB-3A: 8 -> 10 (wb.issue_status_summary/wb.issue_trend_analysis).
    Phase WB-3B: 10 -> 15 (5 new historical/cross-source trend skills)."""
    from agent.skills.registry import SkillRegistry

    package = build_wb_module_package()
    skill_registry = SkillRegistry()
    for directory in package.skill_directories:
        skill_registry.load_directory(directory)
    assert len(skill_registry.list()) == 15


def test_wb_module_package_budget_is_shallow_not_oee_rca_sized():
    """Phase WB-2C item 26 / WB-2D item 59: even with RCA now supported,
    WB's budget stays deliberately shallow (plant-level only, worst case
    a 4-round Output-oriented chain) -- nowhere near OEE's own RCA budget
    (10 steps / 30 tool calls) for equipment-level deep-dive."""
    package = build_wb_module_package()
    assert package.budget.max_steps <= 6
    assert package.budget.max_tool_calls <= 6
    assert package.budget.max_steps < 10  # meaningfully smaller than OEE's RCA budget


def test_wb_module_package_accepts_injected_datasources():
    """Mirrors OEE's own `datasource=` injection seam -- a caller (a
    future real-API phase, or a test) can swap WBDataSources without
    touching this function."""
    from agent.domain.wb.datasource import (
        InMemoryWBBankDataSource,
        InMemoryWBIssueDataSource,
        InMemoryWBPlantOEEDataSource,
        InMemoryWBStageOutputDataSource,
        InMemoryWBWIPDataSource,
    )
    from agent.tools.wb.registration import WBDataSources

    custom = WBDataSources(
        oee=InMemoryWBPlantOEEDataSource([]), bank=InMemoryWBBankDataSource([]),
        wip=InMemoryWBWIPDataSource([]), output=InMemoryWBStageOutputDataSource([]),
        issue=InMemoryWBIssueDataSource([]),
    )
    package = build_wb_module_package(datasources=custom)
    registry = ToolRegistry()
    package.tool_registrations(registry)  # must not raise even with an empty dataset


# ============================================================================
# Registration wiring (item 27/28) -- ModulePackageRegistry, never a
# bootstrap.py if-chain
# ============================================================================


def test_wb_module_package_is_registered_in_default_module_package_registry():
    registry = default_module_package_registry()
    package = registry.get("WB")
    assert package.module_type == "WB"


def test_bootstrap_module_registration_loop_has_no_wb_specific_branch():
    """Regression proof (item 27): `bootstrap_runtime` itself must not
    contain any `WB`-literal branching -- confirmed by AST-scanning
    `agent/bootstrap.py` for the string "WB" appearing anywhere OTHER than
    inside `default_module_package_registry` (the one sanctioned catalog-
    building function, matching the existing OEE precedent)."""
    import ast
    from pathlib import Path

    source = Path("agent/bootstrap.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    functions = {node.name: node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)}
    bootstrap_runtime_source = ast.get_source_segment(source, functions["bootstrap_runtime"])
    assert '"WB"' not in bootstrap_runtime_source
    assert "'WB'" not in bootstrap_runtime_source
