"""Phase WB-3A Tests 1/2/3/11: WBIssueRecord canonical parsing, missing-
value semantics, plant mapping, and the synthetic historical-ready
dataset's own observed decline pattern. All offline.
"""
from datetime import date, datetime

from agent.domain.wb.datasource import parse_wb_issue_row
from agent.domain.wb.mappings import KNOWN_PLANT_IDS
from agent.domain.wb.normalization import normalize_row_missing_values
from agent.domain.wb.synthetic import (
    GOLDEN_DATE,
    ISSUE_DECLINE_START,
    SCENARIO_B_PLANT,
    build_wb_issue_records,
)

_SAMPLE_ROW = {
    "SYNC_TIME": "2026-08-13 08:40:00",
    "bd_no": "BD001", "cu_flag": "Y", "cust_2_code": "C1", "cust_runtype": "N",
    "customer_name": "CUSTOMER_ONE", "customer_sod": "2026-08-01", "dev_type": "DEVICE_A",
    "internal_sod": "2026-08-01", "iss_qty": 1000, "lead_count": "100",
    "pack_code": "RY2N", "pack_typ": "STANDARD", "prctr": "A01007", "region": "TW",
    "rel_date": "2026-08-12", "rel_sys": "MES", "rel_time": "08:00:00", "routid": "",
    "run_type": "N", "schedule": "SCH0001", "site": "A2", "time": "AM", "uom": "P",
    "user_id": "U001", "user_name": "TESTER", "wafer_inch": "12", "year": "6",
}


# ============================================================================
# Test 1: Parser
# ============================================================================


def test_parses_raw_issue_row_into_canonical_record():
    record = parse_wb_issue_row(_SAMPLE_ROW)

    assert record.source_sync_time == datetime(2026, 8, 13, 8, 40, 0)
    assert record.release_date == date(2026, 8, 12)
    assert record.release_date_raw == "2026-08-12"
    assert record.issue_quantity == 1000
    assert record.plant_id == "ASE07"  # prctr A01007 -> ASE07
    assert record.schedule == "SCH0001"
    assert record.customer_code == "C1"
    assert record.customer_name == "CUSTOMER_ONE"
    assert record.device_type == "DEVICE_A"
    assert record.package_code == "RY2N"
    assert record.package_type == "STANDARD"
    assert record.release_time == "08:00:00"
    assert record.release_system == "MES"
    assert record.time_bucket == "AM"
    assert record.wafer_inch == "12"
    assert record.year == "6"


def test_sync_time_and_release_date_are_never_conflated():
    """The whole point of item F/V: these are two genuinely different
    dates in the sample row (SYNC_TIME is 2026-08-13, rel_date is
    2026-08-12) -- the parser must keep them as two separate fields, never
    collapse one into the other."""
    record = parse_wb_issue_row(_SAMPLE_ROW)
    assert record.source_sync_time.date() != record.release_date
    assert record.source_sync_time.date() == date(2026, 8, 13)
    assert record.release_date == date(2026, 8, 12)


def test_unknown_fields_preserve_raw_value_never_interpreted():
    record = parse_wb_issue_row(_SAMPLE_ROW)
    assert record.bd_no_unknown == "BD001"
    assert record.cu_flag_unknown == "Y"
    assert record.customer_run_type_unknown == "N"
    assert record.customer_sod_unknown == "2026-08-01"
    assert record.internal_sod_unknown == "2026-08-01"
    assert record.run_type_unknown == "N"
    assert record.unit_of_measure_unknown == "P"
    assert record.user_id_unknown == "U001"
    assert record.user_name_unknown == "TESTER"


def test_unparseable_release_date_falls_back_to_none_but_preserves_raw():
    """Item H: tolerant parser, never guesses a different format, never
    raises -- release_date_raw always keeps the original string."""
    row = dict(_SAMPLE_ROW, rel_date="[DATE]")  # the literal placeholder shape from the phase spec's own sample
    record = parse_wb_issue_row(row)
    assert record.release_date is None
    assert record.release_date_raw == "[DATE]"


def test_missing_release_date_is_none_on_both_fields():
    row = dict(_SAMPLE_ROW, rel_date=None)
    record = parse_wb_issue_row(row)
    assert record.release_date is None
    assert record.release_date_raw is None


# ============================================================================
# Test 2: Missing value semantics -- "" -> None, but iss_qty=0 stays 0
# ============================================================================


def test_empty_string_fields_normalize_to_none_via_the_shared_mechanism():
    """Reuses `normalize_row_missing_values` (the same mechanism BANK/WIP/
    OEE/OUTPUT already use, item E's own explicit "don't reinvent
    normalization" instruction) -- this is exactly the pipeline
    `RemoteWBIssueDataSource` runs before calling `parse_wb_issue_row`."""
    row = dict(_SAMPLE_ROW, bd_no="", cu_flag="", customer_sod="", routid="")
    normalized = normalize_row_missing_values(row)
    record = parse_wb_issue_row(normalized)
    assert record.bd_no_unknown is None
    assert record.cu_flag_unknown is None
    assert record.customer_sod_unknown is None
    assert record.routid_unknown is None


def test_zero_issue_quantity_is_never_treated_as_missing():
    row = dict(_SAMPLE_ROW, iss_qty=0)
    normalized = normalize_row_missing_values(row)
    record = parse_wb_issue_row(normalized)
    assert record.issue_quantity == 0
    assert record.issue_quantity is not None


# ============================================================================
# Test 3: Plant mapping
# ============================================================================


def test_known_prctr_codes_map_to_canonical_plant_ids():
    for raw, expected in [("A01001", "ASE01"), ("A01002", "ASE02"), ("A01003", "ASE03"), ("A01007", "ASE07"), ("A01008", "ASE08")]:
        record = parse_wb_issue_row(dict(_SAMPLE_ROW, prctr=raw))
        assert record.plant_id == expected
        assert record.plant_id in KNOWN_PLANT_IDS


def test_unknown_prctr_code_is_preserved_raw_never_guessed():
    record = parse_wb_issue_row(dict(_SAMPLE_ROW, prctr="A99999"))
    assert record.plant_id == "A99999"  # unchanged -- never coerced to a nearest-known plant


def test_site_field_is_preserved_raw_never_canonicalized_to_one_plant():
    """Item J: `site` (e.g. "A2") is a group/site semantic covering
    multiple plants -- it must stay its own raw field, never collapsed
    into `plant_id`."""
    record = parse_wb_issue_row(_SAMPLE_ROW)
    assert record.site == "A2"
    assert record.plant_id == "ASE07"
    assert record.site != record.plant_id


# ============================================================================
# Test 11: historical-ready synthetic dataset -- observed pattern only,
# never a causal claim in the test name/assertions
# ============================================================================


def test_ase07_recent_issue_quantity_is_below_its_own_historical_baseline():
    """Item N's own worked example, verified as a pure OBSERVATION: ASE07's
    issue quantity for the days at/after ISSUE_DECLINE_START is lower than
    its own earlier baseline days. This test makes NO claim about why."""
    records = build_wb_issue_records()
    ase07 = [r for r in records if r.plant_id == SCENARIO_B_PLANT]

    baseline_days = {r.release_date for r in ase07 if r.release_date is not None and r.release_date < ISSUE_DECLINE_START}
    decline_days = {r.release_date for r in ase07 if r.release_date is not None and ISSUE_DECLINE_START <= r.release_date <= GOLDEN_DATE}
    assert baseline_days and decline_days

    def daily_total(day):
        return sum(r.issue_quantity or 0 for r in ase07 if r.release_date == day)

    baseline_avg = sum(daily_total(d) for d in baseline_days) / len(baseline_days)
    decline_avg = sum(daily_total(d) for d in decline_days) / len(decline_days)
    assert decline_avg < baseline_avg  # observed fact only


def test_other_plants_hold_a_stable_baseline_across_the_same_window():
    """Contrast check: the decline is ASE07-specific in the synthetic
    story, not a dataset-wide artifact."""
    records = build_wb_issue_records()
    for plant in ("ASE01", "ASE02", "ASE03", "ASE08"):
        plant_records = [r for r in records if r.plant_id == plant]
        totals = {r.release_date: 0 for r in plant_records}
        for r in plant_records:
            totals[r.release_date] += r.issue_quantity or 0
        assert len(set(totals.values())) == 1  # every day has the identical baseline total
