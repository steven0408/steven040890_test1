"""Phase 8B-1 Part H: `analyzer_mock` (agent/graph/nodes/analyzer_mock.py)
is a Phase 2 legacy/test fixture -- hardcodes OEE/Output/WIP module
selection, ignores TaskType. It stays available for the ~90 existing
Harness-mechanics regression tests written against it (unchanged, per this
phase's scope guard), but the production entrypoint boundary
(agent/graph/production.py) must make it structurally impossible to reach
it by accident.
"""
import ast
from pathlib import Path

import pytest
from langgraph.checkpoint.memory import InMemorySaver

from agent.graph.production import build_production_graph, build_production_graph_with_synthesis

_AGENT_DIR = Path(__file__).resolve().parents[1] / "agent"


def test_bootstrap_never_imports_analyzer_mock():
    """AST-level (not substring grep) -- proves the composition root
    itself has no import path to the legacy fixture, module-level or
    symbol-level."""
    tree = ast.parse((_AGENT_DIR / "bootstrap.py").read_text(encoding="utf-8"), filename="bootstrap.py")
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module is not None and "analyzer_mock" in node.module:
            pytest.fail(f"agent/bootstrap.py imports from '{node.module}'")
        if isinstance(node, ast.Import):
            for alias in node.names:
                if "analyzer_mock" in alias.name:
                    pytest.fail(f"agent/bootstrap.py imports '{alias.name}'")


def _custom_analyzer(state):
    return {}


def _custom_standardizer(state):
    return {}


def test_production_graph_requires_explicit_analyzer():
    with pytest.raises(TypeError):
        build_production_graph({}, InMemorySaver(), standardizer=_custom_standardizer)  # type: ignore[call-arg]


def test_production_graph_requires_explicit_standardizer():
    with pytest.raises(TypeError):
        build_production_graph({}, InMemorySaver(), analyzer=_custom_analyzer)  # type: ignore[call-arg]


def test_production_graph_with_synthesis_requires_explicit_analyzer():
    with pytest.raises(TypeError):
        build_production_graph_with_synthesis({}, InMemorySaver(), lambda state: {}, standardizer=_custom_standardizer)  # type: ignore[call-arg]


def test_production_graph_with_synthesis_requires_explicit_standardizer():
    with pytest.raises(TypeError):
        build_production_graph_with_synthesis({}, InMemorySaver(), lambda state: {}, analyzer=_custom_analyzer)  # type: ignore[call-arg]


def test_production_graph_delegates_to_build_phase2_graph_with_given_analyzer():
    """Proves build_production_graph is a pure pass-through -- no new
    topology, same node/edge shape as build_phase2_graph."""
    from agent.graph.graph import build_phase2_graph

    expected = build_phase2_graph({}, InMemorySaver(), analyzer=_custom_analyzer, standardizer=_custom_standardizer)
    actual = build_production_graph({}, InMemorySaver(), analyzer=_custom_analyzer, standardizer=_custom_standardizer)
    assert set(actual.nodes) == set(expected.nodes)
