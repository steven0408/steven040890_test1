"""Phase 5C-3 (item 8) / WB-2B.1: PlannerDecisionQuality -- a deterministic,
rule-based SOFT scoring signal for a Planner decision, distinct from
`validate_planner_decision`'s HARD gate. Exercised here against hand-built
decisions/module states so each dimension can be pinned down in isolation;
the real-provider smoke tests (test_phase5c3_real_planner_smoke.py) reuse
this same evaluator against real ModuleState snapshots.
"""
from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.planning.decision_quality import evaluate_planner_decision_quality
from agent.state.enums import (
    BranchStatus,
    EntityAnalysisStatus,
    ObjectiveAction,
    ObjectiveStatus,
    TargetRefType,
    TaskType,
)
from agent.state.models import Branch, EntityState, ObjectiveRecord, TargetRef

from .conftest import make_module_state, make_oee_capability_runtime, make_oee_skill_registry

_SCREENING_KEY = "oee.equipment_screening"
_DETAIL_KEY = "oee.equipment_detail"
_STATUS_KEY = "oee.current_status"


def _runtime():
    return make_oee_capability_runtime(MOCK_EQUIPMENT, OEE_THRESHOLD)


def _state_with_availability_branch(*, screened: bool = True) -> "ModuleState":
    state = make_module_state()
    branches = {
        "branch-availability": Branch(
            branch_id="branch-availability", name="Availability Loss", pattern="Availability",
            status=BranchStatus.ACTIVE, priority_score=0.9, tree_node_id="n1", entity_ids=["EQ001", "EQ003"],
        ),
        "branch-quality": Branch(
            branch_id="branch-quality", name="Quality Loss", pattern="Quality",
            status=BranchStatus.PENDING, priority_score=0.3, tree_node_id="n2", entity_ids=["EQ009"],
        ),
    }
    entity_states = {
        "EQ001": EntityState(entity_id="EQ001", entity_type="EQUIPMENT", status=EntityAnalysisStatus.SCREENED, current_tree_node_id="n3", branch_id="branch-availability", priority_score=0.85),
        "EQ009": EntityState(entity_id="EQ009", entity_type="EQUIPMENT", status=EntityAnalysisStatus.SCREENED, current_tree_node_id="n4", branch_id="branch-quality", priority_score=0.3),
    }
    objective_history = {}
    if screened:
        objective_history["OEE-obj-1"] = ObjectiveRecord(
            objective_id="OEE-obj-1", description="screen", action=ObjectiveAction.SCREEN, capability_key=_SCREENING_KEY,
            target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="OEE"), status=ObjectiveStatus.COMPLETED,
            created_step=1, attempt_count=1,
        )
    return state.model_copy(update={"branches": branches, "entity_states": entity_states, "objective_history": objective_history})


def _dispatch(action: ObjectiveAction, ref_type: TargetRefType, ref_id: str, *, capability_key: str | None, priority: float = 0.8) -> PlannerDecision:
    return PlannerDecision(
        decision=PlannerDecisionType.DISPATCH,
        next_objective=ObjectiveProposal(action=action, capability_key=capability_key, target_ref=TargetRef(ref_type=ref_type, ref_id=ref_id), description="d", expected_output="e"),
        priority=priority,
        rationale_summary="r",
    )


def _evaluate(decision, *, module_state, task_type):
    return evaluate_planner_decision_quality(
        decision, module_state=module_state, task_type=task_type,
        capability_resolver=_runtime().capability_resolver, skill_registry=make_oee_skill_registry(),
    )


def test_no_viable_objective_reports_fully_valid():
    decision = PlannerDecision(decision=PlannerDecisionType.NO_VIABLE_OBJECTIVE, rationale_summary="budget exhausted")
    quality = _evaluate(decision, module_state=make_module_state(), task_type=TaskType.RCA)
    assert quality.overall_score == 1.0


def test_action_invalid_for_task_type():
    state = _state_with_availability_branch()
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", capability_key=_DETAIL_KEY)
    quality = _evaluate(decision, module_state=state, task_type=TaskType.INFORMATION)
    assert quality.action_valid is False


def test_target_invalid_hallucinated_entity():
    state = _state_with_availability_branch()
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ999", capability_key=_DETAIL_KEY)
    quality = _evaluate(decision, module_state=state, task_type=TaskType.RCA)
    assert quality.target_valid is False


def test_task_depth_invalid_detail_before_screening():
    state = _state_with_availability_branch(screened=False)
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", capability_key=_DETAIL_KEY)
    quality = _evaluate(decision, module_state=state, task_type=TaskType.RCA)
    assert quality.task_depth_valid is False


def test_task_depth_valid_detail_after_screening():
    state = _state_with_availability_branch(screened=True)
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", capability_key=_DETAIL_KEY)
    quality = _evaluate(decision, module_state=state, task_type=TaskType.RCA)
    assert quality.task_depth_valid is True


def test_target_not_relevant_when_branch_not_active():
    state = _state_with_availability_branch()
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ009", capability_key=_DETAIL_KEY)  # Quality branch is PENDING, not ACTIVE
    quality = _evaluate(decision, module_state=state, task_type=TaskType.RCA)
    assert quality.target_relevant is False


def test_target_relevant_when_branch_active():
    state = _state_with_availability_branch()
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", capability_key=_DETAIL_KEY)
    quality = _evaluate(decision, module_state=state, task_type=TaskType.RCA)
    assert quality.target_relevant is True


def test_target_already_explored_is_flagged():
    state = _state_with_availability_branch()
    state = state.model_copy(update={"objective_history": {
        **state.objective_history,
        "OEE-obj-2": ObjectiveRecord(
            objective_id="OEE-obj-2", description="EQ001 detail", action=ObjectiveAction.DRILL_DOWN, capability_key=_DETAIL_KEY,
            target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="EQ001"), status=ObjectiveStatus.COMPLETED,
            created_step=2, attempt_count=1,
        ),
    }})
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", capability_key=_DETAIL_KEY)
    quality = _evaluate(decision, module_state=state, task_type=TaskType.RCA)
    assert quality.target_unexplored is False


def test_capability_available_true_for_real_oee_action():
    state = _state_with_availability_branch()
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", capability_key=_DETAIL_KEY)
    quality = _evaluate(decision, module_state=state, task_type=TaskType.RCA)
    assert quality.capability_available is True


def test_capability_available_false_for_unknown_capability_key():
    state = _state_with_availability_branch()
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", capability_key="oee.not_a_real_capability")
    quality = _evaluate(decision, module_state=state, task_type=TaskType.RCA)
    assert quality.capability_available is False


def test_priority_alignment_close_to_entity_priority_score():
    state = _state_with_availability_branch()  # EQ001.priority_score == 0.85
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", capability_key=_DETAIL_KEY, priority=0.85)
    quality = _evaluate(decision, module_state=state, task_type=TaskType.RCA)
    assert quality.priority_alignment == 1.0


def test_priority_alignment_penalizes_large_mismatch():
    state = _state_with_availability_branch()  # EQ001.priority_score == 0.85
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", capability_key=_DETAIL_KEY, priority=0.1)
    quality = _evaluate(decision, module_state=state, task_type=TaskType.RCA)
    assert quality.priority_alignment < 0.5


def test_fully_valid_decision_scores_1_0():
    state = _state_with_availability_branch()  # EQ001.priority_score == 0.85
    decision = _dispatch(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", capability_key=_DETAIL_KEY, priority=0.85)
    quality = _evaluate(decision, module_state=state, task_type=TaskType.RCA)
    assert quality.overall_score == 1.0


def test_module_target_current_status_is_always_relevant_and_valid():
    state = make_module_state()
    decision = _dispatch(ObjectiveAction.SUMMARIZE, TargetRefType.MODULE, "OEE", capability_key=_STATUS_KEY)
    quality = _evaluate(decision, module_state=state, task_type=TaskType.INFORMATION)
    assert quality.action_valid and quality.target_valid and quality.target_relevant and quality.capability_available
