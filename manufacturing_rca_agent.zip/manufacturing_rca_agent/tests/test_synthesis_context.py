"""Phase 6A item 3/4/13: SynthesisContext -- built from AgentState (never
the raw AgentState itself reaching a renderer/future LLM), reasoning-skill
sharing across Analyzer/Planner/Synthesis, Executor's permanent exclusion,
context budget control, and the SynthesisContextBuildRecord audit trail.
"""
from pathlib import Path

from agent.llm.context.reasoning_skill_retriever import DeterministicReasoningSkillRetriever
from agent.llm.context.synthesis_context import SynthesisContextBudget, SynthesisContextBuilder
from agent.llm.context.synthesis_context_audit import InMemorySynthesisContextAuditSink
from agent.skills.models import SkillConsumerNode
from agent.skills.registry import SkillRegistry
from agent.state.enums import FindingStatus, ModuleStatus, TaskType
from agent.state.models import Finding, Goal, GoalScope
from agent.synthesis.handoff_builder import ModuleHandoffBuilder

from .conftest import make_agent_state, make_module_state

REASONING_SKILLS_DIR = Path(__file__).resolve().parent.parent / "agent" / "skills" / "reasoning"


def _reasoning_registry() -> SkillRegistry:
    registry = SkillRegistry()
    registry.load_directory(REASONING_SKILLS_DIR)
    return registry


def _state_with_one_complete_oee_module():
    module_state = make_module_state().model_copy(
        update={
            "status": ModuleStatus.COMPLETE,
            "findings": [Finding(finding_id="f1", statement="Motor Failure.", pattern="Availability", confidence=0.9, status=FindingStatus.CONFIRMED, is_root_cause=True)],
        }
    )
    state = make_agent_state()
    return state.model_copy(
        update={
            "module_states": {"OEE": module_state},
            "global_goal": Goal(goal_id="g1", raw_statement="為什麼 OEE 下降？", normalized_statement="Why did OEE decline?", task_type=TaskType.RCA, scope=GoalScope()),
        }
    )


# ============================================================================
# Reasoning skill retrieval sharing (item 4)
# ============================================================================


def test_analyzer_planner_and_synthesis_can_each_retrieve_the_same_reasoning_skill():
    registry = _reasoning_registry()
    retriever = DeterministicReasoningSkillRetriever(registry)

    analyzer_result = retriever.retrieve(node=SkillConsumerNode.ANALYZER, module_type=None, task_type=None, limit=5)
    planner_result = retriever.retrieve(node=SkillConsumerNode.PLANNER, module_type="OEE", task_type=TaskType.RCA, limit=5)
    synthesis_result = retriever.retrieve(node=SkillConsumerNode.SYNTHESIS, module_type=None, task_type=TaskType.RCA, limit=5)

    assert {r.skill_id for r in analyzer_result} == {"reasoning.plant_manager_perspective"}
    assert {r.skill_id for r in planner_result} == {"reasoning.plant_manager_perspective"}
    assert {r.skill_id for r in synthesis_result} == {"reasoning.plant_manager_perspective"}


def test_executor_never_retrieves_a_reasoning_skill():
    registry = _reasoning_registry()
    retriever = DeterministicReasoningSkillRetriever(registry)
    assert retriever.retrieve(node=SkillConsumerNode.EXECUTOR, module_type="OEE", task_type=TaskType.RCA, limit=5) == []


def test_synthesis_context_includes_the_reasoning_skill():
    builder = SynthesisContextBuilder(ModuleHandoffBuilder(), reasoning_skill_retriever=DeterministicReasoningSkillRetriever(_reasoning_registry()))
    outcome = builder.build(_state_with_one_complete_oee_module())

    assert [s.skill_id for s in outcome.context.relevant_reasoning_skills] == ["reasoning.plant_manager_perspective"]
    assert outcome.record.included_reasoning_skills_count == 1


def test_synthesis_context_with_no_retriever_is_a_no_op():
    builder = SynthesisContextBuilder(ModuleHandoffBuilder())
    outcome = builder.build(_state_with_one_complete_oee_module())
    assert outcome.context.relevant_reasoning_skills == []


# ============================================================================
# Budget (item 4's third validation point) + audit (item 13)
# ============================================================================


def test_reasoning_skills_respect_budget_limit():
    builder = SynthesisContextBuilder(ModuleHandoffBuilder(), reasoning_skill_retriever=DeterministicReasoningSkillRetriever(_reasoning_registry()))
    outcome = builder.build(_state_with_one_complete_oee_module(), budget=SynthesisContextBudget(max_reasoning_skills=0))
    assert outcome.context.relevant_reasoning_skills == []


def test_module_handoffs_are_never_trimmed_even_at_a_tiny_character_budget():
    builder = SynthesisContextBuilder(ModuleHandoffBuilder(), reasoning_skill_retriever=DeterministicReasoningSkillRetriever(_reasoning_registry()))
    outcome = builder.build(_state_with_one_complete_oee_module(), budget=SynthesisContextBudget(max_context_characters=1))
    assert len(outcome.context.module_handoffs) == 1
    assert outcome.context.module_handoffs[0].module_id == "mod-oee"
    # only the trimmable buckets shrank
    assert outcome.context.relevant_reasoning_skills == []


def test_context_build_record_counts_and_audit_sink():
    sink = InMemorySynthesisContextAuditSink()
    builder = SynthesisContextBuilder(ModuleHandoffBuilder(), audit_sink=sink)
    state = _state_with_one_complete_oee_module()

    outcome = builder.build(state)

    record = outcome.record
    assert record.run_id == state.run_id
    assert record.included_modules == ["mod-oee"]
    assert record.included_findings_count == 1
    assert record.included_root_causes_count == 1
    assert record.build_duration_ms >= 0
    assert record.estimated_context_characters == len(outcome.context.model_dump_json())
    assert sink.list_for_run(state.run_id) == [record]
    assert sink.list_for_run("some-other-run") == []


def test_multiple_modules_are_sorted_deterministically():
    oee = make_module_state(module_id="OEE", module_type="OEE").model_copy(update={"status": ModuleStatus.COMPLETE})
    output = make_module_state(module_id="Output", module_type="Output").model_copy(update={"status": ModuleStatus.COMPLETE})
    state = make_agent_state().model_copy(update={"module_states": {"Output": output, "OEE": oee}})

    outcome = SynthesisContextBuilder(ModuleHandoffBuilder()).build(state)
    assert [h.module_id for h in outcome.context.module_handoffs] == ["OEE", "Output"]
