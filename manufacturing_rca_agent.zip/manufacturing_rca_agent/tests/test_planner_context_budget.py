"""Phase 5C-1: PlannerContextBudget trimming priority + ContextBuildRecord
audit -- Hard Rules/Goal (and current critical state) must never be trimmed
away, no matter how small the character budget; lower-priority sections
(history, knowledge, capabilities, findings/hypotheses, evidence, in that
order) are trimmed first.
"""
from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
from agent.llm.context.context_audit import InMemoryContextAuditSink
from agent.llm.context.evidence_selector import DeterministicEvidenceSelector
from agent.llm.context.planner_context import PlannerContextBudget, PlannerContextBuilder
from agent.state.enums import TaskType

from .conftest import make_oee_skill_registry, run_oee_module_state_history


def _builder(audit_sink=None) -> PlannerContextBuilder:
    return PlannerContextBuilder(DeterministicEvidenceSelector(), DeterministicCapabilityRetriever(make_oee_skill_registry()), audit_sink=audit_sink)


def test_hard_rules_and_goal_survive_an_extremely_small_character_budget():
    history = run_oee_module_state_history(TaskType.RCA)
    final_state = history[-1]

    tiny_budget = PlannerContextBudget(max_findings=10, max_evidence=10, max_skills=6, max_knowledge_items=5, max_history_items=10, max_context_characters=1)
    outcome = _builder().build(final_state, run_id="run-ctx", budget=tiny_budget)

    assert outcome.context.hard_rules  # never emptied
    assert outcome.context.goal.task_type == TaskType.RCA
    assert outcome.context.goal.module_goal_statement  # never emptied
    # current critical state also protected -- current_objective/limitations/active_branches never trimmed
    assert outcome.context.current_state.active_branches or final_state.branches == {}


def test_trimming_removes_lower_priority_sections_first():
    history = run_oee_module_state_history(TaskType.RCA)
    final_state = history[-1]

    generous = _builder().build(final_state, run_id="run-ctx", budget=PlannerContextBudget(max_history_items=10, max_context_characters=100_000)).context
    assert generous.history_summary  # non-empty at a generous budget

    tight = PlannerContextBudget(max_findings=10, max_evidence=10, max_skills=6, max_knowledge_items=5, max_history_items=10, max_context_characters=1200)
    trimmed = _builder().build(final_state, run_id="run-ctx", budget=tight).context
    # history_summary is first in the trim sequence -- it should shrink
    # before relevant_evidence (second-to-last priority) does
    assert len(trimmed.history_summary) <= len(generous.history_summary)


def test_context_build_record_counts_and_audit_sink():
    history = run_oee_module_state_history(TaskType.RCA)
    final_state = history[-1]
    sink = InMemoryContextAuditSink()

    outcome = _builder(audit_sink=sink).build(final_state, run_id="run-ctx-audit", node="module_planner")

    record = outcome.record
    assert record.run_id == "run-ctx-audit"
    assert record.module_id == final_state.module_id
    assert record.node == "module_planner"
    assert record.included_evidence_count == len(outcome.context.relevant_evidence)
    assert record.included_skills_count == len(outcome.context.relevant_capabilities)
    assert record.included_findings_count == len(outcome.context.current_state.top_findings)
    assert record.estimated_context_characters == len(outcome.context.model_dump_json())
    assert record.build_duration_ms >= 0

    stored = sink.list_for_run("run-ctx-audit")
    assert stored == [record]
    assert sink.list_for_run("some-other-run") == []


def test_default_budgets_grow_from_information_to_analysis_to_rca():
    from agent.llm.context.planner_context import _DEFAULT_BUDGETS

    info, analysis, rca = _DEFAULT_BUDGETS[TaskType.INFORMATION], _DEFAULT_BUDGETS[TaskType.ANALYSIS], _DEFAULT_BUDGETS[TaskType.RCA]
    assert info.max_context_characters < analysis.max_context_characters < rca.max_context_characters
    assert info.max_knowledge_items == 0
    assert info.max_evidence <= analysis.max_evidence <= rca.max_evidence
