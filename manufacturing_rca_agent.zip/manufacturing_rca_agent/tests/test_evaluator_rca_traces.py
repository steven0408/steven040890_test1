"""Phase 7A items 13.C/13.D/13.E: RCA COMPLETE (high root-cause support),
RCA PARTIAL (root cause absent but transparently explained -- not treated
as a hallucination failure), and the hallucinated-root-cause guard.
"""
from agent.evaluation.evaluator import RunEvaluator
from agent.state.enums import ErrorType, EvaluationSeverity, FindingStatus, ModuleStatus, TaskType
from agent.state.models import ErrorRecord, Finding, HandoffPackage, Limitation

from .conftest import make_agent_state, make_module_state, make_run_audit_bundle_from_modules, run_oee_module_state_history


def test_rca_complete_has_high_root_cause_support():
    history = run_oee_module_state_history(TaskType.RCA)
    final = history[-1]
    assert final.status == ModuleStatus.COMPLETE

    state = make_agent_state().model_copy(update={"module_states": {"OEE": final}})
    bundle = make_run_audit_bundle_from_modules([final])
    evaluation = RunEvaluator().evaluate(state, bundle)

    assert evaluation.analytical_quality.root_cause_support_score == 1.0
    assert evaluation.delivery_quality.hallucination_guard_passed is True
    assert not any(i.metric_name == "root_cause_support_score" for i in evaluation.issues)


def test_rca_partial_availability_confirmed_detail_missing_not_treated_as_hallucination():
    module_state = make_module_state().model_copy(
        update={
            "status": ModuleStatus.PARTIAL,
            "findings": [Finding(finding_id="f1", statement="Availability is the dominant loss pattern.", pattern="Availability", confidence=0.7, status=FindingStatus.CONFIRMED, is_root_cause=False)],
            "limitations": [
                Limitation(
                    limitation_id="lim1", description="EQ001 downtime detail unavailable.", impacted_objective_id="o1",
                    impact_statement="failure mechanism unknown",
                    related_error=ErrorRecord(error_type=ErrorType.DATA_NOT_FOUND, message="x", objective_id="o1", occurred_at_step=1),
                )
            ],
        }
    )
    state = make_agent_state().model_copy(update={"module_states": {"OEE": module_state}})
    bundle = make_run_audit_bundle_from_modules([module_state])
    evaluation = RunEvaluator().evaluate(state, bundle)

    # a real partial score (not 0), and NOT flagged as a "low support root
    # cause" issue -- nothing was actually presented as a root cause
    assert evaluation.analytical_quality.root_cause_support_score == 0.5
    assert not any(i.metric_name == "root_cause_support_score" for i in evaluation.issues)
    assert evaluation.delivery_quality.hallucination_guard_passed is True
    assert evaluation.analytical_quality.limitation_transparency_score == 1.0


def test_rca_partial_with_no_limitation_at_all_scores_lower_than_explained_gap():
    silent_module = make_module_state().model_copy(update={"status": ModuleStatus.PARTIAL, "findings": [], "limitations": []})
    state = make_agent_state().model_copy(update={"module_states": {"OEE": silent_module}})
    bundle = make_run_audit_bundle_from_modules([silent_module])
    evaluation = RunEvaluator().evaluate(state, bundle)

    assert evaluation.analytical_quality.root_cause_support_score == 0.2
    assert evaluation.analytical_quality.limitation_transparency_score == 0.0


def test_hallucinated_root_cause_in_handoff_flags_high_issue():
    """A hand-constructed HandoffPackage claims a root cause that the
    underlying module_states never actually confirmed -- simulating a
    hypothetical Synthesis bug (Phase 6B's own guarantees prevent this in
    practice, but the Evaluator's guard must still catch it if it ever
    happens, independent of trusting Synthesis blindly)."""
    from agent.state.models import ConfidenceSummary, RootCause
    from agent.state.enums import SynthesisOverallStatus

    module_state = make_module_state().model_copy(
        update={"status": ModuleStatus.PARTIAL, "findings": [Finding(finding_id="f1", statement="Availability dominant.", pattern="Availability", confidence=0.6, status=FindingStatus.CONFIRMED, is_root_cause=False)]}
    )
    state = make_agent_state().model_copy(update={"module_states": {"OEE": module_state}})

    hallucinated_package = HandoffPackage(
        run_id=state.run_id, request_summary="why", task_type=TaskType.RCA, overall_status=SynthesisOverallStatus.PARTIAL,
        module_results=[], key_findings=[],
        root_causes=[RootCause(root_cause_id="rc-hallucinated", statement="Motor Failure (never actually confirmed).", module_id="OEE", confidence=0.9)],
        confidence_summary=ConfidenceSummary(overall_confidence=0.9, evidence_coverage=0.9),
    )
    state = state.model_copy(update={"synthesis_result": hallucinated_package})

    bundle = make_run_audit_bundle_from_modules([module_state])
    evaluation = RunEvaluator().evaluate(state, bundle)

    assert evaluation.delivery_quality.hallucination_guard_passed is False
    issue = next(i for i in evaluation.issues if i.metric_name == "hallucination_guard_passed")
    assert issue.severity == EvaluationSeverity.HIGH
