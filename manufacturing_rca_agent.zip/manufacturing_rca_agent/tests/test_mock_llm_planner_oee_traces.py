﻿"""Phase 5C-2: Mock LLM Planner OEE traces -- INFORMATION/ANALYSIS/RCA,
exercised through the real (module-level) Module ReAct Subgraph, same
Harness as every prior Planner phase. `OEEPlanningPolicy` is not deleted --
it's both the fallback LLMPlanningPolicy uses on failure AND the
deterministic regression oracle the RCA dynamic trace is compared against.
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.planning.policies.oee import OEEPlanningPolicy
from agent.state.enums import (
    EntityAnalysisStatus,
    FindingStatus,
    ModuleStatus,
    ObjectiveAction,
    ObjectiveStatus,
    TargetRefType,
    TaskType,
)
from agent.state.models import ModuleState, ModuleTask, TargetRef

from .conftest import make_budget, make_llm_planning_policy, make_oee_capability_runtime


def _run_oee(policy, task_type: TaskType, thread_id: str, *, capability_kwargs=None):
    runtime = make_oee_capability_runtime(MOCK_EQUIPMENT, OEE_THRESHOLD, **(capability_kwargs or {}))
    graph = build_module_react_subgraph(policy, capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id="OEE", module_type="OEE", reason="test", goal_statement="test goal", confidence=0.9, priority=0.9, task_type=task_type)
    initial = build_initial_module_state(
        task, make_budget(max_steps=6, max_tool_calls=20, max_depth_per_entity=3), run_id=f"run-{thread_id}", task_type=task_type
    )
    config = {"configurable": {"thread_id": thread_id}}
    result = app.invoke(initial, config=config)
    return ModuleState.model_validate(result)


def _proposal(action, ref_type, ref_id, description, capability_key) -> ObjectiveProposal:
    return ObjectiveProposal(action=action, capability_key=capability_key, target_ref=TargetRef(ref_type=ref_type, ref_id=ref_id), description=description, expected_output="analysis data")


# ============================================================================
# item 7: INFORMATION trace
# ============================================================================


def test_information_trace_dispatches_current_status_only():
    decision = PlannerDecision(
        decision=PlannerDecisionType.DISPATCH,
        next_objective=_proposal(ObjectiveAction.SUMMARIZE, TargetRefType.MODULE, "OEE", "Get current OEE status", "oee.current_status"),
        priority=1.0,
        rationale_summary="User asked for current OEE only.",
    )
    policy, usage_sink, client = make_llm_planning_policy(lambda req: decision)

    final_state = _run_oee(policy, TaskType.INFORMATION, "info-trace")

    assert final_state.status == ModuleStatus.COMPLETE
    targets = [r.action for r in final_state.objective_history.values()]
    assert targets == [ObjectiveAction.SUMMARIZE]  # never EQUIPMENT_SCREENING / EQUIPMENT_DETAIL
    assert [tc.tool_id for tc in final_state.tool_calls] == ["query_oee_data", "aggregate_oee_status"]
    assert len(client.calls) == 1  # single round -- LLM asked exactly once


# ============================================================================
# item 8: ANALYSIS trace
# ============================================================================


def test_analysis_trace_dispatches_equipment_screening_and_stops_before_root_cause():
    decision = PlannerDecision(
        decision=PlannerDecisionType.DISPATCH,
        next_objective=_proposal(ObjectiveAction.SCREEN, TargetRefType.MODULE, "OEE", "Screen and rank abnormal equipment", "oee.equipment_screening"),
        priority=1.0,
        rationale_summary="User asked which equipment is worse.",
    )
    policy, usage_sink, client = make_llm_planning_policy(lambda req: decision)

    final_state = _run_oee(policy, TaskType.ANALYSIS, "analysis-trace")

    assert final_state.status == ModuleStatus.COMPLETE
    targets = [r.action for r in final_state.objective_history.values()]
    assert targets == [ObjectiveAction.SCREEN]  # never EQUIPMENT_DETAIL
    assert len(client.calls) == 1  # never asked a second time to go deeper

    finding = final_state.findings[-1]
    assert finding.is_root_cause is False
    assert final_state.entity_states == {}  # never entered RCA deep-dive machinery


# ============================================================================
# item 9 + 10: RCA dynamic multi-round trace vs. deterministic baseline
# ============================================================================


class _SequencedResponder:
    def __init__(self, decisions: list[PlannerDecision]):
        self._decisions = decisions
        self.calls = 0

    def __call__(self, request):
        index = min(self.calls, len(self._decisions) - 1)
        self.calls += 1
        return self._decisions[index]


def _rca_decision_sequence() -> list[PlannerDecision]:
    return [
        PlannerDecision(
            decision=PlannerDecisionType.DISPATCH,
            next_objective=_proposal(ObjectiveAction.SCREEN, TargetRefType.MODULE, "OEE", "Screen abnormal equipment", "oee.equipment_screening"),
            priority=1.0,
            rationale_summary="No screening evidence yet.",
        ),
        PlannerDecision(
            decision=PlannerDecisionType.DISPATCH,
            # canonical TargetRef (Phase 5C-2.1): action=DRILL_DOWN already
            # says WHAT; target_ref.ref_id is just the bare entity id.
            next_objective=_proposal(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ001", "Deep-dive EQ001", "oee.equipment_detail"),
            priority=1.0,
            rationale_summary="Availability dominant; EQ001, EQ003, EQ012 candidates; EQ001 highest contribution.",
        ),
        PlannerDecision(
            decision=PlannerDecisionType.DISPATCH,
            next_objective=_proposal(ObjectiveAction.DRILL_DOWN, TargetRefType.ENTITY, "EQ003", "Deep-dive EQ003", "oee.equipment_detail"),
            priority=1.0,
            rationale_summary="EQ001 confirmed Motor Failure; EQ003 still unexplored in the same branch.",
        ),
    ]


def test_rca_dynamic_trace_matches_deterministic_oee_planning_policy_baseline():
    responder = _SequencedResponder(_rca_decision_sequence())
    policy, usage_sink, client = make_llm_planning_policy(responder)

    llm_final = _run_oee(policy, TaskType.RCA, "llm-rca")
    baseline_final = _run_oee(OEEPlanningPolicy(), TaskType.RCA, "baseline-rca")

    assert llm_final.status == ModuleStatus.COMPLETE == baseline_final.status

    llm_targets = [r.target_ref.ref_id for r in llm_final.objective_history.values()]
    baseline_targets = [r.target_ref.ref_id for r in baseline_final.objective_history.values()]
    assert llm_targets == baseline_targets == ["OEE", "EQ001", "EQ003"]  # canonical TargetRef (Phase 5C-2.1)
    assert llm_final.objective_history.keys() == baseline_final.objective_history.keys()
    assert all(r.status == ObjectiveStatus.COMPLETED for r in llm_final.objective_history.values())

    llm_finding, baseline_finding = llm_final.findings[-1], baseline_final.findings[-1]
    assert llm_finding.statement == baseline_finding.statement
    assert llm_finding.is_root_cause is True
    assert set(llm_finding.entity_ids) == set(baseline_finding.entity_ids) == {"EQ001", "EQ003"}
    assert "Motor Failure" in llm_finding.pattern

    assert llm_final.branches.keys() == baseline_final.branches.keys()
    assert llm_final.entity_states.keys() == baseline_final.entity_states.keys()
    assert llm_final.entity_states["EQ001"].status == baseline_final.entity_states["EQ001"].status == EntityAnalysisStatus.ROOT_CAUSE_FOUND

    # exactly 3 LLM Planner rounds -- matches the baseline's own round count
    assert len(client.calls) == 3
    assert len(usage_sink.list_for_run(llm_final.run_id)) == 3


# ============================================================================
# item 13: LLM Planner cannot set ModuleStatus -- only Module Completion
# Check decides the terminal status, regardless of stop_candidate
# ============================================================================


def test_llm_planner_stop_candidate_does_not_directly_set_module_status():
    """PlannerDecision has no status field to begin with (schema-closed --
    see test_planner_decision_schema.py), but this proves it end to end:
    even when the LLM sets stop_candidate=True after a failed observation
    with zero findings gathered, the resulting status is exactly what
    Module Completion Check's own findings-based rule computes (FAILED),
    not something the Planner/LLM claimed."""
    decisions = [
        PlannerDecision(
            decision=PlannerDecisionType.DISPATCH,
            next_objective=_proposal(ObjectiveAction.SUMMARIZE, TargetRefType.MODULE, "OEE", "Get current OEE status", "oee.current_status"),
            priority=1.0,
            rationale_summary="Try current status.",
        ),
        PlannerDecision(decision=PlannerDecisionType.NO_VIABLE_OBJECTIVE, rationale_summary="Data source unavailable.", stop_candidate=True),
    ]
    responder = _SequencedResponder(decisions)
    policy, _, _ = make_llm_planning_policy(responder)

    final_state = _run_oee(policy, TaskType.INFORMATION, "stop-responsibility", capability_kwargs={"query_unavailable": True})

    assert final_state.findings == []  # the only data source failed -- nothing was ever confirmed
    assert final_state.status == ModuleStatus.FAILED  # Module Completion Check's own rule: no findings -> FAILED
