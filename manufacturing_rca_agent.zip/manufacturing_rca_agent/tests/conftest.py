from datetime import datetime, timezone
from pathlib import Path

from langgraph.checkpoint.memory import InMemorySaver

from agent.analysis.analysis_tree import AnalysisTree, AnalysisTreeNode
from agent.capability.resolver import CapabilityResolver
from agent.catalog.module_registry import ModuleDefinition, ModuleRegistry
from agent.evaluation.inputs import RunAuditBundle
from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD, EquipmentRecord, register_oee_result_payloads
from agent.domain.oee.datasource import InMemoryOEEDataSource
from agent.graph.nodes.analyzer_llm import AnalyzerLLMService
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.llm.client import MockLLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.context.analyzer_context import AnalyzerContextBuilder
from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
from agent.llm.context.evidence_selector import DeterministicEvidenceSelector
from agent.llm.context.planner_context import PlannerContextBuilder
from agent.llm.context.synthesis_context import SynthesisContextBuilder
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.planning.policies.llm import LLMPlanningPolicy
from agent.planning.policies.oee import OEEPlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.synthesis.handoff_builder import ModuleHandoffBuilder
from agent.synthesis.llm_service import SynthesisLLMService
from agent.state.enums import EvidenceQuality, TaskType, TreeNodeType
from agent.state.models import (
    AnalysisSpace,
    Budget,
    FactoryContext,
    ModuleGoal,
    ModuleState,
    ModuleTask,
    NormalizedRequest,
    SuccessCriteria,
    UserRequest,
)
from agent.state.state import AgentState
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.oee.capability_tools import (
    AggregateOEEStatusTool,
    CalculateContributionTool,
    FilterRowsTool,
    QueryEquipmentDetailTool,
    QueryOEEDataTool,
    RankingTool,
    register_oee_input_payloads,
)
from agent.tools.registry import ToolRegistry

OEE_SKILLS_DIR = Path(__file__).resolve().parents[1] / "agent" / "skills" / "oee"


def make_budget(**overrides) -> Budget:
    base = dict(max_steps=20, max_tool_calls=40, max_depth_per_entity=5)
    base.update(overrides)
    return Budget(**base)


def make_analysis_tree(root_label: str = "OEE") -> AnalysisTree:
    tree = AnalysisTree(root_id="root")
    tree.add_node(
        AnalysisTreeNode(node_id="root", parent_id=None, label=root_label, node_type=TreeNodeType.MODULE)
    )
    return tree


def make_module_state(module_id: str = "mod-oee", module_type: str = "OEE", run_id: str = "run-1") -> ModuleState:
    return ModuleState(
        module_id=module_id,
        module_type=module_type,
        run_id=run_id,
        goal=ModuleGoal(
            module_id=module_id,
            statement="Why did OEE decline?",
            task_type=TaskType.RCA,
            success_criteria=SuccessCriteria(
                min_evidence_quality=EvidenceQuality.MODERATE,
                root_cause_coverage_threshold=0.7,
                required_dimensions=["Availability", "Performance", "Quality"],
            ),
        ),
        analysis_space=AnalysisSpace(
            root_dimension=module_type,
            dimensions={module_type: ["Equipment", "Time", "Availability", "Performance", "Quality", "Loss"]},
        ),
        analysis_tree=make_analysis_tree(module_type),
        budget=make_budget(max_steps=10, max_tool_calls=20, max_depth_per_entity=4),
    )


def make_agent_state(run_id: str = "run-1", raw_text: str = "為什麼今天 Output 不足？") -> AgentState:
    now = datetime(2026, 8, 9, tzinfo=timezone.utc)
    return AgentState(
        run_id=run_id,
        user_request=UserRequest(
            request_id="req-1",
            raw_text=raw_text,
            submitted_by="steven040890@gmail.com",
            submitted_at=now,
        ),
        normalized_request=NormalizedRequest(
            request_id="req-1",
            normalized_text="Why is today's output below target?",
            factory_id="factory-a",
        ),
        factory_context=FactoryContext(
            factory_id="factory-a",
            factory_name="Factory A",
            enabled_modules=["OEE", "Output", "WIP"],
        ),
        global_budget=make_budget(),
    )


def make_oee_tool_registry(
    equipment: list[EquipmentRecord],
    threshold: float,
    *,
    query_unavailable: bool = False,
    detail_unavailable_targets: frozenset[str] = frozenset(),
) -> ToolRegistry:
    """The Phase 5B-2 capability-layer ToolRegistry for OEE -- shared by the
    RCA single-step Skills (query_oee_data / query_equipment_detail, which
    reproduce OEEDataTool's exact semantics) and the ANALYSIS/INFORMATION
    multi-step Skills (filter_rows / calculate_contribution / ranking /
    aggregate_oee_status).

    Phase 8B-1: registers OEE's payload types explicitly (idempotent --
    safe to call from every test that reaches for this helper, mirrors
    what the real OEE ModulePackage does at bootstrap) and builds Tools
    against an `InMemoryOEEDataSource` instead of handing them the raw
    `equipment` list directly."""
    register_oee_result_payloads()
    register_oee_input_payloads()
    datasource = InMemoryOEEDataSource(equipment, unavailable=query_unavailable, unavailable_targets=detail_unavailable_targets)
    registry = ToolRegistry()
    registry.register(QueryOEEDataTool(datasource, threshold))
    registry.register(QueryEquipmentDetailTool(datasource))
    registry.register(FilterRowsTool())
    registry.register(CalculateContributionTool())
    registry.register(RankingTool())
    registry.register(AggregateOEEStatusTool())
    return registry


def make_oee_skill_registry() -> SkillRegistry:
    registry = SkillRegistry()
    registry.load_directory(OEE_SKILLS_DIR)
    return registry


def make_oee_capability_runtime(
    equipment: list[EquipmentRecord],
    threshold: float,
    *,
    query_unavailable: bool = False,
    detail_unavailable_targets: frozenset[str] = frozenset(),
) -> ModuleCapabilityRuntime:
    tool_registry = make_oee_tool_registry(
        equipment, threshold, query_unavailable=query_unavailable, detail_unavailable_targets=detail_unavailable_targets
    )
    skill_registry = make_oee_skill_registry()
    skill_registry.validate_required_tools(tool_registry)
    resolver = CapabilityResolver(skill_registry, tool_registry)
    runner = SkillRunner(tool_registry, ToolExecutionManager())
    return ModuleCapabilityRuntime(capability_resolver=resolver, skill_runner=runner)


def make_module_registry() -> ModuleRegistry:
    """Phase 5B-3 ModuleRegistry catalog -- OEE/Output/WIP. Output/WIP don't
    have a real ModulePlanningPolicy/capability layer yet; this is just the
    decision-level catalog Analyzer reads, independent of whatever runtime
    actually executes a module once dispatched."""
    registry = ModuleRegistry()
    registry.register(
        ModuleDefinition(
            module_type="OEE",
            name="OEE Analysis",
            description="Overall Equipment Effectiveness -- Availability/Performance/Quality across equipment.",
            supported_task_types=[TaskType.INFORMATION, TaskType.ANALYSIS, TaskType.RCA],
            key_questions=["What is current OEE?", "Which equipment has the worst OEE?", "Why did OEE decline?"],
        )
    )
    registry.register(
        ModuleDefinition(
            module_type="Output",
            name="Output Analysis",
            description="Production output/throughput against target.",
            supported_task_types=[TaskType.INFORMATION, TaskType.ANALYSIS, TaskType.RCA],
            key_questions=["What is current output?", "Which lines are under target?", "Why is output insufficient?"],
        )
    )
    registry.register(
        ModuleDefinition(
            module_type="WIP",
            name="WIP Analysis",
            description="Work-in-progress inventory levels and congestion.",
            supported_task_types=[TaskType.INFORMATION, TaskType.ANALYSIS, TaskType.RCA],
            key_questions=["What is current WIP level?", "Where is WIP congested?", "Why is WIP building up?"],
        )
    )
    return registry


def make_analyzer_llm_service(
    responder, *, module_registry: ModuleRegistry | None = None, max_retries: int = 1
) -> tuple[AnalyzerLLMService, InMemoryLLMUsageSink, MockLLMClient]:
    registry = module_registry or make_module_registry()
    client = MockLLMClient(responder)
    usage_sink = InMemoryLLMUsageSink()
    router = LLMRouter(
        routes={"analyzer": LLMRouteConfig(route="analyzer", model="mock-analyzer-v1", max_retries=max_retries)},
        client=client,
        usage_sink=usage_sink,
    )
    context_builder = AnalyzerContextBuilder(registry)
    service = AnalyzerLLMService(registry, context_builder, router)
    return service, usage_sink, client


def run_oee_module_state_history(task_type: TaskType, **capability_kwargs) -> list[ModuleState]:
    """Phase 5C-1 fixture helper: runs a *real* OEE Module ReAct Subgraph
    (capability-routed, same as Phase 5B-2/5B-2.1) to completion and returns
    every intermediate ModuleState checkpoint, oldest first -- so a Context
    Engineering test can pick a genuine mid-run snapshot (e.g. "screening
    done, EQ001 already investigated, EQ003 not yet") instead of hand-
    constructing an artificial ModuleState that might not match what the
    real Harness actually produces."""
    runtime = make_oee_capability_runtime(MOCK_EQUIPMENT, OEE_THRESHOLD, **capability_kwargs)
    policy = OEEPlanningPolicy()
    graph = build_module_react_subgraph(policy, capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id="OEE", module_type="OEE", reason="test", goal_statement="test goal", confidence=0.9, priority=0.9)
    initial = build_initial_module_state(
        task, make_budget(max_steps=6, max_tool_calls=20, max_depth_per_entity=3), run_id="run-ctx", task_type=task_type
    )
    config = {"configurable": {"thread_id": f"ctx-{task_type.value}-{id(runtime)}"}}
    app.invoke(initial, config=config)

    # `get_state_history` includes a pre-START checkpoint where only
    # Annotated-reducer channels have their default value and required
    # plain fields (module_id, goal, ...) were never written yet -- skip it.
    snapshots = [ModuleState.model_validate(snap.values) for snap in app.get_state_history(config) if "module_id" in snap.values]
    return list(reversed(snapshots))


def make_oee_planner_context_builder(*, audit_sink=None) -> PlannerContextBuilder:
    return PlannerContextBuilder(
        DeterministicEvidenceSelector(), DeterministicCapabilityRetriever(make_oee_skill_registry()), audit_sink=audit_sink
    )


def make_llm_planning_policy(
    responder,
    *,
    baseline_policy=None,
    max_retries: int = 1,
    decision_audit_sink=None,
    context_audit_sink=None,
) -> tuple[LLMPlanningPolicy, InMemoryLLMUsageSink, MockLLMClient]:
    """Phase 5C-2: an OEE-wired LLMPlanningPolicy -- baseline defaults to a
    fresh OEEPlanningPolicy (both the fallback and the deterministic
    regression oracle), context_builder reads the real OEE SkillRegistry,
    router talks to a MockLLMClient driven by `responder`."""
    baseline = baseline_policy or OEEPlanningPolicy()
    context_builder = make_oee_planner_context_builder(audit_sink=context_audit_sink)
    usage_sink = InMemoryLLMUsageSink()
    client = MockLLMClient(responder)
    router = LLMRouter(
        routes={"planner": LLMRouteConfig(route="planner", model="mock-planner-v1", max_retries=max_retries)},
        client=client,
        usage_sink=usage_sink,
    )
    policy = LLMPlanningPolicy(baseline, context_builder, router, make_oee_skill_registry(), decision_audit_sink=decision_audit_sink)
    return policy, usage_sink, client


def make_synthesis_llm_service(
    responder,
    *,
    max_retries: int = 1,
    decision_audit_sink=None,
    context_audit_sink=None,
    reasoning_skill_retriever=None,
) -> tuple[SynthesisLLMService, InMemoryLLMUsageSink, MockLLMClient]:
    """Phase 6B: a Mock-LLM-backed SynthesisLLMService -- same wiring shape
    as make_llm_planning_policy, router talks to a MockLLMClient driven by
    `responder`."""
    context_builder = SynthesisContextBuilder(
        ModuleHandoffBuilder(), reasoning_skill_retriever=reasoning_skill_retriever, audit_sink=context_audit_sink
    )
    usage_sink = InMemoryLLMUsageSink()
    client = MockLLMClient(responder)
    router = LLMRouter(
        routes={"synthesis": LLMRouteConfig(route="synthesis", model="mock-synthesis-v1", max_retries=max_retries)},
        client=client,
        usage_sink=usage_sink,
    )
    service = SynthesisLLMService(context_builder, router, decision_audit_sink=decision_audit_sink)
    return service, usage_sink, client


def make_run_audit_bundle_from_modules(module_states, **overrides) -> RunAuditBundle:
    """Phase 7A default wiring: aggregates `ModuleState.tool_calls` across
    modules as `tool_call_records` (the convenience view -- see
    RunAuditBundle's own docstring for the documented caveat vs. a real
    external ToolCallAuditSink, which nothing in this codebase threads
    through yet). Any field can be overridden by a caller that has more
    precise audit data (e.g. real LLMCallRecords from a MockLLMClient
    usage sink)."""
    base = dict(tool_call_records=[tc for m in module_states for tc in m.tool_calls])
    base.update(overrides)
    return RunAuditBundle(**base)


def make_wb_datasources():
    """Phase WB-2A (+ WB-3A ISSUE): the 5 canonical WB InMemory DataSources,
    built from the frozen Phase WB Data Layer V1 synthetic dataset --
    shared helper so every WB Tool test builds them identically, the same
    way `make_oee_tool_registry` is the one shared OEE fixture builder."""
    from agent.domain.wb.datasource import (
        InMemoryWBBankDataSource,
        InMemoryWBIssueDataSource,
        InMemoryWBPlantOEEDataSource,
        InMemoryWBStageOutputDataSource,
        InMemoryWBWIPDataSource,
    )
    from agent.domain.wb.synthetic import (
        build_wb_bank_records,
        build_wb_issue_records,
        build_wb_plant_oee_records,
        build_wb_stage_output_records,
        build_wb_wip_records,
    )
    from agent.tools.wb.registration import WBDataSources

    bank_records, bank_snapshot_dates = build_wb_bank_records()
    wip_records, wip_snapshot_dates = build_wb_wip_records()
    return WBDataSources(
        oee=InMemoryWBPlantOEEDataSource(build_wb_plant_oee_records()),
        bank=InMemoryWBBankDataSource(bank_records, snapshot_dates=bank_snapshot_dates),
        wip=InMemoryWBWIPDataSource(wip_records, snapshot_dates=wip_snapshot_dates),
        output=InMemoryWBStageOutputDataSource(build_wb_stage_output_records()),
        issue=InMemoryWBIssueDataSource(build_wb_issue_records()),
    )
