﻿"""Phase 7A items 13.A/13.B: efficient vs. wasteful INFORMATION runs.
Wasteful means depth exceeded the TaskType's own budget, flagged
regardless of whether the final answer happened to be correct.
"""
from agent.evaluation.evaluator import RunEvaluator
from agent.state.enums import FindingStatus, ModuleStatus, ObjectiveAction, ObjectiveStatus, TargetRefType, TaskType
from agent.state.models import Finding, ObjectiveRecord, TargetRef

from .conftest import make_agent_state, make_module_state, make_run_audit_bundle_from_modules, run_oee_module_state_history


def _with_task_type(state, task_type: TaskType):
    return state.model_copy(update={"goal": state.goal.model_copy(update={"task_type": task_type})})


def test_efficient_information_run_has_minimal_footprint_and_full_depth_compliance():
    history = run_oee_module_state_history(TaskType.INFORMATION)
    final = history[-1]
    assert final.status == ModuleStatus.COMPLETE
    assert [r.action for r in final.objective_history.values()] == [ObjectiveAction.SUMMARIZE]

    state = make_agent_state().model_copy(update={"module_states": {"OEE": final}})
    bundle = make_run_audit_bundle_from_modules([final])
    evaluation = RunEvaluator().evaluate(state, bundle)

    assert evaluation.efficiency.objective_count == 1
    assert evaluation.decision_quality.planner.unnecessary_deep_dive_count == 0
    assert evaluation.delivery_quality.task_type_depth_compliance == 1.0
    assert not any(i.metric_name == "unnecessary_deep_dive_count" for i in evaluation.issues)


def test_wasteful_information_run_flags_unnecessary_deep_dive_even_with_a_correct_answer():
    module_state = _with_task_type(make_module_state(), TaskType.INFORMATION)
    module_state = module_state.model_copy(
        update={
            "status": ModuleStatus.COMPLETE,
            "findings": [Finding(finding_id="f1", statement="Average OEE today is 0.82.", pattern="none", confidence=0.95, status=FindingStatus.CONFIRMED, is_root_cause=False)],
            "objective_history": {
                "o1": ObjectiveRecord(objective_id="o1", description="current status", action=ObjectiveAction.SUMMARIZE, target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="OEE"), status=ObjectiveStatus.COMPLETED, created_step=1, attempt_count=1),
                # a wasteful, TaskType-inappropriate deep dive -- the
                # answer above is still correct, but the process was not
                "o2": ObjectiveRecord(objective_id="o2", description="unnecessary deep dive", action=ObjectiveAction.DRILL_DOWN, target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="EQ001"), status=ObjectiveStatus.COMPLETED, created_step=2, attempt_count=1),
            },
        }
    )
    state = make_agent_state().model_copy(update={"module_states": {"OEE": module_state}})
    bundle = make_run_audit_bundle_from_modules([module_state])
    evaluation = RunEvaluator().evaluate(state, bundle)

    assert evaluation.decision_quality.planner.unnecessary_deep_dive_count == 1
    assert evaluation.delivery_quality.task_type_depth_compliance == 0.0
    issue = next(i for i in evaluation.issues if i.metric_name == "unnecessary_deep_dive_count")
    assert "mod-oee" in issue.related_module_ids
