"""Phase PROD-1: offline tests for agent_api/runtime_events.py -- sink
composition, run-local sequencing, best-effort failure isolation, and the
"no chain-of-thought/no credentials" bound on RuntimeEvent's own shape."""
import pytest

from agent_api.runtime_events import (
    CompositeRuntimeEventSink,
    InMemoryRuntimeEventSink,
    RuntimeEventPublisher,
    RuntimeEventType,
    StdoutRuntimeEventSink,
    build_optional_postgres_runtime_event_sink,
    build_runtime_event_sink,
    event_to_sse,
)


def test_publisher_assigns_monotonic_per_run_sequence():
    sink = InMemoryRuntimeEventSink()
    publisher = RuntimeEventPublisher(run_id="run-1", sink=sink)
    e1 = publisher.publish(RuntimeEventType.RUN_STARTED)
    e2 = publisher.publish(RuntimeEventType.RUN_COMPLETED)
    assert e1.sequence == 1
    assert e2.sequence == 2
    assert e1.run_id == e2.run_id == "run-1"


def test_two_publishers_do_not_share_sequence_state():
    sink = InMemoryRuntimeEventSink()
    p1 = RuntimeEventPublisher(run_id="run-a", sink=sink)
    p2 = RuntimeEventPublisher(run_id="run-b", sink=sink)
    p1.publish(RuntimeEventType.RUN_STARTED)
    p1.publish(RuntimeEventType.RUN_COMPLETED)
    e = p2.publish(RuntimeEventType.RUN_STARTED)
    assert e.sequence == 1  # not 3 -- confirms no shared/global counter (item 24)


def test_summary_and_error_message_are_truncated():
    sink = InMemoryRuntimeEventSink()
    publisher = RuntimeEventPublisher(run_id="run-1", sink=sink)
    long_text = "x" * 5000
    event = publisher.publish(RuntimeEventType.TOOL_COMPLETED, summary=long_text, error_message=long_text)
    assert len(event.summary) < 5000
    assert event.summary.endswith("...(truncated)")
    assert len(event.error_message) < 5000


def test_in_memory_sink_lists_only_its_own_run():
    sink = InMemoryRuntimeEventSink()
    RuntimeEventPublisher(run_id="run-a", sink=sink).publish(RuntimeEventType.RUN_STARTED)
    RuntimeEventPublisher(run_id="run-b", sink=sink).publish(RuntimeEventType.RUN_STARTED)
    assert len(sink.list_for_run("run-a")) == 1
    assert len(sink.list_for_run("run-b")) == 1
    assert len(sink.list_for_run("run-c")) == 0


def test_stdout_sink_never_raises_and_is_not_queryable():
    sink = StdoutRuntimeEventSink()
    publisher = RuntimeEventPublisher(run_id="run-1", sink=sink)
    publisher.publish(RuntimeEventType.RUN_STARTED)  # must not raise
    assert sink.list_for_run("run-1") == []  # stdout is not a queryable store, by design


def test_composite_sink_fans_out_to_every_wrapped_sink():
    a, b = InMemoryRuntimeEventSink(), InMemoryRuntimeEventSink()
    composite = CompositeRuntimeEventSink([a, b])
    RuntimeEventPublisher(run_id="run-1", sink=composite).publish(RuntimeEventType.RUN_STARTED)
    assert len(a.list_for_run("run-1")) == 1
    assert len(b.list_for_run("run-1")) == 1


def test_composite_sink_isolates_one_failing_sink():
    class _BrokenSink:
        def record(self, event):
            raise RuntimeError("simulated DB outage")

        def list_for_run(self, run_id):
            raise RuntimeError("simulated DB outage")

    good = InMemoryRuntimeEventSink()
    composite = CompositeRuntimeEventSink([_BrokenSink(), good])
    # must not raise even though the first sink always fails (item 44)
    RuntimeEventPublisher(run_id="run-1", sink=composite).publish(RuntimeEventType.RUN_STARTED)
    assert len(good.list_for_run("run-1")) == 1
    assert composite.list_for_run("run-1") == good.list_for_run("run-1")  # falls through the broken sink to the good one


def test_build_optional_postgres_sink_returns_none_when_dsn_missing():
    assert build_optional_postgres_runtime_event_sink(None) is None
    assert build_optional_postgres_runtime_event_sink("") is None


def test_build_optional_postgres_sink_returns_none_on_unreachable_host():
    """Item 17/42/43: never raises, even when the DSN is well-formed but
    the host is unreachable -- disables itself instead."""
    sink = build_optional_postgres_runtime_event_sink("postgresql://user:pass@127.0.0.1:0/nonexistent")
    assert sink is None


def test_build_runtime_event_sink_always_includes_stdout():
    sink = build_runtime_event_sink(None)
    assert isinstance(sink, CompositeRuntimeEventSink)
    RuntimeEventPublisher(run_id="run-1", sink=sink).publish(RuntimeEventType.RUN_STARTED)  # must not raise


def test_event_to_sse_format():
    sink = InMemoryRuntimeEventSink()
    event = RuntimeEventPublisher(run_id="run-1", sink=sink).publish(RuntimeEventType.PLANNER_DECISION, capability_key="wb.output.comparison")
    sse = event_to_sse(event)
    assert sse.startswith("event: planner_decision\n")
    assert "data: " in sse
    assert sse.endswith("\n\n")
    assert '"wb.output.comparison"' in sse


def test_runtime_event_has_no_credential_shaped_field():
    """Structural guard (item 13/77): RuntimeEvent's own schema has no
    field named/shaped like a secret -- the model cannot even represent one."""
    from agent_api.runtime_events import RuntimeEvent

    forbidden_substrings = ("password", "secret", "api_key", "token", "credential", "prompt", "system_prompt")
    for field_name in RuntimeEvent.model_fields:
        lowered = field_name.lower()
        assert not any(bad in lowered for bad in forbidden_substrings), f"RuntimeEvent has a suspicious field: {field_name}"
