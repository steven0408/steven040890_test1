"""Phase 8A items 23.D/23.E/23.F: Human Feedback append-only persistence,
Learning Candidate aggregate merge (evidence links still append-only), and
PersistenceUnitOfWork rollback.
"""
from datetime import datetime, timezone

from agent.learning.confidence import TieredCandidateConfidenceScorer
from agent.learning.generators.capability_gap import generate_capability_gap_candidates
from agent.learning.merger import CandidateMerger
from agent.learning.sink import InMemoryLearningCandidateSink
from agent.learning.snapshot import LearningRunSnapshot, SnapshotCapabilityGap, SnapshotEvaluationSummary, SnapshotPlannerSummary
from agent.persistence.audit_repository import build_default_audit_repository
from agent.persistence.human_feedback import InMemoryHumanFeedbackSink
from agent.persistence.learning_repository import LearningCandidateRepository
from agent.persistence.run_repository import InMemoryRunRepository
from agent.persistence.run_writer import RunPersistenceWriter
from agent.persistence.unit_of_work import PersistenceUnitOfWork
from agent.state.enums import FeedbackTargetType, TaskType
from agent.state.models import HumanFeedback

from .conftest import make_agent_state


def _writer():
    run_repo = InMemoryRunRepository()
    audit_repo = build_default_audit_repository()
    feedback_sink = InMemoryHumanFeedbackSink()
    learning_repo = LearningCandidateRepository(InMemoryLearningCandidateSink())
    writer = RunPersistenceWriter(run_repo, audit_repo, feedback_sink, learning_repo)
    return writer, run_repo, feedback_sink, learning_repo


def _fb(feedback_id, offset_seconds=0):
    return HumanFeedback(
        feedback_id=feedback_id, run_id="run-1", target_type=FeedbackTargetType.RUN,
        created_at=datetime.now(timezone.utc), comment=f"feedback #{feedback_id}",
    )


# ============================================================================
# D. Human Feedback append-only persistence
# ============================================================================


def test_two_feedback_submissions_persist_as_two_records():
    writer, _, feedback_sink, _ = _writer()
    state = make_agent_state(run_id="run-1")

    writer.persist_run(state, human_feedback=[_fb("fb-1")])
    writer.persist_run(state, human_feedback=[_fb("fb-2")])

    stored = feedback_sink.list_for_run("run-1")
    assert len(stored) == 2
    assert {f.feedback_id for f in stored} == {"fb-1", "fb-2"}


# ============================================================================
# E. Learning Candidate merge -- aggregate updates, evidence links append-only
# ============================================================================


def _snapshot(run_id):
    gap = SnapshotCapabilityGap(module_type="OEE", requested_action="maintenance_history_analysis", description="unavailable")
    return LearningRunSnapshot(
        run_id=run_id, factory_id="factory-a", module_types=["OEE"], task_type=TaskType.RCA,
        confirmed_findings=[], root_causes=[],
        evaluation_summary=SnapshotEvaluationSummary(analytical_quality_score=0.9, decision_quality_score=0.9, delivery_quality_score=0.9, efficiency_score=0.9, overall_score=None),
        planner_summary=SnapshotPlannerSummary(total_decisions=1, fallback_decisions=0, objective_count=2, unnecessary_deep_dive_count=0),
        capability_gaps=[gap],
    )


def test_candidate_aggregate_updates_while_evidence_links_stay_append_only():
    scorer = TieredCandidateConfidenceScorer()
    sink = InMemoryLearningCandidateSink()
    repo = LearningCandidateRepository(sink)
    merger = CandidateMerger(scorer)

    batch1, links1 = generate_capability_gap_candidates([_snapshot("run-a")], scorer)
    merger.merge_into_sink(repo, batch1, links1)
    assert len(repo.list()) == 1
    candidate_id = repo.list()[0].candidate_id
    assert len(repo.list_evidence_links(candidate_id)) == 1

    batch2, links2 = generate_capability_gap_candidates([_snapshot("run-b")], scorer)
    merger.merge_into_sink(repo, batch2, links2)

    assert len(repo.list()) == 1  # aggregate updated, not duplicated
    updated = repo.get(candidate_id)
    assert set(updated.source_run_ids) == {"run-a", "run-b"}
    assert len(repo.list_evidence_links(candidate_id)) == 2  # both evidence links preserved, appended


def test_get_candidate_with_evidence_composes_both():
    scorer = TieredCandidateConfidenceScorer()
    sink = InMemoryLearningCandidateSink()
    repo = LearningCandidateRepository(sink)
    candidates, links = generate_capability_gap_candidates([_snapshot("run-a")], scorer)
    CandidateMerger(scorer).merge_into_sink(repo, candidates, links)

    candidate_id = repo.list()[0].candidate_id
    bundle = repo.get_candidate_with_evidence(candidate_id)
    assert bundle.candidate.candidate_id == candidate_id
    assert len(bundle.evidence_links) == 1
    assert repo.get_candidate_with_evidence("does-not-exist") is None


# ============================================================================
# F. Rollback
# ============================================================================


def test_uow_rollback_on_exception_applies_nothing():
    run_repo = InMemoryRunRepository()
    uow = PersistenceUnitOfWork()

    class _Boom(Exception):
        pass

    try:
        with uow:
            uow.stage(lambda: run_repo.save_run(_make_run_record()))
            raise _Boom("mid-transaction failure")
    except _Boom:
        pass

    assert run_repo.list_runs() == []  # nothing was ever applied


def test_uow_without_explicit_commit_rolls_back():
    run_repo = InMemoryRunRepository()
    uow = PersistenceUnitOfWork()

    with uow:
        uow.stage(lambda: run_repo.save_run(_make_run_record()))
        # deliberately never calling uow.commit()

    assert run_repo.list_runs() == []


def test_uow_commit_applies_staged_writes():
    run_repo = InMemoryRunRepository()
    uow = PersistenceUnitOfWork()

    with uow:
        uow.stage(lambda: run_repo.save_run(_make_run_record()))
        uow.commit()

    assert len(run_repo.list_runs()) == 1


def _make_run_record():
    from agent.persistence.records import RunRecord
    from agent.state.enums import RunTerminationStatus

    return RunRecord(
        run_id="run-rollback", user_request="x", factory_id="factory-a", run_status=RunTerminationStatus.RUNNING,
        created_at=datetime.now(timezone.utc),
    )
