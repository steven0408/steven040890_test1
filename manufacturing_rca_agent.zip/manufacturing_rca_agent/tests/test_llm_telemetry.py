"""Phase PROD-1.2 (item B/H): offline verification that LLMCallRecord now
carries the bounded telemetry a formal-environment calibration run needs
-- estimator-vs-actual comparison fields, schema cost, finish_reason,
content/reasoning presence -- without ever persisting raw prompt/schema/
reasoning_content text. Fully offline (fake OpenAI client + MockLLMClient),
no real provider needed.
"""
import json

import httpx
import pytest

openai = pytest.importorskip("openai")

from agent.llm.config import LLMRouteConfig
from agent.llm.models import LLMCallStatus, LLMMessage, LLMOutputTruncatedError, LLMRole
from agent.llm.providers.openai_adapter import OpenAICompatibleAdapter
from agent.llm.router import LLMRouter
from agent.llm.token_budget import LLMContextProfile, RouteTokenBudget
from agent.llm.usage import InMemoryLLMUsageSink
from agent.state.base import RCABaseModel


class _Echo(RCABaseModel):
    value: str


class _FakeFunction:
    def __init__(self, name, arguments):
        self.name = name
        self.arguments = arguments


class _FakeToolCall:
    def __init__(self, name, arguments_dict):
        self.function = _FakeFunction(name, json.dumps(arguments_dict))


class _FakeMessage:
    def __init__(self, content=None, tool_calls=None, reasoning_content=None):
        self.content = content
        self.tool_calls = tool_calls
        self.reasoning_content = reasoning_content


class _FakeChoice:
    def __init__(self, message, finish_reason=None):
        self.message = message
        self.finish_reason = finish_reason


class _FakeUsage:
    def __init__(self, prompt_tokens, completion_tokens):
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens


class _FakeChatCompletion:
    def __init__(self, choices, usage=None):
        self.choices = choices
        self.usage = usage


class _FakeCompletionsEndpoint:
    def __init__(self, responder):
        self._responder = responder
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return self._responder(kwargs)


class _FakeChatEndpoint:
    def __init__(self, responder):
        self.completions = _FakeCompletionsEndpoint(responder)


class _FakeOpenAIClient:
    def __init__(self, responder):
        self.chat = _FakeChatEndpoint(responder)


_REQUEST_MESSAGES = [LLMMessage(role=LLMRole.SYSTEM, content="be helpful"), LLMMessage(role=LLMRole.USER, content="hello")]


def _router(fake_client, context_profile=None):
    usage_sink = InMemoryLLMUsageSink()
    adapter = OpenAICompatibleAdapter(client=fake_client)
    router = LLMRouter(
        routes={"planner": LLMRouteConfig(route="planner", model="gpt-test", max_retries=1)},
        client=adapter, usage_sink=usage_sink, context_profile=context_profile,
    )
    return router, usage_sink


def test_successful_call_records_finish_reason_and_content_presence():
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion(
        [_FakeChoice(_FakeMessage(tool_calls=[_FakeToolCall("emit_decision", {"value": "ok"})]), finish_reason="tool_calls")],
        _FakeUsage(120, 30),
    ))
    router, usage_sink = _router(fake)
    outcome = router.call("planner", _REQUEST_MESSAGES, _Echo, run_id="r1", module_id=None, node="test")

    record = usage_sink.list_for_run("r1")[-1]
    assert record.status == LLMCallStatus.SUCCESS
    assert record.finish_reason == "tool_calls"
    assert record.content_present is True
    assert record.reasoning_present is False
    assert record.input_tokens == 120
    assert record.output_tokens == 30


def test_reasoning_content_presence_is_recorded_without_its_text():
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion(
        [_FakeChoice(_FakeMessage(tool_calls=[_FakeToolCall("emit_decision", {"value": "ok"})], reasoning_content="some internal chain of thought"), finish_reason="tool_calls")],
        _FakeUsage(120, 30),
    ))
    router, usage_sink = _router(fake)
    router.call("planner", _REQUEST_MESSAGES, _Echo, run_id="r2", module_id=None, node="test")

    record = usage_sink.list_for_run("r2")[-1]
    assert record.reasoning_present is True
    # never persisted anywhere on the record -- structurally impossible,
    # LLMCallRecord (extra="forbid") has no field that could hold it.
    assert "reasoning_content" not in type(record).model_fields
    assert "chain of thought" not in record.model_dump_json()


def test_estimated_prompt_and_schema_tokens_always_recorded_even_without_profile():
    """Item 6/88: estimator-vs-actual comparison must be possible even
    under the default unbounded profile (no context_profile configured)."""
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion(
        [_FakeChoice(_FakeMessage(tool_calls=[_FakeToolCall("emit_decision", {"value": "ok"})]), finish_reason="tool_calls")],
        _FakeUsage(120, 30),
    ))
    router, usage_sink = _router(fake, context_profile=None)
    router.call("planner", _REQUEST_MESSAGES, _Echo, run_id="r3", module_id=None, node="test")

    record = usage_sink.list_for_run("r3")[-1]
    assert record.estimated_prompt_tokens is not None and record.estimated_prompt_tokens > 0
    assert record.schema_tokens is not None and record.schema_tokens > 0
    assert record.context_window_tokens is None  # no profile configured -- honestly absent, not fabricated
    assert record.reserved_output_tokens is None


def test_context_window_and_reserved_output_recorded_when_profile_configured():
    profile = LLMContextProfile(context_window_tokens=2048, route_budgets={"planner": RouteTokenBudget(max_output_tokens=450, minimum_output_tokens=200, safety_margin_tokens=64)})
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion(
        [_FakeChoice(_FakeMessage(tool_calls=[_FakeToolCall("emit_decision", {"value": "ok"})]), finish_reason="tool_calls")],
        _FakeUsage(120, 30),
    ))
    router, usage_sink = _router(fake, context_profile=profile)
    router.call("planner", _REQUEST_MESSAGES, _Echo, run_id="r4", module_id=None, node="test")

    record = usage_sink.list_for_run("r4")[-1]
    assert record.context_window_tokens == 2048
    assert record.reserved_output_tokens == 450


def test_context_budget_exceeded_record_carries_estimator_telemetry():
    profile = LLMContextProfile(context_window_tokens=2048, route_budgets={"planner": RouteTokenBudget(max_output_tokens=2048, minimum_output_tokens=200, safety_margin_tokens=64)})
    fake = _FakeOpenAIClient(lambda kwargs: (_ for _ in ()).throw(AssertionError("must never be called")))
    router, usage_sink = _router(fake, context_profile=profile)
    with pytest.raises(Exception):
        router.call("planner", _REQUEST_MESSAGES, _Echo, run_id="r5", module_id=None, node="test")

    record = usage_sink.list_for_run("r5")[-1]
    assert record.status == LLMCallStatus.CONTEXT_BUDGET_EXCEEDED
    assert record.estimated_prompt_tokens is not None
    assert record.schema_tokens is not None
    assert record.context_window_tokens == 2048
    assert record.reserved_output_tokens == 2048


def test_output_truncated_record_carries_finish_reason_length():
    fake = _FakeOpenAIClient(lambda kwargs: _FakeChatCompletion(
        [_FakeChoice(_FakeMessage(tool_calls=None), finish_reason="length")], _FakeUsage(1800, 200),
    ))
    router, usage_sink = _router(fake)
    with pytest.raises(Exception):
        router.call("planner", _REQUEST_MESSAGES, _Echo, run_id="r6", module_id=None, node="test")

    records = usage_sink.list_for_run("r6")
    assert any(r.status == LLMCallStatus.OUTPUT_TRUNCATED and r.finish_reason == "length" for r in records)


def test_physical_call_count_matches_max_retries_no_hidden_multiplication():
    """Item 11/39: exactly max_retries+1 physical calls for a persistently
    failing route -- the openai SDK's own internal retry is disabled
    (max_retries=0 on the SDK client, Phase PROD-1.1), so LLMRouter's own
    count is the true physical count."""
    call_count = 0

    def _always_fail(kwargs):
        nonlocal call_count
        call_count += 1
        raise openai.APITimeoutError(request=httpx.Request("POST", "https://internal/v1/chat/completions"))

    fake = _FakeOpenAIClient(_always_fail)
    router, usage_sink = _router(fake)
    with pytest.raises(Exception):
        router.call("planner", _REQUEST_MESSAGES, _Echo, run_id="r7", module_id=None, node="test")

    assert call_count == 2  # max_retries=1 -> 2 attempts, never more
    assert len(usage_sink.list_for_run("r7")) == 2
