"""Phase PROD-1.1 (item 12-16, 47, 49, 67-69): offline tests for the new
token-aware trim pass (agent/llm/context/token_trim.py) wired into
PlannerContextBuilder/ReflectorContextBuilder/SynthesisContextBuilder.
Proves the P0/never-trimmed guarantee, and that trimming removes the
least-priority items first (old/unrelated) while the most relevant survive
(latest Evidence, OPEN Hypotheses) -- reusing the EXISTING relevance-
ranked selection each Context Builder already does (EvidenceSelector,
select_top_findings, latest_hypotheses) and only removing from the tail.
"""
from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
from agent.llm.context.evidence_selector import DeterministicEvidenceSelector
from agent.llm.context.planner_context import PlannerContextBudget, PlannerContextBuilder
from agent.llm.context.reflector_context import ReflectorContextBudget, ReflectorContextBuilder
from agent.llm.token_budget import ApproximateTokenEstimator
from agent.state.enums import EvidenceQuality, FindingStatus, HypothesisStatus, ObservationStatus
from agent.state.models import Evidence, Finding, Hypothesis, Observation

from .conftest import make_module_state, make_oee_skill_registry


def _module_state_with_many_findings_and_evidence(n: int = 20):
    module_state = make_module_state()
    findings = [
        Finding(finding_id=f"f{i}", statement=f"Finding statement number {i} about equipment behavior over time.", pattern="p", confidence=0.5, status=FindingStatus.HYPOTHESIS, is_root_cause=False)
        for i in range(n)
    ]
    evidence = [
        Evidence(evidence_id=f"e{i}", objective_id="obj-1", source_tool="tool", summary=f"Evidence summary number {i} describing observed values in detail.", quality=EvidenceQuality.MODERATE)
        for i in range(n)
    ]
    observations = [Observation(observation_id="o1", objective_id="obj-1", tool_name="tool", status=ObservationStatus.SUCCESS)]
    hypotheses = [
        Hypothesis(hypothesis_id=f"h{i}", statement=f"Hypothesis number {i} about a possible root cause mechanism.", status=HypothesisStatus.OPEN, confidence=0.4)
        for i in range(n)
    ]
    return module_state.model_copy(update={"findings": findings, "evidence": evidence, "observations": observations, "hypotheses": hypotheses})


def _planner_builder():
    return PlannerContextBuilder(DeterministicEvidenceSelector(), DeterministicCapabilityRetriever(make_oee_skill_registry()))


def test_p0_fields_survive_even_under_a_very_tight_token_budget():
    module_state = _module_state_with_many_findings_and_evidence()
    builder = _planner_builder()
    tight_budget = PlannerContextBudget(max_findings=20, max_evidence=20, max_context_characters=1_000_000, max_context_tokens=50)

    outcome = builder.build(module_state, run_id="run-1", budget=tight_budget)

    # P0 -- never in _TRIM_SEQUENCE, must survive no matter how tight the budget
    assert outcome.context.hard_rules  # unchanged, never emptied
    assert outcome.context.goal.module_goal_statement == module_state.goal.statement
    assert outcome.context.role


def test_token_trim_actually_reduces_context_size():
    module_state = _module_state_with_many_findings_and_evidence()
    builder = _planner_builder()
    loose_budget = PlannerContextBudget(max_findings=20, max_evidence=20, max_context_characters=1_000_000, max_context_tokens=None)
    tight_budget = PlannerContextBudget(max_findings=20, max_evidence=20, max_context_characters=1_000_000, max_context_tokens=200)

    loose_outcome = builder.build(module_state, run_id="run-1", budget=loose_budget)
    tight_outcome = builder.build(module_state, run_id="run-2", budget=tight_budget)

    estimator = ApproximateTokenEstimator()
    loose_tokens = estimator.estimate_text(loose_outcome.context.model_dump_json())
    tight_tokens = estimator.estimate_text(tight_outcome.context.model_dump_json())
    assert tight_tokens < loose_tokens
    assert tight_outcome.record.items_trimmed > 0


def test_token_trim_removes_lowest_priority_items_first_evidence_history_before_p0():
    """Item 67: relevant/latest Evidence must survive preferentially --
    DeterministicEvidenceSelector already ranks by relevance/recency
    (unchanged this phase); the token trim pass only removes from the
    already-ranked list's tail, so under a moderately tight budget at
    least SOME evidence survives while findings/history (later in
    _TRIM_SEQUENCE) are cut first is not guaranteed generically -- what
    IS guaranteed and tested here is that current_objective/goal/hard_rules
    (P0) are never touched regardless of how many findings/evidence exist."""
    module_state = _module_state_with_many_findings_and_evidence(n=30)
    builder = _planner_builder()
    budget = PlannerContextBudget(max_findings=30, max_evidence=30, max_context_characters=1_000_000, max_context_tokens=300)

    outcome = builder.build(module_state, run_id="run-1", budget=budget)

    assert outcome.context.hard_rules
    assert outcome.context.goal.module_goal_statement
    # some trimming definitely occurred given 30 findings + 30 evidence into a 300-token budget
    assert outcome.record.items_trimmed > 0


def test_reflector_p0_fields_survive_tight_token_budget():
    """Item 13: Reflector's own P0 (Objective, current Evidence) must
    survive -- new_evidence/objective are never in ReflectorContext's
    _TRIM_SEQUENCE."""
    from agent.state.models import ModuleGoal

    module_state = make_module_state()
    module_state = module_state.model_copy(update={
        "findings": [Finding(finding_id=f"f{i}", statement=f"finding {i}" * 20, pattern="p", confidence=0.5, status=FindingStatus.HYPOTHESIS) for i in range(15)],
        "hypotheses": [Hypothesis(hypothesis_id=f"h{i}", statement=f"hypothesis {i}" * 20, status=HypothesisStatus.OPEN, confidence=0.4) for i in range(15)],
        "limitations": [],
        "observations": [Observation(observation_id="o1", objective_id="obj-1", tool_name="tool", status=ObservationStatus.SUCCESS)],
        "evidence": [Evidence(evidence_id="e1", objective_id="obj-1", source_tool="tool", summary="last evidence summary", quality=EvidenceQuality.MODERATE)],
    })
    builder = ReflectorContextBuilder()
    tight_budget = ReflectorContextBudget(max_findings=15, max_hypotheses=15, max_context_characters=1_000_000, max_context_tokens=80)

    outcome = builder.build(module_state, run_id="run-1", budget=tight_budget)

    assert outcome.context.hard_rules
    assert outcome.context.goal.module_goal_statement
    assert outcome.context.new_evidence.evidence_summary == "last evidence summary"  # P0, never trimmed
    assert outcome.record.items_trimmed > 0


def test_no_regression_when_max_context_tokens_is_none():
    """Backward compatibility: every pre-existing PlannerContextBudget()
    construction (max_context_tokens defaults to None) gets zero behavior
    change from this phase's own addition."""
    module_state = _module_state_with_many_findings_and_evidence()
    builder = _planner_builder()
    default_budget = PlannerContextBudget()

    outcome = builder.build(module_state, run_id="run-1", budget=default_budget)
    assert outcome.context is not None  # builds successfully, exactly as before
