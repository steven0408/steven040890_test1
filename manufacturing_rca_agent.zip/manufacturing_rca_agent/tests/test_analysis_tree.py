import pytest

from agent.analysis.analysis_tree import AnalysisTree, AnalysisTreeNode
from agent.state.enums import TreeNodeStatus, TreeNodeType


def build_oee_drill_down() -> AnalysisTree:
    tree = AnalysisTree(root_id="oee")
    tree.add_node(AnalysisTreeNode(node_id="oee", label="OEE", node_type=TreeNodeType.MODULE))
    tree.add_node(
        AnalysisTreeNode(node_id="equipment", parent_id="oee", label="Equipment", node_type=TreeNodeType.DIMENSION)
    )
    tree.add_node(
        AnalysisTreeNode(
            node_id="eq007", parent_id="equipment", label="EQ007", node_type=TreeNodeType.ENTITY, entity_refs=["EQ007"]
        )
    )
    tree.add_node(
        AnalysisTreeNode(node_id="availability", parent_id="eq007", label="Availability", node_type=TreeNodeType.DIMENSION)
    )
    tree.add_node(
        AnalysisTreeNode(node_id="downtime", parent_id="availability", label="Downtime", node_type=TreeNodeType.DIMENSION)
    )
    tree.add_node(
        AnalysisTreeNode(node_id="failure", parent_id="downtime", label="Equipment Failure", node_type=TreeNodeType.FINDING)
    )
    tree.add_node(
        AnalysisTreeNode(node_id="motor", parent_id="failure", label="Motor Failure", node_type=TreeNodeType.FINDING)
    )
    return tree


def test_drill_down_path_and_parent_child_links():
    tree = build_oee_drill_down()

    assert [n.node_id for n in tree.children_of("oee")] == ["equipment"]
    assert [n.node_id for n in tree.children_of("eq007")] == ["availability"]
    assert tree.get("motor").parent_id == "failure"


def test_set_status_transitions_node():
    tree = build_oee_drill_down()
    tree.set_status("motor", TreeNodeStatus.COMPLETED)
    assert tree.get("motor").status == TreeNodeStatus.COMPLETED


def test_add_node_rejects_duplicate_id():
    tree = build_oee_drill_down()
    with pytest.raises(ValueError):
        tree.add_node(AnalysisTreeNode(node_id="motor", parent_id="failure", label="dup", node_type=TreeNodeType.FINDING))


def test_add_node_rejects_missing_parent():
    tree = AnalysisTree(root_id="oee")
    tree.add_node(AnalysisTreeNode(node_id="oee", label="OEE", node_type=TreeNodeType.MODULE))
    with pytest.raises(ValueError):
        tree.add_node(AnalysisTreeNode(node_id="orphan", parent_id="missing", label="x", node_type=TreeNodeType.DIMENSION))


def test_merge_nodes_groups_common_pattern_as_children():
    tree = AnalysisTree(root_id="oee")
    tree.add_node(AnalysisTreeNode(node_id="oee", label="OEE", node_type=TreeNodeType.MODULE))
    tree.add_node(
        AnalysisTreeNode(node_id="equipment", parent_id="oee", label="Equipment", node_type=TreeNodeType.DIMENSION)
    )
    tree.add_node(
        AnalysisTreeNode(
            node_id="eq001", parent_id="equipment", label="EQ001", node_type=TreeNodeType.ENTITY, entity_refs=["EQ001"]
        )
    )
    tree.add_node(
        AnalysisTreeNode(
            node_id="eq003", parent_id="equipment", label="EQ003", node_type=TreeNodeType.ENTITY, entity_refs=["EQ003"]
        )
    )

    group = tree.merge_nodes(["eq001", "eq003"], into_label="Equipment Failure", new_node_id="grp-failure")

    assert group.node_id == "grp-failure"
    assert group.parent_id == "equipment"
    assert set(group.children_ids) == {"eq001", "eq003"}
    assert set(group.entity_refs) == {"EQ001", "EQ003"}
    assert tree.get("equipment").children_ids == ["grp-failure"]
    assert tree.get("eq001").parent_id == "grp-failure"


def test_merge_nodes_rejects_different_parents():
    tree = build_oee_drill_down()
    with pytest.raises(ValueError):
        tree.merge_nodes(["eq007", "downtime"], into_label="x", new_node_id="bad")
