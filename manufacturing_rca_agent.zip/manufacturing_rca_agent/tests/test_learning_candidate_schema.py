"""Phase 7C: LearningCandidate/LearningEvidenceLink schema + the
CandidateConfidenceScorer's explainability properties.
"""
from datetime import datetime, timezone

from agent.learning.confidence import TieredCandidateConfidenceScorer
from agent.learning.signals import LearningEvidenceLink
from agent.state.enums import LearningCandidateStatus, LearningCandidateType, LearningDestination, LearningSignalType
from agent.state.models import LearningCandidate


def _now():
    return datetime.now(timezone.utc)


def test_learning_candidate_field_set():
    assert set(LearningCandidate.model_fields.keys()) == {
        "candidate_id", "candidate_type", "title", "statement", "status", "confidence", "source_run_ids",
        "source_module_ids", "supporting_finding_ids", "supporting_root_cause_ids", "evaluation_issue_ids",
        "feedback_issue_ids", "planner_decision_record_ids", "supporting_signal_count", "contradicting_signal_count",
        "created_at", "updated_at", "scope", "proposed_destination", "candidate_key", "rationale_summary", "schema_version",
    }


def test_default_status_is_candidate():
    candidate = LearningCandidate(
        candidate_id="c1", candidate_type=LearningCandidateType.KNOWLEDGE_PATTERN, title="t", statement="s",
        confidence=0.5, created_at=_now(), updated_at=_now(), scope="OEE", proposed_destination=LearningDestination.KNOWLEDGE_BASE,
        candidate_key="k1", rationale_summary="r",
    )
    assert candidate.status == LearningCandidateStatus.CANDIDATE


# ============================================================================
# CandidateConfidenceScorer -- explainability properties
# ============================================================================


def _link(signal_type, run_id, supports=True, strength=0.8):
    return LearningEvidenceLink(link_id=f"l-{run_id}-{signal_type.value}-{supports}", candidate_id="c1", signal_type=signal_type, source_run_id=run_id, supports=supports, strength=strength)


def test_no_evidence_scores_zero():
    assert TieredCandidateConfidenceScorer().score([]) == 0.0


def test_more_independent_supporting_runs_increases_confidence():
    scorer = TieredCandidateConfidenceScorer()
    one_run = scorer.score([_link(LearningSignalType.REPEATED_PATTERN, "run-a")])
    three_runs = scorer.score([_link(LearningSignalType.REPEATED_PATTERN, r) for r in ["run-a", "run-b", "run-c"]])
    assert three_runs > one_run


def test_contradicting_evidence_decreases_confidence():
    scorer = TieredCandidateConfidenceScorer()
    links = [_link(LearningSignalType.REPEATED_PATTERN, r) for r in ["run-a", "run-b", "run-c"]]
    baseline = scorer.score(links)
    with_contradiction = scorer.score(links + [_link(LearningSignalType.CONTRADICTING_FINDING, "run-d", supports=False)])
    assert with_contradiction < baseline


def test_strong_signal_outweighs_weak_signal():
    scorer = TieredCandidateConfidenceScorer()
    strong = scorer.score([_link(LearningSignalType.CONFIRMED_ROOT_CAUSE, r) for r in ["run-a", "run-b", "run-c"]])
    weak = scorer.score([_link(LearningSignalType.HUMAN_PREFERENCE, r) for r in ["run-a", "run-b", "run-c"]])
    assert strong > weak


def test_purely_contradicting_evidence_never_scores_above_zero():
    scorer = TieredCandidateConfidenceScorer()
    links = [_link(LearningSignalType.CONTRADICTING_FINDING, "run-a", supports=False)]
    assert scorer.score(links) == 0.0


def test_score_always_in_unit_interval():
    scorer = TieredCandidateConfidenceScorer()
    links = [_link(LearningSignalType.CONFIRMED_ROOT_CAUSE, r) for r in ["a", "b", "c", "d", "e"]]
    score = scorer.score(links)
    assert 0.0 <= score <= 1.0
