"""SkillRunner (Phase 5B-2) -- executes one deterministic Skill's `steps`
sequence, chaining each step's structured output into the next step's input,
with every physical Tool call going through `ToolExecutionManager.execute()`
(never `tool.run()` directly -- see agent/tools/execution_manager.py's
terminology freeze: SkillRunner only ever performs Tool Manager Invocations).

Phase 5B-2 scope: deterministic Skills only (`skill.steps` must be
non-empty); no LLM-driven step selection, no nested ReAct loop inside a
Skill. A step failure stops the whole Skill immediately (no partial-retry-
skip-step contract yet) and is reported back as `SkillExecutionResult.ERROR`
-- Module Executor/Reflector/Planner decide what happens next, exactly as
they already do for a bare Tool ERROR.
"""
from datetime import datetime, timezone
from typing import Callable

from pydantic import ValidationError

from agent.skills.models import SkillDefinition, SkillExecutionResult, SkillExecutionStatus
from agent.state.enums import ErrorType, ObservationStatus
from agent.state.models import ErrorRecord, ModuleState, Objective, ToolCallRecord
from agent.state.payload import PayloadRegistry
from agent.state.scope import get_scope_filter
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.models import ToolExecutionIdentity
from agent.tools.registry import ToolRegistry

_SCOPE_FILTER_PREFIX = "objective.scope.filter."
# Phase WB-3F.2: the OPTIONAL counterpart to `_SCOPE_FILTER_PREFIX` --
# closes the exact blocker WB-3F.1 reported (STOP-gated, not worked
# around, in that phase) rather than a new parallel mechanism. Required-
# dimension semantics (`_SCOPE_FILTER_PREFIX`, unchanged below) still
# raise when absent; this prefix resolves to `_MISSING` instead, letting
# `SkillRunner.run()` omit the key from `overlay` entirely so the Tool's
# own Pydantic default applies -- never `None` (a field whose default is
# a non-None value, e.g. `group_by: list[str] = []`, would fail Pydantic
# validation if explicitly overwritten with `None`).
_SCOPE_FILTER_OPTIONAL_PREFIX = "objective.scope.filter_optional."


class SkillParameterResolutionError(ValueError):
    pass


class _Missing:
    """Internal sentinel only -- constructed once below as `_MISSING`,
    never a public type. Must never leak past `SkillRunner.run()`'s own
    `overlay` construction: not into a Tool's Pydantic input (validated
    immediately after), not into Evidence/Observation, not into
    persistence, not into LLM context, not into JSON serialization (it
    isn't JSON-serializable at all, which is itself a deliberate leak
    detector -- if this sentinel ever escaped this module, downstream
    `model_dump_json()`/DB writes would fail loudly, not silently)."""

    def __repr__(self) -> str:
        return "<MISSING optional parameter>"


_MISSING = _Missing()


class SkillRunOutcome:
    """Not persisted -- pairs the one aggregate SkillExecutionResult Module
    Executor turns into an Observation/Evidence with the full per-step
    ToolCallRecord list it appends to ModuleState.tool_calls (a convenience
    projection -- ToolCallAuditSink stays the physical-execution source of
    truth, per the Phase 5B-1.2 terminology freeze)."""

    def __init__(self, result: SkillExecutionResult, tool_call_records: list[ToolCallRecord]):
        self.result = result
        self.tool_call_records = tool_call_records


def _resolve_param(source: str, prev_output, objective: Objective):
    """Deterministic parameter-source resolution ONLY -- no Python
    expression evaluator, no `eval`/`exec`, no arbitrary attribute-name
    input (`source` always comes from a Skill's own frozen markdown
    frontmatter, never from an Objective/LLM at runtime). Four source
    shapes (Phase WB-3F.2 adds the fourth):

        prev.<field>                        -- one flat field on the
                                                previous step's typed output
        objective.scope.filter.<dim>        -- REQUIRED: `ScopeFilter.value`
                                                for the named dimension, via
                                                the same `get_scope_filter()`
                                                helper `agent/state/scope.py`
                                                itself exposes -- never a
                                                `.filters` list index/
                                                iteration written here.
                                                Raises if the dimension is
                                                absent -- this semantic is
                                                UNCHANGED, still correct for
                                                `plant`/`production_date`
                                                and any other dimension a
                                                Skill's own
                                                `required_scope_dimensions`
                                                guarantees is present (the
                                                Planner-side semantic
                                                validator enforces that
                                                guarantee before a Tool ever
                                                runs).
        objective.scope.filter_optional.<dim> -- OPTIONAL (Phase WB-3F.2):
                                                same lookup, but resolves to
                                                the internal `_MISSING`
                                                sentinel instead of raising
                                                when the dimension is
                                                absent -- see `_MISSING`'s
                                                own docstring and
                                                `SkillRunner.run()`'s
                                                overlay construction for how
                                                this becomes "omit the key,
                                                let the Tool's own default
                                                apply" rather than "pass
                                                None".
        objective.<dotted.path>             -- plain attribute traversal
                                                (unchanged since Phase
                                                5C-2.1; already how
                                                `objective.target_ref.ref_id`
                                                resolves) -- also how
                                                `objective.scope.time.date`
                                                resolves, with a friendly
                                                error instead of a raw
                                                AttributeError when `scope`/
                                                `time` is absent.
    """
    if source.startswith("prev."):
        if prev_output is None:
            raise SkillParameterResolutionError(f"parameter source '{source}' has no previous step output to read")
        field = source[len("prev.") :]
        if not hasattr(prev_output, field):
            raise SkillParameterResolutionError(f"previous step output has no field '{field}' (source '{source}')")
        return getattr(prev_output, field)
    if source.startswith(_SCOPE_FILTER_OPTIONAL_PREFIX):
        dimension = source[len(_SCOPE_FILTER_OPTIONAL_PREFIX) :]
        scope_filter = get_scope_filter(objective.scope, dimension)
        return _MISSING if scope_filter is None else scope_filter.value
    if source.startswith(_SCOPE_FILTER_PREFIX):
        dimension = source[len(_SCOPE_FILTER_PREFIX) :]
        scope_filter = get_scope_filter(objective.scope, dimension)
        if scope_filter is None:
            raise SkillParameterResolutionError(f"parameter source '{source}' has no scope filter for dimension '{dimension}'")
        return scope_filter.value
    if source.startswith("objective."):
        value = objective
        try:
            for part in source[len("objective.") :].split("."):
                value = getattr(value, part)
        except AttributeError as exc:
            raise SkillParameterResolutionError(f"parameter source '{source}' could not be resolved: {exc}") from exc
        return value
    raise SkillParameterResolutionError(f"unsupported parameter source '{source}'")


class SkillRunner:
    def __init__(self, tool_registry: ToolRegistry, execution_manager: ToolExecutionManager):
        self._tools = tool_registry
        self._execution_manager = execution_manager

    def run(
        self,
        skill: SkillDefinition,
        objective: Objective,
        module_state: ModuleState,
        *,
        now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ) -> SkillRunOutcome:
        if not skill.steps:
            raise ValueError(f"skill '{skill.skill_id}' has no executable steps -- Phase 5B-2 only runs deterministic Skills")

        started_at = now_fn()
        records: list[ToolCallRecord] = []
        prev_output = None
        result_payload = None
        last_tool_summary: str | None = None

        for step_index, step in enumerate(skill.steps):
            tool = self._tools.get(step.tool_id)

            base = {} if prev_output is None else prev_output.model_dump(mode="json")
            try:
                # Phase WB-3F.2: an optional-source resolution (see
                # `_resolve_param`'s `_SCOPE_FILTER_OPTIONAL_PREFIX` branch)
                # returns the `_MISSING` sentinel when absent -- omitted
                # from `overlay` entirely here, never assigned as `None`,
                # so the Tool's own Pydantic default (which may not be
                # `None`, e.g. `group_by: list[str] = []`) applies exactly
                # as if this mapping entry had never been declared.
                overlay = {
                    key: value
                    for key, source in step.parameter_mapping.items()
                    if (value := _resolve_param(source, prev_output, objective)) is not _MISSING
                }
            except SkillParameterResolutionError as exc:
                return self._error_outcome(
                    skill, records, started_at, now_fn(), step_index, ErrorType.INVALID_QUERY, str(exc), objective.objective_id
                )

            merged = {**base, **overlay}
            input_model_cls = PayloadRegistry.model_for(tool.definition.input_payload_type)
            try:
                validated = input_model_cls.model_validate(merged)
            except ValidationError as exc:
                return self._error_outcome(
                    skill, records, started_at, now_fn(), step_index, ErrorType.INVALID_QUERY,
                    f"parameter validation failed for step {step_index} ('{step.tool_id}'): {exc}",
                    objective.objective_id,
                )

            payload_in = PayloadRegistry.pack(tool.definition.input_payload_type, validated)
            identity = ToolExecutionIdentity(
                run_id=module_state.run_id,
                module_id=module_state.module_id,
                objective_id=objective.objective_id,
                skill_id=skill.skill_id,
                skill_step_id=f"{step_index}:{step.tool_id}",
                # ties physical replay-safety to the Planner's own retry
                # counter: re-running this exact objective (a checkpoint
                # replay) reuses the cached result, but a genuinely new
                # attempt at the same objective_id (Objective.attempt_count
                # bumped) gets a distinct idempotency_key and actually
                # re-executes -- see test_tool_execution_manager_in_skill_runner.py
                logical_attempt=objective.attempt_count or 1,
            )
            tool_call_id = f"{module_state.module_id}-{objective.objective_id}-{skill.skill_id}-step{step_index}"
            step_started = now_fn()

            outcome = self._execution_manager.execute(
                tool, identity, payload_in, tool_call_id=tool_call_id, started_at=step_started, completed_at_fn=now_fn
            )
            records.append(outcome.record)

            if outcome.result.status != ObservationStatus.SUCCESS:
                completed_at = now_fn()
                error = ErrorRecord(
                    error_type=outcome.result.error_type or ErrorType.TOOL_ERROR,
                    message=outcome.result.error_message or f"step {step_index} ('{step.tool_id}') failed",
                    objective_id=objective.objective_id,
                    occurred_at_step=step_index,
                )
                return SkillRunOutcome(
                    SkillExecutionResult(
                        skill_id=skill.skill_id,
                        status=SkillExecutionStatus.ERROR,
                        tool_call_ids=[r.tool_call_id for r in records],
                        summary=f"skill '{skill.skill_id}' failed at step {step_index} ('{step.tool_id}')",
                        error=error,
                        started_at=started_at,
                        completed_at=completed_at,
                    ),
                    records,
                )

            result_payload = outcome.result.payload
            last_tool_summary = outcome.result.summary
            prev_output = PayloadRegistry.unpack(result_payload)

        completed_at = now_fn()
        # prefer the last step's own human-readable summary (what a Tool
        # actually found) over the generic "completed N step(s)" fallback --
        # see the Phase 5C-1 finding in agent/tools/models.py's
        # ToolExecutionResult.summary docstring
        summary = last_tool_summary or f"skill '{skill.skill_id}' completed {len(skill.steps)} step(s)"
        return SkillRunOutcome(
            SkillExecutionResult(
                skill_id=skill.skill_id,
                status=SkillExecutionStatus.SUCCESS,
                output_payload=result_payload,
                summary=summary,
                tool_call_ids=[r.tool_call_id for r in records],
                started_at=started_at,
                completed_at=completed_at,
            ),
            records,
        )

    @staticmethod
    def _error_outcome(skill, records, started_at, completed_at, step_index, error_type, message, objective_id) -> SkillRunOutcome:
        return SkillRunOutcome(
            SkillExecutionResult(
                skill_id=skill.skill_id,
                status=SkillExecutionStatus.ERROR,
                tool_call_ids=[r.tool_call_id for r in records],
                summary=f"skill '{skill.skill_id}' failed at step {step_index}",
                error=ErrorRecord(error_type=error_type, message=message, objective_id=objective_id, occurred_at_step=step_index),
                started_at=started_at,
                completed_at=completed_at,
            ),
            records,
        )
