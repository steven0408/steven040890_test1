from datetime import datetime
from enum import Enum

from pydantic import Field, model_validator

from agent.state.base import RCABaseModel
from agent.state.enums import ObjectiveAction, RiskLevel, TargetRefType, TaskType
from agent.state.models import ErrorRecord
from agent.state.payload import StructuredPayload


class SkillType(str, Enum):
    """Phase 5D-1: the taxonomy split this whole phase exists to freeze.
    EXECUTION Skills are "how to complete an analysis procedure" (may chain
    Tools via `steps`, run through SkillRunner/ToolExecutionManager).
    REASONING Skills are "how to think/judge" (Plant Manager Perspective,
    an RCA reasoning framework, ...) -- pure guidance text (the markdown
    body), never a Tool, never SkillRunner. Default is EXECUTION so every
    Skill markdown file written before this phase (which never declared
    `skill_type`) keeps behaving exactly as before."""

    EXECUTION = "execution"
    REASONING = "reasoning"


class SkillConsumerNode(str, Enum):
    """Phase 5D-3: the fixed, closed set of Harness nodes a Skill can ever
    be retrieved by -- freezes the Node<->Skill consumption matrix at the
    schema level (an unrecognized node name in a Skill's `applicable_nodes`
    is a pydantic ValidationError at load time, not a silent typo).
    `executor` here means "consumes EXECUTION skills through
    CapabilityResolver", not "retrieves REASONING skills" -- see the
    architecture doc's consumption matrix for the full per-node rule."""

    STANDARDIZER = "standardizer"
    ANALYZER = "analyzer"
    PLANNER = "planner"
    EXECUTION_GATE = "execution_gate"
    EXECUTOR = "executor"
    REFLECTOR = "reflector"
    COMPLETION_CHECK = "completion_check"
    SYNTHESIS = "synthesis"
    EVALUATOR = "evaluator"


class SkillStep(RCABaseModel):
    """One deterministic step in a Skill's procedure -- the machine-
    executable mirror of the markdown body's "Procedure" section, present
    only when the procedure IS a fixed tool sequence (exploratory skills
    without a `steps` list rely on the narrative body + an LLM instead;
    that path isn't built until Phase 5B-3+).
    """

    tool_id: str
    parameter_mapping: dict[str, str] = Field(default_factory=dict)


class SkillDefinition(RCABaseModel):
    """Registry-facing metadata for a Skill, parsed from a markdown file's
    YAML frontmatter (see agent/skills/markdown.py) -- this IS the single
    source of truth; there is no second, hand-maintained copy of `steps`
    anywhere else.
    """

    skill_id: str
    name: str
    description: str
    domains: list[str] = Field(default_factory=list)  # [] = shared
    category: str
    required_tools: list[str] = Field(default_factory=list)
    optional_tools: list[str] = Field(default_factory=list)
    steps: list[SkillStep] = Field(default_factory=list)
    input_contract: str
    output_contract: str
    risk_level: RiskLevel = RiskLevel.LOW
    version: str = "1"

    # Phase 5D-1: taxonomy. Defaults preserve every pre-5D Skill markdown
    # file unchanged (skill_type=EXECUTION, no applicable_nodes/roles
    # declared, enabled=True).
    skill_type: SkillType = SkillType.EXECUTION
    # Which Harness nodes may retrieve this Skill via ReasoningSkillRetriever
    # -- only meaningful for skill_type=REASONING (EXECUTION Skills are
    # never retrieved this way; they're resolved from an Objective's action
    # by CapabilityResolver instead, see agent/capability/resolver.py).
    applicable_nodes: list[SkillConsumerNode] = Field(default_factory=list)
    # Free-form perspective/role tags (e.g. "plant_manager",
    # "operations_manager") -- deliberately not a closed enum, so a new
    # perspective never requires a code change. [] = applies to any role.
    roles: list[str] = Field(default_factory=list)
    enabled: bool = True

    # Resolution triggers -- what CapabilityResolver matches an Objective
    # against. Declared here, in the same frontmatter, rather than as a
    # second hand-maintained rule table elsewhere: the Skill's markdown file
    # stays the single source of truth for "when do I apply", not just "how
    # do I execute".
    task_types: list[TaskType] = Field(default_factory=list)  # [] = any TaskType
    # Phase 5B-2.1: matches Objective.action, now a small closed set of
    # GENERIC analytical verbs (Phase WB-2B.1 -- QUERY/SUMMARIZE/SCREEN/
    # COMPARE/ANALYZE/DRILL_DOWN), never a domain-specific capability name
    # (that's `capability_key` below). Unlike `domains`/`task_types`, an
    # empty list here means "never matches" (no legitimate universal
    # action), not "any".
    actions: list[ObjectiveAction] = Field(default_factory=list)

    # --- Phase WB-2B.1: capability routing + scope contract -----------------
    #
    # WHICH domain capability this Skill IS -- the second half of
    # CapabilityResolver's matching key alongside `action` (Phase 8B-1's
    # objective_action_design_review.md Option 2, landed here). `None` only
    # for a Skill that has no real capability identity yet (the domain-
    # agnostic Harness-mechanics test fixture skill) -- such a Skill can
    # still be matched by domain/task_type/action alone, same as before
    # this phase, but never by an Objective that itself supplies a
    # capability_key (see CapabilityResolver.resolve()).
    capability_key: str | None = None
    # Replaces the old global, per-verb `ACTION_TARGET_TYPE` table
    # (agent/planning/policies/llm.py) -- WB-2B.1's own evidence showed
    # target-ref SHAPE is a property of the capability, not the verb (e.g.
    # SUMMARIZE is MODULE-wide for `oee.current_status` but ENTITY-scoped
    # for `wb.oee_plant_status`). `None` = any TargetRefType accepted.
    expected_target_ref_type: TargetRefType | None = None
    # The full set of ObjectiveScope dimension names (canonical, e.g.
    # "plant"/"operation"/"customer"/"package"/"device"/"status", plus the
    # two special time-kind names "production_date"/"snapshot_date") this
    # capability's Tool/parameter-mapping layer actually consumes -- both
    # required and optional ones. Core (`agent/state/scope.py`) has no
    # opinion on what these strings mean; only this Skill's own metadata
    # and its Tool's parameter mapping do.
    accepted_scope_dimensions: list[str] = Field(default_factory=list)
    # Subset of accepted_scope_dimensions that MUST be present (as a
    # ScopeFilter, or as `scope.time` for a time-kind name) for this
    # capability to be dispatched at all -- checked by
    # `validate_planner_decision` before a Tool ever runs, so a missing
    # `production_date` fails at Planner semantic-validation time, not
    # mid-Tool-execution (Phase WB-2B.1 item M's own requirement).
    required_scope_dimensions: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def _validate_skill_type_shape(self) -> "SkillDefinition":
        """Phase 5D-11 fail-fast rule: a REASONING skill declaring an
        executable-steps contract (steps/required_tools/optional_tools/
        actions/capability_key/scope dimensions) is a configuration error,
        not something CapabilityResolver should silently ignore -- catch it
        at load time, not mid-run."""
        if self.skill_type == SkillType.REASONING and (
            self.steps or self.required_tools or self.optional_tools or self.actions
            or self.capability_key is not None or self.accepted_scope_dimensions or self.required_scope_dimensions
        ):
            raise ValueError(
                f"skill '{self.skill_id}' is skill_type=reasoning but declares an executable-steps contract "
                "(steps/required_tools/optional_tools/actions/capability_key/scope dimensions) -- reasoning "
                "skills are pure guidance, never executed by SkillRunner/CapabilityResolver"
            )
        if self.required_scope_dimensions and not set(self.required_scope_dimensions) <= set(self.accepted_scope_dimensions):
            raise ValueError(
                f"skill '{self.skill_id}' lists required_scope_dimensions not present in accepted_scope_dimensions: "
                f"{sorted(set(self.required_scope_dimensions) - set(self.accepted_scope_dimensions))}"
            )
        return self


class SkillExecutionStatus(str, Enum):
    SUCCESS = "success"
    ERROR = "error"


class SkillExecutionResult(RCABaseModel):
    """What SkillRunner hands back to Module Executor -- one aggregate
    result per Skill run, regardless of how many steps/tool calls it took
    internally (those are separately audited as ToolCallRecord -- see
    SkillRunOutcome in agent/skills/runner.py). Executor turns this into
    exactly one Observation/Evidence, never one per step."""

    skill_id: str
    status: SkillExecutionStatus
    output_payload: StructuredPayload | None = None
    summary: str
    tool_call_ids: list[str] = Field(default_factory=list)
    error: ErrorRecord | None = None
    started_at: datetime
    completed_at: datetime
