---
skill_id: wb.oee_trend_analysis
name: WB OEE Historical Trend Analysis
description: Compares one WB plant's current OEE against its own recent baseline over a date range, with recurrence/persistence of below-threshold days. Descriptive only -- never a root-cause claim.
domains: [wb]
category: analysis
required_tools: [analyze_wb_oee_trend]
optional_tools: []
steps:
  - tool_id: analyze_wb_oee_trend
    parameter_mapping:
      plant_id: objective.scope.filter.plant
      start: objective.scope.time.start
      end: objective.scope.time.end
input_contract: WBOEETrendAnalysisInput
output_contract: WBOEETrendAnalysisResult
risk_level: low
version: "1"
task_types: [analysis, rca]
actions: [analyze]
capability_key: wb.oee.trend_analysis
expected_target_ref_type: entity
required_scope_dimensions: [production_date, plant]
accepted_scope_dimensions: [production_date, plant]
---

# Skill: WB OEE Historical Trend Analysis

## Goal

Answer "is this WB plant's OEE degradation a single-day event or a
recurring/persistent problem" (Phase WB-3B item C's own Scenario C
example) -- ANALYSIS/RCA-tier, plant-scoped, over a bounded historical
window (`ObjectiveScope.time` as a `start`/`end` range, not a single
date). `production_date` is reused as the `TimeScope.kind` tag for the
same documented reason `wb.issue_status_summary` does (see
`agent/planning/policies/wb.py`'s module docstring).

If multiple operations exist for a day and `operation_id` is not
supplied, each day's representative OEE is that day's worst-performing
operation (the same convention `wb.oee_status_analysis`'s own ranking
already uses) -- never a production-volume-weighted average, which this
system does not have the data to compute correctly (see the Tool's own
`limitations` output when this applies).

## Required Inputs

- `objective.target_ref` (`ref_type=entity`, `ref_id` = the plant's
  canonical id).
- `objective.scope.filters`: `plant` (EQ); `objective.scope.time`:
  `kind=production_date`, `start=<window start>`, `end=<current/window end>`.

## Procedure

1. Call `analyze_wb_oee_trend` with `plant_id`/`start`/`end` bound to the
   Objective's own scope.

## Constraints

- Deterministic only: fixed absolute abnormality threshold (OEE < 70),
  fixed recurrence/persistence/consecutive-day arithmetic
  (`agent/domain/wb/historical.py`). No causal claim of any kind --
  "ASE01's OEE was below threshold on 1 of 7 observed days" is a valid
  finding; "ASE01's OEE dropped because of X" is not.
- A day with no recorded OEE for the plant is absent from `daily_series`
  and never counted as normal or abnormal (`observed_days` reflects only
  real data).

## Output Contract

WBOEETrendAnalysisResult (agent.domain.wb.tool_results), scoped to one
plant over a production_date range.
