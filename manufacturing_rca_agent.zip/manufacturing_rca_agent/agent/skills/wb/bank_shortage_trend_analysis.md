---
skill_id: wb.bank_shortage_trend_analysis
name: WB Bank Material-Shortage Historical Trend Analysis
description: Compares one WB plant's current material-shortage ratio against its own recent baseline over a snapshot-date range, with recurrence/persistence of elevated-shortage snapshots. Descriptive only -- never a root-cause claim.
domains: [wb]
category: analysis
required_tools: [analyze_wb_bank_shortage_trend]
optional_tools: []
steps:
  - tool_id: analyze_wb_bank_shortage_trend
    parameter_mapping:
      plant_id: objective.scope.filter.plant
      start: objective.scope.time.start
      end: objective.scope.time.end
input_contract: WBBankShortageTrendAnalysisInput
output_contract: WBBankShortageTrendAnalysisResult
risk_level: low
version: "1"
task_types: [analysis, rca]
actions: [analyze]
capability_key: wb.bank.shortage_trend_analysis
expected_target_ref_type: entity
required_scope_dimensions: [snapshot_date, plant]
accepted_scope_dimensions: [snapshot_date, plant]
---

# Skill: WB Bank Material-Shortage Historical Trend Analysis

## Goal

Answer "has this WB plant's material-shortage rate been persistently
elevated" -- ANALYSIS/RCA-tier, plant-scoped, over a bounded historical
window. Focused on `material_shortage` specifically (Phase WB-3B item
11) -- never merges `Ready To Issue`/`No Wafer In` into one
undifferentiated "bad" bucket.

## Required Inputs

- `objective.target_ref` (`ref_type=entity`, `ref_id` = the plant's
  canonical id).
- `objective.scope.filters`: `plant` (EQ); `objective.scope.time`:
  `kind=snapshot_date`, `start=<window start>`, `end=<current/window end>`.

## Procedure

1. Call `analyze_wb_bank_shortage_trend` with `plant_id`/`start`/`end`
   bound to the Objective's own scope.

## Constraints

- Deterministic only: fixed absolute abnormality threshold (shortage
  ratio >= 0.5), fixed recurrence/persistence/consecutive-day arithmetic.
  "ASE07's material-shortage rate was elevated for 4 consecutive observed
  days" is a valid finding; "ASE07's shortage caused X" is not.

## Output Contract

WBBankShortageTrendAnalysisResult (agent.domain.wb.tool_results), scoped
to one plant over a snapshot_date range.
