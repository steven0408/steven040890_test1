---
skill_id: wb.oee_plant_status
name: WB Plant OEE Status
description: OEE and dominant loss category (downtime/setup/pm/idle) for one WB plant on one production date.
domains: [wb]
category: information
required_tools: [analyze_wb_oee_loss]
optional_tools: []
steps:
  - tool_id: analyze_wb_oee_loss
    parameter_mapping:
      production_date: objective.scope.time.date
      plant_id: objective.scope.filter.plant
input_contract: WBOEELossAnalysisInput
output_contract: WBOEELossAnalysisResult
risk_level: low
version: "1"
task_types: [information, rca]
actions: [summarize]
capability_key: wb.oee.plant_status
expected_target_ref_type: entity
required_scope_dimensions: [production_date, plant]
accepted_scope_dimensions: [production_date, plant]
---

# Skill: WB Plant OEE Status

## Goal

Answer "what is this WB plant's OEE on this date" -- e.g. "2026-08-12
ASE01 OEE 是多少" (Phase WB-2C's own worked example, Case A). Also the
OEE-oriented RCA symptom+pattern check and the Output-oriented RCA
equipment-side contributing-factor check (Phase WB-2D) -- the same one
call already answers both "is OEE abnormal" and "what is the dominant
loss category," so no separate RCA-only capability is needed. Both
`production_date` and `plant` are REQUIRED scope dimensions -- an
INFORMATION-tier single-plant lookup, distinct from
`wb.oee_status_analysis`'s module-wide ranking (Phase WB-2C item 11 needs
a plant-scoped question and an unscoped "who's worst" question to be
answered by two different capabilities, since one Skill's
`parameter_mapping` cannot conditionally include or omit `plant_id`).

## Required Inputs

- `objective.target_ref` (`ref_type=entity`, `ref_id` = the plant's
  canonical id).
- `objective.scope.filters`: `plant` (EQ, matches target_ref.ref_id);
  `objective.scope.time`: `kind=production_date`.

## Procedure

1. Call `analyze_wb_oee_loss` with `production_date`/`plant_id` bound to
   the Objective's own scope.

## Constraints

- Descriptive only: "ASE01 OEE = 58, dominant loss = downtime" is a
  valid finding; "ASE01 downtime caused by a motor failure" is not --
  that conclusion is out of scope (future cross-module RCA).

## Output Contract

WBOEELossAnalysisResult (agent.domain.wb.tool_results), scoped to one
plant/date (every matching operation).
