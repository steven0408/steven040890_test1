"""Standalone WB Skill loading (Phase WB-2B), mirroring
`agent/tools/wb/registration.py`'s own rationale: `ModulePackage`
(`agent/modules/models.py`, Phase 8B-1) requires a `policy_factory`, and
WB still has no real Module/Policy (out of scope this phase too) -- so
this deliberately does NOT go through `ModulePackage.skill_directories`
or touch `agent/bootstrap.py`.

`WB_SKILLS_DIR` is the exact value a future WB `ModulePackage` would put
in its own `skill_directories` tuple -- when that Module is eventually
built, wiring this in is a one-line change, not a rewrite.
"""
from pathlib import Path

from agent.skills.models import SkillDefinition
from agent.skills.registry import SkillRegistry

WB_SKILLS_DIR = Path(__file__).resolve().parent


def register_wb_skills(skill_registry: SkillRegistry) -> list[SkillDefinition]:
    """Loads every `*.md` Skill file in this directory into `skill_registry`.
    Never called at import time -- explicit, like every other WB
    registration this codebase has (Phase WB Data Layer V1's own
    discipline)."""
    return skill_registry.load_directory(WB_SKILLS_DIR)
