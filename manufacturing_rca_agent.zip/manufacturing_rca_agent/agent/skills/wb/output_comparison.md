---
skill_id: wb.output_comparison
name: WB Stage Output Plant Comparison
description: Ranks WB plants by total Stage Output quantity on one production date.
domains: [wb]
category: analysis
required_tools: [compare_wb_stage_output]
optional_tools: []
steps:
  - tool_id: compare_wb_stage_output
    parameter_mapping:
      production_date: objective.scope.time.date
      operation_id: objective.scope.filter_optional.operation
input_contract: WBStageOutputComparisonInput
output_contract: WBStageOutputComparisonResult
risk_level: low
version: "2"
task_types: [analysis, rca]
actions: [compare]
capability_key: wb.output.comparison
expected_target_ref_type: module
required_scope_dimensions: [production_date]
accepted_scope_dimensions: [production_date, operation]
---

# Skill: WB Stage Output Plant Comparison

## Goal

Answer "which WB plant produced the least on this date" -- module-wide
(never scoped to one plant -- that would defeat the purpose of a
comparison), ANALYSIS-tier, and reused for RCA (Phase WB-2D) as an
Output-oriented investigation's symptom-confirmation step: the Planner
finds its target plant's own entry within `comparison` to judge whether
that specific plant is actually low relative to its peers, rather than
trusting the user's premise. `production_date` is a required scope
dimension: WB-2B had left this Tool's `production_date` optional as a
workaround for `Objective` having nowhere to carry a date, which silently
summed output across every recorded date instead of comparing one day.
`ObjectiveScope.time` now supplies it, so the required-date business
semantic is restored (see the Phase WB-2B.1 report's "restore required
production_date" section).

## Required Inputs

- `objective.scope.time`: `kind=production_date`, `date=<the date>`.

## Optional Inputs

- `objective.scope.filters`: `operation` (EQ) -- Phase WB-3F.2. When
  present, narrows the comparison to that operation only (a pre-filter,
  never a grouping key -- every plant is still ranked, just from a
  narrower record set). When absent, `compare_wb_stage_output` uses its
  own default (every operation). The same Skill/Tool serves both "compare
  output across plants" and "compare output across plants for operation
  X" -- there is no separate per-operation capability.

## Procedure

1. Call `compare_wb_stage_output` with `production_date` bound to the
   Objective's own scope, and `operation_id` bound to the Objective's own
   scope when the Planner supplied one -- every plant, ranked descending
   by that day's (optionally operation-filtered) output quantity.

## Constraints

- Ranking is deterministic: highest output first, ties broken by
  plant_id ascending.
- Descriptive only: "ASE03 has the lowest output today" is a valid
  finding; attributing that gap to a specific cause is out of scope for
  this phase.

## Output Contract

WBStageOutputComparisonResult (agent.domain.wb.tool_results), scoped to
one production date.
