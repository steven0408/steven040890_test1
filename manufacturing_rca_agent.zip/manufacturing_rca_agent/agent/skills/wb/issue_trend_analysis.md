---
skill_id: wb.issue_trend_analysis
name: WB Issue Trend Analysis
description: Compares one WB plant's current-period Issue quantity against its own earlier baseline within a release-date range. Descriptive only -- never a causal claim.
domains: [wb]
category: analysis
required_tools: [analyze_wb_issue_trend]
optional_tools: []
steps:
  - tool_id: analyze_wb_issue_trend
    parameter_mapping:
      plant_id: objective.scope.filter.plant
      start: objective.scope.time.start
      end: objective.scope.time.end
input_contract: WBIssueTrendAnalysisInput
output_contract: WBIssueTrendAnalysisResult
risk_level: low
version: "1"
task_types: [analysis, rca]
actions: [analyze]
capability_key: wb.issue.trend_analysis
expected_target_ref_type: entity
required_scope_dimensions: [production_date, plant]
accepted_scope_dimensions: [production_date, plant]
---

# Skill: WB Issue Trend Analysis

## Goal

Answer "is this WB plant's recent Issue quantity below its own baseline"
-- e.g. "ASE07 最近投料是否偏低" (Phase WB-3A item R's own worked example).
ANALYSIS-tier, plant-scoped -- this is inherently a self-baseline
question (comparing a plant against its own earlier history), never a
cross-plant comparison, so `plant` is a required scope dimension.

Uses `ObjectiveScope.time` as a bounded RANGE (`start`/`end`, already
part of the existing `TimeScope` contract -- no Core change was needed
to build this Skill) rather than a single `date`. `production_date` is
reused as the `TimeScope.kind` tag for the same documented reason
`wb.issue_status_summary` reuses it (see that Skill's own docstring, and
`agent/planning/policies/wb.py`'s module docstring).

`AnalyzeWBIssueTrendTool`'s own `current_period_days` input (how many
trailing days of the range count as "current" vs "baseline") is left at
its default (1 day = "today vs. the rest of the window") -- this Skill
does not map it from `ObjectiveScope`, since there is no natural scope
dimension for it yet; a future phase could add one if a real need for a
different split emerges.

## Required Inputs

- `objective.target_ref` (`ref_type=entity`, `ref_id` = the plant's
  canonical id).
- `objective.scope.filters`: `plant` (EQ, matches target_ref.ref_id);
  `objective.scope.time`: `kind=production_date`, `start=<range start>`,
  `end=<range end>`.

## Procedure

1. Call `analyze_wb_issue_trend` with `plant_id`/`start`/`end` bound to
   the Objective's own scope.

## Constraints

- Deterministic descriptive analysis only: current-period vs.
  baseline-period average-daily Issue quantity, a fixed percentage
  threshold for UP/DOWN/FLAT classification. NEVER a causal claim --
  "ASE07's Issue trended down" is a valid finding; "ASE07's Issue trended
  down because of material shortage" or "low Issue caused low Output" are
  both explicitly forbidden (Phase WB-3A item C/W).
- `trend_direction=UNKNOWN` when the range has no baseline period to
  compare against (e.g. `start`/`end` cover only the current window) --
  never fabricated as FLAT/UP/DOWN.

## Output Contract

WBIssueTrendAnalysisResult (agent.domain.wb.tool_results), scoped to one
plant/release-date range.
