---
skill_id: wb.bank_aging_analysis
name: WB Bank Aging Analysis
description: How long WB Bank lots have sat since bank_entry_time, where that field is known -- longest-aging entries and known/unknown split.
domains: [wb]
category: analysis
required_tools: [analyze_wb_bank_aging]
optional_tools: []
steps:
  - tool_id: analyze_wb_bank_aging
    parameter_mapping: {}
input_contract: WBBankAgingAnalysisInput
output_contract: WBBankAgingAnalysisResult
risk_level: low
version: "1"
task_types: [analysis]
actions: [analyze]
capability_key: wb.bank.aging_analysis
expected_target_ref_type: module
---

# Skill: WB Bank Aging Analysis

## Goal

Answer "how long has WB Bank inventory been sitting" -- a distinct
analytical question from `wb.bank_status_summary`'s status distribution,
kept as its own Skill rather than an "optional" step of that one: the
current `SkillRunner` executes a fixed, unconditional step sequence with
no branching, so a genuinely optional sub-analysis is expressed as a
separate Skill, not a conditional step -- see the Phase WB-2B report's
`optional_tools` runtime-semantics finding.

## Procedure

1. Call `analyze_wb_bank_aging` with no filters -- the latest snapshot's
   aging breakdown across every plant.

## Constraints

- Aging is computed ONLY where `bank_entry_time` is known; records
  missing it are counted separately (`records_with_unknown_aging`) and
  surfaced in `limitations`, never guessed at.
- Descriptive only -- reports aging, never a cause for it.

## Output Contract

WBBankAgingAnalysisResult (agent.domain.wb.tool_results).
