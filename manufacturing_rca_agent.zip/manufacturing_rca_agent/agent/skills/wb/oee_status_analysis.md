---
skill_id: wb.oee_status_analysis
name: WB Plant OEE Status Analysis
description: Ranks every WB plant/operation by OEE on one production date and surfaces each entry's dominant loss category.
domains: [wb]
category: analysis
required_tools: [analyze_wb_oee_loss]
optional_tools: []
steps:
  - tool_id: analyze_wb_oee_loss
    parameter_mapping:
      production_date: objective.scope.time.date
input_contract: WBOEELossAnalysisInput
output_contract: WBOEELossAnalysisResult
risk_level: low
version: "1"
task_types: [analysis]
actions: [analyze]
capability_key: wb.oee.status_analysis
expected_target_ref_type: module
required_scope_dimensions: [production_date]
accepted_scope_dimensions: [production_date]
---

# Skill: WB Plant OEE Status Analysis

## Goal

Answer "which WB plant has the worst OEE on this date, and what's the
dominant loss category" -- e.g. "2026-08-12 哪個 Plant OEE 最差？主要
loss 是什麼？" (Phase WB-2C Case B). Module-wide, unscoped by plant on
purpose: ranking every plant is the whole point of this capability. For
"what is ONE specific plant's OEE", see `wb.oee_plant_status` instead --
kept as a separate Skill/capability_key because `parameter_mapping`
cannot conditionally include or omit `plant_id` depending on whether the
Objective happened to supply one (see the Phase WB-2C report's Case A/B
resolution).

## Required Inputs

- `objective.scope.time`: `kind=production_date`. No `target_ref`/plant
  filter needed or accepted -- this capability is inherently cross-plant.

## Procedure

1. Call `analyze_wb_oee_loss` with `production_date` bound to the
   Objective's own scope, no plant filter -- every plant/operation,
   ranked worst-OEE-first.

## Constraints

- Ranking is deterministic (worst OEE first, fixed tie-break) and
  `dominant_loss_category` uses a fixed downtime > setup > pm > idle
  tie-break -- see `agent/tools/wb/oee_tools.py`.
- Descriptive only. "ASE01 OEE = 58, dominant loss = downtime" is a
  valid finding; "ASE01 downtime caused by a motor failure" is not --
  that conclusion is out of scope for this phase (future cross-module
  RCA).

## Output Contract

WBOEELossAnalysisResult (agent.domain.wb.tool_results) -- every recorded
plant/operation on that date, ranked worst-OEE-first.
