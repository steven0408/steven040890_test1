---
skill_id: wb.wip_status_summary
name: WB WIP Status Summary
description: Current WB WIP quantity and lot count, grouped by lot status and operation.
domains: [wb]
category: information
required_tools: [summarize_wb_wip]
optional_tools: []
steps:
  - tool_id: summarize_wb_wip
    parameter_mapping: {}
input_contract: WBWIPSummaryInput
output_contract: WBWIPSummaryResult
risk_level: low
version: "1"
task_types: [information]
actions: [summarize]
capability_key: wb.wip.status_summary
expected_target_ref_type: module
---

# Skill: WB WIP Status Summary

## Goal

Answer "what is WB WIP status right now" -- module-wide, INFORMATION-tier.
WIP is a snapshot dataset; same as `wb.bank_status_summary`, leaving
`snapshot_date` unmapped reads `summarize_wb_wip`'s own
`latest_snapshot_only=True` default, resolving to the current snapshot.

## Procedure

1. Call `summarize_wb_wip` with no filters -- current total quantity/lot
   count across every plant, grouped by status and operation.

## Output Contract

WBWIPSummaryResult (agent.domain.wb.tool_results).
