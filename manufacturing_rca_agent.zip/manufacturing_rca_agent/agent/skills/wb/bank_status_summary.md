---
skill_id: wb.bank_status_summary
name: WB Bank Status Summary
description: Current WB Bank inventory status distribution (Ready To Issue / Material Shortage / No Wafer In) for one plant, grouped by package/device.
domains: [wb]
category: information
required_tools: [summarize_wb_bank_status]
optional_tools: []
steps:
  - tool_id: summarize_wb_bank_status
    parameter_mapping:
      plant_id: objective.scope.filter.plant
      customer_code: objective.scope.filter_optional.customer
      group_by: objective.scope.group_by
input_contract: WBBankStatusSummaryInput
output_contract: WBBankStatusSummaryResult
risk_level: low
version: "2"
task_types: [information, rca]
actions: [summarize]
capability_key: wb.bank.status_summary
expected_target_ref_type: entity
required_scope_dimensions: [plant]
accepted_scope_dimensions: [plant, customer, package, device]
---

# Skill: WB Bank Status Summary

## Goal

Answer "what is WB Bank inventory status right now" for one plant --
e.g. "ASE07 Bank 狀況如何" (Phase WB-2B.1). Reused for RCA (Phase WB-2D)
as an Output-oriented investigation's material-availability
contributing-factor check -- an elevated material-shortage rate is a
supported causal candidate, never a confirmed cause. `plant` is a required scope
dimension: this Skill answers a specific plant's question, not a
cross-plant dump (matches manufacturing usage -- a Plant Manager asks
about their own plant).

`snapshot_date` is deliberately NOT wired as a scope dimension here:
`summarize_wb_bank_status`'s own `latest_snapshot_only=True` default
(Phase WB Data Layer V1/WB-2A) already resolves to "the current snapshot"
correctly on its own -- unlike OEE/OUTPUT's daily-like `production_date`
(where an unscoped call silently blended every recorded day, a real gap
WB-2B.1 fixed), BANK's un-dated default was never actually wrong, so
there is nothing here to fix. A future phase could still add explicit
snapshot_date scoping if a real need for "as of a specific past
snapshot" (not just "current") emerges.

## Required Inputs

- `objective.target_ref` (`ref_type=entity`, `ref_id` = the plant's
  canonical id).
- `objective.scope.filters`: `plant` (EQ, matches target_ref.ref_id).

## Optional Inputs (Phase WB-3F.2)

- `objective.scope.filters`: `customer` (EQ). When present, narrows the
  summary to that customer's own BANK records only. When absent, the
  Tool's own default (every customer) applies -- same Skill/Tool either
  way, never a separate per-customer capability.
- `objective.scope.group_by`: any of `plant`/`package`/`device`. When
  present, narrows which breakdown(s) `summarize_wb_bank_status` computes
  (an unsupported name is rejected by the Tool itself, never silently
  ignored -- see `_BANK_ALLOWED_GROUP_BY` in
  `agent/tools/wb/bank_tools.py`). When absent/empty, all three
  breakdowns are computed, matching this Skill's pre-WB-3F.2 behavior
  exactly.

## Procedure

1. Call `summarize_wb_bank_status` with `plant_id` bound to the
   Objective's own scope, and `customer_code`/`group_by` bound to the
   Objective's own scope when the Planner supplied them -- current
   (latest-snapshot) status distribution for that plant.

## Constraints

- Descriptive counts/ratios only. "ASE07 Material Shortage = 70%" is a
  valid finding; "ASE07 output is low because of Material Shortage" is
  not -- that cross-source causal claim is out of scope for this phase.

## Output Contract

WBBankStatusSummaryResult (agent.domain.wb.tool_results), scoped to one
plant.
