---
skill_id: wb.wip_hold_analysis
name: WB WIP Hold Analysis
description: WB WIP Hold quantity/ratio for one plant, grouped by operation/package/customer -- descriptive only, never a root-cause claim.
domains: [wb]
category: analysis
required_tools: [analyze_wb_hold]
optional_tools: []
steps:
  - tool_id: analyze_wb_hold
    parameter_mapping:
      snapshot_date: objective.scope.time.date
      plant_id: objective.scope.filter.plant
input_contract: WBHoldAnalysisInput
output_contract: WBHoldAnalysisResult
risk_level: low
version: "1"
task_types: [analysis, rca]
actions: [analyze]
capability_key: wb.wip.hold_analysis
expected_target_ref_type: entity
required_scope_dimensions: [snapshot_date, plant]
accepted_scope_dimensions: [snapshot_date, plant]
---

# Skill: WB WIP Hold Analysis

## Goal

Answer "how much WB WIP is on Hold for this plant, and where is it
concentrated" -- e.g. "2026-08-12 ASE03 2800 的 Hold 狀況如何" (Phase
WB-2B.1's own worked example; also the WIP-oriented RCA symptom+pattern
check and the Output-oriented RCA flow-congestion contributing-factor
check, Phase WB-2D) -- `operation` is not wired here: the
underlying `analyze_wb_hold` Tool has no `operation_id` filter, and
adding one wasn't needed by any of this phase's concrete test cases, so
it was left as a noted future extension rather than built speculatively;
see the Phase WB-2B.1 report). Kept as its own Skill, separate from
`wb.wip_status_summary`, for the same reason `wb.bank_aging_analysis` is
separate from `wb.bank_status_summary`: no conditional/optional step
execution exists in the current `SkillRunner`.

## Required Inputs

- `objective.target_ref` (`ref_type=entity`, `ref_id` = the plant's
  canonical id).
- `objective.scope`: `time.kind=snapshot_date` (not `production_date` --
  WIP has no production-date concept, only a snapshot time), `filters:
  plant` (EQ, matches target_ref.ref_id).

## Procedure

1. Call `analyze_wb_hold` with `snapshot_date`/`plant_id` bound to the
   Objective's own scope.

## Constraints

- `hold_ratio` is `None`, never `0.0`, when there are zero lots in scope
  (empty denominator).
- Strictly descriptive: "ASE03 Hold ratio = 73.3%" is a valid finding;
  "ASE03 Hold is caused by equipment failure" or "...by material
  shortage" is explicitly forbidden -- that cross-source causal
  attribution is out of scope for this phase.

## Output Contract

WBHoldAnalysisResult (agent.domain.wb.tool_results), scoped to one plant.
