---
skill_id: wb.wip_hold_trend_analysis
name: WB WIP Hold Historical Trend Analysis
description: Compares one WB plant's current WIP Hold ratio against its own recent baseline over a snapshot-date range, with recurrence/persistence of elevated-Hold snapshots. Descriptive only -- never a root-cause claim.
domains: [wb]
category: analysis
required_tools: [analyze_wb_wip_hold_trend]
optional_tools: []
steps:
  - tool_id: analyze_wb_wip_hold_trend
    parameter_mapping:
      plant_id: objective.scope.filter.plant
      start: objective.scope.time.start
      end: objective.scope.time.end
input_contract: WBWIPHoldTrendAnalysisInput
output_contract: WBWIPHoldTrendAnalysisResult
risk_level: low
version: "1"
task_types: [analysis, rca]
actions: [analyze]
capability_key: wb.wip.hold_trend_analysis
expected_target_ref_type: entity
required_scope_dimensions: [snapshot_date, plant]
accepted_scope_dimensions: [snapshot_date, plant]
---

# Skill: WB WIP Hold Historical Trend Analysis

## Goal

Answer "how many times has this WB plant's WIP Hold ratio been elevated
in the past N days" (Phase WB-3B item 17's own explicit example) --
ANALYSIS/RCA-tier, plant-scoped, over a bounded historical window. Uses
`snapshot_date` (not `production_date`) -- WIP has no production-date
concept, only a snapshot time (same rule `wb.wip_hold_analysis` already
follows).

One representative snapshot per calendar day (via the existing
`latest_snapshot_only` convention, applied per day across the range) --
a day with more than one same-day sync is never double-counted.

## Required Inputs

- `objective.target_ref` (`ref_type=entity`, `ref_id` = the plant's
  canonical id).
- `objective.scope.filters`: `plant` (EQ); `objective.scope.time`:
  `kind=snapshot_date`, `start=<window start>`, `end=<current/window end>`.

## Procedure

1. Call `analyze_wb_wip_hold_trend` with `plant_id`/`start`/`end` bound to
   the Objective's own scope.

## Constraints

- Deterministic only: fixed absolute abnormality threshold (Hold ratio >=
  0.3), fixed recurrence/persistence/consecutive-day arithmetic. Never
  claims the underlying reason for Hold -- "ASE03's Hold ratio was
  elevated on 4 of 7 observed days" is a valid finding; "ASE03's Hold is
  caused by X" is not (same rule `wb.wip_hold_analysis` already follows).
- A snapshot day with zero lots in scope has `hold_ratio=None`, never a
  fabricated `0.0`.

## Output Contract

WBWIPHoldTrendAnalysisResult (agent.domain.wb.tool_results), scoped to
one plant over a snapshot_date range.
