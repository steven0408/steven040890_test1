---
skill_id: wb.output_trend_analysis
name: WB Stage Output Historical Trend Analysis
description: Compares one WB plant's current Stage Output against its own recent baseline over a production-date range, with recurrence/persistence of below-baseline days. Descriptive only -- never a causal claim.
domains: [wb]
category: analysis
required_tools: [analyze_wb_output_trend]
optional_tools: []
steps:
  - tool_id: analyze_wb_output_trend
    parameter_mapping:
      plant_id: objective.scope.filter.plant
      operation_id: objective.scope.filter_optional.operation
      start: objective.scope.time.start
      end: objective.scope.time.end
input_contract: WBOutputTrendAnalysisInput
output_contract: WBOutputTrendAnalysisResult
risk_level: low
version: "2"
task_types: [analysis, rca]
actions: [analyze]
capability_key: wb.output.trend_analysis
expected_target_ref_type: entity
required_scope_dimensions: [production_date, plant]
accepted_scope_dimensions: [production_date, plant, operation]
---

# Skill: WB Stage Output Historical Trend Analysis

## Goal

Answer "has this WB plant's Output been persistently low, or is today a
one-off" -- ANALYSIS/RCA-tier, plant-scoped, over a bounded historical
window. `below_self_baseline_is_abnormal` -- OUTPUT has no domain-
independent "low" value, so abnormality is relative to this window's own
computed baseline (same approach `wb.issue_trend_analysis` already uses).

## Required Inputs

- `objective.target_ref` (`ref_type=entity`, `ref_id` = the plant's
  canonical id).
- `objective.scope.filters`: `plant` (EQ); `objective.scope.time`:
  `kind=production_date`, `start=<window start>`, `end=<current/window end>`.

## Procedure

1. Call `analyze_wb_output_trend` with `plant_id`/`start`/`end` bound to
   the Objective's own scope.

## Constraints

- Deterministic only. Never asserts a cause for a low-Output day --
  "ASE07's Output was below its recent baseline" is a valid finding;
  "ASE07's Output dropped because of X" is not.

## Output Contract

WBOutputTrendAnalysisResult (agent.domain.wb.tool_results), scoped to one
plant over a production_date range.
