---
skill_id: wb.output_status_summary
name: WB Stage Output Status Summary
description: Total WB Stage Output quantity, grouped by plant/operation/product.
domains: [wb]
category: information
required_tools: [summarize_wb_stage_output]
optional_tools: []
steps:
  - tool_id: summarize_wb_stage_output
    parameter_mapping: {}
input_contract: WBStageOutputSummaryInput
output_contract: WBStageOutputSummaryResult
risk_level: low
version: "1"
task_types: [information]
actions: [summarize]
capability_key: wb.output.status_summary
expected_target_ref_type: module
---

# Skill: WB Stage Output Status Summary

## Goal

Answer "what is WB Stage Output right now" -- module-wide,
INFORMATION-tier. OUTPUT is daily-like (has a real `production_date`
distinct from `source_sync_time`), but this Skill leaves it unmapped on
purpose (unlike `wb.oee_status_analysis`/`wb.output_comparison`, whose
underlying Tools' `production_date` is a REQUIRED field precisely because
their business semantic is "analyze one date"): `summarize_wb_stage_output`'s
own `production_date` stays optional, and this Skill's job is a
module-wide overview across every recorded date, not a single-day
figure -- see the Phase WB-2B.1 report for why this one intentionally
was not scoped like the other two.

## Procedure

1. Call `summarize_wb_stage_output` with no filters -- total output
   quantity across every plant/operation/product currently recorded.

## Output Contract

WBStageOutputSummaryResult (agent.domain.wb.tool_results).
