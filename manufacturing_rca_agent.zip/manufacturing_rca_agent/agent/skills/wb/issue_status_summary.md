---
skill_id: wb.issue_status_summary
name: WB Issue Status Summary
description: WB Issue (material release) quantity and distribution for one plant on one release date.
domains: [wb]
category: information
required_tools: [summarize_wb_issue]
optional_tools: []
steps:
  - tool_id: summarize_wb_issue
    parameter_mapping:
      release_date: objective.scope.time.date
      plant_id: objective.scope.filter.plant
input_contract: WBIssueSummaryInput
output_contract: WBIssueSummaryResult
risk_level: low
version: "1"
task_types: [information]
actions: [summarize]
capability_key: wb.issue.status_summary
expected_target_ref_type: entity
required_scope_dimensions: [production_date, plant]
accepted_scope_dimensions: [production_date, plant]
---

# Skill: WB Issue Status Summary

## Goal

Answer "what is this WB plant's Issue (material release) status on this
date" -- e.g. "2026-08-12 ASE07 的投料狀況如何" (Phase WB-3A's own worked
example). Both a release date and a plant are REQUIRED scope dimensions --
an INFORMATION-tier single-plant, single-date lookup, mirroring
`wb.oee_plant_status`'s exact shape.

`production_date` is reused as the `TimeScope.kind` tag here (Phase
WB-3A's own documented decision -- see `agent/planning/policies/wb.py`'s
module docstring) even though the business date is ISSUE's own
`release_date`, never OEE/OUTPUT's `production_date` concept: both are
"a real per-record business date, distinct from any sync/snapshot
timestamp", the exact category `TimeScopeKind.PRODUCTION_DATE` exists to
express, so no new Core enum member was added. `WBQueryScope.release_date`
(never `.production_date`) is what the Tool actually echoes back, so
nothing downstream mislabels this as an OEE/OUTPUT-style date.

## Required Inputs

- `objective.target_ref` (`ref_type=entity`, `ref_id` = the plant's
  canonical id).
- `objective.scope.filters`: `plant` (EQ, matches target_ref.ref_id);
  `objective.scope.time`: `kind=production_date`, `date=<release date>`.

## Procedure

1. Call `summarize_wb_issue` with `release_date`/`plant_id` bound to the
   Objective's own scope.

## Constraints

- **Item V's critical distinction**: the underlying `WBIssueDataSource`
  cannot filter by release date at the source level (the real API's own
  `date` parameter filters `SYNC_TIME`, never `rel_date`) -- `summarize_wb_issue`
  fetches unscoped and filters precisely by the canonical `release_date`
  field itself, in Python. This Skill's caller never needs to know that;
  the Objective's `production_date`-tagged scope is filtered correctly
  either way.
- Descriptive only: "ASE07 issued 400 units on 2026-08-12" is a valid
  finding; "ASE07 issued less because of material shortage" is not --
  that cross-source causal claim is out of scope for this phase.

## Output Contract

WBIssueSummaryResult (agent.domain.wb.tool_results), scoped to one
plant/release date.
