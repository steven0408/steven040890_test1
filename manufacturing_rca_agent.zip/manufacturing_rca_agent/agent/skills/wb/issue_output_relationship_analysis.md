---
skill_id: wb.issue_output_relationship_analysis
name: WB Issue vs. Output Relationship Analysis
description: Descriptive temporal association between one WB plant's Issue and Output trends over the same historical window -- never a causal claim.
domains: [wb]
category: analysis
required_tools: [analyze_wb_issue_vs_output]
optional_tools: []
steps:
  - tool_id: analyze_wb_issue_vs_output
    parameter_mapping:
      plant_id: objective.scope.filter.plant
      start: objective.scope.time.start
      end: objective.scope.time.end
input_contract: WBIssueOutputRelationshipInput
output_contract: WBIssueOutputRelationshipResult
risk_level: low
version: "1"
task_types: [analysis, rca]
actions: [analyze]
capability_key: wb.issue_output.relationship_analysis
expected_target_ref_type: entity
required_scope_dimensions: [production_date, plant]
accepted_scope_dimensions: [production_date, plant]
---

# Skill: WB Issue vs. Output Relationship Analysis

## Goal

Answer "did this WB plant's Issue and Output move together over the same
window" (Phase WB-3B item 19's own worked example) -- the first
cross-source WB capability, consuming BOTH `WBIssueDataSource` and
`WBStageOutputDataSource` inside `AnalyzeWBIssueVsOutputTool`. ANALYSIS/
RCA-tier only (never INFORMATION -- this is inherently a comparative
judgment, not a raw fact lookup).

**Critical boundary (item 21/29)**: this Skill can only ever produce
descriptive temporal association -- "ASE07 issue quantity and output both
declined over the overlapping historical window" is a legal finding.
"Low issue caused low output" is not, and nothing in
`WBIssueOutputRelationshipResult` (no `causal` field, no `cause_strength`)
can represent that claim even if a caller tried.

## Required Inputs

- `objective.target_ref` (`ref_type=entity`, `ref_id` = the plant's
  canonical id).
- `objective.scope.filters`: `plant` (EQ); `objective.scope.time`:
  `kind=production_date`, `start=<window start>`, `end=<current/window end>`.

## Procedure

1. Call `analyze_wb_issue_vs_output` with `plant_id`/`start`/`end` bound
   to the Objective's own scope.

## Constraints

- Join key is business date (`release_date` for ISSUE, `production_date`
  for OUTPUT) -- NEVER `source_sync_time`.
- Both sources are aggregated to one daily total per plant BEFORE any
  join, so there is no row-level many-to-many join and no
  double-counting risk.
- `direction_alignment=INSUFFICIENT_DATA` (never a fabricated
  association) when fewer than `MIN_OVERLAP_DAYS` (2) days have data from
  BOTH sources.

## Output Contract

WBIssueOutputRelationshipResult (agent.domain.wb.tool_results), scoped to
one plant over a production_date range.
