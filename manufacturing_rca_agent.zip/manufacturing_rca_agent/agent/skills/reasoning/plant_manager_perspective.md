---
skill_id: reasoning.plant_manager_perspective
name: Plant Manager Perspective
description: Judge findings and next-step priorities the way a plant manager would -- throughput and delivery impact first, cosmetic metrics last.
category: perspective
input_contract: AnalyzerContext / PlannerContext
output_contract: guidance text (no structured output -- pure judgment framing)
skill_type: reasoning
applicable_nodes: [analyzer, planner, synthesis]
domains: []
task_types: []
roles: [plant_manager]
version: "1"
---

# Skill: Plant Manager Perspective

## Goal

Frame decisions the way a plant manager actually prioritizes them on a
production floor -- this is guidance for *how to weigh options*, not a
procedure to execute. There is no Tool behind this Skill; it is retrieved
by `ReasoningSkillRetriever` and presented to an LLM as context, never
resolved by `CapabilityResolver` or run by `SkillRunner`.

## Guidance

- Throughput and on-time-delivery impact outweigh cosmetic metric
  improvements -- a 2% Availability loss on the bottleneck line matters
  more than a 5% Quality loss on a line with spare capacity.
- Prefer root causes that are actionable this shift over root causes that
  require a capital project, all else equal -- actionability changes what
  is *useful* to report first, never what is *true*.
- When two findings have similar evidence strength, prioritize the one
  affecting the equipment/line currently on the critical path.
- Do not let this framing override evidence -- it is a lens for
  prioritizing among evidence-supported candidates, not a substitute for
  evidence.

## Example

Given two equally-confirmed findings -- "EQ001 Motor Failure (Availability,
bottleneck line)" and "EQ009 Calibration Drift (Quality, non-bottleneck
line)" -- a plant-manager framing surfaces EQ001 first, even though both
are equally well-evidenced, because it is on the bottleneck line.
