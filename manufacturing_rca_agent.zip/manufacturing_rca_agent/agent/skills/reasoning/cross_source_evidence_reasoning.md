---
skill_id: reasoning.cross_source_evidence_reasoning
name: Cross-Source Evidence Reasoning
description: How to combine two independently-established signals (e.g. ISSUE and OUTPUT) responsibly -- align on business date, weigh timing and overlap, consider alternative explanations, and classify the result as descriptive association at most, never a confirmed cause.
category: mental_model
input_contract: PlannerContext
output_contract: guidance text (no structured output -- pure judgment framing)
skill_type: reasoning
applicable_nodes: [planner]
domains: [wb]
task_types: [rca]
roles: []
version: "1"
---

# Skill: Cross-Source Evidence Reasoning

## Goal

Guide how the Planner interprets (and decides whether to pursue) a
cross-source relationship between two WB signals -- responsibly, without
inflating a descriptive pattern into a causal claim.

## Guidance

- **Establish each signal independently first.** Confirm ISSUE's own
  trend and OUTPUT's own trend on their own merits before asking whether
  they moved together -- a cross-source check is only meaningful once
  both sides individually show something worth relating.
- **Business date alignment, never sync/snapshot time.** ISSUE and OUTPUT
  are only comparable day-by-day on their own business dates
  (release_date / production_date) -- never on when either record
  happened to be synced to the database.
- **Overlap size bounds confidence.** A relationship computed over 2
  overlapping days deserves far less weight than one computed over 7 --
  treat a thin overlap as reason for caution, not as reason to avoid
  reporting it (report it, but qualified).
- **Consider the alternative explanation before accepting the obvious
  one.** Two signals moving together over the same window is consistent
  with a shared upstream cause, but is also consistent with coincidence,
  a shared external driver neither signal captures, or one signal
  lagging/leading the other for an unrelated reason. Do not treat
  "moved together" as "one caused the other."
- **Three distinct tiers, never conflated:**
  1. **Descriptive association** -- "both declined over the same
     observed window." Always the ceiling for what a cross-source Tool
     result alone supports.
  2. **Supported candidate** -- association plus a plausible mechanism
     (e.g. the manufacturing-flow reasoning skill's own upstream-flow
     logic) and no strong contradicting evidence. Still not confirmed.
  3. **Confirmed root cause** -- would require evidence this plant-level
     data does not provide (no equipment-failure-reason/defect-reason/
     supply-chain-root field exists at this grain). WB data alone should
     essentially never reach this tier.
- A cross-source Tool's own `association_statement` is already
  descriptive, non-causal wording -- do not add causal language on top of
  it when reasoning about or reporting the result.

## Example

ISSUE trended down (-42.9%) and OUTPUT trended down (-20.0%) over the
same 7-day window, `overlap_observed_days=7`, `direction_alignment=
SAME_DIRECTION`. Correct framing: "ASE07 issue quantity and output both
declined over the same observed period" (tier 1, possibly tier 2 given
the flow reasoning's own upstream-starvation mechanism). Incorrect
framing: "low issue caused low output" (tier 3 -- never supported by
this evidence alone).
