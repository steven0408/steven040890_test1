---
skill_id: reasoning.causal_inference_guard
name: Causal Inference Guard
description: A short, load-bearing caution against overclaiming causation from temporal/positional co-occurrence, process ordering, or correlation -- applies across every WB finding, not just cross-source ones.
category: guardrail
input_contract: PlannerContext
output_contract: guidance text (no structured output -- pure judgment framing)
skill_type: reasoning
applicable_nodes: [planner, reflector]
domains: [wb]
task_types: [rca]
roles: []
version: "1"
---

# Skill: Causal Inference Guard

## Goal

One narrow, load-bearing rule, applicable to every WB finding: WB
plant-level data can establish that things happened, and roughly when --
it essentially never establishes why, in the strong causal sense.

## Guidance

- **Process ordering is not causal proof.** BANK precedes ISSUE precedes
  WIP precedes OUTPUT in the material flow, but "upstream signal was
  abnormal, then downstream signal was abnormal" is a sequence
  observation, not a demonstrated mechanism.
- **Same-day or same-window movement is not causal proof.** Two signals
  changing together is consistent with a causal link, but equally
  consistent with a shared unobserved driver, coincidence, or one metric
  simply lagging/leading the other for unrelated reasons.
- **A single-source abnormal pattern is not, by itself, "the cause" of a
  different symptom.** "WIP Hold ratio was elevated" and "Output was
  low" existing in the same window is an association worth reporting --
  it is not evidence that Hold caused the Output drop, unless corroborated
  by something more than co-occurrence (and even then, WB plant-level
  data rarely provides that "something more").
- **The ceiling for a WB finding, absent stronger evidence, is a
  "supported candidate" or "descriptive pattern," never a "confirmed root
  cause."** `is_root_cause=True` should be reserved for cases where the
  evidence genuinely closes the causal question -- which, given this
  data grain (no equipment-failure-reason/defect-reason/supply-chain-root
  field), is rare to essentially never satisfied.
- This guard does not mean avoid drawing conclusions -- it means state
  them at the confidence level the evidence actually supports: "X is
  consistent with explaining Y" is honest; "X caused Y" usually is not.

## Example

Forbidden: "ASE07's low ISSUE caused the low OUTPUT." Acceptable: "ASE07
issue quantity and output both declined over the same observed window,
consistent with an upstream material constraint -- not confirmed as the
root cause."
