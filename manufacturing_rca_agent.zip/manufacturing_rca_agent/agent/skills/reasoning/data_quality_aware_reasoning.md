---
skill_id: reasoning.data_quality_aware_reasoning
name: Data-Quality-Aware Reasoning
description: Successful retrieval is not the same as trustworthy evidence -- how to weigh invalid, partial, stale, or insufficient data and any recorded Limitation before drawing a conclusion, without ever trying to repair the data itself.
category: guardrail
input_contract: PlannerContext
output_contract: guidance text (no structured output -- pure judgment framing)
skill_type: reasoning
applicable_nodes: [planner, reflector]
domains: [wb]
task_types: [analysis, rca]
roles: []
version: "1"
---

# Skill: Data-Quality-Aware Reasoning

## Goal

A Tool call succeeding (a real result came back) is not the same claim as
the result being trustworthy. Applies equally when choosing the next
investigation (Planner) and when interpreting what a round's evidence
means (Reflector) -- weigh evidence quality before leaning on it, using
whatever structured Limitations are already present in context, never by
trying to fix or second-guess the data itself.

## Guidance

- **Check for recorded Limitations before treating a result as settled
  evidence.** A `NO_DATA`, `INSUFFICIENT_HISTORY`, `PARTIAL_SOURCE_OVERLAP`,
  `DATASOURCE_UNAVAILABLE`, or validation-derived Limitation (invalid
  value range, negative quantity, scope mismatch, potential truncation,
  suspected duplicate, staleness) attached to the current or a prior
  round's evidence describes exactly what's uncertain about that
  evidence -- read it before concluding.
- **An excluded/invalid record is gone from the calculation, not a
  "weaker version" of the calculation.** If a Tool result's own
  `usable_record_count` is lower than its raw record count, the reported
  figures already reflect ONLY the usable subset -- do not mentally
  "add back" the excluded portion.
- **Partial coverage lowers confidence, it does not invalidate the whole
  result.** A trend computed from 3 of 7 requested days can still be
  reported -- just report it as based on 3 observed days, not silently
  as if it were a full 7-day trend.
- **A Limitation and a Finding can coexist.** The presence of a data-
  quality Limitation does not mean "no conclusion is possible" -- it
  means "this specific gap should be stated alongside whatever
  conclusion the remaining, usable evidence actually supports."
- **Never propose fixing, correcting, or reinterpreting the raw data.**
  Negative quantities are not "probably meant to be positive," an
  out-of-range percentage is not "probably a typo for X" -- the
  deterministic validation layer already made the correct, conservative
  call (exclude and report); the Planner's job is to reason with what
  remains usable, not to second-guess the exclusion.
- If a data-quality gap makes the CORE question genuinely unanswerable
  (e.g. the only relevant evidence is fully invalid or entirely absent),
  say so plainly rather than reaching for a weaker signal to paper over
  it.

## Example

An OEE record for the requested plant/date exists but has `oee=180`
(outside the valid 0-100 range) -- the Tool already excluded it and
attached an `invalid_value_range` Limitation. Correct reasoning: "OEE
data was returned but failed validation; the requested abnormality
cannot be confirmed or rejected from this record." Incorrect reasoning:
"OEE was 180%, which is unusually strong" -- treating an excluded,
untrustworthy value as if it were real evidence.
