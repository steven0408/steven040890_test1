---
skill_id: reasoning.wb_manufacturing_flow_reasoning
name: WB Manufacturing Flow Reasoning
description: Mental model of the WB material/production flow (BANK -> ISSUE -> WIP -> OUTPUT, with OEE as a parallel equipment signal) for prioritizing which unexplored capability is most likely to explain a symptom.
category: mental_model
input_contract: PlannerContext
output_contract: guidance text (no structured output -- pure judgment framing)
skill_type: reasoning
applicable_nodes: [planner]
domains: [wb]
task_types: [analysis, rca]
roles: []
version: "1"
---

# Skill: WB Manufacturing Flow Reasoning

## Goal

Give the Planner a mental model of how WB's four data sources relate to
each other, so it can prioritize which unexplored capability is most
likely to explain a given symptom -- not a fixed step order to execute.

## Guidance

- The material/production flow is BANK (inventory not yet issued) ->
  ISSUE (material released into production) -> WIP (lots moving through
  operations, including Hold) -> OUTPUT (completed output at an
  operation). OEE is a PARALLEL equipment/utilization signal, not part of
  this chain -- a low OEE reflects machine-side loss, not a
  material-flow constraint.
- **Process ordering is a hint about WHERE to look next, never a causal
  proof.** A plant being low on ISSUE is *consistent with* downstream
  starvation reaching OUTPUT, but "low ISSUE" and "low OUTPUT happening
  at the same time" is a temporal/positional observation, not a
  demonstrated cause -- see the causal-inference-guard reasoning skill
  for the full distinction.
- When OUTPUT is low, the upstream-vs-equipment-vs-flow question is
  genuinely open until evidence narrows it: a material/loading
  constraint (BANK/ISSUE), a flow blockage (WIP Hold), and an
  equipment-utilization loss (OEE) are three DIFFERENT mechanisms that
  can each independently produce the same symptom -- do not assume one
  over the others without checking.
- Use whatever evidence is already gathered to prioritize the most
  plausible UNEXPLORED path, not a fixed BANK-then-WIP-then-OEE order --
  if BANK is already confirmed abnormal with a strong signal, checking
  WIP/OEE too may still be worthwhile if the budget allows, but is lower
  priority than confirming/rejecting alternative explanations that
  remain genuinely open.
- A normal reading on one candidate mechanism genuinely weakens that
  hypothesis -- move on to the next plausible one rather than persisting
  with a mechanism the evidence doesn't support.

## Example

Output is confirmed low. BANK shows elevated material shortage. This is
consistent with an upstream material constraint, but does not by itself
rule out a flow blockage (WIP Hold) or equipment loss (OEE) also
contributing -- if evidence for those is cheap to gather within budget,
it may still be worth a look before treating BANK shortage as the best-
supported explanation.
