---
skill_id: reasoning.alternative_hypothesis_reasoning
name: Alternative Hypothesis Reasoning
description: When and how to consider a second plausible explanation instead of committing to the first one that looks reasonable -- budget-aware, not "check every capability."
category: mental_model
input_contract: PlannerContext
output_contract: guidance text (no structured output -- pure judgment framing)
skill_type: reasoning
applicable_nodes: [planner]
domains: [wb]
task_types: [rca]
roles: []
version: "1"
---

# Skill: Alternative Hypothesis Reasoning

## Goal

Guard against anchoring on the first plausible-looking explanation when
the evidence for it is weak, conflicting, or when more than one
mechanism could equally explain the symptom -- while staying
budget-aware, not exhaustively checking every capability "just in case."

## Guidance

- **Consider an alternative when:**
  - the evidence for the current leading candidate is weak (e.g. a
    trend just barely crosses the abnormal threshold, or coverage is
    thin),
  - two or more candidate mechanisms are evidentially plausible and not
    yet distinguished,
  - a piece of evidence conflicts with the current leading candidate
    (e.g. a contributing factor comes back normal after looking
    promising from indirect signals).
- **Do not consider an alternative when:**
  - the current evidence already clearly and strongly supports one
    explanation,
  - the remaining budget is tight and the unexplored alternative's
    expected information gain is low,
  - every plausible mechanism has already been checked.
- **Budget-aware, not exhaustive.** Checking one well-chosen alternative
  capability when genuinely warranted is good practice; checking every
  remaining capability "to be thorough" when the leading candidate is
  already well-supported wastes budget the run may need elsewhere.
- **A rejected hypothesis is still useful.** If an alternative comes back
  normal, that is real evidence narrowing the explanation space -- report
  it as "X was checked and found normal, weakening that explanation," not
  as if the check never happened.
- Prefer the manufacturing-flow reasoning skill's own upstream/flow/
  equipment framing to decide WHICH alternative is worth considering
  first, rather than an arbitrary or exhaustive order.

## Example

BANK shows a mild, borderline shortage signal (just above the elevated
threshold) as the only checked contributing factor for a low-Output
symptom. Given the borderline strength, checking WIP Hold next (a
cheap, single-round check) before committing to "material shortage" as
the best-supported explanation is reasonable. Checking OEE as well,
after WIP also comes back unremarkable and BANK's own signal already
looks like the clear best explanation, would likely not be worth the
additional budget.
