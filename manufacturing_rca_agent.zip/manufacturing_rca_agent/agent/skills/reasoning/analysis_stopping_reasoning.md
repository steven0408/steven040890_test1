---
skill_id: reasoning.analysis_stopping_reasoning
name: Analysis Stopping Reasoning
description: When to stop investigating vs. continue -- goal sufficiently answered, low expected information gain, or uncertainty already captured as a Limitation, vs. an unsupported key claim, an unexplored high-relevance path, or materially conflicting evidence.
category: mental_model
input_contract: PlannerContext
output_contract: guidance text (no structured output -- pure judgment framing)
skill_type: reasoning
applicable_nodes: [planner]
domains: [wb]
task_types: [analysis, rca]
roles: []
version: "1"
---

# Skill: Analysis Stopping Reasoning

## Goal

Guide the decision of whether to propose another Objective or treat the
current evidence as sufficient -- a judgment call, not a fixed round
count.

## Guidance

- **Stop when:**
  - the goal is already sufficiently answered by the evidence gathered
    so far,
  - a further capability's expected information gain is low relative to
    what it would cost (budget, additional round),
  - remaining uncertainty is real but already explicitly captured as a
    Limitation -- an honest "we don't know X, and here's why" is itself
    a complete, defensible answer, not a reason to keep searching.
- **Continue when:**
  - a key claim the answer depends on is not yet supported by evidence,
  - an unexplored capability exists that is clearly relevant and
    affordable within the remaining budget,
  - evidence gathered so far materially conflicts (e.g. a symptom
    check and a contributing-factor check point in different
    directions) and that conflict hasn't been addressed.
- Do not equate "more rounds" with "more rigor." A well-supported
  one-round or two-round answer is not worse than a five-round answer
  that padded out low-value checks -- efficiency is part of the quality
  bar, not a tradeoff against it.
- When budget is genuinely nearly exhausted, prefer stopping with an
  honest partial answer (Finding + Limitation) over rushing a weak final
  round that doesn't meaningfully change the conclusion.

## Example

Output confirmed low; BANK shows a strong, clear material-shortage
signal; WIP and OEE both checked and normal. The leading explanation is
well-supported and the two most plausible alternatives have already been
ruled out -- this is a reasonable point to stop, even though ISSUE and
historical trend capabilities remain technically unexplored, since their
expected additional information gain is now low relative to the
already-clear picture.
