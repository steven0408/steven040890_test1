---
skill_id: reasoning.historical_recurrence_reasoning
name: Historical Recurrence Reasoning
description: How to distinguish an isolated event from a recurring, persistent, worsening, or recovering pattern using observed_days/recurrence_count/consecutive_abnormal_days/persistence_ratio -- and why a missing day is never a normal day.
category: mental_model
input_contract: PlannerContext
output_contract: guidance text (no structured output -- pure judgment framing)
skill_type: reasoning
applicable_nodes: [planner]
domains: [wb]
task_types: [analysis, rca]
roles: []
version: "1"
---

# Skill: Historical Recurrence Reasoning

## Goal

Teach the Planner to read a historical trend result's own structured
fields as a shape, not a single number -- so it can tell an isolated
event apart from a recurring, persistent, worsening, or recovering
pattern, and know when the available history is simply too thin to say
either way.

## Guidance

- **`observed_days` is the real number of days with usable data, never
  the requested window length.** A 7-day window with `observed_days=3`
  means only 3 days actually have trustworthy evidence -- treat any
  conclusion built on it as correspondingly weaker, and prefer widening
  the window or being explicit about the limitation over treating 3 days
  as if they were 7.
- **A missing or invalid day is never a normal day.** It is simply
  absent from the count -- it must never be read as "no abnormality that
  day" and must never silently lower `persistence_ratio`'s denominator
  in a way that looks like more days were actually observed than were.
- Distinguish these shapes using the actual fields, not intuition:
  - **Isolated**: `recurrence_count` is 1 (or `consecutive_abnormal_days
    <= 1` and `recurrence_count <= 1`) -- a single-day event.
  - **Recurring but not persistent**: `recurrence_count` is several, but
    `consecutive_abnormal_days` is low -- abnormal on scattered days, not
    a continuous run.
  - **Persistent**: `consecutive_abnormal_days` is close to
    `recurrence_count` and both are multi-day -- a continuous run
    reaching up to the current date.
  - **Worsening vs. recovering**: compare where in the window the
    abnormal days cluster -- concentrated near the current date suggests
    worsening; concentrated earlier with recent normal days suggests
    recovery, even if `recurrence_count` alone looks the same.
  - **Insufficient coverage**: `trend_direction=INSUFFICIENT_DATA` (or,
    for ISSUE's own result shape, `UNKNOWN`) means there is no reliable
    baseline to compare against at all -- report this honestly rather
    than picking a direction.
- `recurrence_count` reflects the ACTUAL historical data, never how many
  times an Objective happened to be dispatched -- a capability queried
  once can still reveal a recurrence count of 4 from that one query's own
  daily series.

## Example

ASE03's WIP Hold ratio: `recurrence_count=4`, `consecutive_abnormal_days=1`,
`observed_days=7`. This is a RECURRING-but-not-persistent pattern (Hold
elevated on 4 of 7 days, but not a continuous run) -- worth reporting as
"has recurred repeatedly this week," not "has been continuously elevated
this week," which would overstate the persistent-run shape the data
doesn't actually show.
