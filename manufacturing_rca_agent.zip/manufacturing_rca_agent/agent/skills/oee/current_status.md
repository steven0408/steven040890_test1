---
skill_id: oee.current_status
name: Current OEE Status
description: Report current OEE status -- average across all equipment and the single worst performer.
domains: [oee]
category: information
required_tools: [query_oee_data, aggregate_oee_status]
optional_tools: []
steps:
  - tool_id: query_oee_data
    parameter_mapping: {}
  - tool_id: aggregate_oee_status
    parameter_mapping: {}
input_contract: OEEQueryInput
output_contract: CurrentOEEStatus
risk_level: low
version: "1"
task_types: [information]
actions: [summarize]
capability_key: oee.current_status
expected_target_ref_type: module
---

# Skill: Current OEE Status

## Goal

Answer "what is OEE right now" without screening for abnormal equipment or
investigating root cause -- a single INFORMATION-tier round.

## Procedure

1. Call `query_oee_data` to fetch A/P/Q/OEE for every equipment.
2. Call `aggregate_oee_status` to compute the average OEE and identify the
   single worst-performing equipment.

## Preferred Tools

query_oee_data, aggregate_oee_status

## Fallback

If `query_oee_data` returns DATA_NOT_FOUND, no fallback source exists at
this skill level -- Module Planner decides whether to retry, skip, or stop.

## Output Contract

CurrentOEEStatus (agent.domain.oee.dataset)
