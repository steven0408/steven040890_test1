---
skill_id: oee.rca_screening
name: RCA Screening Query
description: Fetch raw A/P/Q/OEE for every equipment, for OEEPlanningPolicy's own screen/group/rank logic.
domains: [oee]
category: query
required_tools: [query_oee_data]
optional_tools: []
steps:
  - tool_id: query_oee_data
    parameter_mapping: {}
input_contract: OEEQueryInput
output_contract: ScreeningResult
risk_level: low
version: "1"
task_types: [rca]
actions: [screen]
capability_key: oee.equipment_screening
expected_target_ref_type: module
---

# Skill: RCA Screening Query

## Goal

A single-step wrapper around `query_oee_data` for the RCA TaskType: unlike
`oee.equipment_screening` (ANALYSIS TaskType), this Skill does NOT filter,
score, or rank -- `OEEPlanningPolicy` does its own screening/grouping/
contribution-ranking directly against the raw `ScreeningResult`, exactly as
it did before the Phase 5B-2 capability layer existed. This Skill exists so
that path can still be routed through
`CapabilityResolver -> SkillRunner -> ToolExecutionManager -> ToolRegistry`
without changing what evidence ends up in ModuleState.

## Procedure

1. Call `query_oee_data` to fetch A/P/Q/OEE for every equipment (raw,
   unfiltered).

## Output Contract

ScreeningResult (agent.domain.oee.dataset) -- same shape `OEEDataTool`
(the pre-5B-2 direct-tool path) has always produced for "screen_equipment".
