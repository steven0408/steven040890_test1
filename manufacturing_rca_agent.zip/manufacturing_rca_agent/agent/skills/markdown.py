"""Skill markdown parser (Phase 5B-1): YAML frontmatter + narrative body,
single source of truth -- no second hand-maintained copy of `steps`
anywhere. See agent/skills/oee/equipment_screening.md for a real example.
"""
import re

import yaml

from agent.skills.models import SkillDefinition

_FRONTMATTER_PATTERN = re.compile(r"\A---\s*\n(.*?)\n---\s*\n?(.*)\Z", re.DOTALL)


class SkillMarkdownError(ValueError):
    pass


def parse_skill_markdown(text: str) -> tuple[SkillDefinition, str]:
    """Parses a Skill markdown file.

    Returns (SkillDefinition, body) where `body` is the narrative text
    (Goal/Explanation/Procedure/Constraints/Examples) -- kept as plain text
    for humans and for LLM context, never re-parsed back into structured
    fields. The frontmatter is the only structured source of truth.
    """
    match = _FRONTMATTER_PATTERN.match(text)
    if not match:
        raise SkillMarkdownError("skill markdown must start with a '---' delimited YAML frontmatter block")

    frontmatter_text, body = match.group(1), match.group(2)
    try:
        raw = yaml.safe_load(frontmatter_text)
    except yaml.YAMLError as exc:
        raise SkillMarkdownError(f"invalid YAML frontmatter: {exc}") from exc

    if not isinstance(raw, dict):
        raise SkillMarkdownError("frontmatter must be a YAML mapping")

    definition = SkillDefinition.model_validate(raw)
    return definition, body.strip()
