from pydantic import Field

from agent.state.base import RCABaseModel
from agent.state.enums import TreeNodeStatus, TreeNodeType


class AnalysisTreeNode(RCABaseModel):
    node_id: str
    parent_id: str | None = None
    label: str
    node_type: TreeNodeType
    status: TreeNodeStatus = TreeNodeStatus.PENDING
    entity_refs: list[str] = Field(default_factory=list)
    evidence_refs: list[str] = Field(default_factory=list)
    created_by_objective_id: str | None = None
    children_ids: list[str] = Field(default_factory=list)


class AnalysisTree(RCABaseModel):
    root_id: str
    nodes: dict[str, AnalysisTreeNode] = Field(default_factory=dict)

    def add_node(self, node: AnalysisTreeNode) -> None:
        if node.node_id in self.nodes:
            raise ValueError(f"node '{node.node_id}' already exists")
        if node.parent_id is not None and node.parent_id not in self.nodes:
            raise ValueError(f"parent '{node.parent_id}' not found")
        self.nodes[node.node_id] = node
        if node.parent_id is not None:
            parent = self.nodes[node.parent_id]
            if node.node_id not in parent.children_ids:
                parent.children_ids.append(node.node_id)

    def get(self, node_id: str) -> AnalysisTreeNode:
        return self.nodes[node_id]

    def children_of(self, node_id: str) -> list[AnalysisTreeNode]:
        return [self.nodes[child_id] for child_id in self.nodes[node_id].children_ids]

    def set_status(self, node_id: str, status: TreeNodeStatus) -> None:
        self.nodes[node_id].status = status

    def merge_nodes(
        self,
        node_ids: list[str],
        into_label: str,
        new_node_id: str,
        node_type: TreeNodeType = TreeNodeType.ENTITY_GROUP,
    ) -> AnalysisTreeNode:
        """Group sibling nodes under a new node, reparenting them as its children.

        All `node_ids` must currently share the same parent. Used e.g. to
        collapse EQ001/EQ003 (both showing "Equipment Failure") under one
        group node instead of analyzing the same pattern twice.
        """
        if not node_ids:
            raise ValueError("merge_nodes requires at least one node_id")

        parent_ids = {self.nodes[n].parent_id for n in node_ids}
        if len(parent_ids) != 1:
            raise ValueError("merge_nodes requires all nodes to share the same parent")
        parent_id = next(iter(parent_ids))
        if parent_id is None:
            raise ValueError("merge_nodes cannot merge root-level nodes")

        group_node = AnalysisTreeNode(
            node_id=new_node_id,
            parent_id=parent_id,
            label=into_label,
            node_type=node_type,
            status=TreeNodeStatus.PENDING,
        )
        self.add_node(group_node)

        parent = self.nodes[parent_id]
        for n in node_ids:
            parent.children_ids.remove(n)
            self.nodes[n].parent_id = new_node_id
            group_node.children_ids.append(n)
            group_node.entity_refs.extend(self.nodes[n].entity_refs or [n])

        return group_node
