"""WB canonical domain data contracts -- the ONLY shape any Tool/Agent
code (once built, in a later phase) is ever allowed to see. Four
independent record types, one per real WB data source, deliberately kept
at their own native grain rather than forced into a shared shape (see
`docs/wb_data_layer.md` section "Grain differences" -- OEE/OUTPUT are
Date x Plant x Operation[x Product], BANK is Snapshot x Plant x Mother
Batch x Product, WIP is Snapshot x Child Lot x Operation).

Every field with an explicitly UNKNOWN business meaning (see
`docs/wb_data_layer.md`'s "Unknown fields" table) is still typed and
carried through -- the raw value is never dropped -- but its docstring
says UNKNOWN, not a guessed meaning, and nothing in this codebase (this
phase or any future one, until a human supplies a real definition) may
use it to justify an RCA conclusion.
"""
from datetime import date, datetime
from enum import Enum

from agent.state.base import RCABaseModel


class WBBankStatus(str, Enum):
    """Canonicalized from the raw `status` string (`agent/domain/wb/mappings.py::
    resolve_bank_status`). `UNKNOWN` is a real, expected value -- an
    unrecognized raw status is never silently mapped to one of the three
    known members."""

    READY_TO_ISSUE = "ready_to_issue"
    MATERIAL_SHORTAGE = "material_shortage"
    NO_WAFER_IN = "no_wafer_in"
    UNKNOWN = "unknown"


class WBLotStatus(str, Enum):
    """Canonicalized from WIP's raw `STATUS` string. Only `Active`/`Hold`
    are documented; `UNKNOWN` covers anything else without guessing."""

    ACTIVE = "active"
    HOLD = "hold"
    UNKNOWN = "unknown"


class WBSiteGroup(str, Enum):
    """Broad plant-area grouping from BANK's raw `site` field (A1 ->
    ASE01/02/03, A2 -> ASE07/08). `UNKNOWN` for any value not in that
    documented set -- the raw string is preserved separately
    (`WBBankRecord.site_group_raw`), never discarded."""

    A1 = "a1"
    A2 = "a2"
    UNKNOWN = "unknown"


class WBPlantOEERecord(RCABaseModel):
    """Source: `GET /api/wb/oeedata` (`agent/domain/wb/remote.py::RemoteWBPlantOEEDataSource`).
    Grain: production_date x plant_id x operation_id. Updates daily at
    08:30 (usually yesterday's data) -- see `WB_PLANT_OEE_FRESHNESS`.
    """

    production_date: date
    plant_id: str
    operation_id: str
    oee: float | None
    productive_ratio: float | None
    downtime_ratio: float | None
    pm_ratio: float | None
    setup_ratio: float | None
    idle_ratio: float | None
    # UNKNOWN business meaning (raw "ENG") -- value preserved, never
    # interpreted. See docs/wb_data_layer.md.
    engineering_ratio: float | None
    # UNKNOWN business meaning (raw "TS") -- value preserved, never
    # interpreted.
    ts_ratio: float | None
    source_sync_time: datetime


class WBBankRecord(RCABaseModel):
    """Source: `GET /api/wb/bank`. Grain: snapshot x plant_id x
    mother_batch_id x product (device/package/lead_count combination).
    Updates every 2 hours on the even hour (`xx:40`) -- see
    `WB_BANK_FRESHNESS`. Represents inventory NOT yet issued into
    production flow (see docs/wb_data_layer.md's BANK -> WIP -> OUTPUT
    chain)."""

    plant_id: str
    site_group: WBSiteGroup
    site_group_raw: str
    mother_batch_id: str
    customer_code: str | None
    customer_sub_code: str | None
    customer_group: str | None
    device: str | None
    package_code: str | None
    lead_count: str | None
    wafer_size_inch: str | None
    wafer_quantity: int | None
    die_quantity: int | None
    bank_status: WBBankStatus
    bank_status_raw: str
    bank_entry_time: datetime | None
    description: str | None
    # UNKNOWN business meaning (raw "run_type") -- value preserved.
    run_type: str | None
    # UNKNOWN business meaning (raw "cust_runtype") -- value preserved.
    customer_run_type: str | None
    # UNKNOWN business meaning (raw "uom") -- value preserved.
    unit_of_measure: str | None
    source_sync_time: datetime


class WBWIPRecord(RCABaseModel):
    """Source: `GET /api/wb/wip`. Grain: snapshot x child_batch_id x
    operation_id. Updates every 2 hours on the odd hour (`xx:30`) -- see
    `WB_WIP_FRESHNESS`. Represents lots already issued into production
    flow, currently moving through operations."""

    plant_id: str
    facility_source: str | None
    mother_batch_id: str
    child_batch_id: str
    operation_id: str
    current_quantity: int | None
    customer_code: str | None
    package_code: str | None
    lead_count: str | None
    # UNKNOWN business meaning (raw "RUN_TYPE") -- value preserved.
    run_type: str | None
    lot_status: WBLotStatus
    lot_status_raw: str
    source_sync_time: datetime


class WBStageOutputRecord(RCABaseModel):
    """Source: `GET /api/wb/output_rawdata`. Grain: production_date x
    plant_id x location x operation_id x product (device_type/package/
    lead_count). Updates daily at 08:30 -- see `WB_STAGE_OUTPUT_FRESHNESS`.
    Represents completed output at one operation."""

    production_date: date
    plant_id: str
    location: str | None
    operation_id: str
    output_quantity: int | None
    customer_code: str | None
    device_type: str | None
    package_code: str | None
    lead_count: str | None
    # UNKNOWN business meaning (raw "TT_BOND_DIAG") -- value preserved.
    bond_diagram: str | None
    # UNKNOWN business meaning (raw "SUP_FAC") -- value preserved.
    source_facility: str | None
    source_sync_time: datetime


class WBIssueRecord(RCABaseModel):
    """Source: `GET /api/wb/issue` (Phase WB-3A). Grain (item I): one
    source ISSUE record -- available dimensions are plant x schedule
    (mother batch) x customer x device/package x release date/time.
    Cannot prove one row is a unique release EVENT (no row-level id field
    is documented) -- deliberately described only as "one source ISSUE
    record", never claimed as event-unique.

    `release_date`/`release_time` (raw `rel_date`/`rel_time`) is the
    business date/time this material was actually released/issued --
    NEVER the same thing as `source_sync_time` (raw `SYNC_TIME`, when this
    row was written/synced to the DB). The real Flask endpoint's own
    `date` query parameter filters `SYNC_TIME`, not `rel_date` (see
    `agent/domain/wb/remote.py::RemoteWBIssueDataSource`'s own docstring)
    -- this canonical model keeps the two fields, and their meanings,
    completely separate so nothing downstream can conflate them.
    """

    source_sync_time: datetime
    plant_id: str
    site: str | None
    schedule: str | None
    customer_code: str | None
    customer_name: str | None
    device_type: str | None
    issue_quantity: int | None
    lead_count: str | None
    package_code: str | None
    package_type: str | None
    region: str | None
    # `rel_date` -- tolerant-parsed to `date` when the raw string is
    # unambiguously `YYYY-MM-DD`-shaped; `None` if absent. If a future
    # sample shows a different/unreliable format, `release_date_raw` is
    # still always preserved verbatim so nothing is silently lost (item H).
    release_date: date | None
    release_date_raw: str | None
    release_time: str | None
    release_system: str | None  # raw "rel_sys" -- "該產品投料系統"
    time_bucket: str | None  # raw "time": "AM"/"PM"
    wafer_inch: str | None
    year: str | None
    # UNKNOWN business meaning (see docs/wb_data_layer.md's Unknown
    # fields table) -- raw values preserved, never interpreted, never
    # used for any causal/RCA reasoning (item G).
    bd_no_unknown: str | None
    cu_flag_unknown: str | None
    customer_run_type_unknown: str | None
    customer_sod_unknown: str | None
    internal_sod_unknown: str | None
    routid_unknown: str | None
    run_type_unknown: str | None
    unit_of_measure_unknown: str | None
    user_id_unknown: str | None
    user_name_unknown: str | None


class WBSourceName(str, Enum):
    PLANT_OEE = "wb_plant_oee"
    BANK = "wb_bank"
    WIP = "wb_wip"
    STAGE_OUTPUT = "wb_stage_output"
    ISSUE = "wb_issue"


class WBUpdateFrequency(str, Enum):
    """The two distinct update rhythms real WB sources actually use --
    see docs/wb_data_layer.md's "Snapshot semantics" section. Never
    conflated: a daily-like source has a real `production_date` distinct
    from `source_sync_time`; a snapshot source has only `source_sync_time`
    (there is no separate "production date" concept for BANK/WIP)."""

    DAILY = "daily"
    EVERY_TWO_HOURS_EVEN = "every_two_hours_even"  # BANK: 00:40, 02:40, ...
    EVERY_TWO_HOURS_ODD = "every_two_hours_odd"  # WIP: 01:30, 03:30, ...


class DataFreshness(RCABaseModel):
    """Source-level (not record-level) metadata -- describes HOW a WB
    source updates, not any one record's own timestamps. Each DataSource
    exposes its own constant instance via a `freshness()` method (Part 7's
    minimal-contract choice over embedding this on every record)."""

    source_name: WBSourceName
    update_frequency: WBUpdateFrequency
    typical_sync_times: tuple[str, ...]
    is_snapshot: bool  # True: BANK/WIP (no real production_date). False: OEE/OUTPUT (daily-like, real production_date).
    notes: str = ""


WB_PLANT_OEE_FRESHNESS = DataFreshness(
    source_name=WBSourceName.PLANT_OEE, update_frequency=WBUpdateFrequency.DAILY,
    typical_sync_times=("08:30",), is_snapshot=False,
    notes="Daily at 08:30, usually reflects yesterday's production_date.",
)
WB_BANK_FRESHNESS = DataFreshness(
    source_name=WBSourceName.BANK, update_frequency=WBUpdateFrequency.EVERY_TWO_HOURS_EVEN,
    typical_sync_times=("00:40", "02:40", "04:40", "06:40", "08:40", "10:40", "12:40", "14:40", "16:40", "18:40", "20:40", "22:40"),
    is_snapshot=True, notes="Snapshot dataset -- no separate production_date, source_sync_time IS the effective time.",
)
WB_WIP_FRESHNESS = DataFreshness(
    source_name=WBSourceName.WIP, update_frequency=WBUpdateFrequency.EVERY_TWO_HOURS_ODD,
    typical_sync_times=("01:30", "03:30", "05:30", "07:30", "09:30", "11:30", "13:30", "15:30", "17:30", "19:30", "21:30", "23:30"),
    is_snapshot=True, notes="Snapshot dataset -- no separate production_date, source_sync_time IS the effective time.",
)
WB_STAGE_OUTPUT_FRESHNESS = DataFreshness(
    source_name=WBSourceName.STAGE_OUTPUT, update_frequency=WBUpdateFrequency.DAILY,
    typical_sync_times=("08:30",), is_snapshot=False,
    notes="Daily at 08:30, has its own DATA_DATE distinct from source_sync_time.",
)
WB_ISSUE_FRESHNESS = DataFreshness(
    source_name=WBSourceName.ISSUE, update_frequency=WBUpdateFrequency.DAILY,
    typical_sync_times=("08:40",), is_snapshot=False,
    # Phase WB-3A item K's decision: `is_snapshot=False`, same category as
    # OEE/OUTPUT, NOT BANK/WIP -- an ISSUE record carries its own real
    # business date (`release_date`, raw `rel_date`) distinct from
    # `source_sync_time`, exactly the distinguishing trait `is_snapshot`
    # exists to capture (see WBUpdateFrequency's own docstring). It is a
    # "release-event dataset synchronized daily", not a snapshot-of-
    # current-state dataset like BANK/WIP (which have no comparable
    # business-date field at all).
    notes="Daily at 08:40. Release-event dataset with its own release_date, distinct from source_sync_time -- NOT a state snapshot like BANK/WIP.",
)
