"""WB Plant/site/operation code resolution -- lives in the DataSource/
normalization layer, deliberately NOT in a Planner prompt or generic
AgentState (per this phase's explicit instruction). `ObjectiveAction`/
`AgentState`/`ModuleState` never see a raw plant code like `"A01001"`
or a bracketed placeholder like `"[FAB_A]"` -- by the time any canonical
`WB*Record` exists, `plant_id` has already been resolved through here.

Every resolver in this module follows the same rule (item 6/9's "explicit,
never silently reinterpreted"): a *known* raw value maps to its canonical
form; an *unknown* raw value is returned unchanged, never guessed at or
coerced to the nearest known value. Callers that need to tell the two
cases apart use the paired `is_known_*` predicate.
"""
from agent.domain.wb.models import WBBankStatus, WBLotStatus, WBSiteGroup

# WB BU currently has 5 Plants (item 0). Keys are the raw source-system
# plant codes seen in BANK's `plant`/`plant_1` fields; values are the
# canonical ASE0x codes used everywhere else (OEE's `PLANT`, WIP's
# `PLANT`/`FACILITY_SOURCE`, OUTPUT's `FAC`).
PLANT_ID_MAP: dict[str, str] = {
    "A01001": "ASE01",
    "A01002": "ASE02",
    "A01003": "ASE03",
    "A01007": "ASE07",
    "A01008": "ASE08",
}

KNOWN_PLANT_IDS: frozenset[str] = frozenset(PLANT_ID_MAP.values())

# Broad plant-area grouping (BANK's raw `site` field is already this
# code, e.g. "A1" -- this is NOT derived from plant_id, it's a second,
# independently-reported grouping in the source data).
SITE_GROUP_PLANTS: dict[str, frozenset[str]] = {
    "A1": frozenset({"ASE01", "ASE02", "ASE03"}),
    "A2": frozenset({"ASE07", "ASE08"}),
}

# Known WB operations (item 0). `operation_id` itself stays a raw string
# on every canonical record (real data may contain operation codes beyond
# these two, e.g. the OEE sample response's "1000"/"2000") -- this is a
# label lookup for human-readable display only, never a closed enum.
OPERATION_LABELS: dict[str, str] = {
    "2600": "DA",
    "2800": "WB",
}

_BANK_STATUS_MAP: dict[str, WBBankStatus] = {
    "Ready To Issue": WBBankStatus.READY_TO_ISSUE,
    "MTL Shortage": WBBankStatus.MATERIAL_SHORTAGE,
    "No Wafer In": WBBankStatus.NO_WAFER_IN,
}

_LOT_STATUS_MAP: dict[str, WBLotStatus] = {
    "Active": WBLotStatus.ACTIVE,
    "Hold": WBLotStatus.HOLD,
}


def resolve_plant_id(raw: str) -> str:
    """Maps a raw source plant code (e.g. `"A01001"`) to its canonical
    ASE0x form. A value that's already canonical (e.g. `"ASE01"`, as OEE/
    WIP/OUTPUT's own `PLANT`/`FACILITY_SOURCE`/`FAC` fields already report
    it) passes through unchanged. An unrecognized value (e.g. a bracketed
    placeholder like `"[FAB_A]"`) is ALSO returned unchanged -- never
    guessed at -- so `is_known_plant_id` is the only reliable way to tell
    "known" from "unknown"."""
    if raw in KNOWN_PLANT_IDS:
        return raw
    return PLANT_ID_MAP.get(raw, raw)


def is_known_plant_id(plant_id: str) -> bool:
    return plant_id in KNOWN_PLANT_IDS


def resolve_site_group(raw_site: str | None) -> tuple[WBSiteGroup, str]:
    """Returns `(canonical_enum, original_raw_string)` -- the raw value is
    always preserved (`WBBankRecord.site_group_raw`) even when the
    canonical side is `UNKNOWN`, per item 6's "do not silently reinterpret
    unknown values" rule."""
    if raw_site is None:
        return WBSiteGroup.UNKNOWN, ""
    normalized = raw_site.strip().upper()
    if normalized == "A1":
        return WBSiteGroup.A1, raw_site
    if normalized == "A2":
        return WBSiteGroup.A2, raw_site
    return WBSiteGroup.UNKNOWN, raw_site


def operation_label(operation_id: str) -> str | None:
    """`None` for an operation code with no known label -- never a guess."""
    return OPERATION_LABELS.get(str(operation_id))


def resolve_bank_status(raw_status: str | None) -> tuple[WBBankStatus, str]:
    if raw_status is None:
        return WBBankStatus.UNKNOWN, ""
    return _BANK_STATUS_MAP.get(raw_status, WBBankStatus.UNKNOWN), raw_status


def resolve_lot_status(raw_status: str | None) -> tuple[WBLotStatus, str]:
    if raw_status is None:
        return WBLotStatus.UNKNOWN, ""
    return _LOT_STATUS_MAP.get(raw_status, WBLotStatus.UNKNOWN), raw_status
