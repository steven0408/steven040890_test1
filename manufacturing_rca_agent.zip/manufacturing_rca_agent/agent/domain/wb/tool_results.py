"""Typed WB Tool result models (Phase WB-2A item E). Deliberately NOT one
giant `WBToolResult` -- OEE/BANK/WIP/OUTPUT have genuinely different
output semantics (item E's own instruction), so each Tool gets its own
result shape. Every result shares two common building blocks so "what did
I query" and "can I trust this" never have to be re-invented per tool:

    WBQueryScope        -- what was asked for (filters actually applied)
    WBDataAvailability  -- record_count / is_empty / freshness / limitations

Registered explicitly (Phase 8A-1/WB-Data-Layer-V1's own discipline --
never at import time) via `register_wb_tool_result_payloads()`, called by
`agent/tools/wb/registration.py::register_wb_tools()`.
"""
from datetime import date, datetime
from enum import Enum

from agent.state.base import RCABaseModel
from agent.state.payload import PayloadRegistry
from agent.domain.wb.historical import WBHistoricalMetricSummary
from agent.domain.wb.models import (
    DataFreshness,
    WBBankRecord,
    WBBankStatus,
    WBIssueRecord,
    WBPlantOEERecord,
    WBStageOutputRecord,
    WBWIPRecord,
)
from agent.domain.wb.validation import WBValidationIssue

# ============================================================================
# Shared building blocks
# ============================================================================


class WBQueryScope(RCABaseModel):
    """What was actually asked for -- every filter a Tool call accepted,
    echoed back verbatim (never re-derived/guessed) so a caller can tell
    "zero rows because nothing matched this exact filter" from "zero rows
    because I misread the filter".
    """

    plant_id: str | None = None
    operation_id: str | None = None
    production_date: date | None = None
    snapshot_date: date | None = None
    latest_snapshot_only: bool | None = None  # BANK/WIP only -- item M's freeze
    status_filter: str | None = None
    customer_code: str | None = None
    package_code: str | None = None
    device: str | None = None
    device_type: str | None = None
    # ISSUE only (Phase WB-3A) -- kept as its OWN field, never aliased to
    # `production_date`: `release_date` is the business date the material
    # was actually released (raw `rel_date`), genuinely distinct from any
    # sync/snapshot timestamp (item V). A `start`/`end` pair is echoed
    # instead of a single date for the trend Tool's range query.
    release_date: date | None = None
    release_date_start: date | None = None
    release_date_end: date | None = None
    # Phase WB-3B -- historical/trend Tools echo the requested window as a
    # range, on the SAME business-date field their single-date Tools
    # already use (`production_date` for OEE/OUTPUT, `snapshot_date` for
    # BANK/WIP) -- never a third date concept.
    production_date_start: date | None = None
    production_date_end: date | None = None
    snapshot_date_start: date | None = None
    snapshot_date_end: date | None = None


class WBDataAvailability(RCABaseModel):
    """Item F/G: the explicit "can I trust this" contract every WB Tool
    result carries. `record_count == 0` (`is_empty=True`) is NEVER
    silently turned into a `0`/`None` metric upstream -- callers must read
    `is_empty` before trusting any aggregate field on the result.
    `latest_source_sync_time` is `None` only when `is_empty` is also
    `True` -- there is no timestamp to report when there is no data.

    Phase WB-3D: `validation_issues`/`usable_record_count` are additive,
    default empty/`None` -- `record_count`/`is_empty`'s own WB-2A meaning
    is NEVER redefined (item 32/33's own explicit warning): `record_count`
    always means "raw records returned from the DataSource", `is_empty`
    always means "record_count == 0". `usable_record_count` (only set when
    a Tool actually ran validation) is what distinguishes "no data"
    (`record_count == 0`) from "all-invalid data" (`record_count > 0` but
    `usable_record_count == 0`) -- two genuinely different situations that
    must never collapse into the same `is_empty=True` signal (item 33's
    own explicit regression concern)."""

    record_count: int
    is_empty: bool
    freshness: DataFreshness
    latest_source_sync_time: datetime | None = None
    limitations: list[str] = []
    validation_issues: list[WBValidationIssue] = []
    usable_record_count: int | None = None


def compute_availability(
    records: list, freshness: DataFreshness, *,
    limitations: list[str] | None = None,
    validation_issues: list[WBValidationIssue] | None = None,
    usable_record_count: int | None = None,
) -> WBDataAvailability:
    is_empty = len(records) == 0
    latest = None if is_empty else max(r.source_sync_time for r in records)
    return WBDataAvailability(
        record_count=len(records), is_empty=is_empty, freshness=freshness, latest_source_sync_time=latest,
        limitations=limitations or [], validation_issues=validation_issues or [], usable_record_count=usable_record_count,
    )


# ============================================================================
# A. OEE
# ============================================================================


class WBPlantOEEQueryResult(RCABaseModel):
    scope: WBQueryScope
    availability: WBDataAvailability
    records: list[WBPlantOEERecord]


class WBOEELossBreakdown(RCABaseModel):
    plant_id: str
    operation_id: str
    production_date: date
    oee: float | None
    downtime_ratio: float | None
    setup_ratio: float | None
    pm_ratio: float | None
    idle_ratio: float | None
    productive_ratio: float | None
    # Deterministic tie-break priority when two loss categories are equal:
    # downtime > setup > pm > idle (documented, fixed -- never randomized).
    dominant_loss_category: str | None
    dominant_loss_value: float | None


class WBOEELossAnalysisResult(RCABaseModel):
    scope: WBQueryScope
    availability: WBDataAvailability
    # Sorted worst (lowest OEE) first; `None` OEE values sort last. Tie-break:
    # plant_id then operation_id, ascending -- deterministic, never arbitrary.
    ranking: list[WBOEELossBreakdown]


# ============================================================================
# B. BANK
# ============================================================================


class WBBankQueryResult(RCABaseModel):
    scope: WBQueryScope
    availability: WBDataAvailability
    records: list[WBBankRecord]


class WBBankStatusCount(RCABaseModel):
    status: WBBankStatus
    count: int
    ratio: float  # count / total_count in scope; total_count == 0 is never reached here (see availability.is_empty)


class WBBankStatusSummaryResult(RCABaseModel):
    scope: WBQueryScope
    availability: WBDataAvailability
    total_count: int
    by_status: list[WBBankStatusCount]  # sorted by WBBankStatus enum value, deterministic
    by_plant: dict[str, int]  # plant_id -> record count, keys sorted
    by_package: dict[str, int]
    by_device: dict[str, int]


class WBBankAgingEntry(RCABaseModel):
    plant_id: str
    mother_batch_id: str
    bank_status: WBBankStatus
    aging_hours: float | None  # None when bank_entry_time is missing for this record


class WBBankAgingAnalysisResult(RCABaseModel):
    """Item M's own caution, honored directly: aging is only computed
    where `bank_entry_time` (raw `status_50`) is present -- a record
    missing it contributes to `records_with_unknown_aging`, never a
    guessed/zero aging value."""

    scope: WBQueryScope
    availability: WBDataAvailability
    records_with_known_aging: int
    records_with_unknown_aging: int
    average_aging_hours: float | None  # None if records_with_known_aging == 0
    max_aging_hours: float | None
    # Sorted descending by aging_hours, ties broken by mother_batch_id ascending.
    longest_aging_entries: list[WBBankAgingEntry]
    limitations: list[str] = []


# ============================================================================
# C. WIP
# ============================================================================


class WBWIPQueryResult(RCABaseModel):
    scope: WBQueryScope
    availability: WBDataAvailability
    records: list[WBWIPRecord]


class WBWIPSummaryResult(RCABaseModel):
    scope: WBQueryScope
    availability: WBDataAvailability
    total_quantity: int
    lot_count: int
    by_status: dict[str, int]  # WBLotStatus.value -> lot count, keys sorted
    by_operation: dict[str, int]  # operation_id -> lot count, keys sorted


class WBHoldAnalysisResult(RCABaseModel):
    """Descriptive only -- never a root-cause claim (item C3/J's explicit
    rule: `Hold -> equipment failure` or `Hold -> material shortage` is
    NOT this Tool's job)."""

    scope: WBQueryScope
    availability: WBDataAvailability
    total_lot_count: int
    hold_lot_count: int
    hold_quantity: int
    # `None` only when total_lot_count == 0 -- an empty denominator is
    # never silently reported as a 0.0 ratio (item L).
    hold_ratio: float | None
    by_operation: dict[str, int]  # operation_id -> hold lot count, keys sorted
    by_package: dict[str, int]
    by_customer: dict[str, int]


# ============================================================================
# D. OUTPUT
# ============================================================================


class WBStageOutputQueryResult(RCABaseModel):
    scope: WBQueryScope
    availability: WBDataAvailability
    records: list[WBStageOutputRecord]


class WBStageOutputSummaryResult(RCABaseModel):
    scope: WBQueryScope
    availability: WBDataAvailability
    total_output_quantity: int
    by_plant: dict[str, int]  # keys sorted
    by_operation: dict[str, int]
    by_product: dict[str, int]  # keyed by device_type, "UNKNOWN" for None


class WBStageOutputComparisonEntry(RCABaseModel):
    plant_id: str
    output_quantity: int


class WBStageOutputComparisonResult(RCABaseModel):
    scope: WBQueryScope
    availability: WBDataAvailability
    # Sorted descending by output_quantity, ties broken by plant_id ascending.
    comparison: list[WBStageOutputComparisonEntry]
    highest: WBStageOutputComparisonEntry | None
    lowest: WBStageOutputComparisonEntry | None


# ============================================================================
# E. ISSUE (Phase WB-3A)
# ============================================================================


class WBIssueQueryResult(RCABaseModel):
    scope: WBQueryScope
    availability: WBDataAvailability
    records: list[WBIssueRecord]


class WBIssueSummaryResult(RCABaseModel):
    scope: WBQueryScope
    availability: WBDataAvailability
    total_issue_quantity: int
    record_count: int
    by_plant: dict[str, int]  # plant_id -> total issue_quantity, keys sorted
    by_customer: dict[str, int]
    by_device: dict[str, int]  # keyed by device_type, "UNKNOWN" for None


class WBIssueTrendDailyPoint(RCABaseModel):
    release_date: date
    total_issue_quantity: int
    record_count: int


class WBIssueTrendDirection(str, Enum):
    """Deterministic classification only -- NEVER a causal claim (item Q/W:
    "low ISSUE caused low OUTPUT" is explicitly forbidden anywhere in this
    codebase). Purely describes the arithmetic relationship between the
    current-period and baseline-period totals."""

    UP = "up"
    DOWN = "down"
    FLAT = "flat"
    UNKNOWN = "unknown"  # baseline period had no data to compare against


class WBIssueTrendAnalysisResult(RCABaseModel):
    """Deterministic historical DESCRIPTIVE analysis only (item Q) --
    current-period total vs. baseline-period total/average, computed by
    splitting one `[start, end]` window into two sub-periods at a fixed,
    documented boundary (see `agent/tools/wb/issue_tools.py::AnalyzeWBIssueTrendTool`).
    No causal conclusion of any kind is ever attached to this result."""

    scope: WBQueryScope
    availability: WBDataAvailability
    current_period_start: date
    current_period_end: date
    current_period_total: int
    current_period_average_daily: float
    baseline_period_start: date | None
    baseline_period_end: date | None
    baseline_period_total: int | None
    baseline_period_average_daily: float | None
    # Both computed on the AVERAGE-DAILY figures (never raw totals) so a
    # current period of different length than the baseline period is
    # still a fair comparison.
    absolute_difference: float | None
    percentage_difference: float | None
    trend_direction: WBIssueTrendDirection
    daily_series: list[WBIssueTrendDailyPoint]  # sorted by release_date ascending
    # Phase WB-3B (item 8): additive fields only -- every field above is
    # UNCHANGED from Phase WB-3A for backward compatibility. Computed via
    # the shared `agent.domain.wb.historical.compute_historical_metrics`
    # (`current_date=scope.release_date_end`, baseline excludes it) --
    # note this is a genuinely different split than `current_period_days`
    # above (which allows a MULTI-day current period); these five fields
    # always describe the single latest day specifically.
    observed_days: int = 0
    abnormal_days: int = 0
    recurrence_count: int = 0
    persistence_ratio: float | None = None
    consecutive_abnormal_days: int = 0


# ============================================================================
# F. OEE historical trend (Phase WB-3B)
# ============================================================================


class WBOEETrendDailyPoint(RCABaseModel):
    production_date: date
    # The operation actually used to represent this day (item 9): equals
    # the requested `operation_id` when one was given, otherwise the
    # worst-OEE operation for this plant/day -- the SAME "worst row"
    # convention `AnalyzeWBOEELossTool`/`wb.oee_plant_status` already use,
    # never an invented weighted average across operations.
    operation_id: str
    oee: float | None


class WBOEETrendAnalysisResult(RCABaseModel):
    """Descriptive only. `metrics.trend_direction`/`recurrence_count`/etc.
    never imply a cause -- see `oee_is_abnormal` (fixed, documented
    threshold, mirrors Phase WB-2D's RCA threshold exactly)."""

    scope: WBQueryScope
    availability: WBDataAvailability
    metrics: WBHistoricalMetricSummary
    daily_series: list[WBOEETrendDailyPoint]  # sorted by production_date ascending
    limitations: list[str] = []


# ============================================================================
# G. WIP Hold historical trend (Phase WB-3B)
# ============================================================================


class WBWIPHoldTrendDailyPoint(RCABaseModel):
    snapshot_date: date
    hold_lot_count: int
    total_lot_count: int
    hold_ratio: float | None  # None when total_lot_count == 0 for that day -- never a fabricated 0.0


class WBWIPHoldTrendAnalysisResult(RCABaseModel):
    scope: WBQueryScope
    availability: WBDataAvailability
    metrics: WBHistoricalMetricSummary
    daily_series: list[WBWIPHoldTrendDailyPoint]
    limitations: list[str] = []


# ============================================================================
# H. BANK material-shortage historical trend (Phase WB-3B)
# ============================================================================


class WBBankShortageTrendDailyPoint(RCABaseModel):
    snapshot_date: date
    shortage_count: int
    total_count: int
    shortage_ratio: float | None


class WBBankShortageTrendAnalysisResult(RCABaseModel):
    """Item 11: focused on material_shortage specifically -- never merges
    `Ready To Issue`/`No Wafer In` into one undifferentiated "bad" bucket."""

    scope: WBQueryScope
    availability: WBDataAvailability
    metrics: WBHistoricalMetricSummary
    daily_series: list[WBBankShortageTrendDailyPoint]
    limitations: list[str] = []


# ============================================================================
# I. OUTPUT historical trend (Phase WB-3B)
# ============================================================================


class WBOutputTrendDailyPoint(RCABaseModel):
    production_date: date
    output_quantity: int


class WBOutputTrendAnalysisResult(RCABaseModel):
    scope: WBQueryScope
    availability: WBDataAvailability
    metrics: WBHistoricalMetricSummary
    daily_series: list[WBOutputTrendDailyPoint]
    limitations: list[str] = []


# ============================================================================
# J. Cross-source: ISSUE vs. OUTPUT (Phase WB-3B item 19-27)
# ============================================================================


class WBDirectionAlignment(str, Enum):
    """Deterministic classification of whether two independently-computed
    trends moved the same way over the same observed window -- NEVER a
    causal claim (item 21's own explicit prohibition: no `causal` field,
    no `cause_strength`, no estimated causal effect anywhere on this
    result)."""

    SAME_DIRECTION = "same_direction"
    OPPOSITE_DIRECTION = "opposite_direction"
    MIXED = "mixed"
    INSUFFICIENT_DATA = "insufficient_data"


class WBIssueOutputRelationshipResult(RCABaseModel):
    """Descriptive, temporal-association-only result (item 21). `issue`/
    `output` are each computed via the exact same `compute_historical_metrics`
    used by the single-source trend Tools above -- this Tool's own,
    additional job is the daily JOIN (by `plant_id` + business date, NEVER
    `source_sync_time` -- item 23) and the `direction_alignment`
    classification, nothing else."""

    scope: WBQueryScope
    availability: WBDataAvailability
    issue: WBHistoricalMetricSummary
    output: WBHistoricalMetricSummary
    overlap_observed_days: int  # days present in BOTH daily series after the join -- never assumed equal to either source's own observed_days
    both_declining: bool | None  # None when direction_alignment is INSUFFICIENT_DATA
    direction_alignment: WBDirectionAlignment
    association_statement: str  # plain descriptive text, never a causal verb
    limitations: list[str] = []


# ============================================================================
# Explicit payload registration (Phase WB Data Layer V1's discipline, item F)
# ============================================================================

_RESULT_PAYLOAD_TYPES: dict[str, type[RCABaseModel]] = {
    "wb.plant_oee_query_result": WBPlantOEEQueryResult,
    "wb.oee_loss_analysis_result": WBOEELossAnalysisResult,
    "wb.bank_query_result": WBBankQueryResult,
    "wb.bank_status_summary_result": WBBankStatusSummaryResult,
    "wb.bank_aging_analysis_result": WBBankAgingAnalysisResult,
    "wb.wip_query_result": WBWIPQueryResult,
    "wb.wip_summary_result": WBWIPSummaryResult,
    "wb.hold_analysis_result": WBHoldAnalysisResult,
    "wb.stage_output_query_result": WBStageOutputQueryResult,
    "wb.stage_output_summary_result": WBStageOutputSummaryResult,
    "wb.stage_output_comparison_result": WBStageOutputComparisonResult,
    "wb.issue_query_result": WBIssueQueryResult,
    "wb.issue_summary_result": WBIssueSummaryResult,
    "wb.issue_trend_analysis_result": WBIssueTrendAnalysisResult,
    "wb.oee_trend_analysis_result": WBOEETrendAnalysisResult,
    "wb.wip_hold_trend_analysis_result": WBWIPHoldTrendAnalysisResult,
    "wb.bank_shortage_trend_analysis_result": WBBankShortageTrendAnalysisResult,
    "wb.output_trend_analysis_result": WBOutputTrendAnalysisResult,
    "wb.issue_output_relationship_result": WBIssueOutputRelationshipResult,
}


def register_wb_tool_result_payloads() -> None:
    for payload_type, model in _RESULT_PAYLOAD_TYPES.items():
        PayloadRegistry.register(payload_type, model)
