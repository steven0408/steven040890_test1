"""Contract-ready Remote WB DataSource skeletons (item 19). NEVER called
against the real WB API this phase -- the real API host/port (see the
Phase report for the literal value) appears nowhere in this file, or
anywhere else in this codebase, as a literal string; it is only ever a
value an operator would put in the environment variable named by
`WBApiConfig.base_url_env`, mirroring the exact same "config carries the
env-var *name*, never the value" discipline `DataSourceConfig`
(`agent/datasource/models.py`) already established. See
`tests/test_wb_remote_adapter.py::test_never_contacts_a_real_host` for the
regression guard on this file specifically.

Every `Remote*DataSource` here implements the exact same Protocol its
`InMemory*` sibling does (`agent/domain/wb/datasource.py`) -- a future
Tool/Skill built against `WBPlantOEEDataSource` etc. does not know or
care which one it's holding.

`HttpClient` is an injected Protocol, not a hard dependency on `requests`/
`httpx` -- this module does not import either library, so it stays
importable (and testable via `tests/wb_fake_http_client.py`'s
`FakeHttpClient`) without any HTTP library installed at all.
"""
import os
from dataclasses import dataclass
from datetime import date
from typing import Any, Protocol

from agent.domain.wb.datasource import (
    parse_wb_bank_row,
    parse_wb_issue_row,
    parse_wb_plant_oee_row,
    parse_wb_stage_output_row,
    parse_wb_wip_row,
)
from agent.domain.wb.errors import WBDataNormalizationError, WBDataSourceUnavailableError, WBInvalidAPIResponseError
from agent.domain.wb.models import (
    WB_BANK_FRESHNESS,
    WB_ISSUE_FRESHNESS,
    WB_PLANT_OEE_FRESHNESS,
    WB_STAGE_OUTPUT_FRESHNESS,
    WB_WIP_FRESHNESS,
    DataFreshness,
    WBBankRecord,
    WBIssueRecord,
    WBPlantOEERecord,
    WBStageOutputRecord,
    WBWIPRecord,
)
from agent.domain.wb.normalization import normalize_rows


class HttpResponse(Protocol):
    status_code: int

    def json(self) -> Any: ...


class HttpClient(Protocol):
    def get(self, url: str, *, params: dict[str, Any], timeout: float) -> HttpResponse: ...


@dataclass(frozen=True)
class WBApiConfig:
    """Mirrors `DataSourceConfig`'s env-var-*name*-only discipline. No
    literal host, no credential value -- `base_url_env` names the
    environment variable a real deployment sets to the real WB API's
    base URL, resolved only at request time, never stored on this object
    or logged."""

    base_url_env: str
    timeout_seconds: float = 10.0
    # The real WB endpoints shown this phase carry no auth -- kept for
    # symmetry with DataSourceConfig/PostgresSettings in case a future
    # deployment adds one; still never a literal value.
    credential_env: str | None = None


def _resolve_base_url(config: WBApiConfig) -> str:
    value = os.environ.get(config.base_url_env)
    if not value:
        raise WBDataSourceUnavailableError(
            f"WBApiConfig.base_url_env names '{config.base_url_env}', which is not set -- refusing to guess a default host"
        )
    return value.rstrip("/")


def _resolve_credential(config: WBApiConfig) -> str | None:
    if config.credential_env is None:
        return None
    value = os.environ.get(config.credential_env)
    if not value:
        raise WBDataSourceUnavailableError(f"WBApiConfig.credential_env names '{config.credential_env}', which is not set")
    return value


def _get_json(client: HttpClient, url: str, params: dict[str, Any], timeout: float) -> dict:
    try:
        response = client.get(url, params=params, timeout=timeout)
    except Exception as exc:  # never let a raw requests/httpx exception escape
        raise WBDataSourceUnavailableError(f"WB API request to {url} failed: {exc}") from exc

    if response.status_code >= 500:
        raise WBDataSourceUnavailableError(f"WB API returned {response.status_code} for {url}")
    if response.status_code >= 400:
        raise WBInvalidAPIResponseError(f"WB API returned {response.status_code} for {url}")

    try:
        payload = response.json()
    except Exception as exc:
        raise WBInvalidAPIResponseError(f"WB API response from {url} is not valid JSON: {exc}") from exc

    if not isinstance(payload, dict) or "status" not in payload:
        raise WBInvalidAPIResponseError(f"WB API response from {url} is missing the expected 'status'/'data' envelope")
    if payload.get("status") == "error":
        raise WBInvalidAPIResponseError(f"WB API reported an error for {url}: {payload.get('message')}")
    if "data" not in payload:
        raise WBInvalidAPIResponseError(f"WB API response from {url} is missing 'data'")
    return payload


class RemoteWBPlantOEEDataSource:
    def __init__(self, config: WBApiConfig, *, http_client: HttpClient):
        self._config = config
        self._client = http_client

    def list_oee(self, *, production_date: date | None = None) -> list[WBPlantOEERecord]:
        url = f"{_resolve_base_url(self._config)}/api/wb/oeedata"
        params = {"date": production_date.isoformat()} if production_date else {}
        payload = _get_json(self._client, url, params, self._config.timeout_seconds)
        rows = normalize_rows(payload["data"])
        return [parse_wb_plant_oee_row(row) for row in rows]

    def freshness(self) -> DataFreshness:
        return WB_PLANT_OEE_FRESHNESS


class RemoteWBBankDataSource:
    def __init__(self, config: WBApiConfig, *, http_client: HttpClient):
        self._config = config
        self._client = http_client

    def list_bank(self, *, snapshot_date: date | None = None) -> list[WBBankRecord]:
        url = f"{_resolve_base_url(self._config)}/api/wb/bank"
        params = {"date": snapshot_date.isoformat()} if snapshot_date else {}
        payload = _get_json(self._client, url, params, self._config.timeout_seconds)
        rows = normalize_rows(payload["data"])
        return [parse_wb_bank_row(row) for row in rows]

    def freshness(self) -> DataFreshness:
        return WB_BANK_FRESHNESS


class RemoteWBWIPDataSource:
    def __init__(self, config: WBApiConfig, *, http_client: HttpClient):
        self._config = config
        self._client = http_client

    def list_wip(self, *, snapshot_date: date | None = None, limit: int = 5000) -> list[WBWIPRecord]:
        url = f"{_resolve_base_url(self._config)}/api/wb/wip"
        params: dict[str, Any] = {"limit": limit}
        if snapshot_date is not None:
            params["date"] = snapshot_date.isoformat()
        payload = _get_json(self._client, url, params, self._config.timeout_seconds)
        rows = normalize_rows(payload["data"])
        return [parse_wb_wip_row(row) for row in rows]

    def freshness(self) -> DataFreshness:
        return WB_WIP_FRESHNESS


class RemoteWBStageOutputDataSource:
    def __init__(self, config: WBApiConfig, *, http_client: HttpClient):
        self._config = config
        self._client = http_client

    def list_output(self, *, production_date: date | None = None, sync_time: str | None = None) -> list[WBStageOutputRecord]:
        url = f"{_resolve_base_url(self._config)}/api/wb/output_rawdata"
        params: dict[str, Any] = {}
        if sync_time is not None:
            params["time"] = sync_time
        elif production_date is not None:
            params["date"] = production_date.isoformat()
        payload = _get_json(self._client, url, params, self._config.timeout_seconds)
        rows = normalize_rows(payload["data"])
        return [parse_wb_stage_output_row(row) for row in rows]

    def freshness(self) -> DataFreshness:
        return WB_STAGE_OUTPUT_FRESHNESS


class RemoteWBIssueDataSource:
    """Phase WB-3A. NEVER contacts the real WB API this phase (see this
    module's own top-level docstring) -- `base_url_env` is the only thing
    naming where the real host would come from, never a literal.

    **Item V's own critical semantic note**: the real Flask endpoint's
    `date` query parameter filters `SYNC_TIME LIKE "{date}%"` -- it does
    NOT filter by `rel_date`/release date. `sync_date` here is named and
    documented to match that reality exactly (mirrors
    `WBIssueDataSource.list_issue`'s own Protocol docstring) -- this
    adapter does not, and cannot, ask the real API for "records released
    on this date"; a caller wanting that precision must filter the
    returned canonical records by their own `release_date` field
    (Tool-layer responsibility, `agent/tools/wb/issue_tools.py`). Fetching
    across multiple sync dates to assemble a full release-date's worth of
    records is explicitly NOT attempted here -- see the Phase WB-3A
    report's "Historical RCA Audit" section for why that orchestration is
    deferred to a future phase.
    """

    def __init__(self, config: WBApiConfig, *, http_client: HttpClient):
        self._config = config
        self._client = http_client

    def list_issue(self, *, sync_date: date | None = None) -> list[WBIssueRecord]:
        url = f"{_resolve_base_url(self._config)}/api/wb/issue"
        params: dict[str, Any] = {"date": sync_date.isoformat()} if sync_date is not None else {}
        payload = _get_json(self._client, url, params, self._config.timeout_seconds)
        rows = normalize_rows(payload["data"])
        return [parse_wb_issue_row(row) for row in rows]

    def freshness(self) -> DataFreshness:
        return WB_ISSUE_FRESHNESS


def build_remote_wb_datasources(config: WBApiConfig, *, http_client: HttpClient) -> "WBDataSources":
    """Phase PROD-1: the smallest composition wiring letting a production
    profile select the 5 Remote*DataSource classes above via config,
    instead of `agent/modules/wb/package.py::_default_wb_datasources()`'s
    always-InMemory-synthetic default. All 5 share one `WBApiConfig` (one
    base URL, per this phase's own "single base URL plus stable paths"
    instruction) -- each Remote*DataSource class already appends its own
    fixed path suffix internally (see each class's own `list_*` method).

    NEVER called against a real host by this phase's own tests (only
    constructed, never `.list_*()`-invoked) -- see this module's own
    top-level docstring for the "no literal host anywhere" discipline this
    function inherits unchanged. Returns the generic `WBDataSources`
    dataclass (`agent/tools/wb/registration.py`) so a caller can pass the
    result straight to `build_wb_module_package(datasources=...)` with no
    Tool/Skill/Policy code ever changing."""
    from agent.tools.wb.registration import WBDataSources

    return WBDataSources(
        oee=RemoteWBPlantOEEDataSource(config, http_client=http_client),
        bank=RemoteWBBankDataSource(config, http_client=http_client),
        wip=RemoteWBWIPDataSource(config, http_client=http_client),
        output=RemoteWBStageOutputDataSource(config, http_client=http_client),
        issue=RemoteWBIssueDataSource(config, http_client=http_client),
    )
