"""WB DataSource contracts (item 17) + raw-row -> canonical parsing (the
actual "raw API -> canonical record" boundary every `Remote*`/`InMemory*`
implementation shares) + InMemory implementations (item 18).

Four separate Protocols, not one `WBManufacturingDataSource` -- each
source has its own grain, query parameters, and update cadence (see
`docs/wb_data_layer.md`), and collapsing them into one interface would
blur exactly the distinctions item 6/7 asked to keep explicit (a single
`query(...)` method would need a different parameter/return shape per
source anyway, so nothing is actually saved by unifying the Protocol --
see the Phase report for the fuller comparison).
"""
from datetime import date, datetime
from typing import Protocol

from agent.domain.wb.errors import WBDataNormalizationError
from agent.domain.wb.mappings import resolve_bank_status, resolve_lot_status, resolve_plant_id, resolve_site_group
from agent.domain.wb.models import (
    WB_BANK_FRESHNESS,
    WB_ISSUE_FRESHNESS,
    WB_PLANT_OEE_FRESHNESS,
    WB_STAGE_OUTPUT_FRESHNESS,
    WB_WIP_FRESHNESS,
    DataFreshness,
    WBBankRecord,
    WBIssueRecord,
    WBPlantOEERecord,
    WBStageOutputRecord,
    WBWIPRecord,
)

# ============================================================================
# Shared raw-value coercion + datetime parsing
# ============================================================================


def _to_str(value) -> str | None:
    if value is None:
        return None
    return str(value)


def _to_int(value) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise WBDataNormalizationError(f"cannot parse int from {value!r}") from exc


def _to_float(value) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise WBDataNormalizationError(f"cannot parse float from {value!r}") from exc


def _parse_date(value) -> date:
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value))
    except ValueError as exc:
        raise WBDataNormalizationError(f"cannot parse date from {value!r}") from exc


def _parse_space_datetime(value) -> datetime:
    """`"YYYY-MM-DD HH:MM:SS"` -- OEE's and WIP's SYNC_TIME shape."""
    try:
        return datetime.fromisoformat(str(value))
    except ValueError as exc:
        raise WBDataNormalizationError(f"cannot parse datetime from {value!r}") from exc


def _parse_dash_datetime(value) -> datetime:
    """`"YYYY-MM-DD-HH-MM-SS"` -- BANK's and OUTPUT's SYNC_TIME shape
    (distinct from the space-separated one above -- two real, different
    formats across these 4 sources, per item 8's own observation)."""
    raw = str(value)
    parts = raw.split("-")
    if len(parts) != 6:
        raise WBDataNormalizationError(f"unexpected dash-formatted sync_time: {raw!r}")
    try:
        year, month, day, hour, minute, second = (int(p) for p in parts)
        return datetime(year, month, day, hour, minute, second)
    except ValueError as exc:
        raise WBDataNormalizationError(f"cannot parse dash-formatted sync_time: {raw!r}") from exc


def _parse_compact_datetime(value) -> datetime | None:
    """`"YYYYMMDDHHMMSS"` -- BANK's `status_50` shape."""
    if value is None:
        return None
    try:
        return datetime.strptime(str(value), "%Y%m%d%H%M%S")
    except ValueError as exc:
        raise WBDataNormalizationError(f"cannot parse compact datetime from {value!r}") from exc


def _parse_tolerant_date(value) -> date | None:
    """Phase WB-3A item H: ISSUE's raw `rel_date` sample is a bracketed
    placeholder (`"[DATE]"`), not a concrete example -- its real format is
    genuinely unconfirmed. Tries ISO `YYYY-MM-DD` (the one format every
    other WB daily-like date field, and the API's own `date` query
    parameter, already use) and returns `None` -- never raises, never
    guesses a different format -- on any failure. `WBIssueRecord.release_date_raw`
    always preserves the original string regardless, so nothing is lost
    even when this returns `None`."""
    if value is None:
        return None
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value))
    except ValueError:
        return None


# ============================================================================
# Raw row -> canonical record parsing
# ============================================================================


def parse_wb_plant_oee_row(row: dict) -> WBPlantOEERecord:
    return WBPlantOEERecord(
        production_date=_parse_date(row["DATE"]),
        plant_id=resolve_plant_id(_to_str(row["PLANT"])),
        operation_id=_to_str(row["OPER"]),
        oee=_to_float(row.get("OEE")),
        productive_ratio=_to_float(row.get("PRODUCTIVE")),
        downtime_ratio=_to_float(row.get("DOWN")),
        pm_ratio=_to_float(row.get("PM")),
        setup_ratio=_to_float(row.get("SETUP")),
        idle_ratio=_to_float(row.get("IDLE")),
        engineering_ratio=_to_float(row.get("ENG")),
        ts_ratio=_to_float(row.get("TS")),
        source_sync_time=_parse_space_datetime(row["SYNC_TIME"]),
    )


def parse_wb_bank_row(row: dict) -> WBBankRecord:
    bank_status, bank_status_raw = resolve_bank_status(row.get("status"))
    site_group, site_group_raw = resolve_site_group(row.get("site"))
    raw_plant = row.get("plant") or row.get("plant_1")
    return WBBankRecord(
        plant_id=resolve_plant_id(_to_str(raw_plant)),
        site_group=site_group,
        site_group_raw=site_group_raw,
        mother_batch_id=_to_str(row.get("schedule")),
        customer_code=_to_str(row.get("cust_2_code")),
        customer_sub_code=_to_str(row.get("cust_3_code")),
        customer_group=_to_str(row.get("cust_grp")),
        device=_to_str(row.get("device")),
        package_code=_to_str(row.get("pkg")),
        lead_count=_to_str(row.get("lc")),
        wafer_size_inch=_to_str(row.get("wafer_inch")),
        wafer_quantity=_to_int(row.get("wafer_qty")),
        die_quantity=_to_int(row.get("die_qty")),
        bank_status=bank_status,
        bank_status_raw=bank_status_raw,
        bank_entry_time=_parse_compact_datetime(row.get("status_50")),
        description=_to_str(row.get("description")) or None,
        run_type=_to_str(row.get("run_type")),
        customer_run_type=_to_str(row.get("cust_runtype")),
        unit_of_measure=_to_str(row.get("uom")),
        source_sync_time=_parse_dash_datetime(row["SYNC_TIME"]),
    )


def parse_wb_wip_row(row: dict) -> WBWIPRecord:
    lot_status, lot_status_raw = resolve_lot_status(row.get("STATUS"))
    raw_plant = row.get("PLANT") or row.get("FACILITY_SOURCE")
    return WBWIPRecord(
        plant_id=resolve_plant_id(_to_str(raw_plant)),
        facility_source=_to_str(row.get("FACILITY_SOURCE")),
        mother_batch_id=_to_str(row.get("LOT_NO")),
        child_batch_id=_to_str(row.get("SCHEDULE")),
        operation_id=_to_str(row["OPER"]),
        current_quantity=_to_int(row.get("CURRENT_QTY")),
        customer_code=_to_str(row.get("CUST")),
        package_code=_to_str(row.get("PKG")),
        lead_count=_to_str(row.get("LC")),
        run_type=_to_str(row.get("RUN_TYPE")),
        lot_status=lot_status,
        lot_status_raw=lot_status_raw,
        source_sync_time=_parse_space_datetime(row["SYNC_TIME"]),
    )


def parse_wb_stage_output_row(row: dict) -> WBStageOutputRecord:
    return WBStageOutputRecord(
        production_date=_parse_date(row["DATA_DATE"]),
        plant_id=resolve_plant_id(_to_str(row["FAC"])),
        location=_to_str(row.get("LOCATION")),
        operation_id=_to_str(row["OPER"]),
        output_quantity=_to_int(row.get("QTY_OUT")),
        customer_code=_to_str(row.get("TT_CUSTOMER")),
        device_type=_to_str(row.get("TT_DEVICE_TYPE")),
        package_code=_to_str(row.get("TT_PKG")),
        lead_count=_to_str(row.get("TT_LC")),
        bond_diagram=_to_str(row.get("TT_BOND_DIAG")),
        source_facility=_to_str(row.get("SUP_FAC")),
        source_sync_time=_parse_dash_datetime(row["SYNC_TIME"]),
    )


def parse_wb_issue_row(row: dict) -> WBIssueRecord:
    """Phase WB-3A. `prctr` -> `plant_id` (via the same `resolve_plant_id`
    every other WB source uses -- no second mapping mechanism). `site` is
    preserved as its OWN raw field, never canonicalized into a single
    plant (item J: site is a group/site semantic, e.g. "A1" covers
    ASE01/02/03, not one plant). `rel_date` is tolerant-parsed
    (`_parse_tolerant_date`) into `release_date`, with `release_date_raw`
    always keeping the original string regardless of parse success --
    genuinely distinct from `SYNC_TIME` -> `source_sync_time` (item F/V).
    """
    raw_rel_date = row.get("rel_date")
    return WBIssueRecord(
        source_sync_time=_parse_space_datetime(row["SYNC_TIME"]),
        plant_id=resolve_plant_id(_to_str(row["prctr"])),
        site=_to_str(row.get("site")),
        schedule=_to_str(row.get("schedule")),
        customer_code=_to_str(row.get("cust_2_code")),
        customer_name=_to_str(row.get("customer_name")),
        device_type=_to_str(row.get("dev_type")),
        issue_quantity=_to_int(row.get("iss_qty")),
        lead_count=_to_str(row.get("lead_count")),
        package_code=_to_str(row.get("pack_code")),
        package_type=_to_str(row.get("pack_typ")),
        region=_to_str(row.get("region")),
        release_date=_parse_tolerant_date(raw_rel_date),
        release_date_raw=_to_str(raw_rel_date),
        release_time=_to_str(row.get("rel_time")),
        release_system=_to_str(row.get("rel_sys")),
        time_bucket=_to_str(row.get("time")),
        wafer_inch=_to_str(row.get("wafer_inch")),
        year=_to_str(row.get("year")),
        # UNKNOWN fields (item G) -- raw values preserved, never interpreted.
        bd_no_unknown=_to_str(row.get("bd_no")),
        cu_flag_unknown=_to_str(row.get("cu_flag")),
        customer_run_type_unknown=_to_str(row.get("cust_runtype")),
        customer_sod_unknown=_to_str(row.get("customer_sod")),
        internal_sod_unknown=_to_str(row.get("internal_sod")),
        routid_unknown=_to_str(row.get("routid")),
        run_type_unknown=_to_str(row.get("run_type")),
        unit_of_measure_unknown=_to_str(row.get("uom")),
        user_id_unknown=_to_str(row.get("user_id")),
        user_name_unknown=_to_str(row.get("user_name")),
    )


# ============================================================================
# DataSource Protocols
# ============================================================================


class WBPlantOEEDataSource(Protocol):
    def list_oee(self, *, production_date: date | None = None) -> list[WBPlantOEERecord]: ...

    def freshness(self) -> DataFreshness: ...


class WBBankDataSource(Protocol):
    def list_bank(self, *, snapshot_date: date | None = None) -> list[WBBankRecord]: ...

    def freshness(self) -> DataFreshness: ...


class WBWIPDataSource(Protocol):
    def list_wip(self, *, snapshot_date: date | None = None, limit: int = 5000) -> list[WBWIPRecord]: ...

    def freshness(self) -> DataFreshness: ...


class WBStageOutputDataSource(Protocol):
    def list_output(self, *, production_date: date | None = None, sync_time: str | None = None) -> list[WBStageOutputRecord]: ...

    def freshness(self) -> DataFreshness: ...


class WBIssueDataSource(Protocol):
    """Phase WB-3A -- its own Protocol, not folded into any existing one
    (item L: each WB source keeps its own grain/query-parameter/cadence,
    per the module docstring's explicit design rule).

    `sync_date` deliberately matches what the REAL API can actually filter
    by (`SYNC_TIME`, item V) -- NOT `release_date`. A caller wanting
    "issue records released on 2026-08-12" queries this broadly (or
    unscoped) and filters the returned canonical records by their own
    `release_date` field -- that precise filtering is a Tool-layer
    responsibility (`agent/tools/wb/issue_tools.py`), never pretended to
    be a DataSource-level capability the real API doesn't have."""

    def list_issue(self, *, sync_date: date | None = None) -> list[WBIssueRecord]: ...

    def freshness(self) -> DataFreshness: ...


# ============================================================================
# InMemory implementations (item 18) -- backed by a pre-built list of
# already-canonical records (the synthetic dataset, agent/domain/wb/synthetic.py).
# ============================================================================


class InMemoryWBPlantOEEDataSource:
    def __init__(self, records: list[WBPlantOEERecord]):
        self._records = list(records)

    def list_oee(self, *, production_date: date | None = None) -> list[WBPlantOEERecord]:
        if production_date is None:
            return list(self._records)
        return [r for r in self._records if r.production_date == production_date]

    def freshness(self) -> DataFreshness:
        return WB_PLANT_OEE_FRESHNESS


class InMemoryWBBankDataSource:
    def __init__(self, records: list[WBBankRecord], *, snapshot_dates: dict[int, date] | None = None):
        """`snapshot_dates` optionally maps `id(record)` -> the calendar
        date its snapshot logically belongs to, since `WBBankRecord` itself
        has no `production_date` field (it's a snapshot dataset, item 6/7)
        -- only `source_sync_time`. The synthetic dataset builder supplies
        this so `list_bank(snapshot_date=...)` can filter by calendar day
        without pretending BANK has a production_date it doesn't have."""
        self._records = list(records)
        self._snapshot_dates = snapshot_dates or {}

    def list_bank(self, *, snapshot_date: date | None = None) -> list[WBBankRecord]:
        if snapshot_date is None:
            return list(self._records)
        return [
            r for r in self._records
            if self._snapshot_dates.get(id(r), r.source_sync_time.date()) == snapshot_date
        ]

    def freshness(self) -> DataFreshness:
        return WB_BANK_FRESHNESS


class InMemoryWBWIPDataSource:
    def __init__(self, records: list[WBWIPRecord], *, snapshot_dates: dict[int, date] | None = None):
        self._records = list(records)
        self._snapshot_dates = snapshot_dates or {}

    def list_wip(self, *, snapshot_date: date | None = None, limit: int = 5000) -> list[WBWIPRecord]:
        records = self._records
        if snapshot_date is not None:
            records = [
                r for r in records
                if self._snapshot_dates.get(id(r), r.source_sync_time.date()) == snapshot_date
            ]
        return list(records[:limit])

    def freshness(self) -> DataFreshness:
        return WB_WIP_FRESHNESS


class InMemoryWBStageOutputDataSource:
    def __init__(self, records: list[WBStageOutputRecord]):
        self._records = list(records)

    def list_output(self, *, production_date: date | None = None, sync_time: str | None = None) -> list[WBStageOutputRecord]:
        records = self._records
        if production_date is not None:
            records = [r for r in records if r.production_date == production_date]
        if sync_time is not None:
            records = [r for r in records if r.source_sync_time == _parse_dash_datetime(sync_time)]
        return list(records)

    def freshness(self) -> DataFreshness:
        return WB_STAGE_OUTPUT_FRESHNESS


class InMemoryWBIssueDataSource:
    def __init__(self, records: list[WBIssueRecord]):
        self._records = list(records)

    def list_issue(self, *, sync_date: date | None = None) -> list[WBIssueRecord]:
        """`sync_date` filters `source_sync_time.date()` -- matching
        exactly what `RemoteWBIssueDataSource`/the real API can filter by
        (item V), never `release_date` (a Tool-layer-only filter, see
        `WBIssueDataSource`'s own docstring)."""
        if sync_date is None:
            return list(self._records)
        return [r for r in self._records if r.source_sync_time.date() == sync_date]

    def freshness(self) -> DataFreshness:
        return WB_ISSUE_FRESHNESS
