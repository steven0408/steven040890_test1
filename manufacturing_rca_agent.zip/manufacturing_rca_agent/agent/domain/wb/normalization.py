"""Response-shape and missing-value normalization (items 8/9) -- the
boundary that absorbs every inconsistency in the 4 real Flask endpoints'
actual behavior (`OEE`/`BANK`/`OUTPUT` use pandas `to_json(orient="columns")`,
`WIP` uses `to_dict(orient="records")`; `OEE`/`BANK`/`OUTPUT` `fillna("")`,
`WIP` leaves `None`) so nothing above this module -- canonical parsing,
DataSource, eventually a Tool -- ever needs to know which shape a
particular raw payload arrived in.
"""
import math
from typing import Any

from agent.domain.wb.errors import WBDataNormalizationError


def normalize_api_rows(data: Any) -> list[dict]:
    """Accepts whatever the raw `data` field of a WB API response
    actually is, returns `list[dict]` always. Handles:

    - already a records array (`list[dict]`) -- returned as-is
    - empty list -- `[]`
    - pandas `to_json(orient="columns")` shape: `{"COL": {"0": v0, "1": v1,
      ...}, ...}` -- transposed into records, row order preserved by
      sorting the (string) row-index keys numerically when possible
    - empty dict (`{}`, what every columns-oriented endpoint returns for
      zero rows) -- `[]`
    """
    if data is None:
        return []
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        if not data:
            return []
        if all(isinstance(v, dict) for v in data.values()):
            row_indices: set[str] = set()
            for column in data.values():
                row_indices.update(column.keys())
            try:
                ordered_indices = sorted(row_indices, key=int)
            except ValueError:
                ordered_indices = sorted(row_indices)
            return [{column: values.get(idx) for column, values in data.items()} for idx in ordered_indices]
        # a single flat dict that isn't columns-oriented -- treat as one row
        return [data]
    raise WBDataNormalizationError(f"unsupported raw WB API response shape: {type(data).__name__}")


def normalize_missing_value(value: Any) -> Any:
    """`"" -> None`, `NaN -> None`. Never touches `0`/`0.0`/`False` -- those
    are legitimate business values, not missing-value markers (item 9's
    explicit rule)."""
    if value is None:
        return None
    if isinstance(value, str) and value == "":
        return None
    if isinstance(value, float) and math.isnan(value):
        return None
    return value


def normalize_row_missing_values(row: dict) -> dict:
    return {key: normalize_missing_value(value) for key, value in row.items()}


def normalize_rows(data: Any) -> list[dict]:
    """`normalize_api_rows` + missing-value normalization on every row --
    the one function a `Remote*DataSource` calls between "raw HTTP JSON"
    and "build canonical Record"."""
    return [normalize_row_missing_values(row) for row in normalize_api_rows(data)]
