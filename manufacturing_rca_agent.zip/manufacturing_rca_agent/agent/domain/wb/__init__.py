"""WB (Wire Bond BU) real-data onboarding -- Data Layer only (this phase).

No Tool, Skill, Planner policy, or Module lives here yet -- see
`docs/wb_data_layer.md` for the full glossary/semantics and the Phase
"WB Real Data Onboarding" report for the explicit scope guard. This
package is deliberately structured like `agent/domain/oee/` (models +
datasource Protocols + InMemory implementations), extended with
`mappings.py` (Plant/site/operation code resolution), `normalization.py`
(raw API shape -> canonical), `remote.py` (contract-ready, never-called-
this-phase Remote adapter skeletons), and `synthetic.py` (the coherent
synthetic dataset + golden scenarios A-E).
"""
