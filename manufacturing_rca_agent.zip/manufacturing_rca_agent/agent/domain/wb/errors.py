"""Typed WB data-layer errors (item 20) -- mirrors
`agent/domain/oee/datasource.py`'s own typed-exception pattern (scoped to
the domain, not reused generic `agent/datasource/models.py` exceptions,
since those describe a different boundary shape -- named-query/rows, not
this domain's specific record types). A `Remote*DataSource` (agent/domain/wb/remote.py)
must never let a raw `requests`/`httpx` exception (or a raw `KeyError`/
`ValueError` from bad JSON) escape to a caller -- everything is mapped to
one of these.
"""


class WBDataSourceUnavailableError(RuntimeError):
    """The remote WB API/DB could not be reached at all (connection error,
    timeout, non-2xx status). Never raised by an InMemory implementation."""


class WBInvalidAPIResponseError(ValueError):
    """The remote API responded, but the payload isn't shaped the way
    this adapter expects (missing `status`/`data` keys, `status: "error"`,
    non-JSON body, ...)."""


class WBDataNotFoundError(KeyError):
    """The query was well-formed and the API/DataSource responded
    successfully, but there is no data for the requested
    date/snapshot/plant."""


class WBDataNormalizationError(ValueError):
    """A raw row/payload could not be normalized into `list[dict]` or
    parsed into a canonical `WB*Record` -- an unrecognized raw shape, or a
    row that fails canonical-model validation."""
