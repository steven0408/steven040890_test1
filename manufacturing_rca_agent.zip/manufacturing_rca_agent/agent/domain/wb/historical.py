"""Shared deterministic historical-analysis computation (Phase WB-3B).

Every WB trend Tool (ISSUE/OEE/WIP-Hold/BANK-shortage/OUTPUT) computes its
current/baseline/deviation/recurrence/persistence/consecutive-day metrics
through this ONE shared function -- Planner decides WHICH window to look
at (item 3/14), this module performs the actual arithmetic. No Tool, no
Skill, no Planner ever computes these numbers a second, slightly-different
way; no LLM ever performs this calculation itself.

Design decisions (all deliberate, documented per item AF of the phase
spec's own request, not incidental):

- **Baseline excludes `current_date`** (item 5's own recommendation).
  `current=2026-08-12` with a 7-day window starting `2026-08-05` means
  baseline = `2026-08-05..2026-08-11`, current = `2026-08-12` alone.
- **`daily_values` never contains a fabricated entry for a day with no
  data** -- a missing day is simply absent from the dict. `observed_days`
  is `len(daily_values)`, never the window's calendar length (item 18).
- **Abnormality direction is domain-specific, never global** (item 6): the
  caller supplies `is_abnormal(value, baseline_value) -> bool`. OEE/WIP-
  Hold/BANK-shortage use a fixed, documented absolute threshold (matching
  the exact thresholds Phase WB-2D's RCA already established); ISSUE/
  OUTPUT use a threshold relative to the window's OWN computed baseline
  (self-comparison, since there's no domain-independent "low" for a raw
  quantity).
- **Recurrence count** = number of OBSERVED days in the whole window
  (including `current_date`) that are abnormal -- NEVER derived from
  `ObjectiveHistory`/objective retry count (item 17's own explicit
  regression concern).
- **Consecutive abnormal days** walks backward from `current_date`,
  stopping at the first missing OR normal day.
- **No baseline / no current -> `WBTrendDirection.INSUFFICIENT_DATA`**,
  `relative_deviation=None` -- never a fabricated 0%/"flat" (item 48).
"""
from dataclasses import dataclass
from datetime import date, timedelta
from enum import Enum
from typing import Callable

from agent.state.base import RCABaseModel

# A trend within this band (percentage points) of zero is reported FLAT
# rather than UP/DOWN -- the same fixed, documented threshold Phase WB-3A
# already established for `analyze_wb_issue_trend`, now shared.
FLAT_BAND_PERCENT = 5.0


class WBTrendDirection(str, Enum):
    UP = "up"
    DOWN = "down"
    FLAT = "flat"
    INSUFFICIENT_DATA = "insufficient_data"


class WBHistoricalMetricSummary(RCABaseModel):
    """Shared result shape (item 7) -- embedded by every NEW trend Result
    this phase (OEE/WIP-Hold/BANK-shortage/OUTPUT). `analyze_wb_issue_trend`
    (Phase WB-3A, pre-existing) keeps its own flat field names for
    backward compatibility (item 8) but is computed through this exact
    same function internally -- the LOGIC is shared even where the SHAPE
    isn't."""

    current_value: float | None
    baseline_value: float | None
    absolute_deviation: float | None
    relative_deviation: float | None  # percentage points; None if baseline_value is 0 or missing
    trend_direction: WBTrendDirection
    window_start: date
    window_end: date  # == current_date
    observed_days: int
    abnormal_days: int
    recurrence_count: int
    persistence_ratio: float | None  # abnormal_days / observed_days; None if observed_days == 0
    consecutive_abnormal_days: int


def compute_historical_metrics(
    daily_values: dict[date, float],
    *,
    current_date: date,
    window_start: date,
    is_abnormal: Callable[[float, float | None], bool],
) -> WBHistoricalMetricSummary:
    baseline_end = current_date - timedelta(days=1)
    baseline_days = {d: v for d, v in daily_values.items() if window_start <= d <= baseline_end}
    baseline_value = (sum(baseline_days.values()) / len(baseline_days)) if baseline_days else None
    current_value = daily_values.get(current_date)

    observed_days = len(daily_values)
    abnormal_day_set = {d for d, v in daily_values.items() if is_abnormal(v, baseline_value)}
    abnormal_days = len(abnormal_day_set)
    recurrence_count = abnormal_days
    persistence_ratio = (abnormal_days / observed_days) if observed_days > 0 else None

    consecutive = 0
    cursor = current_date
    while cursor in daily_values and cursor in abnormal_day_set:
        consecutive += 1
        cursor -= timedelta(days=1)

    if current_value is None or baseline_value is None:
        absolute_deviation = None
        relative_deviation = None
        trend_direction = WBTrendDirection.INSUFFICIENT_DATA
    else:
        absolute_deviation = current_value - baseline_value
        relative_deviation = (absolute_deviation / baseline_value * 100) if baseline_value != 0 else None
        if relative_deviation is None:
            trend_direction = WBTrendDirection.INSUFFICIENT_DATA
        elif abs(relative_deviation) < FLAT_BAND_PERCENT:
            trend_direction = WBTrendDirection.FLAT
        else:
            trend_direction = WBTrendDirection.UP if relative_deviation > 0 else WBTrendDirection.DOWN

    return WBHistoricalMetricSummary(
        current_value=current_value, baseline_value=baseline_value,
        absolute_deviation=absolute_deviation, relative_deviation=relative_deviation,
        trend_direction=trend_direction, window_start=window_start, window_end=current_date,
        observed_days=observed_days, abnormal_days=abnormal_days, recurrence_count=recurrence_count,
        persistence_ratio=persistence_ratio, consecutive_abnormal_days=consecutive,
    )


# --- Domain-specific abnormality predicates (item 6) ------------------------
#
# Absolute thresholds mirror Phase WB-2D's RCA contributing-factor
# thresholds exactly (`agent/planning/policies/wb.py`'s `_OEE_ABNORMAL_MAX`/
# `_WIP_HOLD_ABNORMAL_MIN`/`_BANK_SHORTAGE_ELEVATED_MIN`) -- not
# reinvented. ISSUE/OUTPUT have no domain-independent "low" value, so
# their predicate is relative to the window's own computed baseline.

OEE_ABNORMAL_MAX = 70.0  # OEE below this is abnormal (low is bad)
WIP_HOLD_ABNORMAL_MIN = 0.3  # Hold ratio at/above this is abnormal (high is bad)
BANK_SHORTAGE_ABNORMAL_MIN = 0.5  # material-shortage ratio at/above this is abnormal (high is bad)
SELF_BASELINE_LOW_RATIO = 0.7  # ISSUE/OUTPUT: more than 30% below baseline is abnormal


def oee_is_abnormal(value: float, _baseline: float | None) -> bool:
    return value < OEE_ABNORMAL_MAX


def wip_hold_ratio_is_abnormal(value: float, _baseline: float | None) -> bool:
    return value >= WIP_HOLD_ABNORMAL_MIN


def bank_shortage_ratio_is_abnormal(value: float, _baseline: float | None) -> bool:
    return value >= BANK_SHORTAGE_ABNORMAL_MIN


def below_self_baseline_is_abnormal(value: float, baseline: float | None) -> bool:
    """ISSUE/OUTPUT: "abnormal" means materially below this window's own
    baseline -- there is no fixed absolute threshold for a raw quantity
    that means something across every plant/product. `baseline is None`
    (nothing to compare against yet) is never treated as abnormal."""
    if baseline is None:
        return False
    return value < baseline * SELF_BASELINE_LOW_RATIO
