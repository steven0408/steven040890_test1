"""Phase WB-3D: deterministic, WB-specific data validation -- the layer
between "canonical records came back from a DataSource" and "this data is
trustworthy enough to feed a calculation." Reuses the exact
detect-vs-interpret split WB-3C already established for Limitation:

    Tool / DataSource
        |
        v
    THIS MODULE (detect: is this record/result trustworthy?)
        |
        v
    Tool Result (`validation_issues`, additive)
        |
        v
    WBPlanningPolicy (interpret: does this gap matter to the current
        objective? -- creates a structured Limitation if so)

**Not** a generic Data Quality platform (item 3's own explicit scope
guard) -- five bounded, WB-specific validation categories only, each
implemented only as far as the actual data/metadata genuinely supports
(never guessed):

    INVALID_VALUE_RANGE        -- OEE outside [0, 100]
    NEGATIVE_QUANTITY          -- ISSUE/WIP/BANK/OUTPUT quantities < 0
    SCOPE_MISMATCH              -- returned plant_id != requested plant_id
    DATE_MISMATCH                -- returned business date outside requested scope
    SUSPECTED_DUPLICATE        -- composite-key collision (never a destructive dedupe)
    POTENTIAL_TRUNCATION        -- returned_count == requested limit (WIP only --
                                    the only WB DataSource with a `limit` parameter)

Deliberately NOT attempted this phase (see the Phase WB-3D report's own
Data Quality coverage matrix for the honest COVERED/PARTIAL/NOT_DETECTABLE
classification): staleness beyond a same-dataset business-date
comparison, unexpected-row-count anomaly detection (needs a historical
baseline this module doesn't have access to at the pure-function level),
full cross-dataset aggregation reconciliation beyond a same-Tool
self-check.

**Never auto-corrects** (item 67): no `negative -> abs()`, no `180 ->
clamp(100)`, no `wrong plant -> requested plant`, no `wrong date ->
nearest date`, no destructive dedupe. An invalid/mismatched record is
EXCLUDED from `usable_records` and reported, never silently repaired.
"""
from dataclasses import dataclass
from datetime import date
from enum import Enum
from typing import Callable, TypeVar

from agent.domain.wb.models import WBBankRecord, WBIssueRecord, WBPlantOEERecord, WBStageOutputRecord, WBWIPRecord
from agent.state.base import RCABaseModel

T = TypeVar("T")

# WB-domain-only severity -- deliberately not a Core enum (item 5's own
# instruction). ERROR: record excluded from `usable_records`, never
# feeds an aggregation/trend/baseline. WARNING: record stays usable, but
# the caller should treat any conclusion built on it as provisional.
# INFO: metadata/anomaly note, never affects usability.


class WBValidationSeverity(str, Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


class WBValidationIssue(RCABaseModel):
    """One (possibly aggregated) validation finding. `record_count` lets a
    hundred identical-shape invalid rows collapse into ONE issue (item 36
    -- never 100 individual issues), while `sample` keeps exactly one
    bounded, non-sensitive example (item 68 -- never a raw row dump)."""

    code: str
    message: str
    severity: WBValidationSeverity
    field: str | None = None
    record_count: int = 1
    sample: str | None = None


class WBValidationOutcome(RCABaseModel):
    """Result of validating one batch of canonical records for one Tool
    call. `raw_record_count`/`usable_record_count`/`invalid_record_count`
    are kept SEPARATE from `WBDataAvailability.record_count` (item 32) --
    that field's existing meaning (WB-2A) is never silently redefined."""

    issues: list[WBValidationIssue] = []
    raw_record_count: int = 0
    usable_record_count: int = 0
    invalid_record_count: int = 0

    @property
    def has_errors(self) -> bool:
        return any(i.severity == WBValidationSeverity.ERROR for i in self.issues)


def _empty_outcome() -> WBValidationOutcome:
    return WBValidationOutcome()


# ============================================================================
# Generic building blocks (shared across sources -- item 66: one validator
# per concern, never copy-pasted per source)
# ============================================================================


def _aggregate_issue(code: str, message_for_sample: str, severity: WBValidationSeverity, field: str, samples: list[str]) -> WBValidationIssue:
    """item 36: N same-shape invalid records -> ONE issue with
    `record_count=len(samples)` and exactly one representative `sample`."""
    return WBValidationIssue(
        code=code, message=f"{message_for_sample} ({len(samples)} record(s) affected).",
        severity=severity, field=field, record_count=len(samples), sample=samples[0] if samples else None,
    )


def check_negative_quantity(records: list[T], *, get_quantity: Callable[[T], int | float | None], field_name: str) -> tuple[set[int], list[WBValidationIssue]]:
    """Returns (excluded_record_indices, issues). `None` (missing) is
    NEVER flagged -- negative != missing != zero (item 8's own invariant).
    Zero is a legitimate value, never flagged."""
    bad_indices: set[int] = set()
    samples: list[str] = []
    for i, r in enumerate(records):
        value = get_quantity(r)
        if value is not None and value < 0:
            bad_indices.add(i)
            if len(samples) < 1:
                samples.append(f"{field_name}={value}")
    if not bad_indices:
        return bad_indices, []
    return bad_indices, [_aggregate_issue("negative_quantity", f"WB {field_name} contained a negative value, which is not a valid quantity", WBValidationSeverity.ERROR, field_name, samples)]


def check_value_range(records: list[T], *, get_value: Callable[[T], float | None], field_name: str, low: float, high: float) -> tuple[set[int], list[WBValidationIssue]]:
    """`None` is never flagged (missing != invalid). Only a genuinely
    present, out-of-range value is an ERROR."""
    bad_indices: set[int] = set()
    samples: list[str] = []
    for i, r in enumerate(records):
        value = get_value(r)
        if value is not None and not (low <= value <= high):
            bad_indices.add(i)
            if len(samples) < 1:
                samples.append(f"{field_name}={value}")
    if not bad_indices:
        return bad_indices, []
    return bad_indices, [_aggregate_issue("invalid_value_range", f"WB {field_name} returned a value outside the expected [{low}, {high}] range", WBValidationSeverity.ERROR, field_name, samples)]


def check_scope_plant_mismatch(records: list[T], *, get_plant_id: Callable[[T], str], requested_plant: str | None) -> tuple[set[int], list[WBValidationIssue]]:
    """item 9/37: only meaningful when the caller actually requested one
    plant -- a module-wide (no plant filter) call has nothing to mismatch
    against. A mismatch is always ERROR (item 37 -- never a warning),
    since the record does not belong to the requested scope at all."""
    if requested_plant is None:
        return set(), []
    bad_indices: set[int] = set()
    samples: list[str] = []
    for i, r in enumerate(records):
        plant_id = get_plant_id(r)
        if plant_id != requested_plant:
            bad_indices.add(i)
            if len(samples) < 1:
                samples.append(f"requested={requested_plant} returned={plant_id}")
    if not bad_indices:
        return bad_indices, []
    return bad_indices, [_aggregate_issue("scope_mismatch", f"WB data returned record(s) for a plant other than the requested {requested_plant}", WBValidationSeverity.ERROR, "plant_id", samples)]


def check_date_mismatch(records: list[T], *, get_business_date: Callable[[T], date | None], requested_start: date | None, requested_end: date | None) -> tuple[set[int], list[WBValidationIssue]]:
    """item 10/38: business date only -- NEVER `source_sync_time`. Only
    meaningful when the caller actually requested a date/range. A record
    with `get_business_date(r) is None` (e.g. ISSUE's own unparseable
    `release_date`) is never flagged here -- that is ISSUE's own
    documented "skip, never guess" behavior (WB-3A/3B), not a date
    mismatch."""
    if requested_start is None and requested_end is None:
        return set(), []
    bad_indices: set[int] = set()
    samples: list[str] = []
    for i, r in enumerate(records):
        business_date = get_business_date(r)
        if business_date is None:
            continue
        if requested_start is not None and business_date < requested_start:
            bad_indices.add(i)
        elif requested_end is not None and business_date > requested_end:
            bad_indices.add(i)
        else:
            continue
        if len(samples) < 1:
            requested = f"{requested_start or '...'} to {requested_end or '...'}"
            samples.append(f"requested={requested} returned={business_date}")
    if not bad_indices:
        return bad_indices, []
    return bad_indices, [_aggregate_issue("date_mismatch", "WB data returned record(s) with a business date outside the requested scope", WBValidationSeverity.ERROR, "business_date", samples)]


def check_suspected_duplicates(records: list[T], *, get_key: Callable[[T], tuple]) -> list[WBValidationIssue]:
    """item 12/13: NEVER destructive -- only reports a `suspected_duplicate`
    count, never drops a row. `get_key` is a composite of fields that are
    STRONGLY correlated with true identity for this source (documented per
    call site) but not proven unique (no real row-level id field exists in
    any of the 4 WB APIs) -- two records with the exact same key are
    "suspected", not "confirmed", duplicates. Two records with the same
    VALUE but a different key (e.g. different lot) are never flagged
    (item 13's own explicit regression: value equality is not identity)."""
    seen: dict[tuple, int] = {}
    duplicate_count = 0
    sample_key: tuple | None = None
    for r in records:
        key = get_key(r)
        seen[key] = seen.get(key, 0) + 1
        if seen[key] == 2:  # the second occurrence is what makes it "suspected"
            duplicate_count += 1
            if sample_key is None:
                sample_key = key
    if duplicate_count == 0:
        return []
    return [WBValidationIssue(
        code="suspected_duplicate", severity=WBValidationSeverity.WARNING,
        message=f"{duplicate_count} record(s) share an identity-composite key with another record in this result -- possible duplicates, not automatically removed.",
        field=None, record_count=duplicate_count, sample=str(sample_key) if sample_key else None,
    )]


def check_truncation_risk(returned_count: int, limit: int) -> WBValidationIssue | None:
    """item 14/15: `returned_count == limit` is a RISK signal, never proof
    -- no WB DataSource Protocol exposes a total-count-before-limit or
    `has_more` field (confirmed by reading `agent/domain/wb/datasource.py`
    before writing this), so this module can never claim truncation is
    CERTAIN. Only WIP's own `list_wip(limit=...)` has a limit parameter at
    all -- OEE/BANK/OUTPUT/ISSUE have none, so this check is meaningless
    for them (never called for those sources)."""
    if returned_count < limit:
        return None
    return WBValidationIssue(
        code="potential_truncation", severity=WBValidationSeverity.WARNING,
        message=f"Returned row count ({returned_count}) reached the configured fetch limit ({limit}); the result may be incomplete.",
        field=None, record_count=returned_count, sample=None,
    )


def check_stale_relative_to_request(*, latest_available_business_date: date | None, requested_end: date | None, source_label: str) -> WBValidationIssue | None:
    """item 16/17: NEVER wall-clock `now()` -- compares the LATEST business
    date actually present in the fetched records against the requested
    window's own end date. `None` (no data at all) is a NO_DATA concern,
    not staleness -- this check only fires when SOME data exists but
    doesn't reach the requested end."""
    if latest_available_business_date is None or requested_end is None:
        return None
    if latest_available_business_date >= requested_end:
        return None
    return WBValidationIssue(
        code="stale_or_late_data", severity=WBValidationSeverity.WARNING,
        message=f"The latest available {source_label} business date ({latest_available_business_date.isoformat()}) is earlier than the requested date ({requested_end.isoformat()}).",
        field=None, record_count=1, sample=None,
    )


@dataclass
class ValidationSplit:
    """Generic helper: apply a set of `bad_indices` (ERROR-severity, from
    any of the checks above) to split `records` into usable vs. excluded,
    without ever mutating/repairing a value (item 67)."""

    usable: list
    excluded: list


def apply_exclusions(records: list[T], bad_indices: set[int]) -> ValidationSplit:
    usable = [r for i, r in enumerate(records) if i not in bad_indices]
    excluded = [r for i, r in enumerate(records) if i in bad_indices]
    return ValidationSplit(usable=usable, excluded=excluded)


def build_outcome(raw_count: int, issues: list[WBValidationIssue], invalid_count: int) -> WBValidationOutcome:
    return WBValidationOutcome(issues=issues, raw_record_count=raw_count, usable_record_count=raw_count - invalid_count, invalid_record_count=invalid_count)


# ============================================================================
# Source-specific validators (item 65/66) -- ONE function per source,
# composing the generic building blocks above; reused verbatim by every
# Tool for that source (never copy-pasted per Tool). Each returns
# `(usable_records, outcome)` -- `usable_records` excludes anything an
# ERROR-severity check flagged (item 29/31); WARNING-severity issues
# (suspected duplicates, potential truncation, staleness) never exclude a
# record (item 30).
# ============================================================================


def validate_oee_records(
    records: list[WBPlantOEERecord], *, requested_plant: str | None = None,
    requested_start: date | None = None, requested_end: date | None = None,
) -> tuple[list[WBPlantOEERecord], WBValidationOutcome]:
    """OEE and its component ratios are all 0-100 percentage-of-time
    metrics (confirmed via `docs/wb_data_layer.md` + the synthetic
    dataset's own values, e.g. ASE01's oee=58.0/downtime=19.0/setup=13.0).
    `engineering_ratio`/`ts_ratio` are deliberately NOT range-checked
    (item 5/7): their business meaning is documented UNKNOWN
    (`docs/wb_data_layer.md` section 5), so a range assumption on them
    would be exactly the kind of guess this phase forbids."""
    issues: list[WBValidationIssue] = []
    bad: set[int] = set()

    for field_name, getter in (
        ("oee", lambda r: r.oee), ("productive_ratio", lambda r: r.productive_ratio),
        ("downtime_ratio", lambda r: r.downtime_ratio), ("setup_ratio", lambda r: r.setup_ratio),
        ("pm_ratio", lambda r: r.pm_ratio), ("idle_ratio", lambda r: r.idle_ratio),
    ):
        b, iss = check_value_range(records, get_value=getter, field_name=field_name, low=0.0, high=100.0)
        bad |= b
        issues += iss

    b, iss = check_scope_plant_mismatch(records, get_plant_id=lambda r: r.plant_id, requested_plant=requested_plant)
    bad |= b
    issues += iss
    b, iss = check_date_mismatch(records, get_business_date=lambda r: r.production_date, requested_start=requested_start, requested_end=requested_end)
    bad |= b
    issues += iss

    # Grain: production_date x plant_id x operation_id -- a strong
    # identity candidate, but not proven unique (no row-level id field in
    # the real API), so Category B (suspected only, item 12).
    issues += check_suspected_duplicates(records, get_key=lambda r: (r.production_date, r.plant_id, r.operation_id))

    split = apply_exclusions(records, bad)
    return split.usable, build_outcome(len(records), issues, len(bad))


def validate_issue_records(
    records: list[WBIssueRecord], *, requested_plant: str | None = None,
    requested_start: date | None = None, requested_end: date | None = None,
) -> tuple[list[WBIssueRecord], WBValidationOutcome]:
    issues: list[WBValidationIssue] = []
    bad: set[int] = set()

    b, iss = check_negative_quantity(records, get_quantity=lambda r: r.issue_quantity, field_name="issue_quantity")
    bad |= b
    issues += iss
    b, iss = check_scope_plant_mismatch(records, get_plant_id=lambda r: r.plant_id, requested_plant=requested_plant)
    bad |= b
    issues += iss
    b, iss = check_date_mismatch(records, get_business_date=lambda r: r.release_date, requested_start=requested_start, requested_end=requested_end)
    bad |= b
    issues += iss

    # item 12's own explicit uncertainty: "schedule+release_date/time+
    # plant+customer/device 是否真的unique? 不確定" -- Category B, a
    # best-effort composite key, suspected only.
    issues += check_suspected_duplicates(records, get_key=lambda r: (r.schedule, r.release_date, r.plant_id, r.customer_code, r.device_type))

    split = apply_exclusions(records, bad)
    return split.usable, build_outcome(len(records), issues, len(bad))


def validate_wip_records(
    records: list[WBWIPRecord], *, requested_plant: str | None = None,
) -> tuple[list[WBWIPRecord], WBValidationOutcome]:
    """WIP is a snapshot dataset (no `production_date`) -- date-mismatch
    validation doesn't apply here (that's a Tool-layer snapshot-date
    filtering concern already handled by `select_latest_snapshot`, WB-2A/
    2B, not re-validated here)."""
    issues: list[WBValidationIssue] = []
    bad: set[int] = set()

    b, iss = check_negative_quantity(records, get_quantity=lambda r: r.current_quantity, field_name="current_quantity")
    bad |= b
    issues += iss
    b, iss = check_scope_plant_mismatch(records, get_plant_id=lambda r: r.plant_id, requested_plant=requested_plant)
    bad |= b
    issues += iss

    # item 12's own worked example: "mother_batch_id + child_batch_id +
    # operation_id + sync_time 可能接近unique" -- still Category B, never
    # destructively deduped.
    issues += check_suspected_duplicates(records, get_key=lambda r: (r.mother_batch_id, r.child_batch_id, r.operation_id, r.source_sync_time))

    split = apply_exclusions(records, bad)
    return split.usable, build_outcome(len(records), issues, len(bad))


def validate_bank_records(
    records: list[WBBankRecord], *, requested_plant: str | None = None,
) -> tuple[list[WBBankRecord], WBValidationOutcome]:
    """item 12's own explicit caution: BANK may legitimately have multiple
    real records for the same batch/snapshot -- Category C, "cannot detect
    safely". No duplicate check is attempted here at all (NOT_DETECTABLE,
    reported honestly in the Phase report rather than a guessed heuristic
    that would misclassify real repeated records as suspicious)."""
    issues: list[WBValidationIssue] = []
    bad: set[int] = set()

    for field_name, getter in (("wafer_quantity", lambda r: r.wafer_quantity), ("die_quantity", lambda r: r.die_quantity)):
        b, iss = check_negative_quantity(records, get_quantity=getter, field_name=field_name)
        bad |= b
        issues += iss

    b, iss = check_scope_plant_mismatch(records, get_plant_id=lambda r: r.plant_id, requested_plant=requested_plant)
    bad |= b
    issues += iss

    split = apply_exclusions(records, bad)
    return split.usable, build_outcome(len(records), issues, len(bad))


def validate_output_records(
    records: list[WBStageOutputRecord], *, requested_plant: str | None = None,
    requested_start: date | None = None, requested_end: date | None = None,
) -> tuple[list[WBStageOutputRecord], WBValidationOutcome]:
    issues: list[WBValidationIssue] = []
    bad: set[int] = set()

    b, iss = check_negative_quantity(records, get_quantity=lambda r: r.output_quantity, field_name="output_quantity")
    bad |= b
    issues += iss
    b, iss = check_scope_plant_mismatch(records, get_plant_id=lambda r: r.plant_id, requested_plant=requested_plant)
    bad |= b
    issues += iss
    b, iss = check_date_mismatch(records, get_business_date=lambda r: r.production_date, requested_start=requested_start, requested_end=requested_end)
    bad |= b
    issues += iss

    issues += check_suspected_duplicates(records, get_key=lambda r: (r.production_date, r.plant_id, r.operation_id, r.device_type, r.package_code, r.lead_count))

    split = apply_exclusions(records, bad)
    return split.usable, build_outcome(len(records), issues, len(bad))
