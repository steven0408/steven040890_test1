"""Phase PROD-1: the first concrete `HttpClient` implementation satisfying
`agent.domain.wb.remote.HttpClient`'s Protocol -- stdlib-only (`urllib`),
so wiring a production `WBDataSources` profile adds zero new third-party
dependency. NEVER called against a real host by any test in this repo
(see `tests/test_wb_remote_adapter.py`'s own discipline, extended here) --
this file's own tests construct the class and, at most, point it at a
`http://127.0.0.1:0` (a port nothing listens on) to prove the timeout/
connection-error path maps to the same typed errors `remote.py` already
expects, never a real manufacturing host.
"""
import json
import urllib.error
import urllib.parse
import urllib.request
from typing import Any


class _UrllibResponse:
    def __init__(self, status_code: int, body: bytes):
        self.status_code = status_code
        self._body = body

    def json(self) -> Any:
        return json.loads(self._body.decode("utf-8"))


class UrllibHttpClient:
    """Satisfies `agent.domain.wb.remote.HttpClient` using only
    `urllib.request` (Python stdlib) -- no `requests`/`httpx` dependency.
    Every `WBApiConfig`-driven call goes through `agent.domain.wb.remote`'s
    own `_get_json`, which already converts any exception this raises into
    `WBDataSourceUnavailableError`/`WBInvalidAPIResponseError` -- this
    class itself does no error-type translation, it only implements the
    bare `get()` shape."""

    def get(self, url: str, *, params: dict[str, Any], timeout: float) -> _UrllibResponse:
        query = urllib.parse.urlencode(params)
        full_url = f"{url}?{query}" if query else url
        request = urllib.request.Request(full_url, method="GET")
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                return _UrllibResponse(status_code=response.status, body=response.read())
        except urllib.error.HTTPError as exc:
            return _UrllibResponse(status_code=exc.code, body=exc.read())
        except urllib.error.URLError as exc:
            raise ConnectionError(f"GET {full_url} failed: {exc.reason}") from exc
