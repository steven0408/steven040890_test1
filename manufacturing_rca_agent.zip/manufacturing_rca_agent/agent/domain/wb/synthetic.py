"""Coherent synthetic WB dataset (item 11) + Golden Scenarios A-E (items
12-16). Builds RAW row dicts in the exact shape the real Flask endpoints
return (same field names, same two SYNC_TIME formats, same status
strings) and runs them through the real `parse_wb_*_row` functions
(`agent/domain/wb/datasource.py`) -- so building this dataset is itself an
end-to-end exercise of the raw-API-shape -> canonical-record pipeline, not
a shortcut that constructs `WB*Record` objects directly.

Not random: every value is chosen to make one coherent manufacturing
story per plant per day, anchored on 2026-08-12 (the "golden day") where
all five scenarios live side by side across five different plants, so a
future cross-dataset RCA capability (not built this phase) has real
data to be right or wrong about.

| Plant  | Golden Scenario (2026-08-12)              |
|--------|---------------------------------------------|
| ASE01  | A -- equipment-side loss (OEE down)          |
| ASE02  | D -- normal (false-positive check)           |
| ASE03  | C -- WIP/Hold flow issue                     |
| ASE07  | B -- material/input shortage (BANK)          |
| ASE08  | E -- missing data (OEE absent for the day)   |
"""
from datetime import date, datetime, timedelta

from agent.domain.wb.datasource import (
    parse_wb_bank_row,
    parse_wb_issue_row,
    parse_wb_plant_oee_row,
    parse_wb_stage_output_row,
    parse_wb_wip_row,
)
from agent.domain.wb.mappings import PLANT_ID_MAP
from agent.domain.wb.models import WBBankRecord, WBIssueRecord, WBPlantOEERecord, WBStageOutputRecord, WBWIPRecord

_RAW_PLANT_CODE = {canonical: raw for raw, canonical in PLANT_ID_MAP.items()}

PLANTS: tuple[str, ...] = ("ASE01", "ASE02", "ASE03", "ASE07", "ASE08")
OPERATIONS: tuple[str, ...] = ("2600", "2800")
PRODUCTION_DAYS: tuple[date, ...] = tuple(date(2026, 8, 6) + timedelta(days=i) for i in range(7))
GOLDEN_DATE: date = date(2026, 8, 12)

# Phase WB-3B: the shared 14-day historical window every source with a
# per-day/per-snapshot business date can be extended onto -- one single
# source of truth so ISSUE/BANK/WIP's own day lists never silently drift
# apart. Ends on GOLDEN_DATE (the existing golden day's own semantics are
# never touched by this extension).
HISTORY_DAYS: tuple[date, ...] = tuple(GOLDEN_DATE - timedelta(days=13 - i) for i in range(14))
HISTORY_DECLINE_START = GOLDEN_DATE - timedelta(days=3)  # 2026-08-09 .. 2026-08-12 inclusive

SCENARIO_A_PLANT = "ASE01"  # equipment-side loss
SCENARIO_B_PLANT = "ASE07"  # material/input shortage
SCENARIO_C_PLANT = "ASE03"  # WIP/Hold flow issue
SCENARIO_D_PLANT = "ASE02"  # normal (false-positive control)
SCENARIO_E_PLANT = "ASE08"  # missing OEE data

_SITE_FOR_PLANT: dict[str, str] = {"ASE01": "A1", "ASE02": "A1", "ASE03": "A1", "ASE07": "A2", "ASE08": "A2"}
_CUSTOMERS = (("CUSTOMER_01", "CUSTOMER_01_SUB", "CUSTOMER_GROUP_01"), ("CUSTOMER_02", "CUSTOMER_02_SUB", "CUSTOMER_GROUP_02"))
_DEVICES = ("DEVICE_A", "DEVICE_B")
_PACKAGES = ("RY2N", "QFN48")


def _fmt_space(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def _fmt_dash(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d-%H-%M-%S")


def _fmt_compact(dt: datetime) -> str:
    return dt.strftime("%Y%m%d%H%M%S")


# ============================================================================
# A. WB Plant OEE (daily, Date x Plant x Operation)
# ============================================================================


def _oee_row(*, day: date, plant: str, operation: str, oee: float, productive: float, down: float, pm: float, setup: float, idle: float) -> dict:
    sync_time = datetime.combine(day + timedelta(days=1), datetime.min.time()).replace(hour=8, minute=30)
    return {
        "DATE": day.isoformat(), "PLANT": plant, "OPER": operation,
        "OEE": oee, "PRODUCTIVE": productive, "DOWN": down, "PM": pm, "SETUP": setup, "IDLE": idle,
        "ENG": 2.0, "TS": 1.0,  # UNKNOWN fields -- plausible placeholder magnitude only, never interpreted
        "SYNC_TIME": _fmt_space(sync_time),
    }


def build_wb_plant_oee_raw_rows() -> list[dict]:
    rows: list[dict] = []
    for plant in PLANTS:
        for operation in OPERATIONS:
            for day in PRODUCTION_DAYS:
                if day == GOLDEN_DATE and plant == SCENARIO_E_PLANT:
                    continue  # Golden Scenario E: OEE missing entirely for this plant/day
                oee, productive, down, pm, setup, idle = 85.0, 80.0, 5.0, 2.0, 4.0, 3.0
                if day == GOLDEN_DATE and plant == SCENARIO_A_PLANT and operation == "2800":
                    # Golden Scenario A: equipment-side loss -- DOWN/SETUP up, OEE/PRODUCTIVE down
                    oee, productive, down, pm, setup, idle = 58.0, 52.0, 19.0, 2.0, 13.0, 6.0
                rows.append(_oee_row(day=day, plant=plant, operation=operation, oee=oee, productive=productive, down=down, pm=pm, setup=setup, idle=idle))
    return rows


def build_wb_plant_oee_records() -> list[WBPlantOEERecord]:
    return [parse_wb_plant_oee_row(row) for row in build_wb_plant_oee_raw_rows()]


# ============================================================================
# D. WB Stage Output (daily, Date x Plant x Location x Operation x Product)
# ============================================================================


def _output_row(*, day: date, plant: str, operation: str, product_index: int, qty: int) -> dict:
    sync_time = datetime.combine(day, datetime.min.time()).replace(hour=8, minute=30)
    customer, _, _ = _CUSTOMERS[product_index % len(_CUSTOMERS)]
    return {
        "DATA_DATE": day.isoformat(), "FAC": plant, "LOCATION": "LOC_1", "OPER": int(operation),
        "QTY_OUT": qty, "TT_CUSTOMER": customer, "TT_DEVICE_TYPE": _DEVICES[product_index % len(_DEVICES)],
        "TT_PKG": _PACKAGES[product_index % len(_PACKAGES)], "TT_LC": "100",
        "TT_BOND_DIAG": "BOND_DIAG_01", "SUP_FAC": plant,  # UNKNOWN fields -- preserved, not interpreted
        "SYNC_TIME": _fmt_dash(sync_time),
    }


def build_wb_stage_output_raw_rows() -> list[dict]:
    rows: list[dict] = []
    for plant in PLANTS:
        for operation in OPERATIONS:
            for day in PRODUCTION_DAYS:
                for product_index in range(2):  # "a few products"
                    qty = 2000
                    if day == GOLDEN_DATE and plant == SCENARIO_A_PLANT and operation == "2800":
                        qty = 1150  # Golden A: output shortage consistent with equipment loss
                    elif day == GOLDEN_DATE and plant == SCENARIO_B_PLANT and operation == "2800":
                        qty = 1200  # Golden B: output shortage despite normal OEE (material-constrained)
                    elif day == GOLDEN_DATE and plant == SCENARIO_C_PLANT:
                        qty = 1300  # Golden C: output shortage despite normal OEE/BANK (flow/Hold-constrained)
                    rows.append(_output_row(day=day, plant=plant, operation=operation, product_index=product_index, qty=qty))
    return rows


def build_wb_stage_output_records() -> list[WBStageOutputRecord]:
    return [parse_wb_stage_output_row(row) for row in build_wb_stage_output_raw_rows()]


# ============================================================================
# B. WB Bank (snapshot, Snapshot x Plant x Mother Batch x Product)
# ============================================================================

# Phase WB-3B: extended from 2 snapshots to one per day across HISTORY_DAYS
# (14 days) -- 2 snapshots was never enough to support historical/
# recurrence analysis. The LAST entry is byte-identical to the original
# golden snapshot (`datetime(2026, 8, 12, 8, 40)`), so nothing about the
# golden day's own values changes. One snapshot per day (matching
# `latest_snapshot_only=True`'s own "one representative reading per day"
# convention) avoids the "which of N same-day snapshots represents this
# day" ambiguity multiplied across 14 days.
BANK_SNAPSHOTS: tuple[datetime, ...] = tuple(
    datetime.combine(d, datetime.min.time()).replace(hour=8, minute=40) for d in HISTORY_DAYS
)
# ASE07 material-shortage: PERSISTENT (not just single-day) for the same
# 4 trailing days ISSUE already declines over (HISTORY_DECLINE_START ..
# GOLDEN_DATE) -- reinforces the Golden Scenario B cross-source story
# (both signals observable over the same window) without asserting any
# causal link between them (item C/W).
_BANK_SHORTAGE_DAYS = frozenset(d for d in HISTORY_DAYS if d >= HISTORY_DECLINE_START)


def _bank_row(*, sync_time: datetime, plant: str, index: int, status: str) -> dict:
    customer, customer_sub, customer_grp = _CUSTOMERS[index % len(_CUSTOMERS)]
    entry_time = sync_time - timedelta(hours=12, minutes=(index % 5))
    return {
        "SYNC_TIME": _fmt_dash(sync_time),
        "cust_2_code": customer, "cust_3_code": customer_sub, "cust_grp": customer_grp,
        "cust_runtype": "N", "data_cdt": _fmt_compact(sync_time - timedelta(hours=2)),
        "description": "", "device": _DEVICES[index % len(_DEVICES)], "die_qty": 10000 + index * 50,
        "lc": str(100 + index), "pkg": _PACKAGES[index % len(_PACKAGES)],
        "plant": _RAW_PLANT_CODE[plant], "plant_1": _RAW_PLANT_CODE[plant],
        "run_type": "N", "schedule": f"S{plant[-2:]}{index:04d}",
        "site": _SITE_FOR_PLANT[plant], "status": status, "status_50": _fmt_compact(entry_time),
        "uom": "P", "wafer_inch": "12", "wafer_qty": 150 + index, "year": "6",
    }


def build_wb_bank_raw_rows() -> list[dict]:
    rows: list[dict] = []
    for sync_time in BANK_SNAPSHOTS:
        for plant in PLANTS:
            for index in range(10):
                status = "Ready To Issue"
                # Phase WB-3B: was golden-day-only; now persistent across
                # every day in _BANK_SHORTAGE_DAYS (still includes
                # GOLDEN_DATE, so the golden day's own 7/10 value is
                # byte-for-byte unchanged).
                if plant == SCENARIO_B_PLANT and sync_time.date() in _BANK_SHORTAGE_DAYS and index < 7:
                    status = "MTL Shortage"
                elif index == 9:
                    status = "No Wafer In"  # a little background variety, every snapshot/plant
                rows.append(_bank_row(sync_time=sync_time, plant=plant, index=index, status=status))
    return rows


def build_wb_bank_records() -> tuple[list[WBBankRecord], dict[int, date]]:
    """Returns `(records, snapshot_dates)` -- `snapshot_dates` maps
    `id(record) -> date` since `WBBankRecord` itself has no
    `production_date` field (see `InMemoryWBBankDataSource`'s own
    docstring)."""
    records: list[WBBankRecord] = []
    snapshot_dates: dict[int, date] = {}
    for row in build_wb_bank_raw_rows():
        record = parse_wb_bank_row(row)
        records.append(record)
        snapshot_dates[id(record)] = record.source_sync_time.date()
    return records, snapshot_dates


# ============================================================================
# C. WB WIP (snapshot, Snapshot x Child Lot x Operation)
# ============================================================================

# Phase WB-3B: extended from 2 snapshots to one per day across
# HISTORY_DAYS -- same rationale as BANK_SNAPSHOTS above. The LAST entry
# is byte-identical to the original golden snapshot
# (`datetime(2026, 8, 12, 9, 30)`).
WIP_SNAPSHOTS: tuple[datetime, ...] = tuple(
    datetime.combine(d, datetime.min.time()).replace(hour=9, minute=30) for d in HISTORY_DAYS
)
# ASE03 Hold: RECURRING but NOT consecutive -- abnormal every other day
# for the trailing week (08-06/08/10/12), normal in between (08-07/09/11)
# and throughout the earlier baseline days. Deliberately a different shape
# than BANK's persistent-run pattern so recurrence_count (4) and
# consecutive_abnormal_days (1, since 08-11 immediately before GOLDEN_DATE
# is normal) are genuinely distinguishable in tests (item 17).
_WIP_HOLD_RECURRING_DAYS = frozenset(
    GOLDEN_DATE - timedelta(days=offset) for offset in (0, 2, 4, 6)
)


def _wip_row(*, sync_time: datetime, plant: str, operation: str, index: int, status: str) -> dict:
    return {
        "CURRENT_QTY": str(80 + index), "CUST": _CUSTOMERS[index % len(_CUSTOMERS)][0],
        "FACILITY_SOURCE": plant, "LC": str(100 + index), "LOT_NO": f"L{plant[-2:]}{operation}{index // 5:03d}",
        "OPER": operation, "PKG": _PACKAGES[index % len(_PACKAGES)], "PLANT": plant,
        "RUN_TYPE": "N", "SCHEDULE": f"C{plant[-2:]}{operation}{index:05d}", "STATUS": status,
        "SYNC_TIME": _fmt_space(sync_time),
    }


def build_wb_wip_raw_rows() -> list[dict]:
    rows: list[dict] = []
    for sync_time in WIP_SNAPSHOTS:
        for plant in PLANTS:
            for operation in OPERATIONS:
                for index in range(15):
                    status = "Active"
                    # Phase WB-3B: was golden-day-only; now recurring
                    # across _WIP_HOLD_RECURRING_DAYS (still includes
                    # GOLDEN_DATE, so 22/30 on 2026-08-12 is unchanged).
                    if plant == SCENARIO_C_PLANT and sync_time.date() in _WIP_HOLD_RECURRING_DAYS and index < 10:
                        status = "Hold"
                    elif index == 14:
                        status = "Hold"  # a little background variety everywhere
                    rows.append(_wip_row(sync_time=sync_time, plant=plant, operation=operation, index=index, status=status))
    return rows


def build_wb_wip_records() -> tuple[list[WBWIPRecord], dict[int, date]]:
    records: list[WBWIPRecord] = []
    snapshot_dates: dict[int, date] = {}
    for row in build_wb_wip_raw_rows():
        record = parse_wb_wip_row(row)
        records.append(record)
        snapshot_dates[id(record)] = record.source_sync_time.date()
    return records, snapshot_dates


# ============================================================================
# E. WB ISSUE (release-event, Release Date x Plant x Schedule x Customer x
# Device/Package) -- Phase WB-3A
# ============================================================================
#
# 14 days of release_date history (item N: "at least 7-14 days"), ending
# on the existing GOLDEN_DATE so this dataset can sit alongside the
# original 4 sources' own 7-day window without disturbing it -- ISSUE
# simply has a longer history because item N's own worked example (a
# "recent issue quantity < historical baseline" pattern) genuinely needs
# more days of baseline to compare against than a single week gives.
#
# ASE07 (the same plant as Golden Scenario B, material/input shortage)
# shows a clear ISSUE decline for the 4 days immediately before and
# including GOLDEN_DATE. This is a deliberately-placed OBSERVED pattern,
# nothing more: neither this generator nor any Tool/Skill built on top of
# it ever asserts "material shortage caused low issue" or "low issue
# caused output loss" (item C/W's explicit prohibition) -- a future RCA
# phase may or may not find these two signals meaningfully related; this
# phase only makes both observable in the same synthetic story.

ISSUE_DAYS: tuple[date, ...] = HISTORY_DAYS  # Phase WB-3B: now the shared 14-day window (alias, unchanged values)
ISSUE_DECLINE_START = HISTORY_DECLINE_START  # 2026-08-09 .. 2026-08-12 inclusive
_ISSUE_RECORDS_PER_PLANT_PER_DAY = 4
_ISSUE_BASELINE_QTY_PER_RECORD = 250  # 1000/day/plant on a normal day
_ISSUE_DECLINE_QTY_PER_RECORD = 100  # 400/day/plant -- a ~60% drop, unambiguous vs. baseline


def _issue_row(*, release_date: date, plant: str, index: int, qty: int) -> dict:
    # Item K's own reasoning, mirrored from WB_PLANT_OEE_FRESHNESS's
    # "usually reflects yesterday's production_date" note: a daily 08:40
    # sync captures the previous day's release records.
    sync_time = datetime.combine(release_date + timedelta(days=1), datetime.min.time()).replace(hour=8, minute=40)
    customer, _, _ = _CUSTOMERS[index % len(_CUSTOMERS)]
    return {
        "SYNC_TIME": _fmt_space(sync_time),
        "bd_no": "", "cu_flag": "Y" if index % 2 == 0 else "",
        "cust_2_code": customer, "cust_runtype": "N",
        "customer_name": f"{customer}_NAME", "customer_sod": "",
        "dev_type": _DEVICES[index % len(_DEVICES)], "internal_sod": "",
        "iss_qty": qty, "lead_count": "100",
        "pack_code": _PACKAGES[index % len(_PACKAGES)], "pack_typ": "STANDARD",
        "prctr": _RAW_PLANT_CODE[plant], "region": "TW",
        "rel_date": release_date.isoformat(), "rel_sys": "MES",
        "rel_time": "08:00:00", "routid": "",
        "run_type": "N", "schedule": f"I{plant[-2:]}{index:05d}",
        "site": _SITE_FOR_PLANT[plant], "time": "AM" if index % 2 == 0 else "PM",
        "uom": "P", "user_id": "", "user_name": "",
        "wafer_inch": "12", "year": "6",
    }


def build_wb_issue_raw_rows() -> list[dict]:
    rows: list[dict] = []
    for release_date in ISSUE_DAYS:
        for plant in PLANTS:
            declining = plant == SCENARIO_B_PLANT and release_date >= ISSUE_DECLINE_START
            qty = _ISSUE_DECLINE_QTY_PER_RECORD if declining else _ISSUE_BASELINE_QTY_PER_RECORD
            for index in range(_ISSUE_RECORDS_PER_PLANT_PER_DAY):
                rows.append(_issue_row(release_date=release_date, plant=plant, index=index, qty=qty))
    return rows


def build_wb_issue_records() -> list[WBIssueRecord]:
    return [parse_wb_issue_row(row) for row in build_wb_issue_raw_rows()]
