"""OEEDataSource (Phase 8B-1 Part D) -- the domain-typed boundary OEE's
Tools depend on instead of a raw `list[EquipmentRecord]` injected directly
into a Tool constructor. Mirrors the same "Tool -> Domain DataSource ->
backend adapter" shape `agent/datasource/models.py`'s generic `DataSource`
Protocol already established at the cross-domain level (Phase 5D) -- this
is the OEE-specific, properly-typed facade a real production adapter
(file-based, remote-DB-backed, ...) would implement, without any Tool,
Skill, or Planner code changing.

`InMemoryOEEDataSource` is the only implementation this phase -- still
backed by `MOCK_EQUIPMENT`, still no real database connection (Phase 8B-1
Part E's explicit scope guard). The chain this phase proves:

    MOCK_EQUIPMENT -> InMemoryOEEDataSource -> QueryOEEDataTool -> SkillRunner

A future `RemoteOEEDataSource`/`FileOEEDataSource` implementing this same
Protocol would need zero changes to `QueryOEEDataTool`,
`QueryEquipmentDetailTool`, any Skill markdown, or `OEEPlanningPolicy`.
"""
from typing import Protocol

from agent.domain.oee.dataset import EquipmentRecord


class OEEDataUnavailableError(RuntimeError):
    """The data source itself is unreachable/unavailable for a whole
    query (not "this one equipment_id doesn't exist" -- see
    `EquipmentNotFoundError` for that). Mirrors ErrorType.DATA_NOT_FOUND
    at the Tool layer; the Tool is responsible for the translation, this
    exception carries no ErrorType coupling itself."""


class EquipmentNotFoundError(KeyError):
    """No such `equipment_id` in this data source."""


class OEEDataSource(Protocol):
    def list_equipment(self) -> list[EquipmentRecord]: ...

    def get_equipment_detail(self, equipment_id: str) -> EquipmentRecord: ...


class InMemoryOEEDataSource:
    """Backs `list_equipment`/`get_equipment_detail` with an in-process
    list -- today always `MOCK_EQUIPMENT`, injected by the caller (the OEE
    ModulePackage), never hardcoded here. `unavailable`/`unavailable_targets`
    reproduce the exact same test-fixture simulation
    `QueryOEEDataTool`/`QueryEquipmentDetailTool` used to implement
    themselves, moved down one layer so the Tools no longer need to know
    about "simulated unavailability" at all -- that's a data-source-level
    concern now.
    """

    def __init__(
        self,
        equipment: list[EquipmentRecord],
        *,
        unavailable: bool = False,
        unavailable_targets: frozenset[str] = frozenset(),
    ):
        self._equipment = equipment
        self._by_id = {e.equipment_id: e for e in equipment}
        self._unavailable = unavailable
        self._unavailable_targets = unavailable_targets

    def list_equipment(self) -> list[EquipmentRecord]:
        if self._unavailable:
            raise OEEDataUnavailableError("OEE data source unavailable for 'list_equipment'")
        return list(self._equipment)

    def get_equipment_detail(self, equipment_id: str) -> EquipmentRecord:
        if equipment_id in self._unavailable_targets:
            raise OEEDataUnavailableError(f"OEE data source unavailable for '{equipment_id}'")
        record = self._by_id.get(equipment_id)
        if record is None:
            raise EquipmentNotFoundError(equipment_id)
        return record
