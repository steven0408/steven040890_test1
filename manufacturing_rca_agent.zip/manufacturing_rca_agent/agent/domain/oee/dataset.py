"""Mock manufacturing dataset for Phase 5A -- deterministic stand-in for a
real OEE data source. 12 equipment: 5 abnormal (OEE below the 0.80
threshold), 7 normal.

Abnormal set is designed to exercise every requirement from the Phase 5A
spec in one dataset:
  - EQ001, EQ003, EQ012 -> Availability is each one's worst dimension
    (highest aggregate contribution to OEE loss as a group)
  - EQ007 -> Performance is the worst dimension
  - EQ009 -> Quality is the worst dimension
  - EQ001 and EQ003 share the same downtime_reason/failure_reason
    ("Equipment Failure" / "Motor Failure") -- the shared pattern that
    should get grouped; EQ012 is also an Availability-pattern equipment
    but with a *different* failure_reason ("Belt Wear"), so it stays its
    own case rather than joining the group.
"""
from agent.state.base import RCABaseModel
from agent.state.payload import PayloadRegistry


class EquipmentRecord(RCABaseModel):
    equipment_id: str
    availability: float
    performance: float
    quality: float
    oee: float
    production_weight: float
    downtime_minutes: float
    downtime_reason: str | None = None
    failure_reason: str | None = None


class EquipmentSnapshot(RCABaseModel):
    """What Equipment Screening returns for one piece of equipment -- the
    A/P/Q breakdown, no downtime/failure detail yet."""

    equipment_id: str
    oee: float
    availability: float
    performance: float
    quality: float
    production_weight: float


class ScreeningResult(RCABaseModel):
    threshold: float
    equipment: list[EquipmentSnapshot]


class EquipmentDetail(RCABaseModel):
    """What a Deep Dive (action=EQUIPMENT_DETAIL) returns."""

    equipment_id: str
    downtime_minutes: float
    downtime_reason: str | None
    failure_reason: str | None


def pattern_of(snapshot: EquipmentSnapshot) -> str:
    """Which A/P/Q dimension is this equipment's worst -- the grouping key
    both `OEEPlanningPolicy` (RCA path) and the `calculate_contribution`
    capability Tool (Phase 5B-2 ANALYSIS path) use, kept in one place so the
    two paths can never silently disagree on what "Availability loss" means.
    """
    values = {"Availability": snapshot.availability, "Performance": snapshot.performance, "Quality": snapshot.quality}
    return min(values, key=values.get)


# --- Capability-layer (Phase 5B-2) result shapes: the `oee.equipment_screening`
# skill's own step-by-step pipeline (query -> filter -> contribution -> rank),
# distinct from the coarser ScreeningResult/EquipmentDetail the RCA path's
# single-step skills still produce unchanged. ------------------------------


class ContributionItem(RCABaseModel):
    equipment_id: str
    oee: float
    availability: float
    performance: float
    quality: float
    production_weight: float
    pattern: str
    contribution: float


class ContributionResult(RCABaseModel):
    threshold: float
    items: list[ContributionItem]


class PatternGroup(RCABaseModel):
    pattern: str
    equipment_ids: list[str]
    total_contribution: float


class RankedScreeningResult(RCABaseModel):
    """Final output of the `oee.equipment_screening` skill -- abnormal
    equipment only, grouped by worst dimension, groups ranked by aggregate
    contribution (highest first). This is a distinct, more processed shape
    than `ScreeningResult` (which stays the RCA path's raw/unranked
    all-equipment snapshot, per `OEEPlanningPolicy`'s own screening+ranking
    logic) -- the two are not interchangeable, even though both ultimately
    derive from the same `query_oee_data` Tool call."""

    threshold: float
    groups: list[PatternGroup]


class CurrentOEEStatus(RCABaseModel):
    """Output of the `oee.current_status` skill (INFORMATION TaskType)."""

    threshold: float
    equipment_count: int
    average_oee: float
    worst_equipment_id: str
    worst_oee: float


def _record(
    equipment_id: str,
    availability: float,
    performance: float,
    quality: float,
    production_weight: float,
    downtime_minutes: float,
    downtime_reason: str | None = None,
    failure_reason: str | None = None,
) -> EquipmentRecord:
    return EquipmentRecord(
        equipment_id=equipment_id,
        availability=availability,
        performance=performance,
        quality=quality,
        oee=round(availability * performance * quality, 4),
        production_weight=production_weight,
        downtime_minutes=downtime_minutes,
        downtime_reason=downtime_reason,
        failure_reason=failure_reason,
    )


MOCK_EQUIPMENT: list[EquipmentRecord] = [
    # --- abnormal (OEE < 0.80) ---
    _record("EQ001", 0.65, 0.90, 0.95, production_weight=1.0, downtime_minutes=180, downtime_reason="Equipment Failure", failure_reason="Motor Failure"),
    _record("EQ003", 0.68, 0.92, 0.94, production_weight=0.9, downtime_minutes=150, downtime_reason="Equipment Failure", failure_reason="Motor Failure"),
    _record("EQ007", 0.92, 0.60, 0.93, production_weight=0.6, downtime_minutes=40, downtime_reason="Minor Stops", failure_reason="Speed Loss"),
    _record("EQ009", 0.90, 0.91, 0.55, production_weight=0.5, downtime_minutes=20, downtime_reason="Quality Reject", failure_reason="Calibration Drift"),
    _record("EQ012", 0.70, 0.89, 0.93, production_weight=0.4, downtime_minutes=95, downtime_reason="Equipment Failure", failure_reason="Belt Wear"),
    # --- normal (OEE >= 0.80) ---
    _record("EQ002", 0.95, 0.96, 0.97, production_weight=0.8, downtime_minutes=10),
    _record("EQ004", 0.93, 0.94, 0.96, production_weight=0.7, downtime_minutes=12),
    _record("EQ005", 0.96, 0.95, 0.98, production_weight=0.9, downtime_minutes=8),
    _record("EQ006", 0.94, 0.93, 0.95, production_weight=0.6, downtime_minutes=15),
    _record("EQ008", 0.97, 0.96, 0.97, production_weight=0.8, downtime_minutes=6),
    _record("EQ010", 0.93, 0.95, 0.94, production_weight=0.5, downtime_minutes=14),
    _record("EQ011", 0.95, 0.94, 0.96, production_weight=0.6, downtime_minutes=9),
]

OEE_THRESHOLD = 0.80


def register_oee_result_payloads() -> None:
    """Phase 8B-1 item F: explicit registration, called once by the OEE
    ModulePackage (agent/modules/oee/package.py) -- never at import time.
    Whether `oee.screening_result`/etc. are registered payload types now
    depends on whether the OEE package was actually wired into a running
    process, not on which modules happened to be imported."""
    PayloadRegistry.register("oee.screening_result", ScreeningResult)
    PayloadRegistry.register("oee.equipment_detail", EquipmentDetail)
    PayloadRegistry.register("oee.contribution_result", ContributionResult)
    PayloadRegistry.register("oee.ranked_screening_result", RankedScreeningResult)
    PayloadRegistry.register("oee.current_status", CurrentOEEStatus)
