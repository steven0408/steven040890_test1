from typing import Protocol

from agent.state.base import RCABaseModel
from agent.state.enums import ErrorType, EvidenceQuality, ObservationStatus
from agent.state.models import Objective
from agent.state.payload import StructuredPayload


class ToolResult(RCABaseModel):
    status: ObservationStatus
    payload_summary: str | None = None
    structured_payload: StructuredPayload | None = None
    quality: EvidenceQuality | None = None
    error_type: ErrorType | None = None
    error_message: str | None = None


class MockTool(Protocol):
    """A Tool is an executable capability -- distinct from a Skill (the
    domain knowledge of *how* to use it, which lives in
    ModulePlanningPolicy). Phase 3 only has mock tools; real DB/SQL-backed
    tools are a later phase.
    """

    def run(self, objective: Objective) -> ToolResult: ...
