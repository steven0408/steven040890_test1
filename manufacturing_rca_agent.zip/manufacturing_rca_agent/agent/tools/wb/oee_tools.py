"""WB Plant OEE Tools (Phase WB-2A item C1). Depend on `WBPlantOEEDataSource`
(the Protocol, never a concrete `InMemory`/`Remote` implementation) --
constructor injection only, per item B's architecture invariant.

Two tools, not three: `CompareWBPlantOEE`'s ranking and
`AnalyzeWBOEELoss`'s loss-category breakdown are folded into one
`AnalyzeWBOEELossTool`, since both read the exact same filtered OEE
row-set and a caller asking "who's worst" almost always also wants "why"
in the same pass -- see the Phase report's Tool Design Review for the
full reasoning. `QueryWBPlantOEETool` stays the separate, pure
retrieval layer (item D).

WB OEE is `production_date x plant_id x operation_id` grain (Phase WB
Data Layer V1) -- neither tool here fabricates an Availability/
Performance/Quality breakdown or reshapes a row into the unrelated,
equipment-level `EquipmentSnapshot` model (`agent/domain/oee/dataset.py`).
"""
from datetime import date, timedelta

from agent.domain.wb.datasource import WBPlantOEEDataSource
from agent.domain.wb.historical import compute_historical_metrics, oee_is_abnormal
from agent.domain.wb.models import WBPlantOEERecord
from agent.domain.wb.tool_results import (
    WBOEELossAnalysisResult,
    WBOEELossBreakdown,
    WBOEETrendAnalysisResult,
    WBOEETrendDailyPoint,
    WBPlantOEEQueryResult,
    WBQueryScope,
    compute_availability,
)
from agent.domain.wb.validation import validate_oee_records
from agent.state.base import RCABaseModel
from agent.state.enums import EvidenceQuality, ObservationStatus
from agent.state.payload import PayloadRegistry
from agent.tools.models import ExecutionType, ToolCategory, ToolDefinition, ToolExecutionRequest, ToolExecutionResult, ToolIOSchema, ToolSideEffect
from agent.tools.wb._common import map_wb_datasource_error

# --- Loss-category priority order for deterministic dominant-category
# tie-breaking (item K) -- fixed, documented, never randomized.
_LOSS_CATEGORY_PRIORITY = ("downtime", "setup", "pm", "idle")


class WBPlantOEEQueryInput(RCABaseModel):
    production_date: date | None = None
    plant_id: str | None = None
    operation_id: str | None = None


class WBOEELossAnalysisInput(RCABaseModel):
    # Phase WB-2B.1: restored to required. WB-2B had made this Optional as
    # a workaround for `Objective` having no field to carry a date at all;
    # `ObjectiveScope.time` (agent/state/scope.py) now supplies it via
    # `wb.oee_status_analysis`'s own `required_scope_dimensions=
    # [production_date, plant]` -- the business semantic really is
    # "analyze OEE for a specific date", so this Tool should not silently
    # fall back to "every recorded date" when no date is given (see the
    # Phase WB-2B.1 report's "restore required production_date" section).
    production_date: date
    plant_id: str | None = None
    operation_id: str | None = None


class WBOEETrendAnalysisInput(RCABaseModel):
    plant_id: str
    # item 9: optional -- when unset, each day's representative value is
    # that day's worst-OEE operation (the same convention `AnalyzeWBOEELossTool`'s
    # own ranking already uses), never an invented weighted average across
    # operations.
    operation_id: str | None = None
    start: date
    end: date


def register_wb_oee_input_payloads() -> None:
    PayloadRegistry.register("wb.plant_oee_query_input", WBPlantOEEQueryInput)
    PayloadRegistry.register("wb.oee_loss_analysis_input", WBOEELossAnalysisInput)
    PayloadRegistry.register("wb.oee_trend_analysis_input", WBOEETrendAnalysisInput)


def _filter(records: list[WBPlantOEERecord], *, plant_id: str | None, operation_id: str | None) -> list[WBPlantOEERecord]:
    result = records
    if plant_id is not None:
        result = [r for r in result if r.plant_id == plant_id]
    if operation_id is not None:
        result = [r for r in result if r.operation_id == operation_id]
    return result


def _dominant_loss(record: WBPlantOEERecord) -> tuple[str | None, float | None]:
    candidates = {
        "downtime": record.downtime_ratio, "setup": record.setup_ratio,
        "pm": record.pm_ratio, "idle": record.idle_ratio,
    }
    known = {k: v for k, v in candidates.items() if v is not None}
    if not known:
        return None, None
    best_value = max(known.values())
    for category in _LOSS_CATEGORY_PRIORITY:  # fixed priority order breaks ties deterministically
        if known.get(category) == best_value:
            return category, best_value
    return None, None  # unreachable, kept for exhaustiveness


class QueryWBPlantOEETool:
    def __init__(self, datasource: WBPlantOEEDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="query_wb_plant_oee", name="Query WB Plant OEE",
            description="Retrieve WB Plant OEE records, optionally filtered by production_date/plant/operation.",
            category=ToolCategory.QUERY, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBPlantOEEQueryInput"), output_schema=ToolIOSchema(model_name="WBPlantOEEQueryResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.plant_oee_query_input", output_payload_type="wb.plant_oee_query_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBPlantOEEQueryInput)
        try:
            records = self._datasource.list_oee(production_date=params.production_date)
            records = _filter(records, plant_id=params.plant_id, operation_id=params.operation_id)
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        # Phase WB-3D: a raw QUERY tool reports validation issues (scope/
        # date mismatch, invalid range) but never EXCLUDES a record from
        # its own output -- "what's actually in the data" is this Tool's
        # whole job. Only CALCULATION tools (below) exclude invalid
        # records from their own aggregation/ranking. `WBPlantOEEDataSource.
        # list_oee` has no plant parameter at all (confirmed by reading
        # `agent/domain/wb/datasource.py`'s own Protocol) -- `_filter()`'s
        # own unconditional plant-equality check is the ONLY plant-scoping
        # mechanism anywhere in this codebase, so `check_scope_plant_
        # mismatch` running AFTER it is structurally guaranteed to find
        # nothing for any conforming DataSource; it exists as a defensive
        # regression guard, documented honestly (not overclaimed) in the
        # Phase WB-3D report's own coverage matrix.
        usable, outcome = validate_oee_records(records, requested_plant=params.plant_id, requested_start=params.production_date, requested_end=params.production_date)
        scope = WBQueryScope(plant_id=params.plant_id, operation_id=params.operation_id, production_date=params.production_date)
        result = WBPlantOEEQueryResult(
            scope=scope, availability=compute_availability(records, freshness, validation_issues=outcome.issues, usable_record_count=outcome.usable_record_count),
            records=records,
        )
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.plant_oee_query_result", result),
            summary=f"Queried {len(records)} WB Plant OEE record(s)" + (f" for {params.production_date.isoformat()}" if params.production_date else "") + ".",
            quality=EvidenceQuality.STRONG if records else EvidenceQuality.WEAK,
        )


class AnalyzeWBOEELossTool:
    def __init__(self, datasource: WBPlantOEEDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="analyze_wb_oee_loss", name="Analyze WB OEE Loss",
            description="Rank plants/operations by OEE and break down the dominant loss category (DOWN/SETUP/PM/IDLE) for a production date.",
            category=ToolCategory.CALCULATION, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBOEELossAnalysisInput"), output_schema=ToolIOSchema(model_name="WBOEELossAnalysisResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.oee_loss_analysis_input", output_payload_type="wb.oee_loss_analysis_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBOEELossAnalysisInput)
        try:
            records = self._datasource.list_oee(production_date=params.production_date)
            records = _filter(records, plant_id=params.plant_id, operation_id=params.operation_id)
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        # Phase WB-3D: an invalid OEE/ratio record (e.g. OEE=180) must
        # never be ranked as "worst" or drive the dominant-loss-category
        # breakdown (item 29) -- excluded from `usable` before any of
        # that, never clamped/repaired (item 67).
        usable, outcome = validate_oee_records(records, requested_plant=params.plant_id, requested_start=params.production_date, requested_end=params.production_date)

        breakdowns = []
        for record in usable:
            category, value = _dominant_loss(record)
            breakdowns.append(WBOEELossBreakdown(
                plant_id=record.plant_id, operation_id=record.operation_id, production_date=record.production_date,
                oee=record.oee, downtime_ratio=record.downtime_ratio, setup_ratio=record.setup_ratio,
                pm_ratio=record.pm_ratio, idle_ratio=record.idle_ratio, productive_ratio=record.productive_ratio,
                dominant_loss_category=category, dominant_loss_value=value,
            ))
        # Worst (lowest OEE) first; None OEE sorts last. Deterministic
        # tie-break: plant_id then operation_id, ascending.
        breakdowns.sort(key=lambda b: (b.oee is None, b.oee if b.oee is not None else 0.0, b.plant_id, b.operation_id))

        scope = WBQueryScope(plant_id=params.plant_id, operation_id=params.operation_id, production_date=params.production_date)
        result = WBOEELossAnalysisResult(
            scope=scope,
            availability=compute_availability(records, freshness, validation_issues=outcome.issues, usable_record_count=outcome.usable_record_count),
            ranking=breakdowns,
        )
        worst = f", worst is {breakdowns[0].plant_id}/{breakdowns[0].operation_id}" if breakdowns and breakdowns[0].oee is not None else ""
        date_clause = f" for {params.production_date.isoformat()}" if params.production_date else ""
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.oee_loss_analysis_result", result),
            summary=f"Ranked {len(breakdowns)} plant/operation OEE entries{date_clause}{worst}.",
            quality=EvidenceQuality.STRONG if records else EvidenceQuality.WEAK,
        )


class AnalyzeWBOEETrendTool:
    """Phase WB-3B. Descriptive historical analysis only -- `oee_is_abnormal`
    is a fixed, documented absolute threshold (mirrors Phase WB-2D's own
    RCA threshold exactly, never reinvented)."""

    def __init__(self, datasource: WBPlantOEEDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="analyze_wb_oee_trend", name="Analyze WB OEE Trend",
            description="Compare a WB plant's current OEE against its own recent baseline, with recurrence/persistence of below-threshold days. Descriptive only -- never a causal claim.",
            category=ToolCategory.CALCULATION, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBOEETrendAnalysisInput"), output_schema=ToolIOSchema(model_name="WBOEETrendAnalysisResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.oee_trend_analysis_input", output_payload_type="wb.oee_trend_analysis_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBOEETrendAnalysisInput)
        try:
            records = self._datasource.list_oee(production_date=None)
            records = _filter(records, plant_id=params.plant_id, operation_id=params.operation_id)
            records = [r for r in records if params.start <= r.production_date <= params.end]
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        # Phase WB-3D: an invalid OEE value must never be selected as a
        # day's "worst" representative (item 29/42) -- e.g. an out-of-
        # range OEE=-1 would otherwise win the `min()` selection below and
        # silently corrupt the whole trend/baseline. Excluded BEFORE the
        # per-day grouping, never clamped/repaired.
        usable, validation_outcome = validate_oee_records(records, requested_plant=params.plant_id, requested_start=params.start, requested_end=params.end)

        by_date: dict[date, list[WBPlantOEERecord]] = {}
        for r in usable:
            by_date.setdefault(r.production_date, []).append(r)

        limitations: list[str] = []
        daily_points: list[WBOEETrendDailyPoint] = []
        daily_values: dict[date, float] = {}
        for d in sorted(by_date):
            day_records = by_date[d]
            if params.operation_id is not None:
                chosen = day_records[0]
            else:
                if len(day_records) > 1 and not limitations:
                    limitations.append(
                        "Plant-wide OEE trend represents each day's worst-performing operation, "
                        "not a production-volume-weighted average across operations (no weighting data available)."
                    )
                # worst (lowest) OEE first; None sorts last -- same
                # deterministic tie-break as AnalyzeWBOEELossTool's own ranking.
                chosen = min(day_records, key=lambda r: (r.oee is None, r.oee if r.oee is not None else 0.0, r.operation_id))
            daily_points.append(WBOEETrendDailyPoint(production_date=d, operation_id=chosen.operation_id, oee=chosen.oee))
            if chosen.oee is not None:
                daily_values[d] = chosen.oee

        metrics = compute_historical_metrics(daily_values, current_date=params.end, window_start=params.start, is_abnormal=oee_is_abnormal)

        scope = WBQueryScope(plant_id=params.plant_id, operation_id=params.operation_id, production_date_start=params.start, production_date_end=params.end)
        result = WBOEETrendAnalysisResult(
            scope=scope,
            availability=compute_availability(records, freshness, validation_issues=validation_outcome.issues, usable_record_count=validation_outcome.usable_record_count),
            metrics=metrics, daily_series=daily_points, limitations=limitations,
        )
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.oee_trend_analysis_result", result),
            summary=f"WB OEE trend for {params.plant_id}: current {metrics.current_value}, trend {metrics.trend_direction.value}.",
            quality=EvidenceQuality.STRONG if records else EvidenceQuality.WEAK,
        )
