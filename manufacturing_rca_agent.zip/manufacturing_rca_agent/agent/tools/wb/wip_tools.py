"""WB WIP Tools (Phase WB-2A item C3). Depend on `WBWIPDataSource` only.
WIP is a snapshot dataset -- same `latest_snapshot_only=True` default as
BANK (item M). `AnalyzeWBHoldTool` is strictly descriptive (item C3/J):
it reports Hold quantity/ratio/grouping, never a root-cause claim
("Hold -> equipment failure"/"Hold -> material shortage" stays out of
scope for a future cross-source phase).
"""
from datetime import date, timedelta

from agent.domain.wb.datasource import WBWIPDataSource
from agent.domain.wb.historical import compute_historical_metrics, wip_hold_ratio_is_abnormal
from agent.domain.wb.models import WBLotStatus, WBWIPRecord
from agent.domain.wb.tool_results import (
    WBHoldAnalysisResult,
    WBQueryScope,
    WBWIPHoldTrendAnalysisResult,
    WBWIPHoldTrendDailyPoint,
    WBWIPQueryResult,
    WBWIPSummaryResult,
    compute_availability,
)
from agent.domain.wb.validation import (
    WBValidationIssue,
    WBValidationSeverity,
    apply_exclusions,
    build_outcome,
    check_scope_plant_mismatch,
    check_truncation_risk,
    validate_wip_records,
)
from agent.state.base import RCABaseModel
from agent.state.enums import EvidenceQuality, ObservationStatus
from agent.state.payload import PayloadRegistry
from agent.tools.models import ExecutionType, ToolCategory, ToolDefinition, ToolExecutionRequest, ToolExecutionResult, ToolIOSchema, ToolSideEffect
from agent.tools.wb._common import map_wb_datasource_error, select_latest_snapshot, sorted_group_counts

# Large safety margin so the DataSource's own `limit` parameter never
# truncates records before this Tool applies `select_latest_snapshot` --
# see agent/tools/wb/_common.py::select_latest_snapshot's own docstring.
_FETCH_LIMIT = 50_000


class WBWIPQueryInput(RCABaseModel):
    snapshot_date: date | None = None
    plant_id: str | None = None
    operation_id: str | None = None
    status: str | None = None  # a WBLotStatus value, e.g. "hold"
    customer_code: str | None = None
    package_code: str | None = None
    latest_snapshot_only: bool = True
    limit: int = 5000


class WBWIPSummaryInput(RCABaseModel):
    snapshot_date: date | None = None
    plant_id: str | None = None
    latest_snapshot_only: bool = True


class WBHoldAnalysisInput(RCABaseModel):
    snapshot_date: date | None = None
    plant_id: str | None = None
    latest_snapshot_only: bool = True


class WBWIPHoldTrendAnalysisInput(RCABaseModel):
    """Snapshot semantic (item 10) -- `start`/`end` bound `snapshot_date`,
    NEVER `production_date` (WIP has no production_date concept). One
    representative snapshot per day, via the existing `latest_snapshot_only`
    convention (item M's freeze), not a new per-day selection rule."""

    plant_id: str
    start: date
    end: date
    latest_snapshot_only: bool = True


def register_wb_wip_input_payloads() -> None:
    PayloadRegistry.register("wb.wip_query_input", WBWIPQueryInput)
    PayloadRegistry.register("wb.wip_summary_input", WBWIPSummaryInput)
    PayloadRegistry.register("wb.hold_analysis_input", WBHoldAnalysisInput)
    PayloadRegistry.register("wb.wip_hold_trend_analysis_input", WBWIPHoldTrendAnalysisInput)


def _fetch(datasource: WBWIPDataSource, *, snapshot_date: date | None, plant_id: str | None, latest_snapshot_only: bool) -> tuple[list[WBWIPRecord], WBValidationIssue | None]:
    """Phase WB-3D: `check_truncation_risk` compares the count returned
    BEFORE any plant/snapshot filtering against `_FETCH_LIMIT` (the actual
    `limit` this call used) -- filtering AFTER the DataSource call would
    otherwise mask a real "hit the limit" signal (item 14/15). WIP is the
    only WB source with a `limit` parameter at all (confirmed by reading
    `agent/domain/wb/datasource.py`'s own Protocol surface before writing
    this) -- no other `_fetch`-equivalent needs this."""
    raw = datasource.list_wip(snapshot_date=snapshot_date, limit=_FETCH_LIMIT)
    truncation_issue = check_truncation_risk(len(raw), _FETCH_LIMIT)
    records = raw
    if plant_id is not None:
        records = [r for r in records if r.plant_id == plant_id]
    if latest_snapshot_only:
        records = select_latest_snapshot(records)
    return records, truncation_issue


class QueryWBWIPTool:
    def __init__(self, datasource: WBWIPDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="query_wb_wip", name="Query WB WIP",
            description="Retrieve WB WIP records, optionally filtered by snapshot_date/plant/operation/status/customer/package.",
            category=ToolCategory.QUERY, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBWIPQueryInput"), output_schema=ToolIOSchema(model_name="WBWIPQueryResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.wip_query_input", output_payload_type="wb.wip_query_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBWIPQueryInput)
        try:
            records, truncation_issue = _fetch(self._datasource, snapshot_date=params.snapshot_date, plant_id=params.plant_id, latest_snapshot_only=params.latest_snapshot_only)
            if params.operation_id is not None:
                records = [r for r in records if r.operation_id == params.operation_id]
            if params.status is not None:
                records = [r for r in records if r.lot_status.value == params.status]
            if params.customer_code is not None:
                records = [r for r in records if r.customer_code == params.customer_code]
            if params.package_code is not None:
                records = [r for r in records if r.package_code == params.package_code]
            records = records[: params.limit]
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        _, outcome = validate_wip_records(records, requested_plant=params.plant_id)
        issues = ([truncation_issue] if truncation_issue else []) + outcome.issues
        scope = WBQueryScope(plant_id=params.plant_id, operation_id=params.operation_id, snapshot_date=params.snapshot_date, latest_snapshot_only=params.latest_snapshot_only, status_filter=params.status, customer_code=params.customer_code, package_code=params.package_code)
        result = WBWIPQueryResult(
            scope=scope,
            availability=compute_availability(records, freshness, validation_issues=issues, usable_record_count=outcome.usable_record_count),
            records=records,
        )
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.wip_query_result", result),
            summary=f"Queried {len(records)} WB WIP record(s).", quality=EvidenceQuality.STRONG if records else EvidenceQuality.WEAK,
        )


class SummarizeWBWIPTool:
    def __init__(self, datasource: WBWIPDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="summarize_wb_wip", name="Summarize WB WIP",
            description="Total WIP quantity/lot count for a snapshot, grouped by status and operation.",
            category=ToolCategory.CALCULATION, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBWIPSummaryInput"), output_schema=ToolIOSchema(model_name="WBWIPSummaryResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.wip_summary_input", output_payload_type="wb.wip_summary_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBWIPSummaryInput)
        try:
            records, truncation_issue = _fetch(self._datasource, snapshot_date=params.snapshot_date, plant_id=params.plant_id, latest_snapshot_only=params.latest_snapshot_only)
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        # Phase WB-3D (item 31): `lot_count`/`by_status`/`by_operation` are
        # COUNT metrics -- only scope mismatch excludes a lot here; only
        # `total_quantity` (a SUM) needs the quantity-valid subset too.
        scope_bad, scope_issues = check_scope_plant_mismatch(records, get_plant_id=lambda r: r.plant_id, requested_plant=params.plant_id)
        scope_usable = apply_exclusions(records, scope_bad).usable
        quantity_usable, quantity_outcome = validate_wip_records(scope_usable, requested_plant=None)
        total_quantity = sum(r.current_quantity or 0 for r in quantity_usable)

        issues = ([truncation_issue] if truncation_issue else []) + scope_issues + quantity_outcome.issues
        scope = WBQueryScope(plant_id=params.plant_id, snapshot_date=params.snapshot_date, latest_snapshot_only=params.latest_snapshot_only)
        result = WBWIPSummaryResult(
            scope=scope,
            availability=compute_availability(records, freshness, validation_issues=issues, usable_record_count=len(scope_usable)),
            total_quantity=total_quantity, lot_count=len(scope_usable),
            by_status=sorted_group_counts(scope_usable, lambda r: r.lot_status.value),
            by_operation=sorted_group_counts(scope_usable, lambda r: r.operation_id),
        )
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.wip_summary_result", result),
            summary=f"Summarized {len(records)} WB WIP lot(s), total quantity {total_quantity}.",
            quality=EvidenceQuality.STRONG if records else EvidenceQuality.WEAK,
        )


class AnalyzeWBHoldTool:
    def __init__(self, datasource: WBWIPDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="analyze_wb_hold", name="Analyze WB Hold",
            description="Hold quantity/ratio for a WIP snapshot, grouped by operation/package/customer. Descriptive only -- never a root-cause claim.",
            category=ToolCategory.CALCULATION, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBHoldAnalysisInput"), output_schema=ToolIOSchema(model_name="WBHoldAnalysisResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.hold_analysis_input", output_payload_type="wb.hold_analysis_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBHoldAnalysisInput)
        try:
            records, truncation_issue = _fetch(self._datasource, snapshot_date=params.snapshot_date, plant_id=params.plant_id, latest_snapshot_only=params.latest_snapshot_only)
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        # Phase WB-3D (item 31): `hold_ratio`/`total_lot_count`/
        # `hold_lot_count` are LOT-COUNT metrics -- a lot with a genuinely
        # invalid `current_quantity` still legitimately EXISTS as a
        # countable Hold/non-Hold entity, so only a genuine SCOPE mismatch
        # (wrong plant -- not in scope at all) excludes it here. Only
        # `hold_quantity` (a SUM) needs the quantity-valid subset too.
        scope_bad, scope_issues = check_scope_plant_mismatch(records, get_plant_id=lambda r: r.plant_id, requested_plant=params.plant_id)
        scope_usable = apply_exclusions(records, scope_bad).usable
        hold_records = [r for r in scope_usable if r.lot_status == WBLotStatus.HOLD]
        total_lot_count = len(scope_usable)
        hold_lot_count = len(hold_records)
        # Empty denominator is never silently reported as 0.0 (item L).
        hold_ratio = (hold_lot_count / total_lot_count) if total_lot_count > 0 else None

        hold_quantity_usable, quantity_outcome = validate_wip_records(hold_records, requested_plant=None)  # scope already applied above; only quantity matters here
        hold_quantity = sum(r.current_quantity or 0 for r in hold_quantity_usable)

        issues = ([truncation_issue] if truncation_issue else []) + scope_issues + quantity_outcome.issues
        scope = WBQueryScope(plant_id=params.plant_id, snapshot_date=params.snapshot_date, latest_snapshot_only=params.latest_snapshot_only)
        result = WBHoldAnalysisResult(
            scope=scope,
            availability=compute_availability(records, freshness, validation_issues=issues, usable_record_count=len(scope_usable)),
            total_lot_count=total_lot_count,
            hold_lot_count=hold_lot_count, hold_quantity=hold_quantity, hold_ratio=hold_ratio,
            by_operation=sorted_group_counts(hold_records, lambda r: r.operation_id),
            by_package=sorted_group_counts(hold_records, lambda r: r.package_code),
            by_customer=sorted_group_counts(hold_records, lambda r: r.customer_code),
        )
        ratio_str = f"{hold_ratio:.1%}" if hold_ratio is not None else "N/A (no lots in scope)"
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.hold_analysis_result", result),
            summary=f"{hold_lot_count}/{total_lot_count} WB WIP lot(s) on Hold ({ratio_str}).",
            quality=EvidenceQuality.STRONG if records else EvidenceQuality.WEAK,
        )


class AnalyzeWBWIPHoldTrendTool:
    """Phase WB-3B. Snapshot-date range (item 10) -- fetches ONE
    representative snapshot per calendar day (via the existing
    `select_latest_snapshot` convention, applied per-day rather than once
    across the whole range) so a day with more than one same-day sync
    never double-counts. `wip_hold_ratio_is_abnormal` is a fixed,
    documented absolute threshold (mirrors Phase WB-2D's own RCA
    threshold exactly)."""

    def __init__(self, datasource: WBWIPDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="analyze_wb_wip_hold_trend", name="Analyze WB WIP Hold Trend",
            description="Compare a WB plant's current WIP Hold ratio against its own recent baseline, with recurrence/persistence of elevated-Hold snapshots. Descriptive only -- never a root-cause claim.",
            category=ToolCategory.CALCULATION, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBWIPHoldTrendAnalysisInput"), output_schema=ToolIOSchema(model_name="WBWIPHoldTrendAnalysisResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.wip_hold_trend_analysis_input", output_payload_type="wb.wip_hold_trend_analysis_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBWIPHoldTrendAnalysisInput)
        try:
            all_records: list[WBWIPRecord] = []
            daily_points: list[WBWIPHoldTrendDailyPoint] = []
            daily_values: dict[date, float] = {}
            all_validation_issues: list[WBValidationIssue] = []
            any_truncation = False
            cursor = params.start
            while cursor <= params.end:
                day_records, day_truncation_issue = _fetch(self._datasource, snapshot_date=cursor, plant_id=params.plant_id, latest_snapshot_only=params.latest_snapshot_only)
                if day_truncation_issue is not None:
                    any_truncation = True
                if day_records:
                    # Phase WB-3D (item 31): Hold ratio is a LOT-COUNT
                    # metric -- it never reads `current_quantity`, so only
                    # a genuine SCOPE mismatch excludes a lot from this
                    # day's ratio. Quantity is still validated (and
                    # reported) since it's a real WIP data-quality signal,
                    # even though this particular Tool doesn't consume it.
                    day_scope_bad, day_scope_issues = check_scope_plant_mismatch(day_records, get_plant_id=lambda r: r.plant_id, requested_plant=params.plant_id)
                    day_usable = apply_exclusions(day_records, day_scope_bad).usable
                    _, day_quantity_outcome = validate_wip_records(day_usable, requested_plant=None)
                    all_validation_issues += day_scope_issues + day_quantity_outcome.issues
                    hold_records = [r for r in day_usable if r.lot_status == WBLotStatus.HOLD]
                    total = len(day_usable)
                    hold = len(hold_records)
                    ratio = (hold / total) if total > 0 else None
                    daily_points.append(WBWIPHoldTrendDailyPoint(snapshot_date=cursor, hold_lot_count=hold, total_lot_count=total, hold_ratio=ratio))
                    if ratio is not None:
                        daily_values[cursor] = ratio
                    all_records.extend(day_records)
                cursor += timedelta(days=1)
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        metrics = compute_historical_metrics(daily_values, current_date=params.end, window_start=params.start, is_abnormal=wip_hold_ratio_is_abnormal)

        if any_truncation:
            all_validation_issues = [WBValidationIssue(
                code="potential_truncation", severity=WBValidationSeverity.WARNING,
                message="At least one day's WIP fetch reached the configured fetch limit; that day's totals (and any trend metric built from it) may be incomplete.",
                field=None, record_count=1, sample=None,
            )] + all_validation_issues

        scope = WBQueryScope(plant_id=params.plant_id, snapshot_date_start=params.start, snapshot_date_end=params.end, latest_snapshot_only=params.latest_snapshot_only)
        result = WBWIPHoldTrendAnalysisResult(
            scope=scope,
            availability=compute_availability(all_records, freshness, validation_issues=all_validation_issues),
            metrics=metrics, daily_series=daily_points,
        )
        current_str = f"{metrics.current_value:.1%}" if metrics.current_value is not None else "N/A"
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.wip_hold_trend_analysis_result", result),
            summary=f"WB WIP Hold trend for {params.plant_id}: current {current_str}, trend {metrics.trend_direction.value}.",
            quality=EvidenceQuality.STRONG if all_records else EvidenceQuality.WEAK,
        )
