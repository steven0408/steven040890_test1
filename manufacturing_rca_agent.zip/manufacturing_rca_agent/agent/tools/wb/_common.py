"""Shared, deterministic helpers every WB Tool uses -- error mapping
(item O), latest-snapshot selection (item M), and small grouping/ranking
utilities (item K's determinism requirement: every ranking/grouping below
has a fixed sort key and a documented, fixed tie-break -- never
insertion-order-dependent, never random).
"""
from typing import TypeVar

from agent.domain.wb.errors import (
    WBDataNormalizationError,
    WBDataNotFoundError,
    WBDataSourceUnavailableError,
    WBInvalidAPIResponseError,
)
from agent.state.enums import ErrorType

T = TypeVar("T")


def map_wb_datasource_error(exc: Exception) -> tuple[ErrorType, str]:
    """Item O: every WB Tool catches DataSource-level exceptions and maps
    them here -- never lets a raw exception (HTTP or otherwise) escape to
    `ToolExecutionResult`/`Evidence`/`ErrorRecord`. Mirrors the exact
    pattern `QueryOEEDataTool`/`QueryEquipmentDetailTool` already
    established for `OEEDataUnavailableError`/`EquipmentNotFoundError` --
    no parallel error system, just this domain's own typed errors mapped
    onto the same generic `ErrorType` enum every other Tool already uses.
    """
    if isinstance(exc, WBDataSourceUnavailableError):
        return ErrorType.DATA_NOT_FOUND, str(exc)
    if isinstance(exc, WBDataNotFoundError):
        return ErrorType.DATA_NOT_FOUND, str(exc)
    if isinstance(exc, WBInvalidAPIResponseError):
        return ErrorType.QUERY_ERROR, str(exc)
    if isinstance(exc, WBDataNormalizationError):
        return ErrorType.QUERY_ERROR, str(exc)
    raise exc  # pragma: no cover -- an unmapped exception type is a bug, never silently swallowed


def select_latest_snapshot(records: list[T]) -> list[T]:
    """Item M's frozen default rule for BANK/WIP "current status" Tools:
    among whatever `source_sync_time` values are present, keep only the
    records at the single latest one. This is a Tool-layer decision, not
    a DataSource-layer one -- `WBBankDataSource`/`WBWIPDataSource` (Phase
    WB Data Layer V1, frozen) already expose everything needed
    (`source_sync_time` on every record) to do this deterministically
    without any contract change; see the Phase report's "snapshot
    handling" section for why no DataSource extension was needed."""
    if not records:
        return []
    latest = max(r.source_sync_time for r in records)
    return [r for r in records if r.source_sync_time == latest]


def sorted_group_counts(records: list[T], key) -> dict[str, int]:
    """Deterministic `{group_key: count}` -- keys always sorted ascending
    (never Python dict insertion order, which would depend on which
    record happened to be seen first)."""
    counts: dict[str, int] = {}
    for record in records:
        group = key(record)
        label = group if group is not None else "UNKNOWN"
        counts[label] = counts.get(label, 0) + 1
    return dict(sorted(counts.items()))


def sorted_group_sums(records: list[T], key, value) -> dict[str, int]:
    sums: dict[str, int] = {}
    for record in records:
        group = key(record)
        label = group if group is not None else "UNKNOWN"
        sums[label] = sums.get(label, 0) + (value(record) or 0)
    return dict(sorted(sums.items()))
