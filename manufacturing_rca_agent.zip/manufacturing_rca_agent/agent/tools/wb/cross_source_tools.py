"""WB Cross-Source Tools (Phase WB-3B item 19-27) -- the first Tool in
this codebase to consume TWO WB DataSource Protocols at once
(`WBIssueDataSource` + `WBStageOutputDataSource`).

**Descriptive temporal association only** -- never a causal claim (item
21's own explicit prohibition, mirrored exactly in
`WBIssueOutputRelationshipResult`'s own docstring): no `causal` field, no
`cause_strength`, no estimated causal effect anywhere on this result.
"ASE07 issue quantity and output both declined over the same observed
period" is a valid thing this Tool can say; "low issue caused low output"
is not, and nothing in this file constructs that sentence.

**Join semantics (item 23/24)**: the join key is business date
(`release_date` for ISSUE, `production_date` for OUTPUT) -- NEVER
`source_sync_time`. Both sources are aggregated to ONE total per
plant/day BEFORE any join happens (`_daily_totals`), so the join itself
is a plain dict-key intersection -- there is no row-level many-to-many
join anywhere in this file, and therefore no possibility of the
many-to-many row-explosion/double-counting item 24 warns about.
"""
from datetime import date

from agent.domain.wb.datasource import WBIssueDataSource, WBStageOutputDataSource
from agent.domain.wb.historical import FLAT_BAND_PERCENT, WBTrendDirection, below_self_baseline_is_abnormal, compute_historical_metrics
from agent.domain.wb.models import WBIssueRecord, WBStageOutputRecord
from agent.domain.wb.tool_results import WBDirectionAlignment, WBIssueOutputRelationshipResult, WBQueryScope, compute_availability
from agent.domain.wb.validation import validate_issue_records, validate_output_records
from agent.state.base import RCABaseModel
from agent.state.enums import EvidenceQuality, ObservationStatus
from agent.tools.models import ExecutionType, ToolCategory, ToolDefinition, ToolExecutionRequest, ToolExecutionResult, ToolIOSchema, ToolSideEffect
from agent.state.payload import PayloadRegistry
from agent.tools.wb._common import map_wb_datasource_error

# item 25: below this many OVERLAPPING observed days, no association
# judgment is made at all -- a documented first-cut conservative default,
# not a statistically-derived threshold (item 22).
MIN_OVERLAP_DAYS = 2


class WBIssueOutputRelationshipInput(RCABaseModel):
    plant_id: str
    start: date
    end: date


def register_wb_cross_source_input_payloads() -> None:
    PayloadRegistry.register("wb.issue_output_relationship_input", WBIssueOutputRelationshipInput)


def _issue_daily_totals(records: list[WBIssueRecord]) -> dict[date, float]:
    totals: dict[date, float] = {}
    for r in records:
        if r.release_date is None:
            continue  # item H: an unparseable release_date is never guessed into a bucket
        totals[r.release_date] = totals.get(r.release_date, 0.0) + (r.issue_quantity or 0)
    return totals


def _output_daily_totals(records: list[WBStageOutputRecord]) -> dict[date, float]:
    totals: dict[date, float] = {}
    for r in records:
        totals[r.production_date] = totals.get(r.production_date, 0.0) + (r.output_quantity or 0)
    return totals


def _direction_alignment(issue_direction: WBTrendDirection, output_direction: WBTrendDirection, overlap_days: int) -> WBDirectionAlignment:
    if overlap_days < MIN_OVERLAP_DAYS:
        return WBDirectionAlignment.INSUFFICIENT_DATA
    if issue_direction == WBTrendDirection.INSUFFICIENT_DATA or output_direction == WBTrendDirection.INSUFFICIENT_DATA:
        return WBDirectionAlignment.INSUFFICIENT_DATA
    if issue_direction == output_direction:
        return WBDirectionAlignment.SAME_DIRECTION
    if {issue_direction, output_direction} == {WBTrendDirection.UP, WBTrendDirection.DOWN}:
        return WBDirectionAlignment.OPPOSITE_DIRECTION
    return WBDirectionAlignment.MIXED  # one FLAT, the other UP/DOWN


def _association_statement(plant_id: str, alignment: WBDirectionAlignment, overlap_days: int, start: date, end: date) -> str:
    window = f"{start.isoformat()} to {end.isoformat()}, {overlap_days} overlapping observed day(s)"
    if alignment == WBDirectionAlignment.INSUFFICIENT_DATA:
        return f"Insufficient overlapping data to assess an Issue/Output association for {plant_id} ({window})."
    if alignment == WBDirectionAlignment.SAME_DIRECTION:
        return f"{plant_id} issue quantity and output moved in the same direction over the overlapping historical window ({window})."
    if alignment == WBDirectionAlignment.OPPOSITE_DIRECTION:
        return f"{plant_id} issue quantity and output moved in opposite directions over the overlapping historical window ({window})."
    return f"{plant_id} issue quantity and output showed a mixed relationship over the overlapping historical window ({window})."


class AnalyzeWBIssueVsOutputTool:
    def __init__(self, issue_datasource: WBIssueDataSource, output_datasource: WBStageOutputDataSource):
        self._issue_datasource = issue_datasource
        self._output_datasource = output_datasource
        self.definition = ToolDefinition(
            tool_id="analyze_wb_issue_vs_output", name="Analyze WB Issue vs. Output Relationship",
            description="Descriptive temporal association between a WB plant's Issue and Output trends over the same historical window -- never a causal claim.",
            category=ToolCategory.CALCULATION, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBIssueOutputRelationshipInput"), output_schema=ToolIOSchema(model_name="WBIssueOutputRelationshipResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.issue_output_relationship_input", output_payload_type="wb.issue_output_relationship_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBIssueOutputRelationshipInput)
        try:
            issue_records = [
                r for r in self._issue_datasource.list_issue()
                if r.plant_id == params.plant_id and r.release_date is not None and params.start <= r.release_date <= params.end
            ]
            output_records = [
                r for r in self._output_datasource.list_output(production_date=None)
                if r.plant_id == params.plant_id and params.start <= r.production_date <= params.end
            ]
            issue_freshness = self._issue_datasource.freshness()
            output_freshness = self._output_datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        # Phase WB-3D (item 22/44/45): an invalid ISSUE/OUTPUT day (e.g. a
        # negative issue_quantity, or a record from the wrong plant) must
        # never enter the daily aggregation OR the overlap computation --
        # `usable_*` excludes it BEFORE `_issue_daily_totals`/
        # `_output_daily_totals` run, so `overlap_days` is always based on
        # USABLE business dates, never raw ones. This can coexist with a
        # PARTIAL_SOURCE_OVERLAP limitation without either one suppressing
        # the other (item 45).
        usable_issue_records, issue_validation_outcome = validate_issue_records(issue_records, requested_plant=params.plant_id, requested_start=params.start, requested_end=params.end)
        usable_output_records, output_validation_outcome = validate_output_records(output_records, requested_plant=params.plant_id, requested_start=params.start, requested_end=params.end)

        issue_daily = _issue_daily_totals(usable_issue_records)
        output_daily = _output_daily_totals(usable_output_records)

        issue_metrics = compute_historical_metrics(issue_daily, current_date=params.end, window_start=params.start, is_abnormal=below_self_baseline_is_abnormal)
        output_metrics = compute_historical_metrics(output_daily, current_date=params.end, window_start=params.start, is_abnormal=below_self_baseline_is_abnormal)

        overlap_days = len(set(issue_daily.keys()) & set(output_daily.keys()))
        alignment = _direction_alignment(issue_metrics.trend_direction, output_metrics.trend_direction, overlap_days)
        both_declining = None
        if alignment != WBDirectionAlignment.INSUFFICIENT_DATA:
            both_declining = issue_metrics.trend_direction == WBTrendDirection.DOWN and output_metrics.trend_direction == WBTrendDirection.DOWN

        limitations: list[str] = []
        issue_only_days = set(issue_daily.keys()) - set(output_daily.keys())
        output_only_days = set(output_daily.keys()) - set(issue_daily.keys())
        if issue_only_days or output_only_days:
            limitations.append(
                f"Partial overlap: {len(issue_only_days)} day(s) had Issue data without Output, "
                f"{len(output_only_days)} day(s) had Output data without Issue -- only {overlap_days} day(s) overlap."
            )

        # `compute_availability` needs one freshness value; ISSUE's is used
        # as the primary one (both sources are DAILY-cadence, item K/9.7).
        if issue_freshness.update_frequency != output_freshness.update_frequency:  # pragma: no cover -- defensive, both are DAILY today
            limitations.append("ISSUE and OUTPUT sources have different update cadences -- freshness reflects ISSUE only.")
        validation_issues = issue_validation_outcome.issues + output_validation_outcome.issues
        usable_record_count = issue_validation_outcome.usable_record_count + output_validation_outcome.usable_record_count
        availability = compute_availability(
            issue_records + output_records, issue_freshness, limitations=limitations,
            validation_issues=validation_issues, usable_record_count=usable_record_count,
        )

        scope = WBQueryScope(plant_id=params.plant_id, production_date_start=params.start, production_date_end=params.end)
        result = WBIssueOutputRelationshipResult(
            scope=scope, availability=availability,
            issue=issue_metrics, output=output_metrics,
            overlap_observed_days=overlap_days, both_declining=both_declining,
            direction_alignment=alignment,
            association_statement=_association_statement(params.plant_id, alignment, overlap_days, params.start, params.end),
            limitations=limitations,
        )
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.issue_output_relationship_result", result),
            summary=result.association_statement,
            quality=EvidenceQuality.STRONG if overlap_days >= MIN_OVERLAP_DAYS else EvidenceQuality.WEAK,
        )
