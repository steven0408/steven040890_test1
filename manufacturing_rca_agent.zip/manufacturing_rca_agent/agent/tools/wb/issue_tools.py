"""WB ISSUE Tools (Phase WB-3A). Depend on `WBIssueDataSource` only.

Item V's semantic split, honored end to end: the real API's `date` query
parameter filters `SYNC_TIME`, never `rel_date` -- so every Tool here
fetches from the DataSource UNSCOPED (or scoped only by the DataSource's
own `sync_date`, which none of these three actually use, since the
synthetic/in-memory dataset is small enough that an unscoped fetch is
cheap and correct) and then filters precisely by the canonical
`release_date` field itself, in Python, deterministically -- never
pretending the DataSource/remote API can do that filtering natively.
"""
from datetime import date, timedelta

from agent.domain.wb.datasource import WBIssueDataSource
from agent.domain.wb.historical import below_self_baseline_is_abnormal, compute_historical_metrics
from agent.domain.wb.models import WBIssueRecord
from agent.domain.wb.tool_results import (
    WBIssueQueryResult,
    WBIssueSummaryResult,
    WBIssueTrendAnalysisResult,
    WBIssueTrendDailyPoint,
    WBIssueTrendDirection,
    WBQueryScope,
    compute_availability,
)
from agent.domain.wb.validation import validate_issue_records
from agent.state.base import RCABaseModel
from agent.state.enums import EvidenceQuality, ObservationStatus
from agent.state.payload import PayloadRegistry
from agent.tools.models import ExecutionType, ToolCategory, ToolDefinition, ToolExecutionRequest, ToolExecutionResult, ToolIOSchema, ToolSideEffect
from agent.tools.wb._common import map_wb_datasource_error, sorted_group_sums

# A trend direction within this band (percentage points) of zero is
# reported FLAT rather than UP/DOWN -- a fixed, documented threshold
# (item W: deterministic classification, never a statistical inference)
# that keeps small day-to-day noise from being labeled a "trend".
_FLAT_BAND_PERCENT = 5.0


class WBIssueQueryInput(RCABaseModel):
    release_date: date | None = None
    plant_id: str | None = None
    customer_code: str | None = None
    device_type: str | None = None
    package_code: str | None = None


class WBIssueSummaryInput(RCABaseModel):
    release_date: date | None = None
    plant_id: str | None = None


class WBIssueTrendAnalysisInput(RCABaseModel):
    """Trend is inherently a per-plant, self-baseline question (item N's
    own worked example: "is ASE07's recent issue quantity below ITS OWN
    baseline" -- never a cross-plant comparison), so `plant_id` is
    required, unlike the other two ISSUE Tools."""

    plant_id: str
    start: date
    end: date
    # Trailing N days of [start, end] count as "current"; the remaining
    # earlier days in the window are "baseline". Default 1 -- "how does
    # today compare to the rest of this window" (item R's own example
    # question: "今天的 ISSUE 是否低於過去 7 天 baseline").
    current_period_days: int = 1


def register_wb_issue_input_payloads() -> None:
    PayloadRegistry.register("wb.issue_query_input", WBIssueQueryInput)
    PayloadRegistry.register("wb.issue_summary_input", WBIssueSummaryInput)
    PayloadRegistry.register("wb.issue_trend_analysis_input", WBIssueTrendAnalysisInput)


def _fetch(datasource: WBIssueDataSource, *, release_date: date | None, plant_id: str | None) -> list[WBIssueRecord]:
    """Fetches unscoped from the DataSource (item V: it cannot filter by
    release_date), then filters precisely by the canonical `release_date`/
    `plant_id` fields in Python."""
    records = datasource.list_issue()
    if release_date is not None:
        records = [r for r in records if r.release_date == release_date]
    if plant_id is not None:
        records = [r for r in records if r.plant_id == plant_id]
    return records


class QueryWBIssueTool:
    def __init__(self, datasource: WBIssueDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="query_wb_issue", name="Query WB Issue",
            description="Retrieve WB ISSUE (material release) records, optionally filtered by release_date/plant/customer/device/package.",
            category=ToolCategory.QUERY, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBIssueQueryInput"), output_schema=ToolIOSchema(model_name="WBIssueQueryResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.issue_query_input", output_payload_type="wb.issue_query_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBIssueQueryInput)
        try:
            records = _fetch(self._datasource, release_date=params.release_date, plant_id=params.plant_id)
            if params.customer_code is not None:
                records = [r for r in records if r.customer_code == params.customer_code]
            if params.device_type is not None:
                records = [r for r in records if r.device_type == params.device_type]
            if params.package_code is not None:
                records = [r for r in records if r.package_code == params.package_code]
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        usable, outcome = validate_issue_records(records, requested_plant=params.plant_id, requested_start=params.release_date, requested_end=params.release_date)
        scope = WBQueryScope(plant_id=params.plant_id, release_date=params.release_date, customer_code=params.customer_code, device_type=params.device_type, package_code=params.package_code)
        result = WBIssueQueryResult(
            scope=scope,
            availability=compute_availability(records, freshness, validation_issues=outcome.issues, usable_record_count=outcome.usable_record_count),
            records=records,
        )
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.issue_query_result", result),
            summary=f"Queried {len(records)} WB Issue record(s)" + (f" for {params.release_date.isoformat()}" if params.release_date else "") + ".",
            quality=EvidenceQuality.STRONG if records else EvidenceQuality.WEAK,
        )


class SummarizeWBIssueTool:
    def __init__(self, datasource: WBIssueDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="summarize_wb_issue", name="Summarize WB Issue",
            description="Total WB Issue (material release) quantity for a release_date/plant, grouped by customer/device.",
            category=ToolCategory.CALCULATION, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBIssueSummaryInput"), output_schema=ToolIOSchema(model_name="WBIssueSummaryResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.issue_summary_input", output_payload_type="wb.issue_summary_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBIssueSummaryInput)
        try:
            records = _fetch(self._datasource, release_date=params.release_date, plant_id=params.plant_id)
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        # Phase WB-3D: a negative issue_quantity must never enter the
        # total/breakdown aggregation (item 8/29) -- excluded before
        # summing, never `abs()`-repaired (item 67).
        usable, outcome = validate_issue_records(records, requested_plant=params.plant_id, requested_start=params.release_date, requested_end=params.release_date)
        total = sum(r.issue_quantity or 0 for r in usable)
        scope = WBQueryScope(plant_id=params.plant_id, release_date=params.release_date)
        result = WBIssueSummaryResult(
            scope=scope,
            availability=compute_availability(records, freshness, validation_issues=outcome.issues, usable_record_count=outcome.usable_record_count),
            total_issue_quantity=total, record_count=len(records),
            by_plant=sorted_group_sums(usable, lambda r: r.plant_id, lambda r: r.issue_quantity),
            by_customer=sorted_group_sums(usable, lambda r: r.customer_code, lambda r: r.issue_quantity),
            by_device=sorted_group_sums(usable, lambda r: r.device_type, lambda r: r.issue_quantity),
        )
        date_clause = f" for {params.release_date.isoformat()}" if params.release_date else ""
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.issue_summary_result", result),
            summary=f"Summarized {len(records)} WB Issue record(s){date_clause}, total quantity {total}.",
            quality=EvidenceQuality.STRONG if records else EvidenceQuality.WEAK,
        )


def _classify_trend(percentage_difference: float | None) -> WBIssueTrendDirection:
    if percentage_difference is None:
        return WBIssueTrendDirection.UNKNOWN
    if abs(percentage_difference) < _FLAT_BAND_PERCENT:
        return WBIssueTrendDirection.FLAT
    return WBIssueTrendDirection.UP if percentage_difference > 0 else WBIssueTrendDirection.DOWN


class AnalyzeWBIssueTrendTool:
    """Deterministic historical DESCRIPTIVE analysis only (item Q/W) --
    splits `[start, end]` into a trailing "current" window and an earlier
    "baseline" window, compares their average-daily issue quantity. Never
    produces or implies a causal conclusion."""

    def __init__(self, datasource: WBIssueDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="analyze_wb_issue_trend", name="Analyze WB Issue Trend",
            description="Compare a WB plant's current-period Issue quantity against its own earlier baseline within a date range. Descriptive only -- never a causal claim.",
            category=ToolCategory.CALCULATION, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBIssueTrendAnalysisInput"), output_schema=ToolIOSchema(model_name="WBIssueTrendAnalysisResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.issue_trend_analysis_input", output_payload_type="wb.issue_trend_analysis_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBIssueTrendAnalysisInput)
        try:
            records = _fetch(self._datasource, release_date=None, plant_id=params.plant_id)
            records = [r for r in records if r.release_date is not None and params.start <= r.release_date <= params.end]
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        # Phase WB-3D: a negative issue_quantity must never enter the
        # current/baseline totals or the daily/trend series (item 8/29/42)
        # -- excluded before any of the calculations below, never
        # `abs()`-repaired (item 67).
        usable, validation_outcome = validate_issue_records(records, requested_plant=params.plant_id, requested_start=params.start, requested_end=params.end)

        current_start = max(params.start, params.end - timedelta(days=params.current_period_days - 1))
        current_records = [r for r in usable if current_start <= r.release_date <= params.end]
        current_total = sum(r.issue_quantity or 0 for r in current_records)
        current_days = (params.end - current_start).days + 1
        current_average_daily = current_total / current_days

        baseline_end = current_start - timedelta(days=1)
        baseline_records = [r for r in usable if params.start <= r.release_date <= baseline_end] if baseline_end >= params.start else []
        if baseline_records:
            baseline_total = sum(r.issue_quantity or 0 for r in baseline_records)
            baseline_days = (baseline_end - params.start).days + 1
            baseline_average_daily = baseline_total / baseline_days
            absolute_difference = current_average_daily - baseline_average_daily
            percentage_difference = (absolute_difference / baseline_average_daily * 100) if baseline_average_daily != 0 else None
        else:
            baseline_total = None
            baseline_average_daily = None
            absolute_difference = None
            percentage_difference = None

        daily_totals: dict[date, list[int]] = {}
        for r in usable:
            bucket = daily_totals.setdefault(r.release_date, [0, 0])
            bucket[0] += r.issue_quantity or 0
            bucket[1] += 1
        daily_series = [
            WBIssueTrendDailyPoint(release_date=d, total_issue_quantity=totals[0], record_count=totals[1])
            for d, totals in sorted(daily_totals.items())
        ]

        # Phase WB-3B (item 8): additive recurrence/persistence/consecutive
        # fields, computed via the shared helper -- `current_date=params.end`
        # (single latest day), distinct from `current_period_days` above
        # (which may span multiple trailing days for the pre-existing
        # current_period_total/average fields).
        daily_values = {d: float(totals[0]) for d, totals in daily_totals.items()}
        metrics = compute_historical_metrics(
            daily_values, current_date=params.end, window_start=params.start, is_abnormal=below_self_baseline_is_abnormal
        )

        scope = WBQueryScope(plant_id=params.plant_id, release_date_start=params.start, release_date_end=params.end)
        result = WBIssueTrendAnalysisResult(
            scope=scope,
            availability=compute_availability(records, freshness, validation_issues=validation_outcome.issues, usable_record_count=validation_outcome.usable_record_count),
            current_period_start=current_start, current_period_end=params.end,
            current_period_total=current_total, current_period_average_daily=current_average_daily,
            baseline_period_start=params.start if baseline_records else None,
            baseline_period_end=baseline_end if baseline_records else None,
            baseline_period_total=baseline_total, baseline_period_average_daily=baseline_average_daily,
            absolute_difference=absolute_difference, percentage_difference=percentage_difference,
            trend_direction=_classify_trend(percentage_difference),
            daily_series=daily_series,
            observed_days=metrics.observed_days, abnormal_days=metrics.abnormal_days,
            recurrence_count=metrics.recurrence_count, persistence_ratio=metrics.persistence_ratio,
            consecutive_abnormal_days=metrics.consecutive_abnormal_days,
        )
        direction_clause = f", trend {result.trend_direction.value}" if baseline_records else ""
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.issue_trend_analysis_result", result),
            summary=f"WB Issue trend for {params.plant_id}: current-period avg {current_average_daily:.0f}/day{direction_clause}.",
            quality=EvidenceQuality.STRONG if records else EvidenceQuality.WEAK,
        )
