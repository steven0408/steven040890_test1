"""Standalone WB Tool registration (Phase WB-2A item N).

**Architecture gap found and reported, not silently worked around**: the
only "register a domain's wiring in one place" mechanism this codebase
has is `ModulePackage` (Phase 8B-1, `agent/modules/models.py`), and a
`ModulePackage` requires a `policy_factory: Callable[[], ModulePlanningPolicy]`
-- i.e. it assumes a real Module/Policy exists. This phase explicitly
forbids creating a WB Module/Policy/Skill, so no `ModulePackage` can be
built yet, and this registration deliberately does NOT touch
`agent/bootstrap.py` (also explicitly forbidden this phase).

**Resolution (minimal, additive, no fake Module)**: a plain function with
the EXACT same signature shape a future `ModulePackage.tool_registrations`
field already expects (`Callable[[ToolRegistry], None]`) -- so when a
later phase does build a real WB `ModulePackage`, wiring this in is a
one-line change (`tool_registrations=lambda registry: register_wb_tools(registry, datasources=...)`),
not a rewrite. Until then, this function is called directly by tests
(and, if a caller wants a standalone WB ToolRegistry outside of
bootstrap, by that caller) -- never from the composition root.
"""
from dataclasses import dataclass

from agent.domain.wb.datasource import (
    WBBankDataSource,
    WBIssueDataSource,
    WBPlantOEEDataSource,
    WBStageOutputDataSource,
    WBWIPDataSource,
)
from agent.domain.wb.tool_results import register_wb_tool_result_payloads
from agent.tools.registry import ToolRegistry
from agent.tools.wb.bank_tools import (
    AnalyzeWBBankAgingTool,
    AnalyzeWBBankShortageTrendTool,
    QueryWBBankTool,
    SummarizeWBBankStatusTool,
    register_wb_bank_input_payloads,
)
from agent.tools.wb.cross_source_tools import AnalyzeWBIssueVsOutputTool, register_wb_cross_source_input_payloads
from agent.tools.wb.issue_tools import (
    AnalyzeWBIssueTrendTool,
    QueryWBIssueTool,
    SummarizeWBIssueTool,
    register_wb_issue_input_payloads,
)
from agent.tools.wb.oee_tools import AnalyzeWBOEELossTool, AnalyzeWBOEETrendTool, QueryWBPlantOEETool, register_wb_oee_input_payloads
from agent.tools.wb.output_tools import (
    AnalyzeWBOutputTrendTool,
    CompareWBStageOutputTool,
    QueryWBStageOutputTool,
    SummarizeWBStageOutputTool,
    register_wb_output_input_payloads,
)
from agent.tools.wb.wip_tools import (
    AnalyzeWBHoldTool,
    AnalyzeWBWIPHoldTrendTool,
    QueryWBWIPTool,
    SummarizeWBWIPTool,
    register_wb_wip_input_payloads,
)


@dataclass(frozen=True)
class WBDataSources:
    """The 5 canonical WB DataSource Protocols a caller injects -- an
    `InMemoryWB*DataSource` (this phase, tests) or a `RemoteWB*DataSource`
    (a future phase) satisfy the exact same Protocols
    (`agent/domain/wb/datasource.py`), so nothing here or in any WB Tool
    changes when that swap eventually happens. `issue` added Phase WB-3A."""

    oee: WBPlantOEEDataSource
    bank: WBBankDataSource
    wip: WBWIPDataSource
    output: WBStageOutputDataSource
    issue: WBIssueDataSource


def register_wb_payloads() -> None:
    """Explicit registration (Phase WB Data Layer V1's own discipline,
    extended here to Tool input/output payload types) -- call once before
    any WB Tool runs, never at import time."""
    register_wb_tool_result_payloads()
    register_wb_oee_input_payloads()
    register_wb_bank_input_payloads()
    register_wb_wip_input_payloads()
    register_wb_output_input_payloads()
    register_wb_issue_input_payloads()
    register_wb_cross_source_input_payloads()


def register_wb_tools(tool_registry: ToolRegistry, *, datasources: WBDataSources) -> None:
    """Registers all 19 WB Tools. Matches `Callable[[ToolRegistry], None]`
    -- the exact shape `ModulePackage.tool_registrations` already expects
    -- via a small wrapper closure a future WB ModulePackage would supply
    (see this module's own docstring). Phase WB-3B adds 5 historical trend
    Tools (one per source) + the first cross-source Tool
    (`AnalyzeWBIssueVsOutputTool`, the only Tool here constructed from TWO
    `WBDataSources` fields at once)."""
    register_wb_payloads()

    tool_registry.register(QueryWBPlantOEETool(datasources.oee))
    tool_registry.register(AnalyzeWBOEELossTool(datasources.oee))
    tool_registry.register(AnalyzeWBOEETrendTool(datasources.oee))

    tool_registry.register(QueryWBBankTool(datasources.bank))
    tool_registry.register(SummarizeWBBankStatusTool(datasources.bank))
    tool_registry.register(AnalyzeWBBankAgingTool(datasources.bank))
    tool_registry.register(AnalyzeWBBankShortageTrendTool(datasources.bank))

    tool_registry.register(QueryWBWIPTool(datasources.wip))
    tool_registry.register(SummarizeWBWIPTool(datasources.wip))
    tool_registry.register(AnalyzeWBHoldTool(datasources.wip))
    tool_registry.register(AnalyzeWBWIPHoldTrendTool(datasources.wip))

    tool_registry.register(QueryWBStageOutputTool(datasources.output))
    tool_registry.register(SummarizeWBStageOutputTool(datasources.output))
    tool_registry.register(CompareWBStageOutputTool(datasources.output))
    tool_registry.register(AnalyzeWBOutputTrendTool(datasources.output))

    tool_registry.register(QueryWBIssueTool(datasources.issue))
    tool_registry.register(SummarizeWBIssueTool(datasources.issue))
    tool_registry.register(AnalyzeWBIssueTrendTool(datasources.issue))

    tool_registry.register(AnalyzeWBIssueVsOutputTool(datasources.issue, datasources.output))
