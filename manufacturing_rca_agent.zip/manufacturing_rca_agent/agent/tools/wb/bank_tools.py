"""WB Bank Tools (Phase WB-2A item C2). Depend on `WBBankDataSource`
only. BANK is a snapshot dataset (Phase WB Data Layer V1) -- every tool
here defaults to `latest_snapshot_only=True` (item M's frozen rule),
selecting the single latest `source_sync_time` among whatever the
DataSource returns for `snapshot_date`, entirely in the Tool layer (no
DataSource contract change -- see `agent/tools/wb/_common.py::select_latest_snapshot`).
"""
from datetime import date, timedelta

from agent.domain.wb.datasource import WBBankDataSource
from agent.domain.wb.historical import bank_shortage_ratio_is_abnormal, compute_historical_metrics
from agent.domain.wb.models import WBBankRecord, WBBankStatus
from agent.domain.wb.tool_results import (
    WBBankAgingAnalysisResult,
    WBBankAgingEntry,
    WBBankQueryResult,
    WBBankShortageTrendAnalysisResult,
    WBBankShortageTrendDailyPoint,
    WBBankStatusCount,
    WBBankStatusSummaryResult,
    WBQueryScope,
    compute_availability,
)
from agent.domain.wb.validation import apply_exclusions, check_scope_plant_mismatch, validate_bank_records
from agent.state.base import RCABaseModel
from agent.state.enums import ErrorType, EvidenceQuality, ObservationStatus
from agent.state.payload import PayloadRegistry
from agent.tools.models import ExecutionType, ToolCategory, ToolDefinition, ToolExecutionRequest, ToolExecutionResult, ToolIOSchema, ToolSideEffect
from agent.tools.wb._common import map_wb_datasource_error, select_latest_snapshot, sorted_group_counts


class WBBankQueryInput(RCABaseModel):
    snapshot_date: date | None = None
    plant_id: str | None = None
    status: str | None = None  # a WBBankStatus value, e.g. "material_shortage"
    customer_code: str | None = None
    package_code: str | None = None
    device: str | None = None
    latest_snapshot_only: bool = True


class WBBankStatusSummaryInput(RCABaseModel):
    snapshot_date: date | None = None
    plant_id: str | None = None
    latest_snapshot_only: bool = True
    # Phase WB-3F.1: additive optional pre-filter, same pattern plant_id
    # already uses -- WBBankRecord.customer_code is a real canonical field
    # (already exposed on the raw, orphaned QueryWBBankTool), never a fake
    # dimension invented for this phase.
    customer_code: str | None = None
    # Phase WB-3F.1 (item 31): allow-listed breakdown selection -- None/[]
    # preserves the exact pre-existing behavior (all three breakdowns
    # computed, unconditionally, matching every WBPlanningPolicy/test
    # expectation that predates this field); a non-empty list narrows to
    # only the requested breakdown(s). Never an arbitrary pandas group-by
    # engine -- only "plant"/"package"/"device" are ever recognized
    # (enforced by the Planner-side semantic validator against this
    # Skill's own `accepted_scope_dimensions`, see agent/planning/
    # policies/llm.py's `_validate_scope`).
    group_by: list[str] = []


class WBBankAgingAnalysisInput(RCABaseModel):
    snapshot_date: date | None = None
    plant_id: str | None = None
    latest_snapshot_only: bool = True
    top_n: int = 10


class WBBankShortageTrendAnalysisInput(RCABaseModel):
    """Item 11: focused on material_shortage specifically. Snapshot
    semantic (item 10) -- `start`/`end` bound `snapshot_date`."""

    plant_id: str
    start: date
    end: date
    latest_snapshot_only: bool = True


def register_wb_bank_input_payloads() -> None:
    PayloadRegistry.register("wb.bank_query_input", WBBankQueryInput)
    PayloadRegistry.register("wb.bank_status_summary_input", WBBankStatusSummaryInput)
    PayloadRegistry.register("wb.bank_aging_analysis_input", WBBankAgingAnalysisInput)
    PayloadRegistry.register("wb.bank_shortage_trend_analysis_input", WBBankShortageTrendAnalysisInput)


def _fetch(
    datasource: WBBankDataSource, *, snapshot_date: date | None, plant_id: str | None, latest_snapshot_only: bool, customer_code: str | None = None
) -> list[WBBankRecord]:
    records = datasource.list_bank(snapshot_date=snapshot_date)
    if plant_id is not None:
        records = [r for r in records if r.plant_id == plant_id]
    if customer_code is not None:
        records = [r for r in records if r.customer_code == customer_code]
    if latest_snapshot_only:
        records = select_latest_snapshot(records)
    return records


class QueryWBBankTool:
    def __init__(self, datasource: WBBankDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="query_wb_bank", name="Query WB Bank",
            description="Retrieve WB Bank records, optionally filtered by snapshot_date/plant/status/customer/package/device.",
            category=ToolCategory.QUERY, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBBankQueryInput"), output_schema=ToolIOSchema(model_name="WBBankQueryResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.bank_query_input", output_payload_type="wb.bank_query_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBBankQueryInput)
        try:
            records = _fetch(self._datasource, snapshot_date=params.snapshot_date, plant_id=params.plant_id, latest_snapshot_only=params.latest_snapshot_only)
            if params.status is not None:
                records = [r for r in records if r.bank_status.value == params.status]
            if params.customer_code is not None:
                records = [r for r in records if r.customer_code == params.customer_code]
            if params.package_code is not None:
                records = [r for r in records if r.package_code == params.package_code]
            if params.device is not None:
                records = [r for r in records if r.device == params.device]
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        # Phase WB-3D: a raw QUERY tool reports validation issues but never
        # excludes a record from its own output (matches every other WB
        # Query Tool's own convention this phase).
        _, outcome = validate_bank_records(records, requested_plant=params.plant_id)
        scope = WBQueryScope(plant_id=params.plant_id, snapshot_date=params.snapshot_date, latest_snapshot_only=params.latest_snapshot_only, status_filter=params.status, customer_code=params.customer_code, package_code=params.package_code, device=params.device)
        result = WBBankQueryResult(
            scope=scope,
            availability=compute_availability(records, freshness, validation_issues=outcome.issues, usable_record_count=outcome.usable_record_count),
            records=records,
        )
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.bank_query_result", result),
            summary=f"Queried {len(records)} WB Bank record(s).", quality=EvidenceQuality.STRONG if records else EvidenceQuality.WEAK,
        )


_BANK_ALLOWED_GROUP_BY = {"plant", "package", "device"}


class SummarizeWBBankStatusTool:
    def __init__(self, datasource: WBBankDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="summarize_wb_bank_status", name="Summarize WB Bank Status",
            description="Status distribution (Ready To Issue / Material Shortage / No Wafer In / Unknown) for a BANK snapshot, grouped by plant/package/device.",
            category=ToolCategory.CALCULATION, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBBankStatusSummaryInput"), output_schema=ToolIOSchema(model_name="WBBankStatusSummaryResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.bank_status_summary_input", output_payload_type="wb.bank_status_summary_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBBankStatusSummaryInput)
        # Phase WB-3F.1 (item 34): reject an unsupported group_by entry
        # outright rather than silently computing an empty/degraded
        # breakdown -- this Skill's own `accepted_scope_dimensions`
        # (plant/customer/package/device) is deliberately reused for both
        # filter- and group_by-acceptance (item 35's documented
        # duplication-avoidance choice), so a Planner-level dimension name
        # like "customer" can pass that coarser check without being a real
        # groupable breakdown here -- this Tool-level allow-list is the
        # actual, precise enforcement point for THIS tool's group_by.
        unsupported_group_by = set(params.group_by) - _BANK_ALLOWED_GROUP_BY
        if unsupported_group_by:
            return ToolExecutionResult(
                status=ObservationStatus.ERROR,
                error_type=ErrorType.INVALID_QUERY,
                error_message=f"summarize_wb_bank_status does not support group_by dimension(s) {sorted(unsupported_group_by)} -- supported: {sorted(_BANK_ALLOWED_GROUP_BY)}",
            )
        try:
            records = _fetch(
                self._datasource, snapshot_date=params.snapshot_date, plant_id=params.plant_id,
                latest_snapshot_only=params.latest_snapshot_only, customer_code=params.customer_code,
            )
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        # Phase WB-3D (item 31): status distribution is a COUNT metric,
        # never reads wafer/die quantity -- only a genuine scope mismatch
        # excludes a record here. Quantity is still validated (and
        # reported) as a real data-quality signal, just never used to
        # exclude from THIS count-based calculation.
        scope_bad, scope_issues = check_scope_plant_mismatch(records, get_plant_id=lambda r: r.plant_id, requested_plant=params.plant_id)
        scope_usable = apply_exclusions(records, scope_bad).usable
        _, quantity_outcome = validate_bank_records(scope_usable, requested_plant=None)
        issues = scope_issues + quantity_outcome.issues

        total = len(scope_usable)
        counts: dict[WBBankStatus, int] = {}
        for r in scope_usable:
            counts[r.bank_status] = counts.get(r.bank_status, 0) + 1
        # deterministic order: iterate the enum's own declaration order, never dict insertion order
        by_status = [WBBankStatusCount(status=s, count=counts[s], ratio=counts[s] / total) for s in WBBankStatus if s in counts]

        # Phase WB-3F.1 (item 31): empty/unset group_by preserves the exact
        # pre-existing behavior -- all three breakdowns computed
        # unconditionally, matching every caller/test that predates this
        # field. A non-empty group_by narrows to only the requested
        # breakdown(s); an unrecognized entry is silently excluded HERE
        # (the Planner-side semantic validator, not this Tool, is where an
        # unsupported dimension is rejected -- see `_validate_scope` in
        # agent/planning/policies/llm.py -- this Tool only ever computes
        # what's allow-listed by its own if/else below, never an arbitrary
        # caller-supplied grouping expression).
        requested = set(params.group_by) if params.group_by else {"plant", "package", "device"}
        scope = WBQueryScope(plant_id=params.plant_id, snapshot_date=params.snapshot_date, latest_snapshot_only=params.latest_snapshot_only, customer_code=params.customer_code)
        result = WBBankStatusSummaryResult(
            scope=scope,
            availability=compute_availability(records, freshness, validation_issues=issues, usable_record_count=len(scope_usable)),
            total_count=total, by_status=by_status,
            by_plant=sorted_group_counts(scope_usable, lambda r: r.plant_id) if "plant" in requested else {},
            by_package=sorted_group_counts(scope_usable, lambda r: r.package_code) if "package" in requested else {},
            by_device=sorted_group_counts(scope_usable, lambda r: r.device) if "device" in requested else {},
        )
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.bank_status_summary_result", result),
            summary=f"Summarized {total} WB Bank record(s) across {len(by_status)} status categor(y/ies).",
            quality=EvidenceQuality.STRONG if records else EvidenceQuality.WEAK,
        )


class AnalyzeWBBankAgingTool:
    """Item M's own caution honored directly: aging (`source_sync_time -
    bank_entry_time`) is computed ONLY where `bank_entry_time` (raw
    `status_50`) is present. A record missing it is counted in
    `records_with_unknown_aging`, never assigned a guessed/zero value."""

    def __init__(self, datasource: WBBankDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="analyze_wb_bank_aging", name="Analyze WB Bank Aging",
            description="How long BANK lots have sat since bank_entry_time, where that field is known.",
            category=ToolCategory.CALCULATION, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBBankAgingAnalysisInput"), output_schema=ToolIOSchema(model_name="WBBankAgingAnalysisResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.bank_aging_analysis_input", output_payload_type="wb.bank_aging_analysis_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBBankAgingAnalysisInput)
        try:
            records = _fetch(self._datasource, snapshot_date=params.snapshot_date, plant_id=params.plant_id, latest_snapshot_only=params.latest_snapshot_only)
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        # Phase WB-3D: aging is computed from timestamps, never wafer/die
        # quantity -- only a genuine scope mismatch excludes a record here.
        scope_bad, scope_issues = check_scope_plant_mismatch(records, get_plant_id=lambda r: r.plant_id, requested_plant=params.plant_id)
        scope_usable = apply_exclusions(records, scope_bad).usable
        _, quantity_outcome = validate_bank_records(scope_usable, requested_plant=None)
        validation_issues = scope_issues + quantity_outcome.issues

        entries: list[WBBankAgingEntry] = []
        known_hours: list[float] = []
        unknown_count = 0
        for r in scope_usable:
            if r.bank_entry_time is None:
                unknown_count += 1
                entries.append(WBBankAgingEntry(plant_id=r.plant_id, mother_batch_id=r.mother_batch_id, bank_status=r.bank_status, aging_hours=None))
                continue
            aging_hours = (r.source_sync_time - r.bank_entry_time).total_seconds() / 3600.0
            known_hours.append(aging_hours)
            entries.append(WBBankAgingEntry(plant_id=r.plant_id, mother_batch_id=r.mother_batch_id, bank_status=r.bank_status, aging_hours=aging_hours))

        # Sorted descending by aging_hours (unknown/None sorts last), ties broken by mother_batch_id ascending.
        entries.sort(key=lambda e: (e.aging_hours is None, -(e.aging_hours or 0.0), e.mother_batch_id))
        longest = entries[: params.top_n]

        limitations = []
        if unknown_count:
            limitations.append(f"{unknown_count} record(s) have no bank_entry_time (status_50) -- aging could not be computed for them.")

        scope = WBQueryScope(plant_id=params.plant_id, snapshot_date=params.snapshot_date, latest_snapshot_only=params.latest_snapshot_only)
        result = WBBankAgingAnalysisResult(
            scope=scope,
            availability=compute_availability(records, freshness, limitations=limitations, validation_issues=validation_issues, usable_record_count=len(scope_usable)),
            records_with_known_aging=len(known_hours), records_with_unknown_aging=unknown_count,
            average_aging_hours=(sum(known_hours) / len(known_hours)) if known_hours else None,
            max_aging_hours=max(known_hours) if known_hours else None,
            longest_aging_entries=longest, limitations=limitations,
        )
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.bank_aging_analysis_result", result),
            summary=f"Computed aging for {len(known_hours)}/{len(records)} WB Bank record(s)" + (f"; {unknown_count} unknown" if unknown_count else "") + ".",
            quality=EvidenceQuality.STRONG if known_hours else EvidenceQuality.WEAK,
        )


class AnalyzeWBBankShortageTrendTool:
    """Phase WB-3B. Focused on `material_shortage` specifically (item 11)
    -- never merges `Ready To Issue`/`No Wafer In` into one undifferentiated
    "bad" bucket. One representative snapshot per calendar day, same
    per-day `select_latest_snapshot` convention as WIP's trend Tool.
    `bank_shortage_ratio_is_abnormal` is a fixed, documented absolute
    threshold (mirrors Phase WB-2D's own RCA threshold exactly)."""

    def __init__(self, datasource: WBBankDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="analyze_wb_bank_shortage_trend", name="Analyze WB Bank Shortage Trend",
            description="Compare a WB plant's current material-shortage ratio against its own recent baseline, with recurrence/persistence of elevated-shortage snapshots. Descriptive only -- never a root-cause claim.",
            category=ToolCategory.CALCULATION, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBBankShortageTrendAnalysisInput"), output_schema=ToolIOSchema(model_name="WBBankShortageTrendAnalysisResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.bank_shortage_trend_analysis_input", output_payload_type="wb.bank_shortage_trend_analysis_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBBankShortageTrendAnalysisInput)
        try:
            all_records: list[WBBankRecord] = []
            daily_points: list[WBBankShortageTrendDailyPoint] = []
            daily_values: dict[date, float] = {}
            all_validation_issues = []
            cursor = params.start
            while cursor <= params.end:
                day_records = _fetch(self._datasource, snapshot_date=cursor, plant_id=params.plant_id, latest_snapshot_only=params.latest_snapshot_only)
                if day_records:
                    # Phase WB-3D (item 31): shortage ratio is a COUNT
                    # metric, never reads wafer/die quantity -- only a
                    # genuine scope mismatch excludes a record here.
                    day_scope_bad, day_scope_issues = check_scope_plant_mismatch(day_records, get_plant_id=lambda r: r.plant_id, requested_plant=params.plant_id)
                    day_usable = apply_exclusions(day_records, day_scope_bad).usable
                    _, day_quantity_outcome = validate_bank_records(day_usable, requested_plant=None)
                    all_validation_issues += day_scope_issues + day_quantity_outcome.issues
                    shortage_records = [r for r in day_usable if r.bank_status == WBBankStatus.MATERIAL_SHORTAGE]
                    total = len(day_usable)
                    shortage = len(shortage_records)
                    ratio = (shortage / total) if total > 0 else None
                    daily_points.append(WBBankShortageTrendDailyPoint(snapshot_date=cursor, shortage_count=shortage, total_count=total, shortage_ratio=ratio))
                    if ratio is not None:
                        daily_values[cursor] = ratio
                    all_records.extend(day_records)
                cursor += timedelta(days=1)
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        metrics = compute_historical_metrics(daily_values, current_date=params.end, window_start=params.start, is_abnormal=bank_shortage_ratio_is_abnormal)

        scope = WBQueryScope(plant_id=params.plant_id, snapshot_date_start=params.start, snapshot_date_end=params.end, latest_snapshot_only=params.latest_snapshot_only)
        result = WBBankShortageTrendAnalysisResult(
            scope=scope, availability=compute_availability(all_records, freshness, validation_issues=all_validation_issues),
            metrics=metrics, daily_series=daily_points,
        )
        current_str = f"{metrics.current_value:.1%}" if metrics.current_value is not None else "N/A"
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.bank_shortage_trend_analysis_result", result),
            summary=f"WB Bank shortage trend for {params.plant_id}: current {current_str}, trend {metrics.trend_direction.value}.",
            quality=EvidenceQuality.STRONG if all_records else EvidenceQuality.WEAK,
        )
