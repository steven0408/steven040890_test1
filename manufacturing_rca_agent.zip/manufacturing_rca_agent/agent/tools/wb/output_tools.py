"""WB Stage Output Tools (Phase WB-2A item C4). Depend on
`WBStageOutputDataSource` only. OUTPUT is daily-like (`production_date`
is real, distinct from `source_sync_time` -- item 6/7), so no
latest-snapshot selection is needed here (that's a BANK/WIP-only concern).
"""
from datetime import date, timedelta

from agent.domain.wb.datasource import WBStageOutputDataSource
from agent.domain.wb.historical import below_self_baseline_is_abnormal, compute_historical_metrics
from agent.domain.wb.models import WBStageOutputRecord
from agent.domain.wb.tool_results import (
    WBOutputTrendAnalysisResult,
    WBOutputTrendDailyPoint,
    WBQueryScope,
    WBStageOutputComparisonEntry,
    WBStageOutputComparisonResult,
    WBStageOutputQueryResult,
    WBStageOutputSummaryResult,
    compute_availability,
)
from agent.domain.wb.validation import validate_output_records
from agent.state.base import RCABaseModel
from agent.state.enums import EvidenceQuality, ObservationStatus
from agent.state.payload import PayloadRegistry
from agent.tools.models import ExecutionType, ToolCategory, ToolDefinition, ToolExecutionRequest, ToolExecutionResult, ToolIOSchema, ToolSideEffect
from agent.tools.wb._common import map_wb_datasource_error, sorted_group_sums


class WBStageOutputQueryInput(RCABaseModel):
    production_date: date | None = None
    plant_id: str | None = None
    operation_id: str | None = None
    customer_code: str | None = None
    package_code: str | None = None
    device_type: str | None = None


class WBStageOutputSummaryInput(RCABaseModel):
    production_date: date | None = None
    plant_id: str | None = None
    operation_id: str | None = None


class WBStageOutputComparisonInput(RCABaseModel):
    # Phase WB-2B.1: restored to required -- same rationale as
    # WBOEELossAnalysisInput (agent/tools/wb/oee_tools.py). `wb.output_comparison`'s
    # own `required_scope_dimensions=[production_date]` (ObjectiveScope,
    # agent/state/scope.py) is what supplies it now; a comparison silently
    # summed across every recorded date was WB-2B's workaround, not the
    # intended business semantic (see the Phase WB-2B.1 report).
    production_date: date
    operation_id: str | None = None
    plant_ids: list[str] | None = None  # None = compare every plant present in scope


class WBOutputTrendAnalysisInput(RCABaseModel):
    plant_id: str
    operation_id: str | None = None
    start: date
    end: date


def register_wb_output_input_payloads() -> None:
    PayloadRegistry.register("wb.stage_output_query_input", WBStageOutputQueryInput)
    PayloadRegistry.register("wb.stage_output_summary_input", WBStageOutputSummaryInput)
    PayloadRegistry.register("wb.stage_output_comparison_input", WBStageOutputComparisonInput)
    PayloadRegistry.register("wb.output_trend_analysis_input", WBOutputTrendAnalysisInput)


def _filter(records: list[WBStageOutputRecord], *, plant_id: str | None, operation_id: str | None) -> list[WBStageOutputRecord]:
    result = records
    if plant_id is not None:
        result = [r for r in result if r.plant_id == plant_id]
    if operation_id is not None:
        result = [r for r in result if r.operation_id == operation_id]
    return result


class QueryWBStageOutputTool:
    def __init__(self, datasource: WBStageOutputDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="query_wb_stage_output", name="Query WB Stage Output",
            description="Retrieve WB Stage Output records, optionally filtered by production_date/plant/operation/customer/package/device_type.",
            category=ToolCategory.QUERY, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBStageOutputQueryInput"), output_schema=ToolIOSchema(model_name="WBStageOutputQueryResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.stage_output_query_input", output_payload_type="wb.stage_output_query_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBStageOutputQueryInput)
        try:
            records = self._datasource.list_output(production_date=params.production_date)
            records = _filter(records, plant_id=params.plant_id, operation_id=params.operation_id)
            if params.customer_code is not None:
                records = [r for r in records if r.customer_code == params.customer_code]
            if params.package_code is not None:
                records = [r for r in records if r.package_code == params.package_code]
            if params.device_type is not None:
                records = [r for r in records if r.device_type == params.device_type]
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        _, outcome = validate_output_records(records, requested_plant=params.plant_id, requested_start=params.production_date, requested_end=params.production_date)
        scope = WBQueryScope(plant_id=params.plant_id, operation_id=params.operation_id, production_date=params.production_date, customer_code=params.customer_code, package_code=params.package_code, device_type=params.device_type)
        result = WBStageOutputQueryResult(
            scope=scope,
            availability=compute_availability(records, freshness, validation_issues=outcome.issues, usable_record_count=outcome.usable_record_count),
            records=records,
        )
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.stage_output_query_result", result),
            summary=f"Queried {len(records)} WB Stage Output record(s).", quality=EvidenceQuality.STRONG if records else EvidenceQuality.WEAK,
        )


class SummarizeWBStageOutputTool:
    def __init__(self, datasource: WBStageOutputDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="summarize_wb_stage_output", name="Summarize WB Stage Output",
            description="Total output quantity for a production_date, grouped by plant/operation/product.",
            category=ToolCategory.CALCULATION, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBStageOutputSummaryInput"), output_schema=ToolIOSchema(model_name="WBStageOutputSummaryResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.stage_output_summary_input", output_payload_type="wb.stage_output_summary_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBStageOutputSummaryInput)
        try:
            records = self._datasource.list_output(production_date=params.production_date)
            records = _filter(records, plant_id=params.plant_id, operation_id=params.operation_id)
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        # Phase WB-3D: a negative output_quantity must never enter the
        # total/breakdown sums (item 8/29) -- excluded before summing,
        # never `abs()`-repaired (item 67).
        usable, outcome = validate_output_records(records, requested_plant=params.plant_id, requested_start=params.production_date, requested_end=params.production_date)
        total = sum(r.output_quantity or 0 for r in usable)
        scope = WBQueryScope(plant_id=params.plant_id, operation_id=params.operation_id, production_date=params.production_date)
        result = WBStageOutputSummaryResult(
            scope=scope,
            availability=compute_availability(records, freshness, validation_issues=outcome.issues, usable_record_count=outcome.usable_record_count),
            total_output_quantity=total,
            by_plant=sorted_group_sums(usable, lambda r: r.plant_id, lambda r: r.output_quantity),
            by_operation=sorted_group_sums(usable, lambda r: r.operation_id, lambda r: r.output_quantity),
            by_product=sorted_group_sums(usable, lambda r: r.device_type, lambda r: r.output_quantity),
        )
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.stage_output_summary_result", result),
            summary=f"Summarized {len(records)} WB Stage Output record(s), total quantity {total}.",
            quality=EvidenceQuality.STRONG if records else EvidenceQuality.WEAK,
        )


class CompareWBStageOutputTool:
    def __init__(self, datasource: WBStageOutputDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="compare_wb_stage_output", name="Compare WB Stage Output",
            description="Ranks plants by total output quantity for a production_date (+ optional operation), e.g. ASE01 vs ASE07.",
            category=ToolCategory.CALCULATION, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBStageOutputComparisonInput"), output_schema=ToolIOSchema(model_name="WBStageOutputComparisonResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.stage_output_comparison_input", output_payload_type="wb.stage_output_comparison_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBStageOutputComparisonInput)
        try:
            records = self._datasource.list_output(production_date=params.production_date)
            records = _filter(records, plant_id=None, operation_id=params.operation_id)
            if params.plant_ids is not None:
                records = [r for r in records if r.plant_id in params.plant_ids]
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        # Phase WB-3D: module-wide comparison -- no single requested plant
        # to reconcile scope against (a `plant_ids` allowlist, if given, is
        # already applied as a plain filter above, not a validation
        # concern); only quantity is validated here (never scope).
        usable, outcome = validate_output_records(records, requested_plant=None)
        totals = sorted_group_sums(usable, lambda r: r.plant_id, lambda r: r.output_quantity)
        entries = [WBStageOutputComparisonEntry(plant_id=plant_id, output_quantity=qty) for plant_id, qty in totals.items()]
        # Highest output first, ties broken by plant_id ascending -- deterministic.
        entries.sort(key=lambda e: (-e.output_quantity, e.plant_id))

        scope = WBQueryScope(operation_id=params.operation_id, production_date=params.production_date)
        result = WBStageOutputComparisonResult(
            scope=scope,
            availability=compute_availability(records, freshness, validation_issues=outcome.issues, usable_record_count=outcome.usable_record_count),
            comparison=entries,
            highest=entries[0] if entries else None, lowest=entries[-1] if entries else None,
        )
        date_clause = f" for {params.production_date.isoformat()}" if params.production_date else " across every recorded date"
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.stage_output_comparison_result", result),
            summary=f"Compared {len(entries)} plant(s){date_clause}.",
            quality=EvidenceQuality.STRONG if entries else EvidenceQuality.WEAK,
        )


class AnalyzeWBOutputTrendTool:
    """Phase WB-3B. `below_self_baseline_is_abnormal` -- OUTPUT has no
    domain-independent "low" value (unlike OEE/WIP/BANK's fixed
    thresholds), so abnormality is relative to this window's own computed
    baseline, exactly like ISSUE's own trend Tool."""

    def __init__(self, datasource: WBStageOutputDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="analyze_wb_output_trend", name="Analyze WB Output Trend",
            description="Compare a WB plant's current Stage Output against its own recent baseline, with recurrence/persistence of below-baseline days. Descriptive only -- never a causal claim.",
            category=ToolCategory.CALCULATION, domains=["wb"],
            input_schema=ToolIOSchema(model_name="WBOutputTrendAnalysisInput"), output_schema=ToolIOSchema(model_name="WBOutputTrendAnalysisResult"),
            execution_type=ExecutionType.DETERMINISTIC, side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="wb.output_trend_analysis_input", output_payload_type="wb.output_trend_analysis_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, WBOutputTrendAnalysisInput)
        try:
            records = self._datasource.list_output(production_date=None)
            records = _filter(records, plant_id=params.plant_id, operation_id=params.operation_id)
            records = [r for r in records if params.start <= r.production_date <= params.end]
            freshness = self._datasource.freshness()
        except Exception as exc:
            error_type, message = map_wb_datasource_error(exc)
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=error_type, error_message=message)

        # Phase WB-3D: a negative output_quantity must never enter the
        # daily trend series (item 8/29/42) -- excluded before the daily
        # totals are built, never `abs()`-repaired (item 67).
        usable, outcome = validate_output_records(records, requested_plant=params.plant_id, requested_start=params.start, requested_end=params.end)

        daily_totals: dict[date, int] = {}
        for r in usable:
            daily_totals[r.production_date] = daily_totals.get(r.production_date, 0) + (r.output_quantity or 0)
        daily_points = [WBOutputTrendDailyPoint(production_date=d, output_quantity=q) for d, q in sorted(daily_totals.items())]
        daily_values = {d: float(q) for d, q in daily_totals.items()}

        metrics = compute_historical_metrics(daily_values, current_date=params.end, window_start=params.start, is_abnormal=below_self_baseline_is_abnormal)

        scope = WBQueryScope(plant_id=params.plant_id, operation_id=params.operation_id, production_date_start=params.start, production_date_end=params.end)
        result = WBOutputTrendAnalysisResult(
            scope=scope,
            availability=compute_availability(records, freshness, validation_issues=outcome.issues, usable_record_count=outcome.usable_record_count),
            metrics=metrics, daily_series=daily_points,
        )
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS, payload=PayloadRegistry.pack("wb.output_trend_analysis_result", result),
            summary=f"WB Output trend for {params.plant_id}: current {metrics.current_value}, trend {metrics.trend_direction.value}.",
            quality=EvidenceQuality.STRONG if records else EvidenceQuality.WEAK,
        )
