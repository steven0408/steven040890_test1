from agent.state.enums import ErrorType, ObservationStatus
from agent.state.models import Objective
from agent.tools.base import ToolResult


class ScriptedMockTool:
    """Deterministic tool for tests: maps an objective's `target_ref.ref_id`
    (the "source" being queried) to a scripted ToolResult. Any source not
    present in the script returns DATA_NOT_FOUND, so a typo in a test's
    script fails loudly instead of silently succeeding.
    """

    def __init__(self, script: dict[str, ToolResult]):
        self._script = script

    def run(self, objective: Objective) -> ToolResult:
        source = objective.target_ref.ref_id
        if source in self._script:
            return self._script[source]
        return ToolResult(
            status=ObservationStatus.ERROR,
            error_type=ErrorType.DATA_NOT_FOUND,
            error_message=f"no scripted result for source '{source}'",
        )
