from agent.domain.oee.dataset import EquipmentDetail, EquipmentRecord, EquipmentSnapshot, ScreeningResult
from agent.state.enums import ErrorType, EvidenceQuality, ObjectiveAction, ObservationStatus
from agent.state.models import Objective
from agent.state.payload import PayloadRegistry
from agent.tools.base import ToolResult


class OEEDataTool:
    """Deterministic stand-in for a real OEE data source. Understands two
    Objective actions:

      - ObjectiveAction.SCREEN -> ScreeningResult (A/P/Q for
        every equipment, no downtime/failure detail)
      - ObjectiveAction.DRILL_DOWN    -> EquipmentDetail (downtime/
        failure detail for one equipment, identified by the canonical
        `target_ref.ref_id`, e.g. "EQ001")

    Dispatches on `objective.action`, not on parsing `target_ref.ref_id`
    (Phase 5C-2.1: `action` is WHAT to do, `target_ref` is only ever WHO/
    WHAT to act on -- never an action-prefixed compound string like the old
    "equipment_detail:EQ001").

    `unavailable_targets` lets tests simulate specific queries being down
    (DATA_NOT_FOUND) without faking the whole dataset -- e.g. the downtime
    detail system being unreachable while screening still works. Holds
    canonical `target_ref.ref_id` values (the module_type for a screening
    objective, or the bare equipment id for a detail objective).
    """

    def __init__(
        self,
        equipment: list[EquipmentRecord],
        threshold: float,
        unavailable_targets: frozenset[str] = frozenset(),
    ):
        self._equipment = equipment
        self._by_id = {e.equipment_id: e for e in equipment}
        self._threshold = threshold
        self._unavailable_targets = unavailable_targets

    def run(self, objective: Objective) -> ToolResult:
        target_ref_id = objective.target_ref.ref_id

        if target_ref_id in self._unavailable_targets:
            return ToolResult(
                status=ObservationStatus.ERROR,
                error_type=ErrorType.DATA_NOT_FOUND,
                error_message=f"OEE data source unavailable for '{target_ref_id}'",
            )

        if objective.action == ObjectiveAction.SCREEN:
            result = ScreeningResult(
                threshold=self._threshold,
                equipment=[
                    EquipmentSnapshot(
                        equipment_id=e.equipment_id,
                        oee=e.oee,
                        availability=e.availability,
                        performance=e.performance,
                        quality=e.quality,
                        production_weight=e.production_weight,
                    )
                    for e in self._equipment
                ],
            )
            abnormal_count = sum(1 for e in result.equipment if e.oee < result.threshold)
            return ToolResult(
                status=ObservationStatus.SUCCESS,
                payload_summary=(
                    f"Screened {len(result.equipment)} equipment against a {result.threshold:.0%} "
                    f"OEE threshold; {abnormal_count} abnormal."
                ),
                structured_payload=PayloadRegistry.pack("oee.screening_result", result),
                quality=EvidenceQuality.STRONG,
            )

        if objective.action == ObjectiveAction.DRILL_DOWN:
            equipment_id = target_ref_id
            record = self._by_id.get(equipment_id)
            if record is None:
                return ToolResult(
                    status=ObservationStatus.ERROR,
                    error_type=ErrorType.DATA_NOT_FOUND,
                    error_message=f"no such equipment '{equipment_id}'",
                )
            detail = EquipmentDetail(
                equipment_id=equipment_id,
                downtime_minutes=record.downtime_minutes,
                downtime_reason=record.downtime_reason,
                failure_reason=record.failure_reason,
            )
            return ToolResult(
                status=ObservationStatus.SUCCESS,
                payload_summary=(
                    f"{equipment_id} downtime detail: {detail.downtime_minutes} min, "
                    f"reason={detail.downtime_reason}, failure={detail.failure_reason}."
                ),
                structured_payload=PayloadRegistry.pack("oee.equipment_detail", detail),
                quality=EvidenceQuality.STRONG,
            )

        return ToolResult(
            status=ObservationStatus.ERROR,
            error_type=ErrorType.DATA_NOT_FOUND,
            error_message=f"unknown OEE objective action '{objective.action.value}'",
        )
