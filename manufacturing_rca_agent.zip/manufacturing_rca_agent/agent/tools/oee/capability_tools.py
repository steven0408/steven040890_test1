"""Concrete OEE Tools for the Phase 5B-2 capability layer -- the new `Tool`
Protocol (agent/tools/models.py: `run(ToolExecutionRequest) ->
ToolExecutionResult`, typed StructuredPayload in/out), distinct from the
legacy `MockTool` (`run(objective) -> ToolResult`, agent/tools/base.py) that
`agent.tools.mocks.oee_data_tool.OEEDataTool` still implements for the
pre-5B-2 direct-tool Module Executor path.

`query_oee_data` and `query_equipment_detail` deliberately reproduce
`OEEDataTool`'s exact query semantics (same dataset, same "unavailable
target" simulation) -- the RCA path's single-step Skills wrap these to
reach byte-for-byte the same Evidence shape `OEEPlanningPolicy` already
consumes, so Phase 5A's COMPLETE/PARTIAL/FAILED behavior is unchanged
whether an OEE module runs through the legacy direct-tool executor or the
new capability-routed one.
"""
from agent.domain.oee.dataset import (
    ContributionItem,
    ContributionResult,
    CurrentOEEStatus,
    EquipmentDetail,
    EquipmentSnapshot,
    PatternGroup,
    RankedScreeningResult,
    ScreeningResult,
    pattern_of,
)
from agent.domain.oee.datasource import EquipmentNotFoundError, OEEDataSource, OEEDataUnavailableError
from agent.planning.contribution import ContributionInputs, DefaultContributionScorer
from agent.state.base import RCABaseModel
from agent.state.enums import ErrorType, EvidenceQuality, ObservationStatus
from agent.state.payload import PayloadRegistry
from agent.tools.models import (
    ExecutionType,
    ToolCategory,
    ToolDefinition,
    ToolExecutionRequest,
    ToolExecutionResult,
    ToolIOSchema,
    ToolSideEffect,
)

# --- Tool input contracts ---------------------------------------------------


class OEEQueryInput(RCABaseModel):
    """Zero fields on purpose -- `query_oee_data` takes no parameters."""


class EquipmentDetailQueryInput(RCABaseModel):
    # canonical objective.target_ref.ref_id (Phase 5C-2.1) -- the bare
    # equipment id, e.g. "EQ001", never an action-prefixed compound string
    equipment_id: str


class FilterRowsInput(RCABaseModel):
    threshold: float
    equipment: list[EquipmentSnapshot]


class ContributionInput(RCABaseModel):
    threshold: float
    equipment: list[EquipmentSnapshot]


class RankingInput(RCABaseModel):
    threshold: float
    items: list[ContributionItem]


def register_oee_input_payloads() -> None:
    """Phase 8B-1 item F: explicit registration (paired with
    `agent.domain.oee.dataset.register_oee_result_payloads`), called once
    by the OEE ModulePackage -- never at import time."""
    PayloadRegistry.register("oee.query_input", OEEQueryInput)
    PayloadRegistry.register("oee.equipment_detail_query_input", EquipmentDetailQueryInput)
    PayloadRegistry.register("oee.filter_rows_input", FilterRowsInput)
    PayloadRegistry.register("oee.contribution_input", ContributionInput)
    PayloadRegistry.register("oee.ranking_input", RankingInput)


# --- Tools -------------------------------------------------------------------


class QueryOEEDataTool:
    """Phase 8B-1 Part D: depends on `OEEDataSource`, never a raw
    `list[EquipmentRecord]` -- the Tool no longer knows or cares whether
    the data comes from `MOCK_EQUIPMENT`, a file, or a remote DB. Swapping
    `InMemoryOEEDataSource` for a future real adapter requires zero
    changes here."""

    def __init__(self, datasource: OEEDataSource, threshold: float):
        self._datasource = datasource
        self._threshold = threshold
        self.definition = ToolDefinition(
            tool_id="query_oee_data",
            name="Query OEE Data",
            description="Fetch A/P/Q/OEE for every equipment (raw, unfiltered).",
            category=ToolCategory.QUERY,
            domains=["oee"],
            input_schema=ToolIOSchema(model_name="OEEQueryInput"),
            output_schema=ToolIOSchema(model_name="ScreeningResult"),
            execution_type=ExecutionType.DETERMINISTIC,
            side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="oee.query_input",
            output_payload_type="oee.screening_result",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        PayloadRegistry.unpack(request.parameters)  # validates shape; OEEQueryInput carries no data
        try:
            equipment = self._datasource.list_equipment()
        except OEEDataUnavailableError:
            return ToolExecutionResult(
                status=ObservationStatus.ERROR,
                error_type=ErrorType.DATA_NOT_FOUND,
                error_message="OEE data source unavailable for 'screen_equipment'",
            )
        result = ScreeningResult(
            threshold=self._threshold,
            equipment=[
                EquipmentSnapshot(
                    equipment_id=e.equipment_id,
                    oee=e.oee,
                    availability=e.availability,
                    performance=e.performance,
                    quality=e.quality,
                    production_weight=e.production_weight,
                )
                for e in equipment
            ],
        )
        abnormal_count = sum(1 for e in result.equipment if e.oee < result.threshold)
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS,
            payload=PayloadRegistry.pack("oee.screening_result", result),
            summary=f"Screened {len(result.equipment)} equipment against a {result.threshold:.0%} OEE threshold; {abnormal_count} abnormal.",
            quality=EvidenceQuality.STRONG,
        )


class QueryEquipmentDetailTool:
    def __init__(self, datasource: OEEDataSource):
        self._datasource = datasource
        self.definition = ToolDefinition(
            tool_id="query_equipment_detail",
            name="Query Equipment Detail",
            description="Fetch downtime/failure detail for one equipment.",
            category=ToolCategory.QUERY,
            domains=["oee"],
            input_schema=ToolIOSchema(model_name="EquipmentDetailQueryInput"),
            output_schema=ToolIOSchema(model_name="EquipmentDetail"),
            execution_type=ExecutionType.DETERMINISTIC,
            side_effect=ToolSideEffect.READ_ONLY,
            input_payload_type="oee.equipment_detail_query_input",
            output_payload_type="oee.equipment_detail",
        )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, EquipmentDetailQueryInput)

        equipment_id = params.equipment_id
        try:
            record = self._datasource.get_equipment_detail(equipment_id)
        except OEEDataUnavailableError:
            return ToolExecutionResult(
                status=ObservationStatus.ERROR,
                error_type=ErrorType.DATA_NOT_FOUND,
                error_message=f"OEE data source unavailable for '{equipment_id}'",
            )
        except EquipmentNotFoundError:
            return ToolExecutionResult(
                status=ObservationStatus.ERROR, error_type=ErrorType.DATA_NOT_FOUND, error_message=f"no such equipment '{equipment_id}'"
            )

        detail = EquipmentDetail(
            equipment_id=equipment_id,
            downtime_minutes=record.downtime_minutes,
            downtime_reason=record.downtime_reason,
            failure_reason=record.failure_reason,
        )
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS,
            payload=PayloadRegistry.pack("oee.equipment_detail", detail),
            summary=(
                f"{equipment_id} downtime detail: {detail.downtime_minutes} min, "
                f"reason={detail.downtime_reason}, failure={detail.failure_reason}."
            ),
            quality=EvidenceQuality.STRONG,
        )


class FilterRowsTool:
    definition = ToolDefinition(
        tool_id="filter_rows",
        name="Filter Rows",
        description="Keep only equipment whose OEE is below threshold.",
        category=ToolCategory.TRANSFORM,
        domains=["oee"],
        input_schema=ToolIOSchema(model_name="FilterRowsInput"),
        output_schema=ToolIOSchema(model_name="ScreeningResult"),
        execution_type=ExecutionType.DETERMINISTIC,
        side_effect=ToolSideEffect.READ_ONLY,
        input_payload_type="oee.filter_rows_input",
        output_payload_type="oee.screening_result",
    )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, FilterRowsInput)
        abnormal = [e for e in params.equipment if e.oee < params.threshold]
        result = ScreeningResult(threshold=params.threshold, equipment=abnormal)
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS,
            payload=PayloadRegistry.pack("oee.screening_result", result),
            summary=f"Filtered to {len(abnormal)} equipment below the {params.threshold:.0%} OEE threshold.",
            quality=EvidenceQuality.STRONG,
        )


class CalculateContributionTool:
    definition = ToolDefinition(
        tool_id="calculate_contribution",
        name="Calculate Contribution",
        description="Score each equipment's contribution to aggregate OEE loss.",
        category=ToolCategory.CALCULATION,
        domains=["oee"],
        input_schema=ToolIOSchema(model_name="ContributionInput"),
        output_schema=ToolIOSchema(model_name="ContributionResult"),
        execution_type=ExecutionType.DETERMINISTIC,
        side_effect=ToolSideEffect.READ_ONLY,
        input_payload_type="oee.contribution_input",
        output_payload_type="oee.contribution_result",
    )

    def __init__(self):
        self._scorer = DefaultContributionScorer()

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, ContributionInput)
        items = [
            ContributionItem(
                equipment_id=e.equipment_id,
                oee=e.oee,
                availability=e.availability,
                performance=e.performance,
                quality=e.quality,
                production_weight=e.production_weight,
                pattern=pattern_of(e),
                contribution=self._scorer.score(ContributionInputs(abnormality=1 - e.oee, weight=e.production_weight)),
            )
            for e in params.equipment
        ]
        result = ContributionResult(threshold=params.threshold, items=items)
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS,
            payload=PayloadRegistry.pack("oee.contribution_result", result),
            summary=f"Scored contribution for {len(items)} equipment.",
            quality=EvidenceQuality.STRONG,
        )


class RankingTool:
    definition = ToolDefinition(
        tool_id="ranking",
        name="Ranking",
        description="Group scored equipment by worst dimension, rank groups by aggregate contribution.",
        category=ToolCategory.CALCULATION,
        domains=["oee"],
        input_schema=ToolIOSchema(model_name="RankingInput"),
        output_schema=ToolIOSchema(model_name="RankedScreeningResult"),
        execution_type=ExecutionType.DETERMINISTIC,
        side_effect=ToolSideEffect.READ_ONLY,
        input_payload_type="oee.ranking_input",
        output_payload_type="oee.ranked_screening_result",
    )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, RankingInput)

        groups: dict[str, list[ContributionItem]] = {}
        for item in params.items:
            groups.setdefault(item.pattern, []).append(item)

        ranked: list[PatternGroup] = []
        for pattern, members in groups.items():
            members_sorted = sorted(members, key=lambda m: m.contribution, reverse=True)
            ranked.append(
                PatternGroup(
                    pattern=pattern,
                    equipment_ids=[m.equipment_id for m in members_sorted],
                    total_contribution=sum(m.contribution for m in members),
                )
            )
        ranked.sort(key=lambda g: g.total_contribution, reverse=True)

        result = RankedScreeningResult(threshold=params.threshold, groups=ranked)
        top = f"top pattern '{ranked[0].pattern}' ({', '.join(ranked[0].equipment_ids)})" if ranked else "no abnormal groups"
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS,
            payload=PayloadRegistry.pack("oee.ranked_screening_result", result),
            summary=f"Ranked {len(ranked)} pattern group(s) by aggregate contribution; {top}.",
            quality=EvidenceQuality.STRONG,
        )


class AggregateOEEStatusTool:
    definition = ToolDefinition(
        tool_id="aggregate_oee_status",
        name="Aggregate OEE Status",
        description="Summarize current OEE status: average and worst equipment.",
        category=ToolCategory.CALCULATION,
        domains=["oee"],
        input_schema=ToolIOSchema(model_name="ScreeningResult"),
        output_schema=ToolIOSchema(model_name="CurrentOEEStatus"),
        execution_type=ExecutionType.DETERMINISTIC,
        side_effect=ToolSideEffect.READ_ONLY,
        # reuses query_oee_data's own output type: an aggregate step's
        # input is exactly the previous step's ScreeningResult, unchanged
        input_payload_type="oee.screening_result",
        output_payload_type="oee.current_status",
    )

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        params = PayloadRegistry.unpack(request.parameters)
        assert isinstance(params, ScreeningResult)
        if not params.equipment:
            return ToolExecutionResult(status=ObservationStatus.ERROR, error_type=ErrorType.DATA_NOT_FOUND, error_message="no equipment data available")

        worst = min(params.equipment, key=lambda e: e.oee)
        average = sum(e.oee for e in params.equipment) / len(params.equipment)
        result = CurrentOEEStatus(
            threshold=params.threshold,
            equipment_count=len(params.equipment),
            average_oee=average,
            worst_equipment_id=worst.equipment_id,
            worst_oee=worst.oee,
        )
        return ToolExecutionResult(
            status=ObservationStatus.SUCCESS,
            payload=PayloadRegistry.pack("oee.current_status", result),
            summary=(
                f"Average OEE across {result.equipment_count} equipment is {result.average_oee:.0%}; "
                f"worst is {result.worst_equipment_id} at {result.worst_oee:.0%}."
            ),
            quality=EvidenceQuality.STRONG,
        )
