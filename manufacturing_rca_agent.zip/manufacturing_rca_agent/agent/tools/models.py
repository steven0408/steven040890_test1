"""Formal Tool contracts (Phase 5B-1). `ToolRegistry` / `CapabilityResolver`
/ `SkillRunner` (Phase 5B-2, landed and wired into `agent/bootstrap.py`
long since) are what actually construct and consume these in production
today. The legacy `MockTool.run(objective) -> ToolResult`
(agent/tools/base.py) contract still exists and still works, but is no
longer used by any real `ModulePackage`/`bootstrap.py` composition --
Phase WB-3E's own cleanup audit confirmed it as test-fixture-only now
(Harness-mechanics regression coverage across ~11 test files), not a
production code path.

`Tool` decouples execution from `Objective` on purpose: Tools must also
serve INFORMATION/ANALYSIS tasks that don't need the full RCA-flavored
Objective wrapper, and a Tool should never need to know what an "Objective"
even is.
"""
import hashlib
from enum import Enum
from typing import Protocol

from pydantic import Field

from agent.state.base import RCABaseModel
from agent.state.enums import ErrorType, EvidenceQuality, ObservationStatus, RiskLevel
from agent.state.payload import StructuredPayload


class ToolCategory(str, Enum):
    QUERY = "query"
    TRANSFORM = "transform"
    CALCULATION = "calculation"
    SANDBOX = "sandbox"


class ToolSideEffect(str, Enum):
    """How a Tool must be treated under replay (Phase 5B-1.1 finding: parts
    of an in-flight run *do* get re-invoked under specific conditions --
    see agent/tools/execution_manager.py). READ_ONLY / IDEMPOTENT_WRITE can
    simply run again; NON_IDEMPOTENT_WRITE must go through
    ToolExecutionManager's idempotency-key dedup, never called bare.

    Production Gate (Phase 5B-1.2, documentation-only -- not enforced in
    code yet): a NON_IDEMPOTENT_WRITE tool backed only by
    `InMemoryToolResultCache` must NOT be considered production-safe.
    `InMemoryToolResultCache` does not survive a process restart, and
    Phase 5B-1.1 established that pending Send tasks can still be
    re-invoked across a resume -- if that resume happens in a fresh
    process (the realistic case for a real deployment), an in-memory-only
    cache has already forgotten the first physical execution and a
    NON_IDEMPOTENT_WRITE tool would run twice for real. Before enabling any
    production write Tool with this side-effect tier, ToolExecutionManager
    must be backed by either a durable idempotency ledger (e.g. a Postgres
    table keyed by idempotency_key, checked before every physical
    execution) or a backend-supported idempotency mechanism (an
    idempotency-key header the downstream system itself de-duplicates on,
    a transactional upsert, etc.). This is a gate on enabling the Tool, not
    something ToolExecutionManager's interface alone can guarantee."""

    READ_ONLY = "read_only"
    IDEMPOTENT_WRITE = "idempotent_write"
    NON_IDEMPOTENT_WRITE = "non_idempotent_write"


class ExecutionType(str, Enum):
    DETERMINISTIC = "deterministic"
    QUERY_BACKEND = "query_backend"
    SANDBOXED_CODE = "sandboxed_code"


class PermissionLevel(str, Enum):
    PUBLIC = "public"
    RESTRICTED = "restricted"
    ADMIN = "admin"


class ToolIOField(RCABaseModel):
    name: str
    type_name: str
    description: str
    required: bool = True


class ToolIOSchema(RCABaseModel):
    model_name: str
    fields: list[ToolIOField] = Field(default_factory=list)


class ToolDefinition(RCABaseModel):
    tool_id: str
    name: str
    description: str
    category: ToolCategory
    domains: list[str] = Field(default_factory=list)  # [] = shared/domain-agnostic
    input_schema: ToolIOSchema
    output_schema: ToolIOSchema
    execution_type: ExecutionType
    permission_level: PermissionLevel = PermissionLevel.PUBLIC
    risk_level: RiskLevel = RiskLevel.LOW
    read_only: bool = True
    side_effect: ToolSideEffect = ToolSideEffect.READ_ONLY
    timeout_seconds: float = 30.0
    sandbox_required: bool = False

    # Phase 5B-2: the registered PayloadRegistry types SkillRunner validates
    # against before/after calling this Tool -- `input_schema`/
    # `output_schema` above stay descriptive-only (human/UI-facing field
    # lists); these two are what execution actually checks.
    input_payload_type: str
    output_payload_type: str


class ToolExecutionIdentity(RCABaseModel):
    """What makes one *logical* Tool action the same action even if it
    physically executes more than once (checkpoint replay, explicit retry).
    `logical_attempt` is NOT the replay/attempt counter ToolExecutionManager
    tracks -- it's the Planner-visible "this is the Nth time we've tried
    this exact objective+tool" (mirrors Objective.attempt_count), kept
    separate from physical replay counting on purpose.
    """

    run_id: str
    module_id: str
    objective_id: str
    skill_id: str | None = None
    skill_step_id: str | None = None
    logical_attempt: int = 1

    def idempotency_key(self) -> str:
        parts = [
            self.run_id,
            self.module_id,
            self.objective_id,
            self.skill_id or "-",
            self.skill_step_id or "-",
            str(self.logical_attempt),
        ]
        return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()


class ToolExecutionRequest(RCABaseModel):
    tool_id: str
    parameters: StructuredPayload
    run_id: str
    module_id: str
    objective_id: str | None = None
    requested_by_skill: str | None = None
    idempotency_key: str | None = None


class ToolExecutionResult(RCABaseModel):
    status: ObservationStatus
    payload: StructuredPayload | None = None
    # Phase 5C-1 finding: dropped from the Phase 5B-2 capability-layer Tool
    # contract relative to the legacy `ToolResult.payload_summary` -- without
    # it, SkillRunner had nothing human-readable to put in Evidence.summary
    # beyond a generic "skill completed N step(s)" message, which starved
    # History summarization / EvidenceSelector of the very content they
    # exist to surface. Optional: a purely structural/transform Tool
    # (filter_rows, calculate_contribution) may reasonably leave it unset.
    summary: str | None = None
    error_type: ErrorType | None = None
    error_message: str | None = None
    quality: EvidenceQuality | None = None


class Tool(Protocol):
    definition: ToolDefinition

    def run(self, request: ToolExecutionRequest) -> ToolExecutionResult: ...
