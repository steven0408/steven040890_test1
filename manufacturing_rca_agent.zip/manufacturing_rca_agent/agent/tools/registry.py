"""ToolRegistry (Phase 5B-2) -- the terminal stop of the capability chain
(`Objective -> Executor -> CapabilityResolver -> Skill -> SkillRunner ->
ToolExecutionManager -> ToolRegistry -> Tool`). Purely a lookup/allow-list
service: it holds `Tool` instances (the new agent/tools/models.py `Tool`
Protocol -- `run(request: ToolExecutionRequest) -> ToolExecutionResult`),
keyed by `tool_id`, and answers "does this exist" / "is this usable by this
module_type". It has no opinion on *which* tool a Skill should use -- that's
CapabilityResolver's job.
"""
from __future__ import annotations

from agent.tools.models import Tool, ToolDefinition


class DuplicateToolError(ValueError):
    pass


class ToolNotFoundError(KeyError):
    pass


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        tool_id = tool.definition.tool_id
        if tool_id in self._tools:
            raise DuplicateToolError(f"tool_id '{tool_id}' is already registered")
        self._tools[tool_id] = tool

    def get(self, tool_id: str) -> Tool:
        tool = self._tools.get(tool_id)
        if tool is None:
            raise ToolNotFoundError(f"no tool registered with tool_id '{tool_id}'")
        return tool

    def list(self) -> list[ToolDefinition]:
        return [t.definition for t in self._tools.values()]

    def allowed_for(self, module_type: str) -> list[ToolDefinition]:
        """Shared tools (`domains=[]`) plus tools whose `domains` includes
        this module_type (case-insensitive) -- e.g. a WIP-only tool
        (`domains=["wip"]`) is never in an OEE module's allow-list."""
        domain = module_type.lower()
        return [t.definition for t in self._tools.values() if not t.definition.domains or domain in t.definition.domains]
