"""ObjectiveScope (Phase WB-2B.1) -- the typed, generic "analytical
boundary" contract `Objective` carries alongside `action`/`target_ref`.

Split out of `agent/state/models.py` on purpose (still imported into it,
still part of the same Frozen Core Contract) -- this is a self-contained
sub-schema with its own validation rules, not a growing bag of manufacturing
fields. Core (`agent/state/`) does NOT know what "plant" or "operation"
mean -- `ScopeFilter.dimension` is an opaque string as far as this module
is concerned; a domain's own Tool/Skill parameter-mapping layer is what
decides which dimension names it accepts (see `agent/skills/runner.py`'s
`_resolve_param`). Adding a new domain (Yield, Q-Time,
Cycle Time, ...) with entirely different scope dimensions never requires
touching this file.

No arbitrary dynamic execution: `ScopeFilter.value` is JSON-scalar-only
data (str/int/float/bool, or a list of those for `IN`) -- never a Python
expression string, never `eval`/`exec`, never a SQL fragment. See the
Phase WB-2B.1 report's "no arbitrary dynamic execution" boundary.
"""
from datetime import date as _date
from enum import Enum

from pydantic import model_validator

from agent.state.base import RCABaseModel

ScopeScalar = str | int | float | bool


class TimeScopeKind(str, Enum):
    """OEE/Output are daily-like (a real `production_date`); BANK/WIP are
    snapshot datasets (only `snapshot_date` -- no separate "production"
    concept). Kept as a closed, explicit tag rather than one generic
    "date" field so a Planner/Skill can never accidentally treat a WIP
    snapshot date as if it were a production date, or vice versa -- see
    the Phase WB-2B.1 report's snapshot-scope section."""

    PRODUCTION_DATE = "production_date"
    SNAPSHOT_DATE = "snapshot_date"


class TimeScope(RCABaseModel):
    """A single point-in-time scope (`date`) or a bounded range
    (`start`/`end`) -- never both. Intentionally minimal: no "last N
    days"/relative-date language, no timezone/time-of-day granularity --
    those are exactly the "SQL-like arbitrary expression" shape this
    contract is not meant to grow into (Phase WB-2B.1 item F/S)."""

    kind: TimeScopeKind
    date: _date | None = None
    start: _date | None = None
    end: _date | None = None

    @model_validator(mode="after")
    def _validate_shape(self) -> "TimeScope":
        has_point = self.date is not None
        has_range = self.start is not None or self.end is not None
        if has_point and has_range:
            raise ValueError("TimeScope must be a single `date` OR a `start`/`end` range, never both")
        if not has_point and not has_range:
            raise ValueError("TimeScope requires either `date` or `start`/`end`")
        if self.start is not None and self.end is not None and self.start > self.end:
            raise ValueError(f"TimeScope.start ({self.start}) must not be after end ({self.end})")
        return self


class ScopeOperator(str, Enum):
    """Minimal set (Phase WB-2B.1 item E's own instruction): only what the
    8 WB Skills' actual filters need today. GTE/LTE deliberately omitted
    -- add them only when a real capability needs a range filter, not
    speculatively."""

    EQ = "eq"
    IN = "in"


class ScopeFilter(RCABaseModel):
    """`dimension` is a canonical, domain-facing name (Phase WB-2B.1 item
    R's frozen convention: `plant`/`operation`/`customer`/`package`/
    `device`/`status`, never a raw source field like `PLANT`/`FAC`/
    `A01001` -- DataSource-level raw-value mapping stays exactly where
    Phase WB Data Layer V1 already put it, `agent/domain/wb/mappings.py`).
    Core has no opinion on which dimension names are legal for which
    capability -- see `SkillDefinition.accepted_scope_dimensions`/
    `required_scope_dimensions`."""

    dimension: str
    operator: ScopeOperator
    value: ScopeScalar | list[ScopeScalar]

    @model_validator(mode="after")
    def _validate_value_shape(self) -> "ScopeFilter":
        is_list = isinstance(self.value, list)
        if self.operator == ScopeOperator.IN and not is_list:
            raise ValueError("ScopeFilter with operator=IN requires a list value")
        if self.operator == ScopeOperator.EQ and is_list:
            raise ValueError("ScopeFilter with operator=EQ requires a scalar value, not a list")
        return self


class ObjectiveScope(RCABaseModel):
    """The query/analytical boundary for an Objective -- distinct from
    `TargetRef` (Phase WB-2B.1 item G's frozen split): `TargetRef` says
    WHICH primary object/entity/module is under investigation;
    `ObjectiveScope` says what date/filter/grouping boundary the analysis
    should run within. `group_by` names dimensions the same way
    `ScopeFilter.dimension` does (again opaque to Core)."""

    time: TimeScope | None = None
    filters: list[ScopeFilter] = []
    group_by: list[str] = []


class ConstraintSource(str, Enum):
    """Phase WB-3F.4: how confidently a `RequestConstraint` traces back to
    the user's own words -- the load-bearing distinction item 6 of the
    phase spec calls for. Only `USER_EXPLICIT` is strict enough to justify
    a scope-preservation semantic-validation failure (agent/planning/
    policies/llm.py's `validate_request_constraint_preservation`);
    `STANDARDIZER_INFERRED`/`SYSTEM_CONTEXT` are informational only."""

    USER_EXPLICIT = "user_explicit"
    STANDARDIZER_INFERRED = "standardizer_inferred"
    SYSTEM_CONTEXT = "system_context"


class RequestConstraint(ScopeFilter):
    """Phase WB-3F.4: an explicit (or, per `source`, inferred) boundary the
    USER stated, extracted by the Standardizer -- e.g. "customer=CUSTOMER_X"
    from "...for customer CUSTOMER_X...". Deliberately a `ScopeFilter`
    SUBCLASS, not a hand-duplicated parallel shape: reuses `dimension`/
    `operator`/`value` and their existing EQ/IN shape validation verbatim,
    adding only the one field (`source`) a Request Constraint needs that an
    Objective's own `ScopeFilter` never did.

    RequestConstraint IS NOT ObjectiveScope.filters. They are deliberately
    different concepts kept as different (though structurally related)
    types (see the phase's own item 5 "freeze these definitions"):
      - RequestConstraint: what the user explicitly said, extracted ONCE at
        Standardizer time, authoritative for the whole run, never mutated
        by any later node.
      - ObjectiveScope.filters: what ONE Objective (one investigation step)
        actually queries -- the Planner's own per-round DECISION about how
        much of the available RequestConstraints to apply, narrow, or
        deliberately broaden past, informed by evidence gathered so far.
    A Planner is never required to copy every RequestConstraint into every
    ObjectiveScope it proposes -- only the first-objective-of-a-module case
    is safely, deterministically enforceable (see item 19's own "minimal
    validation option" -- agent/planning/policies/llm.py)."""

    source: ConstraintSource = ConstraintSource.USER_EXPLICIT


def get_scope_filter(scope: ObjectiveScope | None, dimension: str) -> ScopeFilter | None:
    """Deterministic lookup helper (Phase WB-2B.1 item H) -- the only
    sanctioned way `SkillRunner`'s parameter-mapping resolver reads a
    filter out of `objective.scope`. Returns the FIRST matching filter (a
    Skill declaring a dimension in `required_scope_dimensions`/
    `accepted_scope_dimensions` is expected to receive at most one filter
    per dimension; a caller supplying duplicates is not deterministically
    resolved beyond "first wins")."""
    if scope is None:
        return None
    for f in scope.filters:
        if f.dimension == dimension:
            return f
    return None
