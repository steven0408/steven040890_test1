from datetime import datetime
from typing import Annotated

from pydantic import Field, model_validator

from agent.analysis.analysis_tree import AnalysisTree
from agent.state.base import RCABaseModel
from agent.state.enums import (
    BranchStatus,
    CoordinatorDecision,
    EntityAnalysisStatus,
    ErrorType,
    EvaluationCategory,
    EvaluationSeverity,
    EvidenceQuality,
    ExecutionStrategy,
    FeedbackTargetType,
    FindingStatus,
    GateDecision,
    HumanDecision,
    HumanFeedbackThumbs,
    HumanReason,
    HumanRequestStatus,
    HypothesisStatus,
    LearningCandidateStatus,
    LearningCandidateType,
    LearningDestination,
    ModulePlannerDecision,
    ModuleStatus,
    ObjectiveAction,
    ObjectiveStatus,
    ObservationStatus,
    RecommendationActionType,
    ReflectorVerdict,
    RelationType,
    RelationValidationStatus,
    RiskLevel,
    StandardizerDecision,
    SynthesisOverallStatus,
    TargetRefType,
    TaskType,
)
from agent.state.payload import StructuredPayload
from agent.state.reducers import append_list, merge_by_key
from agent.state.scope import ObjectiveScope, RequestConstraint

# --- Errors / Limitations -------------------------------------------------


class ErrorRecord(RCABaseModel):
    error_type: ErrorType
    message: str
    objective_id: str | None = None
    occurred_at_step: int


class Limitation(RCABaseModel):
    """A gap in evidence/coverage a module could not close (e.g. DATA_NOT_FOUND
    after exhausting alternatives). Feeds Synthesis's Missing Data section."""

    limitation_id: str
    description: str
    impacted_objective_id: str
    impact_statement: str
    related_error: ErrorRecord | None = None


class RejectionRecord(RCABaseModel):
    """A Human REJECT at the Execution Gate. `alternative_found` tells Module
    Completion Check whether this rejection can still lead to BLOCKED."""

    objective_id: str
    permission_type: str | None = None
    reason: str
    alternative_found: bool


# --- Analysis primitives (Branch / Entity / Hypothesis / Evidence / Finding)


class Branch(RCABaseModel):
    branch_id: str
    name: str
    pattern: str
    entity_ids: list[str] = Field(default_factory=list)
    parent_branch_id: str | None = None
    status: BranchStatus = BranchStatus.PENDING
    execution_strategy: ExecutionStrategy = ExecutionStrategy.SEQUENTIAL
    priority_score: float = 0.0
    depth: int = 0
    tree_node_id: str


class EntityState(RCABaseModel):
    entity_id: str
    entity_type: str
    depth: int = 0
    status: EntityAnalysisStatus = EntityAnalysisStatus.SCREENED
    current_tree_node_id: str
    branch_id: str | None = None
    priority_score: float = 0.0
    finding_ids: list[str] = Field(default_factory=list)
    last_updated_step: int = 0


class Hypothesis(RCABaseModel):
    hypothesis_id: str
    statement: str
    related_dimensions: list[str] = Field(default_factory=list)
    status: HypothesisStatus = HypothesisStatus.OPEN
    confidence: float


class Evidence(RCABaseModel):
    evidence_id: str
    objective_id: str
    source_tool: str
    summary: str
    quality: EvidenceQuality
    raw_ref: str | None = None
    structured_payload: StructuredPayload | None = None


class Observation(RCABaseModel):
    observation_id: str
    objective_id: str
    tool_name: str
    status: ObservationStatus
    payload_summary: str | None = None
    error: ErrorRecord | None = None
    structured_payload: StructuredPayload | None = None


class ToolCallRecord(RCABaseModel):
    """Per-tool-invocation audit entry -- granular, unlike Observation/
    Evidence which stay one-per-objective even when a Skill chains several
    tool calls together (see Phase 5B architecture note). Evaluator's
    tool_call_count / failed_tool_ratio / latency / duplicate-call analysis
    all read this list, not Observation.

    Phase 5B-1.1 finding: `ModuleState.tool_calls` is a convenient
    module-scoped *view*, not the physical-execution source of truth --
    under checkpoint replay, a module's whole branch can physically
    re-execute while `module_states` (merge_by_key, whole-value-per-key)
    only ever keeps the *latest* ModuleState, silently discarding the
    earlier physical attempt's record. `replayed`/`result_reused`/
    `attempt_number` exist so a future append-only execution ledger
    (Postgres `tool_calls`, never overwritten) can tell "1 logical action,
    2 physical executions" apart from "1 logical action, 1 execution" --
    this in-state list alone cannot, once overwritten.
    """

    tool_call_id: str
    run_id: str
    module_id: str
    objective_id: str
    skill_id: str | None = None
    tool_id: str
    status: ObservationStatus
    duration_seconds: float
    error: ErrorRecord | None = None
    sandboxed: bool = False
    started_at: datetime
    completed_at: datetime
    idempotency_key: str | None = None
    logical_call_id: str | None = None
    attempt_number: int = 1
    replayed: bool = False
    result_reused: bool = False


class Finding(RCABaseModel):
    finding_id: str
    statement: str
    entity_ids: list[str] = Field(default_factory=list)
    pattern: str
    supporting_evidence_ids: list[str] = Field(default_factory=list)
    confidence: float
    status: FindingStatus = FindingStatus.HYPOTHESIS
    is_root_cause: bool = False


class ReflectionRecord(RCABaseModel):
    reflection_id: str
    objective_id: str
    verdict: ReflectorVerdict
    rationale: str
    evidence_ids: list[str] = Field(default_factory=list)
    created_at_step: int


# --- Analysis space / module goal / budget --------------------------------


class AnalysisSpace(RCABaseModel):
    """A module's own dimension breakdown, e.g. {"OEE": ["Equipment", "Time",
    "Availability", "Performance", "Quality", "Loss"]}. Seeded by that
    module's ModulePlanningPolicy, not authored by Analyzer."""

    root_dimension: str
    dimensions: dict[str, list[str]] = Field(default_factory=dict)


class SuccessCriteria(RCABaseModel):
    min_evidence_quality: EvidenceQuality
    root_cause_coverage_threshold: float
    required_dimensions: list[str] = Field(default_factory=list)


class ModuleGoal(RCABaseModel):
    module_id: str
    statement: str
    task_type: TaskType
    success_criteria: SuccessCriteria
    # Phase WB-3F.4: additive, default empty -- carries the request-level
    # RequestConstraints (agent/state/scope.py) relevant to this module,
    # threaded verbatim from NormalizedRequest.constraints through
    # ModuleTask.constraints (see agent/graph/nodes/analyzer_llm.py) into
    # here at agent/graph/nodes/module/bootstrap.py's
    # build_initial_module_state. This is what makes Request Constraints
    # visible to a per-module Planner at all -- a Module subgraph runs via
    # Send() with ONLY ModuleState as its state type, structurally isolated
    # from AgentState/NormalizedRequest once dispatched (confirmed by
    # reading agent/graph/nodes/module_subgraph_node.py); without this
    # field, constraints could only reach the Planner as unstructured
    # prose baked into `statement`, defeating this phase's own purpose.
    # Judged additive (one new default-empty list field on an existing
    # model), not a "ModuleState redesign" -- see the completion report's
    # own explicit justification for this judgment call.
    constraints: list[RequestConstraint] = Field(default_factory=list)


class Budget(RCABaseModel):
    max_steps: int
    used_steps: int = 0
    max_tool_calls: int
    used_tool_calls: int = 0
    max_depth_per_entity: int
    deadline: datetime | None = None


class ModuleMetrics(RCABaseModel):
    step_count: int = 0
    tool_call_count: int = 0
    retry_count: int = 0
    branch_count: int = 0
    entity_count: int = 0


class RunMetrics(RCABaseModel):
    step_count: int = 0
    tool_call_count: int = 0
    retry_count: int = 0
    branch_count: int = 0
    entity_count: int = 0
    human_intervention_count: int = 0


# --- Plan / Objective (module-scoped only -- never global) ----------------


class TargetRef(RCABaseModel):
    ref_type: TargetRefType
    ref_id: str


class Objective(RCABaseModel):
    objective_id: str
    description: str  # human/LLM-readable explanation -- never routing input
    action: ObjectiveAction  # generic analytical verb (Phase WB-2B.1) -- WHAT kind of action, not which capability
    # WHICH domain capability is requested, e.g. "wb.wip.hold_analysis" --
    # CapabilityResolver matches on (domain, task_type, action,
    # capability_key) together, never `action` alone (Phase WB-2B.1).
    # `None` only for the domain-agnostic Harness-mechanics test fixture
    # path (DeterministicMockPolicy), which never goes through
    # CapabilityResolver at all.
    capability_key: str | None = None
    target_ref: TargetRef  # WHO/WHAT primary entity/module is under investigation -- never a query-parameter bag (Phase WB-2B.1 item G)
    scope: ObjectiveScope | None = None  # the query/analytical boundary (date/filters/group_by) -- see agent/state/scope.py
    expected_output: str
    priority_score: float
    requires_permission: bool = False
    risk_level: RiskLevel | None = None
    permission_type: str | None = None
    attempt_count: int = 0
    status: ObjectiveStatus = ObjectiveStatus.PENDING


class Plan(RCABaseModel):
    plan_id: str
    module_id: str
    current_objective: Objective
    step_queue: list[Objective] = Field(default_factory=list)
    candidate_branches: list[str] = Field(default_factory=list)
    execution_strategy: ExecutionStrategy = ExecutionStrategy.SEQUENTIAL
    budget_snapshot: Budget
    created_at_step: int


class ObjectiveRecord(RCABaseModel):
    """Audit trail entry for one objective's full lifecycle -- distinct from
    `Objective` itself (the live/current definition). Created DISPATCHED by
    Module Planner the moment it dispatches an objective; closed out to
    COMPLETED by whichever node causes that objective to stop being current
    (Module Planner when looping back to dispatch the next one, Module
    Completion Check when the module terminates while it's still current).
    Tool SUCCESS is never read as "objective COMPLETED" here -- completion
    is always driven by a Reflector verdict or a terminal lifecycle
    decision, recorded in `termination_reason`.
    """

    objective_id: str
    description: str
    action: ObjectiveAction  # Phase 5C-1: carried over from Objective.action at dispatch time -- History
    # summarization (agent/llm/context) needs *what kind* of action ran, not just target_ref's string id.
    capability_key: str | None = None  # carried over from Objective.capability_key (Phase WB-2B.1) -- same reasoning as `action`
    target_ref: TargetRef
    # Phase WB-2B.2: carried over from Objective.scope verbatim -- the
    # query/analytical boundary (date/filters/group_by) this objective was
    # dispatched with. A straight projection, never re-derived/re-inferred
    # here or anywhere downstream (see agent/graph/nodes/module/module_planner.py
    # ::_build_dispatch_update, the only place an ObjectiveRecord is built).
    scope: ObjectiveScope | None = None
    status: ObjectiveStatus
    created_step: int
    completed_step: int | None = None
    attempt_count: int
    observation_ids: list[str] = Field(default_factory=list)
    evidence_ids: list[str] = Field(default_factory=list)
    termination_reason: str | None = None


# --- Control signals (routing bookkeeping only, no domain data) -----------


class ControlSignals(RCABaseModel):
    standardizer_decision: StandardizerDecision | None = None
    coordinator_decision: CoordinatorDecision | None = None


class ModuleControlSignals(RCABaseModel):
    planner_decision: ModulePlannerDecision | None = None
    gate_decision: GateDecision | None = None
    reflector_verdict: ReflectorVerdict | None = None


# --- Module state -----------------------------------------------------------


class ModuleState(RCABaseModel):
    module_id: str
    module_type: str
    run_id: str
    status: ModuleStatus = ModuleStatus.PENDING

    # Lifecycle timestamps (Phase 8A-1) -- `started_at` is stamped once,
    # the first time this module is actually dispatched/executed (never
    # re-stamped by a later physical replay of the same logical module --
    # see module_subgraph_node.py's explicit checkpoint-preserving guard).
    # `completed_at` is set once, only by Module Completion Check, only on
    # the terminal-status-setting paths (COMPLETE/PARTIAL/FAILED/BLOCKED).
    # SKIPPED (option A, item 9): `started_at=None` (never actually began
    # execution) but `completed_at` set to the skip-decision time -- no
    # node in this codebase produces ModuleStatus.SKIPPED yet (confirmed
    # in the Phase 6A report), so this is a documented shape for whichever
    # future Module Coordinator budget/scheduling path adds it, not
    # something wired into a real node this phase.
    started_at: datetime | None = None
    completed_at: datetime | None = None

    goal: ModuleGoal
    current_plan: Plan | None = None
    current_objective: Objective | None = None
    objective_history: Annotated[dict[str, ObjectiveRecord], merge_by_key] = Field(default_factory=dict)

    analysis_space: AnalysisSpace
    analysis_tree: AnalysisTree

    branches: Annotated[dict[str, Branch], merge_by_key] = Field(default_factory=dict)
    entity_states: Annotated[dict[str, EntityState], merge_by_key] = Field(default_factory=dict)

    hypotheses: Annotated[list[Hypothesis], append_list] = Field(default_factory=list)
    observations: Annotated[list[Observation], append_list] = Field(default_factory=list)
    evidence: Annotated[list[Evidence], append_list] = Field(default_factory=list)
    findings: Annotated[list[Finding], append_list] = Field(default_factory=list)

    reflection_history: Annotated[list[ReflectionRecord], append_list] = Field(default_factory=list)
    limitations: Annotated[list[Limitation], append_list] = Field(default_factory=list)
    rejections: Annotated[list[RejectionRecord], append_list] = Field(default_factory=list)
    tool_calls: Annotated[list[ToolCallRecord], append_list] = Field(default_factory=list)

    budget: Budget
    metrics: ModuleMetrics = Field(default_factory=ModuleMetrics)
    control: ModuleControlSignals = Field(default_factory=ModuleControlSignals)


# --- Module task / dispatch (owned by Analyzer / Module Coordinator) ------


class ModuleTask(RCABaseModel):
    module_id: str
    module_type: str
    reason: str
    # Phase WB-2C.1: `reason` answers "why was this module selected?";
    # `goal_statement` answers "what should this module accomplish?" -- the
    # two are deliberately separate fields, never merged. Propagated
    # verbatim from `ModuleSelection.goal_statement` (Analyzer's own output)
    # through Send()/ModuleDispatchPayload into `build_initial_module_state`,
    # which stamps it onto `ModuleGoal.statement` -- the first time a Module
    # Planner sees the real, module-specific task it was dispatched to do
    # instead of a hardcoded placeholder string.
    goal_statement: str
    confidence: float
    priority: float
    depends_on: list[str] = Field(default_factory=list)
    # Propagated end-to-end from Goal.task_type (Analyzer reads
    # state.global_goal, never re-infers it) down into ModuleGoal.task_type
    # at module bootstrap. Defaults to RCA -- the depth every pre-5B-2.1
    # scenario implicitly assumed -- so existing call sites that predate
    # TaskType-aware dispatch are unaffected.
    task_type: TaskType = TaskType.RCA
    # Phase WB-3F.4: additive, default empty -- Analyzer copies
    # `state.normalized_request.constraints` verbatim into every
    # `ModuleTask` it dispatches (see agent/graph/nodes/analyzer_llm.py),
    # the Send()-payload leg of the same thread `ModuleGoal.constraints`
    # (this file, above) carries the rest of the way into ModuleState.
    constraints: list[RequestConstraint] = Field(default_factory=list)


class ModuleDispatchState(RCABaseModel):
    execution_policy: ExecutionStrategy = ExecutionStrategy.HYBRID
    in_flight: list[str] = Field(default_factory=list)
    pending: list[str] = Field(default_factory=list)


# --- Request / factory / goal ----------------------------------------------


class UserRequest(RCABaseModel):
    request_id: str
    raw_text: str
    submitted_by: str
    submitted_at: datetime


class NormalizedRequest(RCABaseModel):
    request_id: str
    normalized_text: str
    factory_id: str
    plant_id: str | None = None
    line_id: str | None = None
    time_range_start: datetime | None = None
    time_range_end: datetime | None = None
    # Phase WB-3F.4: generic, domain-agnostic explicit boundaries the user
    # stated -- NEVER WB-specific fields (no `customer`/`operation` field
    # here; see RequestConstraint's own docstring, agent/state/scope.py,
    # for why `dimension` stays an opaque string at this layer). Additive,
    # default empty -- every pre-existing `NormalizedRequest(...)`
    # construction across the codebase keeps working unchanged.
    # `plant_id`/`time_range_start`/`time_range_end` above remain the
    # authoritative source for THEIR OWN dimensions (unchanged, no
    # duplication into `constraints` -- see the completion report's own
    # "plant backward compatibility" section for why); `constraints` is
    # additive coverage for the dimensions those pre-existing fields never
    # represented (customer/operation/package/device/status/...).
    constraints: list[RequestConstraint] = Field(default_factory=list)


class FactoryContext(RCABaseModel):
    factory_id: str
    factory_name: str
    enabled_modules: list[str] = Field(default_factory=list)
    timezone: str = "UTC"


class GoalScope(RCABaseModel):
    time_range_start: datetime | None = None
    time_range_end: datetime | None = None
    plant_id: str | None = None
    line_id: str | None = None


class Goal(RCABaseModel):
    goal_id: str
    raw_statement: str
    normalized_statement: str
    task_type: TaskType
    scope: GoalScope


# --- Human-in-the-loop -------------------------------------------------------


class ResumeTarget(RCABaseModel):
    """Audit/UI metadata only -- NOT the resume mechanism itself. Resuming a
    paused module subgraph is handled by LangGraph's interrupt()/Command(
    resume=...) against that exact paused task, keyed by request_id."""

    module_id: str | None = None
    node: str
    objective_id: str | None = None


class HumanResponse(RCABaseModel):
    decision: HumanDecision
    payload: str | None = None
    responded_by: str
    responded_at: datetime


class HumanRequest(RCABaseModel):
    request_id: str
    run_id: str
    module_id: str | None = None
    branch_id: str | None = None
    objective_id: str | None = None
    source_node: str
    reason: HumanReason
    question: str
    options: list[str] | None = None
    permission_type: str | None = None
    risk_level: RiskLevel | None = None
    resume_target: ResumeTarget
    status: HumanRequestStatus = HumanRequestStatus.PENDING
    response: HumanResponse | None = None
    created_at_step: int


# --- Learning (Phase 7C) ------------------------------------------------------
#
# LearningCandidate is what `AgentState.learning_candidates` actually holds
# -- evolved in place from the Phase 1 placeholder `CandidateInsight`
# (KNOWLEDGE/PATTERN/STRATEGY, three-field-shallow, never once constructed
# anywhere in this codebase before this phase -- confirmed by grep, same
# situation `HandoffPackage`/`RunEvaluation` were in before their own
# phases). Building/scoring/merging one is agent/learning/'s job; this
# model is only the data shape. `LearningEvidenceLink`/`LearningRunSnapshot`
# /`CandidateReview` are sink-only artifacts (never referenced by
# AgentState directly), so they live in agent/learning/ instead -- same
# split PlannerDecisionRecord/EvaluationRecord already established.


class LearningCandidate(RCABaseModel):
    """The Phase 7C invariant this schema exists to make checkable: nothing
    in `agent/learning/` ever constructs one with
    `status=LearningCandidateStatus.VALIDATED` -- see
    tests/test_learning_promotion_boundary.py's grep-level regression."""

    candidate_id: str
    candidate_type: LearningCandidateType
    title: str
    statement: str
    status: LearningCandidateStatus = LearningCandidateStatus.CANDIDATE
    confidence: float
    source_run_ids: list[str] = Field(default_factory=list)
    source_module_ids: list[str] = Field(default_factory=list)
    supporting_finding_ids: list[str] = Field(default_factory=list)
    supporting_root_cause_ids: list[str] = Field(default_factory=list)
    evaluation_issue_ids: list[str] = Field(default_factory=list)
    feedback_issue_ids: list[str] = Field(default_factory=list)
    planner_decision_record_ids: list[str] = Field(default_factory=list)
    supporting_signal_count: int = 0
    contradicting_signal_count: int = 0
    created_at: datetime
    updated_at: datetime
    scope: str  # free-form scope descriptor, e.g. "factory-a/OEE" -- deliberately not a closed enum, a new factory/module never requires a schema change
    proposed_destination: LearningDestination
    # A dedup/merge key (item 14), NOT the free-text `statement` --
    # (candidate_type, scope, normalized pattern/action/capability key).
    # See agent/learning/candidate_key.py.
    candidate_key: str
    rationale_summary: str  # concise -- never chain-of-thought
    schema_version: str = "1"  # Phase 8A item 22 -- durable migration marker, never the Python class name


# --- Synthesis / handoff (Phase 6A) ----------------------------------------
#
# ModuleState -> ModuleHandoff -> SynthesisContext (agent/llm/context/
# synthesis_context.py) -> HandoffPackage -> deterministic Markdown
# (agent/synthesis/). Everything below is a *projection* of ModuleState's
# analysis results, never a second copy of runtime/audit data: no
# objective_history, raw Observation/Evidence payloads, ToolCallRecord,
# LLMCallRecord, ContextBuildRecord, PlannerDecisionRecord, or Human audit
# internals reaches this layer -- see agent/synthesis/handoff_builder.py's
# own docstring for the full exclusion list, mirroring the same
# "Full State != LLM/Handoff Context" discipline PlannerContext established
# in Phase 5C-1.


class RootCause(RCABaseModel):
    root_cause_id: str
    statement: str
    module_id: str
    entity_ids: list[str] = Field(default_factory=list)
    confidence: float
    supporting_finding_ids: list[str] = Field(default_factory=list)


class EvidenceSummary(RCABaseModel):
    module_id: str
    summary: str
    evidence_ids: list[str] = Field(default_factory=list)
    quality: EvidenceQuality


class BranchHandoffSummary(RCABaseModel):
    """Compact Branch projection -- name/pattern/status/priority only, no
    tree_node_id/execution_strategy/depth (runtime-routing details with no
    reader-facing meaning)."""

    branch_id: str
    name: str
    pattern: str
    status: BranchStatus
    priority_score: float
    entity_ids: list[str] = Field(default_factory=list)


class ModuleHandoff(RCABaseModel):
    """Phase 6A item 1 -- Synthesis's *only* view of one module's analysis
    result; it never reads ModuleState directly. Built once per module by
    `ModuleHandoffBuilder.build()`, purely deterministic (no LLM)."""

    module_id: str
    module_type: str
    task_type: TaskType
    module_status: ModuleStatus
    module_goal: str
    executive_finding: str  # one deterministic sentence -- never LLM-authored this phase
    confirmed_findings: list[Finding] = Field(default_factory=list)  # FindingStatus.CONFIRMED only
    hypotheses: list[Hypothesis] = Field(default_factory=list)  # still-OPEN hypotheses -- the unresolved signal
    root_causes: list[RootCause] = Field(default_factory=list)  # only from CONFIRMED + is_root_cause=True findings
    key_entities: list[str] = Field(default_factory=list)
    branch_summary: list[BranchHandoffSummary] = Field(default_factory=list)
    evidence_summary: list[EvidenceSummary] = Field(default_factory=list)
    limitations: list[Limitation] = Field(default_factory=list)
    unresolved_questions: list[str] = Field(default_factory=list)
    confidence: float
    evidence_coverage: float


class CrossModuleRelation(RCABaseModel):
    """Phase 6A item 5 -- contract only this phase; the deterministic
    synthesizer never constructs one automatically (no cross-module
    correlation detection yet). The validator below is the hard guarantee
    that survives even after a future phase starts auto-generating these:
    a CONFIRMED_CAUSAL claim must always carry supporting findings, and
    nothing here promotes mere temporal coincidence to causality on its
    own -- that promotion, if it ever happens, must show its work via
    `supporting_finding_ids`."""

    relation_id: str
    source_modules: list[str]
    relation_type: RelationType
    statement: str
    supporting_finding_ids: list[str] = Field(default_factory=list)
    confidence: float
    validation_status: RelationValidationStatus = RelationValidationStatus.CANDIDATE

    @model_validator(mode="after")
    def _confirmed_causal_requires_support(self) -> "CrossModuleRelation":
        if self.relation_type == RelationType.CONFIRMED_CAUSAL and not self.supporting_finding_ids:
            raise ValueError("a CONFIRMED_CAUSAL relation must have at least one supporting_finding_id")
        return self


class RecommendationCandidate(RCABaseModel):
    """Phase 6A item 7 -- contract only; the deterministic synthesizer
    produces zero of these automatically this phase (no auto-recommendation
    quality bar has been established yet). The validator is the hard
    guarantee: a recommendation can never be source-less."""

    recommendation_id: str
    statement: str
    based_on_finding_ids: list[str] = Field(default_factory=list)
    based_on_root_cause_ids: list[str] = Field(default_factory=list)
    action_type: RecommendationActionType
    confidence: float

    @model_validator(mode="after")
    def _requires_lineage(self) -> "RecommendationCandidate":
        if not self.based_on_finding_ids and not self.based_on_root_cause_ids:
            raise ValueError("a RecommendationCandidate must be based on at least one finding or root cause")
        return self


class ConfidenceSummary(RCABaseModel):
    overall_confidence: float
    module_confidence: dict[str, float] = Field(default_factory=dict)
    evidence_coverage: float


class HandoffPackage(RCABaseModel):
    """The final machine-readable handoff interface (Phase 6A item 6) for a
    future Report Agent / Dashboard / Presentation Agent / API consumer.
    `overall_status` is always computed by `agent.synthesis.package.
    compute_overall_status` (deterministic, rule-based) -- never an LLM
    decision, see that function's own docstring."""

    run_id: str
    request_summary: str
    task_type: TaskType
    overall_status: SynthesisOverallStatus
    module_results: list[ModuleHandoff] = Field(default_factory=list)
    key_findings: list[Finding] = Field(default_factory=list)
    root_causes: list[RootCause] = Field(default_factory=list)
    cross_module_relations: list[CrossModuleRelation] = Field(default_factory=list)
    limitations: list[Limitation] = Field(default_factory=list)
    unresolved_questions: list[str] = Field(default_factory=list)
    recommendation_candidates: list[RecommendationCandidate] = Field(default_factory=list)
    confidence_summary: ConfidenceSummary
    markdown: str = ""


# --- Run evaluation (Phase 7A) ------------------------------------------------
#
# RunEvaluator (agent/evaluation/evaluator.py) is a run-level, read-only,
# post-analysis Harness service -- deterministic/metric-based this phase,
# no LLM judge. It judges *what happened* (efficiency/quality/decisions/
# delivery); it never proposes what should change (that's Learning's job,
# Phase 7C -- see the architecture note in agent/evaluation/evaluator.py).


class EfficiencyMetrics(RCABaseModel):
    """Tool-call semantics deliberately kept apart per the Phase 5B-1.2
    terminology freeze (see agent/tools/execution_manager.py's own
    docstring): logical / manager-invocation / physical-execution /
    replay / reuse are five different counts, never collapsed into one
    `tool_call_count`."""

    total_module_count: int
    completed_module_count: int
    planner_decision_count: int
    objective_count: int
    logical_tool_call_count: int
    tool_manager_invocation_count: int
    physical_tool_execution_count: int
    result_reuse_count: int
    replay_count: int
    failed_tool_execution_count: int
    total_llm_calls: int
    llm_retry_count: int
    input_tokens: int
    output_tokens: int
    total_context_characters: int
    context_trim_count: int
    human_intervention_count: int
    total_duration_ms: float | None = None


class AnalyticalQualityMetrics(RCABaseModel):
    evidence_coverage: float
    confirmed_finding_ratio: float
    root_cause_support_score: float
    limitation_transparency_score: float
    unresolved_question_transparency: float
    failed_module_ratio: float
    blocked_module_ratio: float
    partial_module_ratio: float
    synthesis_fact_consistency: float
    cross_module_relation_support_score: float


class AnalyzerDecisionQuality(RCABaseModel):
    selected_module_count: int
    module_selection_validity: float
    unsupported_module_selection_count: int
    analyzer_fallback_used: bool


class PlannerDecisionQualityAggregate(RCABaseModel):
    """`average_planner_quality`/`minimum_planner_quality` are `None` unless
    the caller supplies precomputed `PlannerDecisionQuality` scores (Phase
    5C-3's `evaluate_planner_decision_quality`) -- retrospectively
    recomputing one from a persisted `PlannerDecisionRecord` alone isn't
    possible (that record doesn't carry the ModuleState snapshot the
    decision was made against). `baseline_alignment_score` is one signal
    among several, never the only quality measure (Phase 5C-2.1
    architecture note) -- also `None` unless supplied."""

    average_planner_quality: float | None = None
    minimum_planner_quality: float | None = None
    invalid_decision_count: int
    fallback_decision_count: int
    redundant_target_count: int
    unnecessary_deep_dive_count: int
    baseline_alignment_score: float | None = None


class DecisionQualityMetrics(RCABaseModel):
    analyzer: AnalyzerDecisionQuality
    planner: PlannerDecisionQualityAggregate


class DeliveryQualityMetrics(RCABaseModel):
    request_answered_score: float
    module_result_coverage: float
    root_cause_lineage_validity: float
    limitation_preservation: float
    task_type_depth_compliance: float
    synthesis_status_consistency: float
    hallucination_guard_passed: bool


class EvaluationWeighting(RCABaseModel):
    """A strategy/config, not a hard-coded truth -- `RunEvaluator` accepts
    a caller-supplied instance; this default is only a reasonable starting
    point. Must sum to 1.0."""

    analytical_quality: float = 0.35
    decision_quality: float = 0.30
    delivery_quality: float = 0.25
    efficiency: float = 0.10

    @model_validator(mode="after")
    def _weights_sum_to_one(self) -> "EvaluationWeighting":
        total = self.analytical_quality + self.decision_quality + self.delivery_quality + self.efficiency
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"EvaluationWeighting must sum to 1.0, got {total}")
        return self


class EvaluationIssue(RCABaseModel):
    issue_id: str
    category: EvaluationCategory
    severity: EvaluationSeverity
    statement: str
    related_module_ids: list[str] = Field(default_factory=list)
    related_objective_ids: list[str] = Field(default_factory=list)
    metric_name: str
    evidence_refs: list[str] = Field(default_factory=list)
    suggested_improvement_area: str


class RunEvaluation(RCABaseModel):
    """`overall_score` is optional and, when present, always
    `weighting`-derived (agent/evaluation/evaluator.py) -- never a bare
    number without the dimension scores and weighting that produced it.

    `evaluation_id` (Phase 8A lineage fix): a run can legitimately be
    re-evaluated (e.g. after a Human Feedback update), so `run_id` alone
    is not a stable persistence key for this record -- `evaluation_id` is
    the same id `EvaluationRecord.evaluation_id` (agent/evaluation/audit.py)
    correlates to, generated once per `RunEvaluator.evaluate()` call and
    threaded through both."""

    evaluation_id: str
    run_id: str
    evaluator_version: str
    evaluated_at: datetime
    efficiency: EfficiencyMetrics
    analytical_quality: AnalyticalQualityMetrics
    decision_quality: DecisionQualityMetrics
    delivery_quality: DeliveryQualityMetrics
    issues: list[EvaluationIssue] = Field(default_factory=list)
    weighting: EvaluationWeighting | None = None
    overall_score: float | None = None
    schema_version: str = "1"


# --- Post-run Human Feedback (Phase 7A contract, Phase 7B target
# granularity + lineage validation -- contract + InMemory sink only, never
# mixed into RunEvaluation's deterministic score, see
# agent/persistence/human_feedback.py and agent/feedback/) -------------------
#
# Deliberately a completely separate concept from HumanRequest/
# HumanAuditSink (agent/persistence/human_audit.py): that is the in-run
# interrupt/permission-approval flow (Execution Gate asking "may I do
# this?"); HumanFeedback is post-run evaluation feedback ("was this
# right?") submitted after a run has already finished. Never merged into
# one table/model -- see agent/feedback/'s own architecture note.


class HumanFeedback(RCABaseModel):
    """Four independent signal groups, never collapsed into one thumb
    (Phase 7B item 2): Experience (`thumbs`/`answer_helpful`), Analytical
    validation (`finding_correct`/`root_cause_correct`), Action usefulness
    (`recommendation_useful`). A thumbs-down never implies
    root_cause_correct=False, and vice versa -- each field is only ever set
    by an explicit, separate human input.

    `target_id` presence is structurally enforced by `target_type`: RUN/
    SYNTHESIS may omit it (exactly one of each per run); MODULE/FINDING/
    ROOT_CAUSE/RECOMMENDATION require it. This is a *structural* check only
    (is target_id present when it must be) -- whether that id actually
    refers to something real in this run's HandoffPackage is a separate,
    data-dependent check, see agent/feedback/validation.py's
    `validate_human_feedback` (deliberately not a model_validator here,
    since it needs the HandoffPackage to check against).
    """

    feedback_id: str
    run_id: str
    target_type: FeedbackTargetType
    target_id: str | None = None
    user_id: str | None = None
    thumbs: HumanFeedbackThumbs = HumanFeedbackThumbs.NONE
    answer_helpful: bool | None = None
    root_cause_correct: bool | None = None
    finding_correct: bool | None = None
    recommendation_useful: bool | None = None
    comment: str | None = None
    # Audit metadata (Phase 7B item 10) -- never anything sensitive beyond
    # a channel label/session correlation id.
    source: str | None = None
    session_id: str | None = None
    feedback_version: str = "1"
    created_at: datetime

    @model_validator(mode="after")
    def _target_id_matches_target_type(self) -> "HumanFeedback":
        requires_target_id = {FeedbackTargetType.MODULE, FeedbackTargetType.FINDING, FeedbackTargetType.ROOT_CAUSE, FeedbackTargetType.RECOMMENDATION}
        if self.target_type in requires_target_id and self.target_id is None:
            raise ValueError(f"HumanFeedback.target_type={self.target_type.value} requires target_id to be set")
        return self


# --- Execution audit trail ------------------------------------------------------


class ExecutionStep(RCABaseModel):
    step_id: str
    step_index: int
    node_name: str
    module_id: str | None = None
    summary: str
    started_at: datetime
    ended_at: datetime | None = None
