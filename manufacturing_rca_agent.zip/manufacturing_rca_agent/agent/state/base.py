from pydantic import BaseModel, ConfigDict


class RCABaseModel(BaseModel):
    """Shared base for all agent models: strict schema, validated mutation.

    extra="forbid" enforces that every field is explicitly declared (no
    silent dict[str, Any] drift). validate_assignment=True keeps in-place
    mutations (e.g. AnalysisTree.set_status) subject to the same validation
    as construction.
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True)
