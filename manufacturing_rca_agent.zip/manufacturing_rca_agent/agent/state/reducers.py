"""Reducer functions for AgentState / ModuleState channels.

These follow LangGraph's `Annotated[Type, reducer]` convention: when a graph
node returns a partial update for a field, LangGraph calls
`reducer(existing_value, update_value)` to combine it with the current
channel value. They are defined here with no dependency on langgraph itself,
so the state schema in `state.py` (and `ModuleState` in `models.py`) is
ready to be used directly as a LangGraph state schema in Phase 2 without
modification.
"""
from typing import TypeVar

T = TypeVar("T")


def append_list(existing: list[T], update: list[T]) -> list[T]:
    """Append-only history channel (execution_history, evidence, findings, ...).

    Nodes must return updates as a list, even for a single new item, e.g.
    `{"errors": [new_error]}`, matching LangGraph's `add_messages` convention.
    """
    return [*existing, *update]


def merge_by_key(existing: dict[str, T], update: dict[str, T]) -> dict[str, T]:
    """Key-wise merge for dict channels written by multiple branches.

    Used for `module_states` (written by parallel Send()-dispatched module
    subgraphs, one key each), `human_requests` (keyed by request_id -- needs
    update-in-place when a request moves PENDING -> RESOLVED, and multiple
    module subgraphs could raise requests in the same step), and for
    `branches` / `entity_states` within a module (new entities/branches
    discovered in one step must not clobber ones discovered in a previous
    step). Each key's value is replaced wholesale by the latest update for
    that key.
    """
    merged = dict(existing)
    merged.update(update)
    return merged
