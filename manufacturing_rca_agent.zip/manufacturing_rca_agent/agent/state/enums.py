from enum import Enum


class TaskType(str, Enum):
    INFORMATION = "information"
    ANALYSIS = "analysis"
    RCA = "rca"


class ModuleStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETE = "complete"
    PARTIAL = "partial"
    FAILED = "failed"
    BLOCKED = "blocked"
    SKIPPED = "skipped"


TERMINAL_MODULE_STATUSES = frozenset(
    {
        ModuleStatus.COMPLETE,
        ModuleStatus.PARTIAL,
        ModuleStatus.FAILED,
        ModuleStatus.BLOCKED,
        ModuleStatus.SKIPPED,
    }
)


class TreeNodeType(str, Enum):
    MODULE = "module"
    DIMENSION = "dimension"
    ENTITY = "entity"
    ENTITY_GROUP = "entity_group"
    FINDING = "finding"


class TreeNodeStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    SKIPPED = "skipped"
    REJECTED = "rejected"


class BranchStatus(str, Enum):
    PENDING = "pending"
    ACTIVE = "active"
    COMPLETED = "completed"
    SKIPPED = "skipped"
    MERGED = "merged"


class EntityAnalysisStatus(str, Enum):
    SCREENED = "screened"
    INVESTIGATING = "investigating"
    ROOT_CAUSE_FOUND = "root_cause_found"
    STALLED = "stalled"
    SKIPPED = "skipped"


class FindingStatus(str, Enum):
    HYPOTHESIS = "hypothesis"
    CONFIRMED = "confirmed"
    REJECTED = "rejected"


class HypothesisStatus(str, Enum):
    OPEN = "open"
    SUPPORTED = "supported"
    REFUTED = "refuted"


class EvidenceQuality(str, Enum):
    STRONG = "strong"
    MODERATE = "moderate"
    WEAK = "weak"


class ExecutionStrategy(str, Enum):
    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"
    HYBRID = "hybrid"


class ObservationStatus(str, Enum):
    SUCCESS = "success"
    ERROR = "error"


class ErrorType(str, Enum):
    DATA_NOT_FOUND = "data_not_found"
    DATA_NOT_READY = "data_not_ready"
    QUERY_ERROR = "query_error"
    INVALID_QUERY = "invalid_query"
    PERMISSION_DENIED = "permission_denied"
    TOOL_ERROR = "tool_error"
    TIMEOUT = "timeout"
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"
    AMBIGUOUS = "ambiguous"
    # Phase 5B-2.1: distinct from QUERY_ERROR on purpose -- QUERY_ERROR means
    # a capability/Tool exists but its execution failed; CAPABILITY_NOT_FOUND
    # means the Harness has no Skill/Tool that can service this Objective's
    # `action` at all (CapabilityResolutionError). Evaluator/Learning need to
    # tell "broken execution" apart from "missing capability" -- the fix for
    # one is retry/fallback, the fix for the other is registering a new
    # Skill/Tool, and conflating them would hide that distinction.
    CAPABILITY_NOT_FOUND = "capability_not_found"


class ObjectiveAction(str, Enum):
    """Generic analytical verb (Phase WB-2B.1 -- landed Phase 8B-1's
    `objective_action_design_review.md` Option 2). Says WHAT KIND of
    analytical action/depth an Objective wants -- never a domain-specific
    capability name (that lives in `Objective.capability_key`, a free
    string `CapabilityResolver` validates against a Skill's own declared
    `capability_key` at resolve time -- see `agent/capability/resolver.py`).

    Deliberately separate from `Objective.description` (human/LLM-readable
    explanation) and from `TargetRef` (which entity/branch/module the
    action applies to). Small and stable by design: a new domain should
    almost always reuse an existing verb (e.g. WB's aging/hold analyses
    both use ANALYZE, exactly like OEE's deep-dive uses DRILL_DOWN) rather
    than mint a new one -- only a genuinely new analytical *shape* (not a
    new domain) justifies adding a member here.

    Migration note: this enum previously held OEE-specific, capability-
    shaped members (`EQUIPMENT_SCREENING`/`EQUIPMENT_DETAIL`/
    `CURRENT_STATUS`/`GENERIC_QUERY`). Renamed, not aliased -- this repo
    has no external persisted runtime depending on the old values (Phase
    WB-2B.1 report confirms this via a repo-wide reference search).
    """

    QUERY = "query"
    SUMMARIZE = "summarize"
    SCREEN = "screen"
    COMPARE = "compare"
    ANALYZE = "analyze"
    DRILL_DOWN = "drill_down"


class LearningCandidateType(str, Enum):
    """Phase 7C taxonomy (evolved from the Phase 1 placeholder `InsightKind`
    KNOWLEDGE/PATTERN/STRATEGY, which nothing ever constructed -- see the
    Phase 7C report for the zero-usage confirmation). Four kinds,
    deliberately never conflated (agent/learning/'s own architecture
    note): a domain fact/association, a Planner strategy observation, a
    presentation/reasoning-framework preference, and a missing capability
    are different enough in what happens to them next (Knowledge Base vs.
    Planner strategy vs. Reasoning Skill vs. Capability backlog -- see
    LearningDestination) that merging them into one generic "insight"
    would lose exactly the distinction Learning needs to stay safe."""

    KNOWLEDGE_PATTERN = "knowledge_pattern"
    PLANNING_STRATEGY = "planning_strategy"
    REASONING_SKILL = "reasoning_skill"
    CAPABILITY_GAP = "capability_gap"


class LearningCandidateStatus(str, Enum):
    """Evolved from the Phase 1 placeholder `InsightStatus`
    (CANDIDATE/VALIDATED/REJECTED) -- adds DEPRECATED. The Phase 7C
    invariant: `LearningCandidateGenerator.generate()` (agent/learning/
    generator.py) never constructs anything but CANDIDATE -- VALIDATED is
    reachable only through a future human/Learning-review promotion step
    that does not exist in this codebase yet (see
    agent/learning/promotion.py's `NoAutoPromotionPolicy`)."""

    CANDIDATE = "candidate"
    REJECTED = "rejected"
    VALIDATED = "validated"
    DEPRECATED = "deprecated"


class LearningDestination(str, Enum):
    """Where a candidate, if ever promoted, would eventually be written --
    a proposal only (Phase 7C item 15). Nothing in this codebase writes to
    any of these destinations automatically."""

    KNOWLEDGE_BASE = "knowledge_base"
    PLANNER_STRATEGY = "planner_strategy"
    REASONING_SKILL = "reasoning_skill"
    CAPABILITY_BACKLOG = "capability_backlog"


class LearningSignalType(str, Enum):
    """What kind of evidence one `LearningEvidenceLink` carries -- never
    conflated (item 5's explicit rule: a thumbs-up is not equivalent to a
    human validating a root cause)."""

    CONFIRMED_FINDING = "confirmed_finding"
    CONFIRMED_ROOT_CAUSE = "confirmed_root_cause"
    REPEATED_PATTERN = "repeated_pattern"
    HIGH_EVALUATION_SCORE = "high_evaluation_score"
    HUMAN_ROOT_CAUSE_VALIDATION = "human_root_cause_validation"
    HUMAN_FINDING_VALIDATION = "human_finding_validation"
    HUMAN_PREFERENCE = "human_preference"
    EFFICIENCY_IMPROVEMENT = "efficiency_improvement"
    CAPABILITY_NOT_FOUND = "capability_not_found"
    NEGATIVE_HUMAN_FEEDBACK = "negative_human_feedback"
    CONTRADICTING_FINDING = "contradicting_finding"


class CandidateReviewDecision(str, Enum):
    APPROVE = "approve"
    REJECT = "reject"
    NEEDS_MORE_EVIDENCE = "needs_more_evidence"


class RunTerminationStatus(str, Enum):
    RUNNING = "running"
    READY_FOR_SYNTHESIS = "ready_for_synthesis"
    BUDGET_EXCEEDED = "budget_exceeded"
    BLOCKED = "blocked"


class HumanReason(str, Enum):
    UNCLEAR_INTENT = "unclear_intent"
    PERMISSION_REQUIRED = "permission_required"
    HIGH_RISK_ACTION = "high_risk_action"


class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class HumanRequestStatus(str, Enum):
    PENDING = "pending"
    RESOLVED = "resolved"


class HumanDecision(str, Enum):
    APPROVE = "approve"
    REJECT = "reject"
    PROVIDE_INFO = "provide_info"
    CHOOSE_OPTION = "choose_option"


class StandardizerDecision(str, Enum):
    OK = "ok"
    BLOCKED = "blocked"
    NEEDS_HUMAN = "needs_human"


class CoordinatorDecision(str, Enum):
    DISPATCH = "dispatch"
    WAIT = "wait"
    ALL_TERMINAL = "all_terminal"


class ModulePlannerDecision(str, Enum):
    DISPATCH = "dispatch"
    NO_VIABLE_OBJECTIVE = "no_viable_objective"


class GateDecision(str, Enum):
    PASS = "pass"
    REJECTED = "rejected"


class ReflectorVerdict(str, Enum):
    CONTINUE = "continue"
    RETRY = "retry"
    CANDIDATE_COMPLETE = "candidate_complete"
    PERMISSION_DENIED_AT_RUNTIME = "permission_denied_at_runtime"


class TargetRefType(str, Enum):
    BRANCH = "branch"
    ENTITY = "entity"
    MODULE = "module"


class ObjectiveStatus(str, Enum):
    PENDING = "pending"
    DISPATCHED = "dispatched"
    COMPLETED = "completed"
    REJECTED = "rejected"


# --- Synthesis / handoff (Phase 6A) ----------------------------------------


class SynthesisOverallStatus(str, Enum):
    """Deterministic, rule-based rollup of every selected module's own
    ModuleStatus (agent/synthesis/package.py's `compute_overall_status`) --
    never an LLM decision. Deliberately a narrower set than ModuleStatus:
    there is no top-level BLOCKED/SKIPPED -- a BLOCKED module folds into
    COMPLETE/PARTIAL/FAILED depending on whether other modules still answer
    the global goal, and its authorization gap is reported via that
    module's own ModuleHandoff instead (see module_completion_check.py's
    BLOCKED rule and ModuleHandoffBuilder's per-status handling)."""

    COMPLETE = "complete"
    PARTIAL = "partial"
    FAILED = "failed"


class RelationType(str, Enum):
    """How two-or-more modules' findings relate -- ordered roughly by
    strength of claim. CONFIRMED_CAUSAL is the only tier
    `CrossModuleRelation`'s own validator refuses to accept without
    `supporting_finding_ids` -- Synthesis must never promote a temporal
    coincidence straight to causality (Phase 6A spec's explicit rule)."""

    CORRELATED = "correlated"
    SUPPORTS = "supports"
    CAUSAL_CANDIDATE = "causal_candidate"
    CONFIRMED_CAUSAL = "confirmed_causal"


class RelationValidationStatus(str, Enum):
    CANDIDATE = "candidate"
    VALIDATED = "validated"


class RecommendationActionType(str, Enum):
    INVESTIGATE_FURTHER = "investigate_further"
    MAINTENANCE_ACTION = "maintenance_action"
    PROCESS_CHANGE = "process_change"
    MONITOR = "monitor"
    ESCALATE = "escalate"


# --- Evaluation (Phase 7A) ---------------------------------------------------


class EvaluationCategory(str, Enum):
    """Which of RunEvaluation's four dimensions an EvaluationIssue belongs
    to -- mirrors RunEvaluation's own top-level field names exactly, so an
    issue's category always names a real, inspectable metric group."""

    EFFICIENCY = "efficiency"
    ANALYTICAL_QUALITY = "analytical_quality"
    DECISION_QUALITY = "decision_quality"
    DELIVERY_QUALITY = "delivery_quality"


class EvaluationSeverity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class HumanFeedbackThumbs(str, Enum):
    UP = "up"
    DOWN = "down"
    NONE = "none"


class FeedbackTargetType(str, Enum):
    """What one HumanFeedback record is actually about (Phase 7B) -- drives
    HumanFeedback's own structural target_id validator (RUN/SYNTHESIS may
    omit target_id -- there is only ever one of each per run; MODULE/
    FINDING/ROOT_CAUSE/RECOMMENDATION require one, since a run can have
    several)."""

    RUN = "run"
    MODULE = "module"
    FINDING = "finding"
    ROOT_CAUSE = "root_cause"
    RECOMMENDATION = "recommendation"
    SYNTHESIS = "synthesis"
