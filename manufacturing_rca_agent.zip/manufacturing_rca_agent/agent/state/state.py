from datetime import datetime
from typing import Annotated

from pydantic import Field

from agent.state.base import RCABaseModel
from agent.state.enums import RunTerminationStatus
from agent.state.models import (
    Budget,
    ControlSignals,
    ErrorRecord,
    ExecutionStep,
    FactoryContext,
    Goal,
    HandoffPackage,
    HumanRequest,
    LearningCandidate,
    ModuleDispatchState,
    ModuleState,
    ModuleTask,
    NormalizedRequest,
    RunEvaluation,
    RunMetrics,
    UserRequest,
)
from agent.state.reducers import append_list, merge_by_key


class AgentState(RCABaseModel):
    """Global/run-level state owned by Standardizer, Analyzer, Module
    Coordinator, Global Completion Check, Synthesis, Evaluator and Learning.
    Per-module analysis process lives in `module_states[*]` (ModuleState),
    never here -- there is deliberately no global `current_plan` /
    `current_objective`.
    """

    run_id: str
    user_request: UserRequest
    normalized_request: NormalizedRequest | None = None
    factory_context: FactoryContext

    # Lifecycle timestamps (Phase 8A-1) -- `started_at` is when the Graph
    # actually began executing (Standardizer, the first node), never
    # `UserRequest.submitted_at` (a different moment -- submission and
    # execution start can legitimately differ). `completed_at` is set once
    # by Global Completion Check when the run reaches a terminal decision;
    # `None` means still running/interrupted. Both are write-once -- see
    # standardizer_mock.py/global_completion_check.py's own guards, not a
    # model_validator here (a partial-state channel update mid-run must
    # never be blocked by a completeness check on the other field).
    started_at: datetime | None = None
    completed_at: datetime | None = None

    global_goal: Goal | None = None
    selected_modules: list[ModuleTask] = Field(default_factory=list)
    module_states: Annotated[dict[str, ModuleState], merge_by_key] = Field(default_factory=dict)
    module_dispatch: ModuleDispatchState = Field(default_factory=ModuleDispatchState)

    # Optional runtime projection / convenience view only -- NOT the Human
    # audit source-of-truth (that's HumanAuditSink, see
    # agent/persistence/human_audit.py). Phase 5B-1.2: the pending-interrupt
    # window never writes here anymore, because doing so required
    # `app.update_state()` on a checkpoint with a still-pending Send task,
    # which Phase 5B-1.1 showed re-executes that entire pending superstep on
    # resume. If a resolved-history projection into AgentState is wanted
    # later, it must be written at a point with no pending superstep (e.g.
    # after a run fully settles), never during a pending interrupt.
    human_requests: Annotated[dict[str, HumanRequest], merge_by_key] = Field(default_factory=dict)

    global_budget: Budget
    global_metrics: RunMetrics = Field(default_factory=RunMetrics)

    synthesis_result: HandoffPackage | None = None
    run_evaluation: RunEvaluation | None = None
    learning_candidates: Annotated[list[LearningCandidate], append_list] = Field(default_factory=list)

    execution_history: Annotated[list[ExecutionStep], append_list] = Field(default_factory=list)
    errors: Annotated[list[ErrorRecord], append_list] = Field(default_factory=list)

    termination_status: RunTerminationStatus = RunTerminationStatus.RUNNING
    control: ControlSignals = Field(default_factory=ControlSignals)
