"""Structured payload envelope (Phase 5B-1) -- replaces the Phase 5A
workaround of JSON-encoding structured tool output directly into
`Evidence.summary`. `summary` goes back to being pure human-readable text;
this is the machine-readable side.

`StructuredPayload.data` is the one deliberately generic field left in this
codebase: an envelope whose entire job is carrying an arbitrary *registered*
type across a boundary needs *a* generic slot somewhere. `dict[str,
JsonValue]` keeps it JSON-safe (no arbitrary Python objects) without pinning
it to one domain's shape. The discipline is that nothing reads `.data`
directly -- every caller goes through `PayloadRegistry.pack`/`unpack` and
gets a real, fully-typed Pydantic instance back.
"""
from pydantic import JsonValue

from agent.state.base import RCABaseModel


class StructuredPayload(RCABaseModel):
    payload_type: str
    schema_version: str = "1"
    data: dict[str, JsonValue]


class PayloadRegistry:
    """Process-wide registry mapping `payload_type` -> the Pydantic model it
    packs/unpacks as. Domain modules register their result types at import
    time (see agent/domain/oee/dataset.py)."""

    _types: dict[str, type[RCABaseModel]] = {}

    @classmethod
    def register(cls, payload_type: str, model: type[RCABaseModel]) -> None:
        cls._types[payload_type] = model

    @classmethod
    def pack(cls, payload_type: str, instance: RCABaseModel) -> StructuredPayload:
        if payload_type not in cls._types:
            raise ValueError(f"payload_type '{payload_type}' is not registered")
        return StructuredPayload(payload_type=payload_type, data=instance.model_dump(mode="json"))

    @classmethod
    def unpack(cls, payload: StructuredPayload) -> RCABaseModel:
        return cls.model_for(payload.payload_type).model_validate(payload.data)

    @classmethod
    def model_for(cls, payload_type: str) -> type[RCABaseModel]:
        """Phase 5B-2: lets a caller (SkillRunner) validate a *candidate*
        dict against a registered type's schema before it has a
        StructuredPayload to unpack -- e.g. Skill parameter mapping output,
        which must conform to a Tool's declared input_payload_type."""
        model_cls = cls._types.get(payload_type)
        if model_cls is None:
            raise ValueError(f"payload_type '{payload_type}' is not registered")
        return model_cls
