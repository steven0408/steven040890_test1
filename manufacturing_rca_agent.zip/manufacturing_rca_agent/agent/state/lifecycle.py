"""Duration projection (Phase 8A-1 item 5): pure, derived-never-stored
helpers over the Run/Module `started_at`/`completed_at` timestamps added in
this phase. Neither `AgentState`/`ModuleState` nor any persistence record
stores a duration field -- callers (Evaluator, persistence projection)
compute it on demand from the two timestamps, so there is exactly one
source of truth and no risk of a stale cached duration.
"""
from agent.state.models import ModuleState
from agent.state.state import AgentState


def run_duration_ms(state: AgentState) -> float | None:
    """None whenever the run hasn't reached its terminal timestamp yet --
    never a fabricated/partial duration for an in-flight run."""
    if state.started_at is None or state.completed_at is None:
        return None
    return (state.completed_at - state.started_at).total_seconds() * 1000


def module_duration_ms(module_state: ModuleState) -> float | None:
    """None for a module that hasn't terminated yet (including one that
    will end up SKIPPED, per the Option-A semantics documented on
    ModuleState.completed_at: SKIPPED means never actually started)."""
    if module_state.started_at is None or module_state.completed_at is None:
        return None
    return (module_state.completed_at - module_state.started_at).total_seconds() * 1000
