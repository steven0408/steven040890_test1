"""SynthesisLLMService (Phase 6B item 1/3/4/16) -- the real/mock LLM
Synthesis path:

    AgentState -> SynthesisContextBuilder -> LLMRouter(route="synthesis")
        -> SynthesisDraft -> validate_synthesis_draft
        -> build_handoff_package_from_draft -> HandoffPackage

On any LLM failure (timeout / provider error / invalid structured output /
semantic-invalid references), falls back to the Phase 6A deterministic
`build_handoff_package` directly -- an already-complete analysis run must
never lose its output because Synthesis's LLM call failed (item 16).
Records `SynthesisSource.LLM`/`FALLBACK` either way via
`SynthesisGenerationAuditSink` if one is configured.
"""
import itertools
from datetime import datetime, timezone
from typing import Callable

from agent.llm.context.synthesis_context import SynthesisContextBuilder
from agent.llm.prompts.synthesis import SynthesisDraft, build_synthesis_messages
from agent.llm.router import LLMRouter, LLMRouterError
from agent.state.models import CrossModuleRelation, HandoffPackage, RecommendationCandidate
from agent.state.state import AgentState
from agent.synthesis.decision_audit import SynthesisGenerationAuditSink, SynthesisGenerationRecord, SynthesisSource
from agent.synthesis.draft_rendering import build_handoff_package_from_draft
from agent.synthesis.package import build_handoff_package
from agent.synthesis.validation import validate_synthesis_draft

_synthesis_record_id_counter = itertools.count(1)


class SynthesisOutcome:
    def __init__(self, package: HandoffPackage, source: SynthesisSource, fallback_reason: str | None = None):
        self.package = package
        self.source = source
        self.fallback_reason = fallback_reason


class SynthesisLLMService:
    def __init__(
        self,
        context_builder: SynthesisContextBuilder,
        router: LLMRouter,
        *,
        route: str = "synthesis",
        decision_audit_sink: SynthesisGenerationAuditSink | None = None,
        now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ):
        self._context_builder = context_builder
        self._router = router
        self._route = route
        self._decision_audit_sink = decision_audit_sink
        self._now_fn = now_fn

    def synthesize(
        self,
        state: AgentState,
        *,
        cross_module_relations: list[CrossModuleRelation] | None = None,
        recommendation_candidates: list[RecommendationCandidate] | None = None,
    ) -> SynthesisOutcome:
        context_outcome = self._context_builder.build(
            state, cross_module_relations=cross_module_relations, recommendation_candidates=recommendation_candidates
        )
        messages = build_synthesis_messages(context_outcome.context)

        def _validate(draft: SynthesisDraft) -> None:
            validate_synthesis_draft(draft, context=context_outcome.context)

        try:
            router_outcome = self._router.call(
                self._route, messages, SynthesisDraft, run_id=state.run_id, module_id=None, node="synthesis", validate=_validate
            )
            draft = router_outcome.parsed_output
            package = build_handoff_package_from_draft(context_outcome.context, draft)
            source, fallback_reason, llm_call_id = SynthesisSource.LLM, None, router_outcome.call_record.llm_call_id
            referenced_finding_ids = list(draft.key_finding_ids)
            referenced_root_cause_ids = list(draft.root_cause_ids)
            referenced_relation_ids = list(draft.relation_ids)
            referenced_recommendation_ids = list(draft.recommendation_ids)
        except LLMRouterError as exc:
            package = build_handoff_package(context_outcome.context)
            source, fallback_reason, llm_call_id = SynthesisSource.FALLBACK, str(exc), None
            referenced_finding_ids = [f.finding_id for f in package.key_findings]
            referenced_root_cause_ids = [rc.root_cause_id for rc in package.root_causes]
            referenced_relation_ids = [r.relation_id for r in package.cross_module_relations]
            referenced_recommendation_ids = [r.recommendation_id for r in package.recommendation_candidates]

        if self._decision_audit_sink is not None:
            self._decision_audit_sink.record(
                SynthesisGenerationRecord(
                    synthesis_record_id=f"synthesis-{next(_synthesis_record_id_counter)}",
                    run_id=state.run_id,
                    source=source,
                    context_build_record_id=context_outcome.record.context_build_record_id,
                    llm_call_id=llm_call_id,
                    included_module_ids=[h.module_id for h in context_outcome.context.module_handoffs],
                    referenced_finding_ids=referenced_finding_ids,
                    referenced_root_cause_ids=referenced_root_cause_ids,
                    referenced_relation_ids=referenced_relation_ids,
                    referenced_recommendation_ids=referenced_recommendation_ids,
                    fallback_reason=fallback_reason,
                    created_at=self._now_fn(),
                )
            )

        return SynthesisOutcome(package=package, source=source, fallback_reason=fallback_reason)
