"""validate_synthesis_draft (Phase 6B item 3) -- semantic validation beyond
SynthesisDraft's pydantic schema, same two-tier pattern as
`validate_planner_decision` (agent/planning/policies/llm.py) and
`validate_analyzer_decision` (agent/graph/nodes/analyzer_llm.py): schema
validation catches structurally-wrong output, this catches
structurally-valid-but-nonsensical output (a reference to an id that
doesn't exist).

Every check here is a referential-integrity check against
`SynthesisContext` -- "does this id actually exist in the data the LLM was
given" -- never a content/quality judgment. Two guarantees fall out of
this "only from context" design for free, with no extra code: a FAILED
module's ModuleHandoff never has any confirmed_findings (Phase 6A's
ModuleHandoffBuilder already guarantees that), so its finding ids are
simply never in the allowed set; a HYPOTHESIS-status finding never
produces a RootCause at all (same builder), so there is no root_cause_id
to reference in the first place -- both are proven directly rather than
assumed, see tests/test_synthesis_semantic_validation.py.
"""
from agent.llm.context.synthesis_context import SynthesisContext
from agent.llm.models import LLMInvalidOutputError
from agent.llm.prompts.synthesis import SynthesisDraft
from agent.state.enums import TaskType


class SynthesisSemanticValidationError(LLMInvalidOutputError):
    """A subclass, not a new sibling exception -- LLMRouter's failure
    handling is isinstance-based (agent/llm/router.py's `_status_for`), so
    this is treated exactly like the client producing invalid structured
    output: recorded INVALID_OUTPUT, retried, and once retries are
    exhausted, triggers SynthesisLLMService's fallback to the deterministic
    synthesizer."""


def validate_synthesis_draft(draft: SynthesisDraft, *, context: SynthesisContext) -> None:
    module_ids = {h.module_id for h in context.module_handoffs}
    finding_ids = {f.finding_id for h in context.module_handoffs for f in h.confirmed_findings}
    root_cause_ids = {rc.root_cause_id for h in context.module_handoffs for rc in h.root_causes}
    limitation_ids = {lim.limitation_id for h in context.module_handoffs for lim in h.limitations}
    relation_ids = {r.relation_id for r in context.cross_module_relations}
    recommendation_ids = {r.recommendation_id for r in context.recommendation_candidates}

    for summary in draft.module_summaries:
        if summary.module_id not in module_ids:
            raise SynthesisSemanticValidationError(f"module_summaries references unknown module_id '{summary.module_id}'")

    for finding_id in draft.key_finding_ids:
        if finding_id not in finding_ids:
            raise SynthesisSemanticValidationError(f"key_finding_ids references unknown finding_id '{finding_id}' -- possible hallucination")

    for root_cause_id in draft.root_cause_ids:
        if root_cause_id not in root_cause_ids:
            raise SynthesisSemanticValidationError(f"root_cause_ids references unknown root_cause_id '{root_cause_id}' -- possible hallucination")

    for limitation_id in draft.limitation_ids:
        if limitation_id not in limitation_ids:
            raise SynthesisSemanticValidationError(f"limitation_ids references unknown limitation_id '{limitation_id}'")

    for relation_id in draft.relation_ids:
        if relation_id not in relation_ids:
            raise SynthesisSemanticValidationError(f"relation_ids references unknown relation_id '{relation_id}' -- no CrossModuleRelation exists with this id")

    for recommendation_id in draft.recommendation_ids:
        if recommendation_id not in recommendation_ids:
            raise SynthesisSemanticValidationError(f"recommendation_ids references unknown recommendation_id '{recommendation_id}'")

    for recommendation_id in draft.recommendation_wording:
        if recommendation_id not in recommendation_ids:
            raise SynthesisSemanticValidationError(f"recommendation_wording references unknown recommendation_id '{recommendation_id}'")

    # TaskType-aware depth (item 7): INFORMATION/ANALYSIS never carry a
    # root cause -- defense in depth on top of the structural guarantee
    # above (an INFORMATION/ANALYSIS module's ModuleHandoff.root_causes is
    # already always [] by construction, so root_cause_ids would already
    # be empty from the existence check alone; this makes the TaskType
    # rule explicit and independently checked).
    task_type = context.global_goal.task_type if context.global_goal is not None else None
    if task_type in (TaskType.INFORMATION, TaskType.ANALYSIS) and draft.root_cause_ids:
        raise SynthesisSemanticValidationError(f"root_cause_ids must be empty for task_type={task_type.value}, got {draft.root_cause_ids}")
