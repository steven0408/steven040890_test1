"""build_handoff_package_from_draft (Phase 6B item 14) -- the merge point
between a validated `SynthesisDraft` (LLM wording/ordering/emphasis) and
the deterministic `HandoffPackage` (Code-controlled facts/ids/status/
lineage). The draft never influences anything except `markdown`: every
other field on the returned `HandoffPackage` is byte-for-byte what
`build_handoff_package` would have produced on its own from the same
`SynthesisContext` -- this is what makes "facts never live only in free
LLM text" a structural guarantee rather than a convention.
"""
from agent.llm.context.synthesis_context import SynthesisContext
from agent.llm.prompts.synthesis import SynthesisDraft
from agent.state.models import HandoffPackage
from agent.synthesis.package import build_handoff_package
from agent.synthesis.renderer import render_markdown


def build_handoff_package_from_draft(context: SynthesisContext, draft: SynthesisDraft) -> HandoffPackage:
    package = build_handoff_package(context)
    return package.model_copy(update={"markdown": render_markdown(package, draft)})
