"""Deterministic Markdown renderer (Phase 6A item 10, extended Phase 6B
item 14) -- the last step of `ModuleState -> ModuleHandoff ->
SynthesisContext -> HandoffPackage [-> SynthesisDraft] -> Markdown`.

Renders *only* what is already present on the `HandoffPackage` (facts/ids/
section structure -- Code controls these) it is given, optionally
overlaid with an already-validated `SynthesisDraft`'s wording/ordering/
emphasis (LLM controls these, Phase 6B). It must never invent, infer, or
upgrade a Finding/RootCause/relation that isn't already there (see
tests/test_synthesis_hallucination_regression.py, item 11's explicit
regression: if `HandoffPackage.root_causes` doesn't contain "Motor
Failure", this renderer must never print it) -- the `draft` parameter can
only ever *reorder* or *relabel* items that are already in `package`, it
can never add or remove one: every list this function reads from `package`
stays complete regardless of what `draft` contains.

Empty sections are omitted entirely rather than printed as an empty
heading -- this is what makes the output naturally TaskType-aware without
a TaskType-specific renderer.
"""
from typing import TYPE_CHECKING

from agent.state.models import HandoffPackage, ModuleHandoff

if TYPE_CHECKING:
    from agent.llm.prompts.synthesis import SynthesisDraft


def _reorder_by_ids(items: list, ids: list[str], id_attr: str) -> list:
    """Puts items referenced by `ids` first, in that order, followed by
    every remaining item in its original order -- never drops or adds an
    item, only reorders (the "prioritize presentation" lever, item 1)."""
    by_id = {getattr(item, id_attr): item for item in items}
    referenced = {i for i in ids if i in by_id}
    ordered = [by_id[i] for i in ids if i in by_id]
    ordered += [item for item in items if getattr(item, id_attr) not in referenced]
    return ordered


def _module_section(handoff: ModuleHandoff, module_summary_text: str | None) -> list[str]:
    lines = [f"### {handoff.module_type}", "", f"Status: {handoff.module_status.value}", ""]
    if module_summary_text:
        lines += [module_summary_text, ""]
    lines += [handoff.executive_finding, ""]

    if handoff.confirmed_findings:
        lines.append("**Confirmed findings:**")
        lines += [f"- {f.statement} (confidence={f.confidence:.2f})" for f in handoff.confirmed_findings]
        lines.append("")

    if handoff.root_causes:
        lines.append("**Root causes:**")
        lines += [f"- {rc.statement} (confidence={rc.confidence:.2f})" for rc in handoff.root_causes]
        lines.append("")

    if handoff.limitations:
        lines.append("**Limitations:**")
        lines += [f"- {lim.description}" for lim in handoff.limitations]
        lines.append("")

    if handoff.unresolved_questions:
        lines.append("**Unresolved questions:**")
        lines += [f"- {q}" for q in handoff.unresolved_questions]
        lines.append("")

    return lines


def render_markdown(package: HandoffPackage, draft: "SynthesisDraft | None" = None) -> str:
    lines = ["# Analysis Summary", "", "## Request", "", package.request_summary, ""]

    lines += ["## Executive Summary", ""]
    if draft is not None and draft.audience_summary:
        lines += [f"*{draft.audience_summary}*", ""]
    if draft is not None and draft.executive_summary:
        lines += [draft.executive_summary, ""]
    else:
        lines += [f"Overall status: {package.overall_status.value}", ""]
    for handoff in package.module_results:
        lines.append(f"- **{handoff.module_type}** ({handoff.module_status.value}): {handoff.executive_finding}")
    lines.append("")

    module_summary_by_id = {s.module_id: s.summary_text for s in draft.module_summaries} if draft is not None else {}
    if package.module_results:
        lines.append("## Module Results")
        lines.append("")
        for handoff in package.module_results:
            lines += _module_section(handoff, module_summary_by_id.get(handoff.module_id))

    key_findings = _reorder_by_ids(package.key_findings, draft.key_finding_ids, "finding_id") if draft is not None else package.key_findings
    if key_findings:
        lines.append("## Key Findings")
        lines.append("")
        lines += [f"- {f.statement} (confidence={f.confidence:.2f})" for f in key_findings]
        lines.append("")

    root_causes = _reorder_by_ids(package.root_causes, draft.root_cause_ids, "root_cause_id") if draft is not None else package.root_causes
    if root_causes:
        lines.append("## Root Causes")
        lines.append("")
        lines += [f"- {rc.statement} ({rc.module_id}, confidence={rc.confidence:.2f})" for rc in root_causes]
        lines.append("")

    relations = _reorder_by_ids(package.cross_module_relations, draft.relation_ids, "relation_id") if draft is not None else package.cross_module_relations
    if relations:
        lines.append("## Cross-Module Relationships")
        lines.append("")
        lines += [f"- [{rel.relation_type.value}] {rel.statement} (modules: {', '.join(rel.source_modules)})" for rel in relations]
        lines.append("")

    if package.limitations:
        lines.append("## Limitations / Missing Information")
        lines.append("")
        lines += [f"- {lim.description}" for lim in package.limitations]
        lines.append("")

    if package.unresolved_questions:
        lines.append("## Unresolved Questions")
        lines.append("")
        if draft is not None and draft.unresolved_question_summary:
            lines += [draft.unresolved_question_summary, ""]
        lines += [f"- {q}" for q in package.unresolved_questions]
        lines.append("")

    if package.recommendation_candidates:
        lines.append("## Recommendations")
        lines.append("")
        wording = draft.recommendation_wording if draft is not None else {}
        # lineage/action_type always read from the authoritative
        # RecommendationCandidate -- only the displayed statement text can
        # come from the draft (item 9: reword allowed, lineage/action_type
        # locked)
        lines += [f"- {wording.get(rec.recommendation_id, rec.statement)} ({rec.action_type.value}, confidence={rec.confidence:.2f})" for rec in package.recommendation_candidates]
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"
