"""HandoffPackage assembly (Phase 6A item 6/8) -- deterministic, rule-based
aggregation of every module's ModuleHandoff into the final
`HandoffPackage`. No LLM call; `compute_overall_status` in particular must
never become an LLM decision (see its own docstring).

`cross_module_relations`/`recommendation_candidates` are carried straight
through from `SynthesisContext` (Phase 6B: `SynthesisContextBuilder.build`
accepts them as explicit, externally-supplied input) -- this function
never invents one itself; nothing in this codebase auto-generates either
yet (Phase 6A explicitly deferred both, still true here). The typed
validators on those models (agent/state/models.py) are what actually
enforces "never source-less" / "never unsupported causal claim", not this
function.
"""
from agent.llm.context.synthesis_context import SynthesisContext
from agent.state.enums import ModuleStatus, SynthesisOverallStatus, TaskType
from agent.state.models import ConfidenceSummary, HandoffPackage, ModuleHandoff
from agent.synthesis.renderer import render_markdown

_VALID_OUTCOME_STATUSES = (ModuleStatus.COMPLETE, ModuleStatus.PARTIAL)


def compute_overall_status(module_results: list[ModuleHandoff]) -> SynthesisOverallStatus:
    """Deterministic rollup -- never an LLM decision (Phase 6A item 8's
    explicit instruction). A BLOCKED/FAILED/SKIPPED module does not
    automatically make the whole run BLOCKED/FAILED: it only does if
    *nothing* else produced a valid outcome. This is a first-cut heuristic
    (it does not yet know which modules were strictly *required* to answer
    the global goal vs. merely supplementary) -- see the Phase 6A report's
    explicit note on this simplification.

        - COMPLETE: every selected module reached ModuleStatus.COMPLETE.
        - FAILED:   no selected module reached COMPLETE or PARTIAL (i.e.
                    nothing produced even one confirmed finding).
        - PARTIAL:  everything in between.
    """
    if not module_results:
        return SynthesisOverallStatus.FAILED
    statuses = [m.module_status for m in module_results]
    if all(s == ModuleStatus.COMPLETE for s in statuses):
        return SynthesisOverallStatus.COMPLETE
    if any(s in _VALID_OUTCOME_STATUSES for s in statuses):
        return SynthesisOverallStatus.PARTIAL
    return SynthesisOverallStatus.FAILED


def _confidence_summary(module_results: list[ModuleHandoff]) -> ConfidenceSummary:
    outcome_modules = [m for m in module_results if m.module_status in _VALID_OUTCOME_STATUSES]
    overall_confidence = sum(m.confidence for m in outcome_modules) / len(outcome_modules) if outcome_modules else 0.0
    evidence_coverage = sum(m.evidence_coverage for m in module_results) / len(module_results) if module_results else 0.0
    return ConfidenceSummary(
        overall_confidence=overall_confidence,
        module_confidence={m.module_id: m.confidence for m in module_results},
        evidence_coverage=evidence_coverage,
    )


def build_handoff_package(context: SynthesisContext) -> HandoffPackage:
    module_results = context.module_handoffs
    key_findings = [f for h in module_results for f in h.confirmed_findings]
    root_causes = [rc for h in module_results for rc in h.root_causes]
    limitations = [lim for h in module_results for lim in h.limitations]
    unresolved_questions = [q for h in module_results for q in h.unresolved_questions]
    if context.global_goal is not None:
        task_type = context.global_goal.task_type
    elif module_results:
        task_type = module_results[0].task_type
    else:
        task_type = TaskType.INFORMATION  # defensive fallback -- not expected in practice, Analyzer always sets global_goal first

    package = HandoffPackage(
        run_id=context.run_id,
        request_summary=context.request_summary,
        task_type=task_type,
        overall_status=compute_overall_status(module_results),
        module_results=module_results,
        key_findings=key_findings,
        root_causes=root_causes,
        cross_module_relations=list(context.cross_module_relations),
        limitations=limitations,
        unresolved_questions=unresolved_questions,
        recommendation_candidates=list(context.recommendation_candidates),
        confidence_summary=_confidence_summary(module_results),
        markdown="",
    )
    return package.model_copy(update={"markdown": render_markdown(package)})
