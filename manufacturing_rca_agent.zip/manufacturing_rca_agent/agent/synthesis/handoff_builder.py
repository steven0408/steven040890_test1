"""ModuleHandoffBuilder (Phase 6A) -- Harness service, not a LangGraph node,
projecting `ModuleState -> ModuleHandoff`. Synthesis never reads a
ModuleState directly; this is the only door in.

Deliberately excludes: full `objective_history` (ObjectiveRecord audit
trail), raw `Observation`/`ToolCallRecord` entries, `Evidence.
structured_payload` (only `EvidenceSummary` text/quality survives),
`LLMCallRecord`/`ContextBuildRecord`/`PlannerDecisionRecord` (LLM Runtime
audit, a different sink entirely), and Human audit internals (that's
HumanAuditSink's job, not Synthesis's). `ModuleHandoff` is an analysis
*result* projection, not a runtime dump -- same discipline
`PlannerContext` established for "what should an LLM see" in Phase 5C-1,
applied here to "what should a human/downstream consumer see".

No LLM call anywhere in this module -- every field is derived by a plain,
deterministic rule from ModuleState, branching only on `ModuleStatus`.
"""
from agent.state.enums import (
    EntityAnalysisStatus,
    FindingStatus,
    HypothesisStatus,
    ModuleStatus,
    TaskType,
)
from agent.state.models import (
    BranchHandoffSummary,
    EvidenceSummary,
    Limitation,
    ModuleHandoff,
    ModuleState,
    RootCause,
)


def _confirmed_findings(module_state: ModuleState) -> list:
    return [f for f in module_state.findings if f.status == FindingStatus.CONFIRMED]


def _root_causes(module_state: ModuleState) -> list[RootCause]:
    """Only ever built from findings that are BOTH `status=CONFIRMED` AND
    `is_root_cause=True` -- the single hallucination guard every other
    root-cause-bearing field (ModuleHandoff.root_causes,
    HandoffPackage.root_causes, the Markdown renderer's Root Causes
    section) transitively relies on. A HYPOTHESIS-status finding, even one
    with `is_root_cause=True` set prematurely, never becomes a RootCause
    here (see test_synthesis_hallucination_regression.py)."""
    return [
        RootCause(
            root_cause_id=f"{module_state.module_id}-rc-{f.finding_id}",
            statement=f.statement,
            module_id=module_state.module_id,
            entity_ids=list(f.entity_ids),
            confidence=f.confidence,
            supporting_finding_ids=list(f.supporting_evidence_ids) or [f.finding_id],
        )
        for f in module_state.findings
        if f.status == FindingStatus.CONFIRMED and f.is_root_cause
    ]


def _open_hypotheses(module_state: ModuleState) -> list:
    return [h for h in module_state.hypotheses if h.status == HypothesisStatus.OPEN]


def _key_entities(module_state: ModuleState) -> list[str]:
    entities_with_findings = sorted(e.entity_id for e in module_state.entity_states.values() if e.finding_ids)
    if entities_with_findings:
        return entities_with_findings
    # No entity has a finding attached yet (e.g. ANALYSIS/screening-only
    # runs never populate entity_states.finding_ids) -- fall back to
    # whichever entities are furthest along, still deterministic (sorted).
    investigating = sorted(
        e.entity_id for e in module_state.entity_states.values()
        if e.status in (EntityAnalysisStatus.INVESTIGATING, EntityAnalysisStatus.ROOT_CAUSE_FOUND)
    )
    return investigating


def _branch_summaries(module_state: ModuleState) -> list[BranchHandoffSummary]:
    return [
        BranchHandoffSummary(
            branch_id=b.branch_id, name=b.name, pattern=b.pattern, status=b.status,
            priority_score=b.priority_score, entity_ids=list(b.entity_ids),
        )
        for b in sorted(module_state.branches.values(), key=lambda b: b.priority_score, reverse=True)
    ]


def _evidence_summaries(module_state: ModuleState) -> list[EvidenceSummary]:
    return [
        EvidenceSummary(module_id=module_state.module_id, summary=e.summary, evidence_ids=[e.evidence_id], quality=e.quality)
        for e in module_state.evidence
    ]


def _evidence_coverage(module_state: ModuleState) -> float:
    """A coarse, deterministic heuristic -- fraction of dispatched
    objectives that actually produced evidence -- not a scientific
    measure. 0.0 when nothing was ever dispatched."""
    if not module_state.objective_history:
        return 0.0
    return min(1.0, len(module_state.evidence) / len(module_state.objective_history))


def _confidence(module_state: ModuleState, confirmed_findings: list, open_hypotheses: list) -> float:
    if confirmed_findings:
        return sum(f.confidence for f in confirmed_findings) / len(confirmed_findings)
    if open_hypotheses:
        # unconfirmed -- discounted, never presented at face value
        return (sum(h.confidence for h in open_hypotheses) / len(open_hypotheses)) * 0.5
    return 0.0


def _unresolved_questions(module_state: ModuleState, task_type: TaskType, root_causes: list[RootCause], open_hypotheses: list) -> list[str]:
    questions = [f"Open hypothesis for {module_state.module_type}: {h.statement}" for h in open_hypotheses]
    if task_type == TaskType.RCA and not root_causes and module_state.status != ModuleStatus.SKIPPED:
        questions.append(f"Root cause not yet confirmed for {module_state.module_type}.")
    return questions


def _authorization_limitation(module_state: ModuleState) -> Limitation | None:
    """Derived from `RejectionRecord`, never from `Limitation` -- keeps an
    authorization/permission gap (Human REJECTed, no alternative) visibly
    distinct from a plain data gap (DATA_NOT_FOUND after exhausting
    sources): this synthetic Limitation always has `related_error=None`
    and an explicit "Authorization" prefix, whereas every data-gap
    Limitation on ModuleState carries a real `related_error`."""
    if not module_state.rejections:
        return None
    last = module_state.rejections[-1]
    if last.alternative_found:
        return None
    return Limitation(
        limitation_id=f"{module_state.module_id}-auth-gap",
        description=f"Authorization required: {last.permission_type or 'unspecified permission'} ({last.reason})",
        impacted_objective_id=last.objective_id,
        impact_statement="Analysis blocked pending human authorization -- not a data availability gap.",
        related_error=None,
    )


def _executive_finding(module_state: ModuleState, task_type: TaskType, root_causes: list[RootCause], confirmed_findings: list) -> str:
    status = module_state.status
    if status == ModuleStatus.COMPLETE:
        if root_causes:
            return root_causes[0].statement
        if confirmed_findings:
            return confirmed_findings[0].statement
        return f"{module_state.module_type} analysis complete."
    if status == ModuleStatus.PARTIAL:
        if root_causes:
            return f"Partial: {root_causes[0].statement} (coverage incomplete)."
        if confirmed_findings:
            return f"Partial: {confirmed_findings[0].statement} -- root cause not fully confirmed." if task_type == TaskType.RCA else f"Partial: {confirmed_findings[0].statement}"
        return f"Partial analysis for {module_state.module_type} -- insufficient evidence for a confirmed finding."
    if status == ModuleStatus.FAILED:
        return f"No reliable finding produced for {module_state.module_type}."
    if status == ModuleStatus.BLOCKED:
        auth = _authorization_limitation(module_state)
        return auth.description if auth is not None else f"{module_state.module_type} analysis blocked."
    if status == ModuleStatus.SKIPPED:
        return f"{module_state.module_type} was not executed this run."
    return f"{module_state.module_type} analysis is still in progress."  # PENDING/RUNNING -- defensive, not expected at Synthesis time


class ModuleHandoffBuilder:
    def build(self, module_state: ModuleState) -> ModuleHandoff:
        task_type = module_state.goal.task_type
        status = module_state.status

        # FAILED/SKIPPED never carry findings/root-causes/entities forward,
        # even if some were somehow present -- an unreliable/unexecuted
        # module reports nothing rather than a partial truth presented at
        # face value.
        if status in (ModuleStatus.FAILED, ModuleStatus.SKIPPED):
            confirmed_findings: list = []
            root_causes: list[RootCause] = []
            open_hypotheses: list = []
            key_entities: list[str] = []
            branch_summary: list[BranchHandoffSummary] = []
            evidence_summary: list[EvidenceSummary] = []
            limitations: list[Limitation] = list(module_state.limitations) if status == ModuleStatus.FAILED else []
        else:
            confirmed_findings = _confirmed_findings(module_state)
            root_causes = _root_causes(module_state)
            open_hypotheses = _open_hypotheses(module_state)
            key_entities = _key_entities(module_state)
            branch_summary = _branch_summaries(module_state)
            evidence_summary = _evidence_summaries(module_state)
            limitations = list(module_state.limitations)
            if status == ModuleStatus.BLOCKED:
                auth_limitation = _authorization_limitation(module_state)
                if auth_limitation is not None:
                    limitations = [auth_limitation, *limitations]

        unresolved_questions = _unresolved_questions(module_state, task_type, root_causes, open_hypotheses)
        confidence = _confidence(module_state, confirmed_findings, open_hypotheses) if status not in (ModuleStatus.FAILED, ModuleStatus.SKIPPED) else 0.0
        evidence_coverage = _evidence_coverage(module_state) if status != ModuleStatus.SKIPPED else 0.0

        return ModuleHandoff(
            module_id=module_state.module_id,
            module_type=module_state.module_type,
            task_type=task_type,
            module_status=status,
            module_goal=module_state.goal.statement,
            executive_finding=_executive_finding(module_state, task_type, root_causes, confirmed_findings),
            confirmed_findings=confirmed_findings,
            hypotheses=open_hypotheses,
            root_causes=root_causes,
            key_entities=key_entities,
            branch_summary=branch_summary,
            evidence_summary=evidence_summary,
            limitations=limitations,
            unresolved_questions=unresolved_questions,
            confidence=confidence,
            evidence_coverage=evidence_coverage,
        )
