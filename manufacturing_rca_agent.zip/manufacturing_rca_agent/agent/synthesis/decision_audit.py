"""SynthesisGenerationRecord / SynthesisGenerationAuditSink (Phase 6B item
10) -- same "Protocol + InMemory reference impl" pattern as
PlannerDecisionRecord (agent/planning/decision_audit.py). Correlation
(item 11): `context_build_record_id` -> SynthesisContextBuildRecord,
`llm_call_id` -> LLMCallRecord -- both `None` when `source=FALLBACK` and no
LLM call ever succeeded. Never chain-of-thought, only the referenced ids.
"""
from datetime import datetime
from enum import Enum
from typing import Protocol

from agent.state.base import RCABaseModel


class SynthesisSource(str, Enum):
    LLM = "llm"
    FALLBACK = "fallback"


class SynthesisGenerationRecord(RCABaseModel):
    synthesis_record_id: str
    run_id: str
    source: SynthesisSource
    context_build_record_id: str | None = None
    llm_call_id: str | None = None
    included_module_ids: list[str]
    referenced_finding_ids: list[str]
    referenced_root_cause_ids: list[str]
    referenced_relation_ids: list[str]
    referenced_recommendation_ids: list[str]
    fallback_reason: str | None = None
    created_at: datetime


class SynthesisGenerationAuditSink(Protocol):
    def record(self, record: SynthesisGenerationRecord) -> None: ...

    def list_for_run(self, run_id: str) -> list[SynthesisGenerationRecord]: ...


class InMemorySynthesisGenerationAuditSink:
    def __init__(self) -> None:
        self._records: list[SynthesisGenerationRecord] = []

    def record(self, record: SynthesisGenerationRecord) -> None:
        self._records.append(record)

    def list_for_run(self, run_id: str) -> list[SynthesisGenerationRecord]:
        return [r for r in self._records if r.run_id == run_id]
