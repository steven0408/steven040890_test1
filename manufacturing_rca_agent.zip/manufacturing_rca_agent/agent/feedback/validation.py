"""validate_human_feedback (Phase 7B item 3) -- lineage validation beyond
`HumanFeedback`'s own structural `target_id`-presence check (see its
`model_validator` in agent/state/models.py). This is a plain, typed
`ValueError` subclass, not `LLMInvalidOutputError`: there is no LLM/Router
involved in submitting human feedback, so there is nothing to retry --
a fake target_id is simply rejected outright, never silently saved.
"""
from agent.state.enums import FeedbackTargetType
from agent.state.models import HandoffPackage, HumanFeedback


class FeedbackLineageError(ValueError):
    pass


def validate_human_feedback(feedback: HumanFeedback, *, handoff_package: HandoffPackage) -> None:
    if feedback.target_type == FeedbackTargetType.MODULE:
        module_ids = {m.module_id for m in handoff_package.module_results}
        if feedback.target_id not in module_ids:
            raise FeedbackLineageError(f"feedback references unknown module_id '{feedback.target_id}'")

    elif feedback.target_type == FeedbackTargetType.FINDING:
        finding_ids = {f.finding_id for f in handoff_package.key_findings}
        finding_ids |= {f.finding_id for m in handoff_package.module_results for f in m.confirmed_findings}
        if feedback.target_id not in finding_ids:
            raise FeedbackLineageError(f"feedback references unknown finding_id '{feedback.target_id}'")

    elif feedback.target_type == FeedbackTargetType.ROOT_CAUSE:
        root_cause_ids = {rc.root_cause_id for rc in handoff_package.root_causes}
        if feedback.target_id not in root_cause_ids:
            raise FeedbackLineageError(f"feedback references unknown root_cause_id '{feedback.target_id}'")

    elif feedback.target_type == FeedbackTargetType.RECOMMENDATION:
        recommendation_ids = {r.recommendation_id for r in handoff_package.recommendation_candidates}
        if feedback.target_id not in recommendation_ids:
            raise FeedbackLineageError(f"feedback references unknown recommendation_id '{feedback.target_id}'")

    elif feedback.target_type == FeedbackTargetType.SYNTHESIS:
        if feedback.target_id is not None and feedback.target_id != handoff_package.run_id:
            raise FeedbackLineageError(f"feedback references a synthesis result for a different run ('{feedback.target_id}')")

    # RUN: nothing further to check -- feedback.run_id itself is the
    # target, and the caller is responsible for only ever validating
    # feedback against the HandoffPackage of the run it names.
