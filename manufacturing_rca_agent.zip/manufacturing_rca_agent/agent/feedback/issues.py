"""classify_feedback_issues (Phase 7B item 6/9) -- deterministic
classification straight from HumanFeedback's own structured fields, never
from parsing `comment` (comment stays human-readable evidence attached to
an issue, never interpreted -- no LLM here). Severity follows item 9's
explicit criticality rules.
"""
import itertools
from enum import Enum

from agent.state.base import RCABaseModel
from agent.state.enums import EvaluationSeverity, FeedbackTargetType, HumanFeedbackThumbs
from agent.state.models import HumanFeedback

_issue_id_counter = itertools.count(1)


class FeedbackIssueCategory(str, Enum):
    INCORRECT_FINDING = "incorrect_finding"
    INCORRECT_ROOT_CAUSE = "incorrect_root_cause"
    UNHELPFUL_RECOMMENDATION = "unhelpful_recommendation"
    ANSWER_NOT_HELPFUL = "answer_not_helpful"
    UNCLEAR_OUTPUT = "unclear_output"
    OTHER = "other"


class FeedbackIssue(RCABaseModel):
    issue_id: str
    feedback_id: str
    target_type: FeedbackTargetType
    target_id: str | None
    category: FeedbackIssueCategory
    severity: EvaluationSeverity
    statement: str
    comment: str | None = None


def _next_issue_id() -> str:
    return f"feedback-issue-{next(_issue_id_counter)}"


def classify_feedback_issues(feedback_list: list[HumanFeedback]) -> list[FeedbackIssue]:
    issues: list[FeedbackIssue] = []

    for f in feedback_list:
        explicit_negative_fields = 0

        if f.root_cause_correct is False:
            explicit_negative_fields += 1
            issues.append(
                FeedbackIssue(
                    issue_id=_next_issue_id(), feedback_id=f.feedback_id, target_type=f.target_type, target_id=f.target_id,
                    category=FeedbackIssueCategory.INCORRECT_ROOT_CAUSE, severity=EvaluationSeverity.HIGH,
                    statement="A human reviewer marked a root cause as incorrect.", comment=f.comment,
                )
            )

        if f.finding_correct is False:
            explicit_negative_fields += 1
            issues.append(
                FeedbackIssue(
                    issue_id=_next_issue_id(), feedback_id=f.feedback_id, target_type=f.target_type, target_id=f.target_id,
                    category=FeedbackIssueCategory.INCORRECT_FINDING, severity=EvaluationSeverity.MEDIUM,
                    statement="A human reviewer marked a finding as incorrect.", comment=f.comment,
                )
            )

        if f.recommendation_useful is False:
            explicit_negative_fields += 1
            issues.append(
                FeedbackIssue(
                    issue_id=_next_issue_id(), feedback_id=f.feedback_id, target_type=f.target_type, target_id=f.target_id,
                    category=FeedbackIssueCategory.UNHELPFUL_RECOMMENDATION, severity=EvaluationSeverity.MEDIUM,
                    statement="A human reviewer marked a recommendation as unhelpful.", comment=f.comment,
                )
            )

        if f.answer_helpful is False:
            explicit_negative_fields += 1
            issues.append(
                FeedbackIssue(
                    issue_id=_next_issue_id(), feedback_id=f.feedback_id, target_type=f.target_type, target_id=f.target_id,
                    category=FeedbackIssueCategory.ANSWER_NOT_HELPFUL, severity=EvaluationSeverity.MEDIUM,
                    statement="A human reviewer marked the answer as not helpful.", comment=f.comment,
                )
            )

        if f.thumbs == HumanFeedbackThumbs.DOWN and explicit_negative_fields == 0:
            issues.append(
                FeedbackIssue(
                    issue_id=_next_issue_id(), feedback_id=f.feedback_id, target_type=f.target_type, target_id=f.target_id,
                    category=FeedbackIssueCategory.OTHER, severity=EvaluationSeverity.LOW,
                    statement="Thumbs-down feedback with no specific structured signal set.", comment=f.comment,
                )
            )

    return issues
