"""RunAssessment (Phase 7B item 7/8/11) -- a read-only VIEW combining
`RunEvaluation` (Phase 7A, deterministic/metric-based) and
`HumanFeedbackSummary` (Phase 7B) side by side. Building one never mutates
either input -- `RunEvaluation` stays immutable, `HumanFeedback` stays
append-only. Phase 7B deliberately does not decide "who is right" when
they disagree (item 8's explicit instruction) -- `EvaluationHumanAgreement`
only *labels* the relationship; a future Learning phase decides what, if
anything, to do about it.
"""
from enum import Enum

from agent.feedback.aggregator import HumanFeedbackSummary
from agent.feedback.issues import FeedbackIssue
from agent.state.base import RCABaseModel
from agent.state.models import RunEvaluation

_HIGH_THRESHOLD = 0.7
_LOW_THRESHOLD = 0.4


class AgreementDimension(str, Enum):
    OVERALL = "overall"
    ROOT_CAUSE = "root_cause"


class EvaluationHumanAgreement(str, Enum):
    AGREE_POSITIVE = "agree_positive"
    AGREE_NEGATIVE = "agree_negative"
    DISAGREE_EVALUATOR_HIGH_HUMAN_LOW = "disagree_evaluator_high_human_low"
    DISAGREE_EVALUATOR_LOW_HUMAN_HIGH = "disagree_evaluator_low_human_high"
    INSUFFICIENT_FEEDBACK = "insufficient_feedback"


class AgreementSignal(RCABaseModel):
    dimension: AgreementDimension
    evaluator_score: float | None
    human_positive_rate: float | None
    agreement: EvaluationHumanAgreement


class RunAssessment(RCABaseModel):
    run_id: str
    run_evaluation: RunEvaluation
    human_feedback_summary: HumanFeedbackSummary
    feedback_issues: list[FeedbackIssue]
    agreement_signals: list[AgreementSignal]


def _classify(evaluator_score: float | None, human_rate: float | None) -> EvaluationHumanAgreement:
    if evaluator_score is None or human_rate is None:
        return EvaluationHumanAgreement.INSUFFICIENT_FEEDBACK
    evaluator_high = evaluator_score >= _HIGH_THRESHOLD
    evaluator_low = evaluator_score < _LOW_THRESHOLD
    human_high = human_rate >= 0.5
    if evaluator_high and human_high:
        return EvaluationHumanAgreement.AGREE_POSITIVE
    if evaluator_low and not human_high:
        return EvaluationHumanAgreement.AGREE_NEGATIVE
    if evaluator_high and not human_high:
        return EvaluationHumanAgreement.DISAGREE_EVALUATOR_HIGH_HUMAN_LOW
    if not evaluator_high and human_high:
        return EvaluationHumanAgreement.DISAGREE_EVALUATOR_LOW_HUMAN_HIGH
    # evaluator score sits in the middle band (neither clearly high nor
    # clearly low) -- not a disagreement worth flagging either way
    return EvaluationHumanAgreement.AGREE_POSITIVE if human_high else EvaluationHumanAgreement.AGREE_NEGATIVE


def _overall_human_rate(summary: HumanFeedbackSummary) -> float | None:
    total_thumbs = summary.thumbs_up_count + summary.thumbs_down_count
    if total_thumbs > 0:
        return summary.thumbs_up_count / total_thumbs
    return summary.helpful_rate


def build_agreement_signals(evaluation: RunEvaluation, summary: HumanFeedbackSummary) -> list[AgreementSignal]:
    from agent.evaluation.scoring import analytical_summary_score, delivery_summary_score

    overall_evaluator_score = (analytical_summary_score(evaluation.analytical_quality) + delivery_summary_score(evaluation.delivery_quality)) / 2
    overall_human_rate = _overall_human_rate(summary)

    root_cause_evaluator_score = evaluation.analytical_quality.root_cause_support_score
    root_cause_human_rate = summary.root_cause_correct_rate

    return [
        AgreementSignal(
            dimension=AgreementDimension.OVERALL, evaluator_score=overall_evaluator_score, human_positive_rate=overall_human_rate,
            agreement=_classify(overall_evaluator_score, overall_human_rate),
        ),
        AgreementSignal(
            dimension=AgreementDimension.ROOT_CAUSE, evaluator_score=root_cause_evaluator_score, human_positive_rate=root_cause_human_rate,
            agreement=_classify(root_cause_evaluator_score, root_cause_human_rate),
        ),
    ]


def build_run_assessment(
    evaluation: RunEvaluation, feedback_summary: HumanFeedbackSummary, feedback_issues: list[FeedbackIssue]
) -> RunAssessment:
    return RunAssessment(
        run_id=evaluation.run_id,
        run_evaluation=evaluation,
        human_feedback_summary=feedback_summary,
        feedback_issues=feedback_issues,
        agreement_signals=build_agreement_signals(evaluation, feedback_summary),
    )
