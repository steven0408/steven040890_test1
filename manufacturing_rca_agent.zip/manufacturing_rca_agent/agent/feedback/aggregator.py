"""HumanFeedbackAggregator (Phase 7B item 5) -- deterministic, purely
arithmetic aggregation over `list[HumanFeedback]`. No LLM, no comment
parsing (comment stays human-readable evidence only, never interpreted).

Rate denominators (item 5's explicit rule): each `*_rate` divides only by
feedback that actually *set* that field -- `None` is "not answered", never
coerced to `False`. A run with 3 feedback records where only 1 answered
`root_cause_correct` has a rate denominator of 1, not 3.
"""
from collections import defaultdict

from agent.state.base import RCABaseModel
from agent.state.enums import FeedbackTargetType, HumanFeedbackThumbs
from agent.state.models import HumanFeedback


class TargetBreakdownEntry(RCABaseModel):
    target_type: FeedbackTargetType
    target_id: str | None
    feedback_count: int
    thumbs_up_count: int
    thumbs_down_count: int


class HumanFeedbackSummary(RCABaseModel):
    run_id: str
    total_feedback_count: int
    thumbs_up_count: int
    thumbs_down_count: int
    helpful_rate: float | None = None
    root_cause_correct_rate: float | None = None
    finding_correct_rate: float | None = None
    recommendation_useful_rate: float | None = None
    target_breakdown: list[TargetBreakdownEntry]
    unresolved_negative_feedback_count: int


def _rate(values: list[bool]) -> float | None:
    if not values:
        return None
    return sum(1 for v in values if v) / len(values)


def _is_negative(feedback: HumanFeedback) -> bool:
    if feedback.thumbs == HumanFeedbackThumbs.DOWN:
        return True
    return any(v is False for v in [feedback.answer_helpful, feedback.root_cause_correct, feedback.finding_correct, feedback.recommendation_useful])


class HumanFeedbackAggregator:
    def summarize(self, run_id: str, feedback_list: list[HumanFeedback]) -> HumanFeedbackSummary:
        run_feedback = [f for f in feedback_list if f.run_id == run_id]

        by_target: dict[tuple[FeedbackTargetType, str | None], list[HumanFeedback]] = defaultdict(list)
        for f in run_feedback:
            by_target[(f.target_type, f.target_id)].append(f)

        target_breakdown = [
            TargetBreakdownEntry(
                target_type=target_type, target_id=target_id, feedback_count=len(items),
                thumbs_up_count=sum(1 for f in items if f.thumbs == HumanFeedbackThumbs.UP),
                thumbs_down_count=sum(1 for f in items if f.thumbs == HumanFeedbackThumbs.DOWN),
            )
            for (target_type, target_id), items in by_target.items()
        ]

        # "unresolved" = the MOST RECENT feedback for that target is
        # negative -- append-only history means an earlier negative
        # followed by a later positive is no longer unresolved, but a
        # negative that nothing followed still is.
        unresolved_negative_feedback_count = 0
        for items in by_target.values():
            latest = max(items, key=lambda f: f.created_at)
            if _is_negative(latest):
                unresolved_negative_feedback_count += 1

        return HumanFeedbackSummary(
            run_id=run_id,
            total_feedback_count=len(run_feedback),
            thumbs_up_count=sum(1 for f in run_feedback if f.thumbs == HumanFeedbackThumbs.UP),
            thumbs_down_count=sum(1 for f in run_feedback if f.thumbs == HumanFeedbackThumbs.DOWN),
            helpful_rate=_rate([f.answer_helpful for f in run_feedback if f.answer_helpful is not None]),
            root_cause_correct_rate=_rate([f.root_cause_correct for f in run_feedback if f.root_cause_correct is not None]),
            finding_correct_rate=_rate([f.finding_correct for f in run_feedback if f.finding_correct is not None]),
            recommendation_useful_rate=_rate([f.recommendation_useful for f in run_feedback if f.recommendation_useful is not None]),
            target_breakdown=target_breakdown,
            unresolved_negative_feedback_count=unresolved_negative_feedback_count,
        )
