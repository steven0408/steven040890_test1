"""LLM Runtime contracts (Phase 5B-3A) -- provider-agnostic. Nothing here
imports a provider SDK; that only happens inside a concrete `LLMClient`
implementation (agent/llm/client.py's `MockLLMClient` this phase -- a real
provider adapter is Phase 5B-3B).
"""
from datetime import datetime
from enum import Enum

from pydantic import Field

from agent.state.base import RCABaseModel


class LLMRole(str, Enum):
    SYSTEM = "system"
    USER = "user"


class LLMMessage(RCABaseModel):
    role: LLMRole
    content: str


class LLMCallStatus(str, Enum):
    SUCCESS = "success"
    TIMEOUT = "timeout"
    PROVIDER_ERROR = "provider_error"
    INVALID_OUTPUT = "invalid_output"
    # Phase PROD-1.1: two new, explicitly distinguishable failure modes
    # (item 97 -- "do not collapse them into 'LLM failed'"). Both are
    # detected BEFORE/independent of the client's own generic invalid-
    # output classification, so they get their own LLMCallStatus rather
    # than sharing INVALID_OUTPUT.
    CONTEXT_BUDGET_EXCEEDED = "context_budget_exceeded"  # preflight rejection -- no network call was made
    OUTPUT_TRUNCATED = "output_truncated"  # finish_reason=length with no usable content -- item 55


class DecisionSource(str, Enum):
    """Shared across every LLM-backed decision-maker (Analyzer, Planner, ...)
    -- not analyzer-specific despite first appearing there in Phase 5B-3A.
    Moved here in Phase 5C-2 when Planner needed the exact same concept,
    rather than each decision-maker defining its own parallel copy."""

    LLM = "llm"
    FALLBACK = "fallback"


class LLMRequest(RCABaseModel):
    route: str
    model: str
    messages: list[LLMMessage]
    output_schema_name: str
    timeout_seconds: float = 30.0
    run_id: str
    module_id: str | None = None
    node: str


class LLMCallRecord(RCABaseModel):
    """Per-attempt audit entry -- one row per physical LLM call, retries
    included (mirrors ToolCallRecord's attempt-level granularity). This is
    the future-Postgres-backed durable source of truth for token/cost
    accounting; never compute those from final AgentState alone.

    Phase PROD-1.2 (item B): the full bounded telemetry set a formal-
    environment calibration run needs (estimator-vs-actual comparison,
    schema cost, provider finish_reason, reasoning-model presence signals)
    without ever carrying a full prompt/schema body or the actual
    `reasoning_content` text. Every new field is optional/defaulted so
    every pre-existing `LLMCallRecord(...)` construction (offline tests,
    the router's own pre-PROD-1.2 call sites) is unaffected."""

    llm_call_id: str
    run_id: str
    module_id: str | None = None
    node: str
    route: str
    model: str
    input_tokens: int
    output_tokens: int
    latency_ms: float
    status: LLMCallStatus
    retry_count: int = 0
    estimated_cost: float | None = None
    error_message: str | None = None
    started_at: datetime
    completed_at: datetime

    # Phase PROD-1.2 additions -- all bounded scalars, never raw content.
    context_window_tokens: int | None = None  # the configured profile's own window, when a context_profile was supplied
    reserved_output_tokens: int | None = None  # this route's own max_output_tokens reservation
    estimated_prompt_tokens: int | None = None  # ApproximateTokenEstimator's own pre-flight estimate (messages only, no schema)
    schema_tokens: int | None = None  # ApproximateTokenEstimator's own estimate of the compact output schema
    finish_reason: str | None = None  # verbatim provider finish_reason string (e.g. "stop"/"length") -- never prompt/response content
    content_present: bool | None = None  # did the provider return usable message/tool_call content?
    reasoning_present: bool | None = None  # did the provider's response carry a reasoning_content field at all? (never its text)


class LLMTimeoutError(RuntimeError):
    pass


class LLMProviderError(RuntimeError):
    pass


class LLMInvalidOutputError(RuntimeError):
    pass


class LLMOutputTruncatedError(LLMInvalidOutputError):
    """Phase PROD-1.1 (item 55): a SUBCLASS of LLMInvalidOutputError (not a
    sibling) so LLMRouter's existing isinstance-based failure handling
    keeps working unchanged (retried the same way any invalid-output
    failure is) -- but `_status_for()` checks for this specific subclass
    FIRST, so it is recorded/audited as its own distinguishable
    `LLMCallStatus.OUTPUT_TRUNCATED` rather than the generic
    `INVALID_OUTPUT`, letting production observability tell "the model
    ran out of generation budget (often to `reasoning_content`, item 10)"
    apart from "the model produced malformed/non-conforming JSON".

    Phase PROD-1.2: carries the verbatim provider `finish_reason` string
    (always `"length"` today, since that's the only trigger -- see
    openai_adapter.py's own `_raise_for_missing_content`) so LLMRouter can
    thread it onto the resulting `LLMCallRecord.finish_reason` without
    re-parsing the exception message."""

    def __init__(self, message: str, *, finish_reason: str | None = "length"):
        super().__init__(message)
        self.finish_reason = finish_reason
