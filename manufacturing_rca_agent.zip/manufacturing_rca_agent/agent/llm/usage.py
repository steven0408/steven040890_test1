"""LLMUsageSink (Phase 5B-3A) -- same "Protocol + InMemory reference impl"
pattern as HumanAuditSink (agent/persistence/human_audit.py) and
ToolCallAuditSink (agent/tools/execution_manager.py): a durable-store-shaped
seam, not AgentState. A future PostgreSQL-backed implementation becomes the
source of truth for token/cost accounting behind this same interface; never
compute those from final AgentState alone -- LLMRouter records one
LLMCallRecord per physical attempt here, retries included, and AgentState
never sees any of it.
"""
from typing import Protocol

from agent.llm.models import LLMCallRecord


class LLMUsageSink(Protocol):
    def record(self, record: LLMCallRecord) -> None: ...

    def list_for_run(self, run_id: str) -> list[LLMCallRecord]: ...


class InMemoryLLMUsageSink:
    def __init__(self) -> None:
        self._records: list[LLMCallRecord] = []

    def record(self, record: LLMCallRecord) -> None:
        self._records.append(record)

    def list_for_run(self, run_id: str) -> list[LLMCallRecord]:
        return [r for r in self._records if r.run_id == run_id]
