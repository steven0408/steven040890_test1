from pydantic import Field

from agent.state.base import RCABaseModel


class LLMRouteConfig(RCABaseModel):
    """Static, graph-construction-time configuration for one named route
    (e.g. "analyzer") -- which model, how long to wait, how many attempts.

    `fallback_models` is a contract-only field this phase: LLMRouter does
    not yet retry against a different model after `model` keeps failing --
    it only retries the *same* model up to `max_retries` times. Wiring
    `fallback_models` into actual retry behavior is future work; the field
    exists now so route configuration doesn't need a breaking schema change
    later.
    """

    route: str
    model: str
    timeout_seconds: float = 30.0
    max_retries: int = 1
    fallback_models: list[str] = Field(default_factory=list)
