"""Phase PROD-1.1 (item 42/43): compact provider-facing JSON Schema
rendering. Pydantic's `model_json_schema()` includes `title` (auto-derived
from the class name) and `description` (the class's own docstring --
several of which, across this codebase's cognitive-output models, are
several sentences of design-rationale prose, e.g. PlannerDecision's own
~400-word docstring) on every model AND every nested `$defs` entry. None of
that is needed by the LLM to produce a conforming JSON object -- only
`type`/`properties`/`required`/`enum`/`$ref`/`items`/structural keys are.

This function NEVER touches the actual Pydantic model class (item 43's own
explicit "do not change runtime/domain Pydantic models merely to save
tokens" instruction) -- it only transforms the schema DICT on its way into
a provider request. The real model (`output_model.model_validate(...)`)
still validates the response exactly as before; compacting what the LLM
SEES has zero effect on response validation correctness.
"""
from typing import Any

_STRIPPED_KEYS = {"title", "description"}


def compact_json_schema(schema_or_model: Any) -> dict:
    """Accepts either an already-built schema dict or a Pydantic model
    class (calls `.model_json_schema()` for the caller's convenience)."""
    schema = schema_or_model.model_json_schema() if hasattr(schema_or_model, "model_json_schema") else schema_or_model
    return _strip(schema)


def _strip(node: Any) -> Any:
    if isinstance(node, dict):
        return {key: _strip(value) for key, value in node.items() if key not in _STRIPPED_KEYS}
    if isinstance(node, list):
        return [_strip(item) for item in node]
    return node
