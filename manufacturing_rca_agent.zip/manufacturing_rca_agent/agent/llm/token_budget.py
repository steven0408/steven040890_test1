"""Phase PROD-1.1: generic Context Budget primitives. Provider/model-
agnostic, domain-agnostic (never imports WB/OEE) -- this is the layer that
makes "FULL STATE != LLM CONTEXT" configuration-driven rather than a
per-node hardcoded assumption. `LLMContextProfile` describes ONE provider's
actual constraints (context window, per-route output reservation); every
cognitive route reads its own `RouteTokenBudget` from it.

Nothing here decides WHAT to include (that stays each domain-aware Context
Builder's job, agent/llm/context/*.py) -- this module only answers "how
much fits" and "did we blow the budget."
"""
import math
from typing import Protocol

from agent.state.base import RCABaseModel


class LLMContextBudgetExceededError(RuntimeError):
    """Raised BEFORE any network call when the estimated request (input +
    schema + reserved output + safety margin) cannot fit inside the
    configured context window -- never a random provider 500/length
    failure. A subclass of RuntimeError (not LLMInvalidOutputError -- see
    agent/llm/models.py's own docstring): this is a deterministic,
    pre-flight configuration/sizing problem, never something a network
    retry could fix (item 56's own "context overflow: NO network retry")."""

    def __init__(self, route: str, *, estimated_input_tokens: int, reserved_output_tokens: int, safety_margin_tokens: int, context_window_tokens: int):
        self.route = route
        self.estimated_input_tokens = estimated_input_tokens
        self.reserved_output_tokens = reserved_output_tokens
        self.safety_margin_tokens = safety_margin_tokens
        self.context_window_tokens = context_window_tokens
        total = estimated_input_tokens + reserved_output_tokens + safety_margin_tokens
        super().__init__(
            f"route '{route}' cannot fit context_window={context_window_tokens}: "
            f"estimated_input={estimated_input_tokens} + reserved_output={reserved_output_tokens} + "
            f"safety_margin={safety_margin_tokens} = {total} > {context_window_tokens}"
        )


class RouteTokenBudget(RCABaseModel):
    """Per-route output/margin reservation -- distinct routes have very
    different generation needs (e.g. Planner's next_objective vs.
    Synthesis's executive_summary), and a reasoning model (item 10) may
    consume part of `max_output_tokens` on `reasoning_content` before any
    final structured content appears, so `minimum_output_tokens` is a
    separate, smaller floor used only for the preflight "can this even
    possibly succeed" check -- `max_output_tokens` is what is actually
    requested from the provider."""

    max_output_tokens: int
    minimum_output_tokens: int
    safety_margin_tokens: int = 64

    def model_post_init(self, __context) -> None:
        if self.minimum_output_tokens > self.max_output_tokens:
            raise ValueError(f"minimum_output_tokens ({self.minimum_output_tokens}) cannot exceed max_output_tokens ({self.max_output_tokens})")


class LLMContextProfile(RCABaseModel):
    """One provider/deployment's own constraints -- built once at
    composition time (agent_api/config.py), injected into LLMRouter. Two
    profiles (e.g. a 2048-token internal deployment and a 128K-token OpenAI
    Cloud deployment) drive the exact same Agent code differently, purely
    through this data -- never a code branch on model name (item 11's own
    explicit "no `if model == 'gpt-oss':`" prohibition)."""

    context_window_tokens: int
    route_budgets: dict[str, RouteTokenBudget] = {}
    default_route_budget: RouteTokenBudget = RouteTokenBudget(max_output_tokens=600, minimum_output_tokens=150, safety_margin_tokens=64)

    def budget_for(self, route: str) -> RouteTokenBudget:
        return self.route_budgets.get(route, self.default_route_budget)

    def available_input_tokens(self, route: str) -> int:
        """The hard ceiling for estimated (messages + schema) tokens --
        everything else (`max_output_tokens` + `safety_margin_tokens`) is
        reserved and must never be encroached on by input content."""
        budget = self.budget_for(route)
        return self.context_window_tokens - budget.max_output_tokens - budget.safety_margin_tokens

    def minimum_viable_window(self, route: str) -> int:
        """The smallest context_window_tokens value under which this route
        could EVER succeed, even with zero input -- schema-independent
        floor used by callers that want to fail configuration validation
        early (item 50/54: 'if configured reservation exceeds available
        budget, fail early, do not silently set max_tokens=1')."""
        budget = self.budget_for(route)
        return budget.minimum_output_tokens + budget.safety_margin_tokens


class TokenEstimator(Protocol):
    def estimate_text(self, text: str) -> int: ...

    def estimate_messages(self, messages: list) -> int: ...

    def estimate_schema(self, schema: dict) -> int: ...


class ApproximateTokenEstimator:
    """Conservative character-count-based approximation -- NOT an exact
    tokenizer (item 6's own explicit "do not pretend an approximation is
    exact" instruction). Uses chars-per-token=3.5 (rounded up), slightly
    more conservative than the common "~4 chars/token for English" rule of
    thumb, so this estimator is more likely to OVER-estimate than under-
    estimate -- a false-positive budget rejection (safe: retry with a
    smaller context) is preferable to a false-negative that lets an
    oversized request reach the provider. If an exact tokenizer for the
    deployed model becomes available, inject a different `TokenEstimator`
    implementation -- nothing else in this module cares which one is used."""

    _CHARS_PER_TOKEN = 3.5

    def estimate_text(self, text: str) -> int:
        if not text:
            return 0
        return math.ceil(len(text) / self._CHARS_PER_TOKEN)

    def estimate_messages(self, messages: list) -> int:
        total = 0
        for message in messages:
            content = getattr(message, "content", None)
            if content is None and isinstance(message, dict):
                content = message.get("content", "")
            total += self.estimate_text(content or "")
            total += 4  # small per-message role/formatting overhead, conservative
        return total

    def estimate_schema(self, schema: dict) -> int:
        import json

        return self.estimate_text(json.dumps(schema))



# Phase PROD-1.1: each Context Builder's own trim pass measures
# `context.model_dump_json()` -- compact, label-free JSON -- but the ACTUAL
# rendered prompt (build_planner_messages() and siblings) re-expands that
# same data into per-item labeled prose ("- {skill_id}: {purpose}
# (supported actions: ..., REQUIRED scope dimensions: ...)" etc.), which is
# measurably LESS token-dense than JSON. Empirically observed on a
# realistic WB Planner context (tests/test_context_budget_2048_profile.py):
# a context trimmed to fit its own JSON budget still rendered to roughly
# 2x that many prompt tokens. Rather than coupling this module to each
# prompt renderer (which would require agent/llm/context/* to import
# agent/llm/prompts/* -- a real circular-import risk, since prompts/*
# already imports context/* for its own PlannerContext/etc. types), this
# constant applies a conservative, documented derating: the context
# object's OWN token budget is set well below the profile's true available
# input budget, leaving headroom for prose expansion. LLMRouter's own
# preflight check (agent/llm/router.py), which measures the REAL rendered
# messages, remains the actual, authoritative hard gate -- this constant
# only makes the context builder's own best-effort trim pass realistic
# enough that the preflight check passes in the common case, rather than
# needing a second retry-with-smaller-budget cycle.
_PROSE_EXPANSION_SAFETY_FACTOR = 0.42


def derive_context_budget(profile: LLMContextProfile, route: str, base_budget):
    """Phase PROD-1.1 (item 3/11): the one generic function that turns a
    provider profile's own numbers into a Context Builder's
    `max_context_tokens` -- NO cognitive node, Context Builder, or this
    function itself ever hardcodes 2048 (or any other window size).
    `base_budget` is any of PlannerContextBudget/ReflectorContextBudget/
    SynthesisContextBudget (all share the same `max_context_tokens: int |
    None` field and Pydantic `.model_copy()`); item-count caps
    (max_findings/max_skills/...) are left exactly as the caller's own
    already-domain-tuned defaults -- only the token ceiling is profile-
    derived. A future LLM_CONTEXT_WINDOW_TOKENS=8192 (or any value)
    automatically produces a looser budget with zero code change (item 3's
    own explicit requirement), because this function reads
    `profile.available_input_tokens(route)` fresh every call. See
    `_PROSE_EXPANSION_SAFETY_FACTOR`'s own comment for why the result is
    LESS than the profile's raw available-input number."""
    context_json_budget = math.floor(profile.available_input_tokens(route) * _PROSE_EXPANSION_SAFETY_FACTOR)
    return base_budget.model_copy(update={"max_context_tokens": max(context_json_budget, 0)})
