"""LLMProviderConfig (Phase WB-3E) -- the provider-selection layer that
sits IN FRONT OF `bootstrap_runtime`, never inside it. `bootstrap_runtime`
(`agent/bootstrap.py`) deliberately requires an explicit `llm_client`
argument with no default (Frozen, untouched this phase) so it can never
silently construct a real network client; this module is what a caller
(a future CLI entrypoint, a test, an operator) uses to build one FROM
environment variables, then hands the result to `bootstrap_runtime`:

    provider_config = LLMProviderConfig.from_env()
    llm_client = build_llm_client(provider_config)
    llm_routes = provider_config.build_routes(["analyzer", "planner"])
    runtime = bootstrap_runtime(AppConfig(..., llm_routes=llm_routes), llm_client=llm_client)

Mirrors `agent/datasource/models.py::DataSourceConfig`'s own established
env-var-NAME-only convention exactly (`endpoint_env`/`credential_env`) --
this model NEVER carries a literal secret value, only the *name* of the
environment variable that holds one at deploy/run time (item AE's own
explicit requirement). `base_url` is not secret but is still
deployment-specific config, so it gets the identical env-var-name
indirection for consistency and easy per-environment overrides.

Two explicit runtime profiles (item AD), selected by `LLM_PROVIDER`:

    LLM_PROVIDER=openai            -- OpenAI Cloud
        OPENAI_MODEL, OPENAI_API_KEY (SDK's own default env var name)
    LLM_PROVIDER=internal_openai   -- internal OpenAI-compatible endpoint
        INTERNAL_LLM_MODEL, INTERNAL_LLM_BASE_URL, INTERNAL_LLM_API_KEY
    LLM_PROVIDER=anthropic         -- existing AnthropicAdapter (unchanged)
        ANTHROPIC_MODEL, ANTHROPIC_API_KEY (SDK's own default env var name)
    LLM_PROVIDER=mock              -- MockLLMClient, for a caller that
        wants `from_env()`'s own dispatch convenience without a real
        provider (e.g. a demo/offline run) -- requires an injected
        `mock_responder` (see `build_llm_client`); never the implicit
        default when no `LLM_PROVIDER` is set at all (see below).
"""
import os
from typing import Callable

from agent.llm.client import LLMClient, MockLLMClient
from agent.llm.config import LLMRouteConfig
from agent.state.base import RCABaseModel

_DEFAULT_TEMPERATURE = 0.0
_DEFAULT_MAX_TOKENS = 3000
_DEFAULT_MAX_RETRIES = 1
_DEFAULT_TIMEOUT_SECONDS = 30.0


class LLMProviderConfigError(RuntimeError):
    """`LLM_PROVIDER` names something unrecognized, or a required env var
    (model / base_url_env's target / api_key_env's target) is missing --
    raised at construction time, never discovered mid-run, matching
    `DataSourceConfigError`'s own fail-fast discipline."""


class LLMProviderConfig(RCABaseModel):
    """The serializable, secret-free half of provider selection -- every
    field here could come straight from a YAML/JSON/env-derived config,
    exactly like `AppConfig` itself. `provider` is a plain `str` (not a
    Core enum) -- this stays in the provider layer, never touching
    `agent/state/enums.py`."""

    provider: str  # "openai" | "internal_openai" | "anthropic" | "mock"
    model: str
    base_url_env: str | None = None
    api_key_env: str | None = None
    temperature: float = _DEFAULT_TEMPERATURE
    max_tokens: int = _DEFAULT_MAX_TOKENS
    max_retries: int = _DEFAULT_MAX_RETRIES
    timeout_seconds: float = _DEFAULT_TIMEOUT_SECONDS
    use_tool_calling: bool = True

    @classmethod
    def from_env(cls) -> "LLMProviderConfig":
        """Reads `LLM_PROVIDER` plus the matching provider's own env vars.
        No implicit default provider -- an unset `LLM_PROVIDER` is a
        config error, not a silent fallback to Mock or any real provider
        (item AR's own explicit "must not silently default to Mock in
        production" concern, generalized to "must not silently default to
        anything")."""
        provider = os.environ.get("LLM_PROVIDER")
        if not provider:
            raise LLMProviderConfigError(
                "LLM_PROVIDER is not set -- must be one of: openai, internal_openai, anthropic, mock "
                "(see agent/llm/providers/provider_config.py's own module docstring for the full env var list per provider)"
            )
        provider = provider.strip().lower()

        if provider == "openai":
            return cls(
                provider="openai", model=_require_env("OPENAI_MODEL"),
                api_key_env="OPENAI_API_KEY",
                temperature=_env_float("OPENAI_TEMPERATURE", _DEFAULT_TEMPERATURE),
                max_tokens=_env_int("OPENAI_MAX_TOKENS", _DEFAULT_MAX_TOKENS),
                max_retries=_env_int("OPENAI_MAX_RETRIES", _DEFAULT_MAX_RETRIES),
                timeout_seconds=_env_float("OPENAI_TIMEOUT_SECONDS", _DEFAULT_TIMEOUT_SECONDS),
            )
        if provider == "internal_openai":
            return cls(
                provider="internal_openai", model=_require_env("INTERNAL_LLM_MODEL"),
                base_url_env="INTERNAL_LLM_BASE_URL", api_key_env="INTERNAL_LLM_API_KEY",
                temperature=_env_float("INTERNAL_LLM_TEMPERATURE", _DEFAULT_TEMPERATURE),
                max_tokens=_env_int("INTERNAL_LLM_MAX_TOKENS", _DEFAULT_MAX_TOKENS),
                max_retries=_env_int("INTERNAL_LLM_MAX_RETRIES", _DEFAULT_MAX_RETRIES),
                timeout_seconds=_env_float("INTERNAL_LLM_TIMEOUT_SECONDS", _DEFAULT_TIMEOUT_SECONDS),
                # item AF/H: an arbitrary internal deployment's tool-calling
                # support is unverified -- explicit opt-out env var, never
                # assumed working without a probe.
                use_tool_calling=_env_bool("INTERNAL_LLM_USE_TOOL_CALLING", True),
            )
        if provider == "anthropic":
            return cls(provider="anthropic", model=_require_env("ANTHROPIC_MODEL"), api_key_env="ANTHROPIC_API_KEY", max_retries=_env_int("ANTHROPIC_MAX_RETRIES", _DEFAULT_MAX_RETRIES), timeout_seconds=_env_float("ANTHROPIC_TIMEOUT_SECONDS", _DEFAULT_TIMEOUT_SECONDS))
        if provider == "mock":
            return cls(provider="mock", model="mock")
        raise LLMProviderConfigError(f"LLM_PROVIDER={provider!r} is not recognized -- must be one of: openai, internal_openai, anthropic, mock")

    def build_routes(self, route_names: list[str]) -> dict[str, LLMRouteConfig]:
        """Every route this provider serves uses the SAME model (there is
        exactly one `LLMClient`/model per `RuntimeContext`, confirmed by
        reading `agent/bootstrap.py` before writing this) -- a caller
        wanting per-route models would need a `LLMRouter` capable of
        multiple clients, which does not exist yet (out of scope, not
        needed by this phase's own requirements)."""
        return {name: LLMRouteConfig(route=name, model=self.model, max_retries=self.max_retries, timeout_seconds=self.timeout_seconds) for name in route_names}


def _require_env(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise LLMProviderConfigError(f"required environment variable {name} is not set")
    return value


def _env_float(name: str, default: float) -> float:
    raw = os.environ.get(name)
    return float(raw) if raw else default


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name)
    return int(raw) if raw else default


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    return raw.strip().lower() not in ("0", "false", "no")


def build_llm_client(config: LLMProviderConfig, *, mock_responder: Callable | None = None) -> LLMClient:
    """The one place a concrete `LLMClient` gets constructed from a
    `LLMProviderConfig` -- never inside `bootstrap.py`, a graph node, or
    any domain policy (item F's own "provider SDK isolation" rule,
    generalized to provider SELECTION too). Reads secrets from the env
    var NAMED by `config.api_key_env`/`config.base_url_env` -- never from
    the config object itself, which never carries one."""
    if config.provider == "mock":
        if mock_responder is None:
            raise LLMProviderConfigError("provider='mock' requires an explicit mock_responder= callable -- never an implicit default")
        return MockLLMClient(mock_responder)

    if config.provider == "anthropic":
        from agent.llm.providers.anthropic_adapter import AnthropicAdapter

        api_key = os.environ.get(config.api_key_env) if config.api_key_env else None
        return AnthropicAdapter(api_key=api_key)

    if config.provider in ("openai", "internal_openai"):
        from agent.llm.providers.openai_adapter import OpenAICompatibleAdapter

        api_key = os.environ.get(config.api_key_env) if config.api_key_env else None
        base_url = os.environ.get(config.base_url_env) if config.base_url_env else None
        return OpenAICompatibleAdapter(
            api_key=api_key, base_url=base_url, temperature=config.temperature,
            max_tokens=config.max_tokens, use_tool_calling=config.use_tool_calling,
        )

    raise LLMProviderConfigError(f"no adapter wiring for provider={config.provider!r}")  # pragma: no cover -- from_env()'s own dispatch already rejects this earlier
