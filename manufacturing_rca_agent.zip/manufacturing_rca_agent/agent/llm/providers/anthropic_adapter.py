"""AnthropicAdapter (Phase 5B-3B) -- the first real `LLMClient` Protocol
implementation. Everything provider-specific lives here and nowhere else:
request formatting, structured-output invocation (Anthropic has no
dedicated "structured output" endpoint -- this uses forced tool-use, the
SDK's standard mechanism, with the tool's `input_schema` set to the
requested `output_model`'s own JSON schema), timeout mapping, exception
mapping, usage extraction, and model name pass-through. Nothing upstream
(AnalyzerContextBuilder, LLMRouter, prompts, Analyzer node) ever imports
`anthropic` or sees a provider-specific type -- they only ever see
`LLMMessage`/`LLMRequest`/`LLMCompletion`/the generic typed exceptions.

The `anthropic` package is an optional dependency (`pip install -e '.[llm]'`)
-- importing this module never fails even if it isn't installed; only
*constructing* `AnthropicAdapter` without it (and without an injected
`client=`) does, with a clear typed error.
"""
import os
import time

from pydantic import ValidationError

from agent.llm.client import LLMCompletion
from agent.llm.models import LLMInvalidOutputError, LLMProviderError, LLMRequest, LLMRole, LLMTimeoutError
from agent.state.base import RCABaseModel

try:
    import anthropic
except ImportError:  # pragma: no cover -- exercised by not installing the `llm` extra
    anthropic = None

_TOOL_NAME = "emit_decision"
_MAX_TOKENS = 1024


class AnthropicAdapterConfigError(RuntimeError):
    pass


class AnthropicAdapter:
    def __init__(self, api_key: str | None = None, *, client=None):
        """`client=` is for tests/dependency-injection -- any object
        exposing `.messages.create(...)` with the same shape as
        `anthropic.Anthropic().messages`, real or fake. Without it, a real
        `anthropic.Anthropic` client is constructed from `api_key` or the
        `ANTHROPIC_API_KEY` environment variable -- never a hardcoded
        secret, never read from a prompt/config file."""
        if client is not None:
            self._client = client
            return

        if anthropic is None:
            raise AnthropicAdapterConfigError(
                "the 'anthropic' package is not installed -- pip install -e '.[llm]', or inject client="
            )
        resolved_key = api_key if api_key is not None else os.environ.get("ANTHROPIC_API_KEY")
        if not resolved_key:
            raise AnthropicAdapterConfigError(
                "no Anthropic API key available -- set the ANTHROPIC_API_KEY environment variable, or pass api_key="
            )
        self._client = anthropic.Anthropic(api_key=resolved_key)

    def complete(self, request: LLMRequest, output_model: type[RCABaseModel]) -> LLMCompletion:
        system_content = "\n\n".join(m.content for m in request.messages if m.role == LLMRole.SYSTEM)
        user_content = "\n\n".join(m.content for m in request.messages if m.role == LLMRole.USER)
        schema = output_model.model_json_schema()

        started = time.monotonic()
        try:
            response = self._client.messages.create(
                model=request.model,
                max_tokens=_MAX_TOKENS,
                system=system_content,
                messages=[{"role": "user", "content": user_content}],
                tools=[{"name": _TOOL_NAME, "description": f"Emit a {output_model.__name__} object.", "input_schema": schema}],
                tool_choice={"type": "tool", "name": _TOOL_NAME},
                timeout=request.timeout_seconds,
            )
        except Exception as exc:
            raise self._map_exception(exc) from exc
        latency_ms = (time.monotonic() - started) * 1000

        tool_uses = [block for block in response.content if getattr(block, "type", None) == "tool_use"]
        if not tool_uses:
            raise LLMInvalidOutputError("provider response contained no tool_use block with the requested structured output")

        try:
            parsed = output_model.model_validate(tool_uses[0].input)
        except ValidationError as exc:
            raise LLMInvalidOutputError(f"response did not conform to {output_model.__name__}: {exc}") from exc

        usage = getattr(response, "usage", None)
        input_tokens = getattr(usage, "input_tokens", None) or 0
        output_tokens = getattr(usage, "output_tokens", None) or 0
        return LLMCompletion(parsed_output=parsed, input_tokens=input_tokens, output_tokens=output_tokens, latency_ms=latency_ms)

    @staticmethod
    def _map_exception(exc: Exception) -> Exception:
        """Never let a raw `anthropic` SDK exception reach a graph node --
        everything maps to one of the three generic typed LLM exceptions.
        Checked by class, not by module identity, so this degrades
        gracefully across SDK versions (an unrecognized subclass of
        `anthropic.AnthropicError` still falls through to the generic
        provider-error branch below rather than leaking)."""
        if anthropic is not None:
            if isinstance(exc, anthropic.APITimeoutError):
                return LLMTimeoutError(str(exc))
            if isinstance(exc, anthropic.AuthenticationError):
                return LLMProviderError(f"authentication/config error: {exc}")
            if isinstance(exc, anthropic.AnthropicError):
                return LLMProviderError(str(exc))
        return LLMProviderError(f"unexpected provider error: {exc}")
