"""OpenAICompatibleAdapter (Phase WB-3E) -- the second real `LLMClient`
Protocol implementation, mirroring `AnthropicAdapter`'s exact shape and
discipline: provider-specific request formatting, structured-output
invocation, timeout/exception mapping, and usage extraction all live
here, nowhere else. Nothing upstream (AnalyzerContextBuilder, LLMRouter,
prompts, Analyzer/Planner) ever imports `openai` or sees a
provider-specific type.

**One class serves BOTH runtime profiles** (item E's own explicit
instruction -- never two near-duplicate adapters): OpenAI Cloud and an
internal OpenAI-compatible endpoint differ only in `base_url`/`api_key`/
`model` (the last one supplied per-route via `LLMRequest.model`, exactly
like `AnthropicAdapter` -- this adapter is itself model-agnostic). The
official `openai` Python SDK is used directly (raw SDK, matching this
repo's own established convention -- `AnthropicAdapter` uses the raw
`anthropic` SDK, not a framework wrapper); `openai.OpenAI(base_url=...)`
already IS the standard way every OpenAI-compatible server documents
itself against, so no LangChain layer was introduced (see the Phase
WB-3E report for the full rationale: avoids a new heavy dependency
family, avoids LangChain's own Responses-API-vs-Chat-Completions
ambiguity item AG raised, and keeps exactly one raw-SDK-per-provider
pattern across this codebase).

**Chat Completions, never the Responses API** (item AG) -- broadest
compatibility across both an arbitrary internal OpenAI-compatible server
and OpenAI Cloud itself; `client.chat.completions.create(...)` is the one
call this adapter ever makes.

**Two-tier structured-output strategy** (item G/AF/AH): forced tool-
calling (OpenAI's standard function-calling mechanism, the same
"forced single tool" pattern `AnthropicAdapter` already uses) is tried
first by default -- but an arbitrary internal deployment's tool-calling
support is unverified/unverifiable without a live probe (item H), so
`use_tool_calling=False` switches this adapter to a plain
prompt-instructed JSON-mode fallback (schema embedded in the system
prompt, response parsed via `json.loads` + Pydantic validation) for a
deployment known not to support tool calling. Either path still enforces
the exact same Pydantic schema -- a provider's own structured-output
extension (or lack of one) never lowers schema safety (item G's own
explicit prohibition).

The `openai` package is an optional dependency (`pip install -e '.[llm]'`)
-- importing this module never fails even if it isn't installed; only
*constructing* `OpenAICompatibleAdapter` without it (and without an
injected `client=`) does, with a clear typed error.
"""
import json
import os
import time

from pydantic import ValidationError

from agent.llm.client import LLMCompletion
from agent.llm.models import LLMInvalidOutputError, LLMOutputTruncatedError, LLMProviderError, LLMRequest, LLMRole, LLMTimeoutError
from agent.llm.schema_compaction import compact_json_schema
from agent.state.base import RCABaseModel

try:
    import openai
except ImportError:  # pragma: no cover -- exercised by not installing the `llm` extra
    openai = None

_TOOL_NAME = "emit_decision"


class OpenAIAdapterConfigError(RuntimeError):
    pass


def _json_schema_prompt_suffix(output_model: type[RCABaseModel]) -> str:
    # Phase PROD-1.1 (item 42/43): compact, not the raw Pydantic schema --
    # strips `title`/`description` (often several sentences of design-
    # rationale docstring per model, repeated in every nested $defs entry)
    # while preserving every structural constraint (type/properties/
    # required/enum/$ref) the provider needs to produce a conforming
    # object. See agent/llm/schema_compaction.py for the transform itself.
    schema = compact_json_schema(output_model)
    return (
        "\n\nRespond with ONLY a single JSON object matching this JSON Schema, "
        "no prose, no markdown code fences, no explanation:\n" + json.dumps(schema)
    )


class OpenAICompatibleAdapter:
    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        temperature: float = 0.0,
        max_tokens: int = 3000,
        use_tool_calling: bool = True,
        client=None,
    ):
        """`client=` is for tests/dependency-injection -- any object
        exposing `.chat.completions.create(...)` with the same shape as
        `openai.OpenAI().chat.completions`, real or fake. Without it, a
        real `openai.OpenAI` client is constructed from `api_key` (or the
        `OPENAI_API_KEY` environment variable, the SDK's own default env
        var name) and `base_url` (`None` = the SDK's own OpenAI Cloud
        default; a non-`None` value points at an internal OpenAI-
        compatible endpoint instead) -- never a hardcoded secret, never
        read from a prompt/config file. `temperature`/`max_tokens`/
        `use_tool_calling` are genuinely adapter-level (not per-route)
        settings -- `model` itself is NOT a constructor argument, exactly
        like `AnthropicAdapter`: it comes from `LLMRequest.model` (i.e.
        from the caller's own `LLMRouteConfig`), so one adapter instance
        is never tied to one model."""
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._use_tool_calling = use_tool_calling

        if client is not None:
            self._client = client
            return

        if openai is None:
            raise OpenAIAdapterConfigError(
                "the 'openai' package is not installed -- pip install -e '.[llm]', or inject client="
            )
        resolved_key = api_key if api_key is not None else os.environ.get("OPENAI_API_KEY")
        if not resolved_key:
            raise OpenAIAdapterConfigError(
                "no API key available -- set the OPENAI_API_KEY environment variable (or the deployment's own "
                "designated env var), or pass api_key="
            )
        # Phase PROD-1.1 (item 56/57): the `openai` SDK client retries
        # transport-level failures internally by default (2 retries) --
        # stacked on top of LLMRouter's own `max_retries` loop, this could
        # multiply physical HTTP calls per logical decision well beyond
        # what LLMRouteConfig.max_retries appears to promise. Disabled
        # here so LLMRouter's own retry count is the single, accurate
        # source of truth for "how many times did we actually call the
        # provider" -- LLMRouter already has its own timeout/retry
        # semantics per route; a second, invisible retry layer underneath
        # it is redundant, not additive safety.
        self._client = openai.OpenAI(api_key=resolved_key, base_url=base_url, max_retries=0)

    def complete(self, request: LLMRequest, output_model: type[RCABaseModel]) -> LLMCompletion:
        if self._use_tool_calling:
            return self._complete_via_tool_calling(request, output_model)
        return self._complete_via_json_prompt(request, output_model)

    # --- Tier 1: forced tool-calling (primary, default) ---------------------

    def _complete_via_tool_calling(self, request: LLMRequest, output_model: type[RCABaseModel]) -> LLMCompletion:
        messages = self._to_openai_messages(request)
        schema = compact_json_schema(output_model)  # Phase PROD-1.1 -- see _json_schema_prompt_suffix's own comment

        started = time.monotonic()
        try:
            response = self._client.chat.completions.create(
                model=request.model,
                messages=messages,
                temperature=self._temperature,
                max_tokens=self._max_tokens,
                timeout=request.timeout_seconds,
                tools=[{"type": "function", "function": {"name": _TOOL_NAME, "description": f"Emit a {output_model.__name__} object.", "parameters": schema}}],
                tool_choice={"type": "function", "function": {"name": _TOOL_NAME}},
            )
        except Exception as exc:
            raise self._map_exception(exc) from exc
        latency_ms = (time.monotonic() - started) * 1000

        choice = response.choices[0] if getattr(response, "choices", None) else None
        tool_calls = getattr(getattr(choice, "message", None), "tool_calls", None) if choice is not None else None
        if not tool_calls:
            _raise_for_missing_content(choice)

        try:
            raw_args = json.loads(tool_calls[0].function.arguments)
        except (json.JSONDecodeError, AttributeError) as exc:
            raise LLMInvalidOutputError(f"tool_call arguments were not valid JSON: {exc}") from exc

        try:
            parsed = output_model.model_validate(raw_args)
        except ValidationError as exc:
            raise LLMInvalidOutputError(f"response did not conform to {output_model.__name__}: {exc}") from exc

        return LLMCompletion(parsed_output=parsed, **self._usage_kwargs(response), latency_ms=latency_ms, **_telemetry_kwargs(choice))

    # --- Tier 2: plain JSON-mode fallback (for a deployment without tool
    # calling support -- item G's own explicit compatibility-layer
    # requirement) --------------------------------------------------------

    def _complete_via_json_prompt(self, request: LLMRequest, output_model: type[RCABaseModel]) -> LLMCompletion:
        messages = self._to_openai_messages(request, extra_system_suffix=_json_schema_prompt_suffix(output_model))

        started = time.monotonic()
        try:
            response = self._client.chat.completions.create(
                model=request.model,
                messages=messages,
                temperature=self._temperature,
                max_tokens=self._max_tokens,
                timeout=request.timeout_seconds,
            )
        except Exception as exc:
            raise self._map_exception(exc) from exc
        latency_ms = (time.monotonic() - started) * 1000

        choice = response.choices[0] if getattr(response, "choices", None) else None
        content = getattr(getattr(choice, "message", None), "content", None) if choice is not None else None
        if not content:
            _raise_for_missing_content(choice)

        try:
            raw = json.loads(_strip_code_fence(content))
        except json.JSONDecodeError as exc:
            raise LLMInvalidOutputError(f"response content was not valid JSON: {exc}") from exc

        try:
            parsed = output_model.model_validate(raw)
        except ValidationError as exc:
            raise LLMInvalidOutputError(f"response did not conform to {output_model.__name__}: {exc}") from exc

        return LLMCompletion(parsed_output=parsed, **self._usage_kwargs(response), latency_ms=latency_ms, **_telemetry_kwargs(choice))

    # --- Shared helpers -------------------------------------------------

    @staticmethod
    def _to_openai_messages(request: LLMRequest, *, extra_system_suffix: str = "") -> list[dict]:
        system_content = "\n\n".join(m.content for m in request.messages if m.role == LLMRole.SYSTEM) + extra_system_suffix
        user_content = "\n\n".join(m.content for m in request.messages if m.role == LLMRole.USER)
        messages = []
        if system_content:
            messages.append({"role": "system", "content": system_content})
        messages.append({"role": "user", "content": user_content})
        return messages

    @staticmethod
    def _usage_kwargs(response) -> dict:
        usage = getattr(response, "usage", None)
        return {
            "input_tokens": getattr(usage, "prompt_tokens", None) or 0,
            "output_tokens": getattr(usage, "completion_tokens", None) or 0,
        }

    @staticmethod
    def _map_exception(exc: Exception) -> Exception:
        """Never let a raw `openai` SDK exception reach a graph node --
        everything maps to one of the three generic typed LLM exceptions.
        Checked by class, not by module identity, so this degrades
        gracefully across SDK versions. The mapped message is built from
        the exception's own string form ONLY -- never from `api_key`/
        `base_url`/any adapter-held credential, so a secret can never leak
        into `LLMCallRecord.error_message` (which the Router persists to
        the audit sink verbatim)."""
        if openai is not None:
            if isinstance(exc, openai.APITimeoutError):
                return LLMTimeoutError(str(exc))
            if isinstance(exc, openai.AuthenticationError):
                return LLMProviderError("authentication/config error (see provider logs -- credential never included here)")
            if isinstance(exc, openai.APIError):
                return LLMProviderError(str(exc))
        return LLMProviderError(f"unexpected provider error: {exc}")


def _telemetry_kwargs(choice) -> dict:
    """Phase PROD-1.2 (item B/54): bounded, presence-only telemetry for a
    SUCCESSFUL completion -- `finish_reason` (a short provider-defined
    string, e.g. "stop"/"tool_calls", never response content),
    `content_present` (always True here -- both call sites already
    validated real content/tool_calls exist before reaching this point),
    and `reasoning_content_present` (True/False only -- the actual
    `reasoning_content` text, if the vLLM/SGLang-style extension field is
    present on the message, is NEVER read into this dict or logged
    anywhere)."""
    message = getattr(choice, "message", None) if choice is not None else None
    reasoning_content = getattr(message, "reasoning_content", None) if message is not None else None
    return {
        "finish_reason": getattr(choice, "finish_reason", None) if choice is not None else None,
        "content_present": True,
        "reasoning_content_present": bool(reasoning_content),
    }


def _raise_for_missing_content(choice) -> None:
    """Phase PROD-1.1 (item 55): treat `finish_reason == "length"` as a
    first-class, distinguishable signal -- production logs already show
    this exact shape (prompt_tokens/completion_tokens both present,
    finish_reason=length, no usable message content: the reasoning model's
    own `reasoning_content`, item 10, consumed the entire output budget
    before any final structured content could be emitted). Anything else
    (finish_reason=stop with no content, missing choice entirely, a
    provider that omits finish_reason) still raises the generic
    LLMInvalidOutputError exactly as before -- this is additive
    classification, not a behavior change for any other failure shape."""
    finish_reason = getattr(choice, "finish_reason", None) if choice is not None else None
    if finish_reason == "length":
        raise LLMOutputTruncatedError(
            "provider response was truncated (finish_reason=length) before any usable content was produced -- "
            "likely consumed by reasoning_content; increase the route's reserved output budget or reduce input size"
        )
    raise LLMInvalidOutputError("provider response contained no tool_call/message content")


def _strip_code_fence(content: str) -> str:
    """A model instructed to emit "ONLY JSON" sometimes still wraps it in
    a markdown code fence anyway -- tolerate that one specific shape
    (```json ... ``` or ``` ... ```) without becoming a general markdown
    parser. Anything else is left untouched and fails `json.loads` as its
    own honest `LLMInvalidOutputError`."""
    stripped = content.strip()
    if stripped.startswith("```"):
        lines = stripped.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        return "\n".join(lines)
    return stripped
