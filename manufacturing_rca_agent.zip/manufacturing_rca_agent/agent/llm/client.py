"""LLMClient (Phase 5B-3A) -- the only seam a real provider SDK is ever
allowed to sit behind. Analyzer node code never imports a provider SDK
directly; it only ever talks to `LLMRouter`, which only ever talks to
whatever `LLMClient` it was constructed with.

`MockLLMClient` is the reference implementation this phase -- deterministic,
test-driven via an injected `responder` callable, so every LLM Runtime and
Analyzer test in this phase is fully reproducible without a real provider.
A real provider adapter (e.g. wrapping the Anthropic/OpenAI SDK) is Phase
5B-3B, implementing this exact same Protocol.
"""
from typing import Callable, Protocol

from pydantic import ValidationError

from agent.llm.models import LLMInvalidOutputError, LLMRequest
from agent.state.base import RCABaseModel


class LLMCompletion:
    """Not persisted -- what a client hands back to LLMRouter for one call:
    the typed parsed output plus the raw usage/timing LLMRouter needs to
    build an LLMCallRecord. The client, not the router, is what actually
    knows real token counts/latency for a real provider.

    Phase PROD-1.2 (item B): `finish_reason`/`content_present`/
    `reasoning_content_present` -- bounded, presence-only telemetry (NEVER
    the actual `reasoning_content` text, per the standing "no chain-of-
    thought logged" invariant). All three default to values that make
    every pre-existing `LLMCompletion(...)` construction (MockLLMClient,
    every offline test) behave exactly as before: `finish_reason=None`
    (unknown/not applicable), `content_present=True` (a Mock always
    produces content), `reasoning_content_present=False` (a Mock never
    simulates a reasoning model)."""

    def __init__(
        self, parsed_output: RCABaseModel, input_tokens: int, output_tokens: int, latency_ms: float,
        *, finish_reason: str | None = None, content_present: bool = True, reasoning_content_present: bool = False,
    ):
        self.parsed_output = parsed_output
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.latency_ms = latency_ms
        self.finish_reason = finish_reason
        self.content_present = content_present
        self.reasoning_content_present = reasoning_content_present


class LLMClient(Protocol):
    def complete(self, request: LLMRequest, output_model: type[RCABaseModel]) -> LLMCompletion:
        """Raises `LLMTimeoutError` / `LLMProviderError` /
        `LLMInvalidOutputError` on failure -- never returns a partially-
        valid result."""
        ...


class MockLLMClient:
    """`responder(request)` returns either an already-built instance of the
    requested `output_model` (happy path), or a raw dict to be validated
    against it (lets a test simulate a real provider's raw-JSON response,
    including one with rejected extra fields -- see
    tests/test_llm_runtime.py). `responder` may also raise
    `LLMTimeoutError`/`LLMProviderError` itself to simulate those failure
    modes directly.
    """

    def __init__(self, responder: Callable[[LLMRequest], RCABaseModel | dict]):
        self._responder = responder
        self.calls: list[LLMRequest] = []

    def complete(self, request: LLMRequest, output_model: type[RCABaseModel]) -> LLMCompletion:
        self.calls.append(request)
        raw = self._responder(request)

        if isinstance(raw, output_model):
            parsed = raw
        else:
            try:
                parsed = output_model.model_validate(raw)
            except ValidationError as exc:
                raise LLMInvalidOutputError(f"response did not conform to {output_model.__name__}: {exc}") from exc

        input_tokens = sum(len(m.content.split()) for m in request.messages)
        output_tokens = len(parsed.model_dump_json().split())
        return LLMCompletion(parsed_output=parsed, input_tokens=input_tokens, output_tokens=output_tokens, latency_ms=5.0)
