"""CapabilityRetriever (Phase 5C-1) -- Planner's view of "what could I do
next", deliberately much narrower than SkillRegistry.list(): a short list of
relevant SkillSummary (no Tool implementation details, no full markdown
body -- see SkillSummary's own docstring). Distinct from CapabilityResolver
(agent/capability/resolver.py), which *resolves* one already-chosen
ObjectiveAction to exactly one Skill for execution; this *retrieves*
candidates for a decision that hasn't been made yet.

Phase 5C-1 scope: deterministic domain/task_type filtering, same primitives
CapabilityResolver already uses (Skill.domains/Skill.task_types) -- no
embeddings/semantic search.

Phase PROD-1.4 (item IX): domain/task_type filtering alone was previously
the ENTIRE retrieval signal, with a pure `skill_id` alphabetical tie-break
whenever the candidate count exceeded `limit` or a later token-budget trim
pass had to pop items off the end of this list. Under WB's own capability
naming, "wip" sorts alphabetically LAST among {bank, issue, oee, output,
wip} -- meaning a WIP-focused request was structurally the first thing cut
under a tight (2048-token) profile, for a reason with nothing to do with
relevance. `query_text` (optional, defaults to None) adds a lexical
term-overlap RE-RANKING signal, reusing the exact term-overlap primitive
`agent/llm/context/reasoning_skill_retriever.py` already established --
but deliberately NOT that retriever's "all-zero-score returns []" behavior:
this retriever NEVER excludes a capability that would otherwise have fit
within `limit` purely for scoring zero relevance (a Planner needs at least
its domain/task_type-eligible options even when the request's own wording
doesn't lexically anticipate every capability name). When `query_text` is
None (every pre-existing caller), behavior is byte-identical to before.
"""
import re
from typing import Protocol

from agent.skills.models import SkillDefinition, SkillType
from agent.skills.registry import SkillRegistry
from agent.state.base import RCABaseModel
from agent.state.enums import ObjectiveAction, TaskType

_STOPWORD_MIN_LEN = 3


def _tokenize(text: str) -> set[str]:
    return {word for word in re.findall(r"[a-zA-Z0-9]+", text.lower()) if len(word) >= _STOPWORD_MIN_LEN}


def _lexical_score(query_terms: set[str], skill: SkillDefinition) -> int:
    if not query_terms:
        return 0
    corpus_terms = _tokenize(f"{skill.name} {skill.description} {skill.capability_key or ''}")
    return len(query_terms & corpus_terms)


class SkillSummary(RCABaseModel):
    """Deliberately excludes `steps`/`required_tools`/`optional_tools`/the
    markdown narrative body -- Planner decides *whether this kind of
    capability is relevant*, not how it executes (SkillRunner's job).
    `required_input_summary` is a short descriptive string
    (SkillDefinition.input_contract), not the actual Tool I/O schema.

    `accepted_scope_dimensions` (Phase WB-3F.2): without this, the Planner
    had no structured signal that e.g. "operation"/"customer" are LEGAL
    `ObjectiveScope.filters` dimensions for a given capability -- only
    `_HARD_RULES`'s generic "scope should carry any date/plant/operation/
    etc. boundary the question specifies" instruction, with no per-
    capability grounding. Live testing that phase showed the model
    reliably OMITTED a scope filter even when the user's own request text
    named it, precisely because it had nothing telling it this specific
    capability actually accepts that dimension.

    `required_scope_dimensions` (Phase WB-3F.3): previously left
    deliberately unexposed on the theory that "a missing required
    dimension gets rejected next round anyway" was sufficient -- re-added
    on reflection because that theory only covers correctness (the
    Planner eventually gets it right after a wasted retry), not
    *reliability/cost* (an explicit required/optional split up front
    should reduce how often the model needs that retry at all). Emitted as
    its own field, not folded into `accepted_scope_dimensions`, so the
    model can distinguish "must supply" from "may supply" without
    inferring it from prose."""

    skill_id: str
    name: str
    purpose: str
    supported_actions: list[ObjectiveAction]
    capability_key: str | None
    required_input_summary: str
    accepted_scope_dimensions: list[str] = []
    required_scope_dimensions: list[str] = []


def _summarize(skill: SkillDefinition) -> SkillSummary:
    return SkillSummary(
        skill_id=skill.skill_id,
        name=skill.name,
        purpose=skill.description,
        supported_actions=list(skill.actions),
        capability_key=skill.capability_key,
        required_input_summary=skill.input_contract,
        accepted_scope_dimensions=sorted(skill.accepted_scope_dimensions),
        required_scope_dimensions=sorted(skill.required_scope_dimensions),
    )


class CapabilityRetriever(Protocol):
    def retrieve(
        self,
        *,
        module_type: str,
        task_type: TaskType,
        action_hint: ObjectiveAction | None = None,
        query_text: str | None = None,
        limit: int,
    ) -> list[SkillSummary]: ...


class DeterministicCapabilityRetriever:
    def __init__(self, skill_registry: SkillRegistry):
        self._skills = skill_registry

    def retrieve(
        self,
        *,
        module_type: str,
        task_type: TaskType,
        action_hint: ObjectiveAction | None = None,
        query_text: str | None = None,
        limit: int,
    ) -> list[SkillSummary]:
        domain = module_type.lower()
        candidates = [
            skill
            for skill in self._skills.list(skill_type=SkillType.EXECUTION)  # Phase 5D-1: never surface REASONING skills as a "thing I could do"
            if (not skill.domains or domain in skill.domains) and (not skill.task_types or task_type in skill.task_types)
        ]
        query_terms = _tokenize(query_text) if query_text else set()
        # action_hint-matching first, then lexical relevance to query_text
        # (0 when query_text is None or nothing overlapped -- never
        # excludes, only re-ranks), then alphabetically stable. With
        # query_text=None every candidate's lexical term is 0, so this is
        # byte-identical to the pre-Phase-PROD-1.4 sort.
        candidates.sort(
            key=lambda s: (
                0 if action_hint is not None and action_hint in s.actions else 1,
                -_lexical_score(query_terms, s),
                s.skill_id,
            )
        )
        return [_summarize(skill) for skill in candidates[:limit]]
