"""Phase PROD-1.1 (item 47): generic, domain-agnostic token-aware trim
helper -- extracted from the near-duplicate `_trim_to_character_budget`
functions that already existed independently in
`planner_context.py`/`reflector_context.py`/`synthesis_context.py`
(char-based only). This module adds a SECOND, TOKEN-aware trim pass reusing
the exact same "priority-ordered bucket list, pop the trailing item, repeat
until it fits" mechanism each of those already implements -- it does not
replace the char-based pass (item 5 explicitly keeps character counting as
a valid secondary/rough guard), it runs AFTER it, using an injected
`TokenEstimator` instead of `len()`.

Domain-agnostic (item 48): this module has no idea what a "capability" or
"hypothesis" is -- it only knows `context.model_dump_json()`, a trim
sequence of dotted bucket-path strings, and a token budget. Each Context
Builder still owns its own `_TRIM_SEQUENCE` (the domain-aware priority
ordering, item 12-16's P0/P1/P2/P3-P4 categories) -- this function only
executes it against a token count instead of a character count.
"""
from typing import Callable, TypeVar

from agent.llm.token_budget import TokenEstimator
from agent.state.base import RCABaseModel

_T = TypeVar("_T", bound=RCABaseModel)


def trim_to_token_budget(
    context: _T,
    trim_sequence: list[str],
    max_tokens: int,
    estimator: TokenEstimator,
    *,
    get_nested: Callable[[_T, str], list] | None = None,
    set_nested: Callable[[_T, str, list], _T] | None = None,
) -> tuple[_T, int]:
    """Same trim-sequence contract every existing `_trim_to_character_budget`
    already uses: `trim_sequence` is an ordered list of either a top-level
    field name, or a `"nested.field"` dotted path (one level -- matches the
    existing `"current_state.open_hypotheses"`-style entries in
    PlannerContext's own `_TRIM_SEQUENCE`). Items are popped from the END of
    whichever bucket is least-priority-and-still-non-empty, one at a time,
    until the whole context fits `max_tokens` or nothing further can be
    trimmed (P0 fields never appear in `trim_sequence`, so they are
    structurally never touched -- same invariant the pre-existing char-trim
    functions already established)."""
    trimmed = 0
    while estimator.estimate_text(context.model_dump_json()) > max_tokens:
        progressed = False
        for bucket in trim_sequence:
            if "." in bucket:
                parent_name, field = bucket.split(".", 1)
                parent = getattr(context, parent_name)
                items = getattr(parent, field)
                if items:
                    new_parent = parent.model_copy(update={field: items[:-1]})
                    context = context.model_copy(update={parent_name: new_parent})
                    trimmed += 1
                    progressed = True
                    break
            else:
                items = getattr(context, bucket)
                if items:
                    context = context.model_copy(update={bucket: items[:-1]})
                    trimmed += 1
                    progressed = True
                    break
        if not progressed:
            break  # nothing left in trim_sequence to remove -- caller decides whether this is a hard failure
    return context, trimmed


def estimate_context_tokens(context: RCABaseModel, estimator: TokenEstimator) -> int:
    return estimator.estimate_text(context.model_dump_json())
