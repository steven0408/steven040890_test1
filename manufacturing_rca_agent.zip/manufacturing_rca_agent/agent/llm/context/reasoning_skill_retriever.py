"""ReasoningSkillRetriever (Phase 5D-4) -- a Context Builder's view of "what
guidance applies to this decision", the REASONING-skill counterpart to
CapabilityRetriever (which only ever surfaces EXECUTION skills, see its own
docstring). Deliberately the same shape/philosophy as CapabilityRetriever
and KnowledgeRetriever: deterministic metadata filtering + stable ranking,
no embeddings/vector search this phase.

A REASONING skill is retrieved by *node* first (only the nodes it declares
in `applicable_nodes` may ever see it -- this is the Node<->Skill
consumption matrix enforced at the retrieval boundary, not just documented
prose), then narrowed by module_type/task_type/role the same way
CapabilityRetriever narrows by domain/task_type. It never reaches
CapabilityResolver/SkillRunner (see agent/capability/resolver.py and
SkillRegistry.list(skill_type=...) filtering) -- retrieval and execution are
different code paths for this Skill type, not just different data.
"""
import re
from typing import Protocol

from agent.skills.models import SkillConsumerNode, SkillDefinition, SkillType
from agent.skills.registry import SkillRegistry
from agent.state.base import RCABaseModel
from agent.state.enums import TaskType


class ReasoningSkillSummary(RCABaseModel):
    """Compact representation for a Context Builder -- `guidance` is the
    Skill markdown's narrative body (the actual "how to think" text),
    deliberately not called "instructions" here: it is guidance a Context
    Builder presents as DATA, never an imperative the LLM must obey (same
    DATA/HARD-RULES boundary discipline as Evidence/Capabilities, see
    build_planner_messages/build_analyzer_messages)."""

    skill_id: str
    name: str
    purpose: str
    guidance: str
    version: str


class ReasoningSkillRetriever(Protocol):
    def retrieve(
        self,
        *,
        node: SkillConsumerNode,
        module_type: str | None = None,
        task_type: TaskType | None = None,
        role: str | None = None,
        query_text: str | None = None,
        limit: int,
    ) -> list[ReasoningSkillSummary]: ...


class EmptyReasoningSkillRetriever:
    """Same role as EmptyKnowledgeRetriever -- the safe default when no
    reasoning-skill directory has been wired up yet."""

    def retrieve(self, *, node, module_type=None, task_type=None, role=None, query_text=None, limit) -> list[ReasoningSkillSummary]:
        return []


def _matches(skill: SkillDefinition, *, node: SkillConsumerNode, module_type: str | None, task_type: TaskType | None, role: str | None) -> bool:
    if node not in skill.applicable_nodes:
        return False
    # `module_type`/`task_type` are None when the caller hasn't decided
    # those dimensions yet (e.g. Analyzer, which runs *before* any module or
    # TaskType is chosen) -- in that case, only a universally-applicable
    # skill (domains=[]/task_types=[]) can legitimately match; a
    # domain/TaskType-scoped skill has no basis to be considered relevant
    # yet, so it's excluded rather than treated as an unscoped wildcard.
    if module_type is None:
        if skill.domains:
            return False
    elif skill.domains and module_type.lower() not in skill.domains:
        return False
    if task_type is None:
        if skill.task_types:
            return False
    elif skill.task_types and task_type not in skill.task_types:
        return False
    if role is not None and skill.roles and role not in skill.roles:
        return False
    return True


_STOPWORD_MIN_LEN = 3


def _tokenize(text: str) -> set[str]:
    return {word for word in re.findall(r"[a-zA-Z0-9]+", text.lower()) if len(word) >= _STOPWORD_MIN_LEN}


def _lexical_score(query_terms: set[str], skill: SkillDefinition, guidance: str) -> int:
    """Phase PROD-1.1 (item 21/26): Stage 1 lexical relevance -- simple
    term-overlap between the caller's `query_text` (e.g. the module goal
    statement) and the skill's own name/purpose/guidance text. Deliberately
    NOT embedding-based (item 26's own "prefer incremental complexity...
    if sufficient, keep it" instruction, and item 85's "avoid a new
    dependency for a handful of Markdown files"). This is a RANKING signal
    only when query_text is supplied by the caller -- every pre-existing
    caller (query_text=None) gets byte-identical alphabetical-only
    behavior, unchanged."""
    corpus_terms = _tokenize(f"{skill.name} {skill.description} {guidance}")
    return len(query_terms & corpus_terms)


def retrieve_relevance_ranked(
    retriever: "ReasoningSkillRetriever", *, node: SkillConsumerNode,
    module_type: str | None = None, task_type: TaskType | None = None, role: str | None = None,
    query_text: str | None, limit: int,
) -> list[ReasoningSkillSummary]:
    """Phase PROD-1.4 (item VII/X): a call-site-level wrapper, NOT a change
    to `DeterministicReasoningSkillRetriever.retrieve` itself -- that
    method's own "all lexical scores zero -> return []" contract is
    deliberately locked by `tests/test_reasoning_skill_lexical_relevance.py
    ::test_no_relevant_skill_returns_zero_not_a_forced_top1` and stays
    completely untouched.

    Merges the lexically-scored subset (query_text=...) with the plain
    metadata-eligible subset (query_text=None), lexical matches first --
    guarantees the returned set is NEVER SMALLER than plain metadata
    filtering alone would produce (closing exactly the gap that caused
    Phase PROD-1.1's own earlier attempt at wiring `query_text` into the
    default Planner call site to be reverted -- see planner_context.py's
    own historical note), while still prioritizing lexically relevant
    guidance to survive first when the eligible set exceeds `limit`."""
    if not query_text:
        return retriever.retrieve(node=node, module_type=module_type, task_type=task_type, role=role, limit=limit)

    lexical = retriever.retrieve(node=node, module_type=module_type, task_type=task_type, role=role, query_text=query_text, limit=limit)
    if len(lexical) >= limit:
        return lexical

    fallback = retriever.retrieve(node=node, module_type=module_type, task_type=task_type, role=role, limit=limit)
    seen = {s.skill_id for s in lexical}
    merged = list(lexical) + [s for s in fallback if s.skill_id not in seen]
    return merged[:limit]


class DeterministicReasoningSkillRetriever:
    def __init__(self, skill_registry: SkillRegistry):
        self._skills = skill_registry

    def retrieve(
        self,
        *,
        node: SkillConsumerNode,
        module_type: str | None = None,
        task_type: TaskType | None = None,
        role: str | None = None,
        query_text: str | None = None,
        limit: int,
    ) -> list[ReasoningSkillSummary]:
        candidates = [
            skill
            for skill in self._skills.list(skill_type=SkillType.REASONING)
            if _matches(skill, node=node, module_type=module_type, task_type=task_type, role=role)
        ]

        if query_text:
            query_terms = _tokenize(query_text)
            scored = [(skill, _lexical_score(query_terms, skill, self._skills.instructions(skill.skill_id))) for skill in candidates]
            # Item 63: a query_text was supplied and query_terms exist, but
            # NOTHING overlapped lexically -- return zero, never force a
            # random Top-1 via the alphabetical fallback below.
            if query_terms and all(score == 0 for _, score in scored):
                return []
            scored = [pair for pair in scored if pair[1] > 0] if query_terms else scored
            scored.sort(key=lambda pair: (-pair[1], pair[0].skill_id))
            candidates = [skill for skill, _ in scored]
        else:
            candidates.sort(key=lambda s: s.skill_id)  # deterministic, stable -- no relevance signal available

        return [
            ReasoningSkillSummary(
                skill_id=skill.skill_id, name=skill.name, purpose=skill.description,
                guidance=self._skills.instructions(skill.skill_id), version=skill.version,
            )
            for skill in candidates[:limit]
        ]
