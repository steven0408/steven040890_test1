"""KnowledgeRetriever (Phase 5C-1) -- contract/interface only this phase, no
PostgreSQL/vector retrieval. `EmptyKnowledgeRetriever` is the production
default until a real store exists; `InMemoryKnowledgeRetriever` is a
reference implementation for tests and, later, a first real (non-vector)
knowledge store.

`ValidationStatus` distinction matters structurally, not just descriptively:
`PlannerContextBuilder` only ever calls a retriever asking for VALIDATED
items for `PlannerContext.relevant_knowledge` (see planner_context.py) --
CANDIDATE insights are never silently promoted into that field. If a future
phase wants Planner to see candidate insights too, that needs its own,
clearly-labeled field (e.g. `candidate_insights`) -- never disguised as
validated knowledge.
"""
from enum import Enum
from typing import Protocol

from pydantic import Field

from agent.state.base import RCABaseModel
from agent.state.enums import TaskType


class ValidationStatus(str, Enum):
    VALIDATED = "validated"
    CANDIDATE = "candidate"


class KnowledgeItem(RCABaseModel):
    knowledge_id: str
    statement: str
    domains: list[str] = Field(default_factory=list)  # [] = applies to any domain
    applicable_entities: list[str] = Field(default_factory=list)  # [] = not entity-specific
    applicable_patterns: list[str] = Field(default_factory=list)  # [] = not pattern-specific
    confidence: float
    validation_status: ValidationStatus
    source_scope: str  # descriptive, e.g. "run", "factory", "global" -- not a typed enum yet, no consumer needs to branch on it this phase


class KnowledgeRetriever(Protocol):
    def retrieve(
        self,
        *,
        module_type: str,
        task_type: TaskType,
        entity_ids: list[str],
        patterns: list[str],
        limit: int,
    ) -> list[KnowledgeItem]:
        """Must only return VALIDATED items -- CANDIDATE filtering is the
        retriever's own responsibility, not something callers opt into."""
        ...


class EmptyKnowledgeRetriever:
    def retrieve(self, **kwargs) -> list[KnowledgeItem]:
        return []


class InMemoryKnowledgeRetriever:
    def __init__(self, items: list[KnowledgeItem] | None = None):
        self._items = list(items or [])

    def retrieve(
        self,
        *,
        module_type: str,
        task_type: TaskType,
        entity_ids: list[str],
        patterns: list[str],
        limit: int,
    ) -> list[KnowledgeItem]:
        domain = module_type.lower()
        entity_set, pattern_set = set(entity_ids), set(patterns)

        def relevant(item: KnowledgeItem) -> bool:
            if item.validation_status != ValidationStatus.VALIDATED:
                return False
            if item.domains and domain not in [d.lower() for d in item.domains]:
                return False
            if item.applicable_entities and not (entity_set & set(item.applicable_entities)):
                return False
            if item.applicable_patterns and not (pattern_set & set(item.applicable_patterns)):
                return False
            return True

        matches = [item for item in self._items if relevant(item)]
        matches.sort(key=lambda item: item.confidence, reverse=True)
        return matches[:limit]
