"""ReflectorContext (Phase WB-3F) -- the Reflector-side counterpart to
PlannerContext: "what should Module Reflector see when interpreting the
evidence from the Objective it just executed?" Same discipline as
PlannerContextBuilder -- a selected, summarized, budget-trimmed working set
built fresh every round, never a dump of ModuleState -- and reuses the same
generic building blocks PlannerContext already established (SelectedEvidence
-shaped summaries, Finding/Hypothesis/Limitation summaries,
ReasoningSkillRetriever) rather than inventing a parallel context stack.

Deliberately does NOT include relevant_capabilities/relevant_knowledge --
Reflector never chooses a Tool/Skill and never needs the Knowledge store
(those are Planner-only context, see agent/llm/context/planner_context.py).
"""
import itertools
from datetime import datetime, timezone
from typing import Callable

from pydantic import Field, JsonValue

from agent.llm.context.context_audit import ContextAuditSink, ContextBuildRecord
from agent.llm.context.planner_context import FindingSummary, HypothesisSummary, LimitationSummary, select_top_findings
from agent.llm.context.reasoning_skill_retriever import (
    EmptyReasoningSkillRetriever,
    ReasoningSkillRetriever,
    ReasoningSkillSummary,
    retrieve_relevance_ranked,
)
from agent.llm.context.token_trim import trim_to_token_budget
from agent.llm.token_budget import ApproximateTokenEstimator, LLMContextProfile, TokenEstimator, derive_context_budget
from agent.planning.hypothesis_view import latest_hypotheses
from agent.skills.models import SkillConsumerNode
from agent.state.base import RCABaseModel
from agent.state.enums import EvidenceQuality, ObservationStatus, TaskType
from agent.state.models import ModuleState
from agent.state.payload import PayloadRegistry

_ROLE = (
    "You are the Module Reflector for a manufacturing RCA agent. Your only job is to interpret what the "
    "evidence from the Objective just executed means for that Objective and for the module's current "
    "hypotheses and findings. You never choose the next investigation, never execute a Tool, and never "
    "decide the module's final completion status."
)

_HARD_RULES = [
    "Only reference evidence_id/limitation_id/hypothesis_id values that appear in this context -- never invent one.",
    "A new hypothesis is content only -- never invent a hypothesis_id, the Harness assigns it; updating an existing hypothesis must reference a real hypothesis_id shown in Open Hypotheses.",
    # Phase PROD-1.1 (item 40): full causal_level classification criteria
    # live in the Causal Reasoning Ladder block below (previously repeated
    # here near-verbatim) -- this rule now only points at it, not restates it.
    "Classify finding_candidate.causal_level per the Causal Reasoning Ladder below by evidence TYPE/lineage, never by how strongly the evidence text is worded.",
    # Phase WB-3F.3 (item 17/19/44): the Objective/goal describes what was
    # REQUESTED; New Evidence's own EXECUTED scope describes what was
    # ACTUALLY applied by the Tool -- these can differ (e.g. an optional
    # filter the request implied was not, in fact, applied this round).
    # Trust EXECUTED scope, never the Objective/goal wording, when
    # deciding what the evidence actually supports.
    "If the Objective/goal implies a narrower scope than New Evidence's own EXECUTED scope actually shows, state the mismatch (verdict=insufficient or objective_assessment=not_satisfied/partially_satisfied) rather than asserting a scope the evidence does not support.",
    "Never propose a Tool call, a capability_key, SQL, or Python code -- that is the Planner's job, not yours.",
    "Keep rationale_summary concise -- do not include chain-of-thought reasoning.",
]


# --- Sub-schemas -------------------------------------------------------------


class ReflectorGoalContext(RCABaseModel):
    module_type: str
    task_type: TaskType
    module_goal_statement: str


class ReflectorObjectiveContext(RCABaseModel):
    objective_id: str
    action: str
    capability_key: str | None
    description: str
    expected_output: str
    target_ref_id: str


class NewEvidenceContext(RCABaseModel):
    observation_status: ObservationStatus
    payload_summary: str | None = None
    evidence_id: str | None = None
    evidence_summary: str | None = None
    evidence_quality: EvidenceQuality | None = None
    error_type: str | None = None
    error_message: str | None = None
    # Phase WB-3F.1 (item 7): evidence LINEAGE, not raw payload content --
    # lets the Reflector judge whether this round's evidence is even the
    # right TYPE to confirm a mechanism (e.g. a `*.status_summary`/
    # `*.trend_analysis` capability is inherently a plant-level aggregate,
    # never able to reach CONFIRMED_CAUSAL, regardless of how strongly its
    # prose summary reads) rather than judging solely by evidence wording.
    source_tool: str | None = None
    payload_type: str | None = None
    # Phase WB-3F.3: the EXECUTED scope -- what the Tool actually applied,
    # as distinct from what the Objective/user intended. Every WB Tool
    # Result already echoes its own resolved input as a `scope` field
    # (confirmed by a whole-Tool-layer audit this phase: all 19 WB Tools
    # construct it from `params.*`, the Pydantic-validated arguments the
    # Tool itself received -- never from raw user text, never from
    # Objective intent directly). This field surfaces that EXISTING,
    # already-authoritative echo generically (duck-typed: works for any
    # domain's Result model with a `.scope` attribute, not just WB's own
    # `WBQueryScope` -- reflector_context.py stays domain-agnostic, no WB
    # import here). Bounded: only the non-None fields of that scope
    # object, never raw rows, never the full payload.
    executed_scope: dict[str, JsonValue] | None = None


class ReflectorBudgetStatus(RCABaseModel):
    steps_remaining: int
    tool_calls_remaining: int
    retry_count: int


class ReflectorContextBudget(RCABaseModel):
    """Same coarse, provider-tokenizer-agnostic philosophy as
    PlannerContextBudget -- item-count caps at the source, then a
    character-budget trim pass as a secondary safety net."""

    max_findings: int = 5
    max_hypotheses: int = 5
    max_limitations: int = 5
    max_reasoning_skills: int = 3
    max_context_characters: int = 8000
    # Phase PROD-1.1: see PlannerContextBudget.max_context_tokens's own
    # docstring -- same additive, opt-in, second-pass token trim.
    max_context_tokens: int | None = None


class ReflectorContext(RCABaseModel):
    role: str
    hard_rules: list[str]
    goal: ReflectorGoalContext
    objective: ReflectorObjectiveContext | None
    new_evidence: NewEvidenceContext
    existing_findings: list[FindingSummary] = Field(default_factory=list)
    open_hypotheses: list[HypothesisSummary] = Field(default_factory=list)
    relevant_limitations: list[LimitationSummary] = Field(default_factory=list)
    relevant_reasoning_skills: list[ReasoningSkillSummary] = Field(default_factory=list)
    budget: ReflectorBudgetStatus
    output_contract_version: str = "1"


class ReflectorContextBuildOutcome:
    def __init__(self, context: ReflectorContext, record: ContextBuildRecord):
        self.context = context
        self.record = record


def _extract_executed_scope(evidence) -> dict[str, JsonValue] | None:
    """Phase WB-3F.3: generic, domain-agnostic extraction of a Tool
    Result's own `scope` echo (see `NewEvidenceContext.executed_scope`'s
    own docstring) -- duck-typed on `hasattr(unpacked, "scope")` rather
    than importing any WB-specific type, so this works unchanged for any
    future domain whose Result models follow the same convention, and
    degrades to `None` (never raises) for one that doesn't. Only the
    non-None fields of the scope object are surfaced -- bounded, never
    raw rows, never the rest of the payload."""
    if evidence is None or evidence.structured_payload is None:
        return None
    try:
        unpacked = PayloadRegistry.unpack(evidence.structured_payload)
    except (ValueError, KeyError):
        return None
    scope_obj = getattr(unpacked, "scope", None)
    if scope_obj is None or not hasattr(scope_obj, "model_dump"):
        return None
    return scope_obj.model_dump(exclude_none=True, mode="json")


_DEFAULT_BUDGET = ReflectorContextBudget()

_TRIM_SEQUENCE = ["relevant_reasoning_skills", "open_hypotheses", "existing_findings", "relevant_limitations"]

_context_build_id_counter = itertools.count(1)


def _trim_to_character_budget(context: ReflectorContext, max_characters: int) -> tuple[ReflectorContext, int]:
    trimmed = 0
    while len(context.model_dump_json()) > max_characters:
        progressed = False
        for bucket in _TRIM_SEQUENCE:
            items = getattr(context, bucket)
            if items:
                context = context.model_copy(update={bucket: items[:-1]})
                trimmed += 1
                progressed = True
                break
        if not progressed:
            break  # Hard Rules/Goal/Objective/New Evidence left -- nothing further to trim
    return context, trimmed


class ReflectorContextBuilder:
    def __init__(
        self,
        *,
        audit_sink: ContextAuditSink | None = None,
        reasoning_skill_retriever: ReasoningSkillRetriever | None = None,
        token_estimator: TokenEstimator | None = None,
        context_profile: LLMContextProfile | None = None,
        now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ):
        self._audit_sink = audit_sink
        self._reasoning_skill_retriever = reasoning_skill_retriever or EmptyReasoningSkillRetriever()
        self._token_estimator = token_estimator or ApproximateTokenEstimator()
        self._context_profile = context_profile  # Phase PROD-1.1 -- see PlannerContextBuilder's own docstring
        self._now_fn = now_fn

    def build(
        self,
        module_state: ModuleState,
        *,
        run_id: str,
        node: str = "module_reflector",
        budget: ReflectorContextBudget | None = None,
    ) -> ReflectorContextBuildOutcome:
        started_at = self._now_fn()
        task_type = module_state.goal.task_type
        if budget is None:
            budget = _DEFAULT_BUDGET
            if self._context_profile is not None:
                budget = derive_context_budget(self._context_profile, "reflector", budget)

        goal = ReflectorGoalContext(module_type=module_state.module_type, task_type=task_type, module_goal_statement=module_state.goal.statement)

        objective = None
        current = module_state.current_objective
        if current is not None:
            objective = ReflectorObjectiveContext(
                objective_id=current.objective_id,
                action=current.action.value,
                capability_key=current.capability_key,
                description=current.description,
                expected_output=current.expected_output,
                target_ref_id=current.target_ref.ref_id,
            )

        last_observation = module_state.observations[-1] if module_state.observations else None
        last_evidence = module_state.evidence[-1] if module_state.evidence else None
        new_evidence = NewEvidenceContext(
            observation_status=last_observation.status if last_observation is not None else ObservationStatus.ERROR,
            payload_summary=last_observation.payload_summary if last_observation is not None else None,
            evidence_id=last_evidence.evidence_id if last_evidence is not None else None,
            evidence_summary=last_evidence.summary if last_evidence is not None else None,
            evidence_quality=last_evidence.quality if last_evidence is not None else None,
            error_type=(last_observation.error.error_type.value if last_observation is not None and last_observation.error is not None else None),
            error_message=(last_observation.error.error_message if last_observation is not None and last_observation.error is not None else None),
            source_tool=last_evidence.source_tool if last_evidence is not None else None,
            payload_type=(last_evidence.structured_payload.payload_type if last_evidence is not None and last_evidence.structured_payload is not None else None),
            executed_scope=_extract_executed_scope(last_evidence),
        )

        top_findings = select_top_findings(module_state.findings, limit=budget.max_findings)
        existing_findings = [
            FindingSummary(finding_id=f.finding_id, statement=f.statement, pattern=f.pattern, status=f.status, is_root_cause=f.is_root_cause, entity_ids=list(f.entity_ids))
            for f in top_findings
        ]
        # Phase WB-3F.1: LATEST status/confidence per hypothesis_id (see
        # agent/planning/hypothesis_view.py), same convention
        # PlannerContextBuilder now applies -- Reflector reasons about the
        # current state of a hypothesis, never a stale earlier version.
        open_hypotheses = [
            HypothesisSummary(hypothesis_id=h.hypothesis_id, statement=h.statement, status=h.status, confidence=h.confidence)
            for h in latest_hypotheses(module_state.hypotheses)[: budget.max_hypotheses]
        ]
        relevant_limitations = [
            LimitationSummary(description=lim.description, impact_statement=lim.impact_statement)
            for lim in module_state.limitations[: budget.max_limitations]
        ]

        # Phase PROD-1.4 (item VII/X): same safe merge strategy as
        # PlannerContextBuilder (see retrieve_relevance_ranked's own
        # docstring) -- query_text combines the module goal and this
        # round's own evidence summary, since Reflector's relevance is
        # about interpreting THIS evidence, not choosing what to
        # investigate next.
        reflector_query_text = f"{goal.module_goal_statement} {new_evidence.evidence_summary or ''}".strip()
        relevant_reasoning_skills = retrieve_relevance_ranked(
            self._reasoning_skill_retriever, node=SkillConsumerNode.REFLECTOR, module_type=module_state.module_type,
            task_type=task_type, query_text=reflector_query_text, limit=budget.max_reasoning_skills,
        )

        budget_status = ReflectorBudgetStatus(
            steps_remaining=max(module_state.budget.max_steps - module_state.budget.used_steps, 0),
            tool_calls_remaining=max(module_state.budget.max_tool_calls - module_state.budget.used_tool_calls, 0),
            retry_count=module_state.metrics.retry_count,
        )

        context = ReflectorContext(
            role=_ROLE,
            hard_rules=list(_HARD_RULES),
            goal=goal,
            objective=objective,
            new_evidence=new_evidence,
            existing_findings=existing_findings,
            open_hypotheses=open_hypotheses,
            relevant_limitations=relevant_limitations,
            relevant_reasoning_skills=relevant_reasoning_skills,
            budget=budget_status,
            output_contract_version="1",
        )
        context, items_trimmed = _trim_to_character_budget(context, budget.max_context_characters)

        token_items_trimmed = 0
        if budget.max_context_tokens is not None:
            context, token_items_trimmed = trim_to_token_budget(context, _TRIM_SEQUENCE, budget.max_context_tokens, self._token_estimator)
        items_trimmed += token_items_trimmed

        completed_at = self._now_fn()
        record = ContextBuildRecord(
            context_build_record_id=f"reflector-ctx-build-{next(_context_build_id_counter)}",
            run_id=run_id,
            module_id=module_state.module_id,
            node=node,
            included_findings_count=len(context.existing_findings),
            included_evidence_count=1 if last_evidence is not None else 0,
            included_skills_count=0,
            included_knowledge_count=0,
            included_reasoning_skills_count=len(context.relevant_reasoning_skills),
            estimated_context_characters=len(context.model_dump_json()),
            items_trimmed=items_trimmed,
            build_duration_ms=(completed_at - started_at).total_seconds() * 1000,
            started_at=started_at,
            completed_at=completed_at,
        )
        if self._audit_sink is not None:
            self._audit_sink.record(record)

        return ReflectorContextBuildOutcome(context=context, record=record)
