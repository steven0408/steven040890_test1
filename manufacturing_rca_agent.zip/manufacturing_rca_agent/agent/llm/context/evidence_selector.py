"""EvidenceSelector (Phase 5C-1) -- Context service, not a LangGraph node.
`ModuleState.evidence` can grow without bound over a long-running module;
Planner must never see all of it, only what's relevant to the decision at
hand.

Entity/branch relevance is resolved via `ModuleState.objective_history`
(every Evidence carries `objective_id`, and every dispatched objective's
`ObjectiveRecord.target_ref` says what it was about) -- a generic bridge
that works for any domain, not string-parsing `Evidence.source_tool`. Note
(Phase 5C-1 finding): `Evidence` itself has no direct entity/target field;
this join is the workaround, and is O(evidence) per selection, acceptable
at this phase's scale -- see the Phase 5C-1 report for the "should Evidence
carry a direct target_ref" question.

Deterministic ranking this phase (no embeddings): entity match > branch
match > evidence quality > recency (append order in `ModuleState.evidence`
is oldest-first, so a later index is more recent).
"""
from agent.state.base import RCABaseModel
from agent.state.enums import EvidenceQuality, TargetRefType
from agent.state.models import Evidence, ModuleState

_QUALITY_RANK = {EvidenceQuality.WEAK: 0, EvidenceQuality.MODERATE: 1, EvidenceQuality.STRONG: 2}


class SelectedEvidence(RCABaseModel):
    evidence_id: str
    objective_id: str
    summary: str
    quality: EvidenceQuality


class DeterministicEvidenceSelector:
    def select(
        self,
        module_state: ModuleState,
        *,
        relevant_entity_ids: list[str],
        relevant_branch_ids: list[str],
        limit: int,
    ) -> list[SelectedEvidence]:
        if limit <= 0 or not module_state.evidence:
            return []

        target_by_objective = {oid: rec.target_ref for oid, rec in module_state.objective_history.items()}
        branch_by_entity = {es.entity_id: es.branch_id for es in module_state.entity_states.values()}
        entity_set, branch_set = set(relevant_entity_ids), set(relevant_branch_ids)

        def sort_key(indexed: tuple[int, Evidence]) -> tuple:
            index, evidence = indexed
            target = target_by_objective.get(evidence.objective_id)
            is_entity_target = target is not None and target.ref_type == TargetRefType.ENTITY
            entity_match = is_entity_target and target.ref_id in entity_set
            branch_match = is_entity_target and branch_by_entity.get(target.ref_id) in branch_set
            return (entity_match, branch_match, _QUALITY_RANK[evidence.quality], index)

        ranked = sorted(enumerate(module_state.evidence), key=sort_key, reverse=True)
        chosen = [evidence for _, evidence in ranked[:limit]]
        return [
            SelectedEvidence(evidence_id=e.evidence_id, objective_id=e.objective_id, summary=e.summary, quality=e.quality)
            for e in chosen
        ]
