"""AnalyzerContext (Phase 5B-3A) -- only what an Analyzer decision (infer
TaskType, select Modules) actually needs. Deliberately excludes every
execution-level thing a Module ReAct loop deals with: ModuleState,
observations, evidence, findings, objective_history, Skills, Tools,
AnalysisTree. Analyzer picks *which* Modules run and at what TaskType depth
-- it never sees how any Module actually investigates.
"""
from pydantic import Field

from agent.catalog.module_registry import ModuleDefinition, ModuleRegistry
from agent.llm.context.reasoning_skill_retriever import EmptyReasoningSkillRetriever, ReasoningSkillRetriever, ReasoningSkillSummary
from agent.llm.token_budget import ApproximateTokenEstimator, LLMContextProfile, TokenEstimator
from agent.skills.models import SkillConsumerNode
from agent.state.base import RCABaseModel
from agent.state.enums import TaskType
from agent.state.state import AgentState

_ROLE = (
    "You are the Analyzer stage of a manufacturing RCA agent. Your only job "
    "is to infer the dominant TaskType for this request and select which "
    "Modules are relevant, with a priority/confidence and a short rationale "
    "for each."
)

_HARD_RULES = [
    "Output exactly one dominant TaskType for the whole request.",
    "Only select Modules from the provided Available Module Catalog -- never invent a module_type.",
    "Never select a tool, a skill, an objective, or an RCA step -- that is not your responsibility.",
    "Keep rationale concise (one sentence) -- do not include chain-of-thought reasoning.",
]

_TASK_TYPE_DEFINITIONS_TEXT: dict[TaskType, str] = {
    TaskType.INFORMATION: "The user wants a current fact or status, with no screening or root-cause analysis.",
    TaskType.ANALYSIS: "The user wants abnormal entities identified and ranked, but not a confirmed root cause.",
    TaskType.RCA: "The user wants to know why something happened -- a confirmed root cause, following evidence as deep as needed.",
}


class TaskTypeDefinition(RCABaseModel):
    task_type: TaskType
    description: str


class AnalyzerContext(RCABaseModel):
    role: str
    hard_rules: list[str]
    user_request_text: str
    normalized_request_text: str
    factory_id: str
    factory_name: str
    available_modules: list[ModuleDefinition]
    task_type_definitions: list[TaskTypeDefinition]
    relevant_reasoning_skills: list[ReasoningSkillSummary] = Field(default_factory=list)
    output_contract_version: str = "1"


class AnalyzerContextBuilder:
    """Coarse, provider-tokenizer-agnostic context budget (Phase 5B-3A):
    caps module/rule counts up front, then trims trailing modules if the
    serialized context is still over `max_context_characters`. Token-aware
    Evidence retrieval for Planner/Reflector is a later Context phase --
    this builder never sees Evidence at all.
    """

    def __init__(
        self,
        module_registry: ModuleRegistry,
        *,
        reasoning_skill_retriever: ReasoningSkillRetriever | None = None,
        max_module_definitions: int = 20,
        max_hard_rules: int = 20,
        max_reasoning_skills: int = 2,
        max_context_characters: int = 8000,
        # Phase PROD-1.1: same additive, opt-in, second-pass token trim as
        # Planner/Reflector/Synthesis's own `max_context_tokens` -- None
        # (default) means zero behavior change for every pre-existing
        # caller. `context_profile`, when given, derives it automatically
        # from `LLM_CONTEXT_WINDOW_TOKENS` (never hardcoded here).
        max_context_tokens: int | None = None,
        token_estimator: TokenEstimator | None = None,
        context_profile: LLMContextProfile | None = None,
    ):
        self._module_registry = module_registry
        self._reasoning_skill_retriever = reasoning_skill_retriever or EmptyReasoningSkillRetriever()
        self.max_module_definitions = max_module_definitions
        self.max_hard_rules = max_hard_rules
        self.max_reasoning_skills = max_reasoning_skills
        self.max_context_characters = max_context_characters
        self._token_estimator = token_estimator or ApproximateTokenEstimator()
        self.max_context_tokens = max_context_tokens if context_profile is None else context_profile.available_input_tokens("analyzer")

    def build(self, state: AgentState) -> AnalyzerContext:
        modules = self._module_registry.available_for(state.factory_context)[: self.max_module_definitions]
        # Analyzer runs before any module/TaskType is chosen -- only
        # universally-applicable reasoning guidance (no domains/task_types
        # declared) can be relevant yet, see reasoning_skill_retriever.py's
        # `_matches`.
        reasoning_skills = self._reasoning_skill_retriever.retrieve(
            node=SkillConsumerNode.ANALYZER, module_type=None, task_type=None, limit=self.max_reasoning_skills
        )
        context = AnalyzerContext(
            role=_ROLE,
            hard_rules=_HARD_RULES[: self.max_hard_rules],
            user_request_text=state.user_request.raw_text,
            normalized_request_text=(
                state.normalized_request.normalized_text if state.normalized_request is not None else state.user_request.raw_text
            ),
            factory_id=state.factory_context.factory_id,
            factory_name=state.factory_context.factory_name,
            available_modules=modules,
            task_type_definitions=[
                TaskTypeDefinition(task_type=t, description=d) for t, d in _TASK_TYPE_DEFINITIONS_TEXT.items()
            ],
            relevant_reasoning_skills=reasoning_skills,
            output_contract_version="1",
        )

        while len(context.model_dump_json()) > self.max_context_characters and context.available_modules:
            context = context.model_copy(update={"available_modules": context.available_modules[:-1]})

        if self.max_context_tokens is not None:
            while self._token_estimator.estimate_text(context.model_dump_json()) > self.max_context_tokens and context.available_modules:
                context = context.model_copy(update={"available_modules": context.available_modules[:-1]})

        return context
