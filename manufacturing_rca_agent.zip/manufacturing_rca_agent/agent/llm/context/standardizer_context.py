"""StandardizerContext (Phase WB-3F.4) -- the smallest possible context for
the first LLM call in the whole pipeline: convert the user's own raw text
into a normalized form plus explicit structured RequestConstraints. Runs
BEFORE Analyzer/module selection/any Evidence exists, so deliberately
excludes everything those later stages need (item 53: no ModuleState, no
Evidence, no Skills, no Tools, no Findings, no History) -- just the raw
request and enough factory identity to stamp `NormalizedRequest.factory_id`.
"""
from agent.state.base import RCABaseModel

_ROLE = (
    "You are the Standardizer for a manufacturing RCA agent. Your only job is to convert the user's raw request "
    "text into a normalized form and extract any EXPLICIT structured constraints the user actually stated. You "
    "never choose a module, a capability, a Tool, or an analysis path -- that is later nodes' job, not yours."
)

_HARD_RULES = [
    "Only extract a constraint when the user's own text explicitly names a dimension and value -- never infer one from implied context.",
    "If a token could plausibly be more than one kind of dimension (e.g. it could be a customer id or a device id) with no clear textual cue, do not extract it at all -- do not guess.",
    "Date/date-range boundaries go in the time field, never as a constraint entry -- see the Output Contract below.",
    "Keep reasoning_summary concise -- do not include chain-of-thought reasoning.",
]


class StandardizerContext(RCABaseModel):
    role: str
    hard_rules: list[str]
    raw_text: str
    factory_id: str
    output_contract_version: str = "1"


class StandardizerContextBuilder:
    def build(self, *, raw_text: str, factory_id: str) -> StandardizerContext:
        return StandardizerContext(role=_ROLE, hard_rules=list(_HARD_RULES), raw_text=raw_text, factory_id=factory_id, output_contract_version="1")
