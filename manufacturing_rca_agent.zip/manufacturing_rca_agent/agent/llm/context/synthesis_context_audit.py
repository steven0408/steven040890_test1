"""SynthesisContextBuildRecord / SynthesisContextAuditSink (Phase 6A item
13) -- same "Protocol + InMemory reference impl" pattern as
ContextAuditSink/PlannerDecisionAuditSink/LLMUsageSink. Counts and sizes
only, never the rendered prompt/context content itself.
"""
from datetime import datetime
from typing import Protocol

from agent.state.base import RCABaseModel


class SynthesisContextBuildRecord(RCABaseModel):
    context_build_record_id: str
    run_id: str
    included_modules: list[str]
    included_findings_count: int
    included_root_causes_count: int
    included_limitations_count: int
    included_reasoning_skills_count: int
    estimated_context_characters: int
    items_trimmed: int
    build_duration_ms: float
    started_at: datetime
    completed_at: datetime


class SynthesisContextAuditSink(Protocol):
    def record(self, record: SynthesisContextBuildRecord) -> None: ...

    def list_for_run(self, run_id: str) -> list[SynthesisContextBuildRecord]: ...


class InMemorySynthesisContextAuditSink:
    def __init__(self) -> None:
        self._records: list[SynthesisContextBuildRecord] = []

    def record(self, record: SynthesisContextBuildRecord) -> None:
        self._records.append(record)

    def list_for_run(self, run_id: str) -> list[SynthesisContextBuildRecord]:
        return [r for r in self._records if r.run_id == run_id]
