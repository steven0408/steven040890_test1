"""LLMRouter (Phase 5B-3A) -- Harness service, not a LangGraph node, sitting
between a Node (Analyzer today) and LLMClient:

    Analyzer Node -> AnalyzerContextBuilder -> LLMRouter -> LLMClient
        -> typed AnalyzerDecision -> Node updates AgentState

Phase 1 scope (Analyzer route only): model selection via `LLMRouteConfig`,
timeout (passed through to the client via `LLMRequest.timeout_seconds`),
retry (same model, up to `max_retries`), typed-output validation (enforced
by the client, surfaced here as `LLMInvalidOutputError`), and usage logging
(one `LLMCallRecord` per physical attempt, success or failure, via
`LLMUsageSink`). Fallback-model-chain retry is NOT implemented yet --
`LLMRouteConfig.fallback_models` is contract-only.

Phase 5B-3B addition: an optional `validate` hook, run after the client's
own pydantic validation succeeds -- e.g. Analyzer's semantic validation
(selected module actually exists/enabled/available/supports this TaskType,
no duplicates, confidence/priority in range -- see
agent/graph/nodes/analyzer_llm.py's `validate_analyzer_decision`). Raising
`LLMInvalidOutputError` (or a subclass) from `validate` is treated exactly
like the client itself producing invalid output: this attempt is recorded
INVALID_OUTPUT and the router retries, same as any other failure mode.

Phase 5C-2 change: `call()` now returns `LLMRouterOutcome` (the parsed
output *and* the successful attempt's own `LLMCallRecord`) instead of the
bare parsed model. This is what lets a caller correlate a downstream
decision back to exactly which LLM call produced it (e.g.
PlannerDecisionRecord.llm_call_id) -- returning only the parsed model gave
no way to do that without an unreliable "look up the most recent sink
entry" workaround.
"""
import itertools
from datetime import datetime, timezone
from typing import Callable

from agent.llm.client import LLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.models import (
    LLMCallRecord,
    LLMCallStatus,
    LLMInvalidOutputError,
    LLMMessage,
    LLMOutputTruncatedError,
    LLMProviderError,
    LLMRequest,
    LLMTimeoutError,
)
from agent.llm.token_budget import ApproximateTokenEstimator, LLMContextBudgetExceededError, LLMContextProfile, TokenEstimator
from agent.llm.usage import LLMUsageSink
from agent.state.base import RCABaseModel

_call_id_counter = itertools.count(1)


def _status_for(exc: Exception) -> LLMCallStatus:
    """isinstance-based, not an exact-type dict lookup -- a `validate` hook
    is expected to raise a *subclass* of LLMInvalidOutputError (see
    AnalyzerSemanticValidationError), which must still map correctly here.
    Order matters: LLMOutputTruncatedError is a SUBCLASS of
    LLMInvalidOutputError, so it must be checked first (Phase PROD-1.1)."""
    if isinstance(exc, LLMTimeoutError):
        return LLMCallStatus.TIMEOUT
    if isinstance(exc, LLMProviderError):
        return LLMCallStatus.PROVIDER_ERROR
    if isinstance(exc, LLMOutputTruncatedError):
        return LLMCallStatus.OUTPUT_TRUNCATED
    if isinstance(exc, LLMInvalidOutputError):
        return LLMCallStatus.INVALID_OUTPUT
    raise TypeError(f"unexpected exception type reached LLMRouter's failure handling: {type(exc)!r}")


class LLMRouteNotFoundError(KeyError):
    pass


class LLMRouterOutcome:
    """Not persisted -- pairs the parsed output with the successful
    attempt's own LLMCallRecord (for correlation, e.g.
    PlannerDecisionRecord.llm_call_id). Only ever constructed for a
    SUCCESS; on failure `call()` raises LLMRouterError instead."""

    def __init__(self, parsed_output: RCABaseModel, call_record: LLMCallRecord):
        self.parsed_output = parsed_output
        self.call_record = call_record


class LLMRouterError(RuntimeError):
    """Every attempt (including retries) for this route failed -- callers
    (AnalyzerLLMService) catch this specifically to trigger their
    deterministic fallback, never a bare exception."""

    def __init__(self, route: str, attempts: int, last_error: Exception):
        self.route = route
        self.attempts = attempts
        self.last_error = last_error
        super().__init__(f"LLM route '{route}' failed after {attempts} attempt(s): {last_error}")


class LLMRouter:
    def __init__(
        self,
        routes: dict[str, LLMRouteConfig],
        client: LLMClient,
        usage_sink: LLMUsageSink,
        *,
        context_profile: LLMContextProfile | None = None,
        token_estimator: TokenEstimator | None = None,
        now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ):
        """`context_profile`/`token_estimator` are optional (Phase PROD-1.1)
        -- every pre-existing caller that never passes them gets byte-
        identical behavior (no preflight check at all), matching this
        codebase's own established "additive, opt-in" discipline. When a
        profile IS configured, `call()` estimates the request BEFORE the
        retry loop (messages/schema don't change between retries) and
        refuses to make ANY network attempt if it cannot fit -- item 56's
        own "context overflow: NO network retry"."""
        self._routes = routes
        self._client = client
        self._usage_sink = usage_sink
        self._context_profile = context_profile
        self._token_estimator = token_estimator or (ApproximateTokenEstimator() if context_profile is not None else None)
        self._now_fn = now_fn

    def _estimate_request(self, route: str, messages: list[LLMMessage], output_model: type[RCABaseModel]) -> tuple[int, int]:
        """Returns `(estimated_prompt_tokens, schema_tokens)` -- always
        computed the same way whether or not a profile is configured, so
        Phase PROD-1.2's own telemetry fields are populated on every
        `LLMCallRecord` (not just when the preflight guard is active),
        letting a formal-environment run compare estimate-vs-actual even
        under the pre-PROD-1.1 unbounded default profile."""
        from agent.llm.schema_compaction import compact_json_schema

        estimator = self._token_estimator or ApproximateTokenEstimator()
        schema_tokens = estimator.estimate_schema(compact_json_schema(output_model))
        estimated_prompt_tokens = estimator.estimate_messages(messages)
        return estimated_prompt_tokens, schema_tokens

    def _preflight_check(self, route: str, estimated_input: int) -> None:
        if self._context_profile is None:
            return
        available = self._context_profile.available_input_tokens(route)
        if estimated_input > available:
            budget = self._context_profile.budget_for(route)
            raise LLMContextBudgetExceededError(
                route, estimated_input_tokens=estimated_input, reserved_output_tokens=budget.max_output_tokens,
                safety_margin_tokens=budget.safety_margin_tokens, context_window_tokens=self._context_profile.context_window_tokens,
            )

    def call(
        self,
        route: str,
        messages: list[LLMMessage],
        output_model: type[RCABaseModel],
        *,
        run_id: str,
        module_id: str | None,
        node: str,
        validate: Callable[[RCABaseModel], None] | None = None,
    ) -> LLMRouterOutcome:
        config = self._routes.get(route)
        if config is None:
            raise LLMRouteNotFoundError(f"no LLMRouteConfig registered for route '{route}'")

        # Phase PROD-1.2: computed once, reused on every LLMCallRecord this
        # call produces (success or failure) -- messages/schema never
        # change across retries of the same logical call.
        estimated_prompt_tokens, schema_tokens = self._estimate_request(route, messages, output_model)
        context_window_tokens = self._context_profile.context_window_tokens if self._context_profile is not None else None
        reserved_output_tokens = self._context_profile.budget_for(route).max_output_tokens if self._context_profile is not None else None

        try:
            self._preflight_check(route, estimated_prompt_tokens + schema_tokens)
        except LLMContextBudgetExceededError as exc:
            started_at = self._now_fn()
            completed_at = started_at
            self._usage_sink.record(
                LLMCallRecord(
                    llm_call_id=f"llm-call-{next(_call_id_counter)}", run_id=run_id, module_id=module_id, node=node,
                    route=route, model=config.model, input_tokens=0, output_tokens=0, latency_ms=0.0,
                    status=LLMCallStatus.CONTEXT_BUDGET_EXCEEDED, retry_count=0, error_message=str(exc),
                    started_at=started_at, completed_at=completed_at,
                    context_window_tokens=context_window_tokens, reserved_output_tokens=reserved_output_tokens,
                    estimated_prompt_tokens=estimated_prompt_tokens, schema_tokens=schema_tokens,
                )
            )
            raise LLMRouterError(route, 0, exc) from exc

        last_error: Exception | None = None
        for attempt in range(config.max_retries + 1):
            started_at = self._now_fn()
            request = LLMRequest(
                route=route,
                model=config.model,
                messages=messages,
                output_schema_name=output_model.__name__,
                timeout_seconds=config.timeout_seconds,
                run_id=run_id,
                module_id=module_id,
                node=node,
            )
            try:
                completion = self._client.complete(request, output_model)
                if validate is not None:
                    validate(completion.parsed_output)
            except (LLMTimeoutError, LLMProviderError, LLMInvalidOutputError) as exc:
                completed_at = self._now_fn()
                self._usage_sink.record(
                    LLMCallRecord(
                        llm_call_id=f"llm-call-{next(_call_id_counter)}",
                        run_id=run_id,
                        module_id=module_id,
                        node=node,
                        route=route,
                        model=config.model,
                        input_tokens=0,
                        output_tokens=0,
                        latency_ms=(completed_at - started_at).total_seconds() * 1000,
                        status=_status_for(exc),
                        retry_count=attempt,
                        error_message=str(exc),
                        started_at=started_at,
                        completed_at=completed_at,
                        context_window_tokens=context_window_tokens, reserved_output_tokens=reserved_output_tokens,
                        estimated_prompt_tokens=estimated_prompt_tokens, schema_tokens=schema_tokens,
                        finish_reason=getattr(exc, "finish_reason", None) if isinstance(exc, LLMOutputTruncatedError) else None,
                    )
                )
                last_error = exc
                continue

            completed_at = self._now_fn()
            record = LLMCallRecord(
                llm_call_id=f"llm-call-{next(_call_id_counter)}",
                run_id=run_id,
                module_id=module_id,
                node=node,
                route=route,
                model=config.model,
                input_tokens=completion.input_tokens,
                output_tokens=completion.output_tokens,
                latency_ms=completion.latency_ms,
                status=LLMCallStatus.SUCCESS,
                retry_count=attempt,
                started_at=started_at,
                completed_at=completed_at,
                context_window_tokens=context_window_tokens, reserved_output_tokens=reserved_output_tokens,
                estimated_prompt_tokens=estimated_prompt_tokens, schema_tokens=schema_tokens,
                finish_reason=getattr(completion, "finish_reason", None),
                content_present=getattr(completion, "content_present", None),
                reasoning_present=getattr(completion, "reasoning_content_present", None),
            )
            self._usage_sink.record(record)
            return LLMRouterOutcome(parsed_output=completion.parsed_output, call_record=record)

        raise LLMRouterError(route, config.max_retries + 1, last_error)
