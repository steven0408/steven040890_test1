"""ModuleRegistry (Phase 5B-3) -- the high-level Module capability catalog
Analyzer reads instead of relying on prompt-hardcoded module names. Distinct
from ToolRegistry/SkillRegistry (agent/tools, agent/skills): those are
execution-level (what a Module's Executor can call once dispatched);
ModuleDefinition is decision-level (does this Module exist, what does it
answer, is it relevant to this factory) -- exactly what Analyzer needs and
nothing more (see AnalyzerContext, which intentionally excludes ModuleState/
Skills/Tools).

Output/WIP don't have a real ModulePlanningPolicy/capability layer yet
(that's still future work) -- their ModuleDefinition entries are just
catalog metadata; Analyzer can select them today, and whatever runtime
actually executes them (legacy `tool=` DeterministicMockPolicy, same as
Phase 5B-2.1) is a separate, later concern.
"""
from __future__ import annotations

from pydantic import Field

from agent.state.base import RCABaseModel
from agent.state.enums import TaskType
from agent.state.models import FactoryContext


class ModuleDefinition(RCABaseModel):
    module_type: str
    name: str
    description: str
    supported_task_types: list[TaskType]
    key_questions: list[str] = Field(default_factory=list)
    # Coarse applicability tags for future multi-domain catalogs (e.g. a
    # non-manufacturing deployment) -- [] means universally applicable.
    # Per-factory enable/disable is ModuleRegistry.available_for's job,
    # driven by FactoryContext.enabled_modules (the concrete mechanism
    # already in use since Phase 2), not this field.
    domains: list[str] = Field(default_factory=list)
    enabled: bool = True


class DuplicateModuleDefinitionError(ValueError):
    pass


class ModuleDefinitionNotFoundError(KeyError):
    pass


class ModuleRegistry:
    def __init__(self) -> None:
        self._modules: dict[str, ModuleDefinition] = {}

    def register(self, definition: ModuleDefinition) -> None:
        if definition.module_type in self._modules:
            raise DuplicateModuleDefinitionError(f"module_type '{definition.module_type}' is already registered")
        self._modules[definition.module_type] = definition

    def get(self, module_type: str) -> ModuleDefinition:
        definition = self._modules.get(module_type)
        if definition is None:
            raise ModuleDefinitionNotFoundError(f"no ModuleDefinition registered for module_type '{module_type}'")
        return definition

    def list(self) -> list[ModuleDefinition]:
        return list(self._modules.values())

    def available_for(self, factory_context: FactoryContext) -> list[ModuleDefinition]:
        """Modules this factory can actually use: `enabled=True` AND listed
        in `factory_context.enabled_modules` -- the same allow-list every
        Phase 2+ `analyzer_mock` scenario has implicitly assumed contained
        exactly OEE/Output/WIP."""
        return [
            definition
            for definition in self._modules.values()
            if definition.enabled and definition.module_type in factory_context.enabled_modules
        ]
