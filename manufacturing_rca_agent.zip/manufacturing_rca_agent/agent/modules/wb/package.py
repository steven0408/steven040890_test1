"""WB's `ModulePackage` (Phase WB-2C) -- the ONLY file that knows how to
wire WB into the Agent, mirroring `agent/modules/oee/package.py` exactly.
`agent/domain/wb/`, `agent/tools/wb/`, `agent/skills/wb/`,
`agent/planning/policies/wb.py` did not move -- this module just imports
and assembles them into the generic `ModulePackage` contract.

`agent/bootstrap.py` imports exactly one name from this file
(`build_wb_module_package`) and knows nothing else about WB -- no
`WBPlanningPolicy`, no WB Tool class, no synthetic dataset. Registered
into `default_module_package_registry()` (one more line, the exact
sanctioned Phase 8B-1 extension point -- never a new `if` branch in
`bootstrap_runtime` itself). NOT added to `AppConfig.enabled_modules`'s
own default list (still `["OEE"]`) -- being *available* in the package
catalog and being *enabled* for a given factory config are different
concerns (`ModuleRegistry.available_for` already keys enablement off
`FactoryContext.enabled_modules`, independent of what packages exist).
"""
from pathlib import Path

from agent.catalog.module_registry import ModuleDefinition
from agent.domain.wb.datasource import (
    InMemoryWBBankDataSource,
    InMemoryWBIssueDataSource,
    InMemoryWBPlantOEEDataSource,
    InMemoryWBStageOutputDataSource,
    InMemoryWBWIPDataSource,
)
from agent.domain.wb.synthetic import (
    build_wb_bank_records,
    build_wb_issue_records,
    build_wb_plant_oee_records,
    build_wb_stage_output_records,
    build_wb_wip_records,
)
from agent.modules.models import ModulePackage
from agent.planning.policies.wb import WBPlanningPolicy
from agent.skills.wb.registration import WB_SKILLS_DIR
from agent.state.enums import TaskType
from agent.state.models import Budget
from agent.tools.registry import ToolRegistry
from agent.tools.wb.registration import WBDataSources, register_wb_tools

_KEY_QUESTIONS = [
    # INFORMATION
    "What is the current/latest WB plant OEE status?",
    "What is the current BANK status?",
    "What is the current WIP level?",
    "What is the latest stage output?",
    # ANALYSIS
    "Which plant has lower OEE, and what is the dominant loss category?",
    "Which plant has elevated material shortage?",
    "Where is WIP Hold concentrated?",
    "Which plant has lower stage output?",
    "Which BANK lots are aging?",
    # INFORMATION/ANALYSIS (Phase WB-3A -- ISSUE)
    "What is the current WB Issue (material release) quantity for a plant?",
    "Is a plant's recent Issue quantity below its own historical baseline?",
    # ANALYSIS/RCA (Phase WB-3B) -- historical window analysis and the
    # first cross-source (ISSUE vs. OUTPUT) descriptive association. Still
    # never a causal claim -- "recurring"/"persistent"/"both declined over
    # the same window" is the ceiling, not "X caused Y". Kept BEFORE the
    # RCA-causal-claim guard block below (not appended at the very end) so
    # `test_wb_rca_key_questions_never_promise_a_definitive_root_cause`'s
    # `key_questions[-3:]` slice keeps targeting the intended questions.
    "Has a plant's Issue quantity stayed below baseline for the whole week, or was it a single day?",
    "How many times has a plant's WIP Hold ratio been elevated this week?",
    "Is a plant's OEE drop a one-off event or a recurring problem?",
    "Did a plant's Issue quantity and Output both decline over the same historical window?",
    "Did this problem start today, or has it been recurring over the past week?",
    # RCA (Phase WB-2D) -- deliberately scoped to "best-supported
    # explanation", never "true causal root cause": plant-level WB data
    # has no equipment-failure-reason/defect-reason/supply-chain-root
    # field, so promising a definitive root cause would be a claim this
    # Module's own data can never back up.
    "Why is a plant's output below expectation, and which observed factor best explains it?",
    "Is a plant's abnormality associated with OEE loss, WIP Hold, or material availability?",
    "Which observed factor is best supported by the available WB evidence?",
]


def _default_wb_datasources() -> WBDataSources:
    """Still no real API/DB (Phase WB-2C item 1) -- the same frozen
    synthetic dataset (agent/domain/wb/synthetic.py, WB Data Layer V1)
    every WB-2A/2B/2B.1/2B.2 test already builds against, wired here as
    the ModulePackage's own production-shaped default, mirroring
    `agent/modules/oee/package.py`'s `MOCK_EQUIPMENT` default exactly."""
    bank_records, bank_snapshot_dates = build_wb_bank_records()
    wip_records, wip_snapshot_dates = build_wb_wip_records()
    return WBDataSources(
        oee=InMemoryWBPlantOEEDataSource(build_wb_plant_oee_records()),
        bank=InMemoryWBBankDataSource(bank_records, snapshot_dates=bank_snapshot_dates),
        wip=InMemoryWBWIPDataSource(wip_records, snapshot_dates=wip_snapshot_dates),
        output=InMemoryWBStageOutputDataSource(build_wb_stage_output_records()),
        issue=InMemoryWBIssueDataSource(build_wb_issue_records()),
    )


def _register_wb_tools(tool_registry: ToolRegistry, datasources: WBDataSources) -> None:
    register_wb_tools(tool_registry, datasources=datasources)


def build_wb_module_package(*, datasources: WBDataSources | None = None) -> ModulePackage:
    """The one production entrypoint for WB's wiring. `datasources`
    defaults to the frozen synthetic dataset -- a caller (a future
    real-API phase, or a test) can inject a different `WBDataSources`
    without this function, `bootstrap.py`, or any Tool/Skill/Policy code
    changing."""
    resolved_datasources = datasources or _default_wb_datasources()

    return ModulePackage(
        module_definition=ModuleDefinition(
            module_type="WB",
            name="Wire Bond Operations",
            description=(
                "Wire Bond BU manufacturing operations -- Plant OEE, Bank inventory, "
                "WIP, Stage Output, and Issue (material release) status/analysis across ASE01/02/03/07/08."
            ),
            supported_task_types=[TaskType.INFORMATION, TaskType.ANALYSIS, TaskType.RCA],
            key_questions=_KEY_QUESTIONS,
        ),
        policy_factory=WBPlanningPolicy,
        # register_wb_tools() (agent/tools/wb/registration.py) already calls
        # register_wb_payloads() as its own first step (a WB-2A design
        # choice) -- no separate payload_registrations callable needed here,
        # unlike OEE's package (whose tool registration closure does NOT
        # self-register payloads).
        tool_registrations=lambda tool_registry: _register_wb_tools(tool_registry, resolved_datasources),
        skill_directories=(WB_SKILLS_DIR,),
        # Phase WB-2D: bumped from 4 to 6 -- Output-oriented RCA's worst
        # case is a 4-round chain (symptom + 3 contributing-factor checks:
        # BANK/WIP/OEE), and 4 left zero slack for even one ERROR/RETRY
        # round. Still far smaller than OEE's RCA budget (10 steps/30 tool
        # calls) -- WB RCA is deliberately shallow, plant-level only, no
        # equipment-style deep-dive.
        budget=Budget(max_steps=6, max_tool_calls=6, max_depth_per_entity=1),
        payload_registrations=None,
    )
