"""OEE's `ModulePackage` (Phase 8B-1 Part A) -- the ONLY file that knows
how to wire OEE into the Agent. `agent/domain/oee/`, `agent/planning/policies/oee.py`,
`agent/tools/oee/`, `agent/skills/oee/` did not move -- this module just
imports and assembles them into the generic `ModulePackage` contract.

`agent/bootstrap.py` imports exactly one name from this file
(`build_oee_module_package`) and knows nothing else about OEE --
no `OEEPlanningPolicy`, no `QueryOEEDataTool`, no `MOCK_EQUIPMENT`.
"""
from pathlib import Path

from agent.catalog.module_registry import ModuleDefinition
from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD, register_oee_result_payloads
from agent.domain.oee.datasource import InMemoryOEEDataSource, OEEDataSource
from agent.modules.models import ModulePackage
from agent.planning.policies.oee import OEEPlanningPolicy
from agent.state.enums import TaskType
from agent.state.models import Budget
from agent.tools.oee.capability_tools import (
    AggregateOEEStatusTool,
    CalculateContributionTool,
    FilterRowsTool,
    QueryEquipmentDetailTool,
    QueryOEEDataTool,
    RankingTool,
    register_oee_input_payloads,
)
from agent.tools.registry import ToolRegistry

_SKILLS_DIR = Path(__file__).resolve().parents[2] / "skills" / "oee"


def _register_oee_tools(tool_registry: ToolRegistry, datasource: OEEDataSource) -> None:
    """Phase 8B-1 Part D: every OEE Tool depends on `OEEDataSource`, never
    a raw equipment list -- `datasource` is this closure's own captured
    dependency, not a separate ModulePackage field (nothing else needs to
    discover it generically yet)."""
    tool_registry.register(QueryOEEDataTool(datasource, OEE_THRESHOLD))
    tool_registry.register(QueryEquipmentDetailTool(datasource))
    tool_registry.register(FilterRowsTool())
    tool_registry.register(CalculateContributionTool())
    tool_registry.register(RankingTool())
    tool_registry.register(AggregateOEEStatusTool())


def _register_oee_payloads() -> None:
    register_oee_result_payloads()
    register_oee_input_payloads()


def build_oee_module_package(*, datasource: OEEDataSource | None = None) -> ModulePackage:
    """The one production entrypoint for OEE's wiring. `datasource`
    defaults to `InMemoryOEEDataSource(MOCK_EQUIPMENT, OEE_THRESHOLD)` --
    still the same mock dataset, still no real DB (Phase 8B-1 Part E's
    explicit scope guard) -- but a caller (a future real-data phase, or a
    test) can inject a different `OEEDataSource` implementation without
    this function, `bootstrap.py`, or any Tool/Skill/Planner code
    changing."""
    resolved_datasource = datasource or InMemoryOEEDataSource(MOCK_EQUIPMENT, unavailable=False)

    return ModulePackage(
        module_definition=ModuleDefinition(
            module_type="OEE",
            name="OEE Analysis",
            description="Overall Equipment Effectiveness -- Availability/Performance/Quality across equipment.",
            supported_task_types=[TaskType.INFORMATION, TaskType.ANALYSIS, TaskType.RCA],
            key_questions=["What is current OEE?", "Which equipment has the worst OEE?", "Why did OEE decline?"],
        ),
        policy_factory=OEEPlanningPolicy,
        tool_registrations=lambda tool_registry: _register_oee_tools(tool_registry, resolved_datasource),
        skill_directories=(_SKILLS_DIR,),
        budget=Budget(max_steps=10, max_tool_calls=30, max_depth_per_entity=4),
        payload_registrations=_register_oee_payloads,
    )
