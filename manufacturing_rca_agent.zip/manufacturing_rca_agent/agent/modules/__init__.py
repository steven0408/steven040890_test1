"""Domain wiring layer (Phase 8B-1) -- how a Module/Domain gets plugged
into the Agent, kept separate from the domain's own business logic
(`agent/domain/<name>/`, `agent/planning/policies/<name>.py`,
`agent/tools/<name>/`, `agent/skills/<name>/`, none of which moved here).
See `agent/modules/models.py` for the `ModulePackage` contract and
`agent/modules/registry.py` for `ModulePackageRegistry`.
"""
