"""ModulePackageRegistry (Phase 8B-1 Part B) -- same "name -> instance,
typed duplicate/missing errors" shape every other registry in this
codebase already uses (`ModuleRegistry`/`ToolRegistry`/`SkillRegistry`/
`DataSourceRegistry`), applied one level up: a registry of *how to wire a
domain in*, not of the domain's own capabilities.
"""
from __future__ import annotations

from agent.modules.models import ModulePackage


class DuplicateModulePackageError(ValueError):
    pass


class ModulePackageNotFoundError(KeyError):
    pass


class ModulePackageRegistry:
    def __init__(self) -> None:
        self._packages: dict[str, ModulePackage] = {}

    def register(self, package: ModulePackage) -> None:
        module_type = package.module_type
        if module_type in self._packages:
            raise DuplicateModulePackageError(f"module_type '{module_type}' already has a registered ModulePackage")
        self._packages[module_type] = package

    def get(self, module_type: str) -> ModulePackage:
        package = self._packages.get(module_type)
        if package is None:
            raise ModulePackageNotFoundError(f"no ModulePackage registered for module_type '{module_type}'")
        return package

    def list(self) -> list[ModulePackage]:
        return list(self._packages.values())
