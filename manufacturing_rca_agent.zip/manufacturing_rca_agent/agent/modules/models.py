"""ModulePackage (Phase 8B-1 Part A) -- "this is how a Domain gets wired
into the Agent," and nothing else. It is deliberately NOT a business-logic
container: no analysis logic, no Tool implementation, no Skill content
lives here or is imported into this file beyond the Protocol/type-level
contracts needed to describe wiring.

Fields map 1:1 onto what `agent/bootstrap.py`'s old `if "OEE" in
config.enabled_modules:` block used to do by hand for exactly one domain
(see the Phase 8B-1 report for the before/after diff):

    module_definition     -- what _default_module_catalog() used to hardcode
    policy_factory         -- what constructed `OEEPlanningPolicy()` inline
                               (returns the RAW domain policy; bootstrap's
                               generic loop still wraps it in
                               `LLMPlanningPolicy` uniformly for every
                               domain -- that wrapping is a cross-cutting
                               concern, not domain-specific, so it stays in
                               bootstrap.py, not here)
    tool_registrations     -- what _register_oee_tools() used to do
                               (any datasource construction is the
                               closure's own business -- ModulePackage
                               doesn't need a separate datasource_factory
                               hook until something else needs to discover
                               a domain's datasource generically, which
                               nothing does yet)
    skill_directories       -- what one entry in AppConfig.skill_directories'
                               default list used to hardcode
    budget                  -- what the inline Budget(...) literal used to hardcode
    payload_registrations   -- Phase 8B-1 Part F: explicit PayloadRegistry
                               registration, called once by bootstrap
                               instead of relying on import-time side
                               effects. None for a domain with no
                               registered payload types.
"""
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from agent.catalog.module_registry import ModuleDefinition
from agent.planning.policies.base import ModulePlanningPolicy
from agent.state.models import Budget
from agent.tools.registry import ToolRegistry


@dataclass(frozen=True)
class ModulePackage:
    module_definition: ModuleDefinition
    policy_factory: Callable[[], ModulePlanningPolicy]
    tool_registrations: Callable[[ToolRegistry], None]
    skill_directories: tuple[Path, ...]
    budget: Budget
    payload_registrations: Callable[[], None] | None = None

    @property
    def module_type(self) -> str:
        return self.module_definition.module_type
