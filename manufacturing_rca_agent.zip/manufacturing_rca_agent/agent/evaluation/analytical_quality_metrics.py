"""compute_analytical_quality_metrics (Phase 7A item 2/5/6) -- deterministic
rule-based scoring of the analysis *result itself* (not the process that
produced it -- that's decision_quality_metrics.py's job). No LLM judge.

Evidence coverage formula (item 5's explicit ask: not a bare
`len(evidence)/len(findings)` ratio): for each module, look at every
COMPLETED objective and ask "did this objective actually produce evidence"
(via `ObjectiveRecord.evidence_ids`, a real pairing, not a coincidental
count) -- then give partial credit back for any gap a Limitation actually
explains (`Limitation.impacted_objective_id` naming that exact objective).
A module that dispatched 3 objectives, got evidence for 2, and has a
Limitation explaining the 3rd scores higher than a module with the same
2-of-3 evidence yield but silence about the gap -- rewarding transparency,
not just raw yield. See `_module_evidence_coverage`'s own docstring for
the exact arithmetic.
"""
from agent.state.enums import FindingStatus, ModuleStatus, ObjectiveStatus, RelationType, TaskType
from agent.state.models import AnalyticalQualityMetrics, HandoffPackage, ModuleState

_INCOMPLETE_STATUSES = (ModuleStatus.PARTIAL, ModuleStatus.FAILED, ModuleStatus.BLOCKED)


def _fact_consistency(actual: HandoffPackage, reference: HandoffPackage) -> float:
    """Does the *delivered* package (possibly LLM-drafted, Phase 6B) agree
    with a fresh deterministic rebuild from the same module_states on
    every authoritative fact -- root causes, key findings, overall_status?
    In this codebase's current design this is expected to always read 1.0:
    `build_handoff_package_from_draft` structurally guarantees fact
    preservation (only `markdown` can differ). This metric exists to catch
    a *regression* of that guarantee, not to find drift that's possible
    today."""
    checks = [
        {rc.root_cause_id for rc in actual.root_causes} == {rc.root_cause_id for rc in reference.root_causes},
        {f.finding_id for f in actual.key_findings} == {f.finding_id for f in reference.key_findings},
        actual.overall_status == reference.overall_status,
    ]
    return sum(checks) / len(checks)


def _relation_support(actual: HandoffPackage) -> float:
    """Every CrossModuleRelation in the delivered package, checked against
    the same rule its own pydantic validator enforces (CONFIRMED_CAUSAL
    requires supporting_finding_ids) plus that those ids resolve to a real
    finding in the same package. 1.0 when there are no relations to check
    -- vacuously fine, and the expected case today (Phase 6A/6B never
    auto-generate one)."""
    if not actual.cross_module_relations:
        return 1.0
    finding_ids = {f.finding_id for f in actual.key_findings}
    scores = []
    for rel in actual.cross_module_relations:
        if rel.relation_type == RelationType.CONFIRMED_CAUSAL and not rel.supporting_finding_ids:
            scores.append(0.0)  # structurally impossible given the model validator, defensive only
        elif rel.supporting_finding_ids:
            scores.append(1.0 if set(rel.supporting_finding_ids) & finding_ids else 0.5)
        else:
            scores.append(1.0)  # CORRELATED/SUPPORTS/CAUSAL_CANDIDATE never require support
    return sum(scores) / len(scores)


def _module_evidence_coverage(module_state: ModuleState) -> float:
    dispatched = [r for r in module_state.objective_history.values() if r.status == ObjectiveStatus.COMPLETED]
    if not dispatched:
        return 0.0
    covered = [r for r in dispatched if r.evidence_ids]
    base = len(covered) / len(dispatched)
    uncovered_objective_ids = {r.objective_id for r in dispatched if not r.evidence_ids}
    if uncovered_objective_ids:
        explained = sum(1 for lim in module_state.limitations if lim.impacted_objective_id in uncovered_objective_ids)
        # half credit per explained gap -- transparency narrows the
        # penalty, it doesn't erase it (evidence is still genuinely missing)
        base += 0.5 * (explained / len(dispatched))
    return min(1.0, base)


def _root_cause_support(module_state: ModuleState) -> float | None:
    """Only meaningful for RCA-task modules; returns None for
    INFORMATION/ANALYSIS (root causes are never expected there, see
    ModuleHandoffBuilder). A PARTIAL module with no root cause but a clear
    limitation gets a real partial score (item 6's explicit instruction),
    not an automatic 0."""
    if module_state.goal.task_type != TaskType.RCA:
        return None

    root_cause_findings = [f for f in module_state.findings if f.status == FindingStatus.CONFIRMED and f.is_root_cause]
    if root_cause_findings:
        evidence_by_id = {e.evidence_id: e for e in module_state.evidence}
        scores = []
        for f in root_cause_findings:
            checks = [
                True,  # status == CONFIRMED, already filtered above
                True,  # is_root_cause, already filtered above
                bool(f.entity_ids),
            ]
            linked_evidence = [evidence_by_id[eid] for eid in f.supporting_evidence_ids if eid in evidence_by_id]
            checks.append(bool(linked_evidence))
            checks.append(bool(linked_evidence) and any(e.objective_id in module_state.objective_history for e in linked_evidence))
            scores.append(sum(checks) / len(checks))
        return sum(scores) / len(scores)

    # no root cause -- was that transparently explained, or silent?
    if module_state.status == ModuleStatus.FAILED:
        return 0.0
    if module_state.status in (ModuleStatus.PARTIAL, ModuleStatus.BLOCKED):
        return 0.5 if module_state.limitations or module_state.rejections else 0.2
    return None  # still RUNNING/PENDING or COMPLETE-with-no-root-cause-expected -- not scoreable here


def compute_analytical_quality_metrics(
    module_states: list[ModuleState], *, actual_package: HandoffPackage, reference_package: HandoffPackage
) -> AnalyticalQualityMetrics:
    if not module_states:
        return AnalyticalQualityMetrics(
            evidence_coverage=0.0, confirmed_finding_ratio=1.0, root_cause_support_score=1.0,
            limitation_transparency_score=1.0, unresolved_question_transparency=1.0,
            failed_module_ratio=0.0, blocked_module_ratio=0.0, partial_module_ratio=0.0,
            synthesis_fact_consistency=1.0, cross_module_relation_support_score=1.0,
        )

    evidence_coverage = sum(_module_evidence_coverage(m) for m in module_states) / len(module_states)

    all_findings = [f for m in module_states for f in m.findings]
    confirmed_finding_ratio = (
        sum(1 for f in all_findings if f.status == FindingStatus.CONFIRMED) / len(all_findings) if all_findings else 1.0
    )

    rca_scores = [s for m in module_states if (s := _root_cause_support(m)) is not None]
    root_cause_support_score = sum(rca_scores) / len(rca_scores) if rca_scores else 1.0

    def _explained(m: ModuleState) -> bool:
        if m.status not in _INCOMPLETE_STATUSES:
            return True
        return bool(m.limitations) or bool(m.rejections)

    limitation_transparency_score = sum(1 for m in module_states if _explained(m)) / len(module_states)

    def _questions_transparent(m: ModuleState) -> bool:
        open_hypotheses = [h for h in m.hypotheses if h.status.value == "open"]
        no_root_cause_rca = m.goal.task_type == TaskType.RCA and not any(f.is_root_cause and f.status == FindingStatus.CONFIRMED for f in m.findings)
        has_open_question = bool(open_hypotheses) or (no_root_cause_rca and m.status != ModuleStatus.COMPLETE)
        if not has_open_question:
            return True
        return bool(m.limitations) or bool(open_hypotheses)  # the question itself being recorded counts as transparency

    unresolved_question_transparency = sum(1 for m in module_states if _questions_transparent(m)) / len(module_states)

    failed_module_ratio = sum(1 for m in module_states if m.status == ModuleStatus.FAILED) / len(module_states)
    blocked_module_ratio = sum(1 for m in module_states if m.status == ModuleStatus.BLOCKED) / len(module_states)
    partial_module_ratio = sum(1 for m in module_states if m.status == ModuleStatus.PARTIAL) / len(module_states)

    return AnalyticalQualityMetrics(
        evidence_coverage=evidence_coverage,
        confirmed_finding_ratio=confirmed_finding_ratio,
        root_cause_support_score=root_cause_support_score,
        limitation_transparency_score=limitation_transparency_score,
        unresolved_question_transparency=unresolved_question_transparency,
        failed_module_ratio=failed_module_ratio,
        blocked_module_ratio=blocked_module_ratio,
        partial_module_ratio=partial_module_ratio,
        synthesis_fact_consistency=_fact_consistency(actual_package, reference_package),
        cross_module_relation_support_score=_relation_support(actual_package),
    )
