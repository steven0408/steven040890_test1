"""compute_decision_quality_metrics (Phase 7A item 2) -- deterministic
scoring of the *decisions* Analyzer/Planner made, not the analysis result
itself (that's analytical_quality_metrics.py). No LLM judge; Planner
quality scores, when present, are precomputed externally (Phase 5C-3's
`evaluate_planner_decision_quality`) since retrospective recomputation
from a bare `PlannerDecisionRecord` isn't possible -- see
`PlannerDecisionQualityAggregate`'s own docstring.
"""
from collections import Counter

from agent.evaluation.inputs import RunAuditBundle
from agent.llm.models import DecisionSource, LLMCallStatus
from agent.state.enums import ObjectiveAction, TaskType
from agent.state.models import AnalyzerDecisionQuality, DecisionQualityMetrics, ModuleState, PlannerDecisionQualityAggregate
from agent.state.state import AgentState

# Public (not `_`-prefixed): shared with delivery_quality_metrics.py's
# `_task_type_depth_compliance` so the two never silently disagree on what
# "unnecessary depth" means for a given TaskType.
SCREENING_DEPTH_ACTIONS = {TaskType.INFORMATION: {ObjectiveAction.SCREEN, ObjectiveAction.DRILL_DOWN}, TaskType.ANALYSIS: {ObjectiveAction.DRILL_DOWN}}


def _analyzer_quality(final_state: AgentState, bundle: RunAuditBundle) -> AnalyzerDecisionQuality:
    selected = final_state.selected_modules
    unsupported = sum(1 for task in selected if task.module_id not in final_state.module_states)
    validity = (len(selected) - unsupported) / len(selected) if selected else 1.0
    return AnalyzerDecisionQuality(
        selected_module_count=len(selected),
        module_selection_validity=validity,
        unsupported_module_selection_count=unsupported,
        analyzer_fallback_used=bundle.analyzer_source == DecisionSource.FALLBACK,
    )


def _unnecessary_deep_dive_count(module_states: list[ModuleState]) -> int:
    """A TaskType-aware check (item 7's own worked example): an
    INFORMATION module that ever dispatched SCREEN/DRILL_DOWN, or an
    ANALYSIS module that ever dispatched DRILL_DOWN, is flagged regardless
    of whether the final answer happened to be correct -- unnecessary
    depth is a process problem, not an outcome problem."""
    count = 0
    for module in module_states:
        forbidden = SCREENING_DEPTH_ACTIONS.get(module.goal.task_type)
        if forbidden and any(r.action in forbidden for r in module.objective_history.values()):
            count += 1
    return count


def _redundant_target_count(bundle: RunAuditBundle) -> int:
    pairs = [
        (r.proposed_action, r.target_ref.ref_id)
        for r in bundle.planner_decision_records
        if r.proposed_action is not None and r.target_ref is not None
    ]
    counts = Counter(pairs)
    return sum(c - 1 for c in counts.values() if c > 1)


def _planner_quality(final_state: AgentState, bundle: RunAuditBundle) -> PlannerDecisionQualityAggregate:
    qualities = [q.overall_score for q in bundle.planner_decision_qualities]
    invalid_decision_count = sum(
        1 for r in bundle.llm_call_records if r.route == "planner" and r.status == LLMCallStatus.INVALID_OUTPUT
    )
    fallback_decision_count = sum(1 for r in bundle.planner_decision_records if r.source == DecisionSource.FALLBACK)

    return PlannerDecisionQualityAggregate(
        average_planner_quality=sum(qualities) / len(qualities) if qualities else None,
        minimum_planner_quality=min(qualities) if qualities else None,
        invalid_decision_count=invalid_decision_count,
        fallback_decision_count=fallback_decision_count,
        redundant_target_count=_redundant_target_count(bundle),
        unnecessary_deep_dive_count=_unnecessary_deep_dive_count(list(final_state.module_states.values())),
        baseline_alignment_score=None,  # not computed this phase -- needs an explicit deterministic-baseline trace to diff against
    )


def compute_decision_quality_metrics(final_state: AgentState, bundle: RunAuditBundle) -> DecisionQualityMetrics:
    return DecisionQualityMetrics(analyzer=_analyzer_quality(final_state, bundle), planner=_planner_quality(final_state, bundle))
