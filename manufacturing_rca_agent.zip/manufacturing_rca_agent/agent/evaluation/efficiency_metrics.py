"""compute_efficiency_metrics (Phase 7A item 2/7) -- deterministic, purely
additive/counting arithmetic over `AgentState` + `RunAuditBundle`. No
judgment calls beyond the Phase 5B-1.2 terminology freeze itself.
"""
from agent.evaluation.inputs import RunAuditBundle
from agent.state.enums import ModuleStatus, ObservationStatus
from agent.state.lifecycle import run_duration_ms
from agent.state.models import EfficiencyMetrics
from agent.state.state import AgentState


def compute_efficiency_metrics(final_state: AgentState, bundle: RunAuditBundle) -> EfficiencyMetrics:
    modules = list(final_state.module_states.values())

    # Logical Tool Call: distinct idempotency_key (the deterministic
    # identity ToolExecutionManager itself uses -- NOT `logical_call_id`,
    # which is coarser: it omits `logical_attempt`, so two genuinely
    # different logical attempts at the same objective would collapse
    # together under logical_call_id but not under idempotency_key).
    logical_keys = {r.idempotency_key or r.tool_call_id for r in bundle.tool_call_records}

    context_records = [*bundle.planner_context_records, *bundle.synthesis_context_records]

    return EfficiencyMetrics(
        total_module_count=len(modules),
        completed_module_count=sum(1 for m in modules if m.status == ModuleStatus.COMPLETE),
        planner_decision_count=len(bundle.planner_decision_records),
        objective_count=sum(len(m.objective_history) for m in modules),
        logical_tool_call_count=len(logical_keys),
        tool_manager_invocation_count=len(bundle.tool_call_records),
        physical_tool_execution_count=sum(1 for r in bundle.tool_call_records if not r.result_reused),
        result_reuse_count=sum(1 for r in bundle.tool_call_records if r.result_reused),
        replay_count=sum(1 for r in bundle.tool_call_records if r.replayed),
        failed_tool_execution_count=sum(1 for r in bundle.tool_call_records if r.status == ObservationStatus.ERROR),
        total_llm_calls=len(bundle.llm_call_records),
        llm_retry_count=sum(r.retry_count for r in bundle.llm_call_records),
        input_tokens=sum(r.input_tokens for r in bundle.llm_call_records),
        output_tokens=sum(r.output_tokens for r in bundle.llm_call_records),
        total_context_characters=sum(r.estimated_context_characters for r in context_records),
        context_trim_count=sum(r.items_trimmed for r in context_records),
        human_intervention_count=len(bundle.human_requests),
        # Phase 8A-1 item 7: AgentState now carries real started_at/
        # completed_at (Phase 7A's gap this closes) -- None whenever the
        # run somehow reaches Evaluator without a stamped completed_at
        # (see global_completion_check.py), never a fabricated duration.
        total_duration_ms=run_duration_ms(final_state),
    )
