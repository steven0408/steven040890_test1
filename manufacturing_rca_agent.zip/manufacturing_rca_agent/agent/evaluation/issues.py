"""generate_issues (Phase 7A item 4) -- deterministic, rule-based issue
detection over already-computed metrics. Every rule here is a plain
threshold/count check against a real metric -- never an LLM judgment, and
never something that gets written back as Learning knowledge (that
boundary is Learning's job, Phase 7C -- see agent/evaluation/evaluator.py's
architecture note).
"""
import itertools

from agent.evaluation.decision_quality_metrics import SCREENING_DEPTH_ACTIONS
from agent.state.enums import EvaluationCategory, EvaluationSeverity, FindingStatus
from agent.state.models import (
    AnalyticalQualityMetrics,
    DecisionQualityMetrics,
    DeliveryQualityMetrics,
    EfficiencyMetrics,
    EvaluationIssue,
    ModuleState,
)

_ROOT_CAUSE_SUPPORT_THRESHOLD = 0.6
_CONTEXT_TRIM_THRESHOLD = 5
_FALLBACK_DECISION_THRESHOLD = 2

_issue_id_counter = itertools.count(1)


def _next_issue_id() -> str:
    return f"issue-{next(_issue_id_counter)}"


def _deep_dive_module_ids(module_states: list[ModuleState]) -> list[str]:
    ids = []
    for module in module_states:
        forbidden = SCREENING_DEPTH_ACTIONS.get(module.goal.task_type)
        if forbidden and any(r.action in forbidden for r in module.objective_history.values()):
            ids.append(module.module_id)
    return ids


def generate_issues(
    module_states: list[ModuleState],
    efficiency: EfficiencyMetrics,
    analytical: AnalyticalQualityMetrics,
    decision: DecisionQualityMetrics,
    delivery: DeliveryQualityMetrics,
) -> list[EvaluationIssue]:
    issues: list[EvaluationIssue] = []

    # Only meaningful when a root cause was actually PRESENTED (CONFIRMED +
    # is_root_cause) -- a PARTIAL module with no root cause yet can also
    # score below the threshold (item 6's "reasonable partial score" for a
    # transparently-unresolved root cause), and that is explicitly NOT the
    # same problem: nothing was presented, so there is nothing to flag as
    # under-supported.
    any_root_cause_presented = any(f.status == FindingStatus.CONFIRMED and f.is_root_cause for m in module_states for f in m.findings)
    if any_root_cause_presented and analytical.root_cause_support_score < _ROOT_CAUSE_SUPPORT_THRESHOLD:
        issues.append(
            EvaluationIssue(
                issue_id=_next_issue_id(), category=EvaluationCategory.ANALYTICAL_QUALITY, severity=EvaluationSeverity.HIGH,
                statement="A presented root cause has low evidence/lineage support.", metric_name="root_cause_support_score",
                suggested_improvement_area="strengthen evidence lineage before confirming a root cause",
            )
        )

    if not delivery.hallucination_guard_passed:
        issues.append(
            EvaluationIssue(
                issue_id=_next_issue_id(), category=EvaluationCategory.DELIVERY_QUALITY, severity=EvaluationSeverity.HIGH,
                statement="The delivered Handoff contains a root cause not grounded in the underlying module results.",
                metric_name="hallucination_guard_passed", suggested_improvement_area="Synthesis fact-grounding pipeline",
            )
        )

    if decision.planner.redundant_target_count > 0:
        issues.append(
            EvaluationIssue(
                issue_id=_next_issue_id(), category=EvaluationCategory.DECISION_QUALITY, severity=EvaluationSeverity.MEDIUM,
                statement=f"The same (action, target) was dispatched {decision.planner.redundant_target_count} redundant time(s).",
                metric_name="redundant_target_count", suggested_improvement_area="Planner objective de-duplication",
            )
        )

    if decision.planner.fallback_decision_count >= _FALLBACK_DECISION_THRESHOLD:
        issues.append(
            EvaluationIssue(
                issue_id=_next_issue_id(), category=EvaluationCategory.DECISION_QUALITY, severity=EvaluationSeverity.MEDIUM,
                statement=f"{decision.planner.fallback_decision_count} Planner decisions used the deterministic fallback.",
                metric_name="fallback_decision_count", suggested_improvement_area="Planner LLM reliability",
            )
        )

    deep_dive_ids = _deep_dive_module_ids(module_states)
    if deep_dive_ids:
        issues.append(
            EvaluationIssue(
                issue_id=_next_issue_id(), category=EvaluationCategory.DECISION_QUALITY, severity=EvaluationSeverity.MEDIUM,
                statement="A module dispatched an objective deeper than its TaskType warrants.", related_module_ids=deep_dive_ids,
                metric_name="unnecessary_deep_dive_count", suggested_improvement_area="TaskType-aware depth gating",
            )
        )

    if decision.analyzer.analyzer_fallback_used:
        issues.append(
            EvaluationIssue(
                issue_id=_next_issue_id(), category=EvaluationCategory.DECISION_QUALITY, severity=EvaluationSeverity.LOW,
                statement="Analyzer used its deterministic fallback instead of a real decision.", metric_name="analyzer_fallback_used",
                suggested_improvement_area="Analyzer LLM reliability",
            )
        )

    if efficiency.context_trim_count > _CONTEXT_TRIM_THRESHOLD:
        issues.append(
            EvaluationIssue(
                issue_id=_next_issue_id(), category=EvaluationCategory.EFFICIENCY, severity=EvaluationSeverity.LOW,
                statement=f"Context was trimmed {efficiency.context_trim_count} time(s) across this run.", metric_name="context_trim_count",
                suggested_improvement_area="context budget tuning",
            )
        )

    if efficiency.failed_tool_execution_count > 0:
        issues.append(
            EvaluationIssue(
                issue_id=_next_issue_id(), category=EvaluationCategory.EFFICIENCY, severity=EvaluationSeverity.MEDIUM,
                statement=f"{efficiency.failed_tool_execution_count} physical tool execution(s) failed.", metric_name="failed_tool_execution_count",
                suggested_improvement_area="Tool reliability / error handling",
            )
        )

    if efficiency.llm_retry_count > 0:
        issues.append(
            EvaluationIssue(
                issue_id=_next_issue_id(), category=EvaluationCategory.EFFICIENCY, severity=EvaluationSeverity.LOW,
                statement=f"LLM calls required {efficiency.llm_retry_count} retry attempt(s) in total.", metric_name="llm_retry_count",
                suggested_improvement_area="LLM output reliability",
            )
        )

    return issues
