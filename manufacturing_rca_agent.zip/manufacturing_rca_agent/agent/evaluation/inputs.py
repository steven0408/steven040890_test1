"""RunAuditBundle (Phase 7A) -- everything `RunEvaluator.evaluate()` reads
beyond `final_state` itself. A plain data bag, not run state and not
persisted -- the caller (whoever actually ran the graph and holds the
various sink instances: tool call audit, LLM usage, Planner/Synthesis
context audit, Planner decision audit, Synthesis generation audit, Human
audit) assembles this from whatever it has. Every field defaults to empty
so a caller missing one sink still gets a RunEvaluation back (with the
metrics that sink would have fed simply reading as zero/None), never a
crash.

`tool_call_records` deliberately accepts a plain list rather than requiring
a `ToolCallAuditSink` Protocol: nothing in this codebase threads an
external audit_sink through `ToolExecutionManager` yet (every
`SkillRunner(tool_registry, ToolExecutionManager())` call site keeps its
own internal `InMemoryToolCallAuditSink`, inaccessible from outside), so
Phase 7A's own test wiring aggregates `ModuleState.tool_calls` across
modules as the practical default -- with the same caveat
agent/tools/execution_manager.py's own docstring already states: that
convenience view can under-count a duplicate physical execution lost to
`merge_by_key`'s whole-value overwrite under checkpoint replay. Passing a
real audit sink's full record list here (once one exists) is strictly more
precise and requires no change to RunEvaluator.
"""
from dataclasses import dataclass, field

from agent.llm.context.context_audit import ContextBuildRecord
from agent.llm.context.synthesis_context_audit import SynthesisContextBuildRecord
from agent.llm.models import DecisionSource, LLMCallRecord
from agent.planning.decision_audit import PlannerDecisionRecord
from agent.planning.decision_quality import PlannerDecisionQuality
from agent.state.models import HumanRequest, ToolCallRecord
from agent.synthesis.decision_audit import SynthesisGenerationRecord


@dataclass(frozen=True)
class RunAuditBundle:
    tool_call_records: list[ToolCallRecord] = field(default_factory=list)
    llm_call_records: list[LLMCallRecord] = field(default_factory=list)
    planner_context_records: list[ContextBuildRecord] = field(default_factory=list)
    synthesis_context_records: list[SynthesisContextBuildRecord] = field(default_factory=list)
    planner_decision_records: list[PlannerDecisionRecord] = field(default_factory=list)
    # Optional, precomputed (Phase 5C-3's evaluate_planner_decision_quality)
    # -- retrospective recomputation from a bare PlannerDecisionRecord isn't
    # possible, see PlannerDecisionQualityAggregate's own docstring.
    planner_decision_qualities: list[PlannerDecisionQuality] = field(default_factory=list)
    synthesis_generation_records: list[SynthesisGenerationRecord] = field(default_factory=list)
    human_requests: list[HumanRequest] = field(default_factory=list)
    analyzer_source: DecisionSource | None = None
