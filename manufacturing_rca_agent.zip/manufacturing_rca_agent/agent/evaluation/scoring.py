"""Dimension-score / overall-score helpers (Phase 7A item 3) -- collapse
each Metrics group into one [0,1] number ONLY for `overall_score`
weighting; `RunEvaluation` always keeps the full dimension breakdown too
(never just a bare final number, per the spec's explicit instruction).
This is a first-cut, replaceable formula -- not the one true scoring
function. A caller that disagrees can compute its own summary scores and
build `RunEvaluation.overall_score` differently; nothing downstream
depends on this specific arithmetic.
"""
from agent.state.models import AnalyticalQualityMetrics, DecisionQualityMetrics, DeliveryQualityMetrics, EfficiencyMetrics


def analytical_summary_score(m: AnalyticalQualityMetrics) -> float:
    base = sum(
        [
            m.evidence_coverage, m.confirmed_finding_ratio, m.root_cause_support_score, m.limitation_transparency_score,
            m.unresolved_question_transparency, m.synthesis_fact_consistency, m.cross_module_relation_support_score,
        ]
    ) / 7
    penalty = (m.failed_module_ratio + m.blocked_module_ratio) / 2
    return max(0.0, base - penalty)


def decision_summary_score(m: DecisionQualityMetrics) -> float:
    analyzer_score = m.analyzer.module_selection_validity * (0.5 if m.analyzer.analyzer_fallback_used else 1.0)
    planner_base = m.planner.average_planner_quality if m.planner.average_planner_quality is not None else 1.0
    penalty_events = m.planner.invalid_decision_count + m.planner.fallback_decision_count + m.planner.redundant_target_count + m.planner.unnecessary_deep_dive_count
    planner_score = max(0.0, planner_base - 0.05 * penalty_events)
    return (analyzer_score + planner_score) / 2


def delivery_summary_score(m: DeliveryQualityMetrics) -> float:
    if not m.hallucination_guard_passed:
        return 0.0  # disqualifying, regardless of every other delivery metric
    return sum(
        [m.request_answered_score, m.module_result_coverage, m.root_cause_lineage_validity, m.limitation_preservation, m.task_type_depth_compliance, m.synthesis_status_consistency]
    ) / 6


def efficiency_summary_score(m: EfficiencyMetrics) -> float:
    completion = m.completed_module_count / m.total_module_count if m.total_module_count else 1.0
    trouble = m.failed_tool_execution_count + m.llm_retry_count + m.replay_count
    volume = max(1, m.tool_manager_invocation_count + m.total_llm_calls)
    trouble_ratio = min(1.0, trouble / volume)
    return max(0.0, completion - trouble_ratio)
