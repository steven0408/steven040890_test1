"""RunEvaluator (Phase 7A item 1/12) -- a Harness *service*, deliberately
not a LangGraph node this phase: post-run evaluation needs no routing,
interrupt, retry loop, or Tool execution, so there is nothing a node would
add except graph-topology risk for zero behavioral benefit. If a future
phase wires `Synthesis -> Evaluator -> END` into the parent graph, this
class is the thing that node would call -- see `evaluate()`'s own
read-only contract, already node-safe.

Architecture note (item 15, frozen): **Evaluator judges what happened;
Learning proposes what should be learned.** RunEvaluator never writes a
Skill, never edits Knowledge, never touches a Planner prompt/threshold,
and never persists a "validated pattern" -- it only ever returns a
`RunEvaluation`. A future Learning component (Phase 7C) is the only thing
allowed to read `RunEvaluation`/`EvaluationIssue` and *propose* a
candidate change; even then, "propose" is doing real work -- Learning
still cannot unilaterally rewrite a Skill/Planner/threshold either, per
the existing Capability-Layer onboarding discipline (Phase 5D).

Everything RunEvaluator reads is already-recorded audit data
(`final_state`, `RunAuditBundle`) -- it builds one internal artifact of its
own (`reference_package`, a fresh deterministic Handoff rebuild used only
for comparison, see analytical/delivery_quality_metrics.py) and returns it
nowhere; `final_state`/`ModuleState`/`HandoffPackage` are never mutated
(see tests/test_evaluator_read_only.py's explicit regression).
"""
import itertools
from datetime import datetime, timezone
from typing import Callable

from agent.evaluation.analytical_quality_metrics import compute_analytical_quality_metrics
from agent.evaluation.audit import EvaluationAuditSink, EvaluationRecord
from agent.evaluation.decision_quality_metrics import compute_decision_quality_metrics
from agent.evaluation.delivery_quality_metrics import compute_delivery_quality_metrics
from agent.evaluation.efficiency_metrics import compute_efficiency_metrics
from agent.evaluation.inputs import RunAuditBundle
from agent.evaluation.issues import generate_issues
from agent.evaluation.scoring import analytical_summary_score, decision_summary_score, delivery_summary_score, efficiency_summary_score
from agent.llm.context.synthesis_context import SynthesisContextBuilder
from agent.state.models import EvaluationWeighting, HandoffPackage, RunEvaluation
from agent.state.state import AgentState
from agent.synthesis.handoff_builder import ModuleHandoffBuilder
from agent.synthesis.package import build_handoff_package

EVALUATOR_VERSION = "7A-1"

_evaluation_id_counter = itertools.count(1)


def _build_reference_package(final_state: AgentState) -> HandoffPackage:
    """Fresh deterministic rebuild from `final_state.module_states` --
    reuses the exact Phase 6A/6B pipeline (never a parallel/duplicated
    implementation), used only as an in-memory comparison baseline. Never
    written back anywhere."""
    context_outcome = SynthesisContextBuilder(ModuleHandoffBuilder()).build(final_state)
    return build_handoff_package(context_outcome.context)


class RunEvaluator:
    def __init__(
        self,
        *,
        weighting: EvaluationWeighting | None = None,
        audit_sink: EvaluationAuditSink | None = None,
        now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ):
        self._weighting = weighting
        self._audit_sink = audit_sink
        self._now_fn = now_fn

    def evaluate(self, final_state: AgentState, bundle: RunAuditBundle | None = None) -> RunEvaluation:
        bundle = bundle or RunAuditBundle()
        module_states = list(final_state.module_states.values())

        reference_package = _build_reference_package(final_state)
        actual_package = final_state.synthesis_result if final_state.synthesis_result is not None else reference_package

        efficiency = compute_efficiency_metrics(final_state, bundle)
        analytical = compute_analytical_quality_metrics(module_states, actual_package=actual_package, reference_package=reference_package)
        decision = compute_decision_quality_metrics(final_state, bundle)
        delivery = compute_delivery_quality_metrics(module_states, actual_package=actual_package, reference_package=reference_package)
        issues = generate_issues(module_states, efficiency, analytical, decision, delivery)

        overall_score = None
        if self._weighting is not None:
            overall_score = (
                analytical_summary_score(analytical) * self._weighting.analytical_quality
                + decision_summary_score(decision) * self._weighting.decision_quality
                + delivery_summary_score(delivery) * self._weighting.delivery_quality
                + efficiency_summary_score(efficiency) * self._weighting.efficiency
            )

        evaluated_at = self._now_fn()
        evaluation_id = f"eval-{next(_evaluation_id_counter)}"
        evaluation = RunEvaluation(
            evaluation_id=evaluation_id,
            run_id=final_state.run_id,
            evaluator_version=EVALUATOR_VERSION,
            evaluated_at=evaluated_at,
            efficiency=efficiency,
            analytical_quality=analytical,
            decision_quality=decision,
            delivery_quality=delivery,
            issues=issues,
            weighting=self._weighting,
            overall_score=overall_score,
        )

        if self._audit_sink is not None:
            context_record_count = len(bundle.planner_context_records) + len(bundle.synthesis_context_records)
            self._audit_sink.record(
                EvaluationRecord(
                    evaluation_id=evaluation_id,
                    run_id=final_state.run_id,
                    evaluator_version=EVALUATOR_VERSION,
                    evaluated_at=evaluated_at,
                    metric_source_counts={
                        "tool_call_records": len(bundle.tool_call_records),
                        "llm_call_records": len(bundle.llm_call_records),
                        "planner_decision_records": len(bundle.planner_decision_records),
                        "planner_decision_qualities": len(bundle.planner_decision_qualities),
                        "synthesis_generation_records": len(bundle.synthesis_generation_records),
                        "human_requests": len(bundle.human_requests),
                    },
                    planner_decision_record_ids=[r.decision_record_id for r in bundle.planner_decision_records],
                    synthesis_record_id=bundle.synthesis_generation_records[-1].synthesis_record_id if bundle.synthesis_generation_records else None,
                    tool_audit_record_count=len(bundle.tool_call_records),
                    llm_call_record_count=len(bundle.llm_call_records),
                    context_record_count=context_record_count,
                    human_intervention_count=len(bundle.human_requests),
                )
            )

        return evaluation
