"""compute_delivery_quality_metrics (Phase 7A item 2) -- deterministic
scoring of the *final Handoff* a run actually delivered. Two comparisons
recur here and in analytical_quality_metrics.py: `actual_package` (what
`final_state.synthesis_result` really is, LLM-drafted or deterministic)
against `reference_package` (a fresh deterministic rebuild from the same
`module_states`, via the exact Phase 6A/6B pipeline) -- consistency here is
"did the delivered package agree with the facts", and self-consistency
(`synthesis_status_consistency`) is "does the delivered package agree with
itself".
"""
from agent.evaluation.decision_quality_metrics import SCREENING_DEPTH_ACTIONS
from agent.state.enums import SynthesisOverallStatus, TaskType
from agent.state.models import DeliveryQualityMetrics, HandoffPackage, ModuleState
from agent.synthesis.package import compute_overall_status

_STATUS_ANSWER_SCORE = {SynthesisOverallStatus.COMPLETE: 1.0, SynthesisOverallStatus.PARTIAL: 0.5, SynthesisOverallStatus.FAILED: 0.0}


def _root_cause_lineage_validity(actual: HandoffPackage) -> float:
    if not actual.root_causes:
        return 1.0
    finding_ids = {f.finding_id for f in actual.key_findings}
    scored = [1.0 if set(rc.supporting_finding_ids) & finding_ids else 0.5 for rc in actual.root_causes]
    return sum(scored) / len(scored)


def _task_type_depth_compliance(module_states: list[ModuleState]) -> float:
    if not module_states:
        return 1.0
    compliant = 0
    for module in module_states:
        forbidden = SCREENING_DEPTH_ACTIONS.get(module.goal.task_type)
        if not forbidden or not any(r.action in forbidden for r in module.objective_history.values()):
            compliant += 1
    return compliant / len(module_states)


def compute_delivery_quality_metrics(
    module_states: list[ModuleState], *, actual_package: HandoffPackage, reference_package: HandoffPackage
) -> DeliveryQualityMetrics:
    selected_module_ids = {m.module_id for m in module_states}
    covered_module_ids = {h.module_id for h in actual_package.module_results}
    module_result_coverage = len(covered_module_ids & selected_module_ids) / len(selected_module_ids) if selected_module_ids else 1.0

    task_type = actual_package.task_type
    root_cause_lineage_validity = _root_cause_lineage_validity(actual_package) if task_type == TaskType.RCA else 1.0

    limitation_preservation = 1.0
    reference_limitation_ids = {lim.limitation_id for lim in reference_package.limitations}
    actual_limitation_ids = {lim.limitation_id for lim in actual_package.limitations}
    if reference_limitation_ids:
        limitation_preservation = len(actual_limitation_ids & reference_limitation_ids) / len(reference_limitation_ids)

    synthesis_status_consistency = 1.0 if compute_overall_status(actual_package.module_results) == actual_package.overall_status else 0.0
    hallucination_guard_passed = {rc.root_cause_id for rc in actual_package.root_causes} <= {rc.root_cause_id for rc in reference_package.root_causes}

    return DeliveryQualityMetrics(
        request_answered_score=_STATUS_ANSWER_SCORE[actual_package.overall_status],
        module_result_coverage=module_result_coverage,
        root_cause_lineage_validity=root_cause_lineage_validity,
        limitation_preservation=limitation_preservation,
        task_type_depth_compliance=_task_type_depth_compliance(module_states),
        synthesis_status_consistency=synthesis_status_consistency,
        hallucination_guard_passed=hallucination_guard_passed,
    )
