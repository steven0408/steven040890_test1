"""EvaluationRecord / EvaluationAuditSink (Phase 7A item 11) -- same
"Protocol + InMemory reference impl" pattern as every other audit sink in
this codebase. Traces exactly which audit inputs a given RunEvaluation was
computed from (counts and ids only, never a full prompt or raw secret) --
so a future reader can answer "how many Planner decisions/LLM calls/
context builds fed this evaluation, and which ones specifically".
"""
from datetime import datetime
from typing import Protocol

from agent.state.base import RCABaseModel


class EvaluationRecord(RCABaseModel):
    evaluation_id: str
    run_id: str
    evaluator_version: str
    evaluated_at: datetime
    metric_source_counts: dict[str, int]
    planner_decision_record_ids: list[str]
    synthesis_record_id: str | None
    tool_audit_record_count: int
    llm_call_record_count: int
    context_record_count: int
    human_intervention_count: int


class EvaluationAuditSink(Protocol):
    def record(self, record: EvaluationRecord) -> None: ...

    def list_for_run(self, run_id: str) -> list[EvaluationRecord]: ...


class InMemoryEvaluationAuditSink:
    def __init__(self) -> None:
        self._records: list[EvaluationRecord] = []

    def record(self, record: EvaluationRecord) -> None:
        self._records.append(record)

    def list_for_run(self, run_id: str) -> list[EvaluationRecord]:
        return [r for r in self._records if r.run_id == run_id]
