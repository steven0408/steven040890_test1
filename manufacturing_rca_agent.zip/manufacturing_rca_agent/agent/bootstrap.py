"""Composition root (Phase 5D-10, restructured Phase 8B-1). `AppConfig` is
the pure, serializable (YAML/JSON-shaped) part of production wiring;
*which domains exist and how they're wired* is a `ModulePackageRegistry`
(`agent/modules/`), supplied by the caller or defaulting to
`default_module_package_registry()`:

    AppConfig  +  ModulePackageRegistry
       v
    bootstrap_runtime(config, module_packages=..., llm_client=...)
       +- ModuleRegistry          (one ModuleDefinition per enabled ModulePackage)
       +- SkillRegistry           (config.skill_directories + each package's own skill_directories)
       +- ToolRegistry            (each enabled package's tool_registrations)
       +- ReasoningSkillRetriever (reads SkillRegistry)
       +- CapabilityResolver      (reads SkillRegistry + ToolRegistry)
       +- DataSourceRegistry      (built from config.datasources)
       +- LLMRouter               (reads config.llm_routes + the injected LLMClient)
       +- Audit sinks             (backend chosen by config.persistence)
       +- module_runtime          (dict[str, ModuleRuntimeConfig], ready for build_phase2_graph)

Every failure mode below is a typed exception raised *during this call*,
never discovered mid-run (Phase 5D-11): duplicate tool/skill/module/package
registration, an EXECUTION skill's required tool missing, a malformed
Skill markdown file, a REASONING skill wrongly declaring an executable-
steps contract, an unsupported/unknown module_type in `enabled_modules`,
and a misconfigured DataSource. This module does not invent a new
aggregating exception type -- each layer's own existing typed error
(DuplicateSkillError, MissingToolForSkillError, DataSourceConfigError,
ModulePackageNotFoundError, ...) propagates as-is; the first problem stops
bootstrap.

**Phase 8B-1 invariant**: this file imports nothing OEE-specific --
no `OEEPlanningPolicy`, no OEE Tool class, no `MOCK_EQUIPMENT`. It only
knows the generic `ModulePackage` contract (`agent/modules/models.py`).
A second real domain is a new `ModulePackage`, never a new branch here --
see `tests/test_modules_onboarding.py`'s `DummyYield` fixture for a
worked proof.

Does not rebuild `build_phase2_graph` itself (still in agent/graph/graph.py,
unchanged) -- this module only assembles the inputs that already-existing
builder needs, centralizing wiring that used to be scattered across
tests/conftest.py-style helpers.
"""
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from pydantic import Field

from agent.capability.resolver import CapabilityResolver
from agent.catalog.module_registry import ModuleRegistry
from agent.datasource.models import DataSourceConfig, InMemoryDataSource, build_datasource
from agent.datasource.registry import DataSourceRegistry
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.llm.client import LLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.context.analyzer_context import AnalyzerContextBuilder
from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
from agent.llm.context.context_audit import ContextAuditSink
from agent.llm.context.evidence_selector import DeterministicEvidenceSelector
from agent.llm.context.planner_context import PlannerContextBuilder
from agent.llm.context.reasoning_skill_retriever import DeterministicReasoningSkillRetriever
from agent.llm.router import LLMRouter
from agent.llm.token_budget import LLMContextProfile
from agent.llm.usage import LLMUsageSink
from agent.modules.oee.package import build_oee_module_package
from agent.modules.registry import ModulePackageRegistry
from agent.modules.wb.package import build_wb_module_package
from agent.persistence.factory import PersistenceBackendConfig, PersistenceLayer, build_persistence_layer
from agent.llm.context.reflector_context import ReflectorContextBuilder
from agent.planning.decision_audit import PlannerDecisionAuditSink
from agent.planning.policies.llm import LLMPlanningPolicy
from agent.planning.policies.llm_reflection import LLMReflectionPolicy
from agent.planning.reflection_audit import InMemoryReflectionDecisionAuditSink, ReflectionDecisionAuditSink
from agent.skills.registry import SkillRegistry
from agent.skills.runner import SkillRunner
from agent.state.base import RCABaseModel
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.registry import ToolRegistry


class BootstrapConfigError(ValueError):
    """A config value doesn't correspond to anything the running process
    knows how to build -- e.g. `enabled_modules` names a module_type with
    no built-in ModuleDefinition/ModulePlanningPolicy wiring yet."""


class AppConfig(RCABaseModel):
    """The serializable half of production wiring -- everything here could
    come straight from a YAML/JSON file. No secrets: `datasources`/`llm`
    only ever carry environment-variable *names* (see DataSourceConfig)."""

    factory_id: str
    factory_name: str
    enabled_modules: list[str] = Field(default_factory=lambda: ["OEE"])
    # Phase 8B-1 Part C: NO per-domain skill directory here anymore (there
    # was only ever `skills/oee` -- now owned by the OEE ModulePackage's
    # own `skill_directories` field, unioned in by bootstrap_runtime).
    # `skills/reasoning` stays here because it is genuinely generic --
    # Reasoning Skills like `plant_manager_perspective.md` declare
    # `domains: []` and are not OEE-specific.
    skill_directories: list[str] = Field(
        default_factory=lambda: [str(Path(__file__).resolve().parent / "skills" / "reasoning")]
    )
    datasources: dict[str, DataSourceConfig] = Field(default_factory=dict)
    llm_routes: dict[str, LLMRouteConfig] = Field(
        default_factory=lambda: {
            "analyzer": LLMRouteConfig(route="analyzer", model="claude-haiku-4-5-20251001"),
            "planner": LLMRouteConfig(route="planner", model="claude-haiku-4-5-20251001"),
        }
    )
    # Phase 8B item 14: defaults to the in-memory backend, so every
    # pre-8B caller (nothing sets this field) keeps its exact existing
    # behavior -- see build_persistence_layer().
    persistence: PersistenceBackendConfig = Field(default_factory=PersistenceBackendConfig)


@dataclass(frozen=True)
class RuntimeContext:
    """Not persisted / not a Pydantic model on purpose -- this bundles live
    registries and service objects (not run data), the composition root's
    own output. `module_runtime` is exactly what `build_phase2_graph`
    expects."""

    module_registry: ModuleRegistry
    skill_registry: SkillRegistry
    tool_registry: ToolRegistry
    capability_resolver: CapabilityResolver
    reasoning_skill_retriever: DeterministicReasoningSkillRetriever
    datasource_registry: DataSourceRegistry
    llm_router: LLMRouter
    llm_usage_sink: LLMUsageSink
    context_audit_sink: ContextAuditSink
    decision_audit_sink: PlannerDecisionAuditSink
    analyzer_context_builder: AnalyzerContextBuilder
    persistence_layer: PersistenceLayer
    module_runtime: dict[str, ModuleRuntimeConfig] = field(default_factory=dict)
    # Phase PROD-1.2: previously-flagged gap, closed -- an in-memory-only
    # (not Postgres-backed; that remains a separate, honestly-reported
    # future concern, same as Phase PROD-1's own report noted) sink so a
    # caller can actually inspect "was this round's Reflector decision
    # LLM or FALLBACK" after a run, which nothing exposed before this.
    # None when no "reflector" route is configured (LLMReflectionPolicy
    # itself is never constructed in that case either -- see below).
    reflection_decision_audit_sink: ReflectionDecisionAuditSink | None = None


def default_module_package_registry() -> ModulePackageRegistry:
    """The built-in `ModulePackage` catalog (Phase 8B-1 replacement for
    the old `_default_module_catalog()`/`_register_oee_tools()` pair).
    Adding a genuinely new Module/Domain means registering one more
    `ModulePackage` here (or passing a caller-supplied
    `ModulePackageRegistry` into `bootstrap_runtime`) -- never editing
    `bootstrap_runtime`'s own body. Adding a Skill never does either, see
    docs/architecture.md's invariant."""
    registry = ModulePackageRegistry()
    registry.register(build_oee_module_package())
    registry.register(build_wb_module_package())  # Phase WB-2C -- one more line, never a new branch in bootstrap_runtime itself
    return registry


def bootstrap_runtime(
    config: AppConfig,
    *,
    module_packages: ModulePackageRegistry | None = None,
    llm_client: LLMClient,
    in_memory_datasource_factory: Callable[[DataSourceConfig], InMemoryDataSource] | None = None,
    context_profile: LLMContextProfile | None = None,
) -> RuntimeContext:
    """Fail-fast: every registry/config problem raises before this function
    returns, never mid-run. `llm_client` is required (not defaulted to a
    real provider) so this module never silently constructs a real network
    client -- the caller decides (AnthropicAdapter() for production,
    MockLLMClient(...) for a test double).

    `context_profile` (Phase PROD-1.1): optional, additive -- when given,
    threaded into LLMRouter (the preflight Context Budget guard) and every
    context builder this function constructs (Planner/Reflector/Analyzer),
    so their DEFAULT per-task-type budgets become token-aware automatically
    (see agent/llm/token_budget.py::derive_context_budget). None (default)
    is byte-identical to every pre-PROD-1.1 caller's behavior.

    Phase 8B-1: this function no longer imports or references
    `OEEPlanningPolicy`/any OEE Tool class/`MOCK_EQUIPMENT` -- everything
    domain-specific was moved into `agent/modules/oee/package.py`. This
    function only knows the generic `ModulePackage` contract; a second
    real domain (Yield/Output/WIP) is a new `ModulePackage` registered
    into `module_packages`, never a new `if` branch here.
    """
    packages = module_packages or default_module_package_registry()

    module_registry = ModuleRegistry()
    for module_type in config.enabled_modules:
        try:
            package = packages.get(module_type)
        except Exception as exc:  # ModulePackageNotFoundError
            raise BootstrapConfigError(
                f"enabled_modules names '{module_type}', which has no registered ModulePackage -- "
                "adding a genuinely new module requires registering one (see default_module_package_registry()), "
                "not just config"
            ) from exc
        module_registry.register(package.module_definition)  # raises DuplicateModuleDefinitionError on a conflict

    skill_registry = SkillRegistry()
    for directory in config.skill_directories:
        skill_registry.load_directory(Path(directory))  # raises SkillMarkdownError / DuplicateSkillError / pydantic ValidationError
    for module_type in config.enabled_modules:
        package = packages.get(module_type)
        for directory in package.skill_directories:
            skill_registry.load_directory(directory)

    tool_registry = ToolRegistry()
    for module_type in config.enabled_modules:
        package = packages.get(module_type)
        if package.payload_registrations is not None:
            package.payload_registrations()  # Phase 8B-1 Part F: explicit, not import-time
        package.tool_registrations(tool_registry)
    skill_registry.validate_required_tools(tool_registry)  # raises MissingToolForSkillError

    capability_resolver = CapabilityResolver(skill_registry, tool_registry)
    reasoning_skill_retriever = DeterministicReasoningSkillRetriever(skill_registry)

    datasource_registry = DataSourceRegistry()
    for name, ds_config in config.datasources.items():
        datasource_registry.register(name, build_datasource(ds_config, in_memory_factory=in_memory_datasource_factory))

    # Phase 8B item 14: which concrete sink instances back these three
    # live-audit wiring points (llm_router / planner_context_builder /
    # each module's decision audit, below) is now chosen by
    # `config.persistence.backend` -- InMemory by default, so behavior is
    # byte-identical to before this field existed. This is the actual
    # integration point: `build_phase2_graph` and every LangGraph node are
    # still untouched, only *which sink object* this composition root
    # wires into them changes.
    persistence_layer = build_persistence_layer(config.persistence)
    llm_usage_sink = persistence_layer.audit_repository.llm_usage_sink
    llm_router = LLMRouter(routes=config.llm_routes, client=llm_client, usage_sink=llm_usage_sink, context_profile=context_profile)

    context_audit_sink = persistence_layer.audit_repository.planner_context_sink
    decision_audit_sink = persistence_layer.audit_repository.planner_decision_sink
    analyzer_context_builder = AnalyzerContextBuilder(
        module_registry, reasoning_skill_retriever=reasoning_skill_retriever, context_profile=context_profile
    )

    # Phase 8B-1 Part C: a plain loop over whatever ModulePackages are
    # enabled -- no `if "OEE" in ...:`, no domain name literal. The
    # LLM-augmentation wrapping (`LLMPlanningPolicy`) is a cross-cutting
    # concern every domain gets uniformly, so it stays here rather than
    # inside each ModulePackage's own `policy_factory` (which returns the
    # raw domain policy, e.g. `OEEPlanningPolicy()`).
    planner_context_builder = PlannerContextBuilder(
        DeterministicEvidenceSelector(),
        DeterministicCapabilityRetriever(skill_registry),
        audit_sink=context_audit_sink,
        reasoning_skill_retriever=reasoning_skill_retriever,
        context_profile=context_profile,
    )
    # Phase PROD-1: whether the injected `llm_router` was actually built
    # with a "reflector" route is the one signal this composition root has
    # for "is real Reflector reasoning configured" -- LLMReflectionPolicy's
    # own `.call(route="reflector", ...)` would otherwise raise a routing
    # error on the very first reflection. Wrapping is purely additive
    # composition (an already-built, already-tested policy from Phase
    # WB-3F, not a Reflector redesign): when no "reflector" route exists
    # (every pre-PROD-1 caller/test), `policy` stays bare `LLMPlanningPolicy`
    # exactly as before -- byte-identical behavior, zero regression risk.
    reflector_context_builder = ReflectorContextBuilder(reasoning_skill_retriever=reasoning_skill_retriever, context_profile=context_profile)
    has_reflector_route = "reflector" in config.llm_routes
    # Phase PROD-1.2: closes the gap the Phase PROD-1 report itself
    # flagged -- an in-memory-only ReflectionDecisionAuditSink (not
    # Postgres-backed; a separate, still-honestly-open concern) so a
    # caller can inspect `source`/`fallback_reason` for every Reflector
    # decision after a run, same as `decision_audit_sink` already lets a
    # caller do for Planner. Only constructed when there is a real
    # LLMReflectionPolicy to record from.
    reflection_decision_audit_sink = InMemoryReflectionDecisionAuditSink() if has_reflector_route else None

    module_runtime: dict[str, ModuleRuntimeConfig] = {}
    for module_type in config.enabled_modules:
        package = packages.get(module_type)
        planner_policy = LLMPlanningPolicy(
            package.policy_factory(), planner_context_builder, llm_router, skill_registry, decision_audit_sink=decision_audit_sink
        )
        policy = (
            LLMReflectionPolicy(planner_policy, reflector_context_builder, llm_router, decision_audit_sink=reflection_decision_audit_sink)
            if has_reflector_route else planner_policy
        )
        module_runtime[module_type] = ModuleRuntimeConfig(
            policy=policy,
            capability=ModuleCapabilityRuntime(capability_resolver=capability_resolver, skill_runner=SkillRunner(tool_registry, ToolExecutionManager())),
            budget=package.budget,
        )

    return RuntimeContext(
        module_registry=module_registry,
        skill_registry=skill_registry,
        tool_registry=tool_registry,
        capability_resolver=capability_resolver,
        reasoning_skill_retriever=reasoning_skill_retriever,
        datasource_registry=datasource_registry,
        llm_router=llm_router,
        llm_usage_sink=llm_usage_sink,
        context_audit_sink=context_audit_sink,
        decision_audit_sink=decision_audit_sink,
        analyzer_context_builder=analyzer_context_builder,
        persistence_layer=persistence_layer,
        module_runtime=module_runtime,
        reflection_decision_audit_sink=reflection_decision_audit_sink,
    )
