"""DataSourceRegistry -- same "name -> instance, typed duplicate/missing
errors" shape as ToolRegistry/SkillRegistry/ModuleRegistry (Phase 5D-8).
"""
from agent.datasource.models import DataSource


class DuplicateDataSourceError(ValueError):
    pass


class DataSourceNotFoundError(KeyError):
    pass


class DataSourceRegistry:
    def __init__(self) -> None:
        self._sources: dict[str, DataSource] = {}

    def register(self, name: str, source: DataSource) -> None:
        if name in self._sources:
            raise DuplicateDataSourceError(f"datasource '{name}' is already registered")
        self._sources[name] = source

    def get(self, name: str) -> DataSource:
        source = self._sources.get(name)
        if source is None:
            raise DataSourceNotFoundError(f"no datasource registered with name '{name}'")
        return source

    def names(self) -> list[str]:
        return list(self._sources.keys())
