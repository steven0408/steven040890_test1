"""DataSource integration boundary (Phase 5D-8) -- lets a future Tool
depend on an abstract `DataSource` contract instead of a hardcoded
connection string/host/password, so a real manufacturing DB (deployed on a
different host, per this phase's spec) can be plugged in later purely
through config + a new adapter class, without touching any Tool that
already depends on this Protocol.

Deliberately NOT connected to anything real this phase -- `InMemoryDataSource`
is the only working implementation; `build_datasource` validates a remote
config's shape/env-vars and then raises `DataSourceNotConnectedError`
(never attempts a network call). See docs/architecture.md's "How to connect
a real DB later" section for where a real adapter plugs in.
"""
import os
from enum import Enum
from typing import Callable, Protocol

from pydantic import Field, JsonValue

from agent.state.base import RCABaseModel


class DataSourceType(str, Enum):
    IN_MEMORY = "in_memory"  # the only type with a real, working adapter this phase
    REMOTE_SQL = "remote_sql"
    REST_API = "rest_api"
    INTERNAL_SERVICE = "internal_service"
    RPC = "rpc"


class DataSourceConfig(RCABaseModel):
    """Conceptual shape of one `datasources.<name>` entry in AppConfig (see
    agent/bootstrap.py) -- mirrors the spec's example:

        datasources:
          manufacturing_db:
            type: remote_sql
            endpoint_env: MANUFACTURING_DB_ENDPOINT
            credential_env: MANUFACTURING_DB_TOKEN

    Never a literal host/connection-string/password field on this model --
    only the *name* of the environment variable that would hold one at
    deploy time. `options` is for adapter-specific non-secret settings
    (e.g. a REST API's request timeout)."""

    name: str
    type: DataSourceType
    endpoint_env: str | None = None
    credential_env: str | None = None
    options: dict[str, str] = Field(default_factory=dict)


class DataSourceConfigError(RuntimeError):
    """A DataSourceConfig is unusable as declared -- a required env var
    name wasn't given, or the env var it names isn't actually set in this
    process. Raised at bootstrap/adapter-construction time, never
    discovered mid-run."""


class DataSourceNotConnectedError(NotImplementedError):
    """Raised by `build_datasource` for every non-IN_MEMORY type this
    phase: the config/env-var boundary is real and validated, but no
    concrete remote adapter has been implemented (and none should be --
    see the Phase 5D scope guard: no real DB connection this phase)."""


class DataSourceQuery(RCABaseModel):
    """What a Tool asks a DataSource for -- a named query plus parameters,
    never a raw SQL string or connection detail. A future `remote_sql`
    adapter would map `query_name` to a prepared statement/stored
    procedure server-side, exactly the same way `InMemoryDataSource` maps
    it to a registered callable here."""

    query_name: str
    parameters: dict[str, JsonValue] = Field(default_factory=dict)


class DataSourceQueryResult(RCABaseModel):
    rows: list[dict[str, JsonValue]] = Field(default_factory=list)
    metadata: dict[str, JsonValue] = Field(default_factory=dict)


class DataSource(Protocol):
    def query(self, request: DataSourceQuery) -> DataSourceQueryResult: ...


class DataSourceQueryNotRegisteredError(KeyError):
    pass


class InMemoryDataSource:
    """The only working `DataSource` implementation this phase -- backs a
    named query by a plain Python callable over in-process data (e.g. the
    existing MOCK_EQUIPMENT list). Real Tools can be written against the
    `DataSource` Protocol today and keep working unchanged once a real
    `remote_sql`/`rest_api` adapter is dropped in later (see
    docs/architecture.md)."""

    def __init__(self, handlers: dict[str, Callable[[dict[str, JsonValue]], list[dict[str, JsonValue]]]]):
        self._handlers = handlers

    def query(self, request: DataSourceQuery) -> DataSourceQueryResult:
        handler = self._handlers.get(request.query_name)
        if handler is None:
            raise DataSourceQueryNotRegisteredError(f"no query handler registered for '{request.query_name}'")
        return DataSourceQueryResult(rows=handler(request.parameters))


def _resolve_env(config: DataSourceConfig, *, field_name: str, env_var: str | None) -> str:
    if env_var is None:
        raise DataSourceConfigError(f"datasource '{config.name}' (type={config.type.value}) has no {field_name} configured")
    value = os.environ.get(env_var)
    if not value:
        raise DataSourceConfigError(
            f"datasource '{config.name}' requires environment variable '{env_var}' (for {field_name}) to be set, but it is not"
        )
    return value


def build_datasource(config: DataSourceConfig, *, in_memory_factory: Callable[[DataSourceConfig], InMemoryDataSource] | None = None) -> DataSource:
    """Composition-root-facing factory (Phase 5D-10 wires this in). For
    IN_MEMORY, delegates to `in_memory_factory` (the caller supplies the
    actual handlers -- this module has no domain data of its own). For
    every remote type, validates `endpoint_env`/`credential_env` actually
    resolve (typed DataSourceConfigError if not) and then deliberately
    stops there -- see DataSourceNotConnectedError."""
    if config.type == DataSourceType.IN_MEMORY:
        if in_memory_factory is None:
            raise DataSourceConfigError(f"datasource '{config.name}' is type=in_memory but no in_memory_factory was provided")
        return in_memory_factory(config)

    _resolve_env(config, field_name="endpoint", env_var=config.endpoint_env)
    if config.credential_env is not None:
        _resolve_env(config, field_name="credential", env_var=config.credential_env)

    raise DataSourceNotConnectedError(
        f"datasource '{config.name}' (type={config.type.value}) is config-valid but no real adapter is implemented "
        "this phase -- see docs/architecture.md's 'How to connect a real DB later' section for where one plugs in"
    )
