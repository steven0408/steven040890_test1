"""LearningCandidateGenerator (Phase 7C item 1) -- the top-level entrypoint,
mirroring `RunEvaluator`'s own shape (Phase 7A): a plain Harness service,
not a LangGraph node (post-run analysis needs no routing/interrupt/retry).

`generate()` is the one method this whole package exposes for producing
candidates, and it is the load-bearing point for the Phase 7C invariant:
every candidate it returns has `status=LearningCandidateStatus.CANDIDATE`
-- this module never imports `LearningCandidateStatus.VALIDATED`, and nor
does any generator it calls (grep-verified, see
tests/test_learning_promotion_boundary.py).

Read-only upstream guarantee (item 20): only ever reads
`list[LearningRunSnapshot]` (already-built projections, see
agent/learning/snapshot.py) and writes candidates via `LearningCandidateSink`
-- never touches AgentState/ModuleState/HandoffPackage/RunEvaluation/
HumanFeedback/Skills/KnowledgeRetriever/PlannerPolicy.
"""
from datetime import datetime, timezone
from typing import Callable

from agent.learning.confidence import CandidateConfidenceScorer, TieredCandidateConfidenceScorer
from agent.learning.generators.capability_gap import generate_capability_gap_candidates
from agent.learning.generators.knowledge_pattern import generate_knowledge_pattern_candidates
from agent.learning.generators.planning_strategy import generate_planning_strategy_candidates
from agent.learning.generators.reasoning_skill import generate_reasoning_skill_candidates
from agent.learning.merger import CandidateMerger
from agent.learning.signals import LearningEvidenceLink
from agent.learning.sink import LearningCandidateSink
from agent.learning.snapshot import LearningRunSnapshot
from agent.state.models import LearningCandidate


class LearningCandidateGenerator:
    def __init__(
        self,
        *,
        confidence_scorer: CandidateConfidenceScorer | None = None,
        candidate_sink: LearningCandidateSink | None = None,
        now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ):
        self._scorer = confidence_scorer or TieredCandidateConfidenceScorer()
        self._sink = candidate_sink
        self._now_fn = now_fn
        self._merger = CandidateMerger(self._scorer)

    def generate(self, snapshots: list[LearningRunSnapshot]) -> list[LearningCandidate]:
        candidates: list[LearningCandidate] = []
        links: list[LearningEvidenceLink] = []

        for generate_fn in (
            generate_knowledge_pattern_candidates,
            generate_planning_strategy_candidates,
            generate_capability_gap_candidates,
            generate_reasoning_skill_candidates,
        ):
            batch_candidates, batch_links = generate_fn(snapshots, self._scorer, now_fn=self._now_fn)
            candidates.extend(batch_candidates)
            links.extend(batch_links)

        if self._sink is None:
            return candidates

        return self._merger.merge_into_sink(self._sink, candidates, links, now_fn=self._now_fn)
