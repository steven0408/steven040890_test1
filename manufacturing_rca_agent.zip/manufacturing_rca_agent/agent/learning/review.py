"""CandidateReview (Phase 7C item 18) -- contract only, no UI, no service.
A future human-review workflow would record one of these per reviewer
decision on a LearningCandidate; nothing in this codebase constructs or
consumes one yet.
"""
from datetime import datetime

from agent.state.base import RCABaseModel
from agent.state.enums import CandidateReviewDecision


class CandidateReview(RCABaseModel):
    review_id: str
    candidate_id: str
    reviewer: str
    decision: CandidateReviewDecision
    comment: str | None = None
    reviewed_at: datetime
