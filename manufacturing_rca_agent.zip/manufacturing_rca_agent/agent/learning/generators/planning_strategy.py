"""generate_planning_strategy_candidates (Phase 7C item 10) -- compares
observed Planner "strategies" (`LearningRunSnapshot.planner_summary.
strategy_label`, item 10's own example: "maintenance-history analysis" vs.
"generic equipment detail") for the same (module scope, TaskType), and
proposes a candidate when one strategy reached a confirmed root cause in
noticeably fewer objectives without a quality drop, across at least two
runs per strategy. Never touches Planner priority/policy itself --
proposal only.
"""
import itertools
from collections import defaultdict
from datetime import datetime, timezone
from statistics import mean
from typing import Callable

from agent.learning.candidate_key import planning_strategy_key
from agent.learning.confidence import CandidateConfidenceScorer
from agent.learning.signals import LearningEvidenceLink
from agent.learning.snapshot import LearningRunSnapshot
from agent.state.enums import LearningCandidateStatus, LearningCandidateType, LearningDestination, LearningSignalType
from agent.state.models import LearningCandidate

_MIN_RUNS_PER_STRATEGY = 2
_QUALITY_TOLERANCE = 0.05  # a "comparable or better" quality band, not stricter-or-equal
_link_id_counter = itertools.count(1)
_candidate_id_counter = itertools.count(1)


def generate_planning_strategy_candidates(
    snapshots: list[LearningRunSnapshot],
    scorer: CandidateConfidenceScorer,
    *,
    now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
) -> tuple[list[LearningCandidate], list[LearningEvidenceLink]]:
    groups: dict[tuple[str, str], dict[str, list[LearningRunSnapshot]]] = defaultdict(lambda: defaultdict(list))
    for snap in snapshots:
        if not snap.root_causes or snap.planner_summary.strategy_label is None:
            continue  # only runs that actually succeeded, with a known strategy, are comparable
        scope = "|".join(sorted(snap.module_types))
        groups[(scope, snap.task_type.value)][snap.planner_summary.strategy_label].append(snap)

    candidates: list[LearningCandidate] = []
    links: list[LearningEvidenceLink] = []

    for (scope, task_type_value), by_strategy in groups.items():
        eligible = {label: snaps for label, snaps in by_strategy.items() if len(snaps) >= _MIN_RUNS_PER_STRATEGY}
        if len(eligible) < 2:
            continue  # need at least two comparably-observed strategies

        stats = {
            label: (mean(s.planner_summary.objective_count for s in snaps), mean(s.evaluation_summary.analytical_quality_score for s in snaps), snaps)
            for label, snaps in eligible.items()
        }
        best_label = min(stats, key=lambda label: stats[label][0])
        best_count, best_quality, best_snaps = stats[best_label]

        for other_label, (other_count, other_quality, other_snaps) in stats.items():
            if other_label == best_label:
                continue
            if not (best_count < other_count and best_quality >= other_quality - _QUALITY_TOLERANCE):
                continue

            candidate_id = f"cand-ps-{next(_candidate_id_counter)}"
            key = planning_strategy_key(scope, task_type_value, f"{best_label}_over_{other_label}")

            candidate_links = [
                LearningEvidenceLink(
                    link_id=f"link-{next(_link_id_counter)}", candidate_id=candidate_id, signal_type=LearningSignalType.EFFICIENCY_IMPROVEMENT,
                    source_run_id=s.run_id, supports=True, strength=0.7, note=f"{best_label}: {s.planner_summary.objective_count} objective(s) to a confirmed root cause",
                )
                for s in best_snaps
            ]
            candidate_links += [
                LearningEvidenceLink(
                    link_id=f"link-{next(_link_id_counter)}", candidate_id=candidate_id, signal_type=LearningSignalType.CONFIRMED_ROOT_CAUSE,
                    source_run_id=s.run_id, supports=True, strength=0.6, note=f"{other_label}: {s.planner_summary.objective_count} objective(s), used for comparison",
                )
                for s in other_snaps
            ]

            confidence = scorer.score(candidate_links)
            statement = (
                f"For {scope} ({task_type_value}), '{best_label}' reached a confirmed root cause in {best_count:.1f} objective(s) on average "
                f"vs. '{other_label}' at {other_count:.1f}, with comparable analytical quality ({best_quality:.2f} vs. {other_quality:.2f})."
            )

            candidates.append(
                LearningCandidate(
                    candidate_id=candidate_id, candidate_type=LearningCandidateType.PLANNING_STRATEGY,
                    title=f"Prefer '{best_label}' over '{other_label}' for {scope}", statement=statement,
                    status=LearningCandidateStatus.CANDIDATE, confidence=confidence,
                    source_run_ids=sorted({s.run_id for s in best_snaps + other_snaps}), source_module_ids=scope.split("|"),
                    supporting_signal_count=len(best_snaps), contradicting_signal_count=0,
                    created_at=now_fn(), updated_at=now_fn(), scope=scope, proposed_destination=LearningDestination.PLANNER_STRATEGY,
                    candidate_key=key, rationale_summary=f"Lower average objective count ({best_count:.1f} vs {other_count:.1f}) with no quality regression across {len(best_snaps)} run(s).",
                )
            )
            links.extend(candidate_links)

    return candidates, links
