"""generate_knowledge_pattern_candidates (Phase 7C item 7) -- conservative,
deterministic cross-module co-occurrence discovery. Relation wording is
always "associated with"/"co-occurs with"/"may indicate" -- never "causes"
-- unless the source data already carries a CONFIRMED_CAUSAL
CrossModuleRelation (which this generator never constructs itself; that
relation type's own pydantic validator requires supporting_finding_ids
regardless, see agent/state/models.py).

Contradiction (item 13): for a given (anchor module+pattern), if
different runs report a DIFFERENT paired pattern on the same other
module, the majority pairing becomes the candidate and the minority runs
become CONTRADICTING_FINDING evidence against it -- the candidate is not
suppressed, only less confident.
"""
import itertools
from collections import defaultdict
from datetime import datetime, timezone
from typing import Callable

from agent.learning.candidate_key import knowledge_pattern_key
from agent.learning.confidence import CandidateConfidenceScorer
from agent.learning.snapshot import LearningRunSnapshot
from agent.learning.signals import LearningEvidenceLink
from agent.state.enums import LearningCandidateStatus, LearningCandidateType, LearningDestination, LearningSignalType
from agent.state.models import LearningCandidate

_MIN_RUNS_FOR_PATTERN = 2
_link_id_counter = itertools.count(1)
_candidate_id_counter = itertools.count(1)


def generate_knowledge_pattern_candidates(
    snapshots: list[LearningRunSnapshot],
    scorer: CandidateConfidenceScorer,
    *,
    now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
) -> tuple[list[LearningCandidate], list[LearningEvidenceLink]]:
    # (anchor_module, anchor_pattern, other_module) -> {other_pattern: {run_id, ...}}
    observations: dict[tuple[str, str, str], dict[str, set[str]]] = defaultdict(lambda: defaultdict(set))
    finding_lookup: dict[tuple[str, str, str], str] = {}  # (run_id, module_type, pattern) -> finding_id

    for snap in snapshots:
        items: dict[tuple[str, str], str] = {}
        for f in snap.confirmed_findings:
            items.setdefault((f.module_type, f.pattern), f.finding_id)
            finding_lookup[(snap.run_id, f.module_type, f.pattern)] = f.finding_id
        keys = list(items.keys())
        for a in keys:
            for b in keys:
                if a[0] == b[0]:
                    continue
                observations[(a[0], a[1], b[0])][b[1]].add(snap.run_id)

    candidates: list[LearningCandidate] = []
    links: list[LearningEvidenceLink] = []

    for (anchor_module, anchor_pattern, other_module), pattern_runs in observations.items():
        if anchor_module >= other_module:
            continue  # avoid emitting both (A,B) and (B,A) for the same pair

        majority_pattern, majority_runs = max(pattern_runs.items(), key=lambda kv: len(kv[1]))
        if len(majority_runs) < _MIN_RUNS_FOR_PATTERN:
            continue

        contradicting_runs: set[str] = set()
        for pattern, runs in pattern_runs.items():
            if pattern != majority_pattern:
                contradicting_runs |= runs

        candidate_id = f"cand-kp-{next(_candidate_id_counter)}"
        scope = "|".join(sorted([anchor_module, other_module]))
        anchor_label, other_label = f"{anchor_module}:{anchor_pattern}", f"{other_module}:{majority_pattern}"
        key = knowledge_pattern_key(scope, (anchor_label, other_label))

        candidate_links = [
            LearningEvidenceLink(
                link_id=f"link-{next(_link_id_counter)}", candidate_id=candidate_id, signal_type=LearningSignalType.REPEATED_PATTERN,
                source_run_id=run_id, supports=True, strength=0.8, note=f"co-occurrence: {anchor_label} with {other_label}",
            )
            for run_id in sorted(majority_runs)
        ]
        candidate_links += [
            LearningEvidenceLink(
                link_id=f"link-{next(_link_id_counter)}", candidate_id=candidate_id, signal_type=LearningSignalType.CONTRADICTING_FINDING,
                source_run_id=run_id, supports=False, strength=0.8, note=f"{anchor_label} observed without {other_label} in this run",
            )
            for run_id in sorted(contradicting_runs)
        ]

        supporting_finding_ids = sorted(
            {finding_lookup[(rid, anchor_module, anchor_pattern)] for rid in majority_runs}
            | {finding_lookup[(rid, other_module, majority_pattern)] for rid in majority_runs}
        )

        confidence = scorer.score(candidate_links)
        total_runs = len(majority_runs) + len(contradicting_runs)
        statement = f"{anchor_label} may be associated with {other_label} (co-occurs in {len(majority_runs)} of {total_runs} observed run(s))."

        candidates.append(
            LearningCandidate(
                candidate_id=candidate_id, candidate_type=LearningCandidateType.KNOWLEDGE_PATTERN,
                title=f"{anchor_module}/{other_module} association candidate", statement=statement,
                status=LearningCandidateStatus.CANDIDATE, confidence=confidence,
                source_run_ids=sorted(majority_runs | contradicting_runs), source_module_ids=sorted([anchor_module, other_module]),
                supporting_finding_ids=supporting_finding_ids, supporting_signal_count=len(majority_runs),
                contradicting_signal_count=len(contradicting_runs), created_at=now_fn(), updated_at=now_fn(),
                scope=scope, proposed_destination=LearningDestination.KNOWLEDGE_BASE, candidate_key=key,
                rationale_summary=(
                    f"Repeated cross-module co-occurrence across {len(majority_runs)} independent run(s)"
                    + (f"; {len(contradicting_runs)} contradicting run(s) observed." if contradicting_runs else ".")
                ),
            )
        )
        links.extend(candidate_links)

    return candidates, links
