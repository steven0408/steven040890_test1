"""generate_reasoning_skill_candidates (Phase 7C item 12) -- a
USER_PREFERENCE / delivery-presentation signal, never domain causal
knowledge: consistently positive human feedback (helpful/recommendation-
useful) on runs where a given reasoning skill was active proposes a
`REASONING_SKILL` candidate whose `proposed_destination` is
`LearningDestination.REASONING_SKILL`, never `KNOWLEDGE_BASE` -- this
generator never writes to validated domain Knowledge.
"""
import itertools
from collections import defaultdict
from datetime import datetime, timezone
from typing import Callable

from agent.learning.candidate_key import reasoning_skill_key
from agent.learning.confidence import CandidateConfidenceScorer
from agent.learning.signals import LearningEvidenceLink
from agent.learning.snapshot import LearningRunSnapshot
from agent.state.enums import LearningCandidateStatus, LearningCandidateType, LearningDestination, LearningSignalType
from agent.state.models import LearningCandidate

_MIN_RUNS_FOR_PATTERN = 2
_POSITIVE_RATE_THRESHOLD = 0.7
_link_id_counter = itertools.count(1)
_candidate_id_counter = itertools.count(1)


def _is_positive(snapshot: LearningRunSnapshot) -> bool:
    summary = snapshot.feedback_summary
    if summary is None:
        return False
    rates = [r for r in (summary.helpful_rate, summary.recommendation_useful_rate) if r is not None]
    return bool(rates) and max(rates) >= _POSITIVE_RATE_THRESHOLD


def generate_reasoning_skill_candidates(
    snapshots: list[LearningRunSnapshot],
    scorer: CandidateConfidenceScorer,
    *,
    now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
) -> tuple[list[LearningCandidate], list[LearningEvidenceLink]]:
    by_skill: dict[str, list[LearningRunSnapshot]] = defaultdict(list)
    for snap in snapshots:
        for skill_id in snap.active_reasoning_skill_ids:
            by_skill[skill_id].append(snap)

    candidates: list[LearningCandidate] = []
    links: list[LearningEvidenceLink] = []

    for skill_id, snaps in by_skill.items():
        positive_snaps = [s for s in snaps if _is_positive(s)]
        if len(positive_snaps) < _MIN_RUNS_FOR_PATTERN:
            continue

        scope = "|".join(sorted({m for s in positive_snaps for m in s.module_types})) or "global"
        candidate_id = f"cand-rs-{next(_candidate_id_counter)}"
        key = reasoning_skill_key(scope, skill_id)

        candidate_links = [
            LearningEvidenceLink(
                link_id=f"link-{next(_link_id_counter)}", candidate_id=candidate_id, signal_type=LearningSignalType.HUMAN_PREFERENCE,
                source_run_id=s.run_id, supports=True, strength=0.5,
                note=f"helpful_rate={s.feedback_summary.helpful_rate}, recommendation_useful_rate={s.feedback_summary.recommendation_useful_rate}",
            )
            for s in positive_snaps
        ]
        confidence = scorer.score(candidate_links)
        statement = (
            f"Reasoning skill '{skill_id}' received consistently positive human feedback across {len(positive_snaps)} run(s) -- "
            "presentation may benefit from this framing (a delivery/audience preference, not a domain causal claim)."
        )

        candidates.append(
            LearningCandidate(
                candidate_id=candidate_id, candidate_type=LearningCandidateType.REASONING_SKILL,
                title=f"Reasoning skill preference: {skill_id}", statement=statement,
                status=LearningCandidateStatus.CANDIDATE, confidence=confidence,
                source_run_ids=sorted({s.run_id for s in positive_snaps}), source_module_ids=sorted({m for s in positive_snaps for m in s.module_types}),
                supporting_signal_count=len(positive_snaps), contradicting_signal_count=0, created_at=now_fn(), updated_at=now_fn(),
                scope=scope, proposed_destination=LearningDestination.REASONING_SKILL, candidate_key=key,
                rationale_summary=f"Positive human feedback (helpful/recommendation-useful) on {len(positive_snaps)} run(s) using this reasoning skill.",
            )
        )
        links.extend(candidate_links)

    return candidates, links
