"""generate_capability_gap_candidates (Phase 7C item 11) -- aggregates
`SnapshotCapabilityGap` entries (derived from `Limitation.related_error.
error_type == CAPABILITY_NOT_FOUND`, see agent/learning/snapshot.py) by
(module_type, requested_action). Unlike knowledge-pattern/planning-strategy
candidates, a single run is enough to propose one (item 9 explicitly
allows CAPABILITY_GAP as a single-run candidate type) -- but confidence
still scales with how many independent runs hit the same gap, via the
same `CandidateConfidenceScorer` every other generator uses. Never
generates Tool code -- only a structured description of what's missing.
"""
import itertools
from collections import defaultdict
from datetime import datetime, timezone
from typing import Callable

from agent.learning.candidate_key import capability_gap_key
from agent.learning.confidence import CandidateConfidenceScorer
from agent.learning.signals import LearningEvidenceLink
from agent.learning.snapshot import LearningRunSnapshot
from agent.state.enums import LearningCandidateStatus, LearningCandidateType, LearningDestination, LearningSignalType
from agent.state.models import LearningCandidate

_link_id_counter = itertools.count(1)
_candidate_id_counter = itertools.count(1)


def generate_capability_gap_candidates(
    snapshots: list[LearningRunSnapshot],
    scorer: CandidateConfidenceScorer,
    *,
    now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
) -> tuple[list[LearningCandidate], list[LearningEvidenceLink]]:
    groups: dict[tuple[str, str], list[tuple[str, str]]] = defaultdict(list)  # (module_type, action) -> [(run_id, description), ...]
    for snap in snapshots:
        for gap in snap.capability_gaps:
            groups[(gap.module_type, gap.requested_action)].append((snap.run_id, gap.description))

    candidates: list[LearningCandidate] = []
    links: list[LearningEvidenceLink] = []

    for (module_type, action), occurrences in groups.items():
        run_ids = sorted({run_id for run_id, _ in occurrences})
        candidate_id = f"cand-cg-{next(_candidate_id_counter)}"
        key = capability_gap_key(module_type, action)

        candidate_links = [
            LearningEvidenceLink(
                link_id=f"link-{next(_link_id_counter)}", candidate_id=candidate_id, signal_type=LearningSignalType.CAPABILITY_NOT_FOUND,
                source_run_id=run_id, supports=True, strength=0.6, note=description,
            )
            for run_id, description in occurrences
        ]
        confidence = scorer.score(candidate_links)
        statement = f"{module_type} repeatedly requires a '{action}' capability that is not currently registered ({len(occurrences)} occurrence(s) across {len(run_ids)} run(s))."

        candidates.append(
            LearningCandidate(
                candidate_id=candidate_id, candidate_type=LearningCandidateType.CAPABILITY_GAP,
                title=f"Missing capability: {module_type}/{action}", statement=statement,
                status=LearningCandidateStatus.CANDIDATE, confidence=confidence,
                source_run_ids=run_ids, source_module_ids=[module_type], supporting_signal_count=len(occurrences),
                contradicting_signal_count=0, created_at=now_fn(), updated_at=now_fn(), scope=module_type,
                proposed_destination=LearningDestination.CAPABILITY_BACKLOG, candidate_key=key,
                rationale_summary=f"Observed {len(occurrences)} time(s) across {len(run_ids)} run(s); no Tool/Skill currently resolves this action.",
            )
        )
        links.extend(candidate_links)

    return candidates, links
