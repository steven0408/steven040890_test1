"""LearningRunSnapshot (Phase 7C item 8) -- Learning's own "Full State !=
Context" projection, the same discipline PlannerContext (Phase 5C-1) and
ModuleHandoff (Phase 6A) already established. Learning never reads a raw
AgentState/ModuleState -- only this bounded projection, built once per run
by `build_learning_run_snapshot`.
"""
from pydantic import Field

from agent.evaluation.scoring import analytical_summary_score, decision_summary_score, delivery_summary_score, efficiency_summary_score
from agent.feedback.aggregator import HumanFeedbackSummary
from agent.state.base import RCABaseModel
from agent.state.enums import ErrorType, FindingStatus, ObjectiveStatus, TaskType
from agent.state.models import ModuleState, RunEvaluation
from agent.state.state import AgentState


class SnapshotFinding(RCABaseModel):
    finding_id: str
    module_id: str
    module_type: str
    statement: str
    pattern: str
    entity_ids: list[str]
    confidence: float
    is_root_cause: bool


class SnapshotRootCause(RCABaseModel):
    root_cause_id: str
    module_id: str
    module_type: str
    statement: str
    entity_ids: list[str]
    confidence: float


class SnapshotCapabilityGap(RCABaseModel):
    module_type: str
    requested_action: str
    description: str
    occurrence_count: int = 1


class SnapshotPlannerSummary(RCABaseModel):
    total_decisions: int
    fallback_decisions: int
    objective_count: int
    unnecessary_deep_dive_count: int
    # A free-text label for "which approach was taken" (e.g. the action of
    # the first post-screening objective) -- not tied to ObjectiveAction's
    # closed enum, since a strategy distinction (item 10's own example,
    # "maintenance-history analysis" vs. "generic equipment detail") may
    # not correspond to a capability that exists in this domain yet.
    strategy_label: str | None = None


class SnapshotEvaluationSummary(RCABaseModel):
    analytical_quality_score: float
    decision_quality_score: float
    delivery_quality_score: float
    efficiency_score: float
    overall_score: float | None


class LearningRunSnapshot(RCABaseModel):
    run_id: str
    factory_id: str
    module_types: list[str]
    task_type: TaskType
    confirmed_findings: list[SnapshotFinding]
    root_causes: list[SnapshotRootCause]
    evaluation_summary: SnapshotEvaluationSummary
    feedback_summary: HumanFeedbackSummary | None = None
    planner_summary: SnapshotPlannerSummary
    capability_gaps: list[SnapshotCapabilityGap]
    # Which reasoning skill(s) (if any) shaped this run's Synthesis --
    # needed for the REASONING_SKILL candidate generator to group runs by
    # "which framing got positive feedback" (item 12). Nothing upstream
    # tracks this end-to-end yet, so it defaults to [] and must be supplied
    # explicitly by a caller that knows (e.g. from SynthesisContext.
    # relevant_reasoning_skills at generation time).
    active_reasoning_skill_ids: list[str] = Field(default_factory=list)


def _module_capability_gaps(module_state: ModuleState) -> list[SnapshotCapabilityGap]:
    gaps = []
    for lim in module_state.limitations:
        if lim.related_error is None or lim.related_error.error_type != ErrorType.CAPABILITY_NOT_FOUND:
            continue
        record = module_state.objective_history.get(lim.impacted_objective_id)
        action = record.action.value if record is not None else "unknown"
        gaps.append(SnapshotCapabilityGap(module_type=module_state.module_type, requested_action=action, description=lim.description))
    return gaps


def _strategy_label(module_state: ModuleState) -> str | None:
    completed = sorted(
        (r for r in module_state.objective_history.values() if r.status == ObjectiveStatus.COMPLETED), key=lambda r: r.created_step
    )
    if len(completed) < 2:
        return None
    return completed[1].action.value  # the action taken right after the first (typically screening) objective


def build_learning_run_snapshot(
    final_state: AgentState,
    evaluation: RunEvaluation,
    *,
    feedback_summary: HumanFeedbackSummary | None = None,
    active_reasoning_skill_ids: list[str] | None = None,
) -> LearningRunSnapshot:
    modules = list(final_state.module_states.values())

    confirmed_findings = [
        SnapshotFinding(
            finding_id=f.finding_id, module_id=m.module_id, module_type=m.module_type, statement=f.statement,
            pattern=f.pattern, entity_ids=list(f.entity_ids), confidence=f.confidence, is_root_cause=f.is_root_cause,
        )
        for m in modules
        for f in m.findings
        if f.status == FindingStatus.CONFIRMED
    ]
    root_causes = [
        SnapshotRootCause(root_cause_id=f.finding_id, module_id=m.module_id, module_type=m.module_type, statement=f.statement, entity_ids=list(f.entity_ids), confidence=f.confidence)
        for m in modules
        for f in m.findings
        if f.status == FindingStatus.CONFIRMED and f.is_root_cause
    ]
    capability_gaps = [gap for m in modules for gap in _module_capability_gaps(m)]

    planner_summary = SnapshotPlannerSummary(
        total_decisions=evaluation.efficiency.planner_decision_count,
        fallback_decisions=evaluation.decision_quality.planner.fallback_decision_count,
        objective_count=evaluation.efficiency.objective_count,
        unnecessary_deep_dive_count=evaluation.decision_quality.planner.unnecessary_deep_dive_count,
        strategy_label=_strategy_label(modules[0]) if len(modules) == 1 else None,
    )

    evaluation_summary = SnapshotEvaluationSummary(
        analytical_quality_score=analytical_summary_score(evaluation.analytical_quality),
        decision_quality_score=decision_summary_score(evaluation.decision_quality),
        delivery_quality_score=delivery_summary_score(evaluation.delivery_quality),
        efficiency_score=efficiency_summary_score(evaluation.efficiency),
        overall_score=evaluation.overall_score,
    )

    return LearningRunSnapshot(
        run_id=final_state.run_id,
        factory_id=final_state.factory_context.factory_id,
        module_types=[m.module_type for m in modules],
        task_type=final_state.global_goal.task_type if final_state.global_goal is not None else TaskType.INFORMATION,
        confirmed_findings=confirmed_findings,
        root_causes=root_causes,
        evaluation_summary=evaluation_summary,
        feedback_summary=feedback_summary,
        planner_summary=planner_summary,
        capability_gaps=capability_gaps,
        active_reasoning_skill_ids=list(active_reasoning_skill_ids or []),
    )
