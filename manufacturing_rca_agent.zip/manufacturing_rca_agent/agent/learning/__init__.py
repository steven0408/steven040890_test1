"""Learning (Phase 7C) -- a post-run Harness service that turns
LearningRunSnapshots (agent/learning/snapshot.py, themselves built from
already-recorded AgentState/RunEvaluation/HumanFeedback data) into
LearningCandidate proposals (agent/state/models.py).

Architecture invariant (frozen, item 21): **Learning may propose what
could be learned. Learning may NOT decide that a candidate is already
validated truth.** The deterministic `OEEPlanningPolicy` remains the
known-scenario baseline/fallback/oracle (Phase 5C-2.1's own architecture
note); Learning is what lets the system notice an association or strategy
the baseline never recorded -- but *novel is not correct*. Every candidate
this package can construct starts and stays `LearningCandidateStatus.
CANDIDATE`; nothing here ever writes `VALIDATED`, edits a Skill markdown
file, a Tool, a Planner prompt/threshold, or Knowledge -- see
agent/learning/promotion.py for the explicit (never auto-invoked)
promotion boundary.

Learning vs. Evaluator (frozen in Phase 7A) vs. Human Feedback (frozen in
Phase 7B): Evaluator judges what happened; Human Feedback records what a
person thought; Learning is the only one of the three that proposes
anything forward-looking, and even then only as an inert, reviewable
`LearningCandidate` -- never a write to a live system.
"""
