"""LearningEvidenceLink (Phase 7C item 5) -- one typed piece of evidence
for or against a `LearningCandidate`. `LearningSignalType` lives in
agent/state/enums.py (used by `LearningEvidenceLink` here, a sink-only
artifact -- never referenced by AgentState directly, so it lives in this
package rather than agent/state/models.py, same split
PlannerDecisionRecord/EvaluationRecord already established).
"""
from agent.state.base import RCABaseModel
from agent.state.enums import LearningSignalType


class LearningEvidenceLink(RCABaseModel):
    link_id: str
    candidate_id: str
    signal_type: LearningSignalType
    source_run_id: str
    source_id: str | None = None  # the finding_id/root_cause_id/issue_id/etc this link points to, when applicable
    supports: bool
    strength: float  # 0..1 -- this link's own weight, before CandidateConfidenceScorer's signal-type tiering
    note: str = ""
