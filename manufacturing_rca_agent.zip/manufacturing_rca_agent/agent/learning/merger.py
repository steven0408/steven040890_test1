"""CandidateMerger (Phase 7C item 14) -- deterministic dedup/merge keyed on
`LearningCandidate.candidate_key` (never the free-text `statement`, see
agent/learning/candidate_key.py). No embeddings this phase.

Distinguishes two update shapes explicitly (item 16): `LearningEvidenceLink`
records are always appended to the sink, never overwritten or removed;
the `LearningCandidate` aggregate record itself is *versioned* -- when a
new candidate shares an existing one's `candidate_key`, the existing
record is replaced with an updated aggregate (union of source_run_ids/
supporting_*_ids, recomputed confidence, bumped `updated_at`) via
`sink.update()`, not by adding a second row for the same real-world
candidate.
"""
from datetime import datetime, timezone
from typing import Callable

from agent.learning.confidence import CandidateConfidenceScorer
from agent.learning.signals import LearningEvidenceLink
from agent.learning.sink import LearningCandidateSink
from agent.state.models import LearningCandidate


class CandidateMerger:
    def __init__(self, scorer: CandidateConfidenceScorer):
        self._scorer = scorer

    def merge_into_sink(
        self,
        sink: LearningCandidateSink,
        candidates: list[LearningCandidate],
        links: list[LearningEvidenceLink],
        *,
        now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ) -> list[LearningCandidate]:
        results: list[LearningCandidate] = []
        for candidate in candidates:
            candidate_links = [link for link in links if link.candidate_id == candidate.candidate_id]
            existing = sink.find_by_candidate_key(candidate.candidate_key)

            if existing is None:
                sink.record(candidate)
                for link in candidate_links:
                    sink.record_evidence_link(link)
                results.append(candidate)
                continue

            remapped_links = [link.model_copy(update={"candidate_id": existing.candidate_id}) for link in candidate_links]
            for link in remapped_links:
                sink.record_evidence_link(link)
            all_links = sink.list_evidence_links(existing.candidate_id)

            updated = existing.model_copy(
                update={
                    "source_run_ids": sorted(set(existing.source_run_ids) | set(candidate.source_run_ids)),
                    "source_module_ids": sorted(set(existing.source_module_ids) | set(candidate.source_module_ids)),
                    "supporting_finding_ids": sorted(set(existing.supporting_finding_ids) | set(candidate.supporting_finding_ids)),
                    "supporting_root_cause_ids": sorted(set(existing.supporting_root_cause_ids) | set(candidate.supporting_root_cause_ids)),
                    "evaluation_issue_ids": sorted(set(existing.evaluation_issue_ids) | set(candidate.evaluation_issue_ids)),
                    "feedback_issue_ids": sorted(set(existing.feedback_issue_ids) | set(candidate.feedback_issue_ids)),
                    "planner_decision_record_ids": sorted(set(existing.planner_decision_record_ids) | set(candidate.planner_decision_record_ids)),
                    "supporting_signal_count": sum(1 for link in all_links if link.supports),
                    "contradicting_signal_count": sum(1 for link in all_links if not link.supports),
                    "confidence": self._scorer.score(all_links),
                    "updated_at": now_fn(),
                }
            )
            sink.update(updated)
            results.append(updated)

        return results
