"""LearningCandidateSink (Phase 7C item 16) -- same "Protocol + InMemory
reference impl" pattern as every other sink in this codebase. Two
different mutability rules on purpose: `record_evidence_link` is
append-only (never update/overwrite, matching HumanFeedbackSink's own
discipline -- Phase 7B); `update` replaces a `LearningCandidate`
*aggregate* record in place, keyed by `candidate_id`, which is what lets
`CandidateMerger` fold new evidence into an existing candidate's rollup
fields without duplicating the candidate itself. A future PostgreSQL
implementation would keep the evidence-link table append-only and the
candidate table as a normal updatable row, exactly mirroring this split.
"""
from __future__ import annotations

from typing import Protocol

from agent.learning.signals import LearningEvidenceLink
from agent.state.enums import LearningCandidateStatus, LearningCandidateType
from agent.state.models import LearningCandidate


class LearningCandidateSink(Protocol):
    def record(self, candidate: LearningCandidate) -> None: ...

    def update(self, candidate: LearningCandidate) -> None: ...

    def get(self, candidate_id: str) -> LearningCandidate | None: ...

    def list(self) -> list[LearningCandidate]: ...

    def list_by_type(self, candidate_type: LearningCandidateType) -> list[LearningCandidate]: ...

    def list_by_status(self, status: LearningCandidateStatus) -> list[LearningCandidate]: ...

    def find_by_candidate_key(self, candidate_key: str) -> LearningCandidate | None: ...

    def record_evidence_link(self, link: LearningEvidenceLink) -> None: ...

    def list_evidence_links(self, candidate_id: str) -> list[LearningEvidenceLink]: ...


class LearningCandidateNotFoundError(KeyError):
    pass


class InMemoryLearningCandidateSink:
    def __init__(self) -> None:
        self._candidates: dict[str, LearningCandidate] = {}
        self._links: list[LearningEvidenceLink] = []

    def record(self, candidate: LearningCandidate) -> None:
        self._candidates[candidate.candidate_id] = candidate

    def update(self, candidate: LearningCandidate) -> None:
        if candidate.candidate_id not in self._candidates:
            raise LearningCandidateNotFoundError(f"no candidate registered with candidate_id '{candidate.candidate_id}' -- call record() first")
        self._candidates[candidate.candidate_id] = candidate

    def get(self, candidate_id: str) -> LearningCandidate | None:
        return self._candidates.get(candidate_id)

    def list(self) -> list[LearningCandidate]:
        return list(self._candidates.values())

    def list_by_type(self, candidate_type: LearningCandidateType) -> list[LearningCandidate]:
        return [c for c in self._candidates.values() if c.candidate_type == candidate_type]

    def list_by_status(self, status: LearningCandidateStatus) -> list[LearningCandidate]:
        return [c for c in self._candidates.values() if c.status == status]

    def find_by_candidate_key(self, candidate_key: str) -> LearningCandidate | None:
        for candidate in self._candidates.values():
            if candidate.candidate_key == candidate_key:
                return candidate
        return None

    def record_evidence_link(self, link: LearningEvidenceLink) -> None:
        self._links.append(link)

    def list_evidence_links(self, candidate_id: str) -> list[LearningEvidenceLink]:
        return [link for link in self._links if link.candidate_id == candidate_id]
