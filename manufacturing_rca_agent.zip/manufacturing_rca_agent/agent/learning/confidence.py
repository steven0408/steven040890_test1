"""CandidateConfidenceScorer (Phase 7C item 6) -- deterministic, explicitly
NOT a statistical/causal confidence. This is a *candidate support
confidence*: how much of the collected evidence, weighted by signal-type
tier and by how many independent runs actually back it, points toward
this candidate being worth a human's attention -- never a claim about the
real-world probability that the candidate's statement is true.

Replaceable by construction (item 6's explicit instruction): a caller
passes any object satisfying `CandidateConfidenceScorer`'s Protocol; the
default `TieredCandidateConfidenceScorer` is not hard-coded into any
generator, only passed in.
"""
from typing import Protocol

from agent.learning.signals import LearningEvidenceLink
from agent.state.enums import LearningSignalType

# Strength tiers, straight from the spec's own worked example: a confirmed
# root cause / a pattern repeated across independent runs / an explicit
# human root-cause validation are "strong"; a high evaluator score or an
# efficiency win is "moderate"; a bare preference signal (thumbs-up alone)
# is "weak"; a contradiction or explicit negative feedback carries real
# (not maximal) weight against a candidate.
_STRONG = 0.9
_MODERATE = 0.6
_WEAK = 0.3
_NEGATIVE = 0.7

_TIER_WEIGHT: dict[LearningSignalType, float] = {
    LearningSignalType.CONFIRMED_ROOT_CAUSE: _STRONG,
    LearningSignalType.REPEATED_PATTERN: _STRONG,
    LearningSignalType.HUMAN_ROOT_CAUSE_VALIDATION: _STRONG,
    LearningSignalType.CONFIRMED_FINDING: _MODERATE,
    LearningSignalType.HUMAN_FINDING_VALIDATION: _MODERATE,
    LearningSignalType.HIGH_EVALUATION_SCORE: _MODERATE,
    LearningSignalType.EFFICIENCY_IMPROVEMENT: _MODERATE,
    LearningSignalType.CAPABILITY_NOT_FOUND: _MODERATE,
    LearningSignalType.HUMAN_PREFERENCE: _WEAK,
    LearningSignalType.NEGATIVE_HUMAN_FEEDBACK: _NEGATIVE,
    LearningSignalType.CONTRADICTING_FINDING: _NEGATIVE,
}

_MIN_RUNS_FOR_FULL_VOLUME_CREDIT = 3


class CandidateConfidenceScorer(Protocol):
    def score(self, evidence_links: list[LearningEvidenceLink]) -> float: ...


class TieredCandidateConfidenceScorer:
    def score(self, evidence_links: list[LearningEvidenceLink]) -> float:
        if not evidence_links:
            return 0.0

        supporting = [link for link in evidence_links if link.supports]
        contradicting = [link for link in evidence_links if not link.supports]
        if not supporting:
            return 0.0

        support_weight = sum(_TIER_WEIGHT.get(link.signal_type, 0.5) * link.strength for link in supporting)
        contradict_weight = sum(_TIER_WEIGHT.get(link.signal_type, 0.5) * link.strength for link in contradicting)
        net_weight = support_weight - contradict_weight
        if net_weight <= 0:
            return 0.0

        # Strength: net evidence weight against a fixed reference ceiling
        # (3 STRONG-tier signals) -- this is what makes signal *type*
        # matter even with zero contradiction (a bare ratio of
        # support/(support+contradict) would always be 1.0 whenever
        # nothing contradicts, regardless of how weak the signal type is).
        ceiling = _STRONG * _MIN_RUNS_FOR_FULL_VOLUME_CREDIT
        strength_component = min(1.0, net_weight / ceiling)

        # Volume: a single supporting run is dampened -- "repeated across
        # independent runs" is explicitly what separates a strong pattern
        # from an isolated observation (item 9's single-run-vs-cross-run
        # rule) -- counted separately from strength so that one run
        # contributing several links can never fake cross-run repetition.
        distinct_supporting_runs = len({link.source_run_id for link in supporting})
        volume_factor = min(1.0, distinct_supporting_runs / _MIN_RUNS_FOR_FULL_VOLUME_CREDIT)

        confidence = strength_component * (0.4 + 0.6 * volume_factor)
        return round(max(0.0, min(1.0, confidence)), 4)
