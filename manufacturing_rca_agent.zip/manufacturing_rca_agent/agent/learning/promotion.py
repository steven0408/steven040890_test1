"""CandidatePromotionPolicy (Phase 7C item 17) -- contract only. Deliberately
a *read-only recommendation* Protocol: `evaluate()` returns a
`PromotionRecommendation` value, never mutates `candidate` or writes
anything to a sink. There is no `promote()` method anywhere in this
package that flips a candidate's status to VALIDATED -- promotion, if it
ever happens, is a future human/reviewer action outside Phase 7C's scope,
never something a production flow calls automatically.

`NoAutoPromotionPolicy` is the only implementation this phase, and it
always recommends against promotion. See
tests/test_learning_promotion_boundary.py for the grep-level regression
proving no code path in `agent/learning/` constructs a VALIDATED
LearningCandidate.
"""
from datetime import datetime
from typing import Protocol

from agent.learning.signals import LearningEvidenceLink
from agent.state.base import RCABaseModel
from agent.state.models import LearningCandidate


class PromotionRecommendation(RCABaseModel):
    candidate_id: str
    recommended: bool
    reasons: list[str]
    evaluated_at: datetime


class CandidatePromotionPolicy(Protocol):
    def evaluate(self, candidate: LearningCandidate, evidence_links: list[LearningEvidenceLink], *, now: datetime) -> PromotionRecommendation: ...


class NoAutoPromotionPolicy:
    """Phase 7C's default and only policy -- always recommends against
    promotion, regardless of confidence/evidence. A future policy might
    check minimum independent runs / minimum human validation / minimum
    support confidence / max contradiction ratio / factory scope /
    reviewer approval -- none of that is implemented here; this class
    exists to make the "nothing auto-promotes" behavior explicit and
    swappable rather than an accidental omission."""

    def evaluate(self, candidate: LearningCandidate, evidence_links: list[LearningEvidenceLink], *, now: datetime) -> PromotionRecommendation:
        return PromotionRecommendation(
            candidate_id=candidate.candidate_id, recommended=False,
            reasons=["Phase 7C: automatic promotion is disabled by policy -- promotion requires a future human/reviewer decision."],
            evaluated_at=now,
        )
