"""Canonical candidate key (Phase 7C item 14) -- what `CandidateMerger`
groups on. Deliberately NOT the free-text `statement` (two candidates with
differently-worded but semantically identical statements must still
merge; no embeddings this phase, so the key is built from the same typed
fields the generator itself decided the candidate on).
"""
from agent.state.enums import LearningCandidateType


def build_candidate_key(candidate_type: LearningCandidateType, scope: str, normalized_pattern: str) -> str:
    return f"{candidate_type.value}::{scope}::{normalized_pattern}"


def knowledge_pattern_key(scope: str, pair: tuple[str, str]) -> str:
    """Order-independent -- "A associated with B" and "B associated with
    A" are the same candidate."""
    normalized = "|".join(sorted(pair))
    return build_candidate_key(LearningCandidateType.KNOWLEDGE_PATTERN, scope, normalized)


def planning_strategy_key(scope: str, task_type: str, strategy_label: str) -> str:
    return build_candidate_key(LearningCandidateType.PLANNING_STRATEGY, scope, f"{task_type}:{strategy_label}")


def capability_gap_key(module_type: str, requested_action: str) -> str:
    return build_candidate_key(LearningCandidateType.CAPABILITY_GAP, module_type, requested_action)


def reasoning_skill_key(scope: str, reasoning_skill_id: str) -> str:
    return build_candidate_key(LearningCandidateType.REASONING_SKILL, scope, reasoning_skill_id)
