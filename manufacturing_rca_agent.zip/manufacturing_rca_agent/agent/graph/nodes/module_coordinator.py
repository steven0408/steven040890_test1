from agent.state.enums import TERMINAL_MODULE_STATUSES, CoordinatorDecision
from agent.state.models import ControlSignals, ModuleDispatchState
from agent.state.state import AgentState


def module_coordinator(state: AgentState) -> dict:
    """Owns dispatch / scheduling / dependency / skip decisions -- never RCA
    reasoning, never ModuleState internals.

    Recomputes the ready/pending split from `module_states` + `selected_modules`
    on every entry rather than incrementally mutating `module_dispatch`, so
    it stays correct no matter how many times it is re-entered (once per
    module round-trip through the Module Subgraph).

    A module counts as "already handled" once it has an entry in
    `module_states` (Module Subgraph Mock only ever writes that entry once
    it reaches a terminal status -- Phase 2 has no genuine in-progress gap
    yet, that arrives with the real Module ReAct Loop).
    """

    task_by_id = {task.module_id: task for task in state.selected_modules}

    terminal_ids = {
        module_id
        for module_id, module_state in state.module_states.items()
        if module_state.status in TERMINAL_MODULE_STATUSES
    }

    not_dispatched = [module_id for module_id in task_by_id if module_id not in state.module_states]
    ready = [
        module_id
        for module_id in not_dispatched
        if set(task_by_id[module_id].depends_on) <= terminal_ids
    ]
    pending = [module_id for module_id in not_dispatched if module_id not in ready]

    if ready:
        decision = CoordinatorDecision.DISPATCH
    elif task_by_id and len(terminal_ids) == len(task_by_id):
        decision = CoordinatorDecision.ALL_TERMINAL
    else:
        decision = CoordinatorDecision.WAIT

    return {
        "module_dispatch": ModuleDispatchState(
            execution_policy=state.module_dispatch.execution_policy,
            in_flight=ready,
            pending=pending,
        ),
        "control": ControlSignals(
            standardizer_decision=state.control.standardizer_decision,
            coordinator_decision=decision,
        ),
    }
