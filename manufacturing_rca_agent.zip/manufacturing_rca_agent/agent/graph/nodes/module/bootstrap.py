from agent.analysis.analysis_tree import AnalysisTree, AnalysisTreeNode
from agent.state.enums import EvidenceQuality, ModuleStatus, TaskType, TreeNodeType
from agent.state.models import AnalysisSpace, Budget, ModuleGoal, ModuleState, ModuleTask, SuccessCriteria


def build_initial_module_state(
    module_task: ModuleTask, budget: Budget, run_id: str, task_type: TaskType = TaskType.RCA
) -> ModuleState:
    """Module init: seeds goal / analysis_space / analysis_tree / budget and
    marks the module RUNNING. Deliberately does NOT set `current_objective`
    -- Module Planner is the only place that ever produces one, even the
    first. `run_id` is carried purely for audit context (e.g. HumanRequest
    payloads raised from inside this module) -- the module never acts on it.
    `task_type` defaults to RCA to match every Phase 1-5A scenario's
    behavior; callers exercising INFORMATION/ANALYSIS depth pass it in.
    """
    tree = AnalysisTree(root_id="root")
    tree.add_node(AnalysisTreeNode(node_id="root", label=module_task.module_type, node_type=TreeNodeType.MODULE))

    return ModuleState(
        module_id=module_task.module_id,
        module_type=module_task.module_type,
        run_id=run_id,
        status=ModuleStatus.RUNNING,
        goal=ModuleGoal(
            module_id=module_task.module_id,
            statement=module_task.goal_statement,
            task_type=task_type,
            success_criteria=SuccessCriteria(
                min_evidence_quality=EvidenceQuality.MODERATE,
                root_cause_coverage_threshold=0.0,
            ),
            # Phase WB-3F.4: threaded verbatim from ModuleTask -- see
            # ModuleGoal.constraints' own docstring for the full chain.
            constraints=module_task.constraints,
        ),
        analysis_space=AnalysisSpace(root_dimension=module_task.module_type, dimensions={}),
        analysis_tree=tree,
        budget=budget,
    )
