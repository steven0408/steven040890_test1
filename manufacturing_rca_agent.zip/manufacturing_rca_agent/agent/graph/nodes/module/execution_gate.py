from langgraph.types import interrupt

from agent.state.enums import GateDecision, HumanDecision, HumanReason
from agent.state.models import ModuleControlSignals, ModuleState


def execution_gate(module_state: ModuleState) -> dict:
    """Is this action allowed to execute?

    Pass-through for any objective that doesn't require permission. For one
    that does, raises a PERMISSION_REQUIRED interrupt and waits for a Human
    APPROVE/REJECT before deciding PASS vs REJECTED.

    Idempotency: LangGraph re-executes an interrupted node from the top on
    resume, so nothing before the `interrupt()` call may have a
    non-repeatable side effect. This node reads `module_state` (never
    mutates it) and calls `interrupt()` at most once per invocation -- no
    budget/metrics/history writes happen here at all, on either the fresh
    or the resumed path. HIGH_RISK_ACTION gating shares this same
    mechanism (risk_level is already carried on Objective) but isn't
    exercised by any policy yet -- only PERMISSION_REQUIRED is wired up
    this phase.
    """
    objective = module_state.current_objective
    if objective is None or not objective.requires_permission:
        return {
            "control": ModuleControlSignals(
                planner_decision=module_state.control.planner_decision,
                gate_decision=GateDecision.PASS,
            )
        }

    response = interrupt(
        {
            "run_id": module_state.run_id,
            "module_id": module_state.module_id,
            "branch_id": None,
            "objective_id": objective.objective_id,
            "source_node": "execution_gate",
            "reason": HumanReason.PERMISSION_REQUIRED.value,
            "question": f"Approve '{objective.permission_type}' access for objective '{objective.description}'?",
            "options": None,
            "permission_type": objective.permission_type,
            "risk_level": objective.risk_level.value if objective.risk_level else None,
        }
    )

    approved = response.get("decision") == HumanDecision.APPROVE.value
    return {
        "control": ModuleControlSignals(
            planner_decision=module_state.control.planner_decision,
            gate_decision=GateDecision.PASS if approved else GateDecision.REJECTED,
        )
    }
