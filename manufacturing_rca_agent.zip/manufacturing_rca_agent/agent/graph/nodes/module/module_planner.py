from agent.planning.policies.base import ModulePlanningPolicy
from agent.state.enums import (
    ExecutionStrategy,
    GateDecision,
    ModulePlannerDecision,
    ObjectiveStatus,
    ObservationStatus,
    ReflectorVerdict,
)
from agent.state.models import Limitation, ModuleControlSignals, ModuleState, Objective, ObjectiveRecord, Plan, RejectionRecord

_CLOSING_REASON_BY_VERDICT = {
    ReflectorVerdict.CONTINUE: "continue_insufficient_evidence",
    ReflectorVerdict.RETRY: "observation_error_retry",
}


def _close_out_current_objective(module_state: ModuleState, *, status: ObjectiveStatus, reason: str) -> ObjectiveRecord | None:
    """Finalizes the ObjectiveRecord for the objective Planner is about to
    stop treating as current (whether it's dispatching a replacement or
    giving up entirely). Tool SUCCESS is not read here as "completed" --
    this only runs off of a lifecycle decision (a Reflector verdict, or a
    Human rejection at the Gate), never a raw tool result.
    """
    previous = module_state.current_objective
    if previous is None:
        return None
    prior_record = module_state.objective_history.get(previous.objective_id)
    if prior_record is None:
        return None  # defensive: every dispatched objective should have a record

    observation_ids = [o.observation_id for o in module_state.observations if o.objective_id == previous.objective_id]
    evidence_ids = [e.evidence_id for e in module_state.evidence if e.objective_id == previous.objective_id]

    return prior_record.model_copy(
        update={
            "status": status,
            "completed_step": len(module_state.observations),
            "observation_ids": observation_ids,
            "evidence_ids": evidence_ids,
            "termination_reason": reason,
        }
    )


def _build_dispatch_update(module_state: ModuleState, next_objective: Objective) -> dict:
    """Common "Planner commits to a new objective" bookkeeping: mark it
    DISPATCHED, create its Plan + fresh ObjectiveRecord, bump step_count.
    Shared by the normal ReAct loop and the post-rejection alternative path.
    """
    next_objective = next_objective.model_copy(update={"status": ObjectiveStatus.DISPATCHED})
    # Must match the policy's own round-number counting (objective_history,
    # not observations) -- a rejected objective never produces an
    # observation, so counting observations here would desync `created_step`
    # from the id the policy already picked.
    round_index = len(module_state.objective_history) + 1
    plan = Plan(
        plan_id=f"{module_state.module_id}-plan-{round_index}",
        module_id=module_state.module_id,
        current_objective=next_objective,
        execution_strategy=ExecutionStrategy.SEQUENTIAL,
        budget_snapshot=module_state.budget,
        created_at_step=round_index,
    )
    new_record = ObjectiveRecord(
        objective_id=next_objective.objective_id,
        description=next_objective.description,
        action=next_objective.action,
        capability_key=next_objective.capability_key,
        target_ref=next_objective.target_ref,
        scope=next_objective.scope,
        status=ObjectiveStatus.DISPATCHED,
        created_step=round_index,
        attempt_count=next_objective.attempt_count,
    )
    return {
        "current_objective": next_objective,
        "current_plan": plan,
        "objective_history": {new_record.objective_id: new_record},
        "metrics": module_state.metrics.model_copy(update={"step_count": module_state.metrics.step_count + 1}),
        "control": ModuleControlSignals(planner_decision=ModulePlannerDecision.DISPATCH),
    }


def _handle_rejection(module_state: ModuleState, policy: ModulePlanningPolicy) -> dict:
    """Human REJECTed the current objective's permission request at
    Execution Gate. Never jumps straight to BLOCKED -- tries an alternative
    via the policy first, the same way a DATA_NOT_FOUND retry would. Only
    when no alternative exists does this hand off to Module Completion
    Check with a RejectionRecord(alternative_found=False) for it to weigh
    against BLOCKED vs PARTIAL/FAILED.
    """
    closed_record = _close_out_current_objective(
        module_state, status=ObjectiveStatus.REJECTED, reason="human_rejected_permission"
    )
    rejected = module_state.current_objective

    # the policy must see the rejection already applied to pick the next
    # source -- module_state.objective_history itself hasn't been updated
    # yet (that update is what we're building to return).
    lookahead_state = module_state.model_copy(
        update={"objective_history": {**module_state.objective_history, closed_record.objective_id: closed_record}}
    )
    next_objective = policy.propose_next_objective(lookahead_state)

    rejection_record = RejectionRecord(
        objective_id=rejected.objective_id,
        permission_type=rejected.permission_type,
        reason="human_rejected_permission",
        alternative_found=next_objective is not None,
    )

    if next_objective is None:
        limitation = Limitation(
            limitation_id=f"{module_state.module_id}-lim-{len(module_state.limitations) + 1}",
            description=f"Permission '{rejected.permission_type}' was denied and no alternative source is available.",
            impacted_objective_id=rejected.objective_id,
            impact_statement=(
                "Some aspects of this module could not be verified because required "
                "authorization was not granted and no alternative analysis path exists."
            ),
            related_error=None,
        )
        return {
            "current_objective": None,
            "objective_history": {closed_record.objective_id: closed_record},
            "rejections": [rejection_record],
            "limitations": [limitation],
            "control": ModuleControlSignals(planner_decision=ModulePlannerDecision.NO_VIABLE_OBJECTIVE),
        }

    updates = _build_dispatch_update(module_state, next_objective)
    updates["objective_history"] = {**updates["objective_history"], closed_record.objective_id: closed_record}
    updates["rejections"] = [rejection_record]
    return updates


def make_module_planner(policy: ModulePlanningPolicy):
    """The only node allowed to create/replace `current_objective` and
    `current_plan` (and, correspondingly, the only node that ever creates a
    new `objective_history` entry). Never touches `module_state.status`
    (Module Completion Check's job). Human's REJECT decision only ever
    reaches this node as a `gate_decision` -- it is a new constraint the
    Planner reacts to, not a new objective definition; Planner still
    authors whatever comes next.
    """

    def module_planner(module_state: ModuleState) -> dict:
        if module_state.control.gate_decision == GateDecision.REJECTED:
            return _handle_rejection(module_state, policy)

        closing_record = _close_out_current_objective(
            module_state,
            status=ObjectiveStatus.COMPLETED,
            reason=_CLOSING_REASON_BY_VERDICT.get(module_state.control.reflector_verdict, "superseded"),
        )

        if module_state.budget.used_steps >= module_state.budget.max_steps:
            updates: dict = {
                "current_objective": None,
                "control": ModuleControlSignals(planner_decision=ModulePlannerDecision.NO_VIABLE_OBJECTIVE),
            }
            if closing_record is not None:
                updates["objective_history"] = {closing_record.objective_id: closing_record}
            return updates

        next_objective = policy.propose_next_objective(module_state)

        if next_objective is None:
            updates = {
                "current_objective": None,
                "control": ModuleControlSignals(planner_decision=ModulePlannerDecision.NO_VIABLE_OBJECTIVE),
            }
            if closing_record is not None:
                updates["objective_history"] = {closing_record.objective_id: closing_record}
            last_observation = module_state.observations[-1] if module_state.observations else None
            if last_observation is not None and last_observation.status == ObservationStatus.ERROR:
                updates["limitations"] = [
                    Limitation(
                        limitation_id=f"{module_state.module_id}-lim-1",
                        description=f"No further data source available for {module_state.module_type}.",
                        impacted_objective_id=last_observation.objective_id,
                        impact_statement=(
                            "Some aspects of this module could not be verified because all "
                            "known data sources were unavailable."
                        ),
                        related_error=last_observation.error,
                    )
                ]
            return updates

        updates = _build_dispatch_update(module_state, next_objective)
        if closing_record is not None:
            updates["objective_history"] = {**updates["objective_history"], closing_record.objective_id: closing_record}
        return updates

    return module_planner
