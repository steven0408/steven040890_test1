from langgraph.graph import END, START, StateGraph

from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime, make_capability_module_executor
from agent.graph.nodes.module.execution_gate import execution_gate
from agent.graph.nodes.module.module_completion_check import module_completion_check
from agent.graph.nodes.module.module_executor import make_module_executor
from agent.graph.nodes.module.module_planner import make_module_planner
from agent.graph.nodes.module.module_reflector import make_module_reflector
from agent.graph.routing import (
    route_from_module_completion_check,
    route_from_module_gate,
    route_from_module_planner,
    route_from_module_reflector,
)
from agent.planning.policies.base import ModulePlanningPolicy
from agent.state.models import ModuleState
from agent.tools.base import MockTool


def build_module_react_subgraph(
    policy: ModulePlanningPolicy, tool: MockTool | None = None, capability: ModuleCapabilityRuntime | None = None
) -> StateGraph:
    """Reusable Module ReAct Subgraph:

        START -> Module Planner -> Execution Gate -> Module Executor
              -> Module Reflector -> Module Completion Check
              -> Module Planner (loop) / END (terminal)

    Execution Gate can also route straight back to Module Planner: Human
    REJECT at the Gate is a constraint Planner must react to (try an
    alternative objective, or give up), not a dead end.

    Same node code regardless of module_type -- domain behavior comes only
    from the injected `policy` and Module Executor's wiring. Pass exactly
    one of `tool` (legacy Phase 3-5A direct-tool executor,
    `Objective -> Executor -> Tool`) or `capability` (Phase 5B-2 capability-
    routed executor, `Objective -> Executor -> CapabilityResolver -> Skill
    -> SkillRunner -> ToolExecutionManager -> ToolRegistry -> Tool`) --
    Module Planner / Execution Gate / Module Reflector / Module Completion
    Check are identical either way, and don't know or care which executor
    variant is wired in.
    """
    if (tool is None) == (capability is None):
        raise ValueError("build_module_react_subgraph requires exactly one of `tool` or `capability`")

    executor = make_module_executor(tool) if tool is not None else make_capability_module_executor(capability)

    graph = StateGraph(ModuleState)

    graph.add_node("module_planner", make_module_planner(policy))
    graph.add_node("execution_gate", execution_gate)
    graph.add_node("module_executor", executor)
    graph.add_node("module_reflector", make_module_reflector(policy))
    graph.add_node("module_completion_check", module_completion_check)

    graph.add_edge(START, "module_planner")
    graph.add_conditional_edges(
        "module_planner", route_from_module_planner, ["execution_gate", "module_completion_check"]
    )
    graph.add_conditional_edges("execution_gate", route_from_module_gate, ["module_executor", "module_planner"])
    graph.add_edge("module_executor", "module_reflector")
    graph.add_conditional_edges(
        "module_reflector", route_from_module_reflector, ["module_planner", "module_completion_check"]
    )
    graph.add_conditional_edges(
        "module_completion_check", route_from_module_completion_check, ["module_planner", END]
    )

    return graph
