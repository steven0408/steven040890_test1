from agent.planning.policies.base import ModulePlanningPolicy
from agent.state.enums import FindingStatus, ObservationStatus, ReflectorVerdict
from agent.state.models import Finding, ModuleControlSignals, ModuleState, ReflectionRecord


def make_module_reflector(policy: ModulePlanningPolicy):
    """Step-level evaluation only. Never creates a new Objective -- it can
    only signal CONTINUE / RETRY / CANDIDATE_COMPLETE and hand back to
    Module Planner (or Module Completion Check on CANDIDATE_COMPLETE).

    On a successful observation it also records/updates a Finding (HYPOTHESIS
    while still gathering more, CONFIRMED once the policy judges the
    evidence sufficient) -- this is "is the result trustworthy/useful",
    not new investigation.
    """

    def module_reflector(module_state: ModuleState) -> dict:
        last_observation = module_state.observations[-1]
        step_index = len(module_state.reflection_history) + 1

        if last_observation.status == ObservationStatus.ERROR:
            verdict = ReflectorVerdict.RETRY
            rationale = (
                f"Observation failed ({last_observation.error.error_type.value}); "
                "handing back to Planner to try an alternative path."
            )
        elif policy.is_sufficient(module_state):
            verdict = ReflectorVerdict.CANDIDATE_COMPLETE
            rationale = "Evidence gathered so far satisfies the module's sufficiency check."
        else:
            verdict = ReflectorVerdict.CONTINUE
            rationale = "Observation succeeded but evidence is not yet sufficient."

        reflection = ReflectionRecord(
            reflection_id=f"{module_state.module_id}-refl-{step_index}",
            objective_id=last_observation.objective_id,
            verdict=verdict,
            rationale=rationale,
            evidence_ids=[e.evidence_id for e in module_state.evidence],
            created_at_step=step_index,
        )

        updates: dict = {
            "reflection_history": [reflection],
            "control": ModuleControlSignals(reflector_verdict=verdict),
        }

        if verdict == ReflectorVerdict.RETRY:
            updates["metrics"] = module_state.metrics.model_copy(
                update={"retry_count": module_state.metrics.retry_count + 1}
            )

        if last_observation.status == ObservationStatus.SUCCESS:
            description = policy.describe_finding(module_state)
            updates["findings"] = [
                Finding(
                    finding_id=f"{module_state.module_id}-finding-{step_index}",
                    statement=description.statement,
                    entity_ids=description.entity_ids,
                    pattern=description.pattern,
                    supporting_evidence_ids=[e.evidence_id for e in module_state.evidence],
                    confidence=0.9 if verdict == ReflectorVerdict.CANDIDATE_COMPLETE else 0.5,
                    status=(
                        FindingStatus.CONFIRMED
                        if verdict == ReflectorVerdict.CANDIDATE_COMPLETE
                        else FindingStatus.HYPOTHESIS
                    ),
                    is_root_cause=description.is_root_cause and verdict == ReflectorVerdict.CANDIDATE_COMPLETE,
                )
            ]

        # domain-specific bookkeeping (Branch / EntityState / AnalysisTree /
        # Limitation / Hypothesis) the policy wants applied this round, on
        # top of Reflector's own updates above -- Reflector applies exactly
        # these five typed fields and nothing else; DomainStateUpdates'
        # closed schema makes it structurally impossible for a policy to
        # sneak in anything else (e.g. `status`) through this seam.
        # `limitations` (Phase WB-3C) and `hypotheses` (Phase WB-3F) are
        # both mechanical passthroughs exactly like `branches`/
        # `entity_states` -- Reflector never interprets *why* a policy
        # decided a gap was Limitation-worthy or a hypothesis worth
        # proposing, it just appends whatever typed records the policy
        # returns.
        extra = policy.derive_state_updates(module_state)
        if extra.branches:
            updates["branches"] = extra.branches
        if extra.entity_states:
            updates["entity_states"] = extra.entity_states
        if extra.analysis_tree is not None:
            updates["analysis_tree"] = extra.analysis_tree
        if extra.limitations:
            updates["limitations"] = extra.limitations
        if extra.hypotheses:
            updates["hypotheses"] = extra.hypotheses

        return updates

    return module_reflector
