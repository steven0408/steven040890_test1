from datetime import datetime, timezone

from agent.state.enums import EvidenceQuality, ObservationStatus
from agent.state.models import ErrorRecord, Evidence, ModuleState, Observation, ToolCallRecord
from agent.tools.base import MockTool


def make_module_executor(tool: MockTool):
    """Only executes `current_objective` via the injected tool and reports
    what happened. Never touches `current_objective` / `current_plan` --
    Module Planner owns those exclusively.

    Emits a `ToolCallRecord` for every invocation in addition to the usual
    Observation/Evidence -- Phase 5B-1 audit requirement (granular tool-call
    accounting for Evaluator, distinct from the one-per-objective
    Observation/Evidence). `skill_id` stays None here: this is still a
    direct tool call, not routed through a Skill/SkillRunner yet (Phase 5B-2).
    """

    def module_executor(module_state: ModuleState) -> dict:
        objective = module_state.current_objective
        started_at = datetime.now(timezone.utc)
        result = tool.run(objective)
        completed_at = datetime.now(timezone.utc)
        step_index = len(module_state.observations) + 1

        observation = Observation(
            observation_id=f"{module_state.module_id}-obs-{step_index}",
            objective_id=objective.objective_id,
            tool_name=f"mock_tool:{objective.target_ref.ref_id}",
            status=result.status,
            payload_summary=result.payload_summary,
            structured_payload=result.structured_payload,
            error=(
                ErrorRecord(
                    error_type=result.error_type,
                    message=result.error_message or "mock tool error",
                    objective_id=objective.objective_id,
                    occurred_at_step=step_index,
                )
                if result.status == ObservationStatus.ERROR
                else None
            ),
        )

        tool_call = ToolCallRecord(
            tool_call_id=f"{module_state.module_id}-toolcall-{step_index}",
            run_id=module_state.run_id,
            module_id=module_state.module_id,
            objective_id=objective.objective_id,
            skill_id=None,
            tool_id=objective.target_ref.ref_id,
            status=result.status,
            duration_seconds=(completed_at - started_at).total_seconds(),
            error=observation.error,
            sandboxed=False,
            started_at=started_at,
            completed_at=completed_at,
        )

        updates: dict = {
            "observations": [observation],
            "tool_calls": [tool_call],
            "budget": module_state.budget.model_copy(
                update={
                    "used_steps": module_state.budget.used_steps + 1,
                    "used_tool_calls": module_state.budget.used_tool_calls + 1,
                }
            ),
            "metrics": module_state.metrics.model_copy(
                update={"tool_call_count": module_state.metrics.tool_call_count + 1}
            ),
        }

        if result.status == ObservationStatus.SUCCESS:
            updates["evidence"] = [
                Evidence(
                    evidence_id=f"{module_state.module_id}-ev-{step_index}",
                    objective_id=objective.objective_id,
                    source_tool=observation.tool_name,
                    summary=result.payload_summary or "mock evidence",
                    structured_payload=result.structured_payload,
                    quality=result.quality or EvidenceQuality.MODERATE,
                )
            ]

        return updates

    return module_executor
