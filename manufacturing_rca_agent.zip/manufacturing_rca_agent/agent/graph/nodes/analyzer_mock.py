from agent.state.enums import TaskType
from agent.state.models import ModuleTask
from agent.state.state import AgentState


def analyzer_mock(state: AgentState) -> dict:
    """Phase 2 placeholder: hardcoded module selection (OEE/Output/WIP), all
    independent (no depends_on) so Module Coordinator can dispatch all
    three in parallel.

    Real module-relevance reasoning (confidence scoring, dependency
    inference from the request) lands in a later phase.

    Phase 5B-2.1: reads `state.global_goal.task_type` (set once by
    Standardizer) and propagates it verbatim into every selected
    ModuleTask -- never re-infers or re-guesses TaskType itself.
    """
    task_type = state.global_goal.task_type if state.global_goal is not None else TaskType.RCA
    return {
        "selected_modules": [
            ModuleTask(module_id="OEE", module_type="OEE", reason="mock selection", goal_statement="Assess OEE for the requested scope.", confidence=0.9, priority=0.9, task_type=task_type),
            ModuleTask(module_id="Output", module_type="Output", reason="mock selection", goal_statement="Assess Output for the requested scope.", confidence=0.9, priority=0.8, task_type=task_type),
            ModuleTask(module_id="WIP", module_type="WIP", reason="mock selection", goal_statement="Assess WIP for the requested scope.", confidence=0.8, priority=0.7, task_type=task_type),
        ]
    }
