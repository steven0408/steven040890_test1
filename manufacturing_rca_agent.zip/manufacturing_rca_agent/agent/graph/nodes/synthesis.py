"""Synthesis node -- `make_synthesis_node` (Phase 6A, deterministic, no
LLM) and `make_llm_synthesis_node` (Phase 6B, Mock/real-LLM-backed with a
built-in deterministic fallback). Both share the same external contract:

    AgentState (terminal module_states)
        -> ModuleHandoffBuilder (per module) -> SynthesisContextBuilder
        -> [LLMSynthesizer, Phase 6B only] -> HandoffPackage
        -> {"synthesis_result": HandoffPackage}

Reads only `state.module_states`/`state.global_goal`/request/factory
fields (all already on AgentState) -- never queries a Tool, never mutates
any ModuleState, same read-only discipline `global_completion_check`
already established for a run-level node. The deterministic node stays
available on purpose (Phase 6B item 4): fallback, regression baseline,
fact-grounded oracle, and a no-LLM mode -- never deleted.
"""
from agent.llm.context.synthesis_context import SynthesisContextBuilder
from agent.state.state import AgentState
from agent.synthesis.handoff_builder import ModuleHandoffBuilder
from agent.synthesis.llm_service import SynthesisLLMService
from agent.synthesis.package import build_handoff_package


def make_synthesis_node(context_builder: SynthesisContextBuilder | None = None):
    """Deterministic-only (Phase 6A) -- no LLM call, ever."""
    builder = context_builder or SynthesisContextBuilder(ModuleHandoffBuilder())

    def synthesis(state: AgentState) -> dict:
        outcome = builder.build(state)
        package = build_handoff_package(outcome.context)
        return {"synthesis_result": package}

    return synthesis


def make_llm_synthesis_node(service: SynthesisLLMService):
    """Phase 6B -- LLM-backed, with `SynthesisLLMService`'s own built-in
    fallback to deterministic synthesis on any LLM failure (see its
    docstring). This node itself never branches on LLM vs. fallback --
    that decision, and its audit trail, live entirely inside the service."""

    def synthesis(state: AgentState) -> dict:
        outcome = service.synthesize(state)
        return {"synthesis_result": outcome.package}

    return synthesis
