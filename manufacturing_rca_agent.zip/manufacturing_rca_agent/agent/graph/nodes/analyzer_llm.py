"""Analyzer LLM node (Phase 5B-3A) -- the first LLM-backed reasoning
component in this codebase. Planner/Reflector/SkillRunner/OEEPlanningPolicy
all remain deterministic (see the Phase 5B-3 architecture note); this is
the only seam.

    Analyzer Node -> AnalyzerContextBuilder -> LLMRouter -> LLMClient
        -> typed AnalyzerDecision -> Node updates AgentState

`AnalyzerLLMService.decide()` is the testable service (no LangGraph
dependency); `make_analyzer_llm_node` wraps it into a node function.
`build_phase2_graph`'s default `analyzer` is still the legacy deterministic
`analyzer_mock` (Phase 2-5B-2.1, unchanged) -- this node is opt-in via
`build_phase2_graph(..., analyzer=make_analyzer_llm_node(service))`.

Architecture note -- single dominant TaskType assumption (Phase 5B-3):
`AnalyzerDecision.task_type` is exactly one TaskType for the whole request;
there is no per-module TaskType decomposition yet. A genuinely mixed-intent
request ("告訴我平均 OEE，並分析 EQ007 原因") is out of scope this phase --
Analyzer will pick one dominant TaskType and apply it to every selected
Module uniformly (see `make_analyzer_llm_node`, which stamps
`decision.task_type` onto every `ModuleTask.task_type`). The schema is
already positioned to evolve into per-task TaskType without a breaking
change: `ModuleTask.task_type` (Phase 5B-2.1) is already per-module, not
global -- a future multi-intent Analyzer could assign different TaskTypes
to different ModuleSelections without touching ModuleTask/ModuleGoal/
CapabilityResolver at all. Not implemented now.
"""
from dataclasses import dataclass

from agent.catalog.module_registry import ModuleRegistry
from agent.llm.context.analyzer_context import AnalyzerContextBuilder
from agent.llm.models import DecisionSource, LLMInvalidOutputError
from agent.llm.prompts.analyzer import AnalyzerDecision, ModuleSelection, build_analyzer_messages
from agent.llm.router import LLMRouter, LLMRouterError
from agent.planning.task_type_inference import infer_task_type_deterministic
from agent.state.models import FactoryContext, Goal, GoalScope, ModuleTask
from agent.state.state import AgentState

# Re-exported for backward compatibility -- DecisionSource moved to
# agent.llm.models in Phase 5C-2 when Planner needed the exact same
# concept; existing imports of `agent.graph.nodes.analyzer_llm.DecisionSource`
# keep working.
__all__ = ["DecisionSource", "AnalyzerSemanticValidationError", "AnalyzerOutcome", "AnalyzerLLMService", "make_analyzer_llm_node", "validate_analyzer_decision"]


class AnalyzerSemanticValidationError(LLMInvalidOutputError):
    """A subclass, not a new sibling exception -- LLMRouter's failure
    handling is isinstance-based specifically so this is treated exactly
    like the client itself producing invalid structured output: recorded
    INVALID_OUTPUT, retried, and (once retries are exhausted) triggers
    AnalyzerLLMService's deterministic fallback. Pydantic schema validation
    alone cannot catch these -- they are true/false only with respect to
    *this run's* ModuleRegistry/FactoryContext, not AnalyzerDecision's
    static shape."""


def validate_analyzer_decision(
    decision: AnalyzerDecision, *, module_registry: ModuleRegistry, factory_context: FactoryContext
) -> None:
    """Semantic validation beyond pydantic schema validation (Phase 5B-3B)
    -- catches an LLM hallucinating a module that doesn't exist / isn't
    enabled / isn't available to this factory / doesn't support the decided
    TaskType, or otherwise producing a structurally-valid-but-nonsensical
    decision. Never lets an invalid decision reach Module Coordinator."""
    if not decision.selected_modules:
        raise AnalyzerSemanticValidationError("AnalyzerDecision must select at least one module")

    if not (0.0 <= decision.confidence <= 1.0):
        raise AnalyzerSemanticValidationError(f"decision confidence out of range [0,1]: {decision.confidence}")

    available = {d.module_type: d for d in module_registry.available_for(factory_context)}
    seen: set[str] = set()
    for selection in decision.selected_modules:
        if selection.module_type in seen:
            raise AnalyzerSemanticValidationError(f"duplicate module_type '{selection.module_type}' in selected_modules")
        seen.add(selection.module_type)

        definition = available.get(selection.module_type)
        if definition is None:
            raise AnalyzerSemanticValidationError(
                f"module_type '{selection.module_type}' is not registered/enabled/available for factory "
                f"'{factory_context.factory_id}' -- possible hallucinated module"
            )
        if decision.task_type not in definition.supported_task_types:
            raise AnalyzerSemanticValidationError(
                f"module_type '{selection.module_type}' does not support task_type '{decision.task_type.value}'"
            )
        if not (0.0 <= selection.confidence <= 1.0):
            raise AnalyzerSemanticValidationError(f"module '{selection.module_type}' confidence out of range [0,1]: {selection.confidence}")
        if not (0.0 <= selection.priority <= 1.0):
            raise AnalyzerSemanticValidationError(f"module '{selection.module_type}' priority out of range [0,1]: {selection.priority}")
        if not selection.goal_statement.strip():
            raise AnalyzerSemanticValidationError(
                f"module '{selection.module_type}' goal_statement must be a non-empty, module-specific task "
                "statement (what this module should accomplish) -- pydantic schema validation alone cannot "
                "catch a blank/whitespace-only string here"
            )


@dataclass(frozen=True)
class AnalyzerOutcome:
    """Not persisted -- pairs the AnalyzerDecision the node applies to
    AgentState with provenance (LLM vs. deterministic fallback, and why)
    for callers/tests that need to assert on it directly. The underlying
    per-attempt LLM call audit trail lives in LLMUsageSink regardless of
    which of these this ends up being -- LLMRouter records it either way."""

    decision: AnalyzerDecision
    source: DecisionSource
    fallback_reason: str | None = None


def _deterministic_fallback_decision(state: AgentState, module_registry: ModuleRegistry) -> AnalyzerDecision:
    task_type = infer_task_type_deterministic(state.user_request.raw_text)
    candidates = module_registry.available_for(state.factory_context)
    relevant = [m for m in candidates if task_type in m.supported_task_types]
    # Item 9: this fallback cannot do genuine module-specific goal
    # decomposition (no LLM available) -- it conservatively reuses the
    # normalized request verbatim as every selected module's goal_statement
    # rather than fabricating a fake per-module rewrite. This is a coarser
    # signal than the LLM path's module-scoped goal_statement; the fallback
    # nature is already marked at the decision level via
    # `AnalyzerOutcome.source == DecisionSource.FALLBACK` (see `decide()`
    # below), so it is not duplicated as a per-selection field here.
    fallback_goal_statement = state.normalized_request.normalized_text if state.normalized_request is not None else state.user_request.raw_text
    selections = [
        ModuleSelection(
            module_type=m.module_type,
            priority=round(0.9 - 0.1 * i, 2),
            confidence=0.9,
            rationale=f"Deterministic fallback selection for {task_type.value}.",
            goal_statement=fallback_goal_statement,
        )
        for i, m in enumerate(relevant)
    ]
    return AnalyzerDecision(
        task_type=task_type,
        selected_modules=selections,
        reasoning_summary="Deterministic fallback (LLM unavailable) -- keyword-based TaskType inference, all applicable modules selected.",
        confidence=0.5,
    )


class AnalyzerLLMService:
    def __init__(
        self,
        module_registry: ModuleRegistry,
        context_builder: AnalyzerContextBuilder,
        router: LLMRouter,
        *,
        route: str = "analyzer",
    ):
        self._module_registry = module_registry
        self._context_builder = context_builder
        self._router = router
        self._route = route

    def decide(self, state: AgentState) -> AnalyzerOutcome:
        context = self._context_builder.build(state)
        messages = build_analyzer_messages(context)

        def _validate(decision: AnalyzerDecision) -> None:
            validate_analyzer_decision(decision, module_registry=self._module_registry, factory_context=state.factory_context)

        try:
            router_outcome = self._router.call(
                self._route, messages, AnalyzerDecision, run_id=state.run_id, module_id=None, node="analyzer", validate=_validate
            )
            return AnalyzerOutcome(decision=router_outcome.parsed_output, source=DecisionSource.LLM)
        except LLMRouterError as exc:
            fallback_decision = _deterministic_fallback_decision(state, self._module_registry)
            return AnalyzerOutcome(decision=fallback_decision, source=DecisionSource.FALLBACK, fallback_reason=str(exc))


def make_analyzer_llm_node(service: AnalyzerLLMService):
    def analyzer_llm(state: AgentState) -> dict:
        outcome = service.decide(state)
        decision = outcome.decision

        goal_update: dict = {}
        if state.global_goal is not None:
            goal_update["global_goal"] = state.global_goal.model_copy(update={"task_type": decision.task_type})
        else:
            goal_update["global_goal"] = Goal(
                goal_id=f"{state.run_id}-goal",
                raw_statement=state.user_request.raw_text,
                normalized_statement=state.user_request.raw_text,
                task_type=decision.task_type,
                scope=GoalScope(),
            )

        # Phase WB-3F.4: every dispatched ModuleTask carries the SAME
        # request-level RequestConstraints verbatim -- Analyzer does not
        # decide which module "needs" which constraint (that stays the
        # Planner's own per-Objective judgment call, item 14/67's "Analyzer
        # must not turn them into Tool arguments" boundary); it only
        # relays what the Standardizer already extracted.
        constraints = state.normalized_request.constraints if state.normalized_request is not None else []
        selected_modules = [
            ModuleTask(
                module_id=selection.module_type,
                module_type=selection.module_type,
                reason=selection.rationale,
                goal_statement=selection.goal_statement,
                confidence=selection.confidence,
                priority=selection.priority,
                task_type=decision.task_type,
                constraints=constraints,
            )
            for selection in decision.selected_modules
        ]

        return {**goal_update, "selected_modules": selected_modules}

    return analyzer_llm
