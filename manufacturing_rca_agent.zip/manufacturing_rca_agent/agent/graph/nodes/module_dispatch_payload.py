from agent.state.base import RCABaseModel
from agent.state.models import ModuleTask


class ModuleDispatchPayload(RCABaseModel):
    """Send() payload for the `module_subgraph` node. Deliberately NOT the
    full AgentState -- each parallel Send-branch only needs the one
    ModuleTask it is responsible for.

    Lives in its own module (rather than alongside routing.py or
    module_subgraph_node.py) purely to avoid a circular import: routing.py
    needs it to build Send() objects, and module_subgraph_node.py needs it
    as the adapter's input type, and module_subgraph_node.py also needs to
    build the Module ReAct Subgraph, whose own routing functions live in
    routing.py.
    """

    module_task: ModuleTask
    run_id: str
