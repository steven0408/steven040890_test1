from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable

from langchain_core.runnables import RunnableConfig
from langgraph.checkpoint.base import BaseCheckpointSaver

from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.capability_executor import ModuleCapabilityRuntime
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.graph.nodes.module_dispatch_payload import ModuleDispatchPayload
from agent.planning.policies.base import ModulePlanningPolicy
from agent.state.models import Budget, ModuleState
from agent.tools.base import MockTool


@dataclass(frozen=True)
class ModuleRuntimeConfig:
    """Graph-construction-time wiring for one module_type: which policy,
    executor path, and budget its Module ReAct Subgraph runs with. This is
    configuration, not run data -- it never goes into AgentState/ModuleState.

    Exactly one of `tool` / `capability` must be set:

      - `tool`: legacy/test adapter -- the Phase 3-5A direct-tool executor
        (`Objective -> Executor -> Tool`). Still used by the Harness-
        mechanics regression tests (Phase 2/4A/4B/resume-replay/human-audit)
        that validate fan-out/interrupt/checkpoint behavior with
        DeterministicMockPolicy, independent of any real domain capability.
      - `capability`: the production capability execution path (Phase
        5B-2/5B-2.1) -- `Objective -> Executor -> CapabilityResolver ->
        Skill -> SkillRunner -> ToolExecutionManager -> ToolRegistry ->
        Tool`. This is what a real domain module (OEE today) runs in
        production-style wiring.
    """

    policy: ModulePlanningPolicy
    budget: Budget
    tool: MockTool | None = None
    capability: ModuleCapabilityRuntime | None = None

    def __post_init__(self) -> None:
        if (self.tool is None) == (self.capability is None):
            raise ValueError(
                "ModuleRuntimeConfig requires exactly one of `tool` (legacy/test adapter) or "
                "`capability` (production capability execution path)"
            )


def make_module_subgraph_node(
    runtime_by_type: dict[str, ModuleRuntimeConfig],
    checkpointer: BaseCheckpointSaver,
    *,
    now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
):
    """Adapter bridging the parent AgentState graph's Send-dispatch to the
    real, reusable Module ReAct Subgraph (agent/graph/nodes/module/module_subgraph.py):

        ModuleDispatchPayload -> build_initial_module_state -> subgraph.invoke(state, config)
        -> final ModuleState -> {"module_states": {module_id: final_state}}

    `checkpointer` MUST be the *same instance* the parent graph itself is
    compiled with (see build_phase2_graph). This is required for correct
    behavior, not just for sharing storage -- see the Phase 4B-1 report for
    the empirical finding: compiling the child with `checkpointer=True`
    (LangGraph's "inherit from context" sentinel) silently returns another
    Send branch's stale result on resume once more than one module is
    dispatched under the same thread. Passing the identical checkpointer
    object explicitly to both parent.compile() and this child.compile()
    avoids that; `config` must also be threaded through to
    `subgraph.invoke()` (not called bare) so the child's checkpoint nests
    under the correct Send-task-derived checkpoint_ns.

    This is still a node *function* wrapping a nested `.invoke()` call, not
    LangGraph's same-schema "add compiled graph directly as node" pattern
    (which does not apply here: ModuleDispatchPayload/ModuleState do not
    share channel names with AgentState). It is, empirically, sufficient for
    child checkpoints to nest correctly, be inspectable via
    `parent.get_state(config, subgraphs=True)`, and for interrupt()/resume
    to target the right branch.
    """

    def module_subgraph_node(payload: ModuleDispatchPayload, config: RunnableConfig) -> dict:
        task = payload.module_task
        runtime = runtime_by_type[task.module_type]

        subgraph = build_module_react_subgraph(runtime.policy, tool=runtime.tool, capability=runtime.capability)
        app = subgraph.compile(checkpointer=checkpointer)

        # Goal.task_type -> Analyzer's ModuleTask.task_type -> here, end to
        # end -- never re-inferred at module bootstrap (Phase 5B-2.1).
        initial_state = build_initial_module_state(task, runtime.budget, run_id=payload.run_id, task_type=task.task_type)

        # Module started_at (Phase 8A-1 item 2/3): stamped once per
        # *physical* invocation of this node. In the normal case (no
        # already-terminal sibling replay) this function is called exactly
        # once per module, so this is also the one true logical
        # started_at. `app.get_state(config)` was tried and rejected here
        # (see the Phase 8A-1 report) -- empirically it does not resolve
        # this child subgraph's own checkpoint the way `app.invoke()`
        # itself does, for either a genuine resume or a sibling replay;
        # reading it and finding nothing would have produced a *wrong*
        # value with false confidence, not a safe fallback. See
        # module_completion_check.py and the Phase 8A-1 report for the
        # one narrow case (a Send-level pending-superstep replay triggered
        # by an intervening `app.update_state()` call, Phase 5B-1.1) where
        # this and `completed_at` are known, documented, and tested to
        # drift -- the exact same limitation `ToolCallRecord` timestamps
        # already have in that scenario.
        initial_state = initial_state.model_copy(update={"started_at": now_fn()})

        result = app.invoke(initial_state, config)
        final_module_state = ModuleState.model_validate(result)

        return {"module_states": {task.module_id: final_module_state}}

    return module_subgraph_node
