"""Standardizer LLM node (Phase WB-3F.4) -- extends the pre-existing
deterministic `standardizer_mock` (unchanged, still the graph's default and
this service's own fallback) with real, LLM-backed structured
RequestConstraint extraction. Mirrors agent/graph/nodes/analyzer_llm.py's
exact discipline:

    Standardizer Node -> StandardizerContextBuilder -> LLMRouter -> LLMClient
        -> typed StandardizerExtraction -> Node updates AgentState

`StandardizerLLMService.decide()` is the testable service (no LangGraph
dependency); `make_standardizer_llm_node` wraps it into a node function.
Task-type inference is UNCHANGED from `standardizer_mock` -- this node only
adds constraint extraction on top; TaskType ownership stays with Analyzer
(or the same provisional deterministic inference `standardizer_mock` always
used), per item 7's "Standardizer... does not choose Tools/capability/root
cause/analysis path" boundary generalized to "does not own TaskType either."
"""
from datetime import datetime, timezone

from agent.llm.context.standardizer_context import StandardizerContextBuilder
from agent.llm.models import DecisionSource, LLMInvalidOutputError
from agent.llm.prompts.standardizer import StandardizerExtraction, build_standardizer_messages
from agent.llm.router import LLMRouter, LLMRouterError
from agent.planning.task_type_inference import infer_task_type_deterministic
from agent.state.enums import StandardizerDecision as StandardizerRoutingDecision
from agent.state.models import ControlSignals, Goal, GoalScope, NormalizedRequest
from agent.state.scope import ConstraintSource, RequestConstraint
from agent.state.state import AgentState

__all__ = ["StandardizerSemanticValidationError", "StandardizerOutcome", "StandardizerLLMService", "make_standardizer_llm_node", "validate_standardizer_extraction"]

_DATE_LIKE_DIMENSIONS = {"date", "production_date", "snapshot_date", "release_date", "date_range"}


class StandardizerSemanticValidationError(LLMInvalidOutputError):
    """A subclass, not a new sibling exception -- LLMRouter's failure
    handling is isinstance-based specifically so this is treated exactly
    like the client itself producing invalid structured output: recorded
    INVALID_OUTPUT, retried, and (once retries are exhausted) triggers
    StandardizerLLMService's deterministic fallback."""


def validate_standardizer_extraction(extraction: StandardizerExtraction) -> None:
    """Semantic validation beyond pydantic schema validation (item 14/56):
    catches an LLM producing a structurally-valid-but-nonsensical
    extraction. Deliberately does NOT validate "does this customer/
    operation value exist in a real registry" -- no such registry exists
    (item 56's own explicit boundary) -- only shape-level sanity."""
    if not extraction.normalized_text.strip():
        raise StandardizerSemanticValidationError("normalized_text must not be empty")

    seen: set[tuple] = set()
    for constraint in extraction.constraints:
        if not constraint.dimension.strip():
            raise StandardizerSemanticValidationError("a constraint's dimension must not be empty")
        # Catches the exact WB-3F.3-class bug (a date represented as a
        # generic filter instead of the dedicated `time` field) at the
        # Standardizer layer this time, before it can ever propagate.
        if constraint.dimension.strip().lower() in _DATE_LIKE_DIMENSIONS:
            raise StandardizerSemanticValidationError(
                f"constraint dimension '{constraint.dimension}' is a date-like dimension -- dates belong in the `time` field, never in `constraints`"
            )
        key = (constraint.dimension, constraint.operator.value, tuple(constraint.value) if isinstance(constraint.value, list) else constraint.value)
        if key in seen:
            raise StandardizerSemanticValidationError(f"duplicate constraint for dimension '{constraint.dimension}'")
        seen.add(key)


class StandardizerOutcome:
    """Not persisted -- pairs the StandardizerExtraction the node applies
    to AgentState with provenance, mirroring AnalyzerOutcome exactly."""

    __slots__ = ("extraction", "source", "fallback_reason")

    def __init__(self, extraction: StandardizerExtraction, source: DecisionSource, fallback_reason: str | None = None):
        self.extraction = extraction
        self.source = source
        self.fallback_reason = fallback_reason


def _deterministic_fallback_extraction(raw_text: str) -> StandardizerExtraction:
    """Matches `standardizer_mock`'s own existing behavior EXACTLY (item 9):
    preserves normalized_text verbatim, fabricates NOTHING -- no plant, no
    time, no constraints. `standardizer_mock` never attempted deterministic
    plant/date extraction before this phase either (confirmed by reading
    it), so this fallback introduces no new regex/keyword parser -- it is
    the literal pre-existing behavior, now given a name and a
    DecisionSource.FALLBACK marker it never had before."""
    return StandardizerExtraction(normalized_text=raw_text, plant_id=None, time=None, constraints=[], reasoning_summary="Deterministic fallback (LLM unavailable) -- no structured extraction attempted.")


class StandardizerLLMService:
    def __init__(self, context_builder: StandardizerContextBuilder, router: LLMRouter, *, route: str = "standardizer"):
        self._context_builder = context_builder
        self._router = router
        self._route = route

    def decide(self, state: AgentState) -> StandardizerOutcome:
        context = self._context_builder.build(raw_text=state.user_request.raw_text, factory_id=state.factory_context.factory_id)
        messages = build_standardizer_messages(context)

        try:
            router_outcome = self._router.call(
                self._route, messages, StandardizerExtraction, run_id=state.run_id, module_id=None, node="standardizer",
                validate=validate_standardizer_extraction,
            )
            return StandardizerOutcome(extraction=router_outcome.parsed_output, source=DecisionSource.LLM)
        except LLMRouterError as exc:
            fallback = _deterministic_fallback_extraction(state.user_request.raw_text)
            return StandardizerOutcome(extraction=fallback, source=DecisionSource.FALLBACK, fallback_reason=str(exc))


def make_standardizer_llm_node(service: StandardizerLLMService):
    def standardizer_llm(state: AgentState) -> dict:
        outcome = service.decide(state)
        extraction = outcome.extraction

        constraints = [
            RequestConstraint(dimension=c.dimension, operator=c.operator, value=c.value, source=ConstraintSource.USER_EXPLICIT)
            for c in extraction.constraints
        ]
        time_range_start = extraction.time.date or extraction.time.start if extraction.time is not None else None
        time_range_end = extraction.time.date or extraction.time.end if extraction.time is not None else None

        normalized_request = NormalizedRequest(
            request_id=state.user_request.request_id,
            normalized_text=extraction.normalized_text,
            factory_id=state.factory_context.factory_id,
            plant_id=extraction.plant_id,
            time_range_start=datetime.combine(time_range_start, datetime.min.time()) if time_range_start else None,
            time_range_end=datetime.combine(time_range_end, datetime.min.time()) if time_range_end else None,
            constraints=constraints,
        )
        # TaskType is still the SAME provisional deterministic inference
        # standardizer_mock always used -- this node adds constraint
        # extraction, it does not change TaskType ownership (Analyzer's
        # own decision, when an LLM Analyzer is wired in, still overwrites
        # this exactly as it always has).
        task_type = infer_task_type_deterministic(state.user_request.raw_text)
        goal = Goal(
            goal_id=f"{state.run_id}-goal", raw_statement=state.user_request.raw_text,
            normalized_statement=extraction.normalized_text, task_type=task_type, scope=GoalScope(),
        )

        updates: dict = {
            "normalized_request": normalized_request,
            "global_goal": goal,
            "control": ControlSignals(standardizer_decision=StandardizerRoutingDecision.OK, coordinator_decision=state.control.coordinator_decision),
        }
        if state.started_at is None:
            updates["started_at"] = datetime.now(timezone.utc)
        return updates

    return standardizer_llm
