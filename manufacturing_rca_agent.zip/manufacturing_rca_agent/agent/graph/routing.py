from langgraph.graph import END
from langgraph.types import Send

from agent.graph.nodes.module_dispatch_payload import ModuleDispatchPayload
from agent.state.enums import CoordinatorDecision, GateDecision, ModulePlannerDecision, ModuleStatus, ReflectorVerdict
from agent.state.models import ModuleState
from agent.state.state import AgentState


def route_from_coordinator(state: AgentState) -> str | list[Send]:
    """Maps `control.coordinator_decision` (computed by the Module
    Coordinator node) to a destination. This is the only place that
    decides *where* the graph goes after Coordinator -- the node itself
    only decides *what* to do.
    """
    decision = state.control.coordinator_decision

    if decision == CoordinatorDecision.DISPATCH:
        task_by_id = {task.module_id: task for task in state.selected_modules}
        return [
            Send("module_subgraph", ModuleDispatchPayload(module_task=task_by_id[module_id], run_id=state.run_id))
            for module_id in state.module_dispatch.in_flight
        ]

    if decision == CoordinatorDecision.ALL_TERMINAL:
        return "global_completion_check"

    raise NotImplementedError(
        "CoordinatorDecision.WAIT is unreachable with the synchronous module "
        "subgraph adapter (each dispatched module resolves fully within one "
        "parent-graph step, since the nested subgraph is invoked "
        "synchronously). True async/interruptible module execution in the "
        "Human Gate phase will need this branch implemented."
    )


# --- Module ReAct Subgraph routing (agent/graph/nodes/module/*) -----------
#
# Same principle as above: each module-level node decides *what* to do and
# writes that decision into `module_state.control`; these functions only
# decide *where* that leads.


def route_from_module_planner(module_state: ModuleState) -> str:
    if module_state.control.planner_decision == ModulePlannerDecision.DISPATCH:
        return "execution_gate"
    return "module_completion_check"  # NO_VIABLE_OBJECTIVE


def route_from_module_gate(module_state: ModuleState) -> str:
    if module_state.control.gate_decision == GateDecision.PASS:
        return "module_executor"
    if module_state.control.gate_decision == GateDecision.REJECTED:
        return "module_planner"
    raise NotImplementedError(
        f"Unexpected gate_decision {module_state.control.gate_decision!r}: Execution "
        "Gate should only ever resolve (post-interrupt) to PASS or REJECTED."
    )


def route_from_module_reflector(module_state: ModuleState) -> str:
    if module_state.control.reflector_verdict == ReflectorVerdict.CANDIDATE_COMPLETE:
        return "module_completion_check"
    return "module_planner"  # CONTINUE or RETRY


def route_from_module_completion_check(module_state: ModuleState) -> str:
    if module_state.status == ModuleStatus.RUNNING:
        return "module_planner"
    return END
