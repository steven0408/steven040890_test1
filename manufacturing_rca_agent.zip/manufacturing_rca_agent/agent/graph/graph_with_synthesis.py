"""build_phase6_graph (Phase 6B item 15) -- `build_phase2_graph` (agent/
graph/graph.py) plus a terminal Synthesis step, kept as a SEPARATE graph
builder rather than modifying `build_phase2_graph` in place:

    START -> Standardizer -> Analyzer -> Module Coordinator
          -> Module Subgraph (fan-out/fan-in, unchanged)
          -> Global Completion Check -> Synthesis -> END

This is the minimal-blast-radius option the spec explicitly allows when
wiring Synthesis into the real parent graph would otherwise touch
Coordinator/Global-Completion-Check semantics or the 356+ tests already
exercising `build_phase2_graph`'s exact topology: every node this graph
uses (`standardizer_mock`, `analyzer`, `module_coordinator`,
`module_subgraph`, `global_completion_check`) is the *same*, unmodified
node function `build_phase2_graph` already uses -- only `synthesis` is
new, and it never mutates AgentState fields any other node reads. Nothing
about Coordinator/Global Completion Check's own decision logic changed to
make this possible.
"""
from typing import Callable

from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.graph import END, START, StateGraph

from agent.graph.nodes.analyzer_mock import analyzer_mock
from agent.graph.nodes.global_completion_check import global_completion_check
from agent.graph.nodes.module_coordinator import module_coordinator
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig, make_module_subgraph_node
from agent.graph.nodes.standardizer_mock import standardizer_mock
from agent.graph.routing import route_from_coordinator
from agent.state.state import AgentState


def build_phase6_graph(
    module_runtime: dict[str, ModuleRuntimeConfig],
    checkpointer: BaseCheckpointSaver,
    synthesis_node: Callable[[AgentState], dict],
    *,
    analyzer: Callable[[AgentState], dict] | None = None,
    standardizer: Callable[[AgentState], dict] | None = None,
) -> StateGraph:
    """Same construction contract as `build_phase2_graph` (same
    `module_runtime`/`checkpointer`/`analyzer`/`standardizer` semantics --
    see its own docstring), plus a required `synthesis_node` (pass
    `make_synthesis_node(...)` for deterministic-only, or
    `make_llm_synthesis_node(service)` for Mock/real-LLM-backed with
    built-in fallback -- agent/graph/nodes/synthesis.py)."""
    graph = StateGraph(AgentState)

    graph.add_node("standardizer", standardizer or standardizer_mock)
    graph.add_node("analyzer", analyzer or analyzer_mock)
    graph.add_node("module_coordinator", module_coordinator)
    graph.add_node("module_subgraph", make_module_subgraph_node(module_runtime, checkpointer))
    graph.add_node("global_completion_check", global_completion_check)
    graph.add_node("synthesis", synthesis_node)

    graph.add_edge(START, "standardizer")
    graph.add_edge("standardizer", "analyzer")
    graph.add_edge("analyzer", "module_coordinator")
    graph.add_conditional_edges(
        "module_coordinator",
        route_from_coordinator,
        ["module_subgraph", "global_completion_check"],
    )
    graph.add_edge("module_subgraph", "module_coordinator")
    graph.add_edge("global_completion_check", "synthesis")
    graph.add_edge("synthesis", END)

    return graph
