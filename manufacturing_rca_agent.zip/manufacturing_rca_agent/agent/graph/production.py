"""Phase 8B-1 Part H (extended Phase PROD-1): the production entrypoint
boundary.

`build_phase2_graph`/`build_phase6_graph` (agent/graph/graph.py,
agent/graph/graph_with_synthesis.py) default their `analyzer` parameter to
`analyzer_mock`, and their `standardizer` parameter to `standardizer_mock`
-- both Phase 2 legacy/test fixtures (`analyzer_mock` hardcodes
OEE/Output/WIP module selection and ignores TaskType; `standardizer_mock`
is deterministic keyword extraction, no LLM). Those defaults exist so the
~90 Harness-mechanics regression tests written against them keep working
unchanged; intentionally NOT removed or changed (that would be exactly the
kind of LangGraph-topology/existing-node change this phase's scope guard
forbids).

The risk those defaults create is a silent one: a real caller building
"the" production graph can simply forget to pass `analyzer=...`/
`standardizer=...` and get the Mock nodes without any error -- the graph
still runs, it just silently never reaches the real LLM-backed reasoning.

`build_production_graph()`/`build_production_graph_with_synthesis()` are
the fix: thin wrappers with REQUIRED `analyzer`/`standardizer` parameters
(no default at all), so it is not physically possible to call them and
silently fall back to either Mock node. They add no new node, no new edge,
no new topology -- they delegate to the exact same `build_phase2_graph`/
`build_phase6_graph` every existing test already uses. This is the one
function a real deployment's own entrypoint script (agent_api/service.py)
should call, never `build_phase2_graph`/`build_phase6_graph` directly with
a bare/omitted `analyzer`/`standardizer`.

See `tests/test_analyzer_mock_production_boundary.py` and
`tests/test_standardizer_mock_production_boundary.py` for the regression
guards: `agent/bootstrap.py` (the composition root) never imports
`analyzer_mock`/`standardizer_mock`, and these two wrappers raise
`TypeError` if called without an explicit `analyzer`/`standardizer`.
"""
from typing import Callable

from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.graph import StateGraph

from agent.graph.graph import build_phase2_graph
from agent.graph.graph_with_synthesis import build_phase6_graph
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig
from agent.state.state import AgentState


def build_production_graph(
    module_runtime: dict[str, ModuleRuntimeConfig],
    checkpointer: BaseCheckpointSaver,
    *,
    analyzer: Callable[[AgentState], dict],
    standardizer: Callable[[AgentState], dict],
) -> StateGraph:
    """Same as `build_phase2_graph`, except `analyzer`/`standardizer` are
    required, not optional -- pass `make_analyzer_llm_node(service)`
    (agent/graph/nodes/analyzer_llm.py) and `make_standardizer_llm_node(service)`
    (agent/graph/nodes/standardizer_llm.py), never `analyzer_mock`/
    `standardizer_mock`."""
    return build_phase2_graph(module_runtime, checkpointer, analyzer=analyzer, standardizer=standardizer)


def build_production_graph_with_synthesis(
    module_runtime: dict[str, ModuleRuntimeConfig],
    checkpointer: BaseCheckpointSaver,
    synthesis_node: Callable[[AgentState], dict],
    *,
    analyzer: Callable[[AgentState], dict],
    standardizer: Callable[[AgentState], dict],
) -> StateGraph:
    """Same as `build_phase6_graph`, except `analyzer`/`standardizer` are
    required, not optional."""
    return build_phase6_graph(module_runtime, checkpointer, synthesis_node, analyzer=analyzer, standardizer=standardizer)
