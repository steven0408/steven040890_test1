from typing import Callable

from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.graph import END, START, StateGraph

from agent.graph.nodes.analyzer_mock import analyzer_mock
from agent.graph.nodes.global_completion_check import global_completion_check
from agent.graph.nodes.module_coordinator import module_coordinator
from agent.graph.nodes.module_subgraph_node import ModuleRuntimeConfig, make_module_subgraph_node
from agent.graph.nodes.standardizer_mock import standardizer_mock
from agent.graph.routing import route_from_coordinator
from agent.state.state import AgentState


def build_phase2_graph(
    module_runtime: dict[str, ModuleRuntimeConfig],
    checkpointer: BaseCheckpointSaver,
    *,
    analyzer: Callable[[AgentState], dict] | None = None,
    standardizer: Callable[[AgentState], dict] | None = None,
) -> StateGraph:
    """Multi-module fan-out/fan-in shell (originally Phase 2, now running
    the real Module ReAct Subgraph natively -- Phase 4B-1):

        START -> Standardizer -> Analyzer -> Module Coordinator
              -> Module Subgraph (real Planner/Gate/Executor/Reflector/
                 Completion-Check loop, fan-out via Send, checkpointed)
              -> Module Coordinator (fan-in / re-check)
              -> Global Completion Check -> END

    `module_runtime` maps module_type -> ModuleRuntimeConfig (policy, tool,
    budget) so each module_type can behave differently in a test.

    `checkpointer` is REQUIRED here (not just accepted at `.compile()` time
    afterwards) because each module subgraph is compiled internally with
    this exact same instance -- see module_subgraph_node.py for why. The
    caller must compile the returned graph with this *same* checkpointer
    object:

        checkpointer = InMemorySaver()
        graph = build_phase2_graph(runtime, checkpointer)
        app = graph.compile(checkpointer=checkpointer)

    Still no real domain policy / Synthesis / Evaluator / Learning / Human
    interrupt -- those are separate later phases.

    `analyzer` (Phase 5B-3A): defaults to the legacy deterministic
    `analyzer_mock` (unchanged since Phase 2 -- hardcoded OEE/Output/WIP
    selection, ignores TaskType) so every pre-5B-3 caller keeps its exact
    existing behavior. Pass `make_analyzer_llm_node(service)` to opt into
    the LLM-backed Analyzer (agent/graph/nodes/analyzer_llm.py), which reads
    `state.global_goal`/`ModuleRegistry` and actually selects modules based
    on the inferred TaskType.

    `standardizer` (Phase PROD-1): same optional-override shape as
    `analyzer`, added for the identical reason -- defaults to
    `standardizer_mock` (deterministic keyword-based extraction, unchanged)
    so every existing caller keeps its exact behavior. Pass
    `make_standardizer_llm_node(service)` (agent/graph/nodes/standardizer_llm.py)
    to opt into the LLM-backed Standardizer. No new node, no new edge --
    only which callable `graph.add_node("standardizer", ...)` uses.
    """
    graph = StateGraph(AgentState)

    graph.add_node("standardizer", standardizer or standardizer_mock)
    graph.add_node("analyzer", analyzer or analyzer_mock)
    graph.add_node("module_coordinator", module_coordinator)
    graph.add_node("module_subgraph", make_module_subgraph_node(module_runtime, checkpointer))
    graph.add_node("global_completion_check", global_completion_check)

    graph.add_edge(START, "standardizer")
    graph.add_edge("standardizer", "analyzer")
    graph.add_edge("analyzer", "module_coordinator")
    graph.add_conditional_edges(
        "module_coordinator",
        route_from_coordinator,
        ["module_subgraph", "global_completion_check"],
    )
    graph.add_edge("module_subgraph", "module_coordinator")
    graph.add_edge("global_completion_check", END)

    return graph
