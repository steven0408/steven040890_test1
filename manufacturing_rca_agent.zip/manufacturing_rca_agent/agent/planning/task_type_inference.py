"""Deterministic/mock TaskType inference -- a placeholder for real language
understanding, shared by exactly two call sites so there is exactly one
place this logic lives (Phase 5B-3 principle: avoid two independently
maintained sources of truth):

  - Standardizer (agent/graph/nodes/standardizer_mock.py) uses it to seed a
    *provisional* Goal.task_type before Analyzer has run -- Goal requires
    the field, and Standardizer runs first.
  - AnalyzerLLMService (agent/graph/nodes/analyzer_llm.py) uses it as the
    deterministic fallback when the LLM call fails (timeout / provider
    error / invalid structured output) -- never a second independent guess.

Production's *authoritative* TaskType, when an LLM-backed Analyzer node is
wired in, is always whatever Analyzer's own decision (LLM or fallback)
ends up being -- it overwrites Standardizer's provisional Goal. When only
the legacy deterministic `analyzer_mock` is wired in (no LLM), Standardizer's
inference is what production actually runs on, unchanged from Phase 5B-2.1.
"""
from agent.state.enums import TaskType

_TASK_TYPE_KEYWORDS: list[tuple[TaskType, tuple[str, ...]]] = [
    (TaskType.RCA, ("為什麼", "why", "root cause", "原因", "下降")),
    (TaskType.ANALYSIS, ("哪些", "which", "比較差", "worse", "screen", "rank")),
    (TaskType.INFORMATION, ("多少", "what is", "current status", "現在")),
]


def infer_task_type_deterministic(raw_text: str) -> TaskType:
    lowered = raw_text.lower()
    for task_type, keywords in _TASK_TYPE_KEYWORDS:
        if any(keyword in lowered for keyword in keywords):
            return task_type
    return TaskType.RCA
