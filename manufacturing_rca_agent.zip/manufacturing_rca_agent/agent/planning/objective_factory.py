"""Objective materialization (Phase 5C-2) -- turns an LLM-proposable
`ObjectiveProposal` into a real `Objective`, assigning exactly the fields an
LLM must never control: `objective_id` and `attempt_count`, via the same
round-number convention `OEEPlanningPolicy`/`DeterministicMockPolicy` each
already use (`f"{module_id}-obj-{round_number}"`, `round_number =
len(objective_history) + 1`). `status`/`created_step`/the `ObjectiveRecord`
itself stay Module Planner's (`module_planner.py::_build_dispatch_update`)
exclusive job, unchanged -- this function only produces the `Objective` that
function receives, same as any `ModulePlanningPolicy.propose_next_objective`
return value always has.

Not domain-specific: any `ModulePlanningPolicy` that wraps an LLM (not just
OEE's) can use this.
"""
from agent.llm.prompts.planner import ObjectiveProposal
from agent.state.models import ModuleState, Objective


def build_objective_from_proposal(module_state: ModuleState, proposal: ObjectiveProposal, priority: float | None) -> Objective:
    round_number = len(module_state.objective_history) + 1
    return Objective(
        objective_id=f"{module_state.module_id}-obj-{round_number}",
        description=proposal.description,
        action=proposal.action,
        capability_key=proposal.capability_key,
        target_ref=proposal.target_ref,
        scope=proposal.scope,
        expected_output=proposal.expected_output,
        priority_score=priority if priority is not None else 1.0,
        requires_permission=proposal.requires_permission,
        risk_level=proposal.risk_level,
        permission_type=proposal.permission_type,
        attempt_count=round_number,
    )
