"""Priority scoring contract (Phase 1: interface + trivial default rule).

Deliberately NOT a real scoring algorithm yet -- this is the seam Module
Coordinator (module-level dispatch priority) and Module Planner (branch /
entity-level priority) call through, so the actual scoring logic
(rule-based, ML, or LLM) can be swapped later without touching dispatch or
planning code.
"""
from typing import Protocol

from pydantic import Field

from agent.state.base import RCABaseModel


class PriorityInputs(RCABaseModel):
    abnormality: float
    contribution: float
    business_impact: float
    evidence_strength: float
    data_availability: float
    analysis_cost: float = Field(gt=0)


class PriorityScorer(Protocol):
    def score(self, inputs: PriorityInputs) -> float: ...


class DefaultRulePriorityScorer:
    """score = (abnormality * contribution * business_impact * evidence_strength * data_availability) / analysis_cost"""

    def score(self, inputs: PriorityInputs) -> float:
        numerator = (
            inputs.abnormality
            * inputs.contribution
            * inputs.business_impact
            * inputs.evidence_strength
            * inputs.data_availability
        )
        return numerator / inputs.analysis_cost
