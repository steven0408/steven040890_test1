"""ReflectionDecisionRecord / ReflectionDecisionAuditSink (Phase WB-3F) --
same "Protocol + InMemory reference impl" pattern as every other audit sink
in this codebase (PlannerDecisionAuditSink / HumanAuditSink /
ToolCallAuditSink / LLMUsageSink / ContextAuditSink). Never chain-of-thought,
only the typed decision + its provenance.

Correlation: `context_build_record_id` and `llm_call_id` let a downstream
reader answer "this reflection was based on which Context version, from
which LLM call?" -- both are `None` when `source=FALLBACK` and no LLM call
ever succeeded for this round.
"""
from datetime import datetime
from typing import Protocol

from agent.llm.models import DecisionSource
from agent.llm.prompts.reflector import ObjectiveAssessment, ReflectionVerdict
from agent.state.base import RCABaseModel


class ReflectionDecisionRecord(RCABaseModel):
    decision_record_id: str
    run_id: str
    module_id: str
    step: int
    verdict: ReflectionVerdict
    objective_assessment: ObjectiveAssessment
    is_root_cause_claimed: bool
    should_continue: bool
    source: DecisionSource
    rationale_summary: str
    context_build_record_id: str | None = None
    llm_call_id: str | None = None
    fallback_reason: str | None = None
    created_at: datetime


class ReflectionDecisionAuditSink(Protocol):
    def record(self, record: ReflectionDecisionRecord) -> None: ...

    def list_for_run(self, run_id: str) -> list[ReflectionDecisionRecord]: ...


class InMemoryReflectionDecisionAuditSink:
    def __init__(self) -> None:
        self._records: list[ReflectionDecisionRecord] = []

    def record(self, record: ReflectionDecisionRecord) -> None:
        self._records.append(record)

    def list_for_run(self, run_id: str) -> list[ReflectionDecisionRecord]:
        return [r for r in self._records if r.run_id == run_id]
