"""Contribution scoring contract (Phase 5A: interface + a trivial default
rule, same spirit as agent/planning/priority.py).

This answers a narrower question than PriorityScorer ("should we keep
investigating this?"): "how much of the aggregate problem does this one
entity/pattern represent?" A policy typically feeds a ContributionScorer's
output into priority decisions, not the other way around.
"""
from typing import Protocol

from pydantic import Field

from agent.state.base import RCABaseModel


class ContributionInputs(RCABaseModel):
    abnormality: float  # e.g. 1 - OEE, or 1 - worst dimension
    weight: float = Field(gt=0)  # e.g. production volume / business importance


class ContributionScorer(Protocol):
    def score(self, inputs: ContributionInputs) -> float: ...


class DefaultContributionScorer:
    """score = abnormality * weight"""

    def score(self, inputs: ContributionInputs) -> float:
        return inputs.abnormality * inputs.weight
