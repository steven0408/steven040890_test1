"""PlannerDecisionRecord / PlannerDecisionAuditSink (Phase 5C-2) -- same
"Protocol + InMemory reference impl" pattern as every other audit sink in
this codebase (HumanAuditSink / ToolCallAuditSink / LLMUsageSink /
ContextAuditSink). This is the future Evaluator/Learning decision audit --
never chain-of-thought, only the typed decision + its provenance.

Correlation (item 11): `context_build_record_id` and `llm_call_id` let a
future reader answer "this Objective was proposed based on which Context
version, from which LLM call?" -- both are `None` when `source=FALLBACK`
and no LLM call ever succeeded for this round.
"""
from datetime import datetime
from typing import Protocol

from agent.llm.models import DecisionSource
from agent.llm.prompts.planner import PlannerDecisionType
from agent.state.base import RCABaseModel
from agent.state.enums import ObjectiveAction
from agent.state.models import TargetRef


class PlannerDecisionRecord(RCABaseModel):
    decision_record_id: str
    run_id: str
    module_id: str
    step: int
    decision: PlannerDecisionType
    proposed_action: ObjectiveAction | None = None
    proposed_capability_key: str | None = None
    target_ref: TargetRef | None = None
    priority: float | None = None
    source: DecisionSource
    rationale_summary: str
    context_build_record_id: str | None = None
    llm_call_id: str | None = None
    fallback_reason: str | None = None
    created_at: datetime


class PlannerDecisionAuditSink(Protocol):
    def record(self, record: PlannerDecisionRecord) -> None: ...

    def list_for_run(self, run_id: str) -> list[PlannerDecisionRecord]: ...


class InMemoryPlannerDecisionAuditSink:
    def __init__(self) -> None:
        self._records: list[PlannerDecisionRecord] = []

    def record(self, record: PlannerDecisionRecord) -> None:
        self._records.append(record)

    def list_for_run(self, run_id: str) -> list[PlannerDecisionRecord]:
        return [r for r in self._records if r.run_id == run_id]
