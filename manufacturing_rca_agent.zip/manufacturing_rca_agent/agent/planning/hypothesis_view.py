"""Phase WB-3F.1 (item 13/18): `ModuleState.hypotheses` is, and remains,
`Annotated[list[Hypothesis], append_list]` -- an append-only Core reducer,
unchanged this phase (a real reducer/schema change would be a Stop-Gate
item; this file avoids needing one at all). "Updating" a hypothesis means
appending a NEW `Hypothesis` record that reuses the SAME `hypothesis_id`
with a revised `status`/`confidence` -- the convention this module makes
explicit and enforces everywhere a reader needs "the current view": the
LAST entry for a given `hypothesis_id` (append order = chronological) is
authoritative; earlier entries for that id are its history, not separate
hypotheses. `LLMReflectionPolicy`, `PlannerContextBuilder`, and
`ReflectorContextBuilder` all read hypotheses through this one helper so
the convention can never silently drift between them.
"""
from agent.state.models import Hypothesis


def latest_hypotheses(hypotheses: list[Hypothesis]) -> list[Hypothesis]:
    """Dedupe by `hypothesis_id`, keeping each id's most recently appended
    entry, in first-seen order (so a hypothesis' position in a rendered
    list stays stable across updates -- only its shown status/confidence
    changes)."""
    latest: dict[str, Hypothesis] = {}
    for h in hypotheses:
        latest[h.hypothesis_id] = h
    return list(latest.values())
