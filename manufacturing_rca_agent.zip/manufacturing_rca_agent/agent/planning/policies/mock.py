from agent.planning.policies.base import DomainStateUpdates, FindingDescription
from agent.state.base import RCABaseModel
from agent.state.enums import ObjectiveAction, ObjectiveStatus, ObservationStatus, RiskLevel, TargetRefType
from agent.state.models import ModuleState, Objective, TargetRef


class PermissionSpec(RCABaseModel):
    """Marks a source as permission-gated: any Objective the policy proposes
    against it comes out with `requires_permission=True` so Execution Gate
    raises a PERMISSION_REQUIRED interrupt instead of passing straight
    through."""

    permission_type: str
    risk_level: RiskLevel = RiskLevel.MEDIUM


class Requirement(RCABaseModel):
    """One sequential requirement within a DeterministicMockPolicy: an
    ordered list of fallback sources, and how much SUCCESS evidence from
    those sources is needed before this requirement counts as satisfied.

    `restricted_sources` marks a subset of `sources` as permission-gated
    (see PermissionSpec) -- a source not listed there is queried freely.
    """

    sources: list[str]
    sufficiency_evidence_count: int = 1
    restricted_sources: dict[str, PermissionSpec] = {}


def _source_of(observation) -> str:
    return observation.tool_name.split(":", 1)[1]


class DeterministicMockPolicy:
    """Deterministic, domain-agnostic Phase 3/4A/4B-2 stand-in for a real
    per-module planning policy -- validates control flow, not domain
    reasoning.

    Works through `requirements` in order. For each requirement it retries
    its `sources` left-to-right, staying on a source that keeps succeeding
    (to accumulate more evidence) and only advancing to the next source when
    that source is "used up" -- either a DATA_NOT_FOUND-style observation
    error, or a Human REJECT recorded against it in `objective_history`
    (Execution Gate denying the permission it required). Both count the
    same way: this source didn't pan out, try the next one. A requirement is
    "satisfied" once enough SUCCESS evidence has been gathered from its own
    sources; it is "exhausted" once every one of its sources has
    errored/been-rejected without ever being satisfied. The policy moves to
    the next requirement once the current one is satisfied; it stops
    (returns None) the moment a requirement is exhausted without being
    satisfied, or once every requirement is satisfied.

    This is what lets a single deterministic policy express "confirm
    Availability (succeeds), then verify the exact failure mechanism (both
    known sources unavailable)" -- an earlier requirement's findings survive
    even though a later requirement never completes. The same mechanism
    expresses "try the restricted source; if Human rejects it, fall back to
    the approved alternative."

    Two ways to construct it:
        DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1)
        DeterministicMockPolicy(requirements=[Requirement(...), Requirement(...)])
    """

    def __init__(
        self,
        sources: list[str] | None = None,
        sufficiency_evidence_count: int = 1,
        requirements: list[Requirement] | None = None,
    ):
        if requirements is not None:
            if sources is not None:
                raise ValueError("pass either `sources` or `requirements`, not both")
            if not requirements:
                raise ValueError("DeterministicMockPolicy requires at least one requirement")
            self.requirements = requirements
        else:
            if not sources:
                raise ValueError("DeterministicMockPolicy requires at least one source")
            self.requirements = [Requirement(sources=sources, sufficiency_evidence_count=sufficiency_evidence_count)]

    def _requirement_progress(self, requirement: Requirement, module_state: ModuleState) -> tuple[int, int]:
        """Returns (success_count, used_up_count) for this requirement's own
        sources, derived purely by replaying module_state's observations and
        objective_history -- no separate counters are stored anywhere.
        `used_up_count` folds together both observation ERRORs and
        Human-REJECTED objectives against this requirement's sources, since
        both mean "this source didn't pan out, move to the next one."
        """
        relevant_obs = [obs for obs in module_state.observations if _source_of(obs) in requirement.sources]
        successes = sum(1 for obs in relevant_obs if obs.status == ObservationStatus.SUCCESS)
        obs_errors = sum(1 for obs in relevant_obs if obs.status == ObservationStatus.ERROR)

        rejected = sum(
            1
            for record in module_state.objective_history.values()
            if record.target_ref.ref_id in requirement.sources and record.status == ObjectiveStatus.REJECTED
        )

        return successes, obs_errors + rejected

    def is_sufficient(self, module_state: ModuleState) -> bool:
        return all(
            self._requirement_progress(requirement, module_state)[0] >= requirement.sufficiency_evidence_count
            for requirement in self.requirements
        )

    def propose_next_objective(self, module_state: ModuleState) -> Objective | None:
        for requirement in self.requirements:
            successes, used_up = self._requirement_progress(requirement, module_state)
            if successes >= requirement.sufficiency_evidence_count:
                continue  # this requirement is satisfied -- move to the next one

            if used_up >= len(requirement.sources):
                return None  # this requirement's sources are exhausted, unsatisfied -> stop entirely

            source = requirement.sources[used_up]
            # Count from objective_history, not observations: a REJECTED
            # objective (Human denied permission before Executor ever ran)
            # never produces an observation, so counting observations would
            # reuse the same round number -- and therefore the same
            # objective_id -- for the replacement objective.
            round_number = len(module_state.objective_history) + 1
            permission_spec = requirement.restricted_sources.get(source)
            return Objective(
                objective_id=f"{module_state.module_id}-obj-{round_number}",
                description=f"Query {source} source for {module_state.module_type} (round {round_number})",
                action=ObjectiveAction.QUERY,
                target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id=source),
                expected_output="mock evidence",
                priority_score=1.0,
                attempt_count=round_number,
                requires_permission=permission_spec is not None,
                permission_type=permission_spec.permission_type if permission_spec else None,
                risk_level=permission_spec.risk_level if permission_spec else None,
            )

        return None  # every requirement satisfied

    def describe_finding(self, module_state: ModuleState) -> FindingDescription:
        return FindingDescription(
            statement=f"{module_state.module_type} analysis based on evidence gathered so far.",
            pattern="mock-pattern",
            entity_ids=[],
        )

    def derive_state_updates(self, module_state: ModuleState) -> DomainStateUpdates:
        return DomainStateUpdates()
