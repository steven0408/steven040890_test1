from typing import Protocol

from pydantic import Field

from agent.analysis.analysis_tree import AnalysisTree
from agent.state.base import RCABaseModel
from agent.state.models import Branch, EntityState, Hypothesis, Limitation, ModuleState, Objective


class DomainStateUpdates(RCABaseModel):
    """Typed return for `derive_state_updates` (Phase 5B-1 -- replaces the
    old free-form `dict`). Deliberately closed to exactly these fields: a
    policy can decide the *content* of domain state, but the schema itself
    makes it structurally impossible to sneak in an update to `status`,
    `current_objective`, or anything else Reflector doesn't own.
    `findings` is intentionally NOT here -- Finding has exactly one path
    (`describe_finding` -> Reflector), and this contract stays closed until
    a real second need for batch findings shows up.

    `limitations` (Phase WB-3C): additive -- a policy can surface
    domain-interpreted evidence gaps (no data / insufficient historical
    coverage / partial cross-source overlap / datasource unavailable /
    unsupported analysis grain) as ordinary `Limitation` records, reusing
    the exact model `module_planner.py`'s own two built-in write paths
    already populate. Reflector applies this field the same mechanical,
    non-interpreting way it applies the other three -- see
    `module_reflector.py`. Defaults to `[]`, so every policy that predates
    this field (`OEEPlanningPolicy`, and WB's own pre-WB-3C code) is
    unaffected.

    `hypotheses` (Phase WB-3F): additive, same precedent as `limitations`
    above -- `ModuleState.hypotheses` has existed since early on but had no
    writer until `LLMReflectionPolicy` (agent/planning/policies/
    llm_reflection.py) started proposing new ones from evidence. Reflector
    applies this field the same mechanical, non-interpreting way it applies
    the other four. Defaults to `[]`, so every existing policy is
    unaffected. Updating an EXISTING hypothesis's status in place (as
    opposed to proposing a new one) is out of scope this phase -- see the
    Phase WB-3F completion report's own stop-gate note.
    """

    branches: dict[str, Branch] = Field(default_factory=dict)
    entity_states: dict[str, EntityState] = Field(default_factory=dict)
    analysis_tree: AnalysisTree | None = None
    limitations: list[Limitation] = Field(default_factory=list)
    hypotheses: list[Hypothesis] = Field(default_factory=list)


class FindingDescription(RCABaseModel):
    """What a policy wants Module Reflector to record as a Finding after a
    successful observation -- the policy owns the domain interpretation
    (pattern name, which entities it's about, whether it counts as a root
    cause); Reflector just wraps it into a `Finding` with the mechanical
    fields (id, confidence tier, supporting_evidence_ids, status) it always
    controlled. Reflector still decides HYPOTHESIS vs CONFIRMED (from the
    verdict), not the policy.
    """

    statement: str
    pattern: str
    entity_ids: list[str] = []
    is_root_cause: bool = False


class ModulePlanningPolicy(Protocol):
    """Domain-strategy seam. `DeterministicMockPolicy` is the domain-agnostic
    control-flow mock; `OEEPlanningPolicy` is the first real domain policy
    (Phase 5A). Module Planner / Module Reflector don't change when a new
    one is plugged in.
    """

    def propose_next_objective(self, module_state: ModuleState) -> Objective | None: ...

    def is_sufficient(self, module_state: ModuleState) -> bool: ...

    def describe_finding(self, module_state: ModuleState) -> FindingDescription:
        """Called by Reflector right after a SUCCESS observation, to fill in
        the domain-meaningful parts of the Finding it's about to append.
        Must be safe to call every round (Reflector does) -- purely a
        stateless read of `module_state`, no side effects.
        """
        ...

    def derive_state_updates(self, module_state: ModuleState) -> DomainStateUpdates:
        """Optional extra generic-state bookkeeping a policy wants applied
        alongside Reflector's own updates this round -- Branch / EntityState
        / AnalysisTree / Limitation records derived from evidence gathered
        so far. `DomainStateUpdates()` (all empty) if nothing to add.
        Reflector applies all four fields verbatim without interpreting
        them -- domain meaning (including which gaps in evidence are
        `Limitation`-worthy) stays in the policy, not in the generic node.
        Must be safe to call every round, purely a stateless read of
        `module_state` -- a policy must never persist "already reported"
        bookkeeping on itself; if it needs to avoid re-reporting the same
        `Limitation` twice, it re-derives that by checking
        `module_state.limitations` (already-applied state), not an
        instance attribute.
        """
        ...
