"""WBPlanningPolicy (Phase WB-2C, extended Phase WB-2D) -- the first real
WB `ModulePlanningPolicy`, implementing the exact same Protocol
`OEEPlanningPolicy`/`DeterministicMockPolicy` do (`agent/planning/policies/base.py`).
Phase WB-2C scope was INFORMATION/ANALYSIS only; Phase WB-2D adds
single-module, plant-level RCA (`_propose_rca`/`_is_sufficient_rca`/
`_describe_finding_rca` below) -- cross-module RCA, Recommendation, and
action ranking remain out of scope.

Deterministic baseline (item 9/16): rule-based, not LLM-driven. This is
both the production fallback `LLMPlanningPolicy` wraps AND the regression
oracle Golden Scenario tests assert against -- the same dual role
`OEEPlanningPolicy` already plays. Per Phase WB-2D item 33: this baseline
is NOT the only legal investigation order -- a future `LLMPlanningPolicy`
wrapping this baseline may choose a different but equally valid sequence
(e.g. checking OEE before BANK); Evaluator should judge validity/evidence
support/efficiency, never "did it match the baseline's exact path".

=== Phase WB-2D: RCA design summary ===

Three RCA entry topics (item 7): OEE-oriented, WIP-oriented, Output-
oriented -- detected via the same `_detect_topic` keyword scan already
used for INFORMATION/ANALYSIS (BANK-oriented RCA is also supported for
symmetry, though no Golden Scenario requires it as an entry topic).

Single-capability topics (OEE/WIP/BANK): one Skill call already returns
BOTH the symptom (is it abnormal) and the pattern (dominant loss
category / Hold ratio / shortage ratio) -- e.g. `wb.oee_plant_status`
gives both "is ASE01's OEE low" and "downtime is the dominant loss
category" in one shot. There is no second WB capability that could add a
deeper causal mechanism at plant grain (no equipment-failure-reason field
exists at this data grain -- see item 18's explicit prohibition on
borrowing the equipment-level OEE mock dataset's Motor Failure detail).
So these topics are a genuine one-round investigation: `is_sufficient`
becomes True immediately after that one round (see the "Confirmation
rule" design note below), and the Module reaches COMPLETE with
`is_root_cause=False` -- "the investigation finished; the data simply
does not go deeper" is treated as a successfully completed RCA, not an
incomplete one. (The Phase WB-2D spec itself hedges this either way for
Scenario A/C -- "可能 PARTIAL ... 請依 generic completion semantics決定" --
this file's answer, and its reasoning, are in the Phase WB-2D report.)

Output-oriented RCA is the multi-capability case (item 7's own
"跨 Output/OEE/WIP/BANK" example): round 1 confirms the symptom via
`wb.output_comparison` (module-wide, but the Planner reads its OWN target
plant's entry out of the ranking -- never trusts the user's premise
un-checked, item 21). If the plant is not actually low relative to its
peers, the investigation stops immediately with a premise-rejected
Finding (item 19). If it IS low, the Planner walks a fixed priority order
of contributing-factor checks -- BANK, then WIP, then OEE (`_RCA_CONTRIBUTING_ORDER`,
matching the Phase WB-2D spec's own item 41 worked example, which checks
BANK immediately after OUTPUT) -- stopping as soon as one comes back
elevated/abnormal (a supported causal candidate, still `is_root_cause=False`)
and re-reading each round's ACTUAL evidence before deciding the next step
(never a hardcoded Output->Bank->WIP workflow -- see `_propose_output_rca`).
A contributing factor that comes back NORMAL genuinely weakens that
hypothesis and the Planner moves on to the next one (item 12/46's
contradiction handling) rather than persisting with a rejected
explanation. If every contributing factor is checked and none is
abnormal, the investigation still ends cleanly with a "no specific
contributing factor confirmed" Finding -- never a fabricated cause.

Confirmation rule (item 15): `is_sufficient` for RCA is derived from a
single question -- "would `_propose_rca` still produce another
objective?" -- plus the existing WB-2C invariant that a `SUCCESS +
is_empty=True` result is never sufficient on its own. This keeps the
stopping rule genuinely evidence-driven (item 22: no `phase = 1/2/3`
state machine, no `step_count` branching) and gives one single source of
truth for "is this investigation done" shared by both `propose_next_objective`
and `is_sufficient` -- they can never disagree.

Hypothesis schema (item 13, report item 7): deliberately NOT used.
Reading `agent/planning/policies/oee.py`'s own existing RCA implementation
(Phase 5A, unchanged since) confirms OEE's RCA never populates
`module_state.hypotheses` either -- it expresses "investigated / rejected
/ candidate" purely through `Finding.status`/`confidence`/`is_root_cause`
plus `EntityState.status`, which this file follows exactly. This is not
just precedent-following: `DomainStateUpdates` (`agent/planning/policies/base.py`)
has no `hypotheses` field, and the only thing that ever applies it
(`agent/graph/nodes/module/module_reflector.py`) has no matching pass-
through -- adding one would mean touching generic Reflector, which item
31 explicitly forbids for the closely related Limitation case (see next
paragraph) and item 60 lists as a STOP trigger. Since `Finding`'s
existing fields fully express the required evidence ladder (descriptive
-> confirmed pattern -> causal candidate -> confirmed root cause, via
`status`/`confidence`/`is_root_cause` combinations -- see `_describe_finding_rca`)
without it, no STOP was needed: this is a deliberate, considered design
choice, not an oversight.

Limitation on missing data (item 31): also deliberately NOT built as a
formal `Limitation` record this phase, for the identical reason -- doing
so would require adding a `limitations` field to `DomainStateUpdates` AND
a new pass-through line in `module_reflector.py` (generic Reflector),
which item 31's own sentence explicitly forbids ("但不要修改 generic
Executor/Reflector") in the same breath it grants permission to detect
`is_empty` and "build" a Limitation. Since there is no seam through which
a built Limitation could reach `module_state.limitations` without that
forbidden edit, this file instead documents the gap richly in the
Finding's own descriptive text (continuing the WB-2C precedent for the
identical situation) and reports it as a NON-BLOCKING FUTURE architecture
gap rather than silently building an object nothing will ever read.

=== Architecture gap (Phase WB-2C item 15), RESOLVED in Phase WB-2C.1 ===

A `ModulePlanningPolicy.propose_next_objective` receives only
`module_state: ModuleState` -- confirmed by reading `agent/planning/policies/base.py`'s
own Protocol. As of Phase WB-2C, tracing the real production wiring
(`agent/graph/nodes/module_subgraph_node.py::module_subgraph_node` ->
`agent/graph/nodes/module/bootstrap.py::build_initial_module_state`) showed
`ModuleGoal.statement` was UNCONDITIONALLY set to a hardcoded
`f"Mock goal for {module_task.module_type}"` string -- no real intent ever
reached a Module's own policy. This was never a problem for OEE (a
single-topic domain -- TaskType alone already fully determines its
procedure); WB genuinely needs to disambiguate FOUR capability families
(OEE/BANK/WIP/OUTPUT) from the same (module_type=WB, task_type) pair, and
was the first Module to expose the gap.

Phase WB-2C.1 closed it at the generic layer: `AnalyzerDecision.selected_modules`
(`ModuleSelection`) now carries a required `goal_statement` field
(module-specific "what should this module accomplish?", separate from
`rationale`'s "why was this module selected?"), threaded verbatim through
`ModuleTask.goal_statement` -> `ModuleDispatchPayload` -> `build_initial_module_state`,
which now stamps `ModuleGoal.statement = module_task.goal_statement`. The
deterministic keyword-based topic detector below is UNCHANGED (per Phase
WB-2C.1 item 16's explicit instruction not to touch WBPlanningPolicy's own
algorithm) -- it now simply receives real, module-scoped goal text from
the real parent graph instead of only in tests.
"""
import re
from dataclasses import dataclass
from datetime import date, timedelta

from agent.domain.wb.historical import WBTrendDirection
from agent.domain.wb.mappings import KNOWN_PLANT_IDS
from agent.planning.policies.base import DomainStateUpdates, FindingDescription
from agent.state.enums import EntityAnalysisStatus, ObjectiveAction, ObservationStatus, TargetRefType, TaskType
from agent.state.models import EntityState, Evidence, Limitation, ModuleState, Objective, TargetRef
from agent.state.payload import PayloadRegistry
from agent.state.scope import ObjectiveScope, ScopeFilter, ScopeOperator, TimeScope, TimeScopeKind

# --- Plant entity initialization (item 6/7) ---------------------------------
#
# Plant is the only first-class WB entity this phase -- operation/customer/
# package/device/lot stay ObjectiveScope filters, never EntityState. Ownership
# is frozen here: WBPlanningPolicy (via derive_state_updates, called every
# Reflector round -- see agent/graph/nodes/module/module_reflector.py) is what
# builds/maintains agent WB entity_states; the generic Planner semantic
# validator (agent/planning/policies/llm.py) only ever *reads*
# module_state.entity_states to check existence -- it has zero WB-specific
# knowledge, no plant id is ever hardcoded there.

WB_CANONICAL_PLANTS: tuple[str, ...] = tuple(sorted(KNOWN_PLANT_IDS))


def build_wb_initial_entity_states() -> dict[str, EntityState]:
    """One EntityState per canonical WB plant (`ASE01`.."ASE08"`, currently
    5: ASE01/02/03/07/08 -- see agent/domain/wb/mappings.py::PLANT_ID_MAP,
    the single authoritative source this reads from, never a second
    hardcoded list). `current_tree_node_id="root"` -- WB doesn't build a
    real per-plant AnalysisTree this phase (item 24: INFORMATION/ANALYSIS
    don't need one), so every plant just points at the generic root node
    `build_initial_module_state` always creates. `status=SCREENED` is the
    minimal "known but not deep-dived" value (no WB-specific EntityStatus
    was added)."""
    return {
        plant_id: EntityState(
            entity_id=plant_id, entity_type="PLANT", status=EntityAnalysisStatus.SCREENED,
            current_tree_node_id="root", branch_id=None, priority_score=0.0,
        )
        for plant_id in WB_CANONICAL_PLANTS
    }


# --- Deterministic topic/plant/date detection (documented gap above) -------

_TOPIC_KEYWORDS: dict[str, tuple[str, ...]] = {
    "oee": ("oee",),
    "bank": ("bank",),
    "wip": ("wip", "hold"),
    "output": ("output",),
    "issue": ("issue", "投料"),  # Phase WB-3A
}
_DEFAULT_TOPIC = "wip"  # the only topic whose INFORMATION capability needs neither a plant nor a date (see _INFORMATION_CAPABILITIES)
_DATE_PATTERN = re.compile(r"\d{4}-\d{2}-\d{2}")


def _detect_topic(module_state: ModuleState) -> str:
    text = (module_state.goal.statement or "").lower()
    for topic, keywords in _TOPIC_KEYWORDS.items():
        if any(keyword in text for keyword in keywords):
            return topic
    return _DEFAULT_TOPIC


def _detect_plant(module_state: ModuleState) -> str | None:
    text = module_state.goal.statement or ""
    for plant_id in WB_CANONICAL_PLANTS:
        if plant_id in text:
            return plant_id
    return None


def _detect_date(module_state: ModuleState) -> date | None:
    match = _DATE_PATTERN.search(module_state.goal.statement or "")
    if match is None:
        return None
    try:
        return date.fromisoformat(match.group())
    except ValueError:
        return None


# --- Phase WB-3B: bounded historical-intent keyword detection (item 60) ----
#
# Deliberately a small, fixed keyword list -- not a large NLP dictionary
# (item 60's own explicit instruction). A future LLM Planner is the
# intended production-richer path for genuinely understanding "does this
# request want historical context"; this deterministic baseline only
# needs to catch the Golden Scenarios' own worked examples.

_HISTORICAL_KEYWORDS: tuple[str, ...] = (
    "最近", "過去", "這週", "上週", "7天", "14天", "30天",
    "trend", "history", "historical", "recurring", "repeated", "persistent",
    "持續", "反覆", "發生幾次",
)
_DEFAULT_HISTORICAL_WINDOW_DAYS = 7
_MAX_HISTORICAL_WINDOW_DAYS = 30  # item 52: a typed, explicit bound -- never silently truncated, never unbounded


def _wants_historical(module_state: ModuleState) -> bool:
    text = (module_state.goal.statement or "").lower()
    return any(keyword.lower() in text for keyword in _HISTORICAL_KEYWORDS)


def _detect_window_days(module_state: ModuleState) -> int:
    """A deliberately crude, bounded heuristic (item 60): "14"/"30" in the
    request text picks that window; otherwise the default 7-day window
    (item 55's own "最近一週" worked example). Never exceeds
    `_MAX_HISTORICAL_WINDOW_DAYS`."""
    text = module_state.goal.statement or ""
    if "30" in text:
        return min(30, _MAX_HISTORICAL_WINDOW_DAYS)
    if "14" in text:
        return min(14, _MAX_HISTORICAL_WINDOW_DAYS)
    return _DEFAULT_HISTORICAL_WINDOW_DAYS


# --- Capability tables (item 11/12/13/14) -----------------------------------


@dataclass(frozen=True)
class _CapabilitySpec:
    capability_key: str
    action: ObjectiveAction
    target_ref_type: TargetRefType
    needs_plant: bool
    needs_date: TimeScopeKind | None


_INFORMATION_CAPABILITIES: dict[str, _CapabilitySpec] = {
    "oee": _CapabilitySpec("wb.oee.plant_status", ObjectiveAction.SUMMARIZE, TargetRefType.ENTITY, True, TimeScopeKind.PRODUCTION_DATE),
    "bank": _CapabilitySpec("wb.bank.status_summary", ObjectiveAction.SUMMARIZE, TargetRefType.ENTITY, True, None),
    "wip": _CapabilitySpec("wb.wip.status_summary", ObjectiveAction.SUMMARIZE, TargetRefType.MODULE, False, None),
    "output": _CapabilitySpec("wb.output.status_summary", ObjectiveAction.SUMMARIZE, TargetRefType.MODULE, False, None),
    # Phase WB-3A: `production_date` reused as the TimeScope.kind tag for
    # ISSUE's own `release_date` business date (module docstring's own
    # documented reasoning) -- WBQueryScope.release_date, never
    # .production_date, is what's actually echoed back.
    "issue": _CapabilitySpec("wb.issue.status_summary", ObjectiveAction.SUMMARIZE, TargetRefType.ENTITY, True, TimeScopeKind.PRODUCTION_DATE),
}
_ANALYSIS_CAPABILITIES: dict[str, _CapabilitySpec] = {
    "oee": _CapabilitySpec("wb.oee.status_analysis", ObjectiveAction.ANALYZE, TargetRefType.MODULE, False, TimeScopeKind.PRODUCTION_DATE),
    "bank": _CapabilitySpec("wb.bank.aging_analysis", ObjectiveAction.ANALYZE, TargetRefType.MODULE, False, None),
    "wip": _CapabilitySpec("wb.wip.hold_analysis", ObjectiveAction.ANALYZE, TargetRefType.ENTITY, True, TimeScopeKind.SNAPSHOT_DATE),
    "output": _CapabilitySpec("wb.output.comparison", ObjectiveAction.COMPARE, TargetRefType.MODULE, False, TimeScopeKind.PRODUCTION_DATE),
    # Phase WB-3A: deliberately NO "issue" entry here. `wb.issue_trend_analysis`
    # (capability_key wb.issue.trend_analysis) exists and is fully reachable
    # via CapabilityResolver/SkillRunner/a hand-built Objective -- it is
    # NOT auto-wired into WBPlanningPolicy's own ANALYSIS dispatch this
    # phase, because doing so would require this policy to invent a "date
    # range" from a single detected date (`_detect_date` only ever finds
    # one point date), which starts to be a genuine Historical Analysis
    # planning capability -- explicitly out of scope this phase (item AA/AG)
    # and deferred to Phase WB-3B. `.get()` (not `[]`) is used below so an
    # ANALYSIS request that detects topic="issue" fails closed (no viable
    # objective -- module docstring's own already-established "never
    # guess" pattern) instead of crashing with a KeyError.
}

# --- Phase WB-2D: RCA capability table + evidence-based predicates ---------
#
# Plant-level RCA only (item 6) -- every entry is either entity-scoped
# (OEE/BANK/WIP, directly answering "this plant") or module-scoped but
# read by picking the target plant's own entry out of the result (OUTPUT,
# item 21 -- a relative "is X low" question genuinely needs the whole
# ranking, not a single-plant query). Reuses the exact same Skills
# INFORMATION/ANALYSIS already use (item 37) -- `wb.oee_plant_status` and
# `wb.bank_status_summary` had their `task_types` extended to include
# `rca` (see the Skill markdown files); `wb.wip_hold_analysis` and
# `wb.output_comparison` likewise. No `wb.rca.*` duplicate Skill exists.
_RCA_CAPABILITIES: dict[str, _CapabilitySpec] = {
    "oee": _CapabilitySpec("wb.oee.plant_status", ObjectiveAction.SUMMARIZE, TargetRefType.ENTITY, True, TimeScopeKind.PRODUCTION_DATE),
    "bank": _CapabilitySpec("wb.bank.status_summary", ObjectiveAction.SUMMARIZE, TargetRefType.ENTITY, True, None),
    "wip": _CapabilitySpec("wb.wip.hold_analysis", ObjectiveAction.ANALYZE, TargetRefType.ENTITY, True, TimeScopeKind.SNAPSHOT_DATE),
    "output": _CapabilitySpec("wb.output.comparison", ObjectiveAction.COMPARE, TargetRefType.MODULE, False, TimeScopeKind.PRODUCTION_DATE),
}

# --- Phase WB-3B: historical trend capabilities (item 8-13) -- entity-
# scoped, range-scoped (`_build_range_objective`, not `_build_objective`).
# Reused identically by both the ANALYSIS historical path
# (`_propose_historical_analysis`) and the RCA historical path
# (`_propose_historical_rca`) -- one table, two callers, never duplicated.
_HISTORICAL_TREND_CAPABILITIES: dict[str, _CapabilitySpec] = {
    "oee": _CapabilitySpec("wb.oee.trend_analysis", ObjectiveAction.ANALYZE, TargetRefType.ENTITY, True, TimeScopeKind.PRODUCTION_DATE),
    "bank": _CapabilitySpec("wb.bank.shortage_trend_analysis", ObjectiveAction.ANALYZE, TargetRefType.ENTITY, True, TimeScopeKind.SNAPSHOT_DATE),
    "wip": _CapabilitySpec("wb.wip.hold_trend_analysis", ObjectiveAction.ANALYZE, TargetRefType.ENTITY, True, TimeScopeKind.SNAPSHOT_DATE),
    "output": _CapabilitySpec("wb.output.trend_analysis", ObjectiveAction.ANALYZE, TargetRefType.ENTITY, True, TimeScopeKind.PRODUCTION_DATE),
    "issue": _CapabilitySpec("wb.issue.trend_analysis", ObjectiveAction.ANALYZE, TargetRefType.ENTITY, True, TimeScopeKind.PRODUCTION_DATE),
}
# The first cross-source capability (item 19-27) -- entity-scoped (one
# plant), range-scoped. Only ever proposed from the Output-oriented
# historical RCA chain, and only once ISSUE's own historical trend has
# ALSO shown a decline (item 28: cross-source Tool use is evidence-gated,
# never unconditional).
_CROSS_SOURCE_RELATIONSHIP_CAPABILITY = _CapabilitySpec(
    "wb.issue_output.relationship_analysis", ObjectiveAction.ANALYZE, TargetRefType.ENTITY, True, TimeScopeKind.PRODUCTION_DATE
)

# Output-oriented RCA's fixed contributing-factor check order, once the
# Output symptom itself is confirmed (item 41's own worked example checks
# BANK immediately after OUTPUT). A deterministic-baseline heuristic, not
# a claim that this is the only valid investigation order (item 33).
_RCA_CONTRIBUTING_ORDER: tuple[str, ...] = ("bank", "wip", "oee")

# Deterministic, documented thresholds (item 15) -- not statistical
# inference, just "clearly outside the golden dataset's own normal
# baseline" cutoffs, chosen with wide margins against the actual
# synthetic data (normal OEE ~85 vs Golden A's 58; normal Hold/shortage
# ~0-7% background vs Golden B/C's 70%/73.3%; normal output ~8000 vs
# Golden A/B/C's 5200-6400 -- see agent/domain/wb/synthetic.py).
_OEE_ABNORMAL_MAX = 70.0
_WIP_HOLD_ABNORMAL_MIN = 0.3
_BANK_SHORTAGE_ELEVATED_MIN = 0.5
_OUTPUT_LOW_MAX_RATIO_OF_HIGHEST = 0.85


def _oee_is_abnormal(payload) -> tuple[bool | None, object]:
    """Returns (is_abnormal, worst_row); `is_abnormal=None` if the OEE
    value itself is unrecorded (distinct from a numeric-but-normal value)."""
    worst = payload.ranking[0]
    if worst.oee is None:
        return None, worst
    return worst.oee < _OEE_ABNORMAL_MAX, worst


def _wip_is_abnormal(payload) -> bool | None:
    if payload.hold_ratio is None:
        return None
    return payload.hold_ratio >= _WIP_HOLD_ABNORMAL_MIN


def _bank_shortage_entry(payload):
    return next((c for c in payload.by_status if c.status.value == "material_shortage"), None)


def _bank_is_elevated(payload) -> bool | None:
    shortage = _bank_shortage_entry(payload)
    if shortage is None:
        return False  # no material_shortage bucket at all in this plant's records
    return shortage.ratio >= _BANK_SHORTAGE_ELEVATED_MIN


def _output_entry_for_plant(payload, plant: str):
    return next((e for e in payload.comparison if e.plant_id == plant), None)


def _output_is_low(payload, plant: str) -> bool | None:
    entry = _output_entry_for_plant(payload, plant)
    if entry is None or payload.highest is None or payload.highest.output_quantity == 0:
        return None
    return entry.output_quantity <= payload.highest.output_quantity * _OUTPUT_LOW_MAX_RATIO_OF_HIGHEST


def _contributing_factor_is_abnormal(topic: str, payload) -> bool | None:
    if topic == "bank":
        return _bank_is_elevated(payload)
    if topic == "wip":
        return _wip_is_abnormal(payload)
    if topic == "oee":
        is_abnormal, _worst = _oee_is_abnormal(payload)
        return is_abnormal
    raise AssertionError(f"unreachable: {topic!r} is not a contributing-factor topic")  # pragma: no cover


def _evidence_by_capability_key(module_state: ModuleState) -> dict[str, Evidence]:
    """Mirrors `OEEPlanningPolicy._evidence_by_target`'s exact pattern
    (agent/planning/policies/oee.py) -- keyed by `capability_key` here
    since WB Objectives already carry one (Phase WB-2B.1), a simpler key
    than OEE's `(action, target_ref.ref_id)` pair. Only ever reads
    `module_state.evidence`/`objective_history` -- stateless, replayed
    every call."""
    result: dict[str, Evidence] = {}
    for evidence in module_state.evidence:
        record = module_state.objective_history.get(evidence.objective_id)
        if record is None or record.capability_key is None:
            continue
        result[record.capability_key] = evidence
    return result


def _attempted_capability_keys(module_state: ModuleState) -> set[str]:
    """Item 50 (DataSource-unavailable alternative path): deliberately
    reads `objective_history` (every dispatched attempt, success or ERROR)
    rather than `evidence` (SUCCESS only) -- so a capability that failed
    with an ERROR observation still counts as "already tried" and is
    never retried, letting the RCA chain move on to the next viable
    contributing factor instead of looping."""
    return {r.capability_key for r in module_state.objective_history.values() if r.capability_key is not None}


def _describe_finding(capability_key: str | None, payload, target_plant: str | None) -> FindingDescription:
    """Strictly descriptive/analytical statements -- never a causal claim
    (item 22's own explicit forbidden-example list). `is_root_cause` is
    never set True anywhere in this function; WB produces no root-cause
    findings this phase."""
    entity_ids = [target_plant] if target_plant else []

    if payload.availability.is_empty:
        scope_note = f" for {target_plant}" if target_plant else ""
        return FindingDescription(
            statement=f"No data was available for capability '{capability_key}'{scope_note} in the queried scope.",
            pattern="WB No Data", entity_ids=entity_ids,
        )

    # Phase WB-3D (item 33): raw records were returned (`is_empty=False`)
    # but validation excluded every one of them -- a genuinely different
    # situation from NO_DATA, and one every capability-specific branch
    # below must never reach with an empty ranking/breakdown list (several
    # index into `payload.ranking[0]`, which would otherwise crash here
    # instead of failing gracefully).
    usable_count = getattr(payload.availability, "usable_record_count", None)
    if usable_count == 0:
        scope_note = f" for {target_plant}" if target_plant else ""
        return FindingDescription(
            statement=f"Data was returned for capability '{capability_key}'{scope_note}, but none of it passed validation -- the requested condition cannot be assessed.",
            pattern="WB All-Invalid Data", entity_ids=entity_ids,
        )

    if capability_key in ("wb.oee.plant_status", "wb.oee.status_analysis"):
        worst = payload.ranking[0]
        if worst.oee is None:
            return FindingDescription(statement=f"OEE data present for {worst.plant_id} but no numeric OEE value was recorded.", pattern="WB OEE Status", entity_ids=[worst.plant_id])
        return FindingDescription(
            statement=f"{worst.plant_id} OEE was {worst.oee}% and {worst.dominant_loss_category or 'an unrecorded category'} was the dominant recorded loss category.",
            pattern="WB OEE Status", entity_ids=[worst.plant_id],
        )
    if capability_key == "wb.bank.status_summary":
        shortage = next((c for c in payload.by_status if c.status.value == "material_shortage"), None)
        shortage_clause = f", {shortage.count} of which were material-shortage records" if shortage is not None else ""
        return FindingDescription(statement=f"{payload.total_count} BANK record(s) found for the queried snapshot{shortage_clause}.", pattern="WB Bank Status", entity_ids=entity_ids)
    if capability_key == "wb.bank.aging_analysis":
        avg_clause = f", average aging {payload.average_aging_hours:.1f}h" if payload.average_aging_hours is not None else ""
        return FindingDescription(statement=f"Aging computed for {payload.records_with_known_aging} BANK record(s){avg_clause}.", pattern="WB Bank Aging")
    if capability_key == "wb.wip.status_summary":
        return FindingDescription(statement=f"WIP total quantity was {payload.total_quantity} across {payload.lot_count} lot(s) for the queried snapshot.", pattern="WB WIP Status")
    if capability_key == "wb.wip.hold_analysis":
        ratio_str = f"{payload.hold_ratio:.1%}" if payload.hold_ratio is not None else "N/A (no lots in scope)"
        return FindingDescription(statement=f"Hold ratio was {ratio_str} ({payload.hold_lot_count}/{payload.total_lot_count} lots) for the queried snapshot.", pattern="WB WIP Hold", entity_ids=entity_ids)
    if capability_key == "wb.output.status_summary":
        return FindingDescription(statement=f"Total stage output quantity was {payload.total_output_quantity} for the queried scope.", pattern="WB Stage Output Status")
    if capability_key == "wb.output.comparison":
        lowest = payload.lowest
        if lowest is None:
            return FindingDescription(statement="No plants were available to compare.", pattern="WB Stage Output Comparison")
        return FindingDescription(statement=f"{lowest.plant_id} had the lowest stage output ({lowest.output_quantity}) among the queried plants.", pattern="WB Stage Output Comparison", entity_ids=[lowest.plant_id])
    if capability_key == "wb.issue.status_summary":
        return FindingDescription(statement=f"Total Issue quantity was {payload.total_issue_quantity} across {payload.record_count} record(s) for the queried scope.", pattern="WB Issue Status", entity_ids=entity_ids)
    if capability_key == "wb.issue.trend_analysis":
        if payload.baseline_period_average_daily is None:
            return FindingDescription(statement=f"Current-period Issue average was {payload.current_period_average_daily:.0f}/day; no baseline period was available to compare against.", pattern="WB Issue Trend", entity_ids=entity_ids)
        return FindingDescription(
            statement=(
                f"Current-period Issue average was {payload.current_period_average_daily:.0f}/day vs. baseline "
                f"{payload.baseline_period_average_daily:.0f}/day ({payload.percentage_difference:+.1f}%, trend {payload.trend_direction.value})."
            ),
            pattern="WB Issue Trend", entity_ids=entity_ids,
        )
    # Phase WB-3B: the 4 NEW historical trend capabilities (ISSUE's own
    # trend capability, above, predates them and keeps its own flat-shape
    # description for backward compatibility -- item 8) all share the one
    # `metrics: WBHistoricalMetricSummary` shape, so they share
    # `_describe_trend_finding` -- defined later in this module, called
    # here only at runtime (safe: Python resolves names at call time).
    _TREND_CAPABILITY_TOPICS = {
        "wb.oee.trend_analysis": "oee", "wb.wip.hold_trend_analysis": "wip",
        "wb.bank.shortage_trend_analysis": "bank", "wb.output.trend_analysis": "output",
    }
    if capability_key in _TREND_CAPABILITY_TOPICS:
        return _describe_trend_finding(_TREND_CAPABILITY_TOPICS[capability_key], payload.metrics, target_plant)

    return FindingDescription(statement="WB capability executed successfully.", pattern="WB", entity_ids=entity_ids)  # pragma: no cover -- defensive, every real capability_key is handled above


def _build_objective(module_state: ModuleState, task_type: TaskType, spec: _CapabilitySpec, plant: str | None, objective_date: date | None) -> Objective:
    """Shared Objective-construction, used by INFORMATION/ANALYSIS and RCA
    alike -- the only thing that varies between them is which `_CapabilitySpec`
    table/topic-detection logic picked `spec`/`plant`/`objective_date`."""
    round_number = len(module_state.objective_history) + 1
    ref_id = plant if spec.target_ref_type == TargetRefType.ENTITY else module_state.module_type

    filters = [ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value=plant)] if spec.needs_plant else []
    time_scope = TimeScope(kind=spec.needs_date, date=objective_date) if spec.needs_date is not None else None
    scope = ObjectiveScope(time=time_scope, filters=filters) if (time_scope is not None or filters) else None

    return Objective(
        objective_id=f"{module_state.module_id}-obj-{round_number}",
        description=f"WB {task_type.value} request ({spec.capability_key})",
        action=spec.action,
        capability_key=spec.capability_key,
        target_ref=TargetRef(ref_type=spec.target_ref_type, ref_id=ref_id),
        scope=scope,
        expected_output="wb capability result",
        priority_score=1.0,
        attempt_count=round_number,
    )


def _build_range_objective(
    module_state: ModuleState, task_type: TaskType, spec: _CapabilitySpec, plant: str | None, window_start: date, window_end: date
) -> Objective:
    """Phase WB-3B: the historical-capability sibling of `_build_objective`
    -- `TimeScope(start=.., end=..)` instead of a single `date`, using the
    exact same `start`/`end` range fields `ObjectiveScope.time` already
    had (item 4: no Core schema change was needed)."""
    round_number = len(module_state.objective_history) + 1
    ref_id = plant if spec.target_ref_type == TargetRefType.ENTITY else module_state.module_type

    filters = [ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value=plant)] if spec.needs_plant else []
    time_scope = TimeScope(kind=spec.needs_date, start=window_start, end=window_end) if spec.needs_date is not None else None
    scope = ObjectiveScope(time=time_scope, filters=filters) if (time_scope is not None or filters) else None

    return Objective(
        objective_id=f"{module_state.module_id}-obj-{round_number}",
        description=f"WB {task_type.value} historical request ({spec.capability_key})",
        action=spec.action,
        capability_key=spec.capability_key,
        target_ref=TargetRef(ref_type=spec.target_ref_type, ref_id=ref_id),
        scope=scope,
        expected_output="wb historical capability result",
        priority_score=1.0,
        attempt_count=round_number,
    )


# --- Phase WB-2D: RCA Finding descriptions ----------------------------------

_RCA_CANDIDATE_LABEL: dict[str, str] = {
    "bank": "Material shortage",
    "wip": "WIP Hold concentration",
    "oee": "Equipment-side OEE loss (downtime-dominated)",
}


def _describe_single_capability_rca_finding(topic: str, payload, plant: str | None, objective_date: date | None) -> FindingDescription:
    """OEE/WIP/BANK-oriented RCA: one call already carries both the
    symptom and the pattern (module docstring's "single-capability topics"
    section) -- descriptive only, `is_root_cause` always False (no
    plant-level data confirms a deeper mechanism)."""
    entity_ids = [plant] if plant else []
    date_str = objective_date.isoformat() if objective_date else "the queried date"

    if topic == "oee":
        is_abnormal, worst = _oee_is_abnormal(payload)
        if is_abnormal is None:
            return FindingDescription(statement=f"OEE data present for {plant} but no numeric OEE value was recorded on {date_str}.", pattern="WB RCA OEE", entity_ids=entity_ids)
        if not is_abnormal:
            return FindingDescription(statement=f"No abnormal OEE condition was confirmed for {plant} on {date_str} (OEE {worst.oee}%).", pattern="WB RCA OEE", entity_ids=entity_ids)
        return FindingDescription(
            statement=(
                f"{plant}'s OEE degradation on {date_str} is dominated by {worst.dominant_loss_category or 'an unrecorded category'} "
                f"(OEE {worst.oee}%); plant-level data does not provide a deeper equipment-failure reason."
            ),
            pattern="WB RCA OEE Pattern", entity_ids=entity_ids,
        )

    if topic == "wip":
        is_abnormal = _wip_is_abnormal(payload)
        if is_abnormal is None:
            return FindingDescription(statement=f"No WIP lots were in scope for {plant} on {date_str}.", pattern="WB RCA WIP", entity_ids=entity_ids)
        if not is_abnormal:
            return FindingDescription(statement=f"No abnormal WIP/Hold condition was confirmed for {plant} on {date_str} (Hold ratio {payload.hold_ratio:.1%}).", pattern="WB RCA WIP", entity_ids=entity_ids)
        return FindingDescription(
            statement=(
                f"{plant}'s WIP abnormality on {date_str} is dominated by Hold concentration "
                f"({payload.hold_lot_count}/{payload.total_lot_count} lots, {payload.hold_ratio:.1%}); "
                "the underlying reason for the Hold status is not available in this data."
            ),
            pattern="WB RCA WIP Pattern", entity_ids=entity_ids,
        )

    if topic == "bank":
        is_elevated = _bank_is_elevated(payload)
        shortage = _bank_shortage_entry(payload)
        if not is_elevated:
            return FindingDescription(statement=f"No elevated material-shortage condition was confirmed for {plant} as of {date_str}.", pattern="WB RCA Bank", entity_ids=entity_ids)
        return FindingDescription(
            statement=(
                f"{plant} shows an elevated material-shortage rate ({shortage.ratio:.1%}, {shortage.count}/{payload.total_count} records) as of {date_str}; "
                "this data alone does not confirm the ultimate supply-chain cause."
            ),
            pattern="WB RCA Bank Pattern", entity_ids=entity_ids,
        )

    raise AssertionError(f"unreachable: {topic!r} is not a single-capability RCA topic")  # pragma: no cover


_RCA_NORMAL_CONTRIBUTING_LABEL: dict[str, str] = {
    "bank": "No elevated material-shortage condition",
    "wip": "No abnormal WIP/Hold condition",
    "oee": "No abnormal OEE condition",
}


def _describe_output_rca_finding(module_state: ModuleState, plant: str | None, objective_date: date | None, latest_capability_key: str | None) -> FindingDescription:
    """Output-oriented RCA: reflects whichever phase of the investigation
    the CURRENT round represents -- symptom-check, premise-rejected, a
    just-ruled-out contributing factor (item 12/46: contradiction is
    reported, not silently absorbed), a supported candidate found, or
    exhausted with none found. Always descriptive, `is_root_cause` always
    False."""
    entity_ids = [plant] if plant else []
    date_str = objective_date.isoformat() if objective_date else "the queried date"
    evidence_by_key = _evidence_by_capability_key(module_state)
    output_key = _RCA_CAPABILITIES["output"].capability_key
    output_evidence = evidence_by_key.get(output_key)
    output_payload = PayloadRegistry.unpack(output_evidence.structured_payload) if output_evidence is not None else None

    if output_payload is None or output_payload.availability.is_empty:
        return FindingDescription(statement=f"No Output data was available for {plant} on {date_str}.", pattern="WB RCA Output No Data", entity_ids=entity_ids)

    is_low = _output_is_low(output_payload, plant)
    if not is_low:
        return FindingDescription(statement=f"No abnormally low Output was confirmed for {plant} on {date_str}.", pattern="WB RCA Output", entity_ids=entity_ids)

    entry = _output_entry_for_plant(output_payload, plant)
    output_quantity = entry.output_quantity if entry is not None else None

    for contributing_topic in _RCA_CONTRIBUTING_ORDER:
        spec = _RCA_CAPABILITIES[contributing_topic]
        existing_evidence = evidence_by_key.get(spec.capability_key)
        if existing_evidence is None:
            continue  # not yet attempted, or attempted and failed -- no verdict from this source yet
        payload = PayloadRegistry.unpack(existing_evidence.structured_payload)
        if payload.availability.is_empty:
            continue
        if _contributing_factor_is_abnormal(contributing_topic, payload):
            return FindingDescription(
                statement=(
                    f"{_RCA_CANDIDATE_LABEL[contributing_topic]} is a supported causal candidate for {plant}'s low Output "
                    f"({output_quantity}) on {date_str}; not confirmed as the root cause."
                ),
                pattern=f"WB RCA Output Candidate: {contributing_topic}", entity_ids=entity_ids,
            )
        if spec.capability_key == latest_capability_key:
            # this round's own contributing-factor check came back NORMAL --
            # report the contradiction explicitly (item 12/46) rather than a
            # generic "still investigating" placeholder, so the ruled-out
            # hypothesis is visible in the record, not just inferred later.
            return FindingDescription(
                statement=(
                    f"{_RCA_NORMAL_CONTRIBUTING_LABEL[contributing_topic]} was confirmed for {plant} as of {date_str}; "
                    f"this does not explain the low Output ({output_quantity}) -- checking the next contributing factor."
                ),
                pattern=f"WB RCA Output Ruled Out: {contributing_topic}", entity_ids=entity_ids,
            )

    attempted = _attempted_capability_keys(module_state)
    all_contributing_checked = all(_RCA_CAPABILITIES[t].capability_key in attempted for t in _RCA_CONTRIBUTING_ORDER)
    if all_contributing_checked:
        return FindingDescription(
            statement=(
                f"{plant}'s low Output ({output_quantity}) on {date_str} was confirmed, but no specific contributing factor "
                "(material availability, WIP flow, or equipment OEE loss) was confirmed as elevated; the cause remains "
                "unresolved among the checked factors."
            ),
            pattern="WB RCA Output Unresolved", entity_ids=entity_ids,
        )
    return FindingDescription(
        statement=f"{plant}'s Output was confirmed low ({output_quantity}) on {date_str}; investigating contributing factors.",
        pattern="WB RCA Output Symptom", entity_ids=entity_ids,
    )


# --- Phase WB-3B: historical/cross-source Finding descriptions -------------

_HISTORICAL_METRIC_LABEL: dict[str, str] = {
    "oee": "OEE", "wip": "WIP Hold ratio", "bank": "material-shortage ratio",
    "output": "Output", "issue": "Issue quantity",
}


def _issue_trend_metrics_adapter(payload) -> "WBHistoricalMetricSummary":
    """ISSUE's own trend result (Phase WB-3A) predates the shared
    `metrics: WBHistoricalMetricSummary` shape and keeps its own flat
    fields for backward compatibility (item 8) -- this adapts it into the
    shared shape purely for `_describe_trend_finding`'s own use, never
    mutating or re-persisting the original payload."""
    from agent.domain.wb.historical import WBHistoricalMetricSummary

    raw_direction = payload.trend_direction.value
    trend_direction = WBTrendDirection(raw_direction) if raw_direction != "unknown" else WBTrendDirection.INSUFFICIENT_DATA
    return WBHistoricalMetricSummary(
        current_value=payload.current_period_average_daily, baseline_value=payload.baseline_period_average_daily,
        absolute_deviation=payload.absolute_difference, relative_deviation=payload.percentage_difference,
        trend_direction=trend_direction, window_start=payload.scope.release_date_start or payload.current_period_start,
        window_end=payload.current_period_end, observed_days=payload.observed_days, abnormal_days=payload.abnormal_days,
        recurrence_count=payload.recurrence_count, persistence_ratio=payload.persistence_ratio,
        consecutive_abnormal_days=payload.consecutive_abnormal_days,
    )


def _describe_trend_finding(topic: str, metrics, plant: str | None) -> FindingDescription:
    """Item 41's own wording rules: "Pattern only" (single-day) vs.
    "Persistent"/"recurring" (multiple observed days) -- computed strictly
    from `metrics.recurrence_count`/`consecutive_abnormal_days`, never
    from `ObjectiveHistory` (item 17's own regression concern). Always
    `is_root_cause=False` -- a trend, however persistent, is still only a
    descriptive pattern. Takes the `WBHistoricalMetricSummary` directly
    (not the full Tool payload) -- ISSUE's own trend result (item 8) needs
    `_issue_trend_metrics_adapter` first, the 4 newer results already
    carry `payload.metrics` in this exact shape."""
    entity_ids = [plant] if plant else []
    label = _HISTORICAL_METRIC_LABEL.get(topic, topic)
    window = f"{metrics.window_start.isoformat()} to {metrics.window_end.isoformat()}"

    if metrics.observed_days == 0:
        return FindingDescription(statement=f"No historical {label} data was available for {plant} over {window}.", pattern=f"WB {topic} Trend No Data", entity_ids=entity_ids)
    if metrics.trend_direction == WBTrendDirection.INSUFFICIENT_DATA:
        return FindingDescription(statement=f"Insufficient historical data to establish a {label} baseline for {plant} over {window}.", pattern=f"WB {topic} Trend", entity_ids=entity_ids)

    if metrics.abnormal_days == 0:
        if metrics.trend_direction == WBTrendDirection.FLAT:
            return FindingDescription(statement=f"{plant}'s {label} was within its normal historical range across {metrics.observed_days} observed day(s) ({window}).", pattern=f"WB {topic} Trend Normal", entity_ids=entity_ids)
        # A non-FLAT direction (item 5's own 5%-noise-band classification)
        # with zero abnormal days is a real, honest state: the movement is
        # directionally real but never crossed this metric's own,
        # deliberately stricter, abnormality threshold (item 6) on any
        # single observed day -- worded as such, never flattened into a
        # blanket "normal" claim that would contradict `trend_direction`.
        return FindingDescription(
            statement=(
                f"{plant}'s {label} trended {metrics.trend_direction.value} ({metrics.relative_deviation:+.1f}%) over {window}, "
                f"but did not cross the abnormal threshold on any of the {metrics.observed_days} observed day(s)."
            ),
            pattern=f"WB {topic} Trend Directional", entity_ids=entity_ids,
        )
    if metrics.recurrence_count <= 1:
        return FindingDescription(
            statement=f"{plant}'s {label} abnormality over {window} appears to be a single-day event ({metrics.abnormal_days} of {metrics.observed_days} observed days).",
            pattern=f"WB {topic} Trend Single-Day", entity_ids=entity_ids,
        )
    if metrics.consecutive_abnormal_days >= metrics.abnormal_days and metrics.consecutive_abnormal_days > 1:
        return FindingDescription(
            statement=f"{plant}'s {label} remained abnormal for {metrics.consecutive_abnormal_days} consecutive observed days ({window}).",
            pattern=f"WB {topic} Trend Persistent", entity_ids=entity_ids,
        )
    return FindingDescription(
        statement=f"{plant}'s {label} was elevated/abnormal on {metrics.abnormal_days} of {metrics.observed_days} observed days ({window}), recurring rather than continuous.",
        pattern=f"WB {topic} Trend Recurring", entity_ids=entity_ids,
    )


def _describe_relationship_finding(payload, plant: str | None) -> FindingDescription:
    """The Tool's own `association_statement` is already a fully-formed,
    non-causal descriptive sentence (`agent/tools/wb/cross_source_tools.py`)
    -- reused verbatim rather than re-derived, so there is exactly one
    place this wording is authored."""
    return FindingDescription(statement=payload.association_statement, pattern="WB Issue-Output Relationship", entity_ids=[plant] if plant else [])


# --- Phase WB-3C: Structured Limitation derivation ---------------------------
#
# Reuses the generic `Limitation` model verbatim (item 3: no parallel
# `WBLimitation`/`WBDataGap` schema) -- the only generic seam change this
# phase made was additive (`DomainStateUpdates.limitations`, see
# `agent/planning/policies/base.py` and `module_reflector.py`'s mechanical
# passthrough). This section is where WB's OWN domain interpretation of
# "does this gap matter to the current objective" lives (item 7's
# ownership boundary) -- Reflector never sees any of this reasoning, only
# the finished `Limitation` records.
#
# `Limitation` has no `type`/category enum (confirmed by reading
# `agent/state/models.py` before writing this -- item 4's own instruction
# not to add one preemptively). Category is instead embedded as a fixed,
# bounded suffix on `limitation_id` itself -- self-documenting AND the
# deterministic dedup key (item 15/27): re-deriving the exact same gap on
# a later round produces the exact same id, which the caller then filters
# against `module_state.limitations` before returning, so nothing is ever
# appended twice. Five bounded categories only (item 4/61):
_LIMITATION_NO_DATA = "no_data"
_LIMITATION_INSUFFICIENT_HISTORY = "insufficient_history"
_LIMITATION_PARTIAL_OVERLAP = "partial_overlap"
_LIMITATION_DATASOURCE_UNAVAILABLE = "datasource_unavailable"
_LIMITATION_UNSUPPORTED_GRAIN = "unsupported_grain"

# The 5 historical trend capability_keys (item 20) -- INSUFFICIENT_HISTORY
# is only meaningful for these (a plain status/summary capability has no
# "window" to be insufficient over; that gap is already fully captured by
# NO_DATA).
_TREND_CAPABILITY_KEYS: frozenset[str] = frozenset(spec.capability_key for spec in _HISTORICAL_TREND_CAPABILITIES.values())


def _wb_limitation_id(module_id: str, objective_id: str, category: str) -> str:
    return f"{module_id}-lim-{objective_id}-{category}"


def _datasource_unavailable_limitation(module_state: ModuleState, objective_id: str) -> Limitation:
    """item 12/28: every `ObservationStatus.ERROR` a WB objective can
    produce has already passed through `map_wb_datasource_error`'s bounded,
    domain-meaningful mapping (DATA_NOT_FOUND/QUERY_ERROR) or
    `CapabilityResolutionError` (CAPABILITY_NOT_FOUND) -- a genuinely
    unexpected exception is never caught into an ERROR Observation at all
    (`agent/tools/wb/_common.py::map_wb_datasource_error`'s own `raise exc`
    for anything unmapped, `agent/tools/execution_manager.py` has no
    catch-all either) -- so it is always safe to treat an ERROR observation
    reaching this policy as domain-meaningful, never a masked bug."""
    error = module_state.observations[-1].error
    record = module_state.objective_history.get(objective_id)
    capability_key = record.capability_key if record is not None else "unknown"
    return Limitation(
        limitation_id=_wb_limitation_id(module_state.module_id, objective_id, _LIMITATION_DATASOURCE_UNAVAILABLE),
        description=f"WB data source was unavailable while executing '{capability_key}': {error.message if error else 'unknown error'}.",
        impacted_objective_id=objective_id,
        impact_statement="Evidence for this objective could not be obtained; the analysis may rely on an alternative capability or remain incomplete for this aspect.",
        related_error=error,
    )


def _no_data_limitation(module_state: ModuleState, objective_id: str, capability_key: str | None, plant: str | None) -> Limitation:
    """item 9: `SUCCESS + availability.is_empty=True` is a legitimate Tool
    outcome (never an ERROR, never a fabricated `0`) -- but still means the
    current objective's own question is unanswerable from this data, which
    is exactly what a `Limitation` (as opposed to a Finding) exists to say."""
    scope_note = f" for {plant}" if plant else ""
    return Limitation(
        limitation_id=_wb_limitation_id(module_state.module_id, objective_id, _LIMITATION_NO_DATA),
        description=f"No WB data was available{scope_note} for the requested scope (capability '{capability_key}').",
        impacted_objective_id=objective_id,
        impact_statement="The requested condition could not be confirmed or rejected due to a complete absence of data in scope.",
        related_error=None,
    )


def _insufficient_history_limitation_from_metrics(module_state: ModuleState, objective_id: str, capability_key: str, plant: str | None, metrics) -> Limitation:
    scope_note = f" for {plant}" if plant else ""
    window = f"{metrics.window_start.isoformat()} to {metrics.window_end.isoformat()}"
    return Limitation(
        limitation_id=_wb_limitation_id(module_state.module_id, objective_id, _LIMITATION_INSUFFICIENT_HISTORY),
        description=f"Only {metrics.observed_days} observed day(s) were available{scope_note} within the requested window ({window}) for capability '{capability_key}'.",
        impacted_objective_id=objective_id,
        impact_statement="Trend, persistence, and recurrence cannot be reliably assessed with this coverage -- only the individually observed data points can be reported.",
        related_error=None,
    )


def _insufficient_history_limitation_from_issue_payload(module_state: ModuleState, objective_id: str, plant: str | None, payload) -> Limitation:
    """ISSUE's own trend result (Phase WB-3A) predates the shared
    `metrics.` shape (item 8) -- `trend_direction=UNKNOWN` is its own
    signal for "no baseline period to compare against", using its own
    flat `observed_days`/`current_period_start`/`current_period_end`
    fields rather than a nested `WBHistoricalMetricSummary`."""
    scope_note = f" for {plant}" if plant else ""
    window = f"{payload.current_period_start.isoformat()} to {payload.current_period_end.isoformat()}"
    return Limitation(
        limitation_id=_wb_limitation_id(module_state.module_id, objective_id, _LIMITATION_INSUFFICIENT_HISTORY),
        description=f"Only {payload.observed_days} observed day(s) were available{scope_note} within the requested window ({window}) for capability 'wb.issue.trend_analysis'; no baseline period could be established.",
        impacted_objective_id=objective_id,
        impact_statement="Trend, persistence, and recurrence cannot be reliably assessed with this coverage -- only the individually observed data points can be reported.",
        related_error=None,
    )


def _partial_overlap_limitation(module_state: ModuleState, objective_id: str, plant: str | None, payload) -> Limitation:
    """item 11/21/22: the cross-source Tool already computes exactly this
    judgment (`agent/tools/wb/cross_source_tools.py`'s own partial-overlap
    `limitations` string) -- reused rather than re-derived, so there is
    exactly one place the overlap-sufficiency threshold is decided."""
    scope_note = f" for {plant}" if plant else ""
    return Limitation(
        limitation_id=_wb_limitation_id(module_state.module_id, objective_id, _LIMITATION_PARTIAL_OVERLAP),
        description=f"Only {payload.overlap_observed_days} overlapping business date(s) were available between ISSUE and OUTPUT{scope_note}.",
        impacted_objective_id=objective_id,
        impact_statement="The strength of any Issue/Output association is limited by the amount of overlapping data -- treat the association as provisional, not a strong pattern.",
        related_error=None,
    )


def _unsupported_grain_limitation(module_state: ModuleState, objective_id: str, plant: str | None, payload) -> Limitation:
    """item 13: the OEE trend Tool already computes exactly this judgment
    (`agent/tools/wb/oee_tools.py`'s own worst-operation-per-day
    limitation string, emitted only when a day genuinely had more than one
    operation and `operation_id` was left unspecified) -- reused verbatim
    rather than re-derived."""
    scope_note = f" ({plant})" if plant else ""
    return Limitation(
        limitation_id=_wb_limitation_id(module_state.module_id, objective_id, _LIMITATION_UNSUPPORTED_GRAIN),
        description=f"{payload.limitations[0]}{scope_note}",
        impacted_objective_id=objective_id,
        impact_statement="Equipment/operation-level attribution within this plant cannot be distinguished from this aggregate view.",
        related_error=None,
    )


# --- Phase WB-3D: Validation Issue -> Limitation mapping (item 21/34/35) ----
#
# Reuses the WB-3C Limitation seam verbatim -- no new generic contract
# change was needed (item 65/26: the detect layer already lives in
# `agent/domain/wb/validation.py`; this is purely the interpret layer).
# ERROR-severity issues mean the affected record(s) were already excluded
# from this round's own calculation (by the Tool, before this payload was
# ever built) -- the Limitation's `impact_statement` says so. WARNING-
# severity issues (suspected duplicate, potential truncation, stale data)
# mean the record(s) are still IN the result -- the Limitation instead
# says the conclusion should be treated as provisional (item 30).

_VALIDATION_ERROR_IMPACT = "The affected record(s) were excluded from this analysis; the requested condition cannot be reliably assessed from the remaining data alone."
_VALIDATION_WARNING_IMPACT = "The affected record(s) remain part of this result, but any conclusion drawn from them should be treated as provisional."


def _validation_issue_limitations(module_state: ModuleState, objective_id: str, plant: str | None, payload) -> list[Limitation]:
    availability = getattr(payload, "availability", None)
    issues = getattr(availability, "validation_issues", None) if availability is not None else None
    if not issues:
        return []
    scope_note = f" for {plant}" if plant else ""
    limitations = []

    # item 33's own explicit regression: raw records > 0 but EVERY one was
    # excluded by validation ("all-invalid") is a DIFFERENT situation from
    # NO_DATA (raw records == 0) -- both must never collapse into the same
    # signal. A dedicated Limitation makes the distinction explicit rather
    # than relying on the reader to infer it from the per-issue messages
    # alone.
    usable_count = getattr(availability, "usable_record_count", None)
    if usable_count == 0 and availability.record_count > 0:
        limitations.append(Limitation(
            limitation_id=_wb_limitation_id(module_state.module_id, objective_id, "validation-all-invalid"),
            description=f"All {availability.record_count} record(s) returned{scope_note} failed validation -- none were usable for this analysis.",
            impacted_objective_id=objective_id,
            impact_statement="This is NOT the same as no data being available -- data was returned, but none of it could be trusted; the requested condition cannot be assessed.",
            related_error=None,
        ))

    for issue in issues:
        impact = _VALIDATION_ERROR_IMPACT if issue.severity.value == "error" else _VALIDATION_WARNING_IMPACT
        limitations.append(Limitation(
            limitation_id=_wb_limitation_id(module_state.module_id, objective_id, f"validation-{issue.code}"),
            description=f"{issue.message}{scope_note}",
            impacted_objective_id=objective_id,
            impact_statement=impact,
            related_error=None,
        ))
    return limitations


def _derive_wb_limitations(module_state: ModuleState) -> list[Limitation]:
    """The single entry point `derive_state_updates` calls. Purely a
    stateless read of `module_state` (item 24) -- processes only the LATEST
    observation/evidence (this round's own result), since every prior
    round's Limitation, once returned, already lives in
    `module_state.limitations` via the `append_list` reducer and needs no
    re-deriving. Deduplicates against `module_state.limitations` by
    `limitation_id` before returning (item 15/27) -- never a free-text hash,
    always the deterministic (module_id, objective_id, category) id."""
    if not module_state.observations:
        return []
    last_observation = module_state.observations[-1]
    objective_id = last_observation.objective_id
    existing_ids = {lim.limitation_id for lim in module_state.limitations}

    candidates: list[Limitation] = []

    if last_observation.status == ObservationStatus.ERROR:
        candidates.append(_datasource_unavailable_limitation(module_state, objective_id))
    elif last_observation.status == ObservationStatus.SUCCESS and module_state.evidence:
        evidence = module_state.evidence[-1]
        if evidence.objective_id == objective_id:
            record = module_state.objective_history.get(objective_id)
            capability_key = record.capability_key if record is not None else None
            plant = record.target_ref.ref_id if record is not None and record.target_ref.ref_type == TargetRefType.ENTITY else None
            payload = PayloadRegistry.unpack(evidence.structured_payload)

            # Phase WB-3D: promote any validation issue this round's own
            # Tool detected (item 21) -- independent of the WB-3C
            # NO_DATA/INSUFFICIENT_HISTORY/etc. checks below, since a
            # result can have BOTH a validation issue and, say, a partial-
            # overlap gap at once (item 45's own explicit coexistence
            # requirement -- neither suppresses the other).
            candidates += _validation_issue_limitations(module_state, objective_id, plant, payload)

            if getattr(payload, "availability", None) is not None and payload.availability.is_empty:
                # item 9: a fully-empty result is the whole story for this
                # round -- no finer-grained (insufficient-history/overlap/
                # grain) judgment is meaningful on top of zero data.
                candidates.append(_no_data_limitation(module_state, objective_id, capability_key, plant))
            else:
                if capability_key in _TREND_CAPABILITY_KEYS:
                    if capability_key == "wb.issue.trend_analysis":
                        if getattr(payload, "trend_direction", None) is not None and payload.trend_direction.value == "unknown":
                            candidates.append(_insufficient_history_limitation_from_issue_payload(module_state, objective_id, plant, payload))
                    else:
                        metrics = getattr(payload, "metrics", None)
                        if metrics is not None and metrics.trend_direction == WBTrendDirection.INSUFFICIENT_DATA:
                            candidates.append(_insufficient_history_limitation_from_metrics(module_state, objective_id, capability_key, plant, metrics))

                if capability_key == _CROSS_SOURCE_RELATIONSHIP_CAPABILITY.capability_key:
                    if getattr(payload, "limitations", None):
                        candidates.append(_partial_overlap_limitation(module_state, objective_id, plant, payload))

                if capability_key == "wb.oee.trend_analysis":
                    if getattr(payload, "limitations", None):
                        candidates.append(_unsupported_grain_limitation(module_state, objective_id, plant, payload))

    return [c for c in candidates if c.limitation_id not in existing_ids]


class WBPlanningPolicy:
    """INFORMATION/ANALYSIS (Phase WB-2C) + single-module, plant-level RCA
    (Phase WB-2D). Cross-module RCA, Recommendation, and action ranking
    remain out of scope -- `propose_next_objective` still returns `None`
    immediately for any TaskType other than these three."""

    # --- ModulePlanningPolicy protocol --------------------------------------

    def propose_next_objective(self, module_state: ModuleState) -> Objective | None:
        task_type = module_state.goal.task_type
        if task_type not in (TaskType.INFORMATION, TaskType.ANALYSIS, TaskType.RCA):
            return None  # cross-module RCA / other TaskTypes: not implemented this phase

        if task_type == TaskType.RCA:
            return self._propose_rca(module_state)

        # Phase WB-3B item 58/59: ONLY ANALYSIS (never INFORMATION) can
        # route to a historical trend capability, and only when the
        # request itself signals historical intent (item 60's bounded
        # keyword set) -- avoids "capability overuse" (item 59's own
        # explicit concern).
        if task_type == TaskType.ANALYSIS and _wants_historical(module_state):
            return self._propose_historical_analysis(module_state)

        spec_table = _INFORMATION_CAPABILITIES if task_type == TaskType.INFORMATION else _ANALYSIS_CAPABILITIES
        spec = spec_table.get(_detect_topic(module_state))
        if spec is None:
            return None  # detected topic has no capability wired for this TaskType yet (e.g. ANALYSIS+"issue" -- see _ANALYSIS_CAPABILITIES's own note)

        # One attempt per capability_key, success or not -- never loops on
        # an empty/insufficient result (item 20/21: absence is not retried
        # into existence).
        already_tried = any(r.capability_key == spec.capability_key for r in module_state.objective_history.values())
        if already_tried:
            return None

        plant = _detect_plant(module_state) if spec.needs_plant else None
        if spec.needs_plant and plant is None:
            return None  # can't propose an entity-scoped objective without knowing which plant -- never guessed

        objective_date = _detect_date(module_state) if spec.needs_date is not None else None
        if spec.needs_date is not None and objective_date is None:
            return None  # same -- never guessed

        return _build_objective(module_state, task_type, spec, plant, objective_date)

    # --- Phase WB-3B: historical ANALYSIS proposal (item 8-16) --------------

    def _propose_historical_analysis(self, module_state: ModuleState) -> Objective | None:
        plant = _detect_plant(module_state)
        if plant is None:
            return None  # never guessed
        current_date = _detect_date(module_state)
        if current_date is None:
            return None  # never guessed

        topic = _detect_topic(module_state)
        spec = _HISTORICAL_TREND_CAPABILITIES.get(topic)
        if spec is None:
            return None  # no historical trend capability for this topic

        if spec.capability_key in _attempted_capability_keys(module_state):
            return None  # one attempt per capability_key, same rule as everywhere else

        window_days = _detect_window_days(module_state)
        window_start = current_date - timedelta(days=window_days - 1)
        return _build_range_objective(module_state, TaskType.ANALYSIS, spec, plant, window_start, current_date)

    # --- Phase WB-2D: RCA proposal (item 10/11/22) --------------------------
    #
    # Stateless throughout -- every decision is re-derived from
    # module_state.objective_history/evidence on each call, never from an
    # instance attribute (item 9: checkpoint/resume requires state to be
    # the only source of truth). No `phase =`/`step_count ==` branching
    # anywhere (item 22): the only "index" this reads is
    # `objective_history`'s own duplicate-guard, exactly like INFORMATION/
    # ANALYSIS already do.

    def _propose_rca(self, module_state: ModuleState) -> Objective | None:
        plant = _detect_plant(module_state)
        if plant is None:
            return None  # RCA always targets a specific plant this phase (item 6) -- never guessed
        objective_date = _detect_date(module_state)
        if objective_date is None:
            return None  # never guessed

        topic = _detect_topic(module_state)

        # Phase WB-3B item 14/60: historical-flavored RCA requests route
        # through a dedicated evidence-driven chain -- gated by the same
        # bounded keyword check as ANALYSIS's own historical path (item
        # 59: never unconditional, "Round 2 一定 historical" is explicitly
        # forbidden).
        if _wants_historical(module_state):
            return self._propose_historical_rca(module_state, topic, plant, objective_date)

        if topic == "output":
            return self._propose_output_rca(module_state, plant, objective_date)

        # OEE/WIP/BANK-oriented RCA: single capability already carries both
        # the symptom and the pattern (module docstring) -- one round only.
        spec = _RCA_CAPABILITIES.get(topic)
        if spec is None:
            return None  # e.g. topic="issue" -- not one of the 3 official RCA entry topics (item 7), fails closed rather than KeyError
        if spec.capability_key in _attempted_capability_keys(module_state):
            return None
        return _build_objective(module_state, TaskType.RCA, spec, plant, objective_date)

    # --- Phase WB-3B: historical RCA proposal (item 14/30-32/45/56) --------

    def _propose_historical_rca(self, module_state: ModuleState, topic: str, plant: str, current_date: date) -> Objective | None:
        window_days = _detect_window_days(module_state)
        window_start = current_date - timedelta(days=window_days - 1)
        attempted = _attempted_capability_keys(module_state)

        if topic == "output":
            return self._propose_output_historical_rca(module_state, plant, current_date, window_start, attempted)

        # OEE/WIP/BANK: symptom+pattern check first (existing single-round
        # RCA capability), THEN that same topic's own historical trend as
        # a follow-up round (item 30 Scenario A / item 32 Scenario C:
        # "is this a single-day event or a recurring/persistent problem").
        symptom_spec = _RCA_CAPABILITIES.get(topic)
        if symptom_spec is None:
            return None
        if symptom_spec.capability_key not in attempted:
            return _build_objective(module_state, TaskType.RCA, symptom_spec, plant, current_date)

        trend_spec = _HISTORICAL_TREND_CAPABILITIES.get(topic)
        if trend_spec is None or trend_spec.capability_key in attempted:
            return None
        return _build_range_objective(module_state, TaskType.RCA, trend_spec, plant, window_start, current_date)

    def _propose_output_historical_rca(
        self, module_state: ModuleState, plant: str, current_date: date, window_start: date, attempted: set[str]
    ) -> Objective | None:
        """Item 56's own worked chain: Output symptom -> Output historical
        -> Issue historical -> (only if Issue ALSO shows a decline)
        Issue-vs-Output relationship -> done. Each step re-reads the
        actual evidence gathered so far (item 45) -- a normal/flat Issue
        trend never triggers the cross-source Tool (item 28: evidence-
        gated, not unconditional)."""
        evidence_by_key = _evidence_by_capability_key(module_state)
        output_symptom_spec = _RCA_CAPABILITIES["output"]

        if output_symptom_spec.capability_key not in attempted:
            return _build_objective(module_state, TaskType.RCA, output_symptom_spec, plant, current_date)

        output_symptom_evidence = evidence_by_key.get(output_symptom_spec.capability_key)
        if output_symptom_evidence is None:
            return None  # symptom check itself failed (ERROR) -- no alternative source for this exact question
        output_symptom_payload = PayloadRegistry.unpack(output_symptom_evidence.structured_payload)
        if output_symptom_payload.availability.is_empty:
            return None  # can't confirm the symptom at all
        if not _output_is_low(output_symptom_payload, plant):
            return None  # premise rejected -- no historical deep-dive on a non-existent symptom

        output_trend_spec = _HISTORICAL_TREND_CAPABILITIES["output"]
        if output_trend_spec.capability_key not in attempted:
            return _build_range_objective(module_state, TaskType.RCA, output_trend_spec, plant, window_start, current_date)

        issue_trend_spec = _HISTORICAL_TREND_CAPABILITIES["issue"]
        if issue_trend_spec.capability_key not in attempted:
            return _build_range_objective(module_state, TaskType.RCA, issue_trend_spec, plant, window_start, current_date)

        issue_trend_evidence = evidence_by_key.get(issue_trend_spec.capability_key)
        if issue_trend_evidence is not None:
            issue_trend_payload = PayloadRegistry.unpack(issue_trend_evidence.structured_payload)
            # ISSUE's own trend result predates the shared `metrics.`
            # shape (item 8: kept flat for backward compatibility) --
            # `.trend_direction` is a top-level field here, comparing by
            # `.value` so it works uniformly whether it's `WBIssueTrendDirection`
            # (ISSUE's own, pre-existing enum) or `WBTrendDirection` (the
            # shared Phase WB-3B enum every other trend result uses).
            if not issue_trend_payload.availability.is_empty and issue_trend_payload.trend_direction.value == WBTrendDirection.DOWN.value:
                relationship_key = _CROSS_SOURCE_RELATIONSHIP_CAPABILITY.capability_key
                if relationship_key not in attempted:
                    return _build_range_objective(module_state, TaskType.RCA, _CROSS_SOURCE_RELATIONSHIP_CAPABILITY, plant, window_start, current_date)

        return None  # exhausted -- either issue trend wasn't also declining, or every step already checked

    def _propose_output_rca(self, module_state: ModuleState, plant: str, objective_date: date) -> Objective | None:
        """Item 11/45/46: genuinely evidence-driven -- re-reads whatever
        contributing-factor evidence actually exists each call, walking
        `_RCA_CONTRIBUTING_ORDER` and stopping at the first ABNORMAL
        result (a supported candidate) rather than a hardcoded sequence.
        A NORMAL result weakens/rejects that hypothesis and moves on
        (item 12/46's contradiction handling); an ERROR/empty result also
        moves on without retrying (item 50's alternative-path requirement)."""
        attempted = _attempted_capability_keys(module_state)
        evidence_by_key = _evidence_by_capability_key(module_state)
        output_spec = _RCA_CAPABILITIES["output"]

        if output_spec.capability_key not in attempted:
            return _build_objective(module_state, TaskType.RCA, output_spec, plant, objective_date)

        output_evidence = evidence_by_key.get(output_spec.capability_key)
        if output_evidence is None:
            return None  # symptom check itself failed (ERROR) -- no alternative source for this exact question
        output_payload = PayloadRegistry.unpack(output_evidence.structured_payload)
        if output_payload.availability.is_empty:
            return None  # can't confirm the symptom at all -- never retried into existence

        if not _output_is_low(output_payload, plant):
            return None  # premise rejected (or undeterminable) -- stop, no fabricated investigation

        for contributing_topic in _RCA_CONTRIBUTING_ORDER:
            spec = _RCA_CAPABILITIES[contributing_topic]
            if spec.capability_key not in attempted:
                return _build_objective(module_state, TaskType.RCA, spec, plant, objective_date)
            existing_evidence = evidence_by_key.get(spec.capability_key)
            if existing_evidence is None:
                continue  # attempted but failed (ERROR) -- move to the next viable candidate (item 50)
            payload = PayloadRegistry.unpack(existing_evidence.structured_payload)
            if payload.availability.is_empty:
                continue  # SUCCESS but no usable data -- move to the next candidate
            if _contributing_factor_is_abnormal(contributing_topic, payload):
                return None  # found a supported candidate -- stop investigating further
            # normal -- this hypothesis is weakened/rejected, move to the next candidate
        return None  # every contributing factor checked, none abnormal -- exhausted

    def is_sufficient(self, module_state: ModuleState) -> bool:
        if not module_state.evidence:
            return False
        payload = PayloadRegistry.unpack(module_state.evidence[-1].structured_payload)
        # Tool-level SUCCESS + is_empty=True is a legitimate result (WB-2A/2B
        # "absence is not an error" invariant) but is NOT, at the Module
        # level, "the goal was achieved" -- a request for data that turns
        # out not to exist is not yet a satisfied INFORMATION/ANALYSIS/RCA
        # goal (item 20's own explicit layer distinction).
        if payload.availability.is_empty:
            return False
        if module_state.goal.task_type != TaskType.RCA:
            return True
        # Confirmation rule (item 15, module docstring): RCA is sufficient
        # exactly when there is nothing more `_propose_rca` would try --
        # single source of truth shared with `propose_next_objective`, so
        # the two can never disagree.
        return self._propose_rca(module_state) is None

    def describe_finding(self, module_state: ModuleState) -> FindingDescription:
        if not module_state.evidence:
            return FindingDescription(statement="WB capability not yet executed.", pattern="WB")

        if module_state.goal.task_type == TaskType.RCA:
            return self._describe_finding_rca(module_state)

        evidence = module_state.evidence[-1]
        record = module_state.objective_history.get(evidence.objective_id)
        capability_key = record.capability_key if record is not None else None
        target_plant = record.target_ref.ref_id if record is not None and record.target_ref.ref_type == TargetRefType.ENTITY else None
        payload = PayloadRegistry.unpack(evidence.structured_payload)
        return _describe_finding(capability_key, payload, target_plant)

    def _describe_finding_rca(self, module_state: ModuleState) -> FindingDescription:
        latest_evidence = module_state.evidence[-1]
        latest_record = module_state.objective_history.get(latest_evidence.objective_id)
        capability_key = latest_record.capability_key if latest_record is not None else None
        plant = (
            latest_record.target_ref.ref_id
            if latest_record is not None and latest_record.target_ref.ref_type == TargetRefType.ENTITY
            else _detect_plant(module_state)
        )
        payload = PayloadRegistry.unpack(latest_evidence.structured_payload)
        objective_date = _detect_date(module_state)

        if payload.availability.is_empty:
            scope_note = f" for {plant}" if plant else ""
            return FindingDescription(
                statement=f"No data was available for capability '{capability_key}'{scope_note} in the queried scope -- the requested symptom could not be confirmed.",
                pattern="WB RCA No Data", entity_ids=[plant] if plant else [],
            )

        # Phase WB-3D (item 33/47): raw records were returned but
        # validation excluded every one of them -- distinct from NO_DATA,
        # and must never reach a downstream branch that indexes into an
        # empty ranking/breakdown list (e.g. `_oee_is_abnormal`'s own
        # `payload.ranking[0]`).
        usable_count = getattr(payload.availability, "usable_record_count", None)
        if usable_count == 0:
            scope_note = f" for {plant}" if plant else ""
            return FindingDescription(
                statement=f"Data was returned for capability '{capability_key}'{scope_note}, but none of it passed validation -- the requested symptom cannot be confirmed or rejected.",
                pattern="WB RCA All-Invalid Data", entity_ids=[plant] if plant else [],
            )

        # Phase WB-3B: historical trend / cross-source relationship rounds
        # get their own description, dispatched by capability_key BEFORE
        # the topic-based routing below (which would otherwise misroute a
        # historical-chain round -- e.g. the latest evidence being the
        # ISSUE trend or relationship result mid-way through an
        # Output-oriented historical RCA chain, item 56).
        if capability_key == _CROSS_SOURCE_RELATIONSHIP_CAPABILITY.capability_key:
            return _describe_relationship_finding(payload, plant)
        for historical_topic, historical_spec in _HISTORICAL_TREND_CAPABILITIES.items():
            if capability_key == historical_spec.capability_key:
                metrics = _issue_trend_metrics_adapter(payload) if historical_topic == "issue" else payload.metrics
                return _describe_trend_finding(historical_topic, metrics, plant)

        topic = _detect_topic(module_state)
        if topic != "output":
            return _describe_single_capability_rca_finding(topic, payload, plant, objective_date)
        return _describe_output_rca_finding(module_state, plant, objective_date, capability_key)

    def derive_state_updates(self, module_state: ModuleState) -> DomainStateUpdates:
        changed_entity_states: dict[str, EntityState] = {}
        base_entity_states = module_state.entity_states
        if not base_entity_states:
            base_entity_states = build_wb_initial_entity_states()
            changed_entity_states = dict(base_entity_states)

        # Item 26: mark the RCA target plant INVESTIGATING once at least
        # one RCA objective has been dispatched for it. Never
        # ROOT_CAUSE_FOUND this phase -- no plant-level data confirms a
        # true root cause (item 26's own explicit caution against
        # mislabeling a causal candidate as a confirmed one).
        if module_state.goal.task_type == TaskType.RCA and module_state.objective_history:
            plant = _detect_plant(module_state)
            if plant is not None and plant in base_entity_states:
                current = base_entity_states[plant]
                if current.status != EntityAnalysisStatus.INVESTIGATING:
                    changed_entity_states[plant] = current.model_copy(
                        update={"status": EntityAnalysisStatus.INVESTIGATING, "last_updated_step": len(module_state.objective_history)}
                    )

        # Phase WB-3C: structured Limitation derivation (item 24) -- reads
        # this round's own observation/evidence, never mutates
        # `propose_next_objective`'s own state, stays fully stateless.
        new_limitations = _derive_wb_limitations(module_state)

        if changed_entity_states or new_limitations:
            return DomainStateUpdates(entity_states=changed_entity_states, limitations=new_limitations)
        return DomainStateUpdates()
