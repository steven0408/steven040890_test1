"""LLMReflectionPolicy (Phase WB-3F) -- the first LLM-backed Reflector
interpretation layer. Implements the exact same three Reflector-facing
`ModulePlanningPolicy` methods (`is_sufficient` / `describe_finding` /
`derive_state_updates`) plus `propose_next_objective` (pure passthrough) --
no parallel contract, no change to `module_reflector.py`/`module_planner.py`
(both stay oblivious to whether their policy is deterministic or
LLM-backed, exactly as `LLMPlanningPolicy` already established for Planner):

    Module Reflector
        v
    ModulePlanningPolicy.is_sufficient / describe_finding / derive_state_updates
        v (LLMReflectionPolicy's own implementation)
    ReflectorContextBuilder -> LLMRouter(route="reflector") -> ReflectionDecision
        v
    validate_reflection_decision -> (verdict, FindingDescription, new Hypotheses)

Composability (mirrors `LLMPlanningPolicy`'s own wrapping precedent, and is
exactly what Phase WB-3F's own required 3-way ablation needs):

    - LLM Planner + LLM Reflector + Reasoning Skills:
        LLMReflectionPolicy(baseline_policy=LLMPlanningPolicy(WBPlanningPolicy(), ...), ...)
    - LLM Planner + deterministic Reflector (Phase WB-3E's own state, unchanged):
        LLMPlanningPolicy(WBPlanningPolicy(), ...) alone
    - deterministic Planner + deterministic Reflector:
        WBPlanningPolicy() alone

`propose_next_objective` always delegates straight to `baseline_policy`,
unconditionally -- this policy never touches Planner-side decisions, the
same discipline `LLMPlanningPolicy.is_sufficient`/`describe_finding`/
`derive_state_updates` already apply in the opposite direction.

Exactly ONE real LLM call per Reflector round: `module_reflector.py` calls
`is_sufficient`, then (conditionally) `describe_finding`, then always
`derive_state_updates`, all with the SAME `module_state` reference within
one node execution -- `_get_or_build` memoizes by (run_id, module_id,
observation_count) so the second/third call in the same round reuses the
first call's already-validated decision instead of re-calling the LLM.

On any LLM failure (timeout / provider error / invalid structured output /
semantic-invalid output), every method for that round degrades to calling
`baseline_policy`'s own equivalent method directly and records
`DecisionSource.FALLBACK` -- never a bare exception, never an unset verdict.

`derive_state_updates`'s branches/entity_states/analysis_tree/limitations
stay fully deterministic even in LLM mode (Final Invariant: "LLM does not
calculate trusted metrics") -- ALWAYS sourced from the baseline policy's own
mechanical bookkeeping. The LLM only ever adds NEW `hypotheses` on top.
"""
from datetime import datetime, timezone
from typing import Callable

from agent.llm.context.reflector_context import ReflectorContextBuilder
from agent.llm.models import DecisionSource, LLMInvalidOutputError
from agent.llm.prompts.reflector import CausalLevel, ObjectiveAssessment, ReflectionDecision, ReflectionVerdict, build_reflector_messages
from agent.llm.router import LLMRouter, LLMRouterError
from agent.planning.hypothesis_view import latest_hypotheses
from agent.planning.policies.base import DomainStateUpdates, FindingDescription, ModulePlanningPolicy
from agent.planning.reflection_audit import ReflectionDecisionAuditSink, ReflectionDecisionRecord
from agent.state.enums import HypothesisStatus, TargetRefType
from agent.state.models import Hypothesis, ModuleState, Objective

_HYPOTHESIS_STATUS_VALUES = {s.value for s in HypothesisStatus}


class ReflectionSemanticValidationError(LLMInvalidOutputError):
    """A subclass, not a new sibling exception -- same reasoning as
    PlannerSemanticValidationError: LLMRouter's failure handling is
    isinstance-based, so this is treated exactly like the client producing
    invalid structured output (recorded INVALID_OUTPUT, retried, and once
    retries are exhausted, triggers LLMReflectionPolicy's fallback to the
    baseline policy)."""


# WB never confirms a root cause via its OWN deterministic policy either
# (agent/planning/policies/wb.py -- every FindingDescription it builds sets
# is_root_cause=False by design: plant-level WB data has no equipment-
# failure-reason/defect-reason/supply-chain-root field to actually confirm
# one). The LLM Reflector is held to the exact same domain-honesty ceiling
# here -- this is "an explicitly justified deterministic guard" (the Core
# Architecture Principle's own carve-out for semantic decisions), not a
# blanket ban on LLM root-cause ownership; a future domain with real
# confirmatory evidence (the way OEE's equipment-failure-detail Tool has)
# would not need this guard.
_MODULE_TYPES_NEVER_CONFIRM_ROOT_CAUSE = {"WB"}


def validate_reflection_decision(decision: ReflectionDecision, *, module_state: ModuleState) -> None:
    """Semantic validation beyond pydantic schema validation -- catches an
    LLM producing a structurally-valid-but-nonsensical reflection: a
    reference to evidence/entity/limitation/hypothesis that doesn't exist
    in this module, or a causal claim the evidence/verdict doesn't
    actually support.

    Phase WB-3F.1: `is_root_cause: bool` was replaced by `causal_level`
    (the 4-level epistemic ladder, agent/llm/prompts/reflector.py) -- the
    validator's own PERMITTED outcomes are unchanged (WB may still never
    reach the top level), only what field it reads."""
    known_evidence_ids = {e.evidence_id for e in module_state.evidence}
    known_entity_ids = set(module_state.entity_states.keys())
    known_limitation_ids = {lim.limitation_id for lim in module_state.limitations}
    known_hypothesis_ids = {h.hypothesis_id for h in module_state.hypotheses}
    # The Objective just executed is definitionally grounded -- it's what
    # this round's evidence IS about -- even before any EntityState record
    # exists for it (e.g. round 1 of an RCA chain, before the domain
    # policy's own derive_state_updates has ever run).
    current_target_id = (
        module_state.current_objective.target_ref.ref_id
        if module_state.current_objective is not None and module_state.current_objective.target_ref.ref_type == TargetRefType.ENTITY
        else None
    )

    fc = decision.finding_candidate
    if fc is not None:
        for evidence_id in fc.supporting_evidence_ids:
            if evidence_id not in known_evidence_ids:
                raise ReflectionSemanticValidationError(f"finding_candidate references unknown evidence_id '{evidence_id}' -- possible hallucination")
        for entity_id in fc.entity_ids:
            if entity_id and entity_id not in known_entity_ids and entity_id != module_state.module_type and entity_id != current_target_id:
                raise ReflectionSemanticValidationError(f"finding_candidate references unknown entity_id '{entity_id}' -- possible hallucination")
        if fc.causal_level == CausalLevel.CONFIRMED_CAUSAL:
            if module_state.module_type in _MODULE_TYPES_NEVER_CONFIRM_ROOT_CAUSE:
                raise ReflectionSemanticValidationError(
                    f"module_type '{module_state.module_type}' data cannot confirm a root cause -- causal_level=confirmed_causal is not permitted for this domain"
                )
            if decision.verdict != ReflectionVerdict.SUPPORTS or decision.objective_assessment != ObjectiveAssessment.SATISFIED:
                raise ReflectionSemanticValidationError("causal_level=confirmed_causal requires verdict=supports and objective_assessment=satisfied")
            if not fc.supporting_evidence_ids:
                raise ReflectionSemanticValidationError("causal_level=confirmed_causal requires at least one real supporting_evidence_id")

    for ref in decision.limitation_refs:
        if ref not in known_limitation_ids:
            raise ReflectionSemanticValidationError(f"limitation_refs references unknown limitation_id '{ref}' -- possible hallucination")

    for proposal in decision.hypothesis_proposals:
        if not (0.0 <= proposal.confidence <= 1.0):
            raise ReflectionSemanticValidationError(f"hypothesis confidence out of range [0,1]: {proposal.confidence}")

    # Phase WB-3F.1 (item 17): hypothesis_updates -- reject an update
    # referencing a hypothesis this module never created, an unrecognized
    # status, an out-of-range confidence, a SUPPORTED claim with no
    # supporting evidence, or a REFUTED claim with no contradicting
    # evidence. The LLM cannot delete a hypothesis -- there is no such
    # operation on this schema at all (extra="forbid" plus a closed field
    # set makes it structurally impossible, not just policy).
    for update in decision.hypothesis_updates:
        if update.hypothesis_id not in known_hypothesis_ids:
            raise ReflectionSemanticValidationError(f"hypothesis_updates references unknown hypothesis_id '{update.hypothesis_id}' -- possible hallucination")
        if update.status not in _HYPOTHESIS_STATUS_VALUES:
            raise ReflectionSemanticValidationError(f"hypothesis_updates.status '{update.status}' is not a recognized HypothesisStatus value ({sorted(_HYPOTHESIS_STATUS_VALUES)})")
        if not (0.0 <= update.confidence <= 1.0):
            raise ReflectionSemanticValidationError(f"hypothesis_updates confidence out of range [0,1]: {update.confidence}")
        for evidence_id in update.supporting_evidence_ids + update.contradicting_evidence_ids:
            if evidence_id not in known_evidence_ids:
                raise ReflectionSemanticValidationError(f"hypothesis_updates references unknown evidence_id '{evidence_id}' -- possible hallucination")
        if update.status == HypothesisStatus.SUPPORTED.value and not update.supporting_evidence_ids:
            raise ReflectionSemanticValidationError(f"hypothesis_updates status=supported for '{update.hypothesis_id}' requires at least one supporting_evidence_id")
        if update.status == HypothesisStatus.REFUTED.value and not update.contradicting_evidence_ids:
            raise ReflectionSemanticValidationError(f"hypothesis_updates status=refuted for '{update.hypothesis_id}' requires at least one contradicting_evidence_id")

    if not decision.rationale_summary.strip():
        raise ReflectionSemanticValidationError("rationale_summary must not be empty")


class _RoundOutcome:
    """Internal per-round cache entry -- either a validated
    `ReflectionDecision` (LLM succeeded) or a FALLBACK sentinel (this round
    degrades entirely to the baseline policy for all three Reflector-facing
    methods)."""

    __slots__ = ("decision", "source", "fallback_reason", "llm_call_id", "context_build_record_id")

    def __init__(self, *, decision=None, source, fallback_reason=None, llm_call_id=None, context_build_record_id=None):
        self.decision = decision
        self.source = source
        self.fallback_reason = fallback_reason
        self.llm_call_id = llm_call_id
        self.context_build_record_id = context_build_record_id


class LLMReflectionPolicy:
    def __init__(
        self,
        baseline_policy: ModulePlanningPolicy,
        context_builder: ReflectorContextBuilder,
        router: LLMRouter,
        *,
        route: str = "reflector",
        decision_audit_sink: ReflectionDecisionAuditSink | None = None,
        now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ):
        self._baseline = baseline_policy
        self._context_builder = context_builder
        self._router = router
        self._route = route
        self._decision_audit_sink = decision_audit_sink
        self._now_fn = now_fn
        self._cache: dict[tuple, _RoundOutcome] = {}

    def _round_key(self, module_state: ModuleState) -> tuple:
        return (module_state.run_id, module_state.module_id, len(module_state.observations))

    def _get_or_build(self, module_state: ModuleState) -> _RoundOutcome:
        key = self._round_key(module_state)
        cached = self._cache.get(key)
        if cached is not None:
            return cached

        step = len(module_state.reflection_history) + 1
        context_outcome = self._context_builder.build(module_state, run_id=module_state.run_id, node="module_reflector")
        messages = build_reflector_messages(context_outcome.context)

        def _validate(decision: ReflectionDecision) -> None:
            validate_reflection_decision(decision, module_state=module_state)

        try:
            router_outcome = self._router.call(
                self._route,
                messages,
                ReflectionDecision,
                run_id=module_state.run_id,
                module_id=module_state.module_id,
                node="module_reflector",
                validate=_validate,
            )
            outcome = _RoundOutcome(
                decision=router_outcome.parsed_output,
                source=DecisionSource.LLM,
                llm_call_id=router_outcome.call_record.llm_call_id,
                context_build_record_id=context_outcome.record.context_build_record_id,
            )
        except LLMRouterError as exc:
            outcome = _RoundOutcome(
                source=DecisionSource.FALLBACK,
                fallback_reason=str(exc),
                context_build_record_id=context_outcome.record.context_build_record_id,
            )

        if self._decision_audit_sink is not None:
            decision = outcome.decision
            self._decision_audit_sink.record(
                ReflectionDecisionRecord(
                    decision_record_id=f"{module_state.module_id}-refl-decision-{step}",
                    run_id=module_state.run_id,
                    module_id=module_state.module_id,
                    step=step,
                    verdict=decision.verdict if decision is not None else ReflectionVerdict.NO_RELEVANT_SIGNAL,
                    objective_assessment=decision.objective_assessment if decision is not None else ObjectiveAssessment.NOT_SATISFIED,
                    is_root_cause_claimed=bool(decision is not None and decision.finding_candidate is not None and decision.finding_candidate.causal_level == CausalLevel.CONFIRMED_CAUSAL),
                    should_continue=decision.should_continue if decision is not None else True,
                    source=outcome.source,
                    rationale_summary=decision.rationale_summary if decision is not None else "Deterministic fallback (baseline policy).",
                    context_build_record_id=outcome.context_build_record_id,
                    llm_call_id=outcome.llm_call_id,
                    fallback_reason=outcome.fallback_reason,
                    created_at=self._now_fn(),
                )
            )

        self._cache[key] = outcome
        return outcome

    # Not LLM-driven this phase -- delegate straight to the deterministic
    # baseline policy, unconditionally (mirrors LLMPlanningPolicy's own
    # opposite-direction passthrough for is_sufficient/describe_finding/
    # derive_state_updates).
    def propose_next_objective(self, module_state: ModuleState) -> Objective | None:
        return self._baseline.propose_next_objective(module_state)

    def is_sufficient(self, module_state: ModuleState) -> bool:
        outcome = self._get_or_build(module_state)
        if outcome.source == DecisionSource.FALLBACK:
            return self._baseline.is_sufficient(module_state)
        return outcome.decision.objective_assessment == ObjectiveAssessment.SATISFIED

    def describe_finding(self, module_state: ModuleState) -> FindingDescription:
        outcome = self._get_or_build(module_state)
        if outcome.source == DecisionSource.FALLBACK:
            return self._baseline.describe_finding(module_state)
        fc = outcome.decision.finding_candidate
        if fc is None:
            return self._baseline.describe_finding(module_state)
        # Phase WB-3F.1: causal_level is reflection-only (agent/llm/prompts
        # /reflector.py) -- only CONFIRMED_CAUSAL ever maps to Core's
        # `is_root_cause: bool`. The Finding schema itself is unchanged.
        return FindingDescription(statement=fc.statement, pattern=fc.pattern, entity_ids=fc.entity_ids, is_root_cause=fc.causal_level == CausalLevel.CONFIRMED_CAUSAL)

    def derive_state_updates(self, module_state: ModuleState) -> DomainStateUpdates:
        # branches/entity_states/analysis_tree/limitations stay fully
        # deterministic even in LLM mode -- ALWAYS sourced from the
        # baseline policy's own mechanical bookkeeping, never from the LLM.
        base_updates = self._baseline.derive_state_updates(module_state)

        outcome = self._get_or_build(module_state)
        if outcome.source == DecisionSource.FALLBACK:
            return base_updates

        step = len(module_state.reflection_history) + 1
        new_hypotheses = [
            Hypothesis(
                hypothesis_id=f"{module_state.module_id}-hyp-{step}-{i}",
                statement=proposal.statement,
                related_dimensions=proposal.related_dimensions,
                status=HypothesisStatus.OPEN,
                confidence=proposal.confidence,
            )
            for i, proposal in enumerate(outcome.decision.hypothesis_proposals)
        ]

        # Phase WB-3F.1 (item 15/18): an "update" is a NEW Hypothesis
        # record that reuses the SAME hypothesis_id with a revised status/
        # confidence -- ModuleState.hypotheses stays append_list (no Core
        # reducer/schema change, see agent/planning/hypothesis_view.py's
        # own docstring for the full rationale). `statement`/
        # `related_dimensions` carry over from the current latest entry
        # unchanged -- the LLM updates the ASSESSMENT of a hypothesis, it
        # never silently rewrites what the hypothesis actually claims.
        current_by_id = {h.hypothesis_id: h for h in latest_hypotheses(module_state.hypotheses)}
        updated_hypotheses = [
            current_by_id[update.hypothesis_id].model_copy(update={"status": HypothesisStatus(update.status), "confidence": update.confidence})
            for update in outcome.decision.hypothesis_updates
            if update.hypothesis_id in current_by_id  # already enforced by validate_reflection_decision; defensive here too
        ]

        all_new = [*new_hypotheses, *updated_hypotheses]
        if not all_new:
            return base_updates
        return base_updates.model_copy(update={"hypotheses": [*base_updates.hypotheses, *all_new]})
