"""PlannerDecisionQuality (Phase 5C-3) -- a deterministic, rule-based SOFT
scoring signal for a real (or mock) Planner decision, distinct from
`validate_planner_decision`'s HARD gate (agent/planning/policies/llm.py).

This is not the Evaluator node (out of scope this phase, see the module
docstring in tests/test_phase5c3_real_planner_smoke.py) -- it exists only
so real-provider Planner smoke tests can start accumulating decision-quality
data without requiring the real LLM to exactly match the deterministic
baseline (see the Phase 5C-2.1 architecture note: a real LLM Planner may
legitimately choose a high-quality Objective the baseline never defined).

Order is always:

    Real LLM -> pydantic validation -> semantic validation (hard gate)
        -> PlannerDecisionQuality evaluation (soft, informational)
        -> Objective

A low quality score never overrides a semantically valid decision, and a
high quality score never rescues a semantically invalid one -- callers must
run `validate_planner_decision` first regardless of what this reports.
Explicitly NOT an LLM-judge: every dimension below is a plain rule against
`module_state`, reusing the exact same tables the semantic validator uses
(`ACTION_TARGET_TYPE` / `ALLOWED_ACTIONS_BY_TASK_TYPE`) so the two can never
silently disagree on what a valid action/target shape is.
"""
from agent.capability.resolver import CapabilityResolutionError, CapabilityResolver
from agent.llm.prompts.planner import PlannerDecision
from agent.planning.policies.llm import ALLOWED_ACTIONS_BY_TASK_TYPE
from agent.skills.registry import SkillRegistry
from agent.state.base import RCABaseModel
from agent.state.enums import BranchStatus, ObjectiveAction, ObjectiveStatus, TargetRefType, TaskType
from agent.state.models import ModuleState, Objective

_TERMINAL_STATUSES = (ObjectiveStatus.COMPLETED, ObjectiveStatus.REJECTED)


class PlannerDecisionQuality(RCABaseModel):
    action_valid: bool
    target_valid: bool
    task_depth_valid: bool
    target_relevant: bool
    target_unexplored: bool
    capability_available: bool
    priority_alignment: float
    overall_score: float


def _fully_valid() -> PlannerDecisionQuality:
    """A NO_VIABLE_OBJECTIVE decision has no target to score -- nothing to
    fault, so it reports as fully valid rather than penalizing a decision
    type this evaluator has no opinion about."""
    return PlannerDecisionQuality(
        action_valid=True, target_valid=True, task_depth_valid=True, target_relevant=True,
        target_unexplored=True, capability_available=True, priority_alignment=1.0, overall_score=1.0,
    )


def _has_completed_screening(module_state: ModuleState) -> bool:
    return any(
        record.action == ObjectiveAction.SCREEN and record.status == ObjectiveStatus.COMPLETED
        for record in module_state.objective_history.values()
    )


def evaluate_planner_decision_quality(
    decision: PlannerDecision,
    *,
    module_state: ModuleState,
    task_type: TaskType,
    capability_resolver: CapabilityResolver,
    skill_registry: SkillRegistry,
) -> PlannerDecisionQuality:
    if decision.next_objective is None:
        return _fully_valid()

    proposal = decision.next_objective
    action = proposal.action
    target_ref = proposal.target_ref

    action_valid = action in ALLOWED_ACTIONS_BY_TASK_TYPE.get(task_type, set())

    # Phase WB-2B.1: target-ref shape is now a property of the capability
    # (SkillDefinition.expected_target_ref_type), not a global per-verb
    # table -- mirrors validate_planner_decision's own lookup.
    matching_skills = [s for s in skill_registry.list() if s.capability_key == proposal.capability_key] if proposal.capability_key else []
    expected_ref_type = matching_skills[0].expected_target_ref_type if matching_skills else None
    shape_ok = expected_ref_type is None or target_ref.ref_type == expected_ref_type
    if target_ref.ref_type == TargetRefType.MODULE:
        exists_ok = target_ref.ref_id == module_state.module_type
    elif target_ref.ref_type == TargetRefType.ENTITY:
        exists_ok = target_ref.ref_id in module_state.entity_states
    else:
        exists_ok = True
    target_valid = shape_ok and exists_ok

    # Depth: diving straight to DRILL_DOWN before any SCREEN evidence
    # exists is premature -- even when the TaskType's allow-list permits
    # it in principle, nothing has identified *which* entity is worth a
    # deep dive yet.
    task_depth_valid = not (action == ObjectiveAction.DRILL_DOWN and not _has_completed_screening(module_state))

    if target_ref.ref_type == TargetRefType.ENTITY:
        entity = module_state.entity_states.get(target_ref.ref_id)
        active_branch_ids = {b.branch_id for b in module_state.branches.values() if b.status == BranchStatus.ACTIVE}
        target_relevant = entity is not None and entity.branch_id in active_branch_ids
    else:
        target_relevant = True

    target_unexplored = not any(
        record.action == action and record.target_ref.ref_id == target_ref.ref_id and record.status in _TERMINAL_STATUSES
        for record in module_state.objective_history.values()
    )

    try:
        stub_objective = Objective(
            objective_id="quality-eval-stub", description=proposal.description, action=action,
            capability_key=proposal.capability_key, target_ref=target_ref, scope=proposal.scope,
            expected_output=proposal.expected_output, priority_score=decision.priority or 0.0,
            requires_permission=proposal.requires_permission, risk_level=proposal.risk_level, permission_type=proposal.permission_type,
        )
        capability_resolver.resolve(stub_objective, module_state.module_type, task_type)
        capability_available = True
    except CapabilityResolutionError:
        capability_available = False

    if target_ref.ref_type == TargetRefType.ENTITY and decision.priority is not None:
        entity = module_state.entity_states.get(target_ref.ref_id)
        priority_alignment = max(0.0, 1.0 - abs(decision.priority - entity.priority_score)) if entity is not None else 0.5
    else:
        priority_alignment = 1.0 if decision.priority is not None else 0.5

    overall_score = (
        sum([action_valid, target_valid, task_depth_valid, target_relevant, target_unexplored, capability_available]) + priority_alignment
    ) / 7.0

    return PlannerDecisionQuality(
        action_valid=action_valid,
        target_valid=target_valid,
        task_depth_valid=task_depth_valid,
        target_relevant=target_relevant,
        target_unexplored=target_unexplored,
        capability_available=capability_available,
        priority_alignment=priority_alignment,
        overall_score=overall_score,
    )
