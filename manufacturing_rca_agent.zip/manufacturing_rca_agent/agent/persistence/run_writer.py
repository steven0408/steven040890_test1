"""RunPersistenceWriter (Phase 8A item 17) -- the one downstream Harness
service that projects `AgentState` (+ its `HandoffPackage`/`RunEvaluation`/
Human Feedback/Learning Candidates) into persistence records and writes
them through a `PersistenceUnitOfWork`. No LangGraph node writes to a
Repository directly -- generic nodes are untouched by this phase.

Every write is staged (`uow.stage(...)`) and only actually applied on
`uow.commit()`, so a caller can build its own `PersistenceUnitOfWork`,
call `persist_run(..., uow=uow)` without committing, and inspect that
nothing landed in the repositories yet -- see
tests/test_persistence_unit_of_work.py's rollback case.

Root-cause projection reuses `ModuleHandoffBuilder` (Phase 6A) rather than
re-deriving "which findings count as a root cause" a second time --
avoids the exact kind of drift Phase 6A's own hallucination-guard tests
exist to prevent.
"""
from datetime import datetime, timezone
from typing import Callable

from agent.persistence.audit_repository import AuditRepository
from agent.persistence.learning_repository import LearningCandidateRepository
from agent.persistence.records import EvidenceRecord, FindingEvidenceLink, FindingRecord, ModuleRunRecord, RootCauseFindingLink, RootCauseRecord, RunRecord
from agent.persistence.run_repository import RunRepository
from agent.persistence.settings import PersistenceSettings
from agent.persistence.unit_of_work import PersistenceUnitOfWork
from agent.state.models import HumanFeedback, LearningCandidate, ModuleState, RunEvaluation
from agent.state.state import AgentState
from agent.synthesis.handoff_builder import ModuleHandoffBuilder


class RunPersistenceWriter:
    def __init__(
        self,
        run_repository: RunRepository,
        audit_repository: AuditRepository,
        feedback_sink,
        learning_repository: LearningCandidateRepository,
        *,
        settings: PersistenceSettings | None = None,
        now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
        handoff_builder: ModuleHandoffBuilder | None = None,
    ):
        self._run_repository = run_repository
        self._audit_repository = audit_repository
        self._feedback_sink = feedback_sink
        self._learning_repository = learning_repository
        self._settings = settings or PersistenceSettings()
        self._now_fn = now_fn
        self._handoff_builder = handoff_builder or ModuleHandoffBuilder()

    def persist_run(
        self,
        final_state: AgentState,
        *,
        run_evaluation: RunEvaluation | None = None,
        human_feedback: list[HumanFeedback] | None = None,
        learning_candidates: list[LearningCandidate] | None = None,
        uow: PersistenceUnitOfWork | None = None,
    ) -> PersistenceUnitOfWork:
        owns_uow = uow is None
        uow = uow or PersistenceUnitOfWork()

        if owns_uow:
            with uow:
                self._stage_all(uow, final_state, run_evaluation, human_feedback, learning_candidates)
                uow.commit()
        else:
            self._stage_all(uow, final_state, run_evaluation, human_feedback, learning_candidates)

        return uow

    def _stage_all(self, uow, final_state, run_evaluation, human_feedback, learning_candidates) -> None:
        self._stage_run(uow, final_state)
        for module_state in final_state.module_states.values():
            self._stage_module(uow, final_state, module_state)

        if final_state.synthesis_result is not None:
            package = final_state.synthesis_result
            uow.stage(lambda: self._run_repository.save_handoff_package(package))

        if run_evaluation is not None:
            uow.stage(lambda: self._audit_repository.run_evaluation_store.save(run_evaluation))

        for feedback in human_feedback or []:
            uow.stage(lambda f=feedback: self._feedback_sink.record(f))

        for candidate in learning_candidates or []:
            uow.stage(lambda c=candidate: self._learning_repository.record(c))

    def _stage_run(self, uow: PersistenceUnitOfWork, final_state: AgentState) -> None:
        record = RunRecord(
            run_id=final_state.run_id,
            user_request=final_state.user_request.raw_text,
            normalized_request=final_state.normalized_request.normalized_text if final_state.normalized_request is not None else None,
            factory_id=final_state.factory_context.factory_id,
            task_type=final_state.global_goal.task_type if final_state.global_goal is not None else None,
            run_status=final_state.termination_status,
            started_at=final_state.started_at,  # Phase 8A-1: real graph-execution start, not UserRequest.submitted_at
            completed_at=final_state.completed_at,
            created_at=self._now_fn(),
        )
        uow.stage(lambda: self._run_repository.save_run(record))

    def _stage_module(self, uow: PersistenceUnitOfWork, final_state: AgentState, module_state: ModuleState) -> None:
        module_record = ModuleRunRecord(
            run_id=final_state.run_id, module_id=module_state.module_id, module_type=module_state.module_type,
            task_type=module_state.goal.task_type, module_status=module_state.status, goal=module_state.goal.statement,
            started_at=module_state.started_at, completed_at=module_state.completed_at,  # Phase 8A-1
            step_count=module_state.metrics.step_count, tool_call_count=module_state.metrics.tool_call_count,
            limitation_count=len(module_state.limitations), finding_count=len(module_state.findings),
        )
        uow.stage(lambda: self._run_repository.save_module_run(module_record))

        for objective_record in module_state.objective_history.values():
            uow.stage(lambda o=objective_record: self._run_repository.save_objective(final_state.run_id, module_state.module_id, o))

        for evidence in module_state.evidence:
            payload_type = evidence.structured_payload.payload_type if evidence.structured_payload is not None else None
            payload_data = (
                evidence.structured_payload.data
                if evidence.structured_payload is not None and self._settings.save_raw_tool_payload
                else None
            )
            evidence_record = EvidenceRecord(
                evidence_id=evidence.evidence_id, run_id=final_state.run_id, module_id=module_state.module_id,
                objective_id=evidence.objective_id, source_tool=evidence.source_tool, quality=evidence.quality,
                summary=evidence.summary, payload_type=payload_type, structured_payload=payload_data,
            )
            uow.stage(lambda r=evidence_record: self._run_repository.save_evidence(r))

        for finding in module_state.findings:
            finding_record = FindingRecord(
                finding_id=finding.finding_id, run_id=final_state.run_id, module_id=module_state.module_id,
                statement=finding.statement, pattern=finding.pattern, status=finding.status,
                confidence=finding.confidence, is_root_cause=finding.is_root_cause, entity_ids=list(finding.entity_ids),
            )
            links = [FindingEvidenceLink(finding_id=finding.finding_id, evidence_id=eid) for eid in finding.supporting_evidence_ids]
            uow.stage(lambda fr=finding_record, li=links: self._run_repository.save_finding(fr, li))

        handoff = self._handoff_builder.build(module_state)
        for root_cause in handoff.root_causes:
            root_cause_record = RootCauseRecord(
                root_cause_id=root_cause.root_cause_id, run_id=final_state.run_id, module_id=module_state.module_id,
                statement=root_cause.statement, confidence=root_cause.confidence, entity_ids=list(root_cause.entity_ids),
            )
            finding_links = [RootCauseFindingLink(root_cause_id=root_cause.root_cause_id, finding_id=fid) for fid in root_cause.supporting_finding_ids]
            uow.stage(lambda rr=root_cause_record, li=finding_links: self._run_repository.save_root_cause(rr, li))
