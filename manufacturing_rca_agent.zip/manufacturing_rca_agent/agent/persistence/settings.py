"""PersistenceSettings (Phase 8A item 21) -- retention/sensitive-data
policy contract only, no cleanup job, no enforcement beyond what
`RunPersistenceWriter` actively does with `save_raw_tool_payload` (redacts
`EvidenceRecord.structured_payload` when False, the default). Defaults are
all "don't keep it" -- secrets/credentials/raw provider auth/full prompts/
unnecessary raw payloads are never persisted unless explicitly opted in.

Mirrors the same "config carries the env-var *name*, never the secret
*value*" discipline `DataSourceConfig` already established (Phase 5D,
agent/datasource/models.py) -- nothing new needed there, this settings
object governs a different concern (what gets written to analysis/audit
persistence, not how a Tool authenticates to a remote system).
"""
from agent.state.base import RCABaseModel


class PersistenceSettings(RCABaseModel):
    save_raw_prompt: bool = False
    save_raw_tool_payload: bool = False
    audit_retention_days: int = 90
    analysis_retention_days: int = 365
