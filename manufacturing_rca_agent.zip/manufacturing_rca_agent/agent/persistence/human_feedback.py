"""HumanFeedbackSink (Phase 7A item 10, extended Phase 7B item 4) --
contract + InMemory reference impl only. `HumanFeedback` is post-run user
feedback about a *completed* analysis ("was the root cause correct",
thumbs up/down), a different concept from `HumanRequest`/`HumanAuditSink`
(agent/persistence/human_audit.py), which is the in-run interrupt/
permission-approval flow -- deliberately never merged into one table/
model (Phase 7B item 13).

Explicitly NOT mixed into `RunEvaluation`'s deterministic score --
see agent/evaluation/evaluator.py's own docstring and
agent/feedback/assessment.py, which is where a *view* combining both
lives without touching either source.

Append-only (Phase 7B item 4): if the same human re-evaluates something,
a NEW HumanFeedback record is added -- nothing here ever updates or
overwrites a prior record. `latest_for_target` reads "most recent by
created_at" as a projection over the full history, not a mutation of it.
"""
from typing import Protocol

from agent.state.enums import FeedbackTargetType
from agent.state.models import HumanFeedback


class HumanFeedbackSink(Protocol):
    def record(self, feedback: HumanFeedback) -> None: ...

    def get(self, feedback_id: str) -> HumanFeedback | None: ...

    def list_for_run(self, run_id: str) -> list[HumanFeedback]: ...

    def list_for_target(self, run_id: str, target_type: FeedbackTargetType, target_id: str | None) -> list[HumanFeedback]: ...

    def latest_for_target(self, run_id: str, target_type: FeedbackTargetType, target_id: str | None) -> HumanFeedback | None: ...


class InMemoryHumanFeedbackSink:
    def __init__(self) -> None:
        self._feedback: list[HumanFeedback] = []

    def record(self, feedback: HumanFeedback) -> None:
        self._feedback.append(feedback)

    def get(self, feedback_id: str) -> HumanFeedback | None:
        for f in self._feedback:
            if f.feedback_id == feedback_id:
                return f
        return None

    def list_for_run(self, run_id: str) -> list[HumanFeedback]:
        return [f for f in self._feedback if f.run_id == run_id]

    def list_for_target(self, run_id: str, target_type: FeedbackTargetType, target_id: str | None) -> list[HumanFeedback]:
        return [f for f in self._feedback if f.run_id == run_id and f.target_type == target_type and f.target_id == target_id]

    def latest_for_target(self, run_id: str, target_type: FeedbackTargetType, target_id: str | None) -> HumanFeedback | None:
        matches = self.list_for_target(run_id, target_type, target_id)
        if not matches:
            return None
        return max(matches, key=lambda f: f.created_at)
