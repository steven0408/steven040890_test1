"""CheckpointerProfile (Phase 8A item 20) -- a production config contract
only. This codebase does not reimplement LangGraph checkpoint internals;
every graph builder (`build_phase2_graph`, `build_phase6_graph`) already
takes a `BaseCheckpointSaver` instance as a parameter (`InMemorySaver` in
every test in this suite). This enum exists so a future bootstrap/config
layer has a typed way to select which saver a deployment should construct
-- it does not itself construct one, and `PRODUCTION_POSTGRES` has no
implementation behind it yet.

See docs/persistence.md section 1 for why checkpoint persistence ("where
is execution right now") and analysis/audit persistence ("what did the
Agent find/do") are two different responsibilities, never the same table,
even when both eventually live in the same PostgreSQL instance.
"""
from enum import Enum


class CheckpointerProfile(str, Enum):
    DEVELOPMENT_IN_MEMORY = "development_in_memory"
    PRODUCTION_POSTGRES = "production_postgres"
