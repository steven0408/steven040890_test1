"""RunController (Phase 5B-1.2) -- the harness-level bridge between a
LangGraph interrupt and HumanAuditSink.

    Execution Gate
        v
    interrupt(HumanRequest payload)
        v
    RunController                    <- this module
        v
    HumanAuditSink.record_request(...)
        v
    (Human responds, out of process)
        v
    RunController.resume(...)
        v
    HumanAuditSink.record_response(...)
        v
    Command(resume=HumanResponse)
        v
    Gate continues

This is deliberately narrow: it is NOT the full pause/resume/restart-branch
RunController described in the original architecture discussion (that is
still future work). Its only responsibility is making sure a pending Human
interrupt is materialized into HumanAuditSink -- and a Human's response is
recorded there -- WITHOUT ever calling `app.update_state()` while anything
from that invocation is still pending. Phase 5B-1.1 established that
`update_state()` on a checkpoint with a still-pending Send task causes
LangGraph to re-list and re-invoke every task from that pending superstep on
resume (tests/test_resume_replay_semantics.py); this controller's job is to
structurally make that call unnecessary for the Human flow, not to work
around it after the fact.
"""
from typing import Any

from langgraph.types import Command

from agent.persistence.human_audit import HumanAuditSink
from agent.state.enums import HumanDecision, HumanReason, HumanRequestStatus, RiskLevel
from agent.state.models import HumanRequest, HumanResponse, ResumeTarget


def _human_request_from_interrupt(payload: dict, request_id: str) -> HumanRequest:
    return HumanRequest(
        request_id=request_id,
        run_id=payload["run_id"],
        module_id=payload["module_id"],
        branch_id=payload["branch_id"],
        objective_id=payload["objective_id"],
        source_node=payload["source_node"],
        reason=HumanReason(payload["reason"]),
        question=payload["question"],
        options=payload["options"],
        permission_type=payload["permission_type"],
        risk_level=RiskLevel(payload["risk_level"]) if payload["risk_level"] else None,
        resume_target=ResumeTarget(
            module_id=payload["module_id"], node=payload["source_node"], objective_id=payload["objective_id"]
        ),
        status=HumanRequestStatus.PENDING,
        created_at_step=0,
    )


class RunController:
    def __init__(self, app: Any, audit_sink: HumanAuditSink):
        self.app = app
        self.audit_sink = audit_sink

    def start(self, initial_state: Any, config: dict) -> dict:
        result = self.app.invoke(initial_state, config=config)
        self._capture_pending_interrupts(result)
        return result

    def resume(
        self,
        config: dict,
        *,
        request_id: str,
        decision: HumanDecision,
        responded_by: str,
        responded_at,
        payload: str | None = None,
    ) -> dict:
        """Records the Human's response in HumanAuditSink, THEN resumes the
        graph via `Command(resume=...)` -- never `update_state()`."""
        response = HumanResponse(decision=decision, payload=payload, responded_by=responded_by, responded_at=responded_at)
        self.audit_sink.record_response(request_id, response)

        result = self.app.invoke(
            Command(resume={"decision": decision.value, "responded_by": responded_by}), config=config
        )
        self._capture_pending_interrupts(result)
        return result

    def _capture_pending_interrupts(self, result: dict) -> None:
        for pending in result.get("__interrupt__", []):
            request = _human_request_from_interrupt(pending.value, str(pending.id))
            self.audit_sink.record_request(request)
