"""PersistenceUnitOfWork (Phase 8A item 16) -- staged-write commit/rollback
boundary, InMemory only this phase (no real DB transaction). Every write a
caller wants inside one logical unit is queued via `stage(...)`; nothing
touches the underlying repositories until `commit()` runs the queue.
`rollback()` (explicit, or automatic on an exception inside the `with`
block, or automatic if the block exits without ever calling `commit()`)
just discards the queue -- since nothing was applied yet, discarding it
*is* the rollback. This is the InMemory-appropriate shape of "transaction
boundary"; a future real-DB unit of work would replace `commit()`'s body
with an actual `connection.commit()` and give `stage()` real statements to
queue, without changing this class's external contract.
"""
from typing import Callable


class PersistenceUnitOfWork:
    def __init__(self) -> None:
        self._pending: list[Callable[[], None]] = []
        self._committed = False

    def stage(self, operation: Callable[[], None]) -> None:
        """Queue a write (a zero-arg callable performing exactly one
        repository/sink call) to be applied on `commit()`."""
        self._pending.append(operation)

    def __enter__(self) -> "PersistenceUnitOfWork":
        self._pending = []
        self._committed = False
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        if exc_type is not None:
            self.rollback()
            return False  # never swallow the exception
        if not self._committed:
            self.rollback()  # no implicit commit -- a caller that forgot to call commit() gets a rollback, not a silent partial write
        return False

    def commit(self) -> None:
        for operation in self._pending:
            operation()
        self._pending = []
        self._committed = True

    def rollback(self) -> None:
        self._pending = []
        self._committed = False
