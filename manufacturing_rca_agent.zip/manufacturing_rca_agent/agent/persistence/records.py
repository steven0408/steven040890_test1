"""New persistence-only record shapes (Phase 8A) -- the artifacts that
don't already have a 1:1 runtime/audit model to reuse as-is. Everything
else (`Objective` -> `ObjectiveRecord`, `ToolCallRecord`, `LLMCallRecord`,
`ContextBuildRecord`/`SynthesisContextBuildRecord`, `PlannerDecisionRecord`,
`SynthesisGenerationRecord`, `EvaluationRecord`, `RunEvaluation`,
`HumanFeedback`, `LearningCandidate`, `LearningEvidenceLink`,
`CandidateReview`, `HandoffPackage`) is reused directly as its own
persistence schema -- each is already a relational-core-shaped Pydantic
model (scalar/typed-list fields), so a second parallel model would just be
duplication, not a real schema improvement. See docs/persistence.md for
the full relational-core-vs-JSONB-extension mapping table.

Strategy (item 3): relational core columns for anything a query needs to
filter/join on, a JSON extension for the rest -- never fully normalized,
never a single JSON blob per row. `Evidence`/`Finding`/`RootCause`
(agent/state/models.py) don't carry `run_id`/`module_id` at the runtime
layer (they don't need to -- lineage is reachable via `objective_id` at
runtime); these persistence wrappers denormalize those onto the row
because a relational table needs them for direct indexed lookup, matching
item 6's explicit column list.
"""
from datetime import datetime

from pydantic import Field

from agent.llm.context.knowledge_retriever import ValidationStatus
from agent.state.base import RCABaseModel
from agent.state.enums import EvidenceQuality, FindingStatus, ModuleStatus, RunTerminationStatus, TaskType


class RunRecord(RCABaseModel):
    run_id: str
    user_request: str
    normalized_request: str | None = None
    factory_id: str
    task_type: TaskType | None = None
    run_status: RunTerminationStatus
    started_at: datetime | None = None  # AgentState.started_at (Phase 8A-1) -- when the graph actually began, not UserRequest.submitted_at
    completed_at: datetime | None = None  # AgentState.completed_at (Phase 8A-1) -- stamped once by global_completion_check
    created_at: datetime
    schema_version: str = "1"
    application_version: str | None = None


class ModuleRunRecord(RCABaseModel):
    run_id: str
    module_id: str
    module_type: str
    task_type: TaskType
    module_status: ModuleStatus
    goal: str
    started_at: datetime | None = None  # ModuleState.started_at (Phase 8A-1) -- None only for a SKIPPED module (Option A)
    completed_at: datetime | None = None  # ModuleState.completed_at (Phase 8A-1) -- stamped once by module_completion_check on a terminal status
    step_count: int
    tool_call_count: int
    limitation_count: int
    finding_count: int
    schema_version: str = "1"


class EvidenceRecord(RCABaseModel):
    evidence_id: str
    run_id: str
    module_id: str
    objective_id: str
    source_tool: str
    quality: EvidenceQuality
    summary: str
    payload_type: str | None = None
    structured_payload: dict | None = None  # JSON extension -- StructuredPayload.data, never re-typed here
    schema_version: str = "1"


class FindingRecord(RCABaseModel):
    finding_id: str
    run_id: str
    module_id: str
    statement: str
    pattern: str
    status: FindingStatus
    confidence: float
    is_root_cause: bool
    entity_ids: list[str] = Field(default_factory=list)  # JSON extension
    schema_version: str = "1"


class FindingEvidenceLink(RCABaseModel):
    """Junction row -- always derived from `Finding.supporting_evidence_ids`
    (the runtime source of truth, agent/state/models.py), never
    independently authored. `Finding` already carries this linkage
    explicitly; this is the relational-table shape of it, not a new fact."""

    finding_id: str
    evidence_id: str


class RootCauseRecord(RCABaseModel):
    root_cause_id: str
    run_id: str
    module_id: str
    statement: str
    confidence: float
    entity_ids: list[str] = Field(default_factory=list)
    schema_version: str = "1"


class RootCauseFindingLink(RCABaseModel):
    """Derived from `RootCause.supporting_finding_ids` -- same relationship
    as FindingEvidenceLink, one lineage hop further up."""

    root_cause_id: str
    finding_id: str


class ValidatedKnowledgeRecord(RCABaseModel):
    """Phase 8A item 14 -- future-only contract. Nothing in this codebase
    writes to this table this phase; no repository/service constructs one
    (grep-verified the same way Phase 7C proved no automatic VALIDATED
    promotion path exists). A future KnowledgeRetriever
    (agent/llm/context/knowledge_retriever.py) would read only rows with
    `validation_status=VALIDATED` from wherever this ends up persisted --
    that wiring does not exist yet either."""

    knowledge_id: str
    statement: str
    knowledge_type: str  # free text -- a validated knowledge item need not have originated from a LearningCandidate at all
    validation_status: ValidationStatus
    confidence: float
    scope: str
    source_candidate_id: str | None = None
    approved_by: str | None = None
    approved_at: datetime | None = None
    version: int = 1
    schema_version: str = "1"
