"""LearningCandidateRepository (Phase 8A item 15) -- NOT a new sink.
`LearningCandidateSink` (agent/learning/sink.py) already fully represents
this domain's persistence capability (record/update/get/list/list_by_type/
list_by_status/find_by_candidate_key/record_evidence_link/
list_evidence_links); this composes an existing sink instance and adds the
one historical-query capability the sink doesn't already have --
`get_candidate_with_evidence` (item 19) -- rather than building a second,
mostly-duplicate Protocol.

`HumanFeedbackSink` (agent/persistence/human_feedback.py) needs no such
wrapper at all: `list_for_run`/`list_for_target`/`latest_for_target`
already cover item 19's `list_feedback(run_id)` directly -- it *is* the
Human Feedback Repository, unchanged.
"""
from dataclasses import dataclass

from agent.learning.signals import LearningEvidenceLink
from agent.learning.sink import LearningCandidateSink
from agent.state.models import LearningCandidate


@dataclass
class CandidateWithEvidence:
    candidate: LearningCandidate
    evidence_links: list[LearningEvidenceLink]


class LearningCandidateRepository:
    def __init__(self, sink: LearningCandidateSink):
        self._sink = sink

    def get_candidate_with_evidence(self, candidate_id: str) -> CandidateWithEvidence | None:
        candidate = self._sink.get(candidate_id)
        if candidate is None:
            return None
        return CandidateWithEvidence(candidate=candidate, evidence_links=self._sink.list_evidence_links(candidate_id))

    def __getattr__(self, name):
        # Pass-through to the composed sink for every capability it already
        # has (record/update/get/list/list_by_type/list_by_status/
        # find_by_candidate_key/record_evidence_link/list_evidence_links) --
        # deliberately not re-declared here one by one.
        return getattr(self._sink, name)
