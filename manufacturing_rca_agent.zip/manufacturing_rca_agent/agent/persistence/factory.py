"""Persistence backend selection (Phase 8B item 14) -- the one place that
chooses InMemory vs. PostgreSQL repository/sink implementations. Every
caller downstream of `build_persistence_layer()` (today: only
`RunPersistenceWriter` and whatever wires audit sinks into live graph
execution) depends solely on the Phase 8A Protocols
(`RunRepository`/`AuditRepository`/`HumanFeedbackSink`/
`LearningCandidateRepository`/a UnitOfWork with `stage`/`commit`/
`rollback`), never on which backend built them -- no graph node, Evaluator,
Learning generator, Synthesis, Skill, or Tool imports this module or
anything under `agent/persistence/postgres/`.

Connection lifetime (documented tradeoff, not a hidden gap): live
per-event audit writes (LLM/Tool/Planner/Synthesis/Context/Human-audit
sinks, plus HumanFeedback -- everything called *during* a run, outside any
explicit `RunPersistenceWriter.persist_run()` call) use an **autocommit**
connection, so each `.record()` is immediately durable on its own -- this
mirrors how the InMemory sinks already behave (an instant, unconditional
append) and needs no external commit call anywhere in live graph code.
`RunPersistenceWriter`'s own end-of-run aggregate (Run/Module/Objective/
Evidence/Finding/RootCause/HandoffPackage, plus the RunEvaluation/Feedback/
LearningCandidate writes staged alongside it) is what genuinely needs
atomic all-or-nothing semantics, and that's what
`PostgresPersistenceUnitOfWork`'s explicit (autocommit=False) transaction
guards. A feedback/learning write staged into the *same* `uow.commit()`
call as the Run aggregate is itself still durable the instant its own
`.record()` runs (autocommit), but is not rolled back if a *later* staged
operation in that same commit() call fails -- each sink's own writes are
atomic; the aggregate as a whole is not a single cross-connection
transaction. Solving true cross-connection distributed transactions is out
of scope for this foundation phase.
"""
from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable

from agent.persistence.audit_repository import AuditRepository, InMemoryRunEvaluationStore, build_default_audit_repository
from agent.persistence.human_feedback import HumanFeedbackSink, InMemoryHumanFeedbackSink
from agent.persistence.learning_repository import LearningCandidateRepository
from agent.persistence.postgres.config import PostgresSettings
from agent.persistence.postgres.connection import connection_factory_from_env
from agent.persistence.run_repository import InMemoryRunRepository, RunRepository
from agent.persistence.unit_of_work import PersistenceUnitOfWork
from agent.state.base import RCABaseModel


class PersistenceBackend(str, Enum):
    MEMORY = "memory"
    POSTGRES = "postgres"


class PersistenceBackendConfig(RCABaseModel):
    backend: PersistenceBackend = PersistenceBackend.MEMORY
    postgres: PostgresSettings | None = None


@dataclass
class PersistenceLayer:
    run_repository: RunRepository
    audit_repository: AuditRepository
    feedback_sink: HumanFeedbackSink
    learning_repository: LearningCandidateRepository
    make_unit_of_work: Callable[[], Any]


def _build_memory_persistence_layer() -> PersistenceLayer:
    from agent.learning.sink import InMemoryLearningCandidateSink

    return PersistenceLayer(
        run_repository=InMemoryRunRepository(),
        audit_repository=build_default_audit_repository(),
        feedback_sink=InMemoryHumanFeedbackSink(),
        learning_repository=LearningCandidateRepository(InMemoryLearningCandidateSink()),
        make_unit_of_work=PersistenceUnitOfWork,
    )


def _dict_row_connection(connection_factory: Callable[[], Any], *, autocommit: bool) -> Any:
    connection = connection_factory()
    connection.autocommit = autocommit
    try:
        from psycopg.rows import dict_row

        connection.row_factory = dict_row
    except ImportError:
        pass  # a FakeConnection (tests) has no row_factory concept -- it always hands back dicts already
    return connection


def _build_postgres_persistence_layer(
    settings: PostgresSettings, *, connection_factory: Callable[[], Any] | None = None
) -> PersistenceLayer:
    from agent.persistence.postgres.repositories import (
        PostgresContextAuditSink,
        PostgresEvaluationAuditSink,
        PostgresHumanAuditSink,
        PostgresHumanFeedbackSink,
        PostgresLearningCandidateSink,
        PostgresLLMUsageSink,
        PostgresPlannerDecisionAuditSink,
        PostgresRunEvaluationStore,
        PostgresRunRepository,
        PostgresSynthesisContextAuditSink,
        PostgresSynthesisGenerationAuditSink,
        PostgresToolCallAuditSink,
    )
    from agent.persistence.postgres.unit_of_work import PostgresPersistenceUnitOfWork

    factory = connection_factory or connection_factory_from_env(settings)

    # Live/event sinks: one autocommit connection each, so `.record()` is
    # immediately durable with no caller-managed transaction (see module
    # docstring). The Run aggregate below gets its own non-autocommit
    # connection instead, owned by a fresh PostgresPersistenceUnitOfWork
    # per logical persist_run() call.
    audit_conn = _dict_row_connection(factory, autocommit=True)
    feedback_conn = _dict_row_connection(factory, autocommit=True)
    learning_conn = _dict_row_connection(factory, autocommit=True)

    audit_repository = AuditRepository(
        llm_usage_sink=PostgresLLMUsageSink(audit_conn),
        planner_context_sink=PostgresContextAuditSink(audit_conn),
        synthesis_context_sink=PostgresSynthesisContextAuditSink(audit_conn),
        planner_decision_sink=PostgresPlannerDecisionAuditSink(audit_conn),
        synthesis_generation_sink=PostgresSynthesisGenerationAuditSink(audit_conn),
        tool_call_sink=PostgresToolCallAuditSink(audit_conn),
        human_audit_sink=PostgresHumanAuditSink(audit_conn),
        evaluation_audit_sink=PostgresEvaluationAuditSink(audit_conn),
        run_evaluation_store=PostgresRunEvaluationStore(audit_conn),
    )

    # `run_repository` and every `make_unit_of_work()` call MUST share this
    # exact connection object: RunPersistenceWriter always writes through
    # `self._run_repository` (bound once, at construction) regardless of
    # which `uow` a given `persist_run()` call was passed, so the UoW's
    # commit()/rollback() only actually applies to what was written if it
    # is committing/rolling back the *same* connection those writes landed
    # on. psycopg's autocommit=False mode starts a new implicit
    # transaction after every commit()/rollback() on the same connection,
    # so reusing one long-lived connection across many persist_run() calls
    # is the correct pattern here, not a leak.
    run_conn = _dict_row_connection(factory, autocommit=False)
    run_repository = PostgresRunRepository(run_conn)

    def make_unit_of_work() -> Any:
        return PostgresPersistenceUnitOfWork(run_conn)

    return PersistenceLayer(
        run_repository=run_repository,
        audit_repository=audit_repository,
        feedback_sink=PostgresHumanFeedbackSink(feedback_conn),
        learning_repository=LearningCandidateRepository(PostgresLearningCandidateSink(learning_conn)),
        make_unit_of_work=make_unit_of_work,
    )


def build_persistence_layer(
    config: PersistenceBackendConfig, *, connection_factory: Callable[[], Any] | None = None
) -> PersistenceLayer:
    """`connection_factory` is a test-only escape hatch (e.g. a
    `FakeConnection`-returning callable, or one pointed at an ephemeral
    local test container) -- production callers leave it `None` and let
    `config.postgres` resolve real env vars via
    `agent/persistence/postgres/connection.py`."""
    if config.backend == PersistenceBackend.MEMORY:
        return _build_memory_persistence_layer()
    if config.postgres is None:
        raise ValueError("PersistenceBackendConfig.backend is 'postgres' but .postgres settings are missing")
    return _build_postgres_persistence_layer(config.postgres, connection_factory=connection_factory)
