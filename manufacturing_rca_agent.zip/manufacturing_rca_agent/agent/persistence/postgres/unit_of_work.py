"""PostgresPersistenceUnitOfWork -- the real-transaction sibling of
`agent/persistence/unit_of_work.py::PersistenceUnitOfWork`. Same external
contract (`stage`/`commit`/`rollback`/context manager), so
`RunPersistenceWriter` (which only ever calls `uow.stage(...)` +
`uow.commit()`) needs zero changes to work against either backend -- see
that file's own docstring for why `stage()` exists at all (nothing touches
a repository until `commit()` runs the queue).

The one real difference: `commit()` here also calls the underlying
connection's real `.commit()`, and any exception raised while running the
queued operations (a mapping bug, a constraint violation, ...) triggers a
real `.rollback()` before propagating -- partial writes never survive past
this class. `PostgresPersistenceUnitOfWork` is the *only* thing in this
package that calls `connection.commit()`/`connection.rollback()`;
individual repositories never commit on their own (item 10's "transaction
owner只能是 UoW").
"""
from typing import Any, Callable


class PostgresPersistenceUnitOfWork:
    def __init__(self, connection: Any) -> None:
        self._connection = connection
        self._pending: list[Callable[[], None]] = []
        self._committed = False

    def stage(self, operation: Callable[[], None]) -> None:
        self._pending.append(operation)

    def __enter__(self) -> "PostgresPersistenceUnitOfWork":
        self._pending = []
        self._committed = False
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        if exc_type is not None:
            self.rollback()
            return False
        if not self._committed:
            self.rollback()
        return False

    def commit(self) -> None:
        try:
            for operation in self._pending:
                operation()
        except Exception:
            self._connection.rollback()
            self._pending = []
            self._committed = False
            raise
        self._connection.commit()
        self._pending = []
        self._committed = True

    def rollback(self) -> None:
        self._connection.rollback()
        self._pending = []
        self._committed = False
