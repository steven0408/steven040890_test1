"""PostgresConnectionFactory -- resolves `PostgresSettings`' env-var
*names* into an actual `psycopg` connection at call time, never earlier.
`psycopg` itself is imported lazily inside `connect()` so that every other
module in this package (config/schema/mapping/repositories/unit_of_work)
stays importable -- and testable -- in an environment that never installs
the optional `postgres` extra at all (offline mapping/repository-contract
tests use a `FakeConnection`, not this factory).

Repositories/`PostgresPersistenceUnitOfWork` never call `connect()`
themselves -- they're handed a connection object (real or fake) by
whoever composes them (`agent/persistence/factory.py`, or a test). This
factory is the *only* place `os.environ` is read for database
credentials.
"""
import os
from typing import Any, Callable

from agent.persistence.postgres.config import PostgresSettings
from agent.persistence.postgres.errors import DatabaseConfigurationError, DatabaseConnectionError, MissingDatabaseEnvironmentVariable


def _resolve_env(env_var_name: str, *, field_name: str) -> str:
    if not env_var_name:
        raise DatabaseConfigurationError(f"PostgresSettings.{field_name} must name a non-empty env var")
    value = os.environ.get(env_var_name)
    if value is None:
        raise MissingDatabaseEnvironmentVariable(
            f"PostgresSettings.{field_name} names env var '{env_var_name}', which is not set"
        )
    return value


def resolve_connection_params(settings: PostgresSettings) -> dict[str, Any]:
    """Resolves every env-var name in `settings` to its actual value --
    the one place a secret (password) briefly exists as a plain string, and
    only in memory, on its way into the driver's connect call. Never
    logged, never stored back onto any Pydantic model (`PostgresSettings`
    itself never gains a `password` field)."""
    return {
        "host": _resolve_env(settings.host_env, field_name="host_env"),
        "port": settings.port,
        "dbname": _resolve_env(settings.database_env, field_name="database_env"),
        "user": _resolve_env(settings.user_env, field_name="user_env"),
        "password": _resolve_env(settings.password_env, field_name="password_env"),
        "sslmode": settings.ssl_mode,
        "connect_timeout": settings.connect_timeout,
    }


def allow_test_database_only(settings: PostgresSettings, *, resolved_database_name: str) -> None:
    """Item 13's guard: even when a caller supplies a `TEST_POSTGRES_DSN`,
    refuse to proceed unless BOTH (a) `settings.require_test_database` is
    explicitly set, AND (b) the *resolved* (not just claimed) database name
    itself carries an unambiguous test marker. Checking the resolved name
    -- not trusting `require_test_database` alone -- means a misconfigured
    env var pointing at a production-looking database name is still
    rejected even if someone flipped the flag by mistake.

    Deliberately conservative: `test`/`tests` must appear in the name, and
    production-sounding substrings (`prod`, `production`) are rejected
    outright even if a test marker is also present.
    """
    if not settings.require_test_database:
        raise DatabaseConfigurationError(
            "refusing to connect: PostgresSettings.require_test_database is False -- "
            "this connection path is for tests only, see allow_test_database_only()"
        )
    lowered = resolved_database_name.lower()
    if "prod" in lowered:
        raise DatabaseConfigurationError(
            f"refusing to connect: database name '{resolved_database_name}' looks production-like (contains 'prod')"
        )
    if "test" not in lowered:
        raise DatabaseConfigurationError(
            f"refusing to connect: database name '{resolved_database_name}' has no 'test' marker -- "
            "test-only connections must use an explicitly test-named database"
        )


class PostgresConnectionFactory:
    """Thin wrapper the composition root (`agent/persistence/factory.py`)
    and integration tests use to obtain a real connection. Everything
    above this class (repositories, PostgresPersistenceUnitOfWork) takes a
    connection object as a constructor argument instead of depending on
    this factory directly, so they remain testable with a `FakeConnection`
    that never imports `psycopg`."""

    def __init__(self, settings: PostgresSettings, *, for_test: bool = False):
        self._settings = settings
        self._for_test = for_test

    def connect(self) -> Any:
        params = resolve_connection_params(self._settings)
        if self._for_test:
            allow_test_database_only(self._settings, resolved_database_name=params["dbname"])
        try:
            import psycopg  # lazy: only required when an actual connection is opened
        except ImportError as exc:
            raise DatabaseConnectionError(
                "psycopg is not installed -- install the 'postgres' extra to use PostgresConnectionFactory.connect()"
            ) from exc
        try:
            return psycopg.connect(**params, autocommit=False)
        except psycopg.Error as exc:
            raise DatabaseConnectionError(f"failed to connect to PostgreSQL: {exc}") from exc


def connection_factory_from_env(
    settings: PostgresSettings, *, for_test: bool = False, connect_fn: Callable[[], Any] | None = None
) -> Callable[[], Any]:
    """Convenience: returns a zero-arg callable producing a fresh
    connection, for callers (factory.py) that just want `connect()` as a
    plain function rather than holding a `PostgresConnectionFactory`
    instance. `connect_fn` lets a test substitute its own connection
    builder (e.g. one pointed at an ephemeral local test container)
    without going through env-var resolution at all."""
    if connect_fn is not None:
        return connect_fn
    return PostgresConnectionFactory(settings, for_test=for_test).connect
