"""Deterministic Record <-> SQL row mappings (item 11). Every `*_to_row`
returns a plain `dict[str, Any]` keyed by column name (Python-native
values: enums already reduced to `.value`, nested Pydantic objects reduced
to plain dict/list via `model_dump(mode="json")` for JSONB columns,
`datetime` objects passed through as-is for TIMESTAMPTZ columns -- never
pre-serialized to a string, so round-tripping never turns a timezone-aware
value naive). Every `*_from_row` takes a `dict` (a cursor row, using
`psycopg.rows.dict_row` as the row factory) and reconstructs the exact
Pydantic Record.

No `psycopg` import here -- `_jsonb()` degrades to a plain dict/list
when `psycopg` isn't installed (see its own docstring), which is what
lets `tests/test_persistence_postgres_mapping.py` round-trip every mapping
without the `postgres` extra.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

from agent.evaluation.audit import EvaluationRecord
from agent.llm.context.context_audit import ContextBuildRecord
from agent.llm.context.synthesis_context_audit import SynthesisContextBuildRecord
from agent.llm.models import LLMCallRecord, LLMCallStatus
from agent.learning.review import CandidateReview
from agent.learning.signals import LearningEvidenceLink, LearningSignalType
from agent.persistence.records import (
    EvidenceRecord,
    FindingEvidenceLink,
    FindingRecord,
    ModuleRunRecord,
    RootCauseFindingLink,
    RootCauseRecord,
    RunRecord,
    ValidatedKnowledgeRecord,
)
from agent.planning.decision_audit import PlannerDecisionRecord
from agent.llm.context.knowledge_retriever import ValidationStatus
from agent.state.enums import (
    CandidateReviewDecision,
    EvidenceQuality,
    FindingStatus,
    HumanDecision,
    HumanFeedbackThumbs,
    HumanReason,
    HumanRequestStatus,
    LearningCandidateStatus,
    LearningCandidateType,
    LearningDestination,
    ModuleStatus,
    ObjectiveAction,
    ObjectiveStatus,
    ObservationStatus,
    RiskLevel,
    RunTerminationStatus,
    TaskType,
)
from agent.state.models import (
    AnalyticalQualityMetrics,
    DecisionQualityMetrics,
    DeliveryQualityMetrics,
    EfficiencyMetrics,
    EvaluationIssue,
    HandoffPackage,
    HumanFeedback,
    HumanRequest,
    HumanResponse,
    LearningCandidate,
    ObjectiveRecord,
    ResumeTarget,
    RunEvaluation,
    TargetRef,
)
from agent.state.scope import ObjectiveScope
from agent.synthesis.decision_audit import SynthesisGenerationRecord
from agent.tools.execution_manager import ToolCallRecord


def _enum(value: Any) -> str | None:
    return value.value if value is not None else None


def _jsonb(value: Any) -> Any:
    """Wraps a plain dict/list for psycopg's JSONB adapter when
    `psycopg` is installed; otherwise returns the value unchanged so
    mapping functions stay importable and testable without the
    `postgres` extra (a `FakeConnection` only needs *some* Python
    object to record, not a real Postgres-adapted one)."""
    if value is None:
        return None
    try:
        from psycopg.types.json import Jsonb

        return Jsonb(value)
    except ImportError:
        return value


def _model_json(model) -> dict | None:
    return model.model_dump(mode="json") if model is not None else None


# ============================================================================
# A. Run / Analysis aggregate
# ============================================================================


def run_to_row(record: RunRecord) -> dict[str, Any]:
    return {
        "run_id": record.run_id,
        "user_request": record.user_request,
        "normalized_request": record.normalized_request,
        "factory_id": record.factory_id,
        "task_type": _enum(record.task_type),
        "run_status": _enum(record.run_status),
        "started_at": record.started_at,
        "completed_at": record.completed_at,
        "created_at": record.created_at,
        "schema_version": record.schema_version,
        "application_version": record.application_version,
    }


def run_from_row(row: dict) -> RunRecord:
    return RunRecord(
        run_id=row["run_id"],
        user_request=row["user_request"],
        normalized_request=row["normalized_request"],
        factory_id=row["factory_id"],
        task_type=TaskType(row["task_type"]) if row["task_type"] is not None else None,
        run_status=RunTerminationStatus(row["run_status"]),
        started_at=row["started_at"],
        completed_at=row["completed_at"],
        created_at=row["created_at"],
        schema_version=row["schema_version"],
        application_version=row["application_version"],
    )


def module_run_to_row(record: ModuleRunRecord) -> dict[str, Any]:
    return {
        "run_id": record.run_id,
        "module_id": record.module_id,
        "module_type": record.module_type,
        "task_type": _enum(record.task_type),
        "module_status": _enum(record.module_status),
        "goal": record.goal,
        "started_at": record.started_at,
        "completed_at": record.completed_at,
        "step_count": record.step_count,
        "tool_call_count": record.tool_call_count,
        "limitation_count": record.limitation_count,
        "finding_count": record.finding_count,
        "schema_version": record.schema_version,
    }


def module_run_from_row(row: dict) -> ModuleRunRecord:
    return ModuleRunRecord(
        run_id=row["run_id"],
        module_id=row["module_id"],
        module_type=row["module_type"],
        task_type=TaskType(row["task_type"]),
        module_status=ModuleStatus(row["module_status"]),
        goal=row["goal"],
        started_at=row["started_at"],
        completed_at=row["completed_at"],
        step_count=row["step_count"],
        tool_call_count=row["tool_call_count"],
        limitation_count=row["limitation_count"],
        finding_count=row["finding_count"],
        schema_version=row["schema_version"],
    )


def objective_to_row(run_id: str, module_id: str, record: ObjectiveRecord) -> dict[str, Any]:
    return {
        "objective_id": record.objective_id,
        "run_id": run_id,
        "module_id": module_id,
        "description": record.description,
        "action": _enum(record.action),
        "capability_key": record.capability_key,
        "target_ref": _jsonb(_model_json(record.target_ref)),
        "scope": _jsonb(_model_json(record.scope)),
        "status": _enum(record.status),
        "created_step": record.created_step,
        "completed_step": record.completed_step,
        "attempt_count": record.attempt_count,
        "observation_ids": list(record.observation_ids),
        "evidence_ids": list(record.evidence_ids),
        "termination_reason": record.termination_reason,
    }


def objective_from_row(row: dict) -> ObjectiveRecord:
    return ObjectiveRecord(
        objective_id=row["objective_id"],
        description=row["description"],
        action=ObjectiveAction(row["action"]),
        capability_key=row.get("capability_key"),
        target_ref=TargetRef.model_validate(row["target_ref"]),
        scope=ObjectiveScope.model_validate(row["scope"]) if row.get("scope") is not None else None,
        status=ObjectiveStatus(row["status"]),
        created_step=row["created_step"],
        completed_step=row["completed_step"],
        attempt_count=row["attempt_count"],
        observation_ids=list(row["observation_ids"] or []),
        evidence_ids=list(row["evidence_ids"] or []),
        termination_reason=row["termination_reason"],
    )


def evidence_to_row(record: EvidenceRecord) -> dict[str, Any]:
    return {
        "evidence_id": record.evidence_id,
        "run_id": record.run_id,
        "module_id": record.module_id,
        "objective_id": record.objective_id,
        "source_tool": record.source_tool,
        "quality": _enum(record.quality),
        "summary": record.summary,
        "payload_type": record.payload_type,
        "structured_payload": _jsonb(record.structured_payload),
        "schema_version": record.schema_version,
    }


def evidence_from_row(row: dict) -> EvidenceRecord:
    return EvidenceRecord(
        evidence_id=row["evidence_id"],
        run_id=row["run_id"],
        module_id=row["module_id"],
        objective_id=row["objective_id"],
        source_tool=row["source_tool"],
        quality=EvidenceQuality(row["quality"]),
        summary=row["summary"],
        payload_type=row["payload_type"],
        structured_payload=row["structured_payload"],
        schema_version=row["schema_version"],
    )


def finding_to_row(record: FindingRecord) -> dict[str, Any]:
    return {
        "finding_id": record.finding_id,
        "run_id": record.run_id,
        "module_id": record.module_id,
        "statement": record.statement,
        "pattern": record.pattern,
        "status": _enum(record.status),
        "confidence": record.confidence,
        "is_root_cause": record.is_root_cause,
        "entity_ids": list(record.entity_ids),
        "schema_version": record.schema_version,
    }


def finding_from_row(row: dict) -> FindingRecord:
    return FindingRecord(
        finding_id=row["finding_id"],
        run_id=row["run_id"],
        module_id=row["module_id"],
        statement=row["statement"],
        pattern=row["pattern"],
        status=FindingStatus(row["status"]),
        confidence=row["confidence"],
        is_root_cause=row["is_root_cause"],
        entity_ids=list(row["entity_ids"] or []),
        schema_version=row["schema_version"],
    )


def finding_evidence_link_to_row(link: FindingEvidenceLink) -> dict[str, Any]:
    return {"finding_id": link.finding_id, "evidence_id": link.evidence_id}


def finding_evidence_link_from_row(row: dict) -> FindingEvidenceLink:
    return FindingEvidenceLink(finding_id=row["finding_id"], evidence_id=row["evidence_id"])


def root_cause_to_row(record: RootCauseRecord) -> dict[str, Any]:
    return {
        "root_cause_id": record.root_cause_id,
        "run_id": record.run_id,
        "module_id": record.module_id,
        "statement": record.statement,
        "confidence": record.confidence,
        "entity_ids": list(record.entity_ids),
        "schema_version": record.schema_version,
    }


def root_cause_from_row(row: dict) -> RootCauseRecord:
    return RootCauseRecord(
        root_cause_id=row["root_cause_id"],
        run_id=row["run_id"],
        module_id=row["module_id"],
        statement=row["statement"],
        confidence=row["confidence"],
        entity_ids=list(row["entity_ids"] or []),
        schema_version=row["schema_version"],
    )


def root_cause_finding_link_to_row(link: RootCauseFindingLink) -> dict[str, Any]:
    return {"root_cause_id": link.root_cause_id, "finding_id": link.finding_id}


def root_cause_finding_link_from_row(row: dict) -> RootCauseFindingLink:
    return RootCauseFindingLink(root_cause_id=row["root_cause_id"], finding_id=row["finding_id"])


def handoff_package_to_row(package: HandoffPackage) -> dict[str, Any]:
    return {
        "run_id": package.run_id,
        "task_type": _enum(package.task_type),
        "overall_status": _enum(package.overall_status),
        "payload": _jsonb(package.model_dump(mode="json")),
    }


def handoff_package_from_row(row: dict) -> HandoffPackage:
    return HandoffPackage.model_validate(row["payload"])


# ============================================================================
# B. Audit domain
# ============================================================================


def llm_call_to_row(record: LLMCallRecord) -> dict[str, Any]:
    return {
        "llm_call_id": record.llm_call_id,
        "run_id": record.run_id,
        "module_id": record.module_id,
        "node": record.node,
        "route": record.route,
        "model": record.model,
        "input_tokens": record.input_tokens,
        "output_tokens": record.output_tokens,
        "latency_ms": record.latency_ms,
        "status": _enum(record.status),
        "retry_count": record.retry_count,
        "estimated_cost": record.estimated_cost,
        "error_message": record.error_message,
        "started_at": record.started_at,
        "completed_at": record.completed_at,
    }


def llm_call_from_row(row: dict) -> LLMCallRecord:
    return LLMCallRecord(
        llm_call_id=row["llm_call_id"], run_id=row["run_id"], module_id=row["module_id"], node=row["node"],
        route=row["route"], model=row["model"], input_tokens=row["input_tokens"], output_tokens=row["output_tokens"],
        latency_ms=row["latency_ms"], status=LLMCallStatus(row["status"]), retry_count=row["retry_count"],
        estimated_cost=row["estimated_cost"], error_message=row["error_message"],
        started_at=row["started_at"], completed_at=row["completed_at"],
    )


def context_build_to_row(record: ContextBuildRecord) -> dict[str, Any]:
    return {
        "context_build_record_id": record.context_build_record_id, "run_id": record.run_id, "module_id": record.module_id,
        "node": record.node, "included_findings_count": record.included_findings_count,
        "included_evidence_count": record.included_evidence_count, "included_skills_count": record.included_skills_count,
        "included_knowledge_count": record.included_knowledge_count,
        "included_reasoning_skills_count": record.included_reasoning_skills_count,
        "estimated_context_characters": record.estimated_context_characters, "items_trimmed": record.items_trimmed,
        "build_duration_ms": record.build_duration_ms, "started_at": record.started_at, "completed_at": record.completed_at,
    }


def context_build_from_row(row: dict) -> ContextBuildRecord:
    return ContextBuildRecord(
        context_build_record_id=row["context_build_record_id"], run_id=row["run_id"], module_id=row["module_id"],
        node=row["node"], included_findings_count=row["included_findings_count"],
        included_evidence_count=row["included_evidence_count"], included_skills_count=row["included_skills_count"],
        included_knowledge_count=row["included_knowledge_count"],
        included_reasoning_skills_count=row["included_reasoning_skills_count"],
        estimated_context_characters=row["estimated_context_characters"], items_trimmed=row["items_trimmed"],
        build_duration_ms=row["build_duration_ms"], started_at=row["started_at"], completed_at=row["completed_at"],
    )


def synthesis_context_build_to_row(record: SynthesisContextBuildRecord) -> dict[str, Any]:
    return {
        "context_build_record_id": record.context_build_record_id, "run_id": record.run_id,
        "included_modules": list(record.included_modules), "included_findings_count": record.included_findings_count,
        "included_root_causes_count": record.included_root_causes_count,
        "included_limitations_count": record.included_limitations_count,
        "included_reasoning_skills_count": record.included_reasoning_skills_count,
        "estimated_context_characters": record.estimated_context_characters, "items_trimmed": record.items_trimmed,
        "build_duration_ms": record.build_duration_ms, "started_at": record.started_at, "completed_at": record.completed_at,
    }


def synthesis_context_build_from_row(row: dict) -> SynthesisContextBuildRecord:
    return SynthesisContextBuildRecord(
        context_build_record_id=row["context_build_record_id"], run_id=row["run_id"],
        included_modules=list(row["included_modules"] or []), included_findings_count=row["included_findings_count"],
        included_root_causes_count=row["included_root_causes_count"],
        included_limitations_count=row["included_limitations_count"],
        included_reasoning_skills_count=row["included_reasoning_skills_count"],
        estimated_context_characters=row["estimated_context_characters"], items_trimmed=row["items_trimmed"],
        build_duration_ms=row["build_duration_ms"], started_at=row["started_at"], completed_at=row["completed_at"],
    )


def planner_decision_to_row(record: PlannerDecisionRecord) -> dict[str, Any]:
    return {
        "decision_record_id": record.decision_record_id, "run_id": record.run_id, "module_id": record.module_id,
        "step": record.step, "decision": _enum(record.decision), "proposed_action": _enum(record.proposed_action),
        "proposed_capability_key": record.proposed_capability_key,
        "target_ref": _jsonb(_model_json(record.target_ref)), "priority": record.priority, "source": _enum(record.source),
        "rationale_summary": record.rationale_summary, "context_build_record_id": record.context_build_record_id,
        "llm_call_id": record.llm_call_id, "fallback_reason": record.fallback_reason, "created_at": record.created_at,
    }


def planner_decision_from_row(row: dict) -> PlannerDecisionRecord:
    from agent.llm.models import DecisionSource
    from agent.llm.prompts.planner import PlannerDecisionType

    return PlannerDecisionRecord(
        decision_record_id=row["decision_record_id"], run_id=row["run_id"], module_id=row["module_id"], step=row["step"],
        decision=PlannerDecisionType(row["decision"]),
        proposed_action=ObjectiveAction(row["proposed_action"]) if row["proposed_action"] is not None else None,
        proposed_capability_key=row.get("proposed_capability_key"),
        target_ref=TargetRef.model_validate(row["target_ref"]) if row["target_ref"] is not None else None,
        priority=row["priority"], source=DecisionSource(row["source"]), rationale_summary=row["rationale_summary"],
        context_build_record_id=row["context_build_record_id"], llm_call_id=row["llm_call_id"],
        fallback_reason=row["fallback_reason"], created_at=row["created_at"],
    )


def synthesis_generation_to_row(record: SynthesisGenerationRecord) -> dict[str, Any]:
    return {
        "synthesis_record_id": record.synthesis_record_id, "run_id": record.run_id, "source": _enum(record.source),
        "context_build_record_id": record.context_build_record_id, "llm_call_id": record.llm_call_id,
        "included_module_ids": list(record.included_module_ids),
        "referenced_finding_ids": list(record.referenced_finding_ids),
        "referenced_root_cause_ids": list(record.referenced_root_cause_ids),
        "referenced_relation_ids": list(record.referenced_relation_ids),
        "referenced_recommendation_ids": list(record.referenced_recommendation_ids),
        "fallback_reason": record.fallback_reason, "created_at": record.created_at,
    }


def synthesis_generation_from_row(row: dict) -> SynthesisGenerationRecord:
    from agent.synthesis.decision_audit import SynthesisSource

    return SynthesisGenerationRecord(
        synthesis_record_id=row["synthesis_record_id"], run_id=row["run_id"], source=SynthesisSource(row["source"]),
        context_build_record_id=row["context_build_record_id"], llm_call_id=row["llm_call_id"],
        included_module_ids=list(row["included_module_ids"] or []),
        referenced_finding_ids=list(row["referenced_finding_ids"] or []),
        referenced_root_cause_ids=list(row["referenced_root_cause_ids"] or []),
        referenced_relation_ids=list(row["referenced_relation_ids"] or []),
        referenced_recommendation_ids=list(row["referenced_recommendation_ids"] or []),
        fallback_reason=row["fallback_reason"], created_at=row["created_at"],
    )


def tool_call_to_row(record: ToolCallRecord) -> dict[str, Any]:
    return {
        "tool_call_id": record.tool_call_id, "run_id": record.run_id, "module_id": record.module_id,
        "objective_id": record.objective_id, "skill_id": record.skill_id, "tool_id": record.tool_id,
        "status": _enum(record.status), "duration_seconds": record.duration_seconds,
        "error": _jsonb(_model_json(record.error)), "sandboxed": record.sandboxed,
        "started_at": record.started_at, "completed_at": record.completed_at,
        "idempotency_key": record.idempotency_key, "logical_call_id": record.logical_call_id,
        "attempt_number": record.attempt_number, "replayed": record.replayed, "result_reused": record.result_reused,
    }


def tool_call_from_row(row: dict) -> ToolCallRecord:
    from agent.state.models import ErrorRecord

    return ToolCallRecord(
        tool_call_id=row["tool_call_id"], run_id=row["run_id"], module_id=row["module_id"],
        objective_id=row["objective_id"], skill_id=row["skill_id"], tool_id=row["tool_id"],
        status=ObservationStatus(row["status"]), duration_seconds=row["duration_seconds"],
        error=ErrorRecord.model_validate(row["error"]) if row["error"] is not None else None,
        sandboxed=row["sandboxed"], started_at=row["started_at"], completed_at=row["completed_at"],
        idempotency_key=row["idempotency_key"], logical_call_id=row["logical_call_id"],
        attempt_number=row["attempt_number"], replayed=row["replayed"], result_reused=row["result_reused"],
    )


def evaluation_record_to_row(record: EvaluationRecord) -> dict[str, Any]:
    return {
        "evaluation_id": record.evaluation_id, "run_id": record.run_id, "evaluator_version": record.evaluator_version,
        "evaluated_at": record.evaluated_at, "metric_source_counts": _jsonb(dict(record.metric_source_counts)),
        "planner_decision_record_ids": list(record.planner_decision_record_ids),
        "synthesis_record_id": record.synthesis_record_id, "tool_audit_record_count": record.tool_audit_record_count,
        "llm_call_record_count": record.llm_call_record_count, "context_record_count": record.context_record_count,
        "human_intervention_count": record.human_intervention_count,
    }


def evaluation_record_from_row(row: dict) -> EvaluationRecord:
    return EvaluationRecord(
        evaluation_id=row["evaluation_id"], run_id=row["run_id"], evaluator_version=row["evaluator_version"],
        evaluated_at=row["evaluated_at"], metric_source_counts=dict(row["metric_source_counts"] or {}),
        planner_decision_record_ids=list(row["planner_decision_record_ids"] or []),
        synthesis_record_id=row["synthesis_record_id"], tool_audit_record_count=row["tool_audit_record_count"],
        llm_call_record_count=row["llm_call_record_count"], context_record_count=row["context_record_count"],
        human_intervention_count=row["human_intervention_count"],
    )


def human_request_to_row(request: HumanRequest) -> dict[str, Any]:
    return {
        "request_id": request.request_id, "run_id": request.run_id, "module_id": request.module_id,
        "branch_id": request.branch_id, "objective_id": request.objective_id, "source_node": request.source_node,
        "reason": _enum(request.reason), "question": request.question,
        "options": list(request.options) if request.options is not None else None,
        "permission_type": request.permission_type, "risk_level": _enum(request.risk_level),
        "resume_target": _jsonb(_model_json(request.resume_target)), "status": _enum(request.status),
        "created_at_step": request.created_at_step,
    }


def human_request_from_row(row: dict, response_row: dict | None) -> HumanRequest:
    return HumanRequest(
        request_id=row["request_id"], run_id=row["run_id"], module_id=row["module_id"], branch_id=row["branch_id"],
        objective_id=row["objective_id"], source_node=row["source_node"], reason=HumanReason(row["reason"]),
        question=row["question"], options=list(row["options"]) if row["options"] is not None else None,
        permission_type=row["permission_type"],
        risk_level=RiskLevel(row["risk_level"]) if row["risk_level"] is not None else None,
        resume_target=ResumeTarget.model_validate(row["resume_target"]),
        status=HumanRequestStatus(row["status"]),
        response=human_response_from_row(response_row) if response_row is not None else None,
        created_at_step=row["created_at_step"],
    )


def human_response_to_row(request_id: str, response: HumanResponse) -> dict[str, Any]:
    return {
        "request_id": request_id, "decision": _enum(response.decision), "payload": response.payload,
        "responded_by": response.responded_by, "responded_at": response.responded_at,
    }


def human_response_from_row(row: dict) -> HumanResponse:
    return HumanResponse(
        decision=HumanDecision(row["decision"]), payload=row["payload"],
        responded_by=row["responded_by"], responded_at=row["responded_at"],
    )


# ============================================================================
# C. RunEvaluation + issues
# ============================================================================


def run_evaluation_to_row(evaluation: RunEvaluation) -> dict[str, Any]:
    return {
        "evaluation_id": evaluation.evaluation_id, "run_id": evaluation.run_id,
        "evaluator_version": evaluation.evaluator_version, "evaluated_at": evaluation.evaluated_at,
        "efficiency": _jsonb(_model_json(evaluation.efficiency)),
        "analytical_quality": _jsonb(_model_json(evaluation.analytical_quality)),
        "decision_quality": _jsonb(_model_json(evaluation.decision_quality)),
        "delivery_quality": _jsonb(_model_json(evaluation.delivery_quality)),
        "weighting": _jsonb(_model_json(evaluation.weighting)),
        "overall_score": evaluation.overall_score, "schema_version": evaluation.schema_version,
    }


def run_evaluation_from_row(row: dict, issues: list[EvaluationIssue]) -> RunEvaluation:
    # Pydantic v2 coerces a plain dict into the declared nested model type
    # on construction, so `weighting` (dict | None straight off the JSONB
    # column) needs no separate model_validate() call here.
    return RunEvaluation(
        evaluation_id=row["evaluation_id"], run_id=row["run_id"], evaluator_version=row["evaluator_version"],
        evaluated_at=row["evaluated_at"], efficiency=EfficiencyMetrics.model_validate(row["efficiency"]),
        analytical_quality=AnalyticalQualityMetrics.model_validate(row["analytical_quality"]),
        decision_quality=DecisionQualityMetrics.model_validate(row["decision_quality"]),
        delivery_quality=DeliveryQualityMetrics.model_validate(row["delivery_quality"]),
        issues=issues, weighting=row["weighting"], overall_score=row["overall_score"], schema_version=row["schema_version"],
    )


def evaluation_issue_to_row(evaluation_id: str, issue: EvaluationIssue) -> dict[str, Any]:
    return {
        "issue_id": issue.issue_id, "evaluation_id": evaluation_id, "category": _enum(issue.category),
        "severity": _enum(issue.severity), "statement": issue.statement,
        "related_module_ids": list(issue.related_module_ids), "related_objective_ids": list(issue.related_objective_ids),
        "metric_name": issue.metric_name, "evidence_refs": list(issue.evidence_refs),
        "suggested_improvement_area": issue.suggested_improvement_area,
    }


def evaluation_issue_from_row(row: dict) -> EvaluationIssue:
    from agent.state.enums import EvaluationCategory, EvaluationSeverity

    return EvaluationIssue(
        issue_id=row["issue_id"], category=EvaluationCategory(row["category"]), severity=EvaluationSeverity(row["severity"]),
        statement=row["statement"], related_module_ids=list(row["related_module_ids"] or []),
        related_objective_ids=list(row["related_objective_ids"] or []), metric_name=row["metric_name"],
        evidence_refs=list(row["evidence_refs"] or []), suggested_improvement_area=row["suggested_improvement_area"],
    )


# ============================================================================
# D. Human Feedback
# ============================================================================


def human_feedback_to_row(feedback: HumanFeedback) -> dict[str, Any]:
    return {
        "feedback_id": feedback.feedback_id, "run_id": feedback.run_id, "target_type": _enum(feedback.target_type),
        "target_id": feedback.target_id, "user_id": feedback.user_id, "thumbs": _enum(feedback.thumbs),
        "answer_helpful": feedback.answer_helpful, "root_cause_correct": feedback.root_cause_correct,
        "finding_correct": feedback.finding_correct, "recommendation_useful": feedback.recommendation_useful,
        "comment": feedback.comment, "source": feedback.source, "session_id": feedback.session_id,
        "feedback_version": feedback.feedback_version, "created_at": feedback.created_at,
    }


def human_feedback_from_row(row: dict) -> HumanFeedback:
    from agent.state.enums import FeedbackTargetType

    return HumanFeedback(
        feedback_id=row["feedback_id"], run_id=row["run_id"], target_type=FeedbackTargetType(row["target_type"]),
        target_id=row["target_id"], user_id=row["user_id"], thumbs=HumanFeedbackThumbs(row["thumbs"]),
        answer_helpful=row["answer_helpful"], root_cause_correct=row["root_cause_correct"],
        finding_correct=row["finding_correct"], recommendation_useful=row["recommendation_useful"],
        comment=row["comment"], source=row["source"], session_id=row["session_id"],
        feedback_version=row["feedback_version"], created_at=row["created_at"],
    )


# ============================================================================
# E. Learning
# ============================================================================


def learning_candidate_to_row(candidate: LearningCandidate) -> dict[str, Any]:
    return {
        "candidate_id": candidate.candidate_id, "candidate_type": _enum(candidate.candidate_type),
        "title": candidate.title, "statement": candidate.statement, "status": _enum(candidate.status),
        "confidence": candidate.confidence, "source_run_ids": list(candidate.source_run_ids),
        "source_module_ids": list(candidate.source_module_ids),
        "supporting_finding_ids": list(candidate.supporting_finding_ids),
        "supporting_root_cause_ids": list(candidate.supporting_root_cause_ids),
        "evaluation_issue_ids": list(candidate.evaluation_issue_ids),
        "feedback_issue_ids": list(candidate.feedback_issue_ids),
        "planner_decision_record_ids": list(candidate.planner_decision_record_ids),
        "supporting_signal_count": candidate.supporting_signal_count,
        "contradicting_signal_count": candidate.contradicting_signal_count,
        "created_at": candidate.created_at, "updated_at": candidate.updated_at, "scope": candidate.scope,
        "proposed_destination": _enum(candidate.proposed_destination), "candidate_key": candidate.candidate_key,
        "rationale_summary": candidate.rationale_summary, "schema_version": candidate.schema_version,
    }


def learning_candidate_from_row(row: dict) -> LearningCandidate:
    return LearningCandidate(
        candidate_id=row["candidate_id"], candidate_type=LearningCandidateType(row["candidate_type"]),
        title=row["title"], statement=row["statement"], status=LearningCandidateStatus(row["status"]),
        confidence=row["confidence"], source_run_ids=list(row["source_run_ids"] or []),
        source_module_ids=list(row["source_module_ids"] or []),
        supporting_finding_ids=list(row["supporting_finding_ids"] or []),
        supporting_root_cause_ids=list(row["supporting_root_cause_ids"] or []),
        evaluation_issue_ids=list(row["evaluation_issue_ids"] or []),
        feedback_issue_ids=list(row["feedback_issue_ids"] or []),
        planner_decision_record_ids=list(row["planner_decision_record_ids"] or []),
        supporting_signal_count=row["supporting_signal_count"], contradicting_signal_count=row["contradicting_signal_count"],
        created_at=row["created_at"], updated_at=row["updated_at"], scope=row["scope"],
        proposed_destination=LearningDestination(row["proposed_destination"]), candidate_key=row["candidate_key"],
        rationale_summary=row["rationale_summary"], schema_version=row["schema_version"],
    )


def learning_evidence_link_to_row(link: LearningEvidenceLink) -> dict[str, Any]:
    return {
        "link_id": link.link_id, "candidate_id": link.candidate_id, "signal_type": _enum(link.signal_type),
        "source_run_id": link.source_run_id, "source_id": link.source_id, "supports": link.supports,
        "strength": link.strength, "note": link.note,
    }


def learning_evidence_link_from_row(row: dict) -> LearningEvidenceLink:
    return LearningEvidenceLink(
        link_id=row["link_id"], candidate_id=row["candidate_id"], signal_type=LearningSignalType(row["signal_type"]),
        source_run_id=row["source_run_id"], source_id=row["source_id"], supports=row["supports"],
        strength=row["strength"], note=row["note"],
    )


def candidate_review_to_row(review: CandidateReview) -> dict[str, Any]:
    return {
        "review_id": review.review_id, "candidate_id": review.candidate_id, "reviewer": review.reviewer,
        "decision": _enum(review.decision), "comment": review.comment, "reviewed_at": review.reviewed_at,
    }


def candidate_review_from_row(row: dict) -> CandidateReview:
    return CandidateReview(
        review_id=row["review_id"], candidate_id=row["candidate_id"], reviewer=row["reviewer"],
        decision=CandidateReviewDecision(row["decision"]), comment=row["comment"], reviewed_at=row["reviewed_at"],
    )


# ============================================================================
# F. Validated Knowledge (future-only -- mapping exists for schema
#    completeness/tests, no repository calls this from a production write path)
# ============================================================================


def validated_knowledge_to_row(record: ValidatedKnowledgeRecord) -> dict[str, Any]:
    return {
        "knowledge_id": record.knowledge_id, "statement": record.statement, "knowledge_type": record.knowledge_type,
        "validation_status": _enum(record.validation_status), "confidence": record.confidence, "scope": record.scope,
        "source_candidate_id": record.source_candidate_id, "approved_by": record.approved_by,
        "approved_at": record.approved_at, "version": record.version, "schema_version": record.schema_version,
    }


def validated_knowledge_from_row(row: dict) -> ValidatedKnowledgeRecord:
    return ValidatedKnowledgeRecord(
        knowledge_id=row["knowledge_id"], statement=row["statement"], knowledge_type=row["knowledge_type"],
        validation_status=ValidationStatus(row["validation_status"]), confidence=row["confidence"], scope=row["scope"],
        source_candidate_id=row["source_candidate_id"], approved_by=row["approved_by"], approved_at=row["approved_at"],
        version=row["version"], schema_version=row["schema_version"],
    )
