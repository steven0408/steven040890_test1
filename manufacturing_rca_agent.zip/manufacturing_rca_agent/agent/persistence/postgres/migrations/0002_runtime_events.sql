-- Phase PROD-1 migration 0002: agent_runtime_events -- a single, bounded,
-- append-only operational/debug table (agent_api/runtime_events.py). This
-- is NOT part of the Phase 8A Run/Module/Objective/Evidence/Finding
-- aggregate (0001_initial.sql) -- it is an observability projection,
-- optional at runtime, and intentionally never carries a hard FK to
-- `runs` (the Agent must be able to log a run_started event before any
-- `runs` row necessarily exists, exactly mirroring 0001's own audit-table
-- FK-design note).
--
-- No raw request text, no raw manufacturing rows, no LLM prompt content --
-- `summary`/`error_message` are bounded free text (agent_api/runtime_events.py's
-- own _MAX_SUMMARY_CHARS truncation); `scope`/`metadata` are small JSONB
-- documents, never a full ModuleState/Evidence payload.

CREATE TABLE IF NOT EXISTS agent_runtime_events (
    event_id        TEXT PRIMARY KEY,
    run_id          TEXT NOT NULL,
    sequence        INTEGER NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL,

    event_type      TEXT NOT NULL,
    node            TEXT,
    module_id       TEXT,
    objective_id    TEXT,

    status          TEXT,
    summary         TEXT,

    capability_key  TEXT,
    tool_id         TEXT,

    scope           JSONB,
    metadata        JSONB,

    error_type      TEXT,
    error_message   TEXT,

    schema_version  TEXT NOT NULL DEFAULT '1'
);

CREATE INDEX IF NOT EXISTS ix_agent_runtime_events_run_id ON agent_runtime_events (run_id);
CREATE INDEX IF NOT EXISTS ix_agent_runtime_events_created_at ON agent_runtime_events (created_at);
CREATE INDEX IF NOT EXISTS ix_agent_runtime_events_event_type ON agent_runtime_events (event_type);
CREATE INDEX IF NOT EXISTS ix_agent_runtime_events_module_id ON agent_runtime_events (module_id);
