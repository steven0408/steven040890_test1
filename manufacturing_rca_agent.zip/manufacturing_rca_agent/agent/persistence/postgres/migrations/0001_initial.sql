-- Phase 8B migration 0001: initial schema for the Analysis / Audit /
-- Human Feedback / Learning persistence domains (Phase 8A's repository
-- contracts). This schema is NOT the LangGraph checkpointer's schema --
-- see docs/persistence.md section 6 for why those stay separate.
--
-- Strategy (Phase 8A item 3, carried forward): relational core columns for
-- anything a query needs to filter/join/sort on, a JSONB extension column
-- for nested/whole-aggregate content that's always consumed as a Pydantic
-- object, never queried field-by-field in SQL. Enums are stored as TEXT
-- (the enum's `.value`), not native Postgres ENUM types -- adding a new
-- enum member would otherwise require an `ALTER TYPE ... ADD VALUE`
-- migration every time. TEXT keeps this adapter's own migrations decoupled
-- from the domain enums' own evolution.
--
-- FK design (item 7): a REAL foreign key exists only where Phase 8A's own
-- `RunPersistenceWriter` guarantees insert order within one transaction
-- (the Run -> Module -> Objective/Evidence/Finding -> RootCause aggregate,
-- and HandoffPackage). Audit tables (planner_decisions, llm_calls,
-- context_builds, synthesis_context_builds, synthesis_generations,
-- tool_calls, human_runtime_requests/responses) and the post-run
-- Evaluation/Feedback/Learning tables are written at different times (live
-- during a run, or in a separate later transaction/process) -- these keep
-- `run_id` as an indexed *conceptual* lineage column without a hard FK, so
-- audit writes are never blocked on `runs` row ordering.

-- ============================================================================
-- A. Run / Analysis aggregate (hard FKs -- always written in dependency
--    order within one RunPersistenceWriter transaction)
-- ============================================================================

CREATE TABLE IF NOT EXISTS runs (
    run_id              TEXT PRIMARY KEY,
    user_request        TEXT NOT NULL,
    normalized_request  TEXT,
    factory_id          TEXT NOT NULL,
    task_type           TEXT,
    run_status          TEXT NOT NULL,
    started_at          TIMESTAMPTZ,
    completed_at        TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL,
    schema_version      TEXT NOT NULL DEFAULT '1',
    application_version TEXT
);
CREATE INDEX IF NOT EXISTS ix_runs_factory_started ON runs (factory_id, started_at);

CREATE TABLE IF NOT EXISTS module_runs (
    run_id           TEXT NOT NULL REFERENCES runs (run_id),
    module_id        TEXT NOT NULL,
    module_type      TEXT NOT NULL,
    task_type        TEXT NOT NULL,
    module_status    TEXT NOT NULL,
    goal             TEXT NOT NULL,
    started_at       TIMESTAMPTZ,
    completed_at     TIMESTAMPTZ,
    step_count       INTEGER NOT NULL,
    tool_call_count  INTEGER NOT NULL,
    limitation_count INTEGER NOT NULL,
    finding_count    INTEGER NOT NULL,
    schema_version   TEXT NOT NULL DEFAULT '1',
    PRIMARY KEY (run_id, module_id)
);
CREATE INDEX IF NOT EXISTS ix_module_runs_run_type ON module_runs (run_id, module_type);

CREATE TABLE IF NOT EXISTS objectives (
    objective_id        TEXT PRIMARY KEY,
    run_id               TEXT NOT NULL,
    module_id            TEXT NOT NULL,
    description          TEXT NOT NULL,
    action               TEXT NOT NULL,
    capability_key       TEXT,
    target_ref           JSONB NOT NULL,
    scope                JSONB,
    status               TEXT NOT NULL,
    created_step         INTEGER NOT NULL,
    completed_step       INTEGER,
    attempt_count        INTEGER NOT NULL,
    observation_ids      TEXT[] NOT NULL DEFAULT '{}',
    evidence_ids         TEXT[] NOT NULL DEFAULT '{}',
    termination_reason   TEXT,
    FOREIGN KEY (run_id, module_id) REFERENCES module_runs (run_id, module_id)
);
CREATE INDEX IF NOT EXISTS ix_objectives_run_module ON objectives (run_id, module_id);

CREATE TABLE IF NOT EXISTS evidence (
    evidence_id         TEXT PRIMARY KEY,
    run_id              TEXT NOT NULL,
    module_id           TEXT NOT NULL,
    objective_id        TEXT NOT NULL,
    source_tool         TEXT NOT NULL,
    quality             TEXT NOT NULL,
    summary             TEXT NOT NULL,
    payload_type        TEXT,
    structured_payload  JSONB,
    schema_version      TEXT NOT NULL DEFAULT '1',
    FOREIGN KEY (run_id, module_id) REFERENCES module_runs (run_id, module_id)
);
CREATE INDEX IF NOT EXISTS ix_evidence_run_module ON evidence (run_id, module_id);

CREATE TABLE IF NOT EXISTS findings (
    finding_id      TEXT PRIMARY KEY,
    run_id          TEXT NOT NULL,
    module_id       TEXT NOT NULL,
    statement       TEXT NOT NULL,
    pattern         TEXT NOT NULL,
    status          TEXT NOT NULL,
    confidence      DOUBLE PRECISION NOT NULL,
    is_root_cause   BOOLEAN NOT NULL,
    entity_ids      TEXT[] NOT NULL DEFAULT '{}',
    schema_version  TEXT NOT NULL DEFAULT '1',
    FOREIGN KEY (run_id, module_id) REFERENCES module_runs (run_id, module_id)
);
CREATE INDEX IF NOT EXISTS ix_findings_run_module ON findings (run_id, module_id);
CREATE INDEX IF NOT EXISTS ix_findings_is_root_cause ON findings (is_root_cause);

CREATE TABLE IF NOT EXISTS finding_evidence_links (
    finding_id   TEXT NOT NULL REFERENCES findings (finding_id),
    evidence_id  TEXT NOT NULL REFERENCES evidence (evidence_id),
    PRIMARY KEY (finding_id, evidence_id)
);

CREATE TABLE IF NOT EXISTS root_causes (
    root_cause_id   TEXT PRIMARY KEY,
    run_id          TEXT NOT NULL,
    module_id       TEXT NOT NULL,
    statement       TEXT NOT NULL,
    confidence      DOUBLE PRECISION NOT NULL,
    entity_ids      TEXT[] NOT NULL DEFAULT '{}',
    schema_version  TEXT NOT NULL DEFAULT '1',
    FOREIGN KEY (run_id, module_id) REFERENCES module_runs (run_id, module_id)
);
CREATE INDEX IF NOT EXISTS ix_root_causes_run_module ON root_causes (run_id, module_id);

CREATE TABLE IF NOT EXISTS root_cause_finding_links (
    root_cause_id  TEXT NOT NULL REFERENCES root_causes (root_cause_id),
    finding_id     TEXT NOT NULL REFERENCES findings (finding_id),
    PRIMARY KEY (root_cause_id, finding_id)
);

-- HandoffPackage: a single cohesive nested aggregate (Synthesis's own
-- output tree) that Evaluator/Learning always consume wholesale via the
-- Pydantic model, never by querying an individual nested field in SQL --
-- the one table this schema deliberately keeps JSONB-primary rather than
-- normalizing further, per item 6's own guidance not to do this
-- reflexively everywhere.
CREATE TABLE IF NOT EXISTS handoff_packages (
    run_id          TEXT PRIMARY KEY REFERENCES runs (run_id),
    task_type       TEXT NOT NULL,
    overall_status  TEXT NOT NULL,
    payload         JSONB NOT NULL
);

-- ============================================================================
-- B. Audit domain (conceptual FK to runs.run_id -- see header note; audit
--    events are written live during a run, not inside RunPersistenceWriter's
--    end-of-run transaction)
-- ============================================================================

CREATE TABLE IF NOT EXISTS planner_decisions (
    decision_record_id       TEXT PRIMARY KEY,
    run_id                   TEXT NOT NULL,
    module_id                TEXT NOT NULL,
    step                     INTEGER NOT NULL,
    decision                 TEXT NOT NULL,
    proposed_action          TEXT,
    proposed_capability_key   TEXT,
    target_ref                JSONB,
    priority                  DOUBLE PRECISION,
    source                    TEXT NOT NULL,
    rationale_summary         TEXT NOT NULL,
    context_build_record_id   TEXT,
    llm_call_id                TEXT,
    fallback_reason              TEXT,
    created_at                    TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_planner_decisions_run ON planner_decisions (run_id, module_id);

CREATE TABLE IF NOT EXISTS llm_calls (
    llm_call_id     TEXT PRIMARY KEY,
    run_id          TEXT NOT NULL,
    module_id       TEXT,
    node            TEXT NOT NULL,
    route           TEXT NOT NULL,
    model           TEXT NOT NULL,
    input_tokens    INTEGER NOT NULL,
    output_tokens   INTEGER NOT NULL,
    latency_ms      DOUBLE PRECISION NOT NULL,
    status          TEXT NOT NULL,
    retry_count     INTEGER NOT NULL DEFAULT 0,
    estimated_cost  DOUBLE PRECISION,
    error_message   TEXT,
    started_at      TIMESTAMPTZ NOT NULL,
    completed_at    TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_llm_calls_run_node ON llm_calls (run_id, node);

CREATE TABLE IF NOT EXISTS context_builds (
    context_build_record_id         TEXT PRIMARY KEY,
    run_id                          TEXT NOT NULL,
    module_id                       TEXT NOT NULL,
    node                             TEXT NOT NULL,
    included_findings_count          INTEGER NOT NULL,
    included_evidence_count          INTEGER NOT NULL,
    included_skills_count            INTEGER NOT NULL,
    included_knowledge_count         INTEGER NOT NULL,
    included_reasoning_skills_count  INTEGER NOT NULL DEFAULT 0,
    estimated_context_characters     INTEGER NOT NULL,
    items_trimmed                    INTEGER NOT NULL,
    build_duration_ms                DOUBLE PRECISION NOT NULL,
    started_at                       TIMESTAMPTZ NOT NULL,
    completed_at                     TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_context_builds_run ON context_builds (run_id);

CREATE TABLE IF NOT EXISTS synthesis_context_builds (
    context_build_record_id         TEXT PRIMARY KEY,
    run_id                          TEXT NOT NULL,
    included_modules                TEXT[] NOT NULL DEFAULT '{}',
    included_findings_count         INTEGER NOT NULL,
    included_root_causes_count      INTEGER NOT NULL,
    included_limitations_count      INTEGER NOT NULL,
    included_reasoning_skills_count INTEGER NOT NULL,
    estimated_context_characters    INTEGER NOT NULL,
    items_trimmed                   INTEGER NOT NULL,
    build_duration_ms               DOUBLE PRECISION NOT NULL,
    started_at                      TIMESTAMPTZ NOT NULL,
    completed_at                    TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_synthesis_context_builds_run ON synthesis_context_builds (run_id);

CREATE TABLE IF NOT EXISTS synthesis_generations (
    synthesis_record_id            TEXT PRIMARY KEY,
    run_id                         TEXT NOT NULL,
    source                         TEXT NOT NULL,
    context_build_record_id        TEXT,
    llm_call_id                    TEXT,
    included_module_ids            TEXT[] NOT NULL DEFAULT '{}',
    referenced_finding_ids         TEXT[] NOT NULL DEFAULT '{}',
    referenced_root_cause_ids      TEXT[] NOT NULL DEFAULT '{}',
    referenced_relation_ids        TEXT[] NOT NULL DEFAULT '{}',
    referenced_recommendation_ids  TEXT[] NOT NULL DEFAULT '{}',
    fallback_reason                 TEXT,
    created_at                      TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_synthesis_generations_run ON synthesis_generations (run_id);

-- Physical Tool audit (Phase 5B/7A freeze: logical / manager-invocation /
-- physical-execution / replay / result-reuse stay independently queryable
-- -- never collapsed into a single "tool_call_count", see item 9.
CREATE TABLE IF NOT EXISTS tool_calls (
    tool_call_id      TEXT PRIMARY KEY,
    run_id            TEXT NOT NULL,
    module_id         TEXT NOT NULL,
    objective_id      TEXT NOT NULL,
    skill_id          TEXT,
    tool_id           TEXT NOT NULL,
    status            TEXT NOT NULL,
    duration_seconds  DOUBLE PRECISION NOT NULL,
    error             JSONB,
    sandboxed         BOOLEAN NOT NULL DEFAULT FALSE,
    started_at        TIMESTAMPTZ NOT NULL,
    completed_at      TIMESTAMPTZ NOT NULL,
    idempotency_key   TEXT,
    logical_call_id   TEXT,
    attempt_number    INTEGER NOT NULL DEFAULT 1,
    replayed          BOOLEAN NOT NULL DEFAULT FALSE,
    result_reused     BOOLEAN NOT NULL DEFAULT FALSE
);
CREATE INDEX IF NOT EXISTS ix_tool_calls_run_module ON tool_calls (run_id, module_id);
CREATE INDEX IF NOT EXISTS ix_tool_calls_logical_call ON tool_calls (logical_call_id);
CREATE INDEX IF NOT EXISTS ix_tool_calls_idempotency_key ON tool_calls (idempotency_key);

CREATE TABLE IF NOT EXISTS evaluation_records (
    evaluation_id                TEXT PRIMARY KEY,
    run_id                       TEXT NOT NULL,
    evaluator_version            TEXT NOT NULL,
    evaluated_at                 TIMESTAMPTZ NOT NULL,
    metric_source_counts         JSONB NOT NULL,
    planner_decision_record_ids  TEXT[] NOT NULL DEFAULT '{}',
    synthesis_record_id          TEXT,
    tool_audit_record_count      INTEGER NOT NULL,
    llm_call_record_count        INTEGER NOT NULL,
    context_record_count         INTEGER NOT NULL,
    human_intervention_count     INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_evaluation_records_run ON evaluation_records (run_id);

CREATE TABLE IF NOT EXISTS human_runtime_requests (
    request_id       TEXT PRIMARY KEY,
    run_id            TEXT NOT NULL,
    module_id         TEXT,
    branch_id         TEXT,
    objective_id      TEXT,
    source_node       TEXT NOT NULL,
    reason            TEXT NOT NULL,
    question          TEXT NOT NULL,
    options           TEXT[],
    permission_type   TEXT,
    risk_level        TEXT,
    resume_target     JSONB NOT NULL,
    status            TEXT NOT NULL,
    created_at_step   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_human_runtime_requests_run ON human_runtime_requests (run_id);

CREATE TABLE IF NOT EXISTS human_runtime_responses (
    request_id    TEXT PRIMARY KEY REFERENCES human_runtime_requests (request_id),
    decision      TEXT NOT NULL,
    payload       TEXT,
    responded_by  TEXT NOT NULL,
    responded_at  TIMESTAMPTZ NOT NULL
);

-- ============================================================================
-- C. RunEvaluation (the metrics themselves -- conceptual FK to runs, see
--    header note) + its normalized issues list
-- ============================================================================

CREATE TABLE IF NOT EXISTS run_evaluations (
    evaluation_id       TEXT PRIMARY KEY,
    run_id               TEXT NOT NULL,
    evaluator_version     TEXT NOT NULL,
    evaluated_at           TIMESTAMPTZ NOT NULL,
    efficiency              JSONB NOT NULL,
    analytical_quality       JSONB NOT NULL,
    decision_quality           JSONB NOT NULL,
    delivery_quality             JSONB NOT NULL,
    weighting                      JSONB,
    overall_score                    DOUBLE PRECISION,
    schema_version                    TEXT NOT NULL DEFAULT '1'
);
CREATE INDEX IF NOT EXISTS ix_run_evaluations_run ON run_evaluations (run_id);

CREATE TABLE IF NOT EXISTS evaluation_issues (
    issue_id                     TEXT PRIMARY KEY,
    evaluation_id                TEXT NOT NULL REFERENCES run_evaluations (evaluation_id),
    category                     TEXT NOT NULL,
    severity                     TEXT NOT NULL,
    statement                    TEXT NOT NULL,
    related_module_ids           TEXT[] NOT NULL DEFAULT '{}',
    related_objective_ids        TEXT[] NOT NULL DEFAULT '{}',
    metric_name                  TEXT NOT NULL,
    evidence_refs                 TEXT[] NOT NULL DEFAULT '{}',
    suggested_improvement_area    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_evaluation_issues_evaluation ON evaluation_issues (evaluation_id);

-- ============================================================================
-- D. Human Feedback (append-only -- stable feedback_id prevents a retry
--    from inserting the same submission twice, item 8)
-- ============================================================================

CREATE TABLE IF NOT EXISTS human_feedback (
    feedback_id            TEXT PRIMARY KEY,
    run_id                 TEXT NOT NULL,
    target_type            TEXT NOT NULL,
    target_id              TEXT,
    user_id                TEXT,
    thumbs                 TEXT NOT NULL,
    answer_helpful         BOOLEAN,
    root_cause_correct     BOOLEAN,
    finding_correct        BOOLEAN,
    recommendation_useful  BOOLEAN,
    comment                TEXT,
    source                 TEXT,
    session_id             TEXT,
    feedback_version       TEXT NOT NULL DEFAULT '1',
    created_at              TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_human_feedback_run_target ON human_feedback (run_id, target_type);

-- ============================================================================
-- E. Learning (aggregate upsert + append-only evidence links, item 8)
-- ============================================================================

CREATE TABLE IF NOT EXISTS learning_candidates (
    candidate_id                  TEXT PRIMARY KEY,
    candidate_type                TEXT NOT NULL,
    title                         TEXT NOT NULL,
    statement                     TEXT NOT NULL,
    status                        TEXT NOT NULL,
    confidence                    DOUBLE PRECISION NOT NULL,
    source_run_ids                TEXT[] NOT NULL DEFAULT '{}',
    source_module_ids             TEXT[] NOT NULL DEFAULT '{}',
    supporting_finding_ids        TEXT[] NOT NULL DEFAULT '{}',
    supporting_root_cause_ids     TEXT[] NOT NULL DEFAULT '{}',
    evaluation_issue_ids          TEXT[] NOT NULL DEFAULT '{}',
    feedback_issue_ids            TEXT[] NOT NULL DEFAULT '{}',
    planner_decision_record_ids   TEXT[] NOT NULL DEFAULT '{}',
    supporting_signal_count       INTEGER NOT NULL DEFAULT 0,
    contradicting_signal_count    INTEGER NOT NULL DEFAULT 0,
    created_at                    TIMESTAMPTZ NOT NULL,
    updated_at                    TIMESTAMPTZ NOT NULL,
    scope                         TEXT NOT NULL,
    proposed_destination          TEXT NOT NULL,
    candidate_key                 TEXT NOT NULL,
    rationale_summary             TEXT NOT NULL,
    schema_version                TEXT NOT NULL DEFAULT '1'
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_learning_candidates_candidate_key ON learning_candidates (candidate_key);
CREATE INDEX IF NOT EXISTS ix_learning_candidates_status_type ON learning_candidates (status, candidate_type);

CREATE TABLE IF NOT EXISTS learning_evidence_links (
    link_id        TEXT PRIMARY KEY,
    candidate_id   TEXT NOT NULL REFERENCES learning_candidates (candidate_id),
    signal_type    TEXT NOT NULL,
    source_run_id  TEXT NOT NULL,
    source_id      TEXT,
    supports       BOOLEAN NOT NULL,
    strength       DOUBLE PRECISION NOT NULL,
    note           TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_learning_evidence_links_candidate ON learning_evidence_links (candidate_id);

-- CandidateReview / candidate_status_history: schema-only, matching
-- ValidatedKnowledge's "future table migration, zero production write
-- path" treatment below -- no repository/sink Protocol in this codebase
-- constructs a CandidateReview or a status-history row yet (grep-verified
-- the same way Phase 7C proved no automatic VALIDATED promotion path
-- exists). Included here because item 5 asks for the table to exist so a
-- future review UI has somewhere to write to without another migration.
CREATE TABLE IF NOT EXISTS candidate_reviews (
    review_id     TEXT PRIMARY KEY,
    candidate_id  TEXT NOT NULL REFERENCES learning_candidates (candidate_id),
    reviewer      TEXT NOT NULL,
    decision      TEXT NOT NULL,
    comment       TEXT,
    reviewed_at   TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_candidate_reviews_candidate ON candidate_reviews (candidate_id);

CREATE TABLE IF NOT EXISTS candidate_status_history (
    id            BIGSERIAL PRIMARY KEY,
    candidate_id  TEXT NOT NULL REFERENCES learning_candidates (candidate_id),
    old_status    TEXT,
    new_status    TEXT NOT NULL,
    changed_at    TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_candidate_status_history_candidate ON candidate_status_history (candidate_id);

-- ============================================================================
-- F. Validated Knowledge -- future-only (Phase 8A item 14 carried
--    forward). No repository in this package writes to this table; see
--    ValidatedKnowledgeRecord's own docstring (agent/persistence/records.py).
-- ============================================================================

CREATE TABLE IF NOT EXISTS validated_knowledge (
    knowledge_id         TEXT PRIMARY KEY,
    statement            TEXT NOT NULL,
    knowledge_type       TEXT NOT NULL,
    validation_status    TEXT NOT NULL,
    confidence           DOUBLE PRECISION NOT NULL,
    scope                TEXT NOT NULL,
    source_candidate_id  TEXT,
    approved_by          TEXT,
    approved_at          TIMESTAMPTZ,
    version              INTEGER NOT NULL DEFAULT 1,
    schema_version       TEXT NOT NULL DEFAULT '1'
);
