"""PostgreSQL implementations of every Phase 8A repository/sink Protocol.
Each class here satisfies an *existing* Protocol structurally (duck
typing -- none of them subclass anything from agent/persistence/*.py) so
`RunPersistenceWriter`/`AuditRepository`/`LearningCandidateRepository`
never need to know which backend they were constructed with.

Every class takes a `connection` in its constructor -- never a
`PostgresSettings`/DSN -- so tests can inject a `FakeConnection`
(tests/postgres_fake.py) instead of a real `psycopg` connection, and this
module itself never imports `psycopg`. Connections are expected to use
`psycopg.rows.dict_row` as the row factory (real connections built via
`agent/persistence/factory.py` are configured that way) so every
`*_from_row()` mapping function receives a plain `dict` keyed by column
name.

Idempotency (item 8): "upsert" tables use `INSERT ... ON CONFLICT (pk) DO
UPDATE`; "append-only" tables use `INSERT ... ON CONFLICT (pk) DO NOTHING`
keyed on the record's own stable domain id -- never a content hash, so a
retried write with the exact same id is a safe no-op rather than a
duplicate row, matching Phase 8A's own freeze.
"""
from __future__ import annotations

from typing import Any, Iterable

from agent.persistence.postgres import mapping as m
from agent.persistence.records import EvidenceRecord, FindingEvidenceLink, FindingRecord, ModuleRunRecord, RootCauseFindingLink, RootCauseRecord, RunRecord
from agent.state.enums import HumanRequestStatus


def _upsert_sql(table: str, columns: list[str], conflict_cols: list[str]) -> str:
    col_list = ", ".join(columns)
    placeholders = ", ".join(f"%({c})s" for c in columns)
    update_cols = [c for c in columns if c not in conflict_cols]
    set_clause = ", ".join(f"{c} = EXCLUDED.{c}" for c in update_cols)
    conflict = ", ".join(conflict_cols)
    return f"INSERT INTO {table} ({col_list}) VALUES ({placeholders}) ON CONFLICT ({conflict}) DO UPDATE SET {set_clause}"


def _insert_ignore_sql(table: str, columns: list[str], conflict_cols: list[str]) -> str:
    col_list = ", ".join(columns)
    placeholders = ", ".join(f"%({c})s" for c in columns)
    conflict = ", ".join(conflict_cols)
    return f"INSERT INTO {table} ({col_list}) VALUES ({placeholders}) ON CONFLICT ({conflict}) DO NOTHING"


def _select_all(table: str, where: str, order_by: str | None = None) -> str:
    sql = f"SELECT * FROM {table} WHERE {where}"
    if order_by:
        sql += f" ORDER BY {order_by}"
    return sql


# ============================================================================
# Generic simple audit tables: record(record) + list_for_run(run_id), one
# row per event, append-only keyed on the record's own stable id. Every
# Phase 8A audit Protocol except HumanAuditSink/RunEvaluationStore has
# exactly this shape (item: LLMUsageSink, ContextAuditSink,
# SynthesisContextAuditSink, PlannerDecisionAuditSink,
# SynthesisGenerationAuditSink, ToolCallAuditSink, EvaluationAuditSink).
# ============================================================================


class _SimpleAppendOnlyTable:
    def __init__(self, connection, *, table: str, id_column: str, columns: list[str], to_row, from_row):
        self._conn = connection
        self._table = table
        self._id_column = id_column
        self._columns = columns
        self._to_row = to_row
        self._from_row = from_row
        self._insert_sql = _insert_ignore_sql(table, columns, [id_column])

    def _record(self, record) -> None:
        self._conn.execute(self._insert_sql, self._to_row(record))

    def _list_for_run(self, run_id: str) -> list:
        cursor = self._conn.execute(_select_all(self._table, "run_id = %(run_id)s", self._id_column), {"run_id": run_id})
        return [self._from_row(row) for row in cursor.fetchall()]


_LLM_CALL_COLUMNS = [
    "llm_call_id", "run_id", "module_id", "node", "route", "model", "input_tokens", "output_tokens",
    "latency_ms", "status", "retry_count", "estimated_cost", "error_message", "started_at", "completed_at",
]


class PostgresLLMUsageSink(_SimpleAppendOnlyTable):
    def __init__(self, connection):
        super().__init__(connection, table="llm_calls", id_column="llm_call_id", columns=_LLM_CALL_COLUMNS,
                          to_row=m.llm_call_to_row, from_row=m.llm_call_from_row)

    def record(self, record) -> None:
        self._record(record)

    def list_for_run(self, run_id: str) -> list:
        return self._list_for_run(run_id)


_CONTEXT_BUILD_COLUMNS = [
    "context_build_record_id", "run_id", "module_id", "node", "included_findings_count", "included_evidence_count",
    "included_skills_count", "included_knowledge_count", "included_reasoning_skills_count",
    "estimated_context_characters", "items_trimmed", "build_duration_ms", "started_at", "completed_at",
]


class PostgresContextAuditSink(_SimpleAppendOnlyTable):
    def __init__(self, connection):
        super().__init__(connection, table="context_builds", id_column="context_build_record_id",
                          columns=_CONTEXT_BUILD_COLUMNS, to_row=m.context_build_to_row, from_row=m.context_build_from_row)

    def record(self, record) -> None:
        self._record(record)

    def list_for_run(self, run_id: str) -> list:
        return self._list_for_run(run_id)


_SYNTHESIS_CONTEXT_BUILD_COLUMNS = [
    "context_build_record_id", "run_id", "included_modules", "included_findings_count", "included_root_causes_count",
    "included_limitations_count", "included_reasoning_skills_count", "estimated_context_characters", "items_trimmed",
    "build_duration_ms", "started_at", "completed_at",
]


class PostgresSynthesisContextAuditSink(_SimpleAppendOnlyTable):
    def __init__(self, connection):
        super().__init__(connection, table="synthesis_context_builds", id_column="context_build_record_id",
                          columns=_SYNTHESIS_CONTEXT_BUILD_COLUMNS, to_row=m.synthesis_context_build_to_row,
                          from_row=m.synthesis_context_build_from_row)

    def record(self, record) -> None:
        self._record(record)

    def list_for_run(self, run_id: str) -> list:
        return self._list_for_run(run_id)


_PLANNER_DECISION_COLUMNS = [
    "decision_record_id", "run_id", "module_id", "step", "decision", "proposed_action", "proposed_capability_key",
    "target_ref", "priority", "source", "rationale_summary", "context_build_record_id", "llm_call_id",
    "fallback_reason", "created_at",
]


class PostgresPlannerDecisionAuditSink(_SimpleAppendOnlyTable):
    def __init__(self, connection):
        super().__init__(connection, table="planner_decisions", id_column="decision_record_id",
                          columns=_PLANNER_DECISION_COLUMNS, to_row=m.planner_decision_to_row,
                          from_row=m.planner_decision_from_row)

    def record(self, record) -> None:
        self._record(record)

    def list_for_run(self, run_id: str) -> list:
        return self._list_for_run(run_id)


_SYNTHESIS_GENERATION_COLUMNS = [
    "synthesis_record_id", "run_id", "source", "context_build_record_id", "llm_call_id", "included_module_ids",
    "referenced_finding_ids", "referenced_root_cause_ids", "referenced_relation_ids", "referenced_recommendation_ids",
    "fallback_reason", "created_at",
]


class PostgresSynthesisGenerationAuditSink(_SimpleAppendOnlyTable):
    def __init__(self, connection):
        super().__init__(connection, table="synthesis_generations", id_column="synthesis_record_id",
                          columns=_SYNTHESIS_GENERATION_COLUMNS, to_row=m.synthesis_generation_to_row,
                          from_row=m.synthesis_generation_from_row)

    def record(self, record) -> None:
        self._record(record)

    def list_for_run(self, run_id: str) -> list:
        return self._list_for_run(run_id)


_TOOL_CALL_COLUMNS = [
    "tool_call_id", "run_id", "module_id", "objective_id", "skill_id", "tool_id", "status", "duration_seconds",
    "error", "sandboxed", "started_at", "completed_at", "idempotency_key", "logical_call_id", "attempt_number",
    "replayed", "result_reused",
]


class PostgresToolCallAuditSink(_SimpleAppendOnlyTable):
    """Item 9: every physical execution keeps its own row (PK = tool_call_id,
    a fresh id per attempt -- see ToolExecutionManager) -- logical/manager-
    invocation/physical-execution/replay/result-reuse stay independently
    queryable via `idempotency_key`/`logical_call_id`/`replayed`/
    `result_reused`, never collapsed into one count at write time."""

    def __init__(self, connection):
        super().__init__(connection, table="tool_calls", id_column="tool_call_id", columns=_TOOL_CALL_COLUMNS,
                          to_row=m.tool_call_to_row, from_row=m.tool_call_from_row)

    def record(self, record) -> None:
        self._record(record)

    def list_for_run(self, run_id: str) -> list:
        return self._list_for_run(run_id)


_EVALUATION_RECORD_COLUMNS = [
    "evaluation_id", "run_id", "evaluator_version", "evaluated_at", "metric_source_counts",
    "planner_decision_record_ids", "synthesis_record_id", "tool_audit_record_count", "llm_call_record_count",
    "context_record_count", "human_intervention_count",
]


class PostgresEvaluationAuditSink(_SimpleAppendOnlyTable):
    def __init__(self, connection):
        super().__init__(connection, table="evaluation_records", id_column="evaluation_id",
                          columns=_EVALUATION_RECORD_COLUMNS, to_row=m.evaluation_record_to_row,
                          from_row=m.evaluation_record_from_row)

    def record(self, record) -> None:
        self._record(record)

    def list_for_run(self, run_id: str) -> list:
        return self._list_for_run(run_id)


# ============================================================================
# HumanAuditSink -- bespoke: request/response are two tables, response
# created strictly after its request (record_response raises if the
# request row doesn't exist, mirroring InMemoryHumanAuditSink's KeyError).
# ============================================================================


class HumanRequestNotFoundError(KeyError):
    pass


_HUMAN_REQUEST_COLUMNS = [
    "request_id", "run_id", "module_id", "branch_id", "objective_id", "source_node", "reason", "question",
    "options", "permission_type", "risk_level", "resume_target", "status", "created_at_step",
]
_HUMAN_RESPONSE_COLUMNS = ["request_id", "decision", "payload", "responded_by", "responded_at"]


class PostgresHumanAuditSink:
    def __init__(self, connection):
        self._conn = connection
        self._insert_request_sql = _insert_ignore_sql("human_runtime_requests", _HUMAN_REQUEST_COLUMNS, ["request_id"])
        self._update_status_sql = "UPDATE human_runtime_requests SET status = %(status)s WHERE request_id = %(request_id)s"
        self._insert_response_sql = _insert_ignore_sql("human_runtime_responses", _HUMAN_RESPONSE_COLUMNS, ["request_id"])

    def record_request(self, request) -> None:
        self._conn.execute(self._insert_request_sql, m.human_request_to_row(request))

    def record_response(self, request_id: str, response) -> None:
        existing = self.get_request(request_id)
        if existing is None:
            raise HumanRequestNotFoundError(request_id)
        self._conn.execute(self._insert_response_sql, m.human_response_to_row(request_id, response))
        self._conn.execute(self._update_status_sql, {"status": HumanRequestStatus.RESOLVED.value, "request_id": request_id})

    def get_request(self, request_id: str):
        row = self._conn.execute(
            _select_all("human_runtime_requests", "request_id = %(request_id)s"), {"request_id": request_id}
        ).fetchone()
        if row is None:
            return None
        response_row = self._conn.execute(
            _select_all("human_runtime_responses", "request_id = %(request_id)s"), {"request_id": request_id}
        ).fetchone()
        return m.human_request_from_row(row, response_row)

    def list_for_run(self, run_id: str) -> list:
        rows = self._conn.execute(_select_all("human_runtime_requests", "run_id = %(run_id)s"), {"run_id": run_id}).fetchall()
        results = []
        for row in rows:
            response_row = self._conn.execute(
                _select_all("human_runtime_responses", "request_id = %(request_id)s"), {"request_id": row["request_id"]}
            ).fetchone()
            results.append(m.human_request_from_row(row, response_row))
        return results


# ============================================================================
# RunEvaluationStore -- upsert-by-evaluation_id, issues normalized into
# their own table and replaced (delete+reinsert) on every save().
# ============================================================================

_RUN_EVALUATION_COLUMNS = [
    "evaluation_id", "run_id", "evaluator_version", "evaluated_at", "efficiency", "analytical_quality",
    "decision_quality", "delivery_quality", "weighting", "overall_score", "schema_version",
]
_EVALUATION_ISSUE_COLUMNS = [
    "issue_id", "evaluation_id", "category", "severity", "statement", "related_module_ids", "related_objective_ids",
    "metric_name", "evidence_refs", "suggested_improvement_area",
]


class PostgresRunEvaluationStore:
    def __init__(self, connection):
        self._conn = connection
        self._upsert_sql = _upsert_sql("run_evaluations", _RUN_EVALUATION_COLUMNS, ["evaluation_id"])
        self._insert_issue_sql = _insert_ignore_sql("evaluation_issues", _EVALUATION_ISSUE_COLUMNS, ["issue_id"])

    def save(self, evaluation) -> None:
        self._conn.execute(self._upsert_sql, m.run_evaluation_to_row(evaluation))
        self._conn.execute("DELETE FROM evaluation_issues WHERE evaluation_id = %(evaluation_id)s", {"evaluation_id": evaluation.evaluation_id})
        for issue in evaluation.issues:
            self._conn.execute(self._insert_issue_sql, m.evaluation_issue_to_row(evaluation.evaluation_id, issue))

    def list_for_run(self, run_id: str) -> list:
        rows = self._conn.execute(_select_all("run_evaluations", "run_id = %(run_id)s"), {"run_id": run_id}).fetchall()
        results = []
        for row in rows:
            issue_rows = self._conn.execute(
                _select_all("evaluation_issues", "evaluation_id = %(evaluation_id)s"), {"evaluation_id": row["evaluation_id"]}
            ).fetchall()
            issues = [m.evaluation_issue_from_row(r) for r in issue_rows]
            results.append(m.run_evaluation_from_row(row, issues))
        return results


# ============================================================================
# HumanFeedbackSink -- append-only, plus target/latest lookups.
# ============================================================================

_HUMAN_FEEDBACK_COLUMNS = [
    "feedback_id", "run_id", "target_type", "target_id", "user_id", "thumbs", "answer_helpful", "root_cause_correct",
    "finding_correct", "recommendation_useful", "comment", "source", "session_id", "feedback_version", "created_at",
]


class PostgresHumanFeedbackSink:
    def __init__(self, connection):
        self._conn = connection
        self._insert_sql = _insert_ignore_sql("human_feedback", _HUMAN_FEEDBACK_COLUMNS, ["feedback_id"])

    def record(self, feedback) -> None:
        self._conn.execute(self._insert_sql, m.human_feedback_to_row(feedback))

    def get(self, feedback_id: str):
        row = self._conn.execute(_select_all("human_feedback", "feedback_id = %(feedback_id)s"), {"feedback_id": feedback_id}).fetchone()
        return m.human_feedback_from_row(row) if row is not None else None

    def list_for_run(self, run_id: str) -> list:
        rows = self._conn.execute(_select_all("human_feedback", "run_id = %(run_id)s"), {"run_id": run_id}).fetchall()
        return [m.human_feedback_from_row(r) for r in rows]

    def list_for_target(self, run_id: str, target_type, target_id: str | None) -> list:
        params: dict[str, Any] = {"run_id": run_id, "target_type": target_type.value}
        where = "run_id = %(run_id)s AND target_type = %(target_type)s"
        if target_id is None:
            where += " AND target_id IS NULL"
        else:
            where += " AND target_id = %(target_id)s"
            params["target_id"] = target_id
        rows = self._conn.execute(_select_all("human_feedback", where), params).fetchall()
        return [m.human_feedback_from_row(r) for r in rows]

    def latest_for_target(self, run_id: str, target_type, target_id: str | None):
        matches = self.list_for_target(run_id, target_type, target_id)
        if not matches:
            return None
        return max(matches, key=lambda f: f.created_at)


# ============================================================================
# LearningCandidateSink -- aggregate upsert (update() requires the row to
# already exist, mirroring InMemoryLearningCandidateSink), evidence links
# append-only.
# ============================================================================

_LEARNING_CANDIDATE_COLUMNS = [
    "candidate_id", "candidate_type", "title", "statement", "status", "confidence", "source_run_ids",
    "source_module_ids", "supporting_finding_ids", "supporting_root_cause_ids", "evaluation_issue_ids",
    "feedback_issue_ids", "planner_decision_record_ids", "supporting_signal_count", "contradicting_signal_count",
    "created_at", "updated_at", "scope", "proposed_destination", "candidate_key", "rationale_summary", "schema_version",
]
_LEARNING_EVIDENCE_LINK_COLUMNS = ["link_id", "candidate_id", "signal_type", "source_run_id", "source_id", "supports", "strength", "note"]


class LearningCandidateNotFoundError(KeyError):
    pass


class PostgresLearningCandidateSink:
    def __init__(self, connection):
        self._conn = connection
        self._insert_sql = _insert_ignore_sql("learning_candidates", _LEARNING_CANDIDATE_COLUMNS, ["candidate_id"])
        self._update_sql = _upsert_sql("learning_candidates", _LEARNING_CANDIDATE_COLUMNS, ["candidate_id"])
        self._insert_link_sql = _insert_ignore_sql("learning_evidence_links", _LEARNING_EVIDENCE_LINK_COLUMNS, ["link_id"])

    def record(self, candidate) -> None:
        self._conn.execute(self._insert_sql, m.learning_candidate_to_row(candidate))

    def update(self, candidate) -> None:
        if self.get(candidate.candidate_id) is None:
            raise LearningCandidateNotFoundError(candidate.candidate_id)
        self._conn.execute(self._update_sql, m.learning_candidate_to_row(candidate))

    def get(self, candidate_id: str):
        row = self._conn.execute(_select_all("learning_candidates", "candidate_id = %(candidate_id)s"), {"candidate_id": candidate_id}).fetchone()
        return m.learning_candidate_from_row(row) if row is not None else None

    def list(self) -> list:
        rows = self._conn.execute("SELECT * FROM learning_candidates").fetchall()
        return [m.learning_candidate_from_row(r) for r in rows]

    def list_by_type(self, candidate_type) -> list:
        rows = self._conn.execute(_select_all("learning_candidates", "candidate_type = %(t)s"), {"t": candidate_type.value}).fetchall()
        return [m.learning_candidate_from_row(r) for r in rows]

    def list_by_status(self, status) -> list:
        rows = self._conn.execute(_select_all("learning_candidates", "status = %(s)s"), {"s": status.value}).fetchall()
        return [m.learning_candidate_from_row(r) for r in rows]

    def find_by_candidate_key(self, candidate_key: str):
        row = self._conn.execute(_select_all("learning_candidates", "candidate_key = %(k)s"), {"k": candidate_key}).fetchone()
        return m.learning_candidate_from_row(row) if row is not None else None

    def record_evidence_link(self, link) -> None:
        self._conn.execute(self._insert_link_sql, m.learning_evidence_link_to_row(link))

    def list_evidence_links(self, candidate_id: str) -> list:
        rows = self._conn.execute(_select_all("learning_evidence_links", "candidate_id = %(candidate_id)s"), {"candidate_id": candidate_id}).fetchall()
        return [m.learning_evidence_link_from_row(r) for r in rows]


# ============================================================================
# RunRepository -- the Run/Module/Objective/Evidence/Finding/RootCause/
# HandoffPackage aggregate (item 15). Hard FKs within this aggregate (see
# migrations/0001_initial.sql) mean callers must save in dependency order
# -- exactly what RunPersistenceWriter._stage_all already does.
# ============================================================================

_RUN_COLUMNS = ["run_id", "user_request", "normalized_request", "factory_id", "task_type", "run_status", "started_at", "completed_at", "created_at", "schema_version", "application_version"]
_MODULE_RUN_COLUMNS = ["run_id", "module_id", "module_type", "task_type", "module_status", "goal", "started_at", "completed_at", "step_count", "tool_call_count", "limitation_count", "finding_count", "schema_version"]
_OBJECTIVE_COLUMNS = ["objective_id", "run_id", "module_id", "description", "action", "capability_key", "target_ref", "scope", "status", "created_step", "completed_step", "attempt_count", "observation_ids", "evidence_ids", "termination_reason"]
_EVIDENCE_COLUMNS = ["evidence_id", "run_id", "module_id", "objective_id", "source_tool", "quality", "summary", "payload_type", "structured_payload", "schema_version"]
_FINDING_COLUMNS = ["finding_id", "run_id", "module_id", "statement", "pattern", "status", "confidence", "is_root_cause", "entity_ids", "schema_version"]
_ROOT_CAUSE_COLUMNS = ["root_cause_id", "run_id", "module_id", "statement", "confidence", "entity_ids", "schema_version"]
_HANDOFF_PACKAGE_COLUMNS = ["run_id", "task_type", "overall_status", "payload"]


class PostgresRunRepository:
    """`self._conn` is shared with `PostgresPersistenceUnitOfWork` (see
    factory.py) and opened non-autocommit, so its transaction boundary is
    normally owned by the UoW's own commit()/rollback(). Read methods here
    are the one exception: they are never staged through a UoW (callers
    invoke `get_run()`/`list_*()` directly), so each one commits
    immediately after fetching its results -- otherwise psycopg's implicit
    per-statement transaction (opened by autocommit=False) would stay open
    indefinitely after every single read, holding a snapshot/locks that
    can block a later DDL statement (`apply_schema()`) or a long-running
    write. This was caught empirically during Phase 8B's local-Postgres
    verification, not from a design review -- a SELECT with no explicit
    commit left a session "idle in transaction" and deadlocked the next
    `CREATE INDEX IF NOT EXISTS` against it. A read-only transaction's
    commit vs. rollback makes no data difference; commit is used since
    it's the conventional no-op for a pure read."""

    def __init__(self, connection):
        self._conn = connection

    def _query_one(self, sql: str, params: dict) -> dict | None:
        row = self._conn.execute(sql, params).fetchone()
        self._conn.commit()
        return row

    def _query_all(self, sql: str, params: dict) -> list[dict]:
        rows = self._conn.execute(sql, params).fetchall()
        self._conn.commit()
        return rows

    # --- Run -------------------------------------------------------------

    def save_run(self, record: RunRecord) -> None:
        self._conn.execute(_upsert_sql("runs", _RUN_COLUMNS, ["run_id"]), m.run_to_row(record))

    def get_run(self, run_id: str) -> RunRecord | None:
        row = self._query_one(_select_all("runs", "run_id = %(run_id)s"), {"run_id": run_id})
        return m.run_from_row(row) if row is not None else None

    def list_runs(self, *, factory_id: str | None = None, since=None, until=None) -> list[RunRecord]:
        clauses, params = ["1 = 1"], {}
        if factory_id is not None:
            clauses.append("factory_id = %(factory_id)s")
            params["factory_id"] = factory_id
        if since is not None:
            clauses.append("created_at >= %(since)s")
            params["since"] = since
        if until is not None:
            clauses.append("created_at <= %(until)s")
            params["until"] = until
        rows = self._query_all(_select_all("runs", " AND ".join(clauses)), params)
        return [m.run_from_row(r) for r in rows]

    # --- Module ------------------------------------------------------------

    def save_module_run(self, record: ModuleRunRecord) -> None:
        self._conn.execute(_upsert_sql("module_runs", _MODULE_RUN_COLUMNS, ["run_id", "module_id"]), m.module_run_to_row(record))

    def get_module_results(self, run_id: str) -> list[ModuleRunRecord]:
        rows = self._query_all(_select_all("module_runs", "run_id = %(run_id)s"), {"run_id": run_id})
        return [m.module_run_from_row(r) for r in rows]

    # --- Objective -----------------------------------------------------------

    def save_objective(self, run_id: str, module_id: str, record) -> None:
        self._conn.execute(_upsert_sql("objectives", _OBJECTIVE_COLUMNS, ["objective_id"]), m.objective_to_row(run_id, module_id, record))

    def list_objectives(self, run_id: str, module_id: str | None = None) -> list:
        where = "run_id = %(run_id)s"
        params: dict[str, Any] = {"run_id": run_id}
        if module_id is not None:
            where += " AND module_id = %(module_id)s"
            params["module_id"] = module_id
        rows = self._query_all(_select_all("objectives", where), params)
        return [m.objective_from_row(r) for r in rows]

    # --- Evidence ------------------------------------------------------------

    def save_evidence(self, record: EvidenceRecord) -> None:
        self._conn.execute(_upsert_sql("evidence", _EVIDENCE_COLUMNS, ["evidence_id"]), m.evidence_to_row(record))

    def list_evidence(self, run_id: str, module_id: str | None = None) -> list[EvidenceRecord]:
        where = "run_id = %(run_id)s"
        params: dict[str, Any] = {"run_id": run_id}
        if module_id is not None:
            where += " AND module_id = %(module_id)s"
            params["module_id"] = module_id
        rows = self._query_all(_select_all("evidence", where), params)
        return [m.evidence_from_row(r) for r in rows]

    # --- Finding ---------------------------------------------------------

    def save_finding(self, record: FindingRecord, evidence_links: Iterable[FindingEvidenceLink]) -> None:
        self._conn.execute(_upsert_sql("findings", _FINDING_COLUMNS, ["finding_id"]), m.finding_to_row(record))
        self._conn.execute("DELETE FROM finding_evidence_links WHERE finding_id = %(finding_id)s", {"finding_id": record.finding_id})
        insert_link_sql = _insert_ignore_sql("finding_evidence_links", ["finding_id", "evidence_id"], ["finding_id", "evidence_id"])
        for link in evidence_links:
            self._conn.execute(insert_link_sql, m.finding_evidence_link_to_row(link))

    def list_findings(self, run_id: str, module_id: str | None = None) -> list[FindingRecord]:
        where = "run_id = %(run_id)s"
        params: dict[str, Any] = {"run_id": run_id}
        if module_id is not None:
            where += " AND module_id = %(module_id)s"
            params["module_id"] = module_id
        rows = self._query_all(_select_all("findings", where), params)
        return [m.finding_from_row(r) for r in rows]

    def list_finding_evidence_links(self, finding_id: str) -> list[FindingEvidenceLink]:
        rows = self._query_all(_select_all("finding_evidence_links", "finding_id = %(finding_id)s"), {"finding_id": finding_id})
        return [m.finding_evidence_link_from_row(r) for r in rows]

    # --- RootCause ------------------------------------------------------

    def save_root_cause(self, record: RootCauseRecord, finding_links: Iterable[RootCauseFindingLink]) -> None:
        self._conn.execute(_upsert_sql("root_causes", _ROOT_CAUSE_COLUMNS, ["root_cause_id"]), m.root_cause_to_row(record))
        self._conn.execute("DELETE FROM root_cause_finding_links WHERE root_cause_id = %(root_cause_id)s", {"root_cause_id": record.root_cause_id})
        insert_link_sql = _insert_ignore_sql("root_cause_finding_links", ["root_cause_id", "finding_id"], ["root_cause_id", "finding_id"])
        for link in finding_links:
            self._conn.execute(insert_link_sql, m.root_cause_finding_link_to_row(link))

    def list_root_causes(self, run_id: str, module_id: str | None = None) -> list[RootCauseRecord]:
        where = "run_id = %(run_id)s"
        params: dict[str, Any] = {"run_id": run_id}
        if module_id is not None:
            where += " AND module_id = %(module_id)s"
            params["module_id"] = module_id
        rows = self._query_all(_select_all("root_causes", where), params)
        return [m.root_cause_from_row(r) for r in rows]

    # --- HandoffPackage --------------------------------------------------

    def save_handoff_package(self, package) -> None:
        self._conn.execute(_upsert_sql("handoff_packages", _HANDOFF_PACKAGE_COLUMNS, ["run_id"]), m.handoff_package_to_row(package))

    def get_handoff_package(self, run_id: str):
        row = self._query_one(_select_all("handoff_packages", "run_id = %(run_id)s"), {"run_id": run_id})
        return m.handoff_package_from_row(row) if row is not None else None
