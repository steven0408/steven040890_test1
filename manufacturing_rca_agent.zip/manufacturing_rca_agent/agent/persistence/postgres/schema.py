"""Loads/applies the version-controlled migration SQL under `migrations/`.
No `psycopg` dependency here -- `apply_schema()` takes any connection-like
object exposing `.execute(sql)` (a real psycopg connection, or a
`FakeConnection` in tests), so schema application is exercised the same
way whether or not the `postgres` extra is installed.
"""
from pathlib import Path

_MIGRATIONS_DIR = Path(__file__).resolve().parent / "migrations"

# Ordered, explicit -- not a directory glob -- so migration order is a
# reviewable fact in this file, not an accident of filesystem sort order.
MIGRATION_FILES: list[str] = [
    "0001_initial.sql",
    "0002_runtime_events.sql",
]

EXPECTED_TABLES: list[str] = [
    "runs", "module_runs", "objectives", "evidence", "findings", "finding_evidence_links",
    "root_causes", "root_cause_finding_links", "handoff_packages",
    "planner_decisions", "llm_calls", "context_builds", "synthesis_context_builds",
    "synthesis_generations", "tool_calls", "evaluation_records",
    "human_runtime_requests", "human_runtime_responses",
    "run_evaluations", "evaluation_issues",
    "human_feedback",
    "learning_candidates", "learning_evidence_links", "candidate_reviews", "candidate_status_history",
    "validated_knowledge",
    # Phase PROD-1 (0002): agent_api/runtime_events.py's own optional
    # observability table -- see that migration file's own header for why
    # it is not part of the Phase 8A aggregate above.
    "agent_runtime_events",
]


def load_migration_sql(filename: str) -> str:
    return (_MIGRATIONS_DIR / filename).read_text(encoding="utf-8")


def _split_statements(sql: str) -> list[str]:
    """Splits a migration file into individual `;`-terminated statements.
    Full-line `--` comments are stripped BEFORE splitting on `;` -- a
    comment's own prose may legitimately contain a semicolon (English
    punctuation), and splitting first would wrongly cut a statement in
    half at that character. No actual SQL statement in this schema embeds
    a literal semicolon itself (no function bodies, no string literals
    containing `;`), so splitting the comment-free text on `;` is safe.
    psycopg3 does not support multiple statements in a single `execute()`
    call, so each DDL statement is sent separately."""
    lines = [line for line in sql.splitlines() if not line.strip().startswith("--")]
    stripped_sql = "\n".join(lines)
    statements = []
    for raw in stripped_sql.split(";"):
        cleaned = raw.strip()
        if cleaned:
            statements.append(cleaned)
    return statements


def apply_schema(connection) -> None:
    """Applies every migration file, in order, against `connection`.
    Idempotent: every DDL statement uses `IF NOT EXISTS`, so re-applying
    against an already-migrated database is a safe no-op."""
    for filename in MIGRATION_FILES:
        sql = load_migration_sql(filename)
        for statement in _split_statements(sql):
            connection.execute(statement)
