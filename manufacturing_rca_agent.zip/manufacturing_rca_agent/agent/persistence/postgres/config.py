"""PostgresSettings -- env-var-*name*-only configuration, mirroring
`DataSourceConfig`'s discipline (`agent/datasource/models.py`, Phase 5D):
the config object itself never holds a literal secret value, only the
*name* of an environment variable a runtime factory resolves later
(`connection.py::PostgresConnectionFactory`). A `PostgresSettings`
instance is safe to log, serialize, or embed in `AppConfig` (YAML/JSON)
without ever leaking a password.
"""
from agent.state.base import RCABaseModel


class PostgresSettings(RCABaseModel):
    host_env: str
    port: int = 5432
    database_env: str
    user_env: str
    password_env: str
    ssl_mode: str = "require"
    connect_timeout: int = 10
    # Applied by connection.py::allow_test_database_only() -- never trust a
    # caller's own claim without also checking the resolved database name
    # (item 13). Left False in production configs; test fixtures set it.
    require_test_database: bool = False
