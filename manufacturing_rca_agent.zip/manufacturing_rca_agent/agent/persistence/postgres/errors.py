"""Typed errors for the PostgreSQL adapter -- never let a raw psycopg/SDK
exception escape this package uncaught at a boundary a caller is expected
to handle (config validation, connection setup). Mirrors the same
typed-exception discipline `agent/datasource/models.py` (`DataSourceConfigError`)
and `agent/bootstrap.py` (`BootstrapConfigError`) already established.
"""


class MissingDatabaseEnvironmentVariable(RuntimeError):
    """A `PostgresSettings` field names an env var (e.g. `password_env`)
    that isn't actually set in the process environment. Raised at connect
    time, not at config-construction time -- `PostgresSettings` itself
    never touches `os.environ`, see its own docstring."""


class DatabaseConfigurationError(RuntimeError):
    """`PostgresSettings` is structurally invalid (e.g. an empty env-var
    *name*) or a test-only guard rejected a production-looking DSN/database
    name (see `connection.py::allow_test_database_only`)."""


class DatabaseConnectionError(RuntimeError):
    """The underlying driver failed to establish or use a connection.
    Wraps whatever `psycopg.Error` was raised -- callers of this package
    never need to import `psycopg` themselves to catch failures."""
