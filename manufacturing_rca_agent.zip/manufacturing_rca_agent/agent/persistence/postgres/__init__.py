"""PostgreSQL persistence adapter (Phase 8B) -- implements the same
repository/sink Protocols Phase 8A defined for InMemory, so
`RunPersistenceWriter`/`PersistenceUnitOfWork` callers never know which
backend they're talking to. See docs/persistence.md section 6 for the
full package map and design rationale.

Nothing in this package is imported by a graph node, Evaluator, Learning
generator, Synthesis, Skill, or Tool -- only by
`agent/persistence/factory.py`'s backend selector and this package's own
tests.
"""
