"""HumanAuditSink (Phase 5B-1.2) -- the durable-store-shaped home for Human
request/response audit, replacing `app.update_state(config, {"human_requests":
...})` as the record of what was asked and how it was answered.

Phase 5B-1.1 pinned down that calling `app.update_state()` on a checkpoint
that still has a pending/interrupted Send task causes LangGraph to re-list
and re-invoke *every* task from that pending superstep on the next resume
(see tests/test_resume_replay_semantics.py) -- siblings included, not just
the interrupted branch. `AgentState.human_requests` was the only reason the
Phase 4B-2 flow ever called `update_state()` during the pending-interrupt
window. Routing Human audit through here instead means that window never
touches the LangGraph checkpoint at all: `AgentState.human_requests` becomes
an optional runtime projection (see its docstring in agent/state/state.py),
not the audit source-of-truth -- this sink is.

Interface only this phase -- no production DB. `InMemoryHumanAuditSink` is
the reference implementation; a Postgres-backed one (append-only requests,
responses recorded against them) is future work behind this same interface.
"""
from typing import Protocol

from agent.state.enums import HumanRequestStatus
from agent.state.models import HumanRequest, HumanResponse


class HumanAuditSink(Protocol):
    def record_request(self, request: HumanRequest) -> None: ...

    def record_response(self, request_id: str, response: HumanResponse) -> None: ...

    def get_request(self, request_id: str) -> HumanRequest | None: ...

    def list_for_run(self, run_id: str) -> list[HumanRequest]: ...


class InMemoryHumanAuditSink:
    def __init__(self) -> None:
        self._requests: dict[str, HumanRequest] = {}

    def record_request(self, request: HumanRequest) -> None:
        self._requests[request.request_id] = request

    def record_response(self, request_id: str, response: HumanResponse) -> None:
        existing = self._requests.get(request_id)
        if existing is None:
            raise KeyError(f"no HumanRequest recorded for '{request_id}' -- call record_request() first")
        self._requests[request_id] = existing.model_copy(
            update={"status": HumanRequestStatus.RESOLVED, "response": response}
        )

    def get_request(self, request_id: str) -> HumanRequest | None:
        return self._requests.get(request_id)

    def list_for_run(self, run_id: str) -> list[HumanRequest]:
        return [r for r in self._requests.values() if r.run_id == run_id]
