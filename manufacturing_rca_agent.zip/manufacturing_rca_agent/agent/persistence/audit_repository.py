"""AuditRepository (Phase 8A item 15) -- the Audit Persistence (domain C)
aggregate boundary: "how did the Agent analyze it?" This is a
**compose-not-duplicate** wrapper: every one of these audit types already
has its own Sink Protocol + InMemory reference implementation
(PlannerDecisionAuditSink, ContextAuditSink, SynthesisContextAuditSink,
SynthesisGenerationAuditSink, EvaluationAuditSink, HumanAuditSink,
LLMUsageSink, ToolCallAuditSink) -- `AuditRepository` does not reimplement
any of them, it just bundles references to whichever instances a run's
services were actually wired with, so `RunPersistenceWriter` (and any
future Dashboard/Learning query) has one place to reach all of them.

The one genuinely new piece: `RunEvaluation` (the metrics themselves, as
opposed to `EvaluationRecord`, which is only the lineage trace of *how*
an evaluation was produced) never had a durable home before this phase --
`RunEvaluationStore` is that home.
"""
from dataclasses import dataclass, field
from typing import Protocol

from agent.evaluation.audit import EvaluationAuditSink, InMemoryEvaluationAuditSink
from agent.llm.context.context_audit import ContextAuditSink, InMemoryContextAuditSink
from agent.llm.context.synthesis_context_audit import InMemorySynthesisContextAuditSink, SynthesisContextAuditSink
from agent.llm.usage import InMemoryLLMUsageSink, LLMUsageSink
from agent.persistence.human_audit import HumanAuditSink, InMemoryHumanAuditSink
from agent.planning.decision_audit import InMemoryPlannerDecisionAuditSink, PlannerDecisionAuditSink
from agent.state.models import RunEvaluation
from agent.synthesis.decision_audit import InMemorySynthesisGenerationAuditSink, SynthesisGenerationAuditSink
from agent.tools.execution_manager import InMemoryToolCallAuditSink, ToolCallAuditSink


class RunEvaluationStore(Protocol):
    def save(self, evaluation: RunEvaluation) -> None: ...

    def list_for_run(self, run_id: str) -> list[RunEvaluation]: ...


class InMemoryRunEvaluationStore:
    def __init__(self) -> None:
        self._by_id: dict[str, RunEvaluation] = {}

    def save(self, evaluation: RunEvaluation) -> None:
        self._by_id[evaluation.evaluation_id] = evaluation  # idempotent upsert -- see Phase 8A item 18

    def list_for_run(self, run_id: str) -> list[RunEvaluation]:
        return [e for e in self._by_id.values() if e.run_id == run_id]


@dataclass
class AuditRepository:
    llm_usage_sink: LLMUsageSink
    planner_context_sink: ContextAuditSink
    synthesis_context_sink: SynthesisContextAuditSink
    planner_decision_sink: PlannerDecisionAuditSink
    synthesis_generation_sink: SynthesisGenerationAuditSink
    tool_call_sink: ToolCallAuditSink
    human_audit_sink: HumanAuditSink
    evaluation_audit_sink: EvaluationAuditSink
    run_evaluation_store: RunEvaluationStore

    def list_evaluations(self, run_id: str) -> list[RunEvaluation]:
        return self.run_evaluation_store.list_for_run(run_id)


def build_default_audit_repository() -> AuditRepository:
    """Fresh, all-InMemory `AuditRepository` -- the composition root a test
    or a future bootstrap wiring uses when it hasn't already built its own
    sink instances (e.g. to correlate with a live run)."""
    return AuditRepository(
        llm_usage_sink=InMemoryLLMUsageSink(),
        planner_context_sink=InMemoryContextAuditSink(),
        synthesis_context_sink=InMemorySynthesisContextAuditSink(),
        planner_decision_sink=InMemoryPlannerDecisionAuditSink(),
        synthesis_generation_sink=InMemorySynthesisGenerationAuditSink(),
        tool_call_sink=InMemoryToolCallAuditSink(),
        human_audit_sink=InMemoryHumanAuditSink(),
        evaluation_audit_sink=InMemoryEvaluationAuditSink(),
        run_evaluation_store=InMemoryRunEvaluationStore(),
    )
