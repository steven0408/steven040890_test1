"""RunRepository (Phase 8A item 15) -- the Analysis Persistence (domain B)
aggregate boundary: "what did the Agent find out?" Run -> Module -> Objective
-> Evidence -> Finding -> RootCause -> HandoffPackage, one repository
because these all belong to the same aggregate root (a Run) and are almost
always read/written together, not because a single giant interface is
easier to implement.

Idempotency (item 18): every `save_*` method is a **domain-id-keyed
upsert**, not an append -- persisting the same `RunRecord`/`ModuleRunRecord`
/`ObjectiveRecord`/`FindingRecord`/`RootCauseRecord`/`EvidenceRecord` twice
(e.g. after a checkpoint resume replays a node) overwrites the same row,
never doubles the count. This mirrors ToolExecutionManager's own
idempotency-key discipline (Phase 5B-1.1) one layer up, applied to
logical/analysis records instead of physical Tool calls.
"""
from __future__ import annotations

from datetime import datetime
from typing import Protocol

from agent.persistence.records import (
    EvidenceRecord,
    FindingEvidenceLink,
    FindingRecord,
    ModuleRunRecord,
    RootCauseFindingLink,
    RootCauseRecord,
    RunRecord,
)
from agent.state.models import HandoffPackage, ObjectiveRecord


class RunRepository(Protocol):
    def save_run(self, record: RunRecord) -> None: ...

    def get_run(self, run_id: str) -> RunRecord | None: ...

    def list_runs(self, *, factory_id: str | None = None, since: datetime | None = None, until: datetime | None = None) -> list[RunRecord]: ...

    def save_module_run(self, record: ModuleRunRecord) -> None: ...

    def get_module_results(self, run_id: str) -> list[ModuleRunRecord]: ...

    def save_objective(self, run_id: str, module_id: str, record: ObjectiveRecord) -> None: ...

    def list_objectives(self, run_id: str, module_id: str | None = None) -> list[ObjectiveRecord]: ...

    def save_evidence(self, record: EvidenceRecord) -> None: ...

    def list_evidence(self, run_id: str, module_id: str | None = None) -> list[EvidenceRecord]: ...

    def save_finding(self, record: FindingRecord, evidence_links: list[FindingEvidenceLink]) -> None: ...

    def list_findings(self, run_id: str, module_id: str | None = None) -> list[FindingRecord]: ...

    def list_finding_evidence_links(self, finding_id: str) -> list[FindingEvidenceLink]: ...

    def save_root_cause(self, record: RootCauseRecord, finding_links: list[RootCauseFindingLink]) -> None: ...

    def list_root_causes(self, run_id: str, module_id: str | None = None) -> list[RootCauseRecord]: ...

    def save_handoff_package(self, package: HandoffPackage) -> None: ...

    def get_handoff_package(self, run_id: str) -> HandoffPackage | None: ...


class InMemoryRunRepository:
    def __init__(self) -> None:
        self._runs: dict[str, RunRecord] = {}
        self._module_runs: dict[tuple[str, str], ModuleRunRecord] = {}
        self._objectives: dict[str, ObjectiveRecord] = {}
        self._objective_scope: dict[str, tuple[str, str]] = {}  # objective_id -> (run_id, module_id)
        self._evidence: dict[str, EvidenceRecord] = {}
        self._findings: dict[str, FindingRecord] = {}
        self._finding_evidence_links: dict[str, list[FindingEvidenceLink]] = {}
        self._root_causes: dict[str, RootCauseRecord] = {}
        self._root_cause_finding_links: dict[str, list[RootCauseFindingLink]] = {}
        self._handoff_packages: dict[str, HandoffPackage] = {}

    # --- Run -----------------------------------------------------------

    def save_run(self, record: RunRecord) -> None:
        self._runs[record.run_id] = record

    def get_run(self, run_id: str) -> RunRecord | None:
        return self._runs.get(run_id)

    def list_runs(self, *, factory_id: str | None = None, since: datetime | None = None, until: datetime | None = None) -> list[RunRecord]:
        results = list(self._runs.values())
        if factory_id is not None:
            results = [r for r in results if r.factory_id == factory_id]
        if since is not None:
            results = [r for r in results if r.created_at >= since]
        if until is not None:
            results = [r for r in results if r.created_at <= until]
        return results

    # --- Module ----------------------------------------------------------

    def save_module_run(self, record: ModuleRunRecord) -> None:
        self._module_runs[(record.run_id, record.module_id)] = record

    def get_module_results(self, run_id: str) -> list[ModuleRunRecord]:
        return [r for (rid, _), r in self._module_runs.items() if rid == run_id]

    # --- Objective ---------------------------------------------------------

    def save_objective(self, run_id: str, module_id: str, record: ObjectiveRecord) -> None:
        self._objectives[record.objective_id] = record
        self._objective_scope[record.objective_id] = (run_id, module_id)

    def list_objectives(self, run_id: str, module_id: str | None = None) -> list[ObjectiveRecord]:
        return [
            record
            for oid, record in self._objectives.items()
            if self._objective_scope[oid][0] == run_id and (module_id is None or self._objective_scope[oid][1] == module_id)
        ]

    # --- Evidence ----------------------------------------------------------

    def save_evidence(self, record: EvidenceRecord) -> None:
        self._evidence[record.evidence_id] = record

    def list_evidence(self, run_id: str, module_id: str | None = None) -> list[EvidenceRecord]:
        return [r for r in self._evidence.values() if r.run_id == run_id and (module_id is None or r.module_id == module_id)]

    # --- Finding -------------------------------------------------------

    def save_finding(self, record: FindingRecord, evidence_links: list[FindingEvidenceLink]) -> None:
        self._findings[record.finding_id] = record
        self._finding_evidence_links[record.finding_id] = list(evidence_links)

    def list_findings(self, run_id: str, module_id: str | None = None) -> list[FindingRecord]:
        return [r for r in self._findings.values() if r.run_id == run_id and (module_id is None or r.module_id == module_id)]

    def list_finding_evidence_links(self, finding_id: str) -> list[FindingEvidenceLink]:
        return list(self._finding_evidence_links.get(finding_id, []))

    # --- RootCause ------------------------------------------------------

    def save_root_cause(self, record: RootCauseRecord, finding_links: list[RootCauseFindingLink]) -> None:
        self._root_causes[record.root_cause_id] = record
        self._root_cause_finding_links[record.root_cause_id] = list(finding_links)

    def list_root_causes(self, run_id: str, module_id: str | None = None) -> list[RootCauseRecord]:
        return [r for r in self._root_causes.values() if r.run_id == run_id and (module_id is None or r.module_id == module_id)]

    # --- HandoffPackage --------------------------------------------------

    def save_handoff_package(self, package: HandoffPackage) -> None:
        self._handoff_packages[package.run_id] = package

    def get_handoff_package(self, run_id: str) -> HandoffPackage | None:
        return self._handoff_packages.get(run_id)
