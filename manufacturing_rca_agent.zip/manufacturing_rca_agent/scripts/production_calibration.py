"""Phase PROD-1.2: Production LLM Calibration Runner.

RUN THIS ON THE FORMAL ENVIRONMENT MACHINE, where INTERNAL_LLM_* env vars
already point at the real internal gpt-oss-120b deployment. This script was
built and exercised in the sandbox ONLY against OpenAI Cloud as a mechanical
regression check (proving the script itself runs correctly) -- that is NOT
formal-environment production-calibration evidence (see the Phase PROD-1.2
completion report's own item I). The real calibration run is yours to
perform and bring back.

WHAT THIS SCRIPT REUSES (never a second, parallel LLM client/config):
    agent_api.config.ApiSettings.from_env()   -- the SAME config the FastAPI
                                                  app itself reads
    agent_api.service.AgentService            -- the SAME composition path
                                                  (bootstrap_runtime, real
                                                  LLMRouter, real per-route
                                                  context builders/services)

HARD SAFETY GUARANTEES:
  - Refuses to start if WB_DATASOURCE_PROFILE is anything other than
    "in_memory" (or unset) -- this script must never be able to reach the
    formal WB API / manufacturing DB, structurally, not just by convention.
  - Refuses to start if LLM_PROVIDER=mock -- calibrating Mock is meaningless.
  - Never prints a raw prompt, the compact schema body, `reasoning_content`
    text, or any credential/URL value -- only bounded counts/status/token
    numbers (see agent/llm/models.py::LLMCallRecord's own Phase PROD-1.2
    fields, which this script reads from, never recomputes independently).

USAGE (on the formal machine):
    python -m scripts.production_calibration

REQUIRED ENV VARS: the same ones `ApiSettings.from_env()` already requires
for a real provider -- LLM_PROVIDER=internal_openai, INTERNAL_LLM_MODEL,
INTERNAL_LLM_BASE_URL, INTERNAL_LLM_API_KEY, LLM_CONTEXT_WINDOW_TOKENS=2048
(or your own measured value). WB_DATASOURCE_PROFILE must stay unset or
"in_memory". See docs/deployment.md and the Phase PROD-1.2 completion
report's own "env vars to set" section.

OUTPUT: plain stdout, in the `=== SECTION ===\\nkey=value` shape the Phase
PROD-1.2 completion report asks for -- paste the FULL stdout back after a
formal-environment run.
"""
import sys
import uuid
from datetime import datetime, timezone

from agent.domain.wb.synthetic import GOLDEN_DATE
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.state.enums import EvidenceQuality, ObjectiveAction, ObservationStatus, TargetRefType, TaskType
from agent.state.models import Budget, Evidence, FactoryContext, ModuleTask, Observation, UserRequest
from agent.state.scope import ConstraintSource, RequestConstraint, ScopeOperator
from agent.state.state import AgentState
from agent_api.config import ApiConfigError, ApiSettings
from agent_api.runtime_events import InMemoryRuntimeEventSink
from agent_api.service import AgentService, normalize_request

_FACTORY_ID = "factory-a"


def _print_section(name: str, fields: dict) -> None:
    print(f"\n=== {name} ===")
    for key, value in fields.items():
        print(f"{key}={value}")


def _record_telemetry(record) -> dict:
    """Bounded telemetry from one LLMCallRecord -- never raw content. See
    agent/llm/models.py::LLMCallRecord's own Phase PROD-1.2 field set."""
    if record is None:
        return {"status": "NO_LLM_CALL_RECORDED"}
    total = None
    if record.input_tokens is not None and record.output_tokens is not None:
        total = record.input_tokens + record.output_tokens
    return {
        "status": record.status.value,
        "context_window_tokens": record.context_window_tokens,
        "estimated_prompt_tokens": record.estimated_prompt_tokens,
        "actual_prompt_tokens": record.input_tokens,
        "schema_tokens": record.schema_tokens,
        "reserved_output_tokens": record.reserved_output_tokens,
        "actual_completion_tokens": record.output_tokens,
        "total_tokens": total,
        "finish_reason": record.finish_reason,
        "content_present": record.content_present,
        "reasoning_present": record.reasoning_present,
        "retry_count": record.retry_count,
        "latency_ms": round(record.latency_ms, 1) if record.latency_ms is not None else None,
        "error_message": (record.error_message or "")[:200] or None,  # bounded excerpt, item 59
    }


def _estimator_error(record) -> dict:
    if record is None or record.estimated_prompt_tokens is None or record.input_tokens in (None, 0):
        return {}
    error = record.input_tokens - record.estimated_prompt_tokens
    pct = (error / record.input_tokens) * 100 if record.input_tokens else None
    return {"estimator_error_tokens": error, "estimator_error_pct": round(pct, 1) if pct is not None else None}


def load_settings() -> ApiSettings:
    try:
        settings = ApiSettings.from_env()
    except ApiConfigError as exc:
        print(f"FATAL: configuration invalid or incomplete: {exc}")
        sys.exit(1)

    if settings.wb_datasource_profile != "in_memory":
        print(
            f"FATAL: WB_DATASOURCE_PROFILE={settings.wb_datasource_profile!r} -- this calibration script REFUSES "
            "to run with anything other than 'in_memory'. It must never be able to reach the formal WB API / "
            "manufacturing DB. Unset WB_DATASOURCE_PROFILE or set it to 'in_memory' and re-run."
        )
        sys.exit(1)
    if settings.is_mock_llm():
        print("FATAL: LLM_PROVIDER=mock -- this script calibrates a REAL provider; refusing to run against Mock.")
        sys.exit(1)

    _print_section("CONFIGURATION", {
        "provider": settings.llm_provider_config.provider,
        "context_window_tokens": settings.context_window_tokens,
        "reserved_output_tokens_override": settings.reserved_output_tokens_override,
        "wb_datasource_profile": settings.wb_datasource_profile,
        "enabled_modules": settings.enabled_modules,
        "factory_id": settings.factory_id,
        "note": "model/base_url/api_key intentionally never printed by this script",
    })
    return settings


def build_service(settings: ApiSettings) -> AgentService:
    return AgentService.from_settings(settings, InMemoryRuntimeEventSink())


# ============================================================================
# Individual route smoke tests (section 12-21)
# ============================================================================


def run_standardizer_smoke(service: AgentService, raw_text: str, run_id: str) -> None:
    if service.standardizer_service is None:
        _print_section("STANDARDIZER", {"status": "SERVICE_NOT_CONFIGURED"})
        return
    state = AgentState(
        run_id=run_id,
        user_request=UserRequest(request_id=f"{run_id}-req", raw_text=raw_text, submitted_by="calibration", submitted_at=datetime.now(timezone.utc)),
        factory_context=FactoryContext(factory_id=_FACTORY_ID, factory_name="Factory A", enabled_modules=[m.module_type for m in service.runtime_context.module_registry.list()]),
        global_budget=Budget(max_steps=20, max_tool_calls=40, max_depth_per_entity=5),
    )
    outcome = service.standardizer_service.decide(state)
    record = service.runtime_context.llm_usage_sink.list_for_run(run_id)
    record = record[-1] if record else None
    fields = {"source": outcome.source.value, "fallback_reason": (outcome.fallback_reason or "")[:200] or None}
    fields.update(_record_telemetry(record))
    fields.update(_estimator_error(record))
    _print_section("STANDARDIZER", fields)


def run_analyzer_smoke(service: AgentService, raw_text: str, run_id: str, normalized_text: str) -> None:
    if service.analyzer_service is None:
        _print_section("ANALYZER", {"status": "SERVICE_NOT_CONFIGURED"})
        return
    from agent.state.models import NormalizedRequest

    state = AgentState(
        run_id=run_id,
        user_request=UserRequest(request_id=f"{run_id}-req", raw_text=raw_text, submitted_by="calibration", submitted_at=datetime.now(timezone.utc)),
        normalized_request=NormalizedRequest(request_id=f"{run_id}-req", normalized_text=normalized_text, factory_id=_FACTORY_ID),
        factory_context=FactoryContext(factory_id=_FACTORY_ID, factory_name="Factory A", enabled_modules=[m.module_type for m in service.runtime_context.module_registry.list()]),
        global_budget=Budget(max_steps=20, max_tool_calls=40, max_depth_per_entity=5),
    )
    outcome = service.analyzer_service.decide(state)
    record = service.runtime_context.llm_usage_sink.list_for_run(run_id)
    record = record[-1] if record else None
    fields = {
        "source": outcome.source.value,
        "task_type": outcome.decision.task_type.value if outcome.source.value == "llm" else None,
        "selected_modules": [m.module_type for m in outcome.decision.selected_modules] if outcome.source.value == "llm" else None,
        "fallback_reason": (outcome.fallback_reason or "")[:200] or None,
    }
    fields.update(_record_telemetry(record))
    fields.update(_estimator_error(record))
    _print_section("ANALYZER", fields)


def _wb_module_state_with_evidence(*, task_type: TaskType, goal_statement: str, constraint: RequestConstraint | None, run_id: str):
    constraints = [constraint] if constraint else []
    task = ModuleTask(
        module_id="WB", module_type="WB", reason="calibration", goal_statement=goal_statement,
        confidence=0.9, priority=0.9, task_type=task_type, constraints=constraints,
    )
    initial = build_initial_module_state(task, Budget(max_steps=6, max_tool_calls=10, max_depth_per_entity=2), run_id=run_id, task_type=task_type)
    # Realistic single round of prior evidence for the Reflector smoke --
    # a Planner-only smoke does not need this (fresh objective).
    evidence = Evidence(evidence_id="e1", objective_id="obj-1", source_tool="compare_wb_stage_output", summary="WB output for operation 2800 at ASE07 was 12,400 units on 2026-08-12, ranked 4th of 5 plants.", quality=EvidenceQuality.MODERATE)
    observation = Observation(observation_id="o1", objective_id="obj-1", tool_name="compare_wb_stage_output", status=ObservationStatus.SUCCESS)
    from agent.state.models import Objective, TargetRef

    current_objective = Objective(
        objective_id="obj-1", action=ObjectiveAction.COMPARE, capability_key="wb.output.comparison",
        target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="WB"),
        description="Compare WB output for operation 2800 across plants.", expected_output="ranked comparison",
        priority_score=0.9,
    )
    return initial.model_copy(update={"evidence": [evidence], "observations": [observation], "current_objective": current_objective})


def run_planner_smoke(service: AgentService, *, task_type: TaskType, goal_statement: str, run_id: str) -> None:
    runtime = service.runtime_context.module_runtime.get("WB")
    if runtime is None:
        _print_section(f"PLANNER ({task_type.value})", {"status": "WB_MODULE_NOT_CONFIGURED"})
        return
    constraint = RequestConstraint(dimension="operation", operator=ScopeOperator.EQ, value="2800", source=ConstraintSource.USER_EXPLICIT)
    module_state = _wb_module_state_with_evidence(task_type=task_type, goal_statement=goal_statement, constraint=constraint, run_id=run_id)
    # Fresh objective for a Planner-only smoke -- clear current_objective/evidence so this reads as "round 1".
    module_state = module_state.model_copy(update={"current_objective": None, "evidence": [], "observations": []})

    objective = runtime.policy.propose_next_objective(module_state)
    records = service.runtime_context.llm_usage_sink.list_for_run(run_id)
    planner_records = [r for r in records if r.route == "planner"]
    record = planner_records[-1] if planner_records else None
    decisions = service.runtime_context.decision_audit_sink.list_for_run(run_id)
    decision = decisions[-1] if decisions else None
    fields = {
        "source": decision.source.value if decision else None,
        "capability_key": objective.capability_key if objective else None,
        "action": objective.action.value if objective else None,
        "fallback_reason": (decision.fallback_reason or "")[:200] if decision and decision.fallback_reason else None,
        "objective_produced": objective is not None,
    }
    fields.update(_record_telemetry(record))
    fields.update(_estimator_error(record))
    _print_section(f"PLANNER ({task_type.value})", fields)


def run_reflector_smoke(service: AgentService, *, run_id: str) -> None:
    runtime = service.runtime_context.module_runtime.get("WB")
    if runtime is None or service.runtime_context.reflection_decision_audit_sink is None:
        _print_section("REFLECTOR", {"status": "REFLECTOR_ROUTE_NOT_CONFIGURED"})
        return
    module_state = _wb_module_state_with_evidence(
        task_type=TaskType.ANALYSIS, goal_statement="Compare WB output for operation 2800 across plants on 2026-08-12.",
        constraint=RequestConstraint(dimension="operation", operator=ScopeOperator.EQ, value="2800", source=ConstraintSource.USER_EXPLICIT),
        run_id=run_id,
    )
    runtime.policy.is_sufficient(module_state)  # triggers exactly one Reflector call (cached for describe_finding/derive_state_updates)
    records = service.runtime_context.llm_usage_sink.list_for_run(run_id)
    reflector_records = [r for r in records if r.route == "reflector"]
    record = reflector_records[-1] if reflector_records else None
    decisions = service.runtime_context.reflection_decision_audit_sink.list_for_run(run_id)
    decision = decisions[-1] if decisions else None
    fields = {
        "source": decision.source.value if decision else None,
        "verdict": decision.verdict.value if decision else None,
        "fallback_reason": (decision.rationale_summary or "")[:200] if decision and decision.source.value == "fallback" else None,
    }
    fields.update(_record_telemetry(record))
    fields.update(_estimator_error(record))
    _print_section("REFLECTOR", fields)


def run_synthesis_smoke(service: AgentService, run_id: str) -> None:
    if service.synthesis_service is None:
        _print_section("SYNTHESIS", {"status": "SERVICE_NOT_CONFIGURED"})
        return
    from agent.state.enums import FindingStatus
    from agent.state.models import Finding, ModuleState, NormalizedRequest

    module_state = _wb_module_state_with_evidence(
        task_type=TaskType.ANALYSIS, goal_statement="Compare WB output for operation 2800 across plants.", constraint=None, run_id=run_id,
    )
    module_state = module_state.model_copy(update={
        "status": module_state.status.__class__.COMPLETE,
        "findings": [Finding(finding_id="f1", statement="WB output at ASE07 for operation 2800 was 12,400 units on 2026-08-12, ranked 4th of 5 plants.", pattern="ranking", confidence=0.7, status=FindingStatus.CONFIRMED)],
    })
    state = AgentState(
        run_id=run_id,
        user_request=UserRequest(request_id=f"{run_id}-req", raw_text="Compare WB output for operation 2800 across plants.", submitted_by="calibration", submitted_at=datetime.now(timezone.utc)),
        normalized_request=NormalizedRequest(request_id=f"{run_id}-req", normalized_text="Compare WB output for operation 2800 across plants.", factory_id=_FACTORY_ID),
        factory_context=FactoryContext(factory_id=_FACTORY_ID, factory_name="Factory A", enabled_modules=["WB"]),
        global_budget=Budget(max_steps=20, max_tool_calls=40, max_depth_per_entity=5),
        module_states={"WB": module_state},
    )
    outcome = service.synthesis_service.synthesize(state)
    records = service.runtime_context.llm_usage_sink.list_for_run(run_id)
    synthesis_records = [r for r in records if r.route == "synthesis"]
    record = synthesis_records[-1] if synthesis_records else None
    fields = {
        "source": outcome.source.value,
        "fallback_reason": (outcome.fallback_reason or "")[:200] or None,
        "markdown_chars": len(outcome.package.markdown),
    }
    fields.update(_record_telemetry(record))
    fields.update(_estimator_error(record))
    _print_section("SYNTHESIS", fields)


# ============================================================================
# Full-graph phases (section 22-27)
# ============================================================================


def run_full_graph(service: AgentService, *, label: str, prompt: str) -> None:
    run_id = f"calib-{label.lower()}-{uuid.uuid4().hex[:8]}"
    normalized = normalize_request(prompt=prompt, request=None, run_id=run_id, factory_id=None, metadata=None)
    try:
        result = service.analyze(normalized)
        status = result.status
        markdown_present = bool(result.markdown)
    except Exception as exc:  # calibration must survive one bad run and keep reporting the rest
        status = f"EXCEPTION: {exc}"
        markdown_present = False

    records = service.runtime_context.llm_usage_sink.list_for_run(run_id)
    planner_records = [r for r in records if r.route == "planner"]
    reflector_records = [r for r in records if r.route == "reflector"]
    standardizer_records = [r for r in records if r.route == "standardizer"]
    analyzer_records = [r for r in records if r.route == "analyzer"]
    synthesis_records = [r for r in records if r.route == "synthesis"]

    planner_decisions = service.runtime_context.decision_audit_sink.list_for_run(run_id)
    reflection_decisions = (
        service.runtime_context.reflection_decision_audit_sink.list_for_run(run_id)
        if service.runtime_context.reflection_decision_audit_sink is not None else []
    )

    fields = {
        "status": status,
        "markdown_present": markdown_present,
        "planner_rounds": len(planner_records),
        "planner_sources": [d.source.value for d in planner_decisions],
        "reflector_rounds": len(reflector_records),
        "reflector_sources": [d.source.value for d in reflection_decisions],
        "standardizer_source": standardizer_records[0].status.value if standardizer_records else None,
        "analyzer_source": analyzer_records[0].status.value if analyzer_records else None,
        "synthesis_source": synthesis_records[0].status.value if synthesis_records else None,
        "total_llm_calls": len(records),
    }
    _print_section(f"FULL {label} RUN", fields)

    # Round-by-round Planner telemetry (item 21/27/28 -- context growth across rounds).
    for i, record in enumerate(planner_records, start=1):
        round_fields = _record_telemetry(record)
        round_fields.update(_estimator_error(record))
        _print_section(f"FULL {label} RUN -- PLANNER ROUND {i}", round_fields)
    for i, record in enumerate(reflector_records, start=1):
        round_fields = _record_telemetry(record)
        round_fields.update(_estimator_error(record))
        _print_section(f"FULL {label} RUN -- REFLECTOR ROUND {i}", round_fields)


# ============================================================================
# Orchestration
# ============================================================================


def main() -> None:
    settings = load_settings()
    service = build_service(settings)

    run_standardizer_smoke(service, "請查詢 ASE01 的 OEE。", "calib-std-simple")
    run_standardizer_smoke(service, "請比較 2026-08-12 operation 2800 各廠 Output。", "calib-std-complex")

    run_analyzer_smoke(service, "請查詢 ASE01 的 OEE。", "calib-analyzer-info", "Check ASE01 OEE status.")
    run_analyzer_smoke(service, "請比較 2026-08-12 各廠 WIP Hold 狀況。", "calib-analyzer-analysis", "Compare WIP Hold status across plants on 2026-08-12.")

    run_planner_smoke(service, task_type=TaskType.INFORMATION, goal_statement="Check WB output for operation 2800 at ASE07.", run_id="calib-planner-info")
    run_planner_smoke(service, task_type=TaskType.ANALYSIS, goal_statement="Compare WB output for operation 2800 across plants on 2026-08-12.", run_id="calib-planner-analysis")
    run_planner_smoke(service, task_type=TaskType.RCA, goal_statement="Investigate why WB output for operation 2800 is low at ASE07.", run_id="calib-planner-rca")

    run_reflector_smoke(service, run_id="calib-reflector")

    run_synthesis_smoke(service, run_id="calib-synthesis")

    run_full_graph(service, label="INFORMATION", prompt="請告訴我 2026-08-12 ASE01 的 OEE。")
    run_full_graph(service, label="ANALYSIS", prompt="請比較 2026-08-12 各廠 WIP Hold 狀況。")
    run_full_graph(service, label="RCA", prompt="請分析目前 WB WIP 狀況，並找出可能造成 WIP 異常的原因。")

    print("\n=== CALIBRATION RUN COMPLETE ===")
    print("Paste the FULL stdout above back for analysis.")


if __name__ == "__main__":
    main()
