"""CapabilityResolver (Phase 5B-2, action-based matching since Phase 5B-2.1)
-- Harness service, not a LangGraph node, sitting between Module Executor
and the Skill/Tool registries:

    Objective -> Executor -> CapabilityResolver -> Skill -> SkillRunner
        -> ToolExecutionManager -> ToolRegistry -> Tool

Deterministic/rule-based this phase (no LLM): matches an Objective's typed
`action` (ObjectiveAction -- a stable machine-routing signal, deliberately
separate from `description`, which stays human/LLM-readable prose, and from
`TargetRef`, which carries entity/branch data) against each candidate
Skill's own declared `actions` (frontmatter-sourced -- see SkillDefinition),
filtered first by `module_type` (Skill.domains) and `task_type`
(Skill.task_types). Module Planner never hard-codes a skill_id, and never
needs a free-text/string-naming convention to get routed correctly -- it
only ever produces an Objective with a typed `action`.
"""
from agent.skills.models import SkillDefinition
from agent.skills.registry import SkillRegistry
from agent.state.base import RCABaseModel
from agent.state.enums import TaskType
from agent.state.models import Objective
from agent.tools.models import ToolDefinition
from agent.tools.registry import ToolRegistry


class CapabilityResolutionError(RuntimeError):
    """Typed failure -- never let an unresolved capability surface as a bare
    exception. Module Executor catches this specifically and turns it into
    an ERROR Observation (ErrorType.CAPABILITY_NOT_FOUND), the same way a
    Tool-level DATA_NOT_FOUND does; Reflector/Planner take it from there.
    Never routes to Human."""

    def __init__(self, *, module_type: str, task_type: TaskType, objective_action: str, reason: str):
        self.module_type = module_type
        self.task_type = task_type
        self.objective_action = objective_action
        self.reason = reason
        super().__init__(
            f"no Skill resolves objective action '{objective_action}' for "
            f"module_type={module_type}, task_type={task_type.value}: {reason}"
        )


class ResolvedCapability(RCABaseModel):
    selected_skill: SkillDefinition
    resolved_tools: list[ToolDefinition]
    resolution_reason: str


class CapabilityResolver:
    def __init__(self, skill_registry: SkillRegistry, tool_registry: ToolRegistry):
        self._skills = skill_registry
        self._tools = tool_registry

    def resolve(self, objective: Objective, module_type: str, task_type: TaskType) -> ResolvedCapability:
        domain = module_type.lower()

        candidates: list[SkillDefinition] = []
        for skill in self._skills.list():
            if skill.domains and domain not in skill.domains:
                continue
            if skill.task_types and task_type not in skill.task_types:
                continue
            if objective.action not in skill.actions:  # [] never matches -- no legitimate universal action
                continue
            candidates.append(skill)

        if not candidates:
            raise CapabilityResolutionError(
                module_type=module_type,
                task_type=task_type,
                objective_action=objective.action.value,
                reason="no registered skill declares a matching domain/task_type/action",
            )

        # deterministic tie-break if more than one skill somehow declares
        # the exact same (domain, task_type, action) triple
        candidates.sort(key=lambda skill: skill.skill_id)
        chosen = candidates[0]

        resolved_tools = [self._tools.get(tool_id).definition for tool_id in chosen.required_tools]
        reason = (
            f"domain='{domain}' task_type='{task_type.value}' action='{objective.action.value}' "
            f"matched skill '{chosen.skill_id}'"
        )
        return ResolvedCapability(selected_skill=chosen, resolved_tools=resolved_tools, resolution_reason=reason)
