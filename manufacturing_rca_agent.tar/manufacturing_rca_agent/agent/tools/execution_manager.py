"""ToolExecutionManager (Phase 5B-1.1) -- Harness service, not a LangGraph
node, sitting between SkillRunner/Executor and the ToolRegistry:

    SkillRunner / Executor
            v
    ToolExecutionManager
            v
    Idempotency / Replay Check
            v
    ToolRegistry -> Tool.run()
            v
    ToolCall Audit / Result Cache

This is the structural answer to the Phase 5B-1.1 finding (see
tests/test_resume_replay_semantics.py): `app.update_state()` on a
checkpoint with still-pending Send tasks causes LangGraph to re-invoke
every task in that pending superstep on the next resume, not just the
interrupted one. That's a Harness/runtime fact this layer must tolerate,
not something a Tool author should have to reason about -- every physical
re-invocation for the same logical action must produce the *same*
observable result for NON_IDEMPOTENT_WRITE tools, enforced here via
`ToolExecutionIdentity.idempotency_key()` + a result cache, not left to
each Tool's own discipline.

Interface only this phase -- no production DB. `InMemoryToolResultCache`
and `InMemoryToolCallAuditSink` are the reference implementations; a
Postgres-backed audit sink (append-only, never overwritten -- see the
ToolCallRecord docstring) is future work.

Terminology freeze (Phase 5B-1.2) -- three distinct counts that must NEVER
be conflated into one `tool_call_count`:

  - **Logical Tool Call**: one business analysis action, identified by a
    deterministic `ToolExecutionIdentity.idempotency_key()`. One logical
    call may correspond to zero, one, or several of the counts below.
  - **Tool Manager Invocation**: every call to `ToolExecutionManager.
    execute()`, regardless of whether it results in a physical execution
    or a cache hit. This is `self._attempt_counts[key]` -- i.e.
    `ToolCallRecord.attempt_number` at its highest value seen for a given
    key.
  - **Physical Tool Execution**: only counted when execution actually
    reaches `Tool.run()`. Equal to the number of `ToolCallRecord`s for a
    given idempotency_key with `replayed=False`, or equivalently, exactly
    1 per key that was ever attempted (this manager's whole purpose is to
    keep that number at 1 for NON_IDEMPOTENT_WRITE tools no matter how
    many Tool Manager Invocations occur -- see
    test_non_idempotent_write_tool_reuses_cached_result_on_replay).

The Evaluator (future work) is expected to compute, per run/module:
`logical_tool_call_count`, `tool_manager_invocation_count`,
`physical_tool_execution_count`, `replay_count`, `result_reuse_count`,
`failed_physical_execution_ratio` -- each read from the `ToolCallRecord`
audit trail (`replayed`/`result_reused`/`attempt_number`/`status`), never
from `len(ModuleState.tool_calls)` alone (Phase 5B-1.1: that list can lose
a duplicate physical execution to `merge_by_key`'s whole-value overwrite).
"""
from typing import Protocol

from agent.state.models import ToolCallRecord
from agent.tools.models import Tool, ToolExecutionIdentity, ToolExecutionRequest, ToolExecutionResult


class ToolResultCache(Protocol):
    def get(self, idempotency_key: str) -> ToolExecutionResult | None: ...

    def put(self, idempotency_key: str, result: ToolExecutionResult) -> None: ...


class ToolCallAuditSink(Protocol):
    def record(self, record: ToolCallRecord) -> None: ...


class InMemoryToolResultCache:
    def __init__(self) -> None:
        self._results: dict[str, ToolExecutionResult] = {}

    def get(self, idempotency_key: str) -> ToolExecutionResult | None:
        return self._results.get(idempotency_key)

    def put(self, idempotency_key: str, result: ToolExecutionResult) -> None:
        self._results[idempotency_key] = result


class InMemoryToolCallAuditSink:
    def __init__(self) -> None:
        self.records: list[ToolCallRecord] = []

    def record(self, record: ToolCallRecord) -> None:
        self.records.append(record)


class ToolExecutionOutcome:
    """Not persisted -- just the pairing ToolExecutionManager.execute()
    hands back to its caller (SkillRunner/Executor) for this one call."""

    def __init__(self, result: ToolExecutionResult, record: ToolCallRecord):
        self.result = result
        self.record = record


class ToolExecutionManager:
    def __init__(
        self,
        result_cache: ToolResultCache | None = None,
        audit_sink: ToolCallAuditSink | None = None,
    ):
        self._result_cache = result_cache or InMemoryToolResultCache()
        self._audit_sink = audit_sink or InMemoryToolCallAuditSink()
        self._attempt_counts: dict[str, int] = {}

    def execute(
        self,
        tool: Tool,
        identity: ToolExecutionIdentity,
        parameters,
        *,
        tool_call_id: str,
        started_at,
        completed_at_fn,
    ) -> ToolExecutionOutcome:
        """`completed_at_fn` is a zero-arg callable returning "now" -- kept
        injectable so tests don't depend on wall-clock timing.

        Distinguishes *logical* calls (same idempotency_key) from
        *physical* attempts (every call to this method, replay or not):
        for a NON_IDEMPOTENT_WRITE tool, a repeated idempotency_key reuses
        the cached result instead of re-invoking `tool.run()` -- this is a
        safety requirement, not an optimization, for that tier. READ_ONLY /
        IDEMPOTENT_WRITE tools are also cached (cheaper, and still safe to
        skip), but re-invoking them again would not have been unsafe.
        """
        key = identity.idempotency_key()
        self._attempt_counts[key] = self._attempt_counts.get(key, 0) + 1
        attempt_number = self._attempt_counts[key]
        is_replay = attempt_number > 1

        cached = self._result_cache.get(key)
        if cached is not None and is_replay:
            record = ToolCallRecord(
                tool_call_id=tool_call_id,
                run_id=identity.run_id,
                module_id=identity.module_id,
                objective_id=identity.objective_id,
                skill_id=identity.skill_id,
                tool_id=tool.definition.tool_id,
                status=cached.status,
                duration_seconds=0.0,
                error=None,
                sandboxed=tool.definition.sandbox_required,
                started_at=started_at,
                completed_at=started_at,
                idempotency_key=key,
                logical_call_id=f"{identity.module_id}-{identity.objective_id}-{tool.definition.tool_id}",
                attempt_number=attempt_number,
                replayed=True,
                result_reused=True,
            )
            self._audit_sink.record(record)
            return ToolExecutionOutcome(result=cached, record=record)

        request = ToolExecutionRequest(
            tool_id=tool.definition.tool_id,
            parameters=parameters,
            run_id=identity.run_id,
            module_id=identity.module_id,
            objective_id=identity.objective_id,
            requested_by_skill=identity.skill_id,
            idempotency_key=key,
        )
        result = tool.run(request)
        completed_at = completed_at_fn()

        record = ToolCallRecord(
            tool_call_id=tool_call_id,
            run_id=identity.run_id,
            module_id=identity.module_id,
            objective_id=identity.objective_id,
            skill_id=identity.skill_id,
            tool_id=tool.definition.tool_id,
            status=result.status,
            duration_seconds=(completed_at - started_at).total_seconds(),
            error=None,
            sandboxed=tool.definition.sandbox_required,
            started_at=started_at,
            completed_at=completed_at,
            idempotency_key=key,
            logical_call_id=f"{identity.module_id}-{identity.objective_id}-{tool.definition.tool_id}",
            attempt_number=attempt_number,
            replayed=is_replay,
            result_reused=False,
        )
        self._audit_sink.record(record)
        self._result_cache.put(key, result)

        return ToolExecutionOutcome(result=result, record=record)
