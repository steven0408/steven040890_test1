from agent.domain.oee.dataset import EquipmentDetail, EquipmentRecord, EquipmentSnapshot, ScreeningResult
from agent.state.enums import ErrorType, EvidenceQuality, ObservationStatus
from agent.state.models import Objective
from agent.state.payload import PayloadRegistry
from agent.tools.base import ToolResult


class OEEDataTool:
    """Deterministic stand-in for a real OEE data source. Understands two
    objective targets:

      - "screen_equipment"          -> ScreeningResult (A/P/Q for every
                                        equipment, no downtime/failure detail)
      - "equipment_detail:<eq_id>"  -> EquipmentDetail (downtime/failure
                                        detail for one equipment)

    `unavailable_targets` lets tests simulate specific queries being down
    (DATA_NOT_FOUND) without faking the whole dataset -- e.g. the downtime
    detail system being unreachable while screening still works.
    """

    def __init__(
        self,
        equipment: list[EquipmentRecord],
        threshold: float,
        unavailable_targets: frozenset[str] = frozenset(),
    ):
        self._equipment = equipment
        self._by_id = {e.equipment_id: e for e in equipment}
        self._threshold = threshold
        self._unavailable_targets = unavailable_targets

    def run(self, objective: Objective) -> ToolResult:
        target = objective.target_ref.ref_id

        if target in self._unavailable_targets:
            return ToolResult(
                status=ObservationStatus.ERROR,
                error_type=ErrorType.DATA_NOT_FOUND,
                error_message=f"OEE data source unavailable for '{target}'",
            )

        if target == "screen_equipment":
            result = ScreeningResult(
                threshold=self._threshold,
                equipment=[
                    EquipmentSnapshot(
                        equipment_id=e.equipment_id,
                        oee=e.oee,
                        availability=e.availability,
                        performance=e.performance,
                        quality=e.quality,
                        production_weight=e.production_weight,
                    )
                    for e in self._equipment
                ],
            )
            abnormal_count = sum(1 for e in result.equipment if e.oee < result.threshold)
            return ToolResult(
                status=ObservationStatus.SUCCESS,
                payload_summary=(
                    f"Screened {len(result.equipment)} equipment against a {result.threshold:.0%} "
                    f"OEE threshold; {abnormal_count} abnormal."
                ),
                structured_payload=PayloadRegistry.pack("oee.screening_result", result),
                quality=EvidenceQuality.STRONG,
            )

        if target.startswith("equipment_detail:"):
            equipment_id = target.split(":", 1)[1]
            record = self._by_id.get(equipment_id)
            if record is None:
                return ToolResult(
                    status=ObservationStatus.ERROR,
                    error_type=ErrorType.DATA_NOT_FOUND,
                    error_message=f"no such equipment '{equipment_id}'",
                )
            detail = EquipmentDetail(
                equipment_id=equipment_id,
                downtime_minutes=record.downtime_minutes,
                downtime_reason=record.downtime_reason,
                failure_reason=record.failure_reason,
            )
            return ToolResult(
                status=ObservationStatus.SUCCESS,
                payload_summary=(
                    f"{equipment_id} downtime detail: {detail.downtime_minutes} min, "
                    f"reason={detail.downtime_reason}, failure={detail.failure_reason}."
                ),
                structured_payload=PayloadRegistry.pack("oee.equipment_detail", detail),
                quality=EvidenceQuality.STRONG,
            )

        return ToolResult(
            status=ObservationStatus.ERROR,
            error_type=ErrorType.DATA_NOT_FOUND,
            error_message=f"unknown OEE query target '{target}'",
        )
