"""Capability-routed Module Executor (Phase 5B-2) -- the
`Objective -> Executor -> CapabilityResolver -> Skill -> SkillRunner ->
ToolExecutionManager -> ToolRegistry -> Tool` path, alongside (not
replacing) the legacy direct-tool executor in module_executor.py.

Same external contract as the legacy executor: reads only
`current_objective`, never touches it or `current_plan` (Module Planner's
exclusively), and returns exactly one Observation/Evidence for this
objective plus the per-step ToolCallRecord audit trail -- multiple Skill
steps never become multiple Observations. `capability_resolver`/
`skill_runner` are wired once at graph-construction time (see
ModuleCapabilityRuntime), the same way the legacy executor is handed one
fixed `tool`.
"""
from dataclasses import dataclass

from agent.capability.resolver import CapabilityResolutionError, CapabilityResolver
from agent.skills.runner import SkillRunner
from agent.state.enums import ErrorType, EvidenceQuality, ObservationStatus
from agent.state.models import ErrorRecord, Evidence, ModuleState, Observation


@dataclass(frozen=True)
class ModuleCapabilityRuntime:
    """Graph-construction-time wiring for the capability-routed executor --
    the capability-layer counterpart to passing a bare `tool` to the legacy
    executor. Not run data; never goes into AgentState/ModuleState."""

    capability_resolver: CapabilityResolver
    skill_runner: SkillRunner


def make_capability_module_executor(runtime: ModuleCapabilityRuntime):
    def module_executor(module_state: ModuleState) -> dict:
        objective = module_state.current_objective
        step_index = len(module_state.observations) + 1
        tool_name = f"capability:{objective.target_ref.ref_id}"

        try:
            resolved = runtime.capability_resolver.resolve(objective, module_state.module_type, module_state.goal.task_type)
        except CapabilityResolutionError as exc:
            observation = Observation(
                observation_id=f"{module_state.module_id}-obs-{step_index}",
                objective_id=objective.objective_id,
                tool_name=tool_name,
                status=ObservationStatus.ERROR,
                payload_summary=None,
                error=ErrorRecord(
                    error_type=ErrorType.CAPABILITY_NOT_FOUND,
                    message=str(exc),
                    objective_id=objective.objective_id,
                    occurred_at_step=step_index,
                ),
            )
            return {
                "observations": [observation],
                "budget": module_state.budget.model_copy(update={"used_steps": module_state.budget.used_steps + 1}),
            }

        outcome = runtime.skill_runner.run(resolved.selected_skill, objective, module_state)
        result = outcome.result
        status = ObservationStatus.SUCCESS if result.status.value == "success" else ObservationStatus.ERROR

        observation = Observation(
            observation_id=f"{module_state.module_id}-obs-{step_index}",
            objective_id=objective.objective_id,
            tool_name=tool_name,
            status=status,
            payload_summary=result.summary,
            structured_payload=result.output_payload,
            error=result.error,
        )

        updates: dict = {
            "observations": [observation],
            "tool_calls": outcome.tool_call_records,
            "budget": module_state.budget.model_copy(
                update={
                    "used_steps": module_state.budget.used_steps + 1,
                    "used_tool_calls": module_state.budget.used_tool_calls + len(outcome.tool_call_records),
                }
            ),
            "metrics": module_state.metrics.model_copy(
                update={"tool_call_count": module_state.metrics.tool_call_count + len(outcome.tool_call_records)}
            ),
        }

        if status == ObservationStatus.SUCCESS:
            updates["evidence"] = [
                Evidence(
                    evidence_id=f"{module_state.module_id}-ev-{step_index}",
                    objective_id=objective.objective_id,
                    source_tool=tool_name,
                    summary=result.summary,
                    structured_payload=result.output_payload,
                    quality=EvidenceQuality.STRONG,
                )
            ]

        return updates

    return module_executor
