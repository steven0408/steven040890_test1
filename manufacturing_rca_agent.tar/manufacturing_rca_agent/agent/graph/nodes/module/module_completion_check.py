from agent.state.enums import ModulePlannerDecision, ModuleStatus, ObjectiveStatus, ReflectorVerdict
from agent.state.models import ModuleControlSignals, ModuleState


def _close_final_objective(module_state: ModuleState) -> dict:
    """Closes out `current_objective`'s ObjectiveRecord when the module
    terminates while it's still current -- only reachable via the
    CANDIDATE_COMPLETE path, since the NO_VIABLE_OBJECTIVE path already had
    Module Planner null (and close out) `current_objective` before routing
    here.
    """
    current = module_state.current_objective
    if current is None:
        return {}
    prior_record = module_state.objective_history.get(current.objective_id)
    if prior_record is None:
        return {}

    observation_ids = [o.observation_id for o in module_state.observations if o.objective_id == current.objective_id]
    evidence_ids = [e.evidence_id for e in module_state.evidence if e.objective_id == current.objective_id]

    closed_record = prior_record.model_copy(
        update={
            "status": ObjectiveStatus.COMPLETED,
            "completed_step": len(module_state.observations),
            "observation_ids": observation_ids,
            "evidence_ids": evidence_ids,
            "termination_reason": "candidate_complete",
        }
    )
    return {"objective_history": {closed_record.objective_id: closed_record}}


def module_completion_check(module_state: ModuleState) -> dict:
    """The only node allowed to change `module_state.status`. Runs no RCA
    reasoning -- reads reflector_verdict / planner_decision / budget /
    findings / rejections and applies the terminal-status rule:

    - Reflector said CANDIDATE_COMPLETE (and a finding backs it up) -> COMPLETE
    - No viable objective left, or budget exhausted:
        - the give-up was caused by a Human-rejected permission with no
          alternative path (not budget) -> BLOCKED, regardless of whether
          other findings already exist -- an authorization gap is reported
          as such, not quietly folded into PARTIAL
        - some findings gathered -> PARTIAL
        - zero findings -> FAILED
    - otherwise -> not terminal yet, loop back to Planner
    """
    if module_state.control.reflector_verdict == ReflectorVerdict.CANDIDATE_COMPLETE and module_state.findings:
        result: dict = {"status": ModuleStatus.COMPLETE, "control": ModuleControlSignals()}
        result.update(_close_final_objective(module_state))
        return result

    no_viable_objective = module_state.control.planner_decision == ModulePlannerDecision.NO_VIABLE_OBJECTIVE
    budget_exhausted = module_state.budget.used_steps >= module_state.budget.max_steps

    if no_viable_objective or budget_exhausted:
        unresolved_permission_gap = (
            no_viable_objective
            and not budget_exhausted
            and module_state.rejections
            and not module_state.rejections[-1].alternative_found
        )
        if unresolved_permission_gap:
            return {"status": ModuleStatus.BLOCKED, "control": ModuleControlSignals()}
        status = ModuleStatus.PARTIAL if module_state.findings else ModuleStatus.FAILED
        return {"status": status, "control": ModuleControlSignals()}

    return {}
