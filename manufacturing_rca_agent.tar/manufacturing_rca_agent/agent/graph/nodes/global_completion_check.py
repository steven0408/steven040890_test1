from agent.state.enums import TERMINAL_MODULE_STATUSES, RunTerminationStatus
from agent.state.state import AgentState


class ModuleCompletionInvariantError(RuntimeError):
    """Raised if this node is ever entered with a non-terminal module.

    Module Coordinator is the only node allowed to route here, and it only
    does so once every selected module has reached a terminal status -- so
    reaching this branch means the dispatch invariant was violated
    elsewhere, not a normal business outcome to recover from.
    """


def global_completion_check(state: AgentState) -> dict:
    """Pure read-only aggregation: `all(module.status in TERMINAL)`.

    Must never write to `module_states` / `module_dispatch` -- only
    `termination_status`. Skip decisions belong to Module Coordinator, not
    here.
    """
    non_terminal = [
        module_id
        for module_id, module_state in state.module_states.items()
        if module_state.status not in TERMINAL_MODULE_STATUSES
    ]
    if non_terminal:
        raise ModuleCompletionInvariantError(
            f"global_completion_check reached with non-terminal modules: {non_terminal}"
        )
    return {"termination_status": RunTerminationStatus.READY_FOR_SYNTHESIS}
