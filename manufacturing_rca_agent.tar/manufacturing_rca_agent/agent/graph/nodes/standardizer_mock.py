from agent.planning.task_type_inference import infer_task_type_deterministic
from agent.state.enums import StandardizerDecision
from agent.state.models import ControlSignals, Goal, GoalScope, NormalizedRequest
from agent.state.state import AgentState


def standardizer_mock(state: AgentState) -> dict:
    """Phase 2 placeholder: always accepts the request as-is.

    Real intent validation / guardrails / UNCLEAR_INTENT -> Human routing
    are out of scope for the fan-out/fan-in milestone and land in a later
    phase. Production responsibility (Phase 5B-3): normalize the request,
    parse explicit factory/time/scope, basic validity, clarification/Human
    boundary -- NOT owning the final TaskType decision.

    `Goal.task_type` here is only *provisional* -- Goal is a required field
    and Standardizer runs before Analyzer, so something has to seed it. When
    an LLM-backed Analyzer node is wired into the graph, its own decision
    (LLM or deterministic fallback) overwrites this `global_goal` entirely,
    since `global_goal` is a plain last-write-wins channel -- Analyzer's
    decision is the actual source of truth for production TaskType, per
    Phase 5B-3. When only the legacy deterministic `analyzer_mock` is wired
    in (no LLM), nothing overwrites it, so this inference *is* what
    production runs on -- unchanged from Phase 5B-2.1. Either way, this
    calls the exact same `infer_task_type_deterministic` Analyzer's fallback
    uses, so there is exactly one place the logic lives even though there
    are two call sites.
    """
    task_type = infer_task_type_deterministic(state.user_request.raw_text)
    normalized_request = NormalizedRequest(
        request_id=state.user_request.request_id,
        normalized_text=state.user_request.raw_text,
        factory_id=state.factory_context.factory_id,
    )
    goal = Goal(
        goal_id=f"{state.run_id}-goal",
        raw_statement=state.user_request.raw_text,
        normalized_statement=state.user_request.raw_text,
        task_type=task_type,
        scope=GoalScope(),
    )
    return {
        "normalized_request": normalized_request,
        "global_goal": goal,
        "control": ControlSignals(
            standardizer_decision=StandardizerDecision.OK,
            coordinator_decision=state.control.coordinator_decision,
        ),
    }
