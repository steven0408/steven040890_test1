from enum import Enum


class TaskType(str, Enum):
    INFORMATION = "information"
    ANALYSIS = "analysis"
    RCA = "rca"


class ModuleStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETE = "complete"
    PARTIAL = "partial"
    FAILED = "failed"
    BLOCKED = "blocked"
    SKIPPED = "skipped"


TERMINAL_MODULE_STATUSES = frozenset(
    {
        ModuleStatus.COMPLETE,
        ModuleStatus.PARTIAL,
        ModuleStatus.FAILED,
        ModuleStatus.BLOCKED,
        ModuleStatus.SKIPPED,
    }
)


class TreeNodeType(str, Enum):
    MODULE = "module"
    DIMENSION = "dimension"
    ENTITY = "entity"
    ENTITY_GROUP = "entity_group"
    FINDING = "finding"


class TreeNodeStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    SKIPPED = "skipped"
    REJECTED = "rejected"


class BranchStatus(str, Enum):
    PENDING = "pending"
    ACTIVE = "active"
    COMPLETED = "completed"
    SKIPPED = "skipped"
    MERGED = "merged"


class EntityAnalysisStatus(str, Enum):
    SCREENED = "screened"
    INVESTIGATING = "investigating"
    ROOT_CAUSE_FOUND = "root_cause_found"
    STALLED = "stalled"
    SKIPPED = "skipped"


class FindingStatus(str, Enum):
    HYPOTHESIS = "hypothesis"
    CONFIRMED = "confirmed"
    REJECTED = "rejected"


class HypothesisStatus(str, Enum):
    OPEN = "open"
    SUPPORTED = "supported"
    REFUTED = "refuted"


class EvidenceQuality(str, Enum):
    STRONG = "strong"
    MODERATE = "moderate"
    WEAK = "weak"


class ExecutionStrategy(str, Enum):
    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"
    HYBRID = "hybrid"


class ObservationStatus(str, Enum):
    SUCCESS = "success"
    ERROR = "error"


class ErrorType(str, Enum):
    DATA_NOT_FOUND = "data_not_found"
    DATA_NOT_READY = "data_not_ready"
    QUERY_ERROR = "query_error"
    INVALID_QUERY = "invalid_query"
    PERMISSION_DENIED = "permission_denied"
    TOOL_ERROR = "tool_error"
    TIMEOUT = "timeout"
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"
    AMBIGUOUS = "ambiguous"
    # Phase 5B-2.1: distinct from QUERY_ERROR on purpose -- QUERY_ERROR means
    # a capability/Tool exists but its execution failed; CAPABILITY_NOT_FOUND
    # means the Harness has no Skill/Tool that can service this Objective's
    # `action` at all (CapabilityResolutionError). Evaluator/Learning need to
    # tell "broken execution" apart from "missing capability" -- the fix for
    # one is retry/fallback, the fix for the other is registering a new
    # Skill/Tool, and conflating them would hide that distinction.
    CAPABILITY_NOT_FOUND = "capability_not_found"


class ObjectiveAction(str, Enum):
    """Stable machine-routing semantic for an Objective -- what
    CapabilityResolver actually matches against (Phase 5B-2.1). Deliberately
    separate from `Objective.description` (human/LLM-readable explanation)
    and from `TargetRef` (which entity/branch/module the action applies to):
    an LLM-driven Planner will eventually generate free-text descriptions,
    but must still select from this closed, typed set for routing -- never
    invent a new string ad hoc.
    """

    EQUIPMENT_SCREENING = "equipment_screening"
    EQUIPMENT_DETAIL = "equipment_detail"
    CURRENT_STATUS = "current_status"
    # Domain-agnostic Harness-mechanics test fixture action, used only by
    # DeterministicMockPolicy (Phase 2-4B regression tests validating
    # control flow, not real domain capability routing) -- never resolved
    # by a real CapabilityResolver skill.
    GENERIC_QUERY = "generic_query"


class InsightKind(str, Enum):
    KNOWLEDGE = "knowledge"
    PATTERN = "pattern"
    STRATEGY = "strategy"


class InsightStatus(str, Enum):
    CANDIDATE = "candidate"
    VALIDATED = "validated"
    REJECTED = "rejected"


class RunTerminationStatus(str, Enum):
    RUNNING = "running"
    READY_FOR_SYNTHESIS = "ready_for_synthesis"
    BUDGET_EXCEEDED = "budget_exceeded"
    BLOCKED = "blocked"


class HumanReason(str, Enum):
    UNCLEAR_INTENT = "unclear_intent"
    PERMISSION_REQUIRED = "permission_required"
    HIGH_RISK_ACTION = "high_risk_action"


class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class HumanRequestStatus(str, Enum):
    PENDING = "pending"
    RESOLVED = "resolved"


class HumanDecision(str, Enum):
    APPROVE = "approve"
    REJECT = "reject"
    PROVIDE_INFO = "provide_info"
    CHOOSE_OPTION = "choose_option"


class StandardizerDecision(str, Enum):
    OK = "ok"
    BLOCKED = "blocked"
    NEEDS_HUMAN = "needs_human"


class CoordinatorDecision(str, Enum):
    DISPATCH = "dispatch"
    WAIT = "wait"
    ALL_TERMINAL = "all_terminal"


class ModulePlannerDecision(str, Enum):
    DISPATCH = "dispatch"
    NO_VIABLE_OBJECTIVE = "no_viable_objective"


class GateDecision(str, Enum):
    PASS = "pass"
    REJECTED = "rejected"


class ReflectorVerdict(str, Enum):
    CONTINUE = "continue"
    RETRY = "retry"
    CANDIDATE_COMPLETE = "candidate_complete"
    PERMISSION_DENIED_AT_RUNTIME = "permission_denied_at_runtime"


class TargetRefType(str, Enum):
    BRANCH = "branch"
    ENTITY = "entity"
    MODULE = "module"


class ObjectiveStatus(str, Enum):
    PENDING = "pending"
    DISPATCHED = "dispatched"
    COMPLETED = "completed"
    REJECTED = "rejected"
