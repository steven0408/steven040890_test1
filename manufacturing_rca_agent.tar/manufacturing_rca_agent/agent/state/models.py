from datetime import datetime
from typing import Annotated

from pydantic import Field

from agent.analysis.analysis_tree import AnalysisTree
from agent.state.base import RCABaseModel
from agent.state.enums import (
    BranchStatus,
    CoordinatorDecision,
    EntityAnalysisStatus,
    ErrorType,
    EvidenceQuality,
    ExecutionStrategy,
    FindingStatus,
    GateDecision,
    HumanDecision,
    HumanReason,
    HumanRequestStatus,
    HypothesisStatus,
    InsightKind,
    InsightStatus,
    ModulePlannerDecision,
    ModuleStatus,
    ObjectiveAction,
    ObjectiveStatus,
    ObservationStatus,
    ReflectorVerdict,
    RiskLevel,
    StandardizerDecision,
    TargetRefType,
    TaskType,
)
from agent.state.payload import StructuredPayload
from agent.state.reducers import append_list, merge_by_key

# --- Errors / Limitations -------------------------------------------------


class ErrorRecord(RCABaseModel):
    error_type: ErrorType
    message: str
    objective_id: str | None = None
    occurred_at_step: int


class Limitation(RCABaseModel):
    """A gap in evidence/coverage a module could not close (e.g. DATA_NOT_FOUND
    after exhausting alternatives). Feeds Synthesis's Missing Data section."""

    limitation_id: str
    description: str
    impacted_objective_id: str
    impact_statement: str
    related_error: ErrorRecord | None = None


class RejectionRecord(RCABaseModel):
    """A Human REJECT at the Execution Gate. `alternative_found` tells Module
    Completion Check whether this rejection can still lead to BLOCKED."""

    objective_id: str
    permission_type: str | None = None
    reason: str
    alternative_found: bool


# --- Analysis primitives (Branch / Entity / Hypothesis / Evidence / Finding)


class Branch(RCABaseModel):
    branch_id: str
    name: str
    pattern: str
    entity_ids: list[str] = Field(default_factory=list)
    parent_branch_id: str | None = None
    status: BranchStatus = BranchStatus.PENDING
    execution_strategy: ExecutionStrategy = ExecutionStrategy.SEQUENTIAL
    priority_score: float = 0.0
    depth: int = 0
    tree_node_id: str


class EntityState(RCABaseModel):
    entity_id: str
    entity_type: str
    depth: int = 0
    status: EntityAnalysisStatus = EntityAnalysisStatus.SCREENED
    current_tree_node_id: str
    branch_id: str | None = None
    priority_score: float = 0.0
    finding_ids: list[str] = Field(default_factory=list)
    last_updated_step: int = 0


class Hypothesis(RCABaseModel):
    hypothesis_id: str
    statement: str
    related_dimensions: list[str] = Field(default_factory=list)
    status: HypothesisStatus = HypothesisStatus.OPEN
    confidence: float


class Evidence(RCABaseModel):
    evidence_id: str
    objective_id: str
    source_tool: str
    summary: str
    quality: EvidenceQuality
    raw_ref: str | None = None
    structured_payload: StructuredPayload | None = None


class Observation(RCABaseModel):
    observation_id: str
    objective_id: str
    tool_name: str
    status: ObservationStatus
    payload_summary: str | None = None
    error: ErrorRecord | None = None
    structured_payload: StructuredPayload | None = None


class ToolCallRecord(RCABaseModel):
    """Per-tool-invocation audit entry -- granular, unlike Observation/
    Evidence which stay one-per-objective even when a Skill chains several
    tool calls together (see Phase 5B architecture note). Evaluator's
    tool_call_count / failed_tool_ratio / latency / duplicate-call analysis
    all read this list, not Observation.

    Phase 5B-1.1 finding: `ModuleState.tool_calls` is a convenient
    module-scoped *view*, not the physical-execution source of truth --
    under checkpoint replay, a module's whole branch can physically
    re-execute while `module_states` (merge_by_key, whole-value-per-key)
    only ever keeps the *latest* ModuleState, silently discarding the
    earlier physical attempt's record. `replayed`/`result_reused`/
    `attempt_number` exist so a future append-only execution ledger
    (Postgres `tool_calls`, never overwritten) can tell "1 logical action,
    2 physical executions" apart from "1 logical action, 1 execution" --
    this in-state list alone cannot, once overwritten.
    """

    tool_call_id: str
    run_id: str
    module_id: str
    objective_id: str
    skill_id: str | None = None
    tool_id: str
    status: ObservationStatus
    duration_seconds: float
    error: ErrorRecord | None = None
    sandboxed: bool = False
    started_at: datetime
    completed_at: datetime
    idempotency_key: str | None = None
    logical_call_id: str | None = None
    attempt_number: int = 1
    replayed: bool = False
    result_reused: bool = False


class Finding(RCABaseModel):
    finding_id: str
    statement: str
    entity_ids: list[str] = Field(default_factory=list)
    pattern: str
    supporting_evidence_ids: list[str] = Field(default_factory=list)
    confidence: float
    status: FindingStatus = FindingStatus.HYPOTHESIS
    is_root_cause: bool = False


class ReflectionRecord(RCABaseModel):
    reflection_id: str
    objective_id: str
    verdict: ReflectorVerdict
    rationale: str
    evidence_ids: list[str] = Field(default_factory=list)
    created_at_step: int


# --- Analysis space / module goal / budget --------------------------------


class AnalysisSpace(RCABaseModel):
    """A module's own dimension breakdown, e.g. {"OEE": ["Equipment", "Time",
    "Availability", "Performance", "Quality", "Loss"]}. Seeded by that
    module's ModulePlanningPolicy, not authored by Analyzer."""

    root_dimension: str
    dimensions: dict[str, list[str]] = Field(default_factory=dict)


class SuccessCriteria(RCABaseModel):
    min_evidence_quality: EvidenceQuality
    root_cause_coverage_threshold: float
    required_dimensions: list[str] = Field(default_factory=list)


class ModuleGoal(RCABaseModel):
    module_id: str
    statement: str
    task_type: TaskType
    success_criteria: SuccessCriteria


class Budget(RCABaseModel):
    max_steps: int
    used_steps: int = 0
    max_tool_calls: int
    used_tool_calls: int = 0
    max_depth_per_entity: int
    deadline: datetime | None = None


class ModuleMetrics(RCABaseModel):
    step_count: int = 0
    tool_call_count: int = 0
    retry_count: int = 0
    branch_count: int = 0
    entity_count: int = 0


class RunMetrics(RCABaseModel):
    step_count: int = 0
    tool_call_count: int = 0
    retry_count: int = 0
    branch_count: int = 0
    entity_count: int = 0
    human_intervention_count: int = 0


# --- Plan / Objective (module-scoped only -- never global) ----------------


class TargetRef(RCABaseModel):
    ref_type: TargetRefType
    ref_id: str


class Objective(RCABaseModel):
    objective_id: str
    description: str  # human/LLM-readable explanation -- never routing input
    action: ObjectiveAction  # stable machine-routing semantic (Phase 5B-2.1) -- what CapabilityResolver matches on
    target_ref: TargetRef
    expected_output: str
    priority_score: float
    requires_permission: bool = False
    risk_level: RiskLevel | None = None
    permission_type: str | None = None
    attempt_count: int = 0
    status: ObjectiveStatus = ObjectiveStatus.PENDING


class Plan(RCABaseModel):
    plan_id: str
    module_id: str
    current_objective: Objective
    step_queue: list[Objective] = Field(default_factory=list)
    candidate_branches: list[str] = Field(default_factory=list)
    execution_strategy: ExecutionStrategy = ExecutionStrategy.SEQUENTIAL
    budget_snapshot: Budget
    created_at_step: int


class ObjectiveRecord(RCABaseModel):
    """Audit trail entry for one objective's full lifecycle -- distinct from
    `Objective` itself (the live/current definition). Created DISPATCHED by
    Module Planner the moment it dispatches an objective; closed out to
    COMPLETED by whichever node causes that objective to stop being current
    (Module Planner when looping back to dispatch the next one, Module
    Completion Check when the module terminates while it's still current).
    Tool SUCCESS is never read as "objective COMPLETED" here -- completion
    is always driven by a Reflector verdict or a terminal lifecycle
    decision, recorded in `termination_reason`.
    """

    objective_id: str
    description: str
    action: ObjectiveAction  # Phase 5C-1: carried over from Objective.action at dispatch time -- History
    # summarization (agent/llm/context) needs *what kind* of action ran, not just target_ref's string id.
    target_ref: TargetRef
    status: ObjectiveStatus
    created_step: int
    completed_step: int | None = None
    attempt_count: int
    observation_ids: list[str] = Field(default_factory=list)
    evidence_ids: list[str] = Field(default_factory=list)
    termination_reason: str | None = None


# --- Control signals (routing bookkeeping only, no domain data) -----------


class ControlSignals(RCABaseModel):
    standardizer_decision: StandardizerDecision | None = None
    coordinator_decision: CoordinatorDecision | None = None


class ModuleControlSignals(RCABaseModel):
    planner_decision: ModulePlannerDecision | None = None
    gate_decision: GateDecision | None = None
    reflector_verdict: ReflectorVerdict | None = None


# --- Module state -----------------------------------------------------------


class ModuleState(RCABaseModel):
    module_id: str
    module_type: str
    run_id: str
    status: ModuleStatus = ModuleStatus.PENDING

    goal: ModuleGoal
    current_plan: Plan | None = None
    current_objective: Objective | None = None
    objective_history: Annotated[dict[str, ObjectiveRecord], merge_by_key] = Field(default_factory=dict)

    analysis_space: AnalysisSpace
    analysis_tree: AnalysisTree

    branches: Annotated[dict[str, Branch], merge_by_key] = Field(default_factory=dict)
    entity_states: Annotated[dict[str, EntityState], merge_by_key] = Field(default_factory=dict)

    hypotheses: Annotated[list[Hypothesis], append_list] = Field(default_factory=list)
    observations: Annotated[list[Observation], append_list] = Field(default_factory=list)
    evidence: Annotated[list[Evidence], append_list] = Field(default_factory=list)
    findings: Annotated[list[Finding], append_list] = Field(default_factory=list)

    reflection_history: Annotated[list[ReflectionRecord], append_list] = Field(default_factory=list)
    limitations: Annotated[list[Limitation], append_list] = Field(default_factory=list)
    rejections: Annotated[list[RejectionRecord], append_list] = Field(default_factory=list)
    tool_calls: Annotated[list[ToolCallRecord], append_list] = Field(default_factory=list)

    budget: Budget
    metrics: ModuleMetrics = Field(default_factory=ModuleMetrics)
    control: ModuleControlSignals = Field(default_factory=ModuleControlSignals)


# --- Module task / dispatch (owned by Analyzer / Module Coordinator) ------


class ModuleTask(RCABaseModel):
    module_id: str
    module_type: str
    reason: str
    confidence: float
    priority: float
    depends_on: list[str] = Field(default_factory=list)
    # Propagated end-to-end from Goal.task_type (Analyzer reads
    # state.global_goal, never re-infers it) down into ModuleGoal.task_type
    # at module bootstrap. Defaults to RCA -- the depth every pre-5B-2.1
    # scenario implicitly assumed -- so existing call sites that predate
    # TaskType-aware dispatch are unaffected.
    task_type: TaskType = TaskType.RCA


class ModuleDispatchState(RCABaseModel):
    execution_policy: ExecutionStrategy = ExecutionStrategy.HYBRID
    in_flight: list[str] = Field(default_factory=list)
    pending: list[str] = Field(default_factory=list)


# --- Request / factory / goal ----------------------------------------------


class UserRequest(RCABaseModel):
    request_id: str
    raw_text: str
    submitted_by: str
    submitted_at: datetime


class NormalizedRequest(RCABaseModel):
    request_id: str
    normalized_text: str
    factory_id: str
    plant_id: str | None = None
    line_id: str | None = None
    time_range_start: datetime | None = None
    time_range_end: datetime | None = None


class FactoryContext(RCABaseModel):
    factory_id: str
    factory_name: str
    enabled_modules: list[str] = Field(default_factory=list)
    timezone: str = "UTC"


class GoalScope(RCABaseModel):
    time_range_start: datetime | None = None
    time_range_end: datetime | None = None
    plant_id: str | None = None
    line_id: str | None = None


class Goal(RCABaseModel):
    goal_id: str
    raw_statement: str
    normalized_statement: str
    task_type: TaskType
    scope: GoalScope


# --- Human-in-the-loop -------------------------------------------------------


class ResumeTarget(RCABaseModel):
    """Audit/UI metadata only -- NOT the resume mechanism itself. Resuming a
    paused module subgraph is handled by LangGraph's interrupt()/Command(
    resume=...) against that exact paused task, keyed by request_id."""

    module_id: str | None = None
    node: str
    objective_id: str | None = None


class HumanResponse(RCABaseModel):
    decision: HumanDecision
    payload: str | None = None
    responded_by: str
    responded_at: datetime


class HumanRequest(RCABaseModel):
    request_id: str
    run_id: str
    module_id: str | None = None
    branch_id: str | None = None
    objective_id: str | None = None
    source_node: str
    reason: HumanReason
    question: str
    options: list[str] | None = None
    permission_type: str | None = None
    risk_level: RiskLevel | None = None
    resume_target: ResumeTarget
    status: HumanRequestStatus = HumanRequestStatus.PENDING
    response: HumanResponse | None = None
    created_at_step: int


# --- Learning ----------------------------------------------------------------


class CandidateInsight(RCABaseModel):
    insight_id: str
    kind: InsightKind
    statement: str
    context: str
    source_run_id: str
    evidence_refs: list[str] = Field(default_factory=list)
    confidence: float
    validation_count: int = 0
    status: InsightStatus = InsightStatus.CANDIDATE
    created_at: datetime


# --- Synthesis / handoff ------------------------------------------------------


class RootCause(RCABaseModel):
    root_cause_id: str
    statement: str
    module_id: str
    entity_ids: list[str] = Field(default_factory=list)
    confidence: float
    supporting_finding_ids: list[str] = Field(default_factory=list)


class EvidenceSummary(RCABaseModel):
    module_id: str
    summary: str
    evidence_ids: list[str] = Field(default_factory=list)
    quality: EvidenceQuality


class ModuleResult(RCABaseModel):
    module_id: str
    module_type: str
    status: ModuleStatus
    summary: str
    findings: list[Finding] = Field(default_factory=list)
    root_causes: list[RootCause] = Field(default_factory=list)
    evidence_summary: list[EvidenceSummary] = Field(default_factory=list)
    limitations: list[Limitation] = Field(default_factory=list)
    unresolved_hypotheses: list[Hypothesis] = Field(default_factory=list)
    confidence: float


class HandoffPackage(RCABaseModel):
    run_id: str
    goal: str
    module_results: list[ModuleResult] = Field(default_factory=list)
    key_findings: list[Finding] = Field(default_factory=list)
    root_causes: list[RootCause] = Field(default_factory=list)
    evidence_summary: list[EvidenceSummary] = Field(default_factory=list)
    limitations: list[Limitation] = Field(default_factory=list)
    unresolved_hypotheses: list[Hypothesis] = Field(default_factory=list)
    confidence: float
    recommended_followups: list[str] = Field(default_factory=list)
    markdown: str


# --- Run evaluation ------------------------------------------------------------


class QualityAssessment(RCABaseModel):
    correctness: float
    evidence_quality: float
    rca_validity: float
    completeness: float
    hallucination_risk: RiskLevel
    missing_data_transparency: float
    cross_module_consistency: float


class EfficiencyAssessment(RCABaseModel):
    total_steps: int
    total_tool_calls: int
    retry_count: int
    repeated_analysis_count: int
    unused_module_analyses: int


class DecisionQualityAssessment(RCABaseModel):
    module_selection_quality: float
    planner_decision_quality: float
    branch_priority_quality: float
    unnecessary_exploration_count: int
    premature_termination_flag: bool


class ModuleEvaluation(RCABaseModel):
    module_id: str
    quality_score: float
    efficiency_score: float
    decision_quality_score: float
    notes: str


class RunEvaluation(RCABaseModel):
    run_id: str
    quality: QualityAssessment
    efficiency: EfficiencyAssessment
    decision_quality: DecisionQualityAssessment
    module_evaluations: list[ModuleEvaluation] = Field(default_factory=list)
    overall_score: float


# --- Execution audit trail ------------------------------------------------------


class ExecutionStep(RCABaseModel):
    step_id: str
    step_index: int
    node_name: str
    module_id: str | None = None
    summary: str
    started_at: datetime
    ended_at: datetime | None = None
