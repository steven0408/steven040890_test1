"""LLM Runtime contracts (Phase 5B-3A) -- provider-agnostic. Nothing here
imports a provider SDK; that only happens inside a concrete `LLMClient`
implementation (agent/llm/client.py's `MockLLMClient` this phase -- a real
provider adapter is Phase 5B-3B).
"""
from datetime import datetime
from enum import Enum

from pydantic import Field

from agent.state.base import RCABaseModel


class LLMRole(str, Enum):
    SYSTEM = "system"
    USER = "user"


class LLMMessage(RCABaseModel):
    role: LLMRole
    content: str


class LLMCallStatus(str, Enum):
    SUCCESS = "success"
    TIMEOUT = "timeout"
    PROVIDER_ERROR = "provider_error"
    INVALID_OUTPUT = "invalid_output"


class DecisionSource(str, Enum):
    """Shared across every LLM-backed decision-maker (Analyzer, Planner, ...)
    -- not analyzer-specific despite first appearing there in Phase 5B-3A.
    Moved here in Phase 5C-2 when Planner needed the exact same concept,
    rather than each decision-maker defining its own parallel copy."""

    LLM = "llm"
    FALLBACK = "fallback"


class LLMRequest(RCABaseModel):
    route: str
    model: str
    messages: list[LLMMessage]
    output_schema_name: str
    timeout_seconds: float = 30.0
    run_id: str
    module_id: str | None = None
    node: str


class LLMCallRecord(RCABaseModel):
    """Per-attempt audit entry -- one row per physical LLM call, retries
    included (mirrors ToolCallRecord's attempt-level granularity). This is
    the future-Postgres-backed durable source of truth for token/cost
    accounting; never compute those from final AgentState alone."""

    llm_call_id: str
    run_id: str
    module_id: str | None = None
    node: str
    route: str
    model: str
    input_tokens: int
    output_tokens: int
    latency_ms: float
    status: LLMCallStatus
    retry_count: int = 0
    estimated_cost: float | None = None
    error_message: str | None = None
    started_at: datetime
    completed_at: datetime


class LLMTimeoutError(RuntimeError):
    pass


class LLMProviderError(RuntimeError):
    pass


class LLMInvalidOutputError(RuntimeError):
    pass
