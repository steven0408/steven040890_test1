"""Analyzer prompt + typed output contract (Phase 5B-3A).

Context layers, in the order the rendered messages present them (see
`build_analyzer_messages`):

    1. Role / Responsibility
    2. Hard Rules
    3. Factory / Request Context
    4. Available Module Catalog
    5. TaskType Definitions
    6. Immediate Decision + Typed Output Contract

Persona is deliberately short (see `AnalyzerContext.role` in
analyzer_context.py) -- the point is the responsibility boundary, not a
character voice.
"""
from pydantic import Field

from agent.llm.context.analyzer_context import AnalyzerContext
from agent.llm.models import LLMMessage, LLMRole
from agent.state.base import RCABaseModel
from agent.state.enums import TaskType


class ModuleSelection(RCABaseModel):
    module_type: str
    priority: float
    confidence: float
    rationale: str  # concise, one sentence -- never chain-of-thought


class AnalyzerDecision(RCABaseModel):
    """Analyzer's entire output contract. `extra="forbid"` (RCABaseModel)
    makes it structurally impossible for an LLM response to smuggle in a
    skill_id / tool_id / objective / RCA step -- those fields don't exist
    on this schema, so `model_validate` rejects them outright (see
    tests/test_llm_runtime.py's typed-output regression test). Analyzer
    infers TaskType and selects Modules; nothing else is its responsibility.
    """

    task_type: TaskType
    selected_modules: list[ModuleSelection] = Field(default_factory=list)
    reasoning_summary: str  # concise -- never chain-of-thought
    confidence: float


def build_analyzer_messages(context: AnalyzerContext) -> list[LLMMessage]:
    system_lines = [context.role, "", "Hard rules:"]
    system_lines += [f"- {rule}" for rule in context.hard_rules]
    system = LLMMessage(role=LLMRole.SYSTEM, content="\n".join(system_lines))

    module_lines = [
        f"- {m.module_type}: {m.description} (supports: {', '.join(t.value for t in m.supported_task_types)})"
        for m in context.available_modules
    ]
    task_type_lines = [f"- {d.task_type.value}: {d.description}" for d in context.task_type_definitions]

    user_lines = [
        "Factory / Request Context:",
        f"- Factory: {context.factory_name} ({context.factory_id})",
        f"- User request: {context.user_request_text}",
        f"- Normalized request: {context.normalized_request_text}",
        "",
        "Available Module Catalog:",
        *module_lines,
        "",
        "TaskType Definitions:",
        *task_type_lines,
        "",
        "Decide the dominant TaskType and select the relevant Module(s). "
        f"Respond with a JSON object conforming exactly to the AnalyzerDecision "
        f"schema (output_contract_version={context.output_contract_version}): "
        "task_type, selected_modules (module_type/priority/confidence/rationale "
        "each), reasoning_summary, confidence. Do not include any other field.",
    ]
    user = LLMMessage(role=LLMRole.USER, content="\n".join(user_lines))

    return [system, user]
