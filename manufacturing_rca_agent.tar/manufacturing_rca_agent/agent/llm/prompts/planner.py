"""Planner typed output contract (Phase 5C-1) -- defined now so Phase 5C-2's
Mock LLM Planner has a stable target, even though nothing calls an LLM this
phase. No prompt renderer yet (that's 5C-2, once there's a call site to
actually build messages for).

`ObjectiveProposal`, not the full `Objective` model: `Objective` carries
Harness-owned bookkeeping (`objective_id`, `status`, `attempt_count`) that
only Module Planner's own deterministic code is allowed to assign (see
module_planner.py's docstring -- unchanged since Phase 3). An LLM proposes
the *content* of the next objective; Module Planner's node code is still
what constructs the real `Objective`/`ObjectiveRecord` from that proposal,
exactly as it already does from `ModulePlanningPolicy.propose_next_objective`
today. `action`/`target_ref`/`description` are the same existing typed
building blocks Objective itself uses -- never free-text routing.
"""
from enum import Enum

from agent.state.base import RCABaseModel
from agent.state.enums import ObjectiveAction, RiskLevel
from agent.state.models import TargetRef


class ObjectiveProposal(RCABaseModel):
    action: ObjectiveAction
    target_ref: TargetRef
    description: str
    expected_output: str
    requires_permission: bool = False
    risk_level: RiskLevel | None = None
    permission_type: str | None = None


class PlannerDecisionType(str, Enum):
    DISPATCH = "dispatch"
    NO_VIABLE_OBJECTIVE = "no_viable_objective"


class PlannerDecision(RCABaseModel):
    """Planner's entire output contract -- structurally cannot carry a
    tool_id/skill_id/SQL/Python code/final RCA answer, since those fields
    don't exist on this schema (RCABaseModel's extra="forbid" rejects them
    at validation time, same discipline as AnalyzerDecision)."""

    decision: PlannerDecisionType
    next_objective: ObjectiveProposal | None = None
    priority: float | None = None  # mirrors next_objective's eventual priority_score, when decision=DISPATCH
    rationale_summary: str  # concise -- never chain-of-thought
    stop_candidate: bool = False  # hint for completion routing; final terminal-status rule stays Module Completion Check's
