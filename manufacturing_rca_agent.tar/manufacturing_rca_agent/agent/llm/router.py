"""LLMRouter (Phase 5B-3A) -- Harness service, not a LangGraph node, sitting
between a Node (Analyzer today) and LLMClient:

    Analyzer Node -> AnalyzerContextBuilder -> LLMRouter -> LLMClient
        -> typed AnalyzerDecision -> Node updates AgentState

Phase 1 scope (Analyzer route only): model selection via `LLMRouteConfig`,
timeout (passed through to the client via `LLMRequest.timeout_seconds`),
retry (same model, up to `max_retries`), typed-output validation (enforced
by the client, surfaced here as `LLMInvalidOutputError`), and usage logging
(one `LLMCallRecord` per physical attempt, success or failure, via
`LLMUsageSink`). Fallback-model-chain retry is NOT implemented yet --
`LLMRouteConfig.fallback_models` is contract-only.

Phase 5B-3B addition: an optional `validate` hook, run after the client's
own pydantic validation succeeds -- e.g. Analyzer's semantic validation
(selected module actually exists/enabled/available/supports this TaskType,
no duplicates, confidence/priority in range -- see
agent/graph/nodes/analyzer_llm.py's `validate_analyzer_decision`). Raising
`LLMInvalidOutputError` (or a subclass) from `validate` is treated exactly
like the client itself producing invalid output: this attempt is recorded
INVALID_OUTPUT and the router retries, same as any other failure mode.
"""
import itertools
from datetime import datetime, timezone
from typing import Callable

from agent.llm.client import LLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.models import (
    LLMCallRecord,
    LLMCallStatus,
    LLMInvalidOutputError,
    LLMMessage,
    LLMProviderError,
    LLMRequest,
    LLMTimeoutError,
)
from agent.llm.usage import LLMUsageSink
from agent.state.base import RCABaseModel

_call_id_counter = itertools.count(1)


def _status_for(exc: Exception) -> LLMCallStatus:
    """isinstance-based, not an exact-type dict lookup -- a `validate` hook
    is expected to raise a *subclass* of LLMInvalidOutputError (see
    AnalyzerSemanticValidationError), which must still map correctly here."""
    if isinstance(exc, LLMTimeoutError):
        return LLMCallStatus.TIMEOUT
    if isinstance(exc, LLMProviderError):
        return LLMCallStatus.PROVIDER_ERROR
    if isinstance(exc, LLMInvalidOutputError):
        return LLMCallStatus.INVALID_OUTPUT
    raise TypeError(f"unexpected exception type reached LLMRouter's failure handling: {type(exc)!r}")


class LLMRouteNotFoundError(KeyError):
    pass


class LLMRouterError(RuntimeError):
    """Every attempt (including retries) for this route failed -- callers
    (AnalyzerLLMService) catch this specifically to trigger their
    deterministic fallback, never a bare exception."""

    def __init__(self, route: str, attempts: int, last_error: Exception):
        self.route = route
        self.attempts = attempts
        self.last_error = last_error
        super().__init__(f"LLM route '{route}' failed after {attempts} attempt(s): {last_error}")


class LLMRouter:
    def __init__(
        self,
        routes: dict[str, LLMRouteConfig],
        client: LLMClient,
        usage_sink: LLMUsageSink,
        *,
        now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ):
        self._routes = routes
        self._client = client
        self._usage_sink = usage_sink
        self._now_fn = now_fn

    def call(
        self,
        route: str,
        messages: list[LLMMessage],
        output_model: type[RCABaseModel],
        *,
        run_id: str,
        module_id: str | None,
        node: str,
        validate: Callable[[RCABaseModel], None] | None = None,
    ) -> RCABaseModel:
        config = self._routes.get(route)
        if config is None:
            raise LLMRouteNotFoundError(f"no LLMRouteConfig registered for route '{route}'")

        last_error: Exception | None = None
        for attempt in range(config.max_retries + 1):
            started_at = self._now_fn()
            request = LLMRequest(
                route=route,
                model=config.model,
                messages=messages,
                output_schema_name=output_model.__name__,
                timeout_seconds=config.timeout_seconds,
                run_id=run_id,
                module_id=module_id,
                node=node,
            )
            try:
                completion = self._client.complete(request, output_model)
                if validate is not None:
                    validate(completion.parsed_output)
            except (LLMTimeoutError, LLMProviderError, LLMInvalidOutputError) as exc:
                completed_at = self._now_fn()
                self._usage_sink.record(
                    LLMCallRecord(
                        llm_call_id=f"llm-call-{next(_call_id_counter)}",
                        run_id=run_id,
                        module_id=module_id,
                        node=node,
                        route=route,
                        model=config.model,
                        input_tokens=0,
                        output_tokens=0,
                        latency_ms=(completed_at - started_at).total_seconds() * 1000,
                        status=_status_for(exc),
                        retry_count=attempt,
                        error_message=str(exc),
                        started_at=started_at,
                        completed_at=completed_at,
                    )
                )
                last_error = exc
                continue

            completed_at = self._now_fn()
            self._usage_sink.record(
                LLMCallRecord(
                    llm_call_id=f"llm-call-{next(_call_id_counter)}",
                    run_id=run_id,
                    module_id=module_id,
                    node=node,
                    route=route,
                    model=config.model,
                    input_tokens=completion.input_tokens,
                    output_tokens=completion.output_tokens,
                    latency_ms=completion.latency_ms,
                    status=LLMCallStatus.SUCCESS,
                    retry_count=attempt,
                    started_at=started_at,
                    completed_at=completed_at,
                )
            )
            return completion.parsed_output

        raise LLMRouterError(route, config.max_retries + 1, last_error)
