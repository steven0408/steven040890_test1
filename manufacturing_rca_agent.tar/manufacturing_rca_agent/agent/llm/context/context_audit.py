"""ContextBuildRecord / ContextAuditSink (Phase 5C-1) -- same "Protocol +
InMemory reference impl" pattern as HumanAuditSink/ToolCallAuditSink/
LLMUsageSink: a durable-store-shaped seam, not AgentState. Deliberately
lightweight -- counts and sizes only, never the rendered prompt/context
content itself (avoid duplicating potentially large/sensitive context into
a second store just for audit purposes). Future Evaluator reads this to ask
"is context size correlated with worse Planner decisions/more retries?".
"""
from datetime import datetime
from typing import Protocol

from agent.state.base import RCABaseModel


class ContextBuildRecord(RCABaseModel):
    run_id: str
    module_id: str
    node: str
    included_findings_count: int
    included_evidence_count: int
    included_skills_count: int
    included_knowledge_count: int
    estimated_context_characters: int
    items_trimmed: int
    build_duration_ms: float
    started_at: datetime
    completed_at: datetime


class ContextAuditSink(Protocol):
    def record(self, record: ContextBuildRecord) -> None: ...

    def list_for_run(self, run_id: str) -> list[ContextBuildRecord]: ...


class InMemoryContextAuditSink:
    def __init__(self) -> None:
        self._records: list[ContextBuildRecord] = []

    def record(self, record: ContextBuildRecord) -> None:
        self._records.append(record)

    def list_for_run(self, run_id: str) -> list[ContextBuildRecord]:
        return [r for r in self._records if r.run_id == run_id]
