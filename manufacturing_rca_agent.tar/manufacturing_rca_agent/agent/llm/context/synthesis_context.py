"""SynthesisContext (Phase 6A item 3) -- answers "what should Synthesis
see?" the same way PlannerContext/AnalyzerContext answer that question for
their own nodes: a bounded, budget-trimmed projection, never the full
AgentState. No LLM call happens in this phase -- this is the context
contract a future real Synthesis (Phase 6B+) will consume unchanged, and
today's deterministic renderer (agent/synthesis/renderer.py) is built
straight from `SynthesisContext.module_handoffs` via `HandoffPackage`
(agent/synthesis/package.py) instead.
"""
import itertools
from datetime import datetime, timezone
from typing import Callable

from pydantic import Field

from agent.llm.context.reasoning_skill_retriever import EmptyReasoningSkillRetriever, ReasoningSkillRetriever, ReasoningSkillSummary
from agent.llm.context.synthesis_context_audit import SynthesisContextAuditSink, SynthesisContextBuildRecord
from agent.skills.models import SkillConsumerNode
from agent.state.base import RCABaseModel
from agent.state.enums import TaskType
from agent.state.models import CrossModuleRelation, Limitation, ModuleHandoff, RecommendationCandidate
from agent.state.state import AgentState
from agent.synthesis.handoff_builder import ModuleHandoffBuilder

_context_build_id_counter = itertools.count(1)


class SynthesisGoalContext(RCABaseModel):
    task_type: TaskType
    statement: str


class SynthesisContext(RCABaseModel):
    run_id: str
    request_summary: str
    normalized_request: str
    global_goal: SynthesisGoalContext | None
    factory_summary: str
    module_handoffs: list[ModuleHandoff]
    # Phase 6B: always [] unless a caller explicitly supplies them --
    # nothing in this codebase auto-generates a CrossModuleRelation or a
    # RecommendationCandidate yet (Phase 6A explicitly deferred both). A
    # future relation-detector/recommendation service would populate these
    # via `SynthesisContextBuilder.build(..., cross_module_relations=...,
    # recommendation_candidates=...)`; Synthesis (LLM or deterministic)
    # only ever *references* ids already here, never invents new ones.
    cross_module_relations: list[CrossModuleRelation] = Field(default_factory=list)
    recommendation_candidates: list[RecommendationCandidate] = Field(default_factory=list)
    relevant_reasoning_skills: list[ReasoningSkillSummary] = Field(default_factory=list)
    global_limitations: list[Limitation] = Field(default_factory=list)
    output_contract_version: str = "1"


class SynthesisContextBuildOutcome:
    def __init__(self, context: SynthesisContext, record: SynthesisContextBuildRecord):
        self.context = context
        self.record = record


class SynthesisContextBudget(RCABaseModel):
    max_reasoning_skills: int = 3
    max_global_limitations: int = 10
    max_context_characters: int = 15000


# Trim order, lowest-priority-first -- module_handoffs (the actual analysis
# results) and global_goal/request_summary are never trimmed, mirroring
# PlannerContext's "Hard Rules/Goal/current critical state never trimmed"
# rule (agent/llm/context/planner_context.py).
_TRIM_SEQUENCE = ["relevant_reasoning_skills", "global_limitations"]


def _trim_to_character_budget(context: SynthesisContext, max_characters: int) -> tuple[SynthesisContext, int]:
    trimmed = 0
    while len(context.model_dump_json()) > max_characters:
        progressed = False
        for bucket in _TRIM_SEQUENCE:
            items = getattr(context, bucket)
            if items:
                context = context.model_copy(update={bucket: items[:-1]})
                trimmed += 1
                progressed = True
                break
        if not progressed:
            break
    return context, trimmed


class SynthesisContextBuilder:
    def __init__(
        self,
        handoff_builder: ModuleHandoffBuilder | None = None,
        reasoning_skill_retriever: ReasoningSkillRetriever | None = None,
        audit_sink: SynthesisContextAuditSink | None = None,
        *,
        now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ):
        self._handoff_builder = handoff_builder or ModuleHandoffBuilder()
        self._reasoning_skill_retriever = reasoning_skill_retriever or EmptyReasoningSkillRetriever()
        self._audit_sink = audit_sink
        self._now_fn = now_fn

    def build(
        self,
        state: AgentState,
        *,
        budget: SynthesisContextBudget | None = None,
        cross_module_relations: list[CrossModuleRelation] | None = None,
        recommendation_candidates: list[RecommendationCandidate] | None = None,
    ) -> SynthesisContextBuildOutcome:
        started_at = self._now_fn()
        budget = budget or SynthesisContextBudget()

        module_handoffs = [self._handoff_builder.build(module_state) for module_state in state.module_states.values()]
        module_handoffs.sort(key=lambda h: h.module_id)

        task_type = state.global_goal.task_type if state.global_goal is not None else None
        reasoning_skills = self._reasoning_skill_retriever.retrieve(
            node=SkillConsumerNode.SYNTHESIS, module_type=None, task_type=task_type, limit=budget.max_reasoning_skills
        )

        global_limitations = [lim for handoff in module_handoffs for lim in handoff.limitations][: budget.max_global_limitations]

        context = SynthesisContext(
            run_id=state.run_id,
            request_summary=state.user_request.raw_text,
            normalized_request=state.normalized_request.normalized_text if state.normalized_request is not None else state.user_request.raw_text,
            global_goal=SynthesisGoalContext(task_type=state.global_goal.task_type, statement=state.global_goal.raw_statement) if state.global_goal is not None else None,
            factory_summary=f"{state.factory_context.factory_name} ({state.factory_context.factory_id})",
            module_handoffs=module_handoffs,
            cross_module_relations=list(cross_module_relations or []),
            recommendation_candidates=list(recommendation_candidates or []),
            relevant_reasoning_skills=reasoning_skills,
            global_limitations=global_limitations,
            output_contract_version="1",
        )
        context, items_trimmed = _trim_to_character_budget(context, budget.max_context_characters)

        completed_at = self._now_fn()
        record = SynthesisContextBuildRecord(
            context_build_record_id=f"synth-ctx-build-{next(_context_build_id_counter)}",
            run_id=state.run_id,
            included_modules=[h.module_id for h in context.module_handoffs],
            included_findings_count=sum(len(h.confirmed_findings) for h in context.module_handoffs),
            included_root_causes_count=sum(len(h.root_causes) for h in context.module_handoffs),
            included_limitations_count=len(context.global_limitations),
            included_reasoning_skills_count=len(context.relevant_reasoning_skills),
            estimated_context_characters=len(context.model_dump_json()),
            items_trimmed=items_trimmed,
            build_duration_ms=(completed_at - started_at).total_seconds() * 1000,
            started_at=started_at,
            completed_at=completed_at,
        )
        if self._audit_sink is not None:
            self._audit_sink.record(record)

        return SynthesisContextBuildOutcome(context=context, record=record)
