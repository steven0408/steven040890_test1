"""PlannerContext (Phase 5C-1) -- answers "what should Module Planner see
when deciding the next Objective?" `Full State != LLM Context`:
`ModuleState` is complete runtime memory (unbounded observations/evidence/
tool_calls/reflection_history); `PlannerContext` is a selected, summarized,
budget-trimmed working set built fresh every decision, never a dump of
ModuleState. No LLM is called this phase -- this is the foundation
Phase 5C-2's Mock LLM Planner will consume.
"""
import itertools
from datetime import datetime, timezone
from typing import Callable

from pydantic import Field

from agent.llm.context.capability_retriever import CapabilityRetriever, SkillSummary
from agent.llm.context.context_audit import ContextAuditSink, ContextBuildRecord
from agent.llm.context.evidence_selector import DeterministicEvidenceSelector, SelectedEvidence
from agent.llm.context.history_summarizer import HistorySummaryItem, summarize_objective_history
from agent.llm.context.knowledge_retriever import EmptyKnowledgeRetriever, KnowledgeItem, KnowledgeRetriever, ValidationStatus
from agent.llm.context.reasoning_skill_retriever import EmptyReasoningSkillRetriever, ReasoningSkillRetriever, ReasoningSkillSummary
from agent.planning.hypothesis_view import latest_hypotheses
from agent.skills.models import SkillConsumerNode
from agent.state.base import RCABaseModel
from agent.state.enums import (
    BranchStatus,
    EntityAnalysisStatus,
    FindingStatus,
    HypothesisStatus,
    ObjectiveAction,
    TargetRefType,
    TaskType,
)
from agent.state.models import Finding, ModuleState, TargetRef

_ROLE = (
    "You are the Module Planner for a manufacturing RCA agent. Your only job is to decide the next "
    "Objective for this module, or to decide no further objective is viable. You never execute a Tool, "
    "never choose a Skill directly, and never produce the final answer."
)

_HARD_RULES = [
    "Choose next_objective.action only from Relevant Capabilities' supported_actions -- never invent a new ObjectiveAction.",
    "Choose next_objective.capability_key only by copying one of Relevant Capabilities' own capability_key values verbatim -- never invent one.",
    "Never select a specific Skill or Tool by name -- CapabilityResolver resolves that from your chosen action + capability_key.",
    "Never write SQL or Python code.",
    "Never produce the final RCA answer or conclusion -- that is Synthesis's job.",
    "Keep rationale_summary concise -- do not include chain-of-thought reasoning.",
]


# --- Sub-schemas -------------------------------------------------------------


class PlannerGoalContext(RCABaseModel):
    module_type: str
    task_type: TaskType
    module_goal_statement: str


class CurrentObjectiveSummary(RCABaseModel):
    objective_id: str
    action: ObjectiveAction
    capability_key: str | None
    description: str
    target_ref: TargetRef


class BranchSummary(RCABaseModel):
    branch_id: str
    name: str
    pattern: str
    status: BranchStatus
    priority_score: float
    entity_ids: list[str]


class FindingSummary(RCABaseModel):
    finding_id: str
    statement: str
    pattern: str
    status: FindingStatus
    is_root_cause: bool
    entity_ids: list[str]


class HypothesisSummary(RCABaseModel):
    hypothesis_id: str
    statement: str
    status: HypothesisStatus
    confidence: float


class LimitationSummary(RCABaseModel):
    description: str
    impact_statement: str


class EntityStateSummary(RCABaseModel):
    entity_id: str
    entity_type: str
    status: EntityAnalysisStatus
    priority_score: float
    branch_id: str | None


class CurrentAnalysisState(RCABaseModel):
    current_objective: CurrentObjectiveSummary | None
    active_branches: list[BranchSummary] = Field(default_factory=list)
    top_findings: list[FindingSummary] = Field(default_factory=list)
    open_hypotheses: list[HypothesisSummary] = Field(default_factory=list)
    limitations: list[LimitationSummary] = Field(default_factory=list)
    relevant_entity_states: list[EntityStateSummary] = Field(default_factory=list)


class PlannerBudgetStatus(RCABaseModel):
    steps_remaining: int
    tool_calls_remaining: int
    retry_count: int


class PlannerContextBudget(RCABaseModel):
    """Coarse, provider-tokenizer-agnostic context budget (same philosophy
    as AnalyzerContextBuilder's) -- caps item counts at the source (each
    selector/retriever/summarizer is called with its own `limit`), then a
    character-budget trim pass is a secondary safety net."""

    max_findings: int = 5
    max_evidence: int = 5
    max_skills: int = 4
    max_knowledge_items: int = 3
    max_history_items: int = 5
    max_reasoning_skills: int = 2
    max_context_characters: int = 6000


class RequestConstraintSummary(RCABaseModel):
    """Phase WB-3F.4: a bounded rendering of one `RequestConstraint`
    (agent/state/scope.py) for Planner context -- the explicit boundary the
    USER stated, threaded from `ModuleGoal.constraints` (see that field's
    own docstring for the full ModuleTask -> ModuleGoal chain). Distinct
    from `ObjectiveScope.filters`: this is what was REQUESTED, never what
    any one Objective actually queries."""

    dimension: str
    operator: str
    value: str | list[str]
    source: str


class PlannerContext(RCABaseModel):
    role: str
    hard_rules: list[str]
    goal: PlannerGoalContext
    current_state: CurrentAnalysisState
    relevant_evidence: list[SelectedEvidence]
    relevant_capabilities: list[SkillSummary]
    relevant_knowledge: list[KnowledgeItem]
    relevant_reasoning_skills: list[ReasoningSkillSummary] = Field(default_factory=list)
    history_summary: list[HistorySummaryItem]
    # Phase WB-3F.4: bounded, always-included (never budget-trimmed -- see
    # `_TRIM_SEQUENCE`'s own docstring below) since request constraints are
    # both small in number (a handful at most) and load-bearing for the
    # scope-preservation guidance (agent/llm/prompts/planner.py).
    request_constraints: list[RequestConstraintSummary] = Field(default_factory=list)
    budget: PlannerBudgetStatus
    output_contract_version: str = "1"


class PlannerContextBuildOutcome:
    """Not persisted -- pairs the PlannerContext a future Planner LLM/node
    consumes with its ContextBuildRecord (already recorded into
    `audit_sink` if one was configured; also returned directly for
    immediate inspection/testing)."""

    def __init__(self, context: PlannerContext, record: ContextBuildRecord):
        self.context = context
        self.record = record


# --- TaskType-aware depth (item 8) ------------------------------------------


class _Gating(RCABaseModel):
    branches: bool
    hypotheses: bool
    entity_states: bool


_GATING: dict[TaskType, _Gating] = {
    TaskType.INFORMATION: _Gating(branches=False, hypotheses=False, entity_states=False),
    TaskType.ANALYSIS: _Gating(branches=True, hypotheses=False, entity_states=False),
    TaskType.RCA: _Gating(branches=True, hypotheses=True, entity_states=True),
}

_DEFAULT_BUDGETS: dict[TaskType, PlannerContextBudget] = {
    # Phase WB-3F.3: `max_skills` bumped 2 -> 5 -- empirically confirmed
    # (not guessed) via a direct repo query that WB's own INFORMATION-tier
    # EXECUTION-skill catalog has grown to 5 candidates (bank/issue/oee/
    # output/wip status summaries); with the old default of 2, retrieval's
    # own alphabetical-fallback tie-break (no embeddings/relevance scoring
    # this phase -- see DeterministicCapabilityRetriever's own docstring)
    # would silently exclude 3 of the 5 from ever reaching the Planner on
    # a fresh (action_hint=None) round, regardless of which one the
    # question actually needed.
    TaskType.INFORMATION: PlannerContextBudget(max_findings=2, max_evidence=2, max_skills=5, max_knowledge_items=0, max_history_items=2, max_context_characters=3000),
    # Phase WB-3E: `max_reasoning_skills` bumped from the class default (2)
    # to accommodate WB's own richer domain-scoped reasoning-skill set
    # (~5 ANALYSIS-relevant / ~7 RCA-relevant candidates as of this phase,
    # see agent/skills/reasoning/) -- with the old default, the SAME
    # alphabetically-first 2 skills would win for every WB call regardless
    # of scenario (retrieval ranking is deterministic-by-skill_id, not
    # relevance-scored), making "relevant included, irrelevant excluded"
    # untestable in any meaningful way. Purely a numeric tuning of these
    # two dict VALUES -- `PlannerContextBudget`'s own shape, `bootstrap.py`,
    # and every other Core file are unchanged; OEE (which has no
    # domains=["wb"]-scoped reasoning skills to gain from a higher limit)
    # is unaffected in practice, only structurally eligible for more if it
    # ever grows its own reasoning-skill set too.
    #
    # Phase WB-3F.3: `max_skills` separately bumped 4 -> 10 -- the SAME
    # class of empirical fix as `max_reasoning_skills` above, found via a
    # direct repo query rather than guessed: WB's ANALYSIS-tier EXECUTION-
    # skill catalog has grown to 10 candidates (bank/issue/oee/output/wip
    # analysis + trend variants). With the old default of 4, a fresh
    # (action_hint=None) ANALYSIS round would only ever see the 4
    # alphabetically-first candidates -- `wb.bank_aging_analysis`,
    # `wb.bank_shortage_trend_analysis`, `wb.issue_output_relationship_
    # analysis`, `wb.issue_trend_analysis` -- structurally EXCLUDING
    # `wb.output_comparison` (7th alphabetically) from ever reaching the
    # Planner for a plain "compare output across plants" request,
    # regardless of anything the prompt says. Confirmed live: this is
    # exactly what caused a real LLM call to invent a mismatched
    # capability_key/action pairing from the only candidates it could see.
    # `max_context_characters` also bumped 6000 -> 14000 alongside
    # `max_skills` above -- empirically verified (not guessed, via a
    # scratchpad sweep script) that leaving it at 6000 caused the now-
    # larger `relevant_capabilities` rendering (10 capabilities instead of
    # 4, each also now showing required/optional scope dimensions) to
    # crowd out `relevant_reasoning_skills` entirely under the character-
    # trim pass's own `_TRIM_SEQUENCE` (which trims reasoning skills before
    # capabilities) -- 0 reasoning skills survived at 6000/8000 chars in
    # the sweep; 14000 (matching RCA's own already-tuned value) reliably
    # fits all 10 capabilities plus 2 reasoning skills.
    TaskType.ANALYSIS: PlannerContextBudget(max_findings=5, max_evidence=5, max_skills=10, max_knowledge_items=3, max_history_items=5, max_reasoning_skills=4, max_context_characters=14000),
    # `max_context_characters` bumped 10000 -> 14000 alongside
    # `max_reasoning_skills` (same Phase WB-3E reasoning above) -- verified
    # empirically (not guessed) that the pre-existing 10000 char ceiling
    # let only 2 of the up-to-6 reasoning skills survive the character-
    # budget trim pass even with `max_reasoning_skills=6` raised; 14000 is
    # a proportionate (40%) increase that lets ~4 fit, still well short of
    # unbounded. This trim pass is deliberately staying ON (not raised
    # enough to always hit the count ceiling) -- context stays bounded
    # even for a densely reasoning-skill-populated domain like WB.
    #
    # Phase WB-3F.3: `max_skills` bumped 6 -> 10 -- same fix as ANALYSIS
    # above; WB's RCA-tier EXECUTION-skill catalog also has 10 candidates,
    # and `wb.output_comparison` (7th alphabetically) was equally at risk
    # of exclusion on a fresh RCA round.
    # Phase WB-3F.3: `max_context_characters` bumped 14000 -> 16000 --
    # RCA's own max_findings/max_evidence/max_history_items (10 each) are
    # double ANALYSIS's (5 each), so RCA needs headroom beyond ANALYSIS's
    # own now-equal 14000 to preserve the deliberate "deeper task type gets
    # more budget" ordering (see test_planner_context_budget.py's own
    # `test_default_budgets_grow_from_information_to_analysis_to_rca`) --
    # not a re-guess of ANALYSIS's separately-measured 14000, just enough
    # margin to keep RCA strictly larger as intended.
    TaskType.RCA: PlannerContextBudget(max_findings=10, max_evidence=10, max_skills=10, max_knowledge_items=5, max_history_items=10, max_reasoning_skills=6, max_context_characters=16000),
}

# Trim order, lowest-priority-first (matches the Phase 5C-1 spec's kept-
# priority list read in reverse) -- Hard Rules/Goal/current critical state
# (current_objective, active_branches, limitations, relevant_entity_states)
# are never in this list, so they are never trimmed.
_TRIM_SEQUENCE = [
    "history_summary",
    "relevant_reasoning_skills",
    "relevant_knowledge",
    "relevant_capabilities",
    "current_state.open_hypotheses",
    "current_state.top_findings",
    "relevant_evidence",
]

_context_build_id_counter = itertools.count(1)


def select_top_findings(findings: list[Finding], *, limit: int) -> list[Finding]:
    """The "FindingSelector" -- root-cause-confirmed findings first, then
    confirmed-but-not-root-cause, then hypothesis-tier by confidence."""
    if limit <= 0:
        return []
    ranked = sorted(findings, key=lambda f: (f.is_root_cause, f.status == FindingStatus.CONFIRMED, f.confidence), reverse=True)
    return ranked[:limit]


def _relevant_scope(module_state: ModuleState) -> tuple[list[str], list[str]]:
    """Entities/branches the current decision is actually about -- ACTIVE
    branches' member entities, plus the current objective's own entity
    target if any. Feeds EvidenceSelector's entity/branch matching."""
    active_branch_ids = [b.branch_id for b in module_state.branches.values() if b.status == BranchStatus.ACTIVE]
    entity_ids = [e.entity_id for e in module_state.entity_states.values() if e.branch_id in active_branch_ids]
    current = module_state.current_objective
    if current is not None and current.target_ref.ref_type == TargetRefType.ENTITY:
        entity_ids.append(current.target_ref.ref_id)
    return list(dict.fromkeys(entity_ids)), active_branch_ids


def _current_objective_summary(module_state: ModuleState) -> CurrentObjectiveSummary | None:
    obj = module_state.current_objective
    if obj is None:
        return None
    return CurrentObjectiveSummary(objective_id=obj.objective_id, action=obj.action, capability_key=obj.capability_key, description=obj.description, target_ref=obj.target_ref)


def _branch_summaries(module_state: ModuleState) -> list[BranchSummary]:
    active = [b for b in module_state.branches.values() if b.status == BranchStatus.ACTIVE]
    ranked = sorted(active, key=lambda b: b.priority_score, reverse=True)
    return [
        BranchSummary(branch_id=b.branch_id, name=b.name, pattern=b.pattern, status=b.status, priority_score=b.priority_score, entity_ids=list(b.entity_ids))
        for b in ranked
    ]


def _finding_summaries(findings: list[Finding]) -> list[FindingSummary]:
    return [
        FindingSummary(finding_id=f.finding_id, statement=f.statement, pattern=f.pattern, status=f.status, is_root_cause=f.is_root_cause, entity_ids=list(f.entity_ids))
        for f in findings
    ]


def _hypothesis_summaries(module_state: ModuleState) -> list[HypothesisSummary]:
    # Phase WB-3F.1: reads the LATEST status/confidence per hypothesis_id
    # (see agent/planning/hypothesis_view.py) -- so Planner never proposes
    # against or re-prioritizes a hypothesis Reflector has already
    # REFUTED/updated based on stale, superseded state.
    return [
        HypothesisSummary(hypothesis_id=h.hypothesis_id, statement=h.statement, status=h.status, confidence=h.confidence)
        for h in latest_hypotheses(module_state.hypotheses)
    ]


def _limitation_summaries(module_state: ModuleState) -> list[LimitationSummary]:
    return [LimitationSummary(description=lim.description, impact_statement=lim.impact_statement) for lim in module_state.limitations]


def _entity_state_summaries(module_state: ModuleState, entity_ids: list[str]) -> list[EntityStateSummary]:
    entity_set = set(entity_ids)
    return [
        EntityStateSummary(entity_id=e.entity_id, entity_type=e.entity_type, status=e.status, priority_score=e.priority_score, branch_id=e.branch_id)
        for e in module_state.entity_states.values()
        if e.entity_id in entity_set
    ]


def _trim_to_character_budget(context: PlannerContext, max_characters: int) -> tuple[PlannerContext, int]:
    trimmed = 0
    while len(context.model_dump_json()) > max_characters:
        progressed = False
        for bucket in _TRIM_SEQUENCE:
            if bucket.startswith("current_state."):
                field = bucket.split(".", 1)[1]
                items = getattr(context.current_state, field)
                if items:
                    context = context.model_copy(update={"current_state": context.current_state.model_copy(update={field: items[:-1]})})
                    trimmed += 1
                    progressed = True
                    break
            else:
                items = getattr(context, bucket)
                if items:
                    context = context.model_copy(update={bucket: items[:-1]})
                    trimmed += 1
                    progressed = True
                    break
        if not progressed:
            break  # Hard Rules/Goal/current critical state left -- nothing further to trim
    return context, trimmed


class PlannerContextBuilder:
    def __init__(
        self,
        evidence_selector: DeterministicEvidenceSelector,
        capability_retriever: CapabilityRetriever,
        knowledge_retriever: KnowledgeRetriever | None = None,
        audit_sink: ContextAuditSink | None = None,
        *,
        reasoning_skill_retriever: ReasoningSkillRetriever | None = None,
        now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ):
        self._evidence_selector = evidence_selector
        self._capability_retriever = capability_retriever
        self._knowledge_retriever = knowledge_retriever or EmptyKnowledgeRetriever()
        self._reasoning_skill_retriever = reasoning_skill_retriever or EmptyReasoningSkillRetriever()
        self._audit_sink = audit_sink
        self._now_fn = now_fn

    def build(
        self,
        module_state: ModuleState,
        *,
        run_id: str,
        node: str = "module_planner",
        budget: PlannerContextBudget | None = None,
    ) -> PlannerContextBuildOutcome:
        started_at = self._now_fn()
        task_type = module_state.goal.task_type
        gating = _GATING[task_type]
        budget = budget or _DEFAULT_BUDGETS[task_type]

        entity_ids, branch_ids = _relevant_scope(module_state)

        goal = PlannerGoalContext(module_type=module_state.module_type, task_type=task_type, module_goal_statement=module_state.goal.statement)

        top_findings = select_top_findings(module_state.findings, limit=budget.max_findings)
        current_state = CurrentAnalysisState(
            current_objective=_current_objective_summary(module_state),
            active_branches=_branch_summaries(module_state) if gating.branches else [],
            top_findings=_finding_summaries(top_findings),
            open_hypotheses=_hypothesis_summaries(module_state) if gating.hypotheses else [],
            limitations=_limitation_summaries(module_state),
            relevant_entity_states=_entity_state_summaries(module_state, entity_ids) if gating.entity_states else [],
        )

        relevant_evidence = self._evidence_selector.select(
            module_state, relevant_entity_ids=entity_ids, relevant_branch_ids=branch_ids, limit=budget.max_evidence
        )

        action_hint = module_state.current_objective.action if module_state.current_objective is not None else None
        relevant_capabilities = self._capability_retriever.retrieve(
            module_type=module_state.module_type, task_type=task_type, action_hint=action_hint, limit=budget.max_skills
        )

        if budget.max_knowledge_items > 0:
            patterns = [b.pattern for b in module_state.branches.values()]
            relevant_knowledge = self._knowledge_retriever.retrieve(
                module_type=module_state.module_type, task_type=task_type, entity_ids=entity_ids, patterns=patterns, limit=budget.max_knowledge_items
            )
        else:
            relevant_knowledge = []
        # defensive: PlannerContext.relevant_knowledge is VALIDATED-only by
        # contract, even if a misbehaving KnowledgeRetriever implementation
        # returns a CANDIDATE item -- never silently promoted.
        relevant_knowledge = [k for k in relevant_knowledge if k.validation_status == ValidationStatus.VALIDATED]

        relevant_reasoning_skills = self._reasoning_skill_retriever.retrieve(
            node=SkillConsumerNode.PLANNER, module_type=module_state.module_type, task_type=task_type, limit=budget.max_reasoning_skills
        )

        history_summary = summarize_objective_history(module_state, limit=budget.max_history_items)

        # Phase WB-3F.4: threaded from ModuleGoal.constraints (itself
        # threaded from ModuleTask/NormalizedRequest -- see that field's
        # own docstring). Not gated by TaskType/budget.max_* -- always
        # rendered in full, since it is small and load-bearing.
        request_constraints = [
            RequestConstraintSummary(dimension=c.dimension, operator=c.operator.value, value=c.value, source=c.source.value)
            for c in module_state.goal.constraints
        ]

        budget_status = PlannerBudgetStatus(
            steps_remaining=max(module_state.budget.max_steps - module_state.budget.used_steps, 0),
            tool_calls_remaining=max(module_state.budget.max_tool_calls - module_state.budget.used_tool_calls, 0),
            retry_count=module_state.metrics.retry_count,
        )

        context = PlannerContext(
            role=_ROLE,
            hard_rules=list(_HARD_RULES),
            goal=goal,
            current_state=current_state,
            relevant_evidence=relevant_evidence,
            relevant_capabilities=relevant_capabilities,
            relevant_knowledge=relevant_knowledge,
            relevant_reasoning_skills=relevant_reasoning_skills,
            history_summary=history_summary,
            request_constraints=request_constraints,
            budget=budget_status,
            output_contract_version="1",
        )
        context, items_trimmed = _trim_to_character_budget(context, budget.max_context_characters)

        completed_at = self._now_fn()
        record = ContextBuildRecord(
            context_build_record_id=f"ctx-build-{next(_context_build_id_counter)}",
            run_id=run_id,
            module_id=module_state.module_id,
            node=node,
            included_findings_count=len(context.current_state.top_findings),
            included_evidence_count=len(context.relevant_evidence),
            included_skills_count=len(context.relevant_capabilities),
            included_knowledge_count=len(context.relevant_knowledge),
            included_reasoning_skills_count=len(context.relevant_reasoning_skills),
            estimated_context_characters=len(context.model_dump_json()),
            items_trimmed=items_trimmed,
            build_duration_ms=(completed_at - started_at).total_seconds() * 1000,
            started_at=started_at,
            completed_at=completed_at,
        )
        if self._audit_sink is not None:
            self._audit_sink.record(record)

        return PlannerContextBuildOutcome(context=context, record=record)
