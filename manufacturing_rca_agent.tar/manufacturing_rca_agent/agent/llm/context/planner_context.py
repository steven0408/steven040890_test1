"""PlannerContext (Phase 5C-1) -- answers "what should Module Planner see
when deciding the next Objective?" `Full State != LLM Context`:
`ModuleState` is complete runtime memory (unbounded observations/evidence/
tool_calls/reflection_history); `PlannerContext` is a selected, summarized,
budget-trimmed working set built fresh every decision, never a dump of
ModuleState. No LLM is called this phase -- this is the foundation
Phase 5C-2's Mock LLM Planner will consume.
"""
from datetime import datetime, timezone
from typing import Callable

from pydantic import Field

from agent.llm.context.capability_retriever import CapabilityRetriever, SkillSummary
from agent.llm.context.context_audit import ContextAuditSink, ContextBuildRecord
from agent.llm.context.evidence_selector import DeterministicEvidenceSelector, SelectedEvidence
from agent.llm.context.history_summarizer import HistorySummaryItem, summarize_objective_history
from agent.llm.context.knowledge_retriever import EmptyKnowledgeRetriever, KnowledgeItem, KnowledgeRetriever, ValidationStatus
from agent.state.base import RCABaseModel
from agent.state.enums import (
    BranchStatus,
    EntityAnalysisStatus,
    FindingStatus,
    HypothesisStatus,
    ObjectiveAction,
    TargetRefType,
    TaskType,
)
from agent.state.models import Finding, ModuleState, TargetRef

_ROLE = (
    "You are the Module Planner for a manufacturing RCA agent. Your only job is to decide the next "
    "Objective for this module, or to decide no further objective is viable. You never execute a Tool, "
    "never choose a Skill directly, and never produce the final answer."
)

_HARD_RULES = [
    "Choose next_objective.action only from Relevant Capabilities' supported_actions -- never invent a new ObjectiveAction.",
    "Never select a specific Skill or Tool by name -- CapabilityResolver resolves that from your chosen action.",
    "Never write SQL or Python code.",
    "Never produce the final RCA answer or conclusion -- that is Synthesis's job.",
    "Keep rationale_summary concise -- do not include chain-of-thought reasoning.",
]


# --- Sub-schemas -------------------------------------------------------------


class PlannerGoalContext(RCABaseModel):
    module_type: str
    task_type: TaskType
    module_goal_statement: str


class CurrentObjectiveSummary(RCABaseModel):
    objective_id: str
    action: ObjectiveAction
    description: str
    target_ref: TargetRef


class BranchSummary(RCABaseModel):
    branch_id: str
    name: str
    pattern: str
    status: BranchStatus
    priority_score: float
    entity_ids: list[str]


class FindingSummary(RCABaseModel):
    finding_id: str
    statement: str
    pattern: str
    status: FindingStatus
    is_root_cause: bool
    entity_ids: list[str]


class HypothesisSummary(RCABaseModel):
    hypothesis_id: str
    statement: str
    status: HypothesisStatus
    confidence: float


class LimitationSummary(RCABaseModel):
    description: str
    impact_statement: str


class EntityStateSummary(RCABaseModel):
    entity_id: str
    entity_type: str
    status: EntityAnalysisStatus
    priority_score: float
    branch_id: str | None


class CurrentAnalysisState(RCABaseModel):
    current_objective: CurrentObjectiveSummary | None
    active_branches: list[BranchSummary] = Field(default_factory=list)
    top_findings: list[FindingSummary] = Field(default_factory=list)
    open_hypotheses: list[HypothesisSummary] = Field(default_factory=list)
    limitations: list[LimitationSummary] = Field(default_factory=list)
    relevant_entity_states: list[EntityStateSummary] = Field(default_factory=list)


class PlannerBudgetStatus(RCABaseModel):
    steps_remaining: int
    tool_calls_remaining: int
    retry_count: int


class PlannerContextBudget(RCABaseModel):
    """Coarse, provider-tokenizer-agnostic context budget (same philosophy
    as AnalyzerContextBuilder's) -- caps item counts at the source (each
    selector/retriever/summarizer is called with its own `limit`), then a
    character-budget trim pass is a secondary safety net."""

    max_findings: int = 5
    max_evidence: int = 5
    max_skills: int = 4
    max_knowledge_items: int = 3
    max_history_items: int = 5
    max_context_characters: int = 6000


class PlannerContext(RCABaseModel):
    role: str
    hard_rules: list[str]
    goal: PlannerGoalContext
    current_state: CurrentAnalysisState
    relevant_evidence: list[SelectedEvidence]
    relevant_capabilities: list[SkillSummary]
    relevant_knowledge: list[KnowledgeItem]
    history_summary: list[HistorySummaryItem]
    budget: PlannerBudgetStatus
    output_contract_version: str = "1"


class PlannerContextBuildOutcome:
    """Not persisted -- pairs the PlannerContext a future Planner LLM/node
    consumes with its ContextBuildRecord (already recorded into
    `audit_sink` if one was configured; also returned directly for
    immediate inspection/testing)."""

    def __init__(self, context: PlannerContext, record: ContextBuildRecord):
        self.context = context
        self.record = record


# --- TaskType-aware depth (item 8) ------------------------------------------


class _Gating(RCABaseModel):
    branches: bool
    hypotheses: bool
    entity_states: bool


_GATING: dict[TaskType, _Gating] = {
    TaskType.INFORMATION: _Gating(branches=False, hypotheses=False, entity_states=False),
    TaskType.ANALYSIS: _Gating(branches=True, hypotheses=False, entity_states=False),
    TaskType.RCA: _Gating(branches=True, hypotheses=True, entity_states=True),
}

_DEFAULT_BUDGETS: dict[TaskType, PlannerContextBudget] = {
    TaskType.INFORMATION: PlannerContextBudget(max_findings=2, max_evidence=2, max_skills=2, max_knowledge_items=0, max_history_items=2, max_context_characters=3000),
    TaskType.ANALYSIS: PlannerContextBudget(max_findings=5, max_evidence=5, max_skills=4, max_knowledge_items=3, max_history_items=5, max_context_characters=6000),
    TaskType.RCA: PlannerContextBudget(max_findings=10, max_evidence=10, max_skills=6, max_knowledge_items=5, max_history_items=10, max_context_characters=10000),
}

# Trim order, lowest-priority-first (matches the Phase 5C-1 spec's kept-
# priority list read in reverse) -- Hard Rules/Goal/current critical state
# (current_objective, active_branches, limitations, relevant_entity_states)
# are never in this list, so they are never trimmed.
_TRIM_SEQUENCE = [
    "history_summary",
    "relevant_knowledge",
    "relevant_capabilities",
    "current_state.open_hypotheses",
    "current_state.top_findings",
    "relevant_evidence",
]


def select_top_findings(findings: list[Finding], *, limit: int) -> list[Finding]:
    """The "FindingSelector" -- root-cause-confirmed findings first, then
    confirmed-but-not-root-cause, then hypothesis-tier by confidence."""
    if limit <= 0:
        return []
    ranked = sorted(findings, key=lambda f: (f.is_root_cause, f.status == FindingStatus.CONFIRMED, f.confidence), reverse=True)
    return ranked[:limit]


def _relevant_scope(module_state: ModuleState) -> tuple[list[str], list[str]]:
    """Entities/branches the current decision is actually about -- ACTIVE
    branches' member entities, plus the current objective's own entity
    target if any. Feeds EvidenceSelector's entity/branch matching."""
    active_branch_ids = [b.branch_id for b in module_state.branches.values() if b.status == BranchStatus.ACTIVE]
    entity_ids = [e.entity_id for e in module_state.entity_states.values() if e.branch_id in active_branch_ids]
    current = module_state.current_objective
    if current is not None and current.target_ref.ref_type == TargetRefType.ENTITY:
        entity_ids.append(current.target_ref.ref_id)
    return list(dict.fromkeys(entity_ids)), active_branch_ids


def _current_objective_summary(module_state: ModuleState) -> CurrentObjectiveSummary | None:
    obj = module_state.current_objective
    if obj is None:
        return None
    return CurrentObjectiveSummary(objective_id=obj.objective_id, action=obj.action, description=obj.description, target_ref=obj.target_ref)


def _branch_summaries(module_state: ModuleState) -> list[BranchSummary]:
    active = [b for b in module_state.branches.values() if b.status == BranchStatus.ACTIVE]
    ranked = sorted(active, key=lambda b: b.priority_score, reverse=True)
    return [
        BranchSummary(branch_id=b.branch_id, name=b.name, pattern=b.pattern, status=b.status, priority_score=b.priority_score, entity_ids=list(b.entity_ids))
        for b in ranked
    ]


def _finding_summaries(findings: list[Finding]) -> list[FindingSummary]:
    return [
        FindingSummary(finding_id=f.finding_id, statement=f.statement, pattern=f.pattern, status=f.status, is_root_cause=f.is_root_cause, entity_ids=list(f.entity_ids))
        for f in findings
    ]


def _hypothesis_summaries(module_state: ModuleState) -> list[HypothesisSummary]:
    return [
        HypothesisSummary(hypothesis_id=h.hypothesis_id, statement=h.statement, status=h.status, confidence=h.confidence)
        for h in module_state.hypotheses
    ]


def _limitation_summaries(module_state: ModuleState) -> list[LimitationSummary]:
    return [LimitationSummary(description=lim.description, impact_statement=lim.impact_statement) for lim in module_state.limitations]


def _entity_state_summaries(module_state: ModuleState, entity_ids: list[str]) -> list[EntityStateSummary]:
    entity_set = set(entity_ids)
    return [
        EntityStateSummary(entity_id=e.entity_id, entity_type=e.entity_type, status=e.status, priority_score=e.priority_score, branch_id=e.branch_id)
        for e in module_state.entity_states.values()
        if e.entity_id in entity_set
    ]


def _trim_to_character_budget(context: PlannerContext, max_characters: int) -> tuple[PlannerContext, int]:
    trimmed = 0
    while len(context.model_dump_json()) > max_characters:
        progressed = False
        for bucket in _TRIM_SEQUENCE:
            if bucket.startswith("current_state."):
                field = bucket.split(".", 1)[1]
                items = getattr(context.current_state, field)
                if items:
                    context = context.model_copy(update={"current_state": context.current_state.model_copy(update={field: items[:-1]})})
                    trimmed += 1
                    progressed = True
                    break
            else:
                items = getattr(context, bucket)
                if items:
                    context = context.model_copy(update={bucket: items[:-1]})
                    trimmed += 1
                    progressed = True
                    break
        if not progressed:
            break  # Hard Rules/Goal/current critical state left -- nothing further to trim
    return context, trimmed


class PlannerContextBuilder:
    def __init__(
        self,
        evidence_selector: DeterministicEvidenceSelector,
        capability_retriever: CapabilityRetriever,
        knowledge_retriever: KnowledgeRetriever | None = None,
        audit_sink: ContextAuditSink | None = None,
        *,
        now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ):
        self._evidence_selector = evidence_selector
        self._capability_retriever = capability_retriever
        self._knowledge_retriever = knowledge_retriever or EmptyKnowledgeRetriever()
        self._audit_sink = audit_sink
        self._now_fn = now_fn

    def build(
        self,
        module_state: ModuleState,
        *,
        run_id: str,
        node: str = "module_planner",
        budget: PlannerContextBudget | None = None,
    ) -> PlannerContextBuildOutcome:
        started_at = self._now_fn()
        task_type = module_state.goal.task_type
        gating = _GATING[task_type]
        budget = budget or _DEFAULT_BUDGETS[task_type]

        entity_ids, branch_ids = _relevant_scope(module_state)

        goal = PlannerGoalContext(module_type=module_state.module_type, task_type=task_type, module_goal_statement=module_state.goal.statement)

        top_findings = select_top_findings(module_state.findings, limit=budget.max_findings)
        current_state = CurrentAnalysisState(
            current_objective=_current_objective_summary(module_state),
            active_branches=_branch_summaries(module_state) if gating.branches else [],
            top_findings=_finding_summaries(top_findings),
            open_hypotheses=_hypothesis_summaries(module_state) if gating.hypotheses else [],
            limitations=_limitation_summaries(module_state),
            relevant_entity_states=_entity_state_summaries(module_state, entity_ids) if gating.entity_states else [],
        )

        relevant_evidence = self._evidence_selector.select(
            module_state, relevant_entity_ids=entity_ids, relevant_branch_ids=branch_ids, limit=budget.max_evidence
        )

        action_hint = module_state.current_objective.action if module_state.current_objective is not None else None
        relevant_capabilities = self._capability_retriever.retrieve(
            module_type=module_state.module_type, task_type=task_type, action_hint=action_hint, limit=budget.max_skills
        )

        if budget.max_knowledge_items > 0:
            patterns = [b.pattern for b in module_state.branches.values()]
            relevant_knowledge = self._knowledge_retriever.retrieve(
                module_type=module_state.module_type, task_type=task_type, entity_ids=entity_ids, patterns=patterns, limit=budget.max_knowledge_items
            )
        else:
            relevant_knowledge = []
        # defensive: PlannerContext.relevant_knowledge is VALIDATED-only by
        # contract, even if a misbehaving KnowledgeRetriever implementation
        # returns a CANDIDATE item -- never silently promoted.
        relevant_knowledge = [k for k in relevant_knowledge if k.validation_status == ValidationStatus.VALIDATED]

        history_summary = summarize_objective_history(module_state, limit=budget.max_history_items)

        budget_status = PlannerBudgetStatus(
            steps_remaining=max(module_state.budget.max_steps - module_state.budget.used_steps, 0),
            tool_calls_remaining=max(module_state.budget.max_tool_calls - module_state.budget.used_tool_calls, 0),
            retry_count=module_state.metrics.retry_count,
        )

        context = PlannerContext(
            role=_ROLE,
            hard_rules=list(_HARD_RULES),
            goal=goal,
            current_state=current_state,
            relevant_evidence=relevant_evidence,
            relevant_capabilities=relevant_capabilities,
            relevant_knowledge=relevant_knowledge,
            history_summary=history_summary,
            budget=budget_status,
            output_contract_version="1",
        )
        context, items_trimmed = _trim_to_character_budget(context, budget.max_context_characters)

        completed_at = self._now_fn()
        record = ContextBuildRecord(
            run_id=run_id,
            module_id=module_state.module_id,
            node=node,
            included_findings_count=len(context.current_state.top_findings),
            included_evidence_count=len(context.relevant_evidence),
            included_skills_count=len(context.relevant_capabilities),
            included_knowledge_count=len(context.relevant_knowledge),
            estimated_context_characters=len(context.model_dump_json()),
            items_trimmed=items_trimmed,
            build_duration_ms=(completed_at - started_at).total_seconds() * 1000,
            started_at=started_at,
            completed_at=completed_at,
        )
        if self._audit_sink is not None:
            self._audit_sink.record(record)

        return PlannerContextBuildOutcome(context=context, record=record)
