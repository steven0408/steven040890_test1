"""CapabilityRetriever (Phase 5C-1) -- Planner's view of "what could I do
next", deliberately much narrower than SkillRegistry.list(): a short list of
relevant SkillSummary (no Tool implementation details, no full markdown
body -- see SkillSummary's own docstring). Distinct from CapabilityResolver
(agent/capability/resolver.py), which *resolves* one already-chosen
ObjectiveAction to exactly one Skill for execution; this *retrieves*
candidates for a decision that hasn't been made yet.

Phase 5C-1 scope: deterministic domain/task_type filtering, same primitives
CapabilityResolver already uses (Skill.domains/Skill.task_types) -- no
embeddings/semantic search.
"""
from typing import Protocol

from agent.skills.models import SkillDefinition
from agent.skills.registry import SkillRegistry
from agent.state.base import RCABaseModel
from agent.state.enums import ObjectiveAction, TaskType


class SkillSummary(RCABaseModel):
    """Deliberately excludes `steps`/`required_tools`/`optional_tools`/the
    markdown narrative body -- Planner decides *whether this kind of
    capability is relevant*, not how it executes (SkillRunner's job).
    `required_input_summary` is a short descriptive string
    (SkillDefinition.input_contract), not the actual Tool I/O schema."""

    skill_id: str
    name: str
    purpose: str
    supported_actions: list[ObjectiveAction]
    required_input_summary: str


def _summarize(skill: SkillDefinition) -> SkillSummary:
    return SkillSummary(
        skill_id=skill.skill_id,
        name=skill.name,
        purpose=skill.description,
        supported_actions=list(skill.actions),
        required_input_summary=skill.input_contract,
    )


class CapabilityRetriever(Protocol):
    def retrieve(
        self,
        *,
        module_type: str,
        task_type: TaskType,
        action_hint: ObjectiveAction | None = None,
        limit: int,
    ) -> list[SkillSummary]: ...


class DeterministicCapabilityRetriever:
    def __init__(self, skill_registry: SkillRegistry):
        self._skills = skill_registry

    def retrieve(
        self,
        *,
        module_type: str,
        task_type: TaskType,
        action_hint: ObjectiveAction | None = None,
        limit: int,
    ) -> list[SkillSummary]:
        domain = module_type.lower()
        candidates = [
            skill
            for skill in self._skills.list()
            if (not skill.domains or domain in skill.domains) and (not skill.task_types or task_type in skill.task_types)
        ]
        # action_hint-matching skills first, then the rest, both alphabetically stable
        candidates.sort(key=lambda s: (0 if action_hint is not None and action_hint in s.actions else 1, s.skill_id))
        return [_summarize(skill) for skill in candidates[:limit]]
