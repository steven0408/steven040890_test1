"""History summarization (Phase 5C-1) -- deterministic projection of
`ModuleState.objective_history` into compact narrative lines. Planner needs
to know *what already happened*, not every mechanical ObjectiveRecord field
(observation_ids/evidence_ids/attempt_count bookkeeping).

Stays domain-agnostic on purpose: `outcome_summary` is read straight from
the matching `Evidence.summary` (every Tool already writes a human-readable
sentence there, e.g. "Screened 12 equipment ... 5 abnormal.") rather than
this module interpreting any `structured_payload` itself -- that would
require domain-specific knowledge this generic Harness service must not
have.
"""
from agent.state.base import RCABaseModel
from agent.state.enums import ObjectiveAction, ObjectiveStatus
from agent.state.models import ModuleState


class HistorySummaryItem(RCABaseModel):
    round_number: int
    action: ObjectiveAction
    target_ref_id: str
    status: ObjectiveStatus
    outcome_summary: str


def summarize_objective_history(module_state: ModuleState, *, limit: int) -> list[HistorySummaryItem]:
    if limit <= 0:
        return []

    evidence_by_objective = {e.objective_id: e for e in module_state.evidence}
    observation_by_objective = {o.objective_id: o for o in module_state.observations}

    items: list[HistorySummaryItem] = []
    # dict preserves insertion order (Python 3.7+); objective_history entries
    # are inserted in dispatch order, so this already reads oldest-first.
    for record in module_state.objective_history.values():
        evidence = evidence_by_objective.get(record.objective_id)
        observation = observation_by_objective.get(record.objective_id)
        if evidence is not None:
            outcome = evidence.summary
        elif observation is not None and observation.error is not None:
            outcome = observation.error.message
        else:
            outcome = "(no outcome recorded)"

        items.append(
            HistorySummaryItem(
                round_number=record.created_step,
                action=record.action,
                target_ref_id=record.target_ref.ref_id,
                status=record.status,
                outcome_summary=outcome,
            )
        )

    # most recent first -- if the caller's budget only keeps a few, the
    # freshest history is what Planner is most likely to need
    items.reverse()
    return items[:limit]
