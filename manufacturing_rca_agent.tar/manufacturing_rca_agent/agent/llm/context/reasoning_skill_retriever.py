"""ReasoningSkillRetriever (Phase 5D-4) -- a Context Builder's view of "what
guidance applies to this decision", the REASONING-skill counterpart to
CapabilityRetriever (which only ever surfaces EXECUTION skills, see its own
docstring). Deliberately the same shape/philosophy as CapabilityRetriever
and KnowledgeRetriever: deterministic metadata filtering + stable ranking,
no embeddings/vector search this phase.

A REASONING skill is retrieved by *node* first (only the nodes it declares
in `applicable_nodes` may ever see it -- this is the Node<->Skill
consumption matrix enforced at the retrieval boundary, not just documented
prose), then narrowed by module_type/task_type/role the same way
CapabilityRetriever narrows by domain/task_type. It never reaches
CapabilityResolver/SkillRunner (see agent/capability/resolver.py and
SkillRegistry.list(skill_type=...) filtering) -- retrieval and execution are
different code paths for this Skill type, not just different data.
"""
from typing import Protocol

from agent.skills.models import SkillConsumerNode, SkillDefinition, SkillType
from agent.skills.registry import SkillRegistry
from agent.state.base import RCABaseModel
from agent.state.enums import TaskType


class ReasoningSkillSummary(RCABaseModel):
    """Compact representation for a Context Builder -- `guidance` is the
    Skill markdown's narrative body (the actual "how to think" text),
    deliberately not called "instructions" here: it is guidance a Context
    Builder presents as DATA, never an imperative the LLM must obey (same
    DATA/HARD-RULES boundary discipline as Evidence/Capabilities, see
    build_planner_messages/build_analyzer_messages)."""

    skill_id: str
    name: str
    purpose: str
    guidance: str
    version: str


class ReasoningSkillRetriever(Protocol):
    def retrieve(
        self,
        *,
        node: SkillConsumerNode,
        module_type: str | None = None,
        task_type: TaskType | None = None,
        role: str | None = None,
        limit: int,
    ) -> list[ReasoningSkillSummary]: ...


class EmptyReasoningSkillRetriever:
    """Same role as EmptyKnowledgeRetriever -- the safe default when no
    reasoning-skill directory has been wired up yet."""

    def retrieve(self, *, node, module_type=None, task_type=None, role=None, limit) -> list[ReasoningSkillSummary]:
        return []


def _matches(skill: SkillDefinition, *, node: SkillConsumerNode, module_type: str | None, task_type: TaskType | None, role: str | None) -> bool:
    if node not in skill.applicable_nodes:
        return False
    # `module_type`/`task_type` are None when the caller hasn't decided
    # those dimensions yet (e.g. Analyzer, which runs *before* any module or
    # TaskType is chosen) -- in that case, only a universally-applicable
    # skill (domains=[]/task_types=[]) can legitimately match; a
    # domain/TaskType-scoped skill has no basis to be considered relevant
    # yet, so it's excluded rather than treated as an unscoped wildcard.
    if module_type is None:
        if skill.domains:
            return False
    elif skill.domains and module_type.lower() not in skill.domains:
        return False
    if task_type is None:
        if skill.task_types:
            return False
    elif skill.task_types and task_type not in skill.task_types:
        return False
    if role is not None and skill.roles and role not in skill.roles:
        return False
    return True


class DeterministicReasoningSkillRetriever:
    def __init__(self, skill_registry: SkillRegistry):
        self._skills = skill_registry

    def retrieve(
        self,
        *,
        node: SkillConsumerNode,
        module_type: str | None = None,
        task_type: TaskType | None = None,
        role: str | None = None,
        limit: int,
    ) -> list[ReasoningSkillSummary]:
        candidates = [
            skill
            for skill in self._skills.list(skill_type=SkillType.REASONING)
            if _matches(skill, node=node, module_type=module_type, task_type=task_type, role=role)
        ]
        candidates.sort(key=lambda s: s.skill_id)  # deterministic, stable -- no relevance scoring this phase
        return [
            ReasoningSkillSummary(
                skill_id=skill.skill_id, name=skill.name, purpose=skill.description,
                guidance=self._skills.instructions(skill.skill_id), version=skill.version,
            )
            for skill in candidates[:limit]
        ]
