"""SkillRegistry (Phase 5B-2) -- loads Skills from their markdown files
(agent/skills/markdown.py's frontmatter parser is the single source of
truth; this registry never maintains a second, hand-written copy of a
Skill's steps/metadata).
"""
from __future__ import annotations

from pathlib import Path

from agent.skills.markdown import parse_skill_markdown
from agent.skills.models import SkillDefinition
from agent.tools.registry import ToolNotFoundError, ToolRegistry


class SkillRegistryError(ValueError):
    pass


class DuplicateSkillError(SkillRegistryError):
    pass


class SkillNotFoundError(SkillRegistryError):
    pass


class MissingToolForSkillError(SkillRegistryError):
    pass


class SkillRegistry:
    def __init__(self) -> None:
        self._skills: dict[str, SkillDefinition] = {}
        self._bodies: dict[str, str] = {}

    def register(self, definition: SkillDefinition, body: str = "") -> None:
        if definition.skill_id in self._skills:
            raise DuplicateSkillError(f"skill_id '{definition.skill_id}' is already registered")
        self._skills[definition.skill_id] = definition
        self._bodies[definition.skill_id] = body

    def load_markdown_file(self, path: Path) -> SkillDefinition:
        text = Path(path).read_text(encoding="utf-8")
        definition, body = parse_skill_markdown(text)
        self.register(definition, body)
        return definition

    def load_directory(self, directory: Path) -> list[SkillDefinition]:
        return [self.load_markdown_file(path) for path in sorted(Path(directory).glob("**/*.md"))]

    def get(self, skill_id: str) -> SkillDefinition:
        skill = self._skills.get(skill_id)
        if skill is None:
            raise SkillNotFoundError(f"no skill registered with skill_id '{skill_id}'")
        return skill

    def instructions(self, skill_id: str) -> str:
        self.get(skill_id)
        return self._bodies[skill_id]

    def list(self, *, domain: str | None = None, category: str | None = None) -> list[SkillDefinition]:
        result = list(self._skills.values())
        if domain is not None:
            result = [s for s in result if not s.domains or domain.lower() in s.domains]
        if category is not None:
            result = [s for s in result if s.category == category]
        return result

    def validate_required_tools(self, tool_registry: ToolRegistry) -> None:
        """Every `required_tools`/`optional_tools` entry each registered
        Skill declares must resolve against `tool_registry` -- called once
        after both registries are populated (Phase 5B-2 wiring), not on
        every resolution."""
        for skill in self._skills.values():
            for tool_id in (*skill.required_tools, *skill.optional_tools):
                try:
                    tool_registry.get(tool_id)
                except ToolNotFoundError as exc:
                    raise MissingToolForSkillError(
                        f"skill '{skill.skill_id}' requires tool '{tool_id}', which is not registered"
                    ) from exc
