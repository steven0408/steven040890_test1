from datetime import datetime
from enum import Enum

from pydantic import Field

from agent.state.base import RCABaseModel
from agent.state.enums import ObjectiveAction, RiskLevel, TaskType
from agent.state.models import ErrorRecord
from agent.state.payload import StructuredPayload


class SkillStep(RCABaseModel):
    """One deterministic step in a Skill's procedure -- the machine-
    executable mirror of the markdown body's "Procedure" section, present
    only when the procedure IS a fixed tool sequence (exploratory skills
    without a `steps` list rely on the narrative body + an LLM instead;
    that path isn't built until Phase 5B-3+).
    """

    tool_id: str
    parameter_mapping: dict[str, str] = Field(default_factory=dict)


class SkillDefinition(RCABaseModel):
    """Registry-facing metadata for a Skill, parsed from a markdown file's
    YAML frontmatter (see agent/skills/markdown.py) -- this IS the single
    source of truth; there is no second, hand-maintained copy of `steps`
    anywhere else.
    """

    skill_id: str
    name: str
    description: str
    domains: list[str] = Field(default_factory=list)  # [] = shared
    category: str
    required_tools: list[str] = Field(default_factory=list)
    optional_tools: list[str] = Field(default_factory=list)
    steps: list[SkillStep] = Field(default_factory=list)
    input_contract: str
    output_contract: str
    risk_level: RiskLevel = RiskLevel.LOW
    version: str = "1"

    # Resolution triggers -- what CapabilityResolver matches an Objective
    # against. Declared here, in the same frontmatter, rather than as a
    # second hand-maintained rule table elsewhere: the Skill's markdown file
    # stays the single source of truth for "when do I apply", not just "how
    # do I execute".
    task_types: list[TaskType] = Field(default_factory=list)  # [] = any TaskType
    # Phase 5B-2.1: matches Objective.action (a typed, closed enum), not the
    # free-text-adjacent `target_ref.ref_id` string convention Phase 5B-2's
    # `objective_targets` used (exact/"prefix*" string matching, since the
    # same target string could carry a varying entity id, e.g.
    # "equipment_detail:EQ001"). Entity/branch targeting still lives on
    # TargetRef -- untouched -- action-based matching only replaced the
    # *routing* signal. Unlike `domains`/`task_types`, an empty list here
    # means "never matches" (no legitimate universal action), not "any".
    actions: list[ObjectiveAction] = Field(default_factory=list)


class SkillExecutionStatus(str, Enum):
    SUCCESS = "success"
    ERROR = "error"


class SkillExecutionResult(RCABaseModel):
    """What SkillRunner hands back to Module Executor -- one aggregate
    result per Skill run, regardless of how many steps/tool calls it took
    internally (those are separately audited as ToolCallRecord -- see
    SkillRunOutcome in agent/skills/runner.py). Executor turns this into
    exactly one Observation/Evidence, never one per step."""

    skill_id: str
    status: SkillExecutionStatus
    output_payload: StructuredPayload | None = None
    summary: str
    tool_call_ids: list[str] = Field(default_factory=list)
    error: ErrorRecord | None = None
    started_at: datetime
    completed_at: datetime
