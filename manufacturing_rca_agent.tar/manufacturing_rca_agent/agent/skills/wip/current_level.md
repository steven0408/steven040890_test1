---
skill_id: wip.current_level
name: Current WIP Level
description: Report current WIP inventory level and capacity utilization.
domains: [wip]
category: information
required_tools: [query_wip_level]
optional_tools: []
steps:
  - tool_id: query_wip_level
    parameter_mapping: {}
input_contract: WIPQueryInput
output_contract: WIPLevelStatus
risk_level: low
version: "1"
task_types: [information]
actions: [current_status]
---

# Skill: Current WIP Level

## Goal

Answer "what is WIP right now" -- a single INFORMATION-tier round, no
congestion analysis or root-cause investigation.

## Procedure

1. Call `query_wip_level` to fetch current WIP units and capacity.

## Output Contract

WIPLevelStatus (utilization_pct = current_wip_units / capacity_units)
