"""SkillRunner (Phase 5B-2) -- executes one deterministic Skill's `steps`
sequence, chaining each step's structured output into the next step's input,
with every physical Tool call going through `ToolExecutionManager.execute()`
(never `tool.run()` directly -- see agent/tools/execution_manager.py's
terminology freeze: SkillRunner only ever performs Tool Manager Invocations).

Phase 5B-2 scope: deterministic Skills only (`skill.steps` must be
non-empty); no LLM-driven step selection, no nested ReAct loop inside a
Skill. A step failure stops the whole Skill immediately (no partial-retry-
skip-step contract yet) and is reported back as `SkillExecutionResult.ERROR`
-- Module Executor/Reflector/Planner decide what happens next, exactly as
they already do for a bare Tool ERROR.
"""
from datetime import datetime, timezone
from typing import Callable

from pydantic import ValidationError

from agent.skills.models import SkillDefinition, SkillExecutionResult, SkillExecutionStatus
from agent.state.enums import ErrorType, ObservationStatus
from agent.state.models import ErrorRecord, ModuleState, Objective, ToolCallRecord
from agent.state.payload import PayloadRegistry
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.models import ToolExecutionIdentity
from agent.tools.registry import ToolRegistry


class SkillParameterResolutionError(ValueError):
    pass


class SkillRunOutcome:
    """Not persisted -- pairs the one aggregate SkillExecutionResult Module
    Executor turns into an Observation/Evidence with the full per-step
    ToolCallRecord list it appends to ModuleState.tool_calls (a convenience
    projection -- ToolCallAuditSink stays the physical-execution source of
    truth, per the Phase 5B-1.2 terminology freeze)."""

    def __init__(self, result: SkillExecutionResult, tool_call_records: list[ToolCallRecord]):
        self.result = result
        self.tool_call_records = tool_call_records


def _resolve_param(source: str, prev_output, objective: Objective):
    if source.startswith("prev."):
        if prev_output is None:
            raise SkillParameterResolutionError(f"parameter source '{source}' has no previous step output to read")
        field = source[len("prev.") :]
        if not hasattr(prev_output, field):
            raise SkillParameterResolutionError(f"previous step output has no field '{field}' (source '{source}')")
        return getattr(prev_output, field)
    if source.startswith("objective."):
        value = objective
        for part in source[len("objective.") :].split("."):
            value = getattr(value, part)
        return value
    raise SkillParameterResolutionError(f"unsupported parameter source '{source}'")


class SkillRunner:
    def __init__(self, tool_registry: ToolRegistry, execution_manager: ToolExecutionManager):
        self._tools = tool_registry
        self._execution_manager = execution_manager

    def run(
        self,
        skill: SkillDefinition,
        objective: Objective,
        module_state: ModuleState,
        *,
        now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ) -> SkillRunOutcome:
        if not skill.steps:
            raise ValueError(f"skill '{skill.skill_id}' has no executable steps -- Phase 5B-2 only runs deterministic Skills")

        started_at = now_fn()
        records: list[ToolCallRecord] = []
        prev_output = None
        result_payload = None
        last_tool_summary: str | None = None

        for step_index, step in enumerate(skill.steps):
            tool = self._tools.get(step.tool_id)

            base = {} if prev_output is None else prev_output.model_dump(mode="json")
            try:
                overlay = {key: _resolve_param(source, prev_output, objective) for key, source in step.parameter_mapping.items()}
            except SkillParameterResolutionError as exc:
                return self._error_outcome(
                    skill, records, started_at, now_fn(), step_index, ErrorType.INVALID_QUERY, str(exc), objective.objective_id
                )

            merged = {**base, **overlay}
            input_model_cls = PayloadRegistry.model_for(tool.definition.input_payload_type)
            try:
                validated = input_model_cls.model_validate(merged)
            except ValidationError as exc:
                return self._error_outcome(
                    skill, records, started_at, now_fn(), step_index, ErrorType.INVALID_QUERY,
                    f"parameter validation failed for step {step_index} ('{step.tool_id}'): {exc}",
                    objective.objective_id,
                )

            payload_in = PayloadRegistry.pack(tool.definition.input_payload_type, validated)
            identity = ToolExecutionIdentity(
                run_id=module_state.run_id,
                module_id=module_state.module_id,
                objective_id=objective.objective_id,
                skill_id=skill.skill_id,
                skill_step_id=f"{step_index}:{step.tool_id}",
                # ties physical replay-safety to the Planner's own retry
                # counter: re-running this exact objective (a checkpoint
                # replay) reuses the cached result, but a genuinely new
                # attempt at the same objective_id (Objective.attempt_count
                # bumped) gets a distinct idempotency_key and actually
                # re-executes -- see test_tool_execution_manager_in_skill_runner.py
                logical_attempt=objective.attempt_count or 1,
            )
            tool_call_id = f"{module_state.module_id}-{objective.objective_id}-{skill.skill_id}-step{step_index}"
            step_started = now_fn()

            outcome = self._execution_manager.execute(
                tool, identity, payload_in, tool_call_id=tool_call_id, started_at=step_started, completed_at_fn=now_fn
            )
            records.append(outcome.record)

            if outcome.result.status != ObservationStatus.SUCCESS:
                completed_at = now_fn()
                error = ErrorRecord(
                    error_type=outcome.result.error_type or ErrorType.TOOL_ERROR,
                    message=outcome.result.error_message or f"step {step_index} ('{step.tool_id}') failed",
                    objective_id=objective.objective_id,
                    occurred_at_step=step_index,
                )
                return SkillRunOutcome(
                    SkillExecutionResult(
                        skill_id=skill.skill_id,
                        status=SkillExecutionStatus.ERROR,
                        tool_call_ids=[r.tool_call_id for r in records],
                        summary=f"skill '{skill.skill_id}' failed at step {step_index} ('{step.tool_id}')",
                        error=error,
                        started_at=started_at,
                        completed_at=completed_at,
                    ),
                    records,
                )

            result_payload = outcome.result.payload
            last_tool_summary = outcome.result.summary
            prev_output = PayloadRegistry.unpack(result_payload)

        completed_at = now_fn()
        # prefer the last step's own human-readable summary (what a Tool
        # actually found) over the generic "completed N step(s)" fallback --
        # see the Phase 5C-1 finding in agent/tools/models.py's
        # ToolExecutionResult.summary docstring
        summary = last_tool_summary or f"skill '{skill.skill_id}' completed {len(skill.steps)} step(s)"
        return SkillRunOutcome(
            SkillExecutionResult(
                skill_id=skill.skill_id,
                status=SkillExecutionStatus.SUCCESS,
                output_payload=result_payload,
                summary=summary,
                tool_call_ids=[r.tool_call_id for r in records],
                started_at=started_at,
                completed_at=completed_at,
            ),
            records,
        )

    @staticmethod
    def _error_outcome(skill, records, started_at, completed_at, step_index, error_type, message, objective_id) -> SkillRunOutcome:
        return SkillRunOutcome(
            SkillExecutionResult(
                skill_id=skill.skill_id,
                status=SkillExecutionStatus.ERROR,
                tool_call_ids=[r.tool_call_id for r in records],
                summary=f"skill '{skill.skill_id}' failed at step {step_index}",
                error=ErrorRecord(error_type=error_type, message=message, objective_id=objective_id, occurred_at_step=step_index),
                started_at=started_at,
                completed_at=completed_at,
            ),
            records,
        )
