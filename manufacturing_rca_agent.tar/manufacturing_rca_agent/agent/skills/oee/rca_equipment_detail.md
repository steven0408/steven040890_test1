---
skill_id: oee.rca_equipment_detail
name: RCA Equipment Detail Query
description: Fetch downtime/failure detail for one equipment, for OEEPlanningPolicy's deep-dive step.
domains: [oee]
category: query
required_tools: [query_equipment_detail]
optional_tools: []
steps:
  - tool_id: query_equipment_detail
    parameter_mapping:
      target: objective.target_ref.ref_id
input_contract: EquipmentDetailQueryInput
output_contract: EquipmentDetail
risk_level: low
version: "1"
task_types: [rca]
actions: [equipment_detail]
---

# Skill: RCA Equipment Detail Query

## Goal

A single-step wrapper around `query_equipment_detail` for the RCA TaskType's
deep-dive objectives (`equipment_detail:<equipment_id>`) -- `OEEPlanningPolicy`
decides which equipment to deep-dive and reads the resulting
`EquipmentDetail` evidence exactly as it did before Phase 5B-2.

## Procedure

1. Call `query_equipment_detail` with the Objective's own target
   (`equipment_detail:<equipment_id>`) -- the Tool itself parses out the
   equipment id.

## Output Contract

EquipmentDetail (agent.domain.oee.dataset) -- same shape `OEEDataTool`
has always produced for `equipment_detail:<id>` targets.
