---
skill_id: oee.equipment_screening
name: Equipment Screening
description: Identify equipment whose OEE falls below the factory threshold.
domains: [oee]
category: screening
required_tools: [query_oee_data, filter_rows, calculate_contribution, ranking]
optional_tools: []
steps:
  - tool_id: query_oee_data
    parameter_mapping: {}
  - tool_id: filter_rows
    parameter_mapping:
      threshold: prev.threshold
  - tool_id: calculate_contribution
    parameter_mapping: {}
  - tool_id: ranking
    parameter_mapping: {}
input_contract: OEEQueryInput
output_contract: RankedScreeningResult
risk_level: low
version: "1"
task_types: [analysis]
actions: [equipment_screening]
---

# Skill: Equipment Screening

## Goal

Identify equipment whose OEE falls below the factory threshold.

## Required Inputs

- OEE threshold -- carried on `query_oee_data`'s own ScreeningResult output
  and threaded through the rest of the chain via `prev.threshold`, not a
  separate input.

## Procedure

1. Call `query_oee_data` to fetch A/P/Q/OEE for every equipment.
2. Call `filter_rows` (oee < threshold) to get the abnormal set.
3. Call `calculate_contribution` per equipment (abnormality x weight).
4. Call `ranking` to sort by contribution, grouped by worst dimension.

## Preferred Tools

query_oee_data, filter_rows, calculate_contribution, ranking

## Fallback

If `query_oee_data` returns DATA_NOT_FOUND, no fallback source exists at
this skill level -- Module Planner decides whether to retry, skip, or stop.

## Output Contract

RankedScreeningResult (agent.domain.oee.dataset) -- abnormal equipment only,
grouped by worst dimension, groups ranked by aggregate contribution. This is
the ANALYSIS TaskType's own output shape; it is not the same as the raw
ScreeningResult the RCA path's `oee.rca_screening` Skill still produces
unchanged.
