"""LLMPlanningPolicy (Phase 5C-2) -- the first LLM-backed `ModulePlanningPolicy`.
Implements the exact same Protocol `OEEPlanningPolicy`/`DeterministicMockPolicy`
already do (agent/planning/policies/base.py) -- no parallel contract, no
change to `module_planner.py` (the generic node stays oblivious to whether
its policy is deterministic or LLM-backed):

    Module Planner
        v
    ModulePlanningPolicy.propose_next_objective(module_state)
        v (LLMPlanningPolicy's own implementation)
    PlannerContextBuilder -> LLMRouter(route="planner") -> PlannerDecision
        v
    build_objective_from_proposal -> Objective

`is_sufficient` / `describe_finding` / `derive_state_updates` are NOT
LLM-driven this phase (per the Phase 5C-2 spec: the LLM only ever decides
DISPATCH/NO_VIABLE_OBJECTIVE + the next Objective's content) -- they
delegate straight to the wrapped `baseline_policy` (e.g. `OEEPlanningPolicy`),
unconditionally. Reflector's sufficiency judgement and Branch/EntityState/
Finding bookkeeping stay fully deterministic.

The wrapped baseline policy is also the fallback: on any LLM failure
(timeout / provider error / invalid structured output / semantic-invalid
output), `propose_next_objective` calls `baseline_policy.propose_next_objective`
directly and reports `DecisionSource.FALLBACK` -- never a bare exception,
never an unset Objective.
"""
from datetime import datetime, timezone
from typing import Callable

from agent.llm.context.planner_context import PlannerContextBuilder
from agent.llm.models import DecisionSource, LLMInvalidOutputError
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType, build_planner_messages
from agent.llm.router import LLMRouter, LLMRouterError
from agent.planning.decision_audit import PlannerDecisionAuditSink, PlannerDecisionRecord
from agent.planning.objective_factory import build_objective_from_proposal
from agent.planning.policies.base import DomainStateUpdates, FindingDescription, ModulePlanningPolicy
from agent.skills.registry import SkillRegistry
from agent.state.enums import ObjectiveAction, ObjectiveStatus, TargetRefType, TaskType
from agent.state.models import ModuleState, Objective
from agent.state.scope import TimeScopeKind


class PlannerSemanticValidationError(LLMInvalidOutputError):
    """A subclass, not a new sibling exception -- same reasoning as
    AnalyzerSemanticValidationError: LLMRouter's failure handling is
    isinstance-based, so this is treated exactly like the client producing
    invalid structured output (recorded INVALID_OUTPUT, retried, and once
    retries are exhausted, triggers LLMPlanningPolicy's fallback to the
    baseline policy). Pydantic schema validation alone cannot catch these --
    they are only true/false with respect to *this module's* current state
    and TaskType, not PlannerDecision's static shape."""


# TaskType-aware VERB allow-list (item 4/O's TaskType-aware depth rules):
# INFORMATION never gets a deep-dive/screening/comparison verb; ANALYSIS
# gets everything except the RCA-only deep-dive; RCA gets everything. Small
# and stable by design (Phase WB-2B.1 landed the design review's Option 2):
# unlike the old per-`ObjectiveAction`-member table this replaces, this
# does NOT grow by N entries per new domain -- a new domain's capabilities
# reuse these same 6 verbs. Public (not `_`-prefixed): Phase 5C-3's
# `agent.planning.decision_quality` reuses this exact table so the hard
# semantic gate and the soft quality evaluator can never silently disagree.
ALLOWED_ACTIONS_BY_TASK_TYPE: dict[TaskType, set[ObjectiveAction]] = {
    TaskType.INFORMATION: {ObjectiveAction.QUERY, ObjectiveAction.SUMMARIZE},
    TaskType.ANALYSIS: {ObjectiveAction.QUERY, ObjectiveAction.SUMMARIZE, ObjectiveAction.SCREEN, ObjectiveAction.COMPARE, ObjectiveAction.ANALYZE},
    TaskType.RCA: {
        ObjectiveAction.QUERY, ObjectiveAction.SUMMARIZE, ObjectiveAction.SCREEN,
        ObjectiveAction.COMPARE, ObjectiveAction.ANALYZE, ObjectiveAction.DRILL_DOWN,
    },
}

_TERMINAL_NO_RETRY_STATUSES = (ObjectiveStatus.COMPLETED, ObjectiveStatus.REJECTED)
_TIME_KIND_NAMES = {kind.value for kind in TimeScopeKind}


def _validate_scope(proposal: ObjectiveProposal, skill) -> None:
    """Phase WB-2B.1 item M points 5/6: every scope dimension the proposal
    supplies must be one this capability actually accepts (catches a
    hallucinated/wrong dimension the LLM invented), and every dimension
    this capability REQUIRES must actually be present -- checked here,
    before any Tool ever runs, not discovered mid-execution as a
    ValidationError inside SkillRunner."""
    scope = proposal.scope
    provided_filter_dims = {f.dimension for f in scope.filters} if scope is not None else set()
    provided_time_kind = scope.time.kind.value if scope is not None and scope.time is not None else None

    for dim in provided_filter_dims:
        if dim not in skill.accepted_scope_dimensions:
            raise PlannerSemanticValidationError(
                f"capability_key '{skill.capability_key}' does not accept scope dimension '{dim}' "
                f"(accepted: {sorted(skill.accepted_scope_dimensions)})"
            )
    # Phase WB-3F.1 item 34: group_by entries reuse the same
    # accepted_scope_dimensions set a Skill already declares for filters
    # (item 35's documented, deliberate reuse rather than a second parallel
    # "accepted_group_by_dimensions" concept) -- an LLM-proposed group_by
    # naming a dimension this capability has no notion of at all (e.g.
    # "product") is rejected here, before any Tool ever runs. A dimension
    # name that IS accepted here but isn't actually a real groupable
    # breakdown for a specific Tool (e.g. "customer" on a Tool that only
    # groups by plant/package/device) is the individual Tool's own
    # allow-list to reject -- see e.g. summarize_wb_bank_status's
    # `_BANK_ALLOWED_GROUP_BY` -- this coarser check only catches dimension
    # names meaningless to the capability at all.
    for dim in scope.group_by if scope is not None else []:
        if dim not in skill.accepted_scope_dimensions:
            raise PlannerSemanticValidationError(
                f"capability_key '{skill.capability_key}' does not accept group_by dimension '{dim}' "
                f"(accepted: {sorted(skill.accepted_scope_dimensions)})"
            )
    if provided_time_kind is not None and provided_time_kind not in skill.accepted_scope_dimensions:
        raise PlannerSemanticValidationError(
            f"capability_key '{skill.capability_key}' does not accept time scope '{provided_time_kind}' "
            f"(accepted: {sorted(skill.accepted_scope_dimensions)})"
        )

    for required_dim in skill.required_scope_dimensions:
        if required_dim in _TIME_KIND_NAMES:
            if provided_time_kind != required_dim:
                raise PlannerSemanticValidationError(
                    f"capability_key '{skill.capability_key}' requires scope.time.kind='{required_dim}', "
                    f"got {provided_time_kind!r}"
                )
        elif required_dim not in provided_filter_dims:
            raise PlannerSemanticValidationError(
                f"capability_key '{skill.capability_key}' requires scope filter dimension '{required_dim}', which is missing"
            )


def _validate_request_constraint_preservation(proposal: ObjectiveProposal, skill, module_state: ModuleState) -> None:
    """Phase WB-3F.4 item 19/20's own "minimal validation option" --
    deliberately the SAFELY DETERMINABLE subset only, not a full
    "every constraint must survive every Objective" rule (item 4/17: the
    Planner may legitimately broaden/narrow scope across rounds, and
    Python cannot safely judge "is this Request Constraint relevant to
    THIS Objective" once other evidence exists).

    The one case this file DOES check deterministically: for the FIRST
    Objective of a module (no `objective_history` yet -- nothing has
    narrowed/broadened anything, so an explicit, capability-accepted
    constraint is unambiguously relevant), every `source=USER_EXPLICIT`
    RequestConstraint whose dimension the chosen capability accepts must
    appear in `proposal.scope.filters`. Any LATER Objective is governed
    only by the Planner prompt's own guidance (agent/llm/prompts/
    planner.py's "Request Constraint preservation" block), not a hard
    validator -- reported honestly as a limitation in the completion
    report, not silently pretended to be fully covered."""
    if module_state.objective_history:
        return  # only the first Objective of a module is safely checkable

    explicit_dims_with_values = {
        c.dimension: c.value for c in module_state.goal.constraints if c.source.value == "user_explicit"
    }
    if not explicit_dims_with_values:
        return

    provided_filter_dims = {f.dimension for f in proposal.scope.filters} if proposal.scope is not None else set()
    for dimension in explicit_dims_with_values:
        if dimension not in skill.accepted_scope_dimensions:
            continue  # this capability has no notion of the dimension at all -- not this validator's concern (§35's own boundary)
        if dimension not in provided_filter_dims:
            raise PlannerSemanticValidationError(
                f"Request Constraint '{dimension}={explicit_dims_with_values[dimension]}' was explicitly stated by the user and is "
                f"accepted by capability_key '{skill.capability_key}', but the first Objective of this module omitted it from scope.filters"
            )


def validate_planner_decision(decision: PlannerDecision, *, module_state: ModuleState, task_type: TaskType, skill_registry: SkillRegistry) -> None:
    """Semantic validation beyond pydantic schema validation -- catches an
    LLM proposing a structurally-valid-but-nonsensical Objective: a target
    that doesn't exist in this module, an action this TaskType doesn't
    permit, an unknown/mismatched capability_key, a missing required scope
    dimension, or repeating an objective that's already been
    completed/rejected with no new justification.

    Canonical TargetRef only (Phase 5C-2.1): `action` alone says WHAT to
    do; `target_ref.ref_id` is bare WHO/WHAT (the module_type itself for a
    MODULE target, the bare entity id for an ENTITY target) -- never an
    action-prefixed compound string.

    `skill_registry` (Phase WB-2B.1): needed to look up the Skill a
    proposed `capability_key` refers to -- target-ref shape and scope
    requirements are now properties of the CAPABILITY (each Skill's own
    metadata), not a global per-verb table, since real WB evidence showed
    a single verb (e.g. SUMMARIZE) can legitimately be MODULE-wide for one
    capability and ENTITY-scoped for another.
    """
    if decision.decision == PlannerDecisionType.DISPATCH:
        if decision.next_objective is None:
            raise PlannerSemanticValidationError("decision=DISPATCH requires next_objective to be set")
    elif decision.next_objective is not None:
        raise PlannerSemanticValidationError("decision=NO_VIABLE_OBJECTIVE must not carry a next_objective")

    if decision.priority is not None and not (0.0 <= decision.priority <= 1.0):
        raise PlannerSemanticValidationError(f"priority out of range [0,1]: {decision.priority}")

    if decision.next_objective is None:
        return
    proposal = decision.next_objective

    allowed_actions = ALLOWED_ACTIONS_BY_TASK_TYPE.get(task_type, set())
    if proposal.action not in allowed_actions:
        raise PlannerSemanticValidationError(f"action '{proposal.action.value}' is not permitted for task_type '{task_type.value}'")

    if proposal.capability_key is None:
        raise PlannerSemanticValidationError(f"next_objective for action '{proposal.action.value}' must carry a capability_key")

    domain = module_state.module_type.lower()
    # Same (domain, task_type) narrowing CapabilityResolver itself applies
    # BEFORE matching on capability_key -- two Skills may legitimately
    # share one capability_key for different TaskTypes (e.g.
    # `oee.equipment_screening`'s ANALYSIS skill vs `oee.rca_screening`'s
    # RCA skill both carry capability_key="oee.equipment_screening"); this
    # narrowing is what keeps that from ever resolving to the wrong one.
    matching_skills = [
        s for s in skill_registry.list()
        if s.capability_key == proposal.capability_key
        and (not s.domains or domain in s.domains)
        and (not s.task_types or task_type in s.task_types)
    ]
    if not matching_skills:
        raise PlannerSemanticValidationError(
            f"capability_key '{proposal.capability_key}' does not match any registered Skill for "
            f"domain '{domain}'/task_type '{task_type.value}'"
        )
    skill = matching_skills[0]

    if proposal.action not in skill.actions:
        raise PlannerSemanticValidationError(f"capability_key '{proposal.capability_key}' does not support action '{proposal.action.value}'")

    expected_ref_type = skill.expected_target_ref_type
    if expected_ref_type is not None and proposal.target_ref.ref_type != expected_ref_type:
        raise PlannerSemanticValidationError(
            f"capability_key '{proposal.capability_key}' requires target_ref.ref_type={expected_ref_type.value}, got '{proposal.target_ref.ref_type.value}'"
        )

    if proposal.target_ref.ref_type == TargetRefType.MODULE and proposal.target_ref.ref_id != module_state.module_type:
        raise PlannerSemanticValidationError(
            f"MODULE target_ref.ref_id '{proposal.target_ref.ref_id}' does not match this module's own module_type '{module_state.module_type}'"
        )

    if proposal.target_ref.ref_type == TargetRefType.ENTITY and proposal.target_ref.ref_id not in module_state.entity_states:
        raise PlannerSemanticValidationError(
            f"target entity '{proposal.target_ref.ref_id}' does not exist in this module's entity_states -- possible hallucinated target"
        )

    _validate_scope(proposal, skill)
    _validate_request_constraint_preservation(proposal, skill, module_state)

    for record in module_state.objective_history.values():
        if (
            record.action == proposal.action
            and record.capability_key == proposal.capability_key
            and record.target_ref.ref_id == proposal.target_ref.ref_id
            and record.status in _TERMINAL_NO_RETRY_STATUSES
        ):
            raise PlannerSemanticValidationError(
                f"objective (action={proposal.action.value}, capability_key={proposal.capability_key}, "
                f"target={proposal.target_ref.ref_id}) was already {record.status.value} -- repeating it has no retry justification"
            )


def decision_from_objective(objective: Objective | None, *, rationale: str) -> PlannerDecision:
    """Public (not `_`-prefixed): the inverse of `build_objective_from_proposal`,
    used internally for fallback-path audit bookkeeping and reused by Phase
    5C-3's real-provider smoke tests to reconstruct a `PlannerDecision`-
    shaped value for `evaluate_planner_decision_quality` from an already-
    materialized `Objective` (propose_next_objective's own return type)."""
    if objective is None:
        return PlannerDecision(decision=PlannerDecisionType.NO_VIABLE_OBJECTIVE, rationale_summary=rationale, stop_candidate=True)
    proposal = ObjectiveProposal(
        action=objective.action,
        capability_key=objective.capability_key,
        target_ref=objective.target_ref,
        scope=objective.scope,
        description=objective.description,
        expected_output=objective.expected_output,
        requires_permission=objective.requires_permission,
        risk_level=objective.risk_level,
        permission_type=objective.permission_type,
    )
    return PlannerDecision(decision=PlannerDecisionType.DISPATCH, next_objective=proposal, priority=objective.priority_score, rationale_summary=rationale)


class LLMPlanningPolicy:
    def __init__(
        self,
        baseline_policy: ModulePlanningPolicy,
        context_builder: PlannerContextBuilder,
        router: LLMRouter,
        skill_registry: SkillRegistry,
        *,
        route: str = "planner",
        decision_audit_sink: PlannerDecisionAuditSink | None = None,
        now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    ):
        self._baseline = baseline_policy
        self._context_builder = context_builder
        self._router = router
        self._skill_registry = skill_registry
        self._route = route
        self._decision_audit_sink = decision_audit_sink
        self._now_fn = now_fn

    def propose_next_objective(self, module_state: ModuleState) -> Objective | None:
        step = len(module_state.objective_history) + 1
        task_type = module_state.goal.task_type

        context_outcome = self._context_builder.build(module_state, run_id=module_state.run_id, node="module_planner")
        messages = build_planner_messages(context_outcome.context)

        def _validate(decision: PlannerDecision) -> None:
            validate_planner_decision(decision, module_state=module_state, task_type=task_type, skill_registry=self._skill_registry)

        objective: Objective | None
        try:
            router_outcome = self._router.call(
                self._route,
                messages,
                PlannerDecision,
                run_id=module_state.run_id,
                module_id=module_state.module_id,
                node="module_planner",
                validate=_validate,
            )
            decision = router_outcome.parsed_output
            source, fallback_reason, llm_call_id = DecisionSource.LLM, None, router_outcome.call_record.llm_call_id
            objective = (
                build_objective_from_proposal(module_state, decision.next_objective, decision.priority)
                if decision.decision == PlannerDecisionType.DISPATCH
                else None
            )
        except LLMRouterError as exc:
            objective = self._baseline.propose_next_objective(module_state)
            decision = decision_from_objective(objective, rationale="Deterministic fallback (baseline policy).")
            source, fallback_reason, llm_call_id = DecisionSource.FALLBACK, str(exc), None

        if self._decision_audit_sink is not None:
            self._decision_audit_sink.record(
                PlannerDecisionRecord(
                    decision_record_id=f"{module_state.module_id}-decision-{step}",
                    run_id=module_state.run_id,
                    module_id=module_state.module_id,
                    step=step,
                    decision=decision.decision,
                    proposed_action=objective.action if objective is not None else None,
                    proposed_capability_key=objective.capability_key if objective is not None else None,
                    target_ref=objective.target_ref if objective is not None else None,
                    priority=decision.priority,
                    source=source,
                    rationale_summary=decision.rationale_summary,
                    context_build_record_id=context_outcome.record.context_build_record_id,
                    llm_call_id=llm_call_id,
                    fallback_reason=fallback_reason,
                    created_at=self._now_fn(),
                )
            )

        return objective

    # Not LLM-driven this phase -- delegate straight to the deterministic
    # baseline policy, unconditionally.
    def is_sufficient(self, module_state: ModuleState) -> bool:
        return self._baseline.is_sufficient(module_state)

    def describe_finding(self, module_state: ModuleState) -> FindingDescription:
        return self._baseline.describe_finding(module_state)

    def derive_state_updates(self, module_state: ModuleState) -> DomainStateUpdates:
        return self._baseline.derive_state_updates(module_state)
