"""OEEPlanningPolicy -- the first real domain policy (Phase 5A).

All OEE-specific intelligence (equipment screening, pattern grouping,
contribution ranking, branch selection, deep-dive depth) lives here.
Module Planner / Execution Gate / Module Executor / Module Reflector /
Module Completion Check are all unchanged from Phase 3/4B -- this plugs
into the exact same `ModulePlanningPolicy` protocol `DeterministicMockPolicy`
implements.

Flow this policy drives:

    screen_equipment
        -> abnormal set (OEE < threshold)
        -> group by worst dimension (Availability / Performance / Quality)
        -> rank groups by aggregate contribution
        -> deep-dive the top-contribution group's top-N equipment
           (by contribution, N = max_deep_dive_per_branch)
        -> stop once the top group has a confirmed root cause (or is
           exhausted) -- lower-ranked groups are left SCREENED, not
           chased down just because they exist.
"""
from agent.analysis.analysis_tree import AnalysisTreeNode
from agent.domain.oee.dataset import (
    CurrentOEEStatus,
    EquipmentDetail,
    EquipmentSnapshot,
    RankedScreeningResult,
    ScreeningResult,
    pattern_of,
)
from agent.planning.contribution import ContributionInputs, ContributionScorer, DefaultContributionScorer
from agent.planning.policies.base import DomainStateUpdates, FindingDescription
from agent.state.enums import BranchStatus, EntityAnalysisStatus, ObjectiveAction, TargetRefType, TaskType, TreeNodeStatus, TreeNodeType
from agent.state.models import Branch, EntityState, Evidence, ModuleState, Objective, TargetRef
from agent.state.payload import PayloadRegistry

_DIMENSION_LABELS = ("Availability", "Performance", "Quality")


def _target_of(evidence: Evidence) -> str:
    return evidence.source_tool.split(":", 1)[1]


class OEEPlanningPolicy:
    def __init__(
        self,
        contribution_scorer: ContributionScorer | None = None,
        max_deep_dive_per_branch: int = 2,
    ):
        self.contribution_scorer = contribution_scorer or DefaultContributionScorer()
        self.max_deep_dive_per_branch = max_deep_dive_per_branch

    # --- reading accumulated evidence (stateless, replayed every call) ----

    def _evidence_by_target(self, module_state: ModuleState) -> dict[str, Evidence]:
        return {_target_of(e): e for e in module_state.evidence}

    def _screening(self, module_state: ModuleState) -> ScreeningResult | None:
        ev = self._evidence_by_target(module_state).get("screen_equipment")
        if ev is None or ev.structured_payload is None:
            return None
        result = PayloadRegistry.unpack(ev.structured_payload)
        assert isinstance(result, ScreeningResult)
        return result

    def _detail(self, module_state: ModuleState, equipment_id: str) -> EquipmentDetail | None:
        ev = self._evidence_by_target(module_state).get(f"equipment_detail:{equipment_id}")
        if ev is None or ev.structured_payload is None:
            return None
        detail = PayloadRegistry.unpack(ev.structured_payload)
        assert isinstance(detail, EquipmentDetail)
        return detail

    def _was_attempted(self, module_state: ModuleState, equipment_id: str) -> bool:
        target = f"equipment_detail:{equipment_id}"
        return any(r.target_ref.ref_id == target for r in module_state.objective_history.values())

    def _contribution(self, snapshot: EquipmentSnapshot) -> float:
        return self.contribution_scorer.score(
            ContributionInputs(abnormality=1 - snapshot.oee, weight=snapshot.production_weight)
        )

    def _group_and_rank(self, screening: ScreeningResult) -> list[tuple[str, list[EquipmentSnapshot]]]:
        abnormal = [e for e in screening.equipment if e.oee < screening.threshold]
        groups: dict[str, list[EquipmentSnapshot]] = {}
        for snap in abnormal:
            groups.setdefault(pattern_of(snap), []).append(snap)
        ranked = []
        for pattern, members in groups.items():
            members_sorted = sorted(members, key=self._contribution, reverse=True)
            total = sum(self._contribution(m) for m in members)
            ranked.append((pattern, members_sorted, total))
        ranked.sort(key=lambda item: item[2], reverse=True)
        return [(pattern, members) for pattern, members, _total in ranked]

    def _make_objective(self, module_state: ModuleState, target: str, description: str) -> Objective:
        round_number = len(module_state.objective_history) + 1
        if target == "screen_equipment":
            ref_type, action = TargetRefType.MODULE, ObjectiveAction.EQUIPMENT_SCREENING
        elif target == "current_status":
            ref_type, action = TargetRefType.MODULE, ObjectiveAction.CURRENT_STATUS
        else:
            ref_type, action = TargetRefType.ENTITY, ObjectiveAction.EQUIPMENT_DETAIL
        return Objective(
            objective_id=f"{module_state.module_id}-obj-{round_number}",
            description=description,
            action=action,
            target_ref=TargetRef(ref_type=ref_type, ref_id=target),
            expected_output="oee analysis data",
            priority_score=1.0,
            attempt_count=round_number,
        )

    # --- INFORMATION / ANALYSIS TaskType support (Phase 5B-2) --------------
    #
    # These two stay deliberately shallow -- one objective, one round, no
    # deep dive -- and read/produce the capability layer's OWN structured
    # shapes (CurrentOEEStatus / RankedScreeningResult), never the raw
    # ScreeningResult the RCA branch below owns. TaskType is decided once at
    # module bootstrap and never changes mid-run, so there is no risk of a
    # module mixing branches; each of the three dispatch methods below
    # simply reads `module_state.goal.task_type` and delegates.

    def _current_status(self, module_state: ModuleState) -> CurrentOEEStatus | None:
        ev = self._evidence_by_target(module_state).get("current_status")
        if ev is None or ev.structured_payload is None:
            return None
        status = PayloadRegistry.unpack(ev.structured_payload)
        assert isinstance(status, CurrentOEEStatus)
        return status

    def _ranked_screening(self, module_state: ModuleState) -> RankedScreeningResult | None:
        ev = self._evidence_by_target(module_state).get("screen_equipment")
        if ev is None or ev.structured_payload is None:
            return None
        ranked = PayloadRegistry.unpack(ev.structured_payload)
        assert isinstance(ranked, RankedScreeningResult)
        return ranked

    def _propose_information(self, module_state: ModuleState) -> Objective | None:
        already_tried = any(r.target_ref.ref_id == "current_status" for r in module_state.objective_history.values())
        if already_tried:
            return None
        return self._make_objective(module_state, "current_status", "Get current OEE status")

    def _is_sufficient_information(self, module_state: ModuleState) -> bool:
        return self._current_status(module_state) is not None

    def _describe_finding_information(self, module_state: ModuleState) -> FindingDescription:
        status = self._current_status(module_state)
        if status is None:
            return FindingDescription(statement="Current OEE status not yet retrieved.", pattern="OEE Status")
        return FindingDescription(
            statement=(
                f"Average OEE across {status.equipment_count} equipment is {status.average_oee:.0%}; "
                f"worst is {status.worst_equipment_id} at {status.worst_oee:.0%}."
            ),
            pattern="OEE Status",
        )

    def _propose_analysis(self, module_state: ModuleState) -> Objective | None:
        already_tried = any(r.target_ref.ref_id == "screen_equipment" for r in module_state.objective_history.values())
        if already_tried:
            return None  # one screening round only -- ANALYSIS never deep-dives root cause
        return self._make_objective(
            module_state, "screen_equipment", "Screen and rank abnormal equipment"
        )

    def _is_sufficient_analysis(self, module_state: ModuleState) -> bool:
        return self._ranked_screening(module_state) is not None

    def _describe_finding_analysis(self, module_state: ModuleState) -> FindingDescription:
        ranked = self._ranked_screening(module_state)
        if ranked is None:
            return FindingDescription(statement="Equipment screening in progress.", pattern="OEE Screening")
        if not ranked.groups:
            return FindingDescription(
                statement="No abnormal equipment found below the OEE threshold.", pattern="OEE Screening"
            )
        top = ranked.groups[0]
        return FindingDescription(
            statement=(
                f"{top.pattern} loss is the dominant pattern among abnormal equipment "
                f"({', '.join(top.equipment_ids)}); root cause not investigated at this TaskType."
            ),
            pattern=f"{top.pattern} Loss",
            entity_ids=top.equipment_ids,
            is_root_cause=False,  # ANALYSIS never claims a confirmed root cause -- that's RCA-only
        )

    # --- ModulePlanningPolicy protocol -------------------------------------

    def propose_next_objective(self, module_state: ModuleState) -> Objective | None:
        task_type = module_state.goal.task_type
        if task_type == TaskType.INFORMATION:
            return self._propose_information(module_state)
        if task_type == TaskType.ANALYSIS:
            return self._propose_analysis(module_state)
        return self._propose_rca(module_state)

    def is_sufficient(self, module_state: ModuleState) -> bool:
        task_type = module_state.goal.task_type
        if task_type == TaskType.INFORMATION:
            return self._is_sufficient_information(module_state)
        if task_type == TaskType.ANALYSIS:
            return self._is_sufficient_analysis(module_state)
        return self._is_sufficient_rca(module_state)

    def describe_finding(self, module_state: ModuleState) -> FindingDescription:
        task_type = module_state.goal.task_type
        if task_type == TaskType.INFORMATION:
            return self._describe_finding_information(module_state)
        if task_type == TaskType.ANALYSIS:
            return self._describe_finding_analysis(module_state)
        return self._describe_finding_rca(module_state)

    # --- RCA (unchanged from Phase 5A -- dynamic screen -> group -> rank ->
    # selective deep-dive) --------------------------------------------------

    def _propose_rca(self, module_state: ModuleState) -> Objective | None:
        screening = self._screening(module_state)
        if screening is None:
            already_tried = any(
                r.target_ref.ref_id == "screen_equipment" for r in module_state.objective_history.values()
            )
            if already_tried:
                return None  # screening failed with no fallback source -- exhausted
            return self._make_objective(
                module_state, "screen_equipment", "Identify abnormal equipment (screen against OEE threshold)"
            )

        ranked = self._group_and_rank(screening)
        if not ranked:
            return None  # nothing abnormal

        top_pattern, top_equipment = ranked[0]
        cap = min(self.max_deep_dive_per_branch, len(top_equipment))
        for eq in top_equipment[:cap]:
            if self._was_attempted(module_state, eq.equipment_id):
                continue
            return self._make_objective(
                module_state,
                f"equipment_detail:{eq.equipment_id}",
                f"Deep-dive {eq.equipment_id} ({top_pattern} loss, contribution-ranked)",
            )
        return None  # top branch's allotted depth reached -- don't cascade into lower branches

    def _is_sufficient_rca(self, module_state: ModuleState) -> bool:
        screening = self._screening(module_state)
        if screening is None:
            return False
        ranked = self._group_and_rank(screening)
        if not ranked:
            return True  # nothing abnormal at all

        top_pattern, top_equipment = ranked[0]
        cap = min(self.max_deep_dive_per_branch, len(top_equipment))
        attempted = [eq for eq in top_equipment[:cap] if self._was_attempted(module_state, eq.equipment_id)]
        if len(attempted) < cap:
            return False  # haven't finished the top branch's allotted depth yet

        return any(
            (detail := self._detail(module_state, eq.equipment_id)) is not None and detail.failure_reason is not None
            for eq in top_equipment[:cap]
        )

    def _describe_finding_rca(self, module_state: ModuleState) -> FindingDescription:
        screening = self._screening(module_state)
        if screening is None:
            return FindingDescription(statement="OEE screening in progress.", pattern="OEE Screening")

        ranked = self._group_and_rank(screening)
        if not ranked:
            return FindingDescription(
                statement="No abnormal equipment found below the OEE threshold.", pattern="OEE Screening"
            )

        top_pattern, top_equipment = ranked[0]
        top_ids = [eq.equipment_id for eq in top_equipment]

        confirmed: dict[str, str] = {}
        for eq in top_equipment:
            detail = self._detail(module_state, eq.equipment_id)
            if detail is not None and detail.failure_reason is not None:
                confirmed[eq.equipment_id] = detail.failure_reason

        if not confirmed:
            return FindingDescription(
                statement=(
                    f"{top_pattern} loss confirmed as the dominant OEE pattern "
                    f"({', '.join(top_ids)}); root cause not yet verified."
                ),
                pattern=f"{top_pattern} Loss",
                entity_ids=top_ids,
            )

        by_reason: dict[str, list[str]] = {}
        for equipment_id, reason in confirmed.items():
            by_reason.setdefault(reason, []).append(equipment_id)
        reason, members = max(by_reason.items(), key=lambda kv: len(kv[1]))
        members = sorted(members)

        statement = (
            f"{top_pattern} loss confirmed for {', '.join(members)} -- shared root cause: {reason}."
            if len(members) > 1
            else f"{top_pattern} loss confirmed for {members[0]} -- root cause: {reason}."
        )
        return FindingDescription(
            statement=statement,
            pattern=f"{top_pattern} Loss: {reason}",
            entity_ids=members,
            is_root_cause=True,
        )

    def derive_state_updates(self, module_state: ModuleState) -> DomainStateUpdates:
        # Branch/EntityState/AnalysisTree bookkeeping below is RCA-specific
        # machinery built on top of the raw ScreeningResult -- INFORMATION
        # and ANALYSIS never deep-dive, so there is nothing for it to do
        # (and their "screen_equipment" evidence, when present, holds a
        # RankedScreeningResult, a different shape `_screening()` cannot
        # unpack as ScreeningResult).
        if module_state.goal.task_type != TaskType.RCA:
            return DomainStateUpdates()

        screening = self._screening(module_state)
        if screening is None:
            return DomainStateUpdates()
        ranked = self._group_and_rank(screening)
        if not ranked:
            return DomainStateUpdates()

        tree = module_state.analysis_tree.model_copy(deep=True)
        if "equipment" not in tree.nodes:
            tree.add_node(
                AnalysisTreeNode(
                    node_id="equipment", parent_id=tree.root_id, label="Equipment", node_type=TreeNodeType.DIMENSION
                )
            )

        branches: dict[str, Branch] = {}
        entity_states: dict[str, EntityState] = {}

        for rank, (pattern, members) in enumerate(ranked):
            branch_id = f"branch-{pattern.lower()}"
            branch_node_id = f"{branch_id}-node"
            if branch_node_id not in tree.nodes:
                tree.add_node(
                    AnalysisTreeNode(
                        node_id=branch_node_id, parent_id="equipment", label=f"{pattern} Loss", node_type=TreeNodeType.DIMENSION
                    )
                )

            member_ids = [eq.equipment_id for eq in members]
            for eq in members:
                eq_node_id = f"eq-{eq.equipment_id}"
                if eq_node_id not in tree.nodes:
                    tree.add_node(
                        AnalysisTreeNode(
                            node_id=eq_node_id,
                            parent_id=branch_node_id,
                            label=eq.equipment_id,
                            node_type=TreeNodeType.ENTITY,
                            entity_refs=[eq.equipment_id],
                        )
                    )

                detail = self._detail(module_state, eq.equipment_id)
                attempted = self._was_attempted(module_state, eq.equipment_id)
                if detail is not None and detail.failure_reason is not None:
                    status = EntityAnalysisStatus.ROOT_CAUSE_FOUND
                    if eq_node_id in tree.nodes:
                        tree.set_status(eq_node_id, TreeNodeStatus.COMPLETED)
                elif attempted:
                    status = EntityAnalysisStatus.INVESTIGATING
                    if eq_node_id in tree.nodes:
                        tree.set_status(eq_node_id, TreeNodeStatus.IN_PROGRESS)
                else:
                    status = EntityAnalysisStatus.SCREENED

                entity_states[eq.equipment_id] = EntityState(
                    entity_id=eq.equipment_id,
                    entity_type="EQUIPMENT",
                    depth=1 if attempted else 0,
                    status=status,
                    current_tree_node_id=eq_node_id,
                    branch_id=branch_id,
                    priority_score=self._contribution(eq),
                )

            branches[branch_id] = Branch(
                branch_id=branch_id,
                name=f"{pattern} Loss",
                pattern=pattern,
                entity_ids=member_ids,
                status=BranchStatus.ACTIVE if rank == 0 else BranchStatus.PENDING,
                priority_score=sum(self._contribution(m) for m in members),
                depth=1,
                tree_node_id=branch_node_id,
            )

        # collapse equipment that share a confirmed failure_reason under one
        # group node instead of leaving them as separate leaves.
        top_pattern, top_equipment = ranked[0]
        branch_node_id = f"branch-{top_pattern.lower()}-node"
        by_reason: dict[str, list[str]] = {}
        for eq in top_equipment:
            detail = self._detail(module_state, eq.equipment_id)
            if detail is not None and detail.failure_reason is not None:
                by_reason.setdefault(detail.failure_reason, []).append(eq.equipment_id)
        for reason, members in by_reason.items():
            if len(members) < 2:
                continue
            group_node_id = f"group-{reason.lower().replace(' ', '-')}"
            member_node_ids = [f"eq-{m}" for m in members]
            if group_node_id in tree.nodes:
                continue
            if all(n in tree.nodes and tree.nodes[n].parent_id == branch_node_id for n in member_node_ids):
                tree.merge_nodes(member_node_ids, into_label=f"Equipment Failure: {reason}", new_node_id=group_node_id)
                tree.set_status(group_node_id, TreeNodeStatus.COMPLETED)

        return DomainStateUpdates(branches=branches, entity_states=entity_states, analysis_tree=tree)
