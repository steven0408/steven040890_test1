"""Phase PROD-1: deployment configuration -- every field here is read from
an environment variable NAME, never a literal secret/host/credential value,
mirroring the exact discipline already established by
`agent.llm.providers.provider_config.LLMProviderConfig`,
`agent.datasource.models.DataSourceConfig`, and
`agent.persistence.postgres.config.PostgresSettings`. This module does not
invent a second config mechanism -- it composes those three existing ones
plus a handful of API-layer-only settings (CORS, request timeout, WB API
base URL, runtime debug DB URL).

`ApiSettings.from_env()` performs STRUCTURAL validation only (required env
vars are set, values parse) -- it never opens a network connection, never
calls the LLM, never contacts the WB API or either PostgreSQL database
(Phase PROD-1's own explicit "do not verify formal infrastructure" rule).
"""
import os
from dataclasses import dataclass, field

from agent.llm.providers.provider_config import LLMProviderConfig, LLMProviderConfigError

_DEFAULT_FACTORY_ID = "factory-a"
_DEFAULT_FACTORY_NAME = "Factory A"
_DEFAULT_MODULES = ["WB"]

_COGNITIVE_ROUTES = ["standardizer", "analyzer", "planner", "reflector", "synthesis"]


class ApiConfigError(RuntimeError):
    """A required piece of deployment configuration is missing or
    structurally invalid -- raised at startup, never mid-request."""


@dataclass(frozen=True)
class ApiSettings:
    llm_provider_config: LLMProviderConfig

    factory_id: str = _DEFAULT_FACTORY_ID
    factory_name: str = _DEFAULT_FACTORY_NAME
    enabled_modules: list[str] = field(default_factory=lambda: list(_DEFAULT_MODULES))

    # WB production DataSource profile: "in_memory" (default -- the frozen
    # synthetic dataset every offline test already uses) or "remote" (the
    # 5 RemoteWB*DataSource classes, agent/domain/wb/remote.py). Switching
    # requires only this env var + WB_API_BASE_URL -- no Tool/Skill/Policy
    # code changes (see agent/domain/wb/remote.py::build_remote_wb_datasources).
    wb_datasource_profile: str = "in_memory"
    wb_api_base_url_env: str = "WB_API_BASE_URL"

    # Optional runtime/debug event PostgreSQL -- deliberately a single DSN
    # env var (not the PostgresSettings host/port/db/user/password-as-
    # separate-env-var-name shape) because this is a distinct, optional,
    # best-effort observability database, not the Agent's own Run
    # persistence layer (agent/persistence/postgres, unchanged/reused as-is
    # for actual analysis persistence when configured separately via
    # AppConfig.persistence). Never required for the Agent to start.
    runtime_db_url_env: str = "AGENT_RUNTIME_DB_URL"

    cors_allow_origins: list[str] = field(default_factory=list)
    request_timeout_seconds: float | None = None

    @classmethod
    def from_env(cls) -> "ApiSettings":
        try:
            llm_provider_config = LLMProviderConfig.from_env()
        except LLMProviderConfigError as exc:
            raise ApiConfigError(f"LLM configuration is invalid or incomplete: {exc}") from exc

        wb_datasource_profile = os.environ.get("WB_DATASOURCE_PROFILE", "in_memory").strip().lower()
        if wb_datasource_profile not in ("in_memory", "remote"):
            raise ApiConfigError(f"WB_DATASOURCE_PROFILE={wb_datasource_profile!r} must be 'in_memory' or 'remote'")
        if wb_datasource_profile == "remote" and not os.environ.get("WB_API_BASE_URL"):
            raise ApiConfigError("WB_DATASOURCE_PROFILE=remote requires WB_API_BASE_URL to be set")

        factory_id = os.environ.get("AGENT_FACTORY_ID", _DEFAULT_FACTORY_ID)
        factory_name = os.environ.get("AGENT_FACTORY_NAME", _DEFAULT_FACTORY_NAME)
        enabled_modules = _split_csv(os.environ.get("AGENT_ENABLED_MODULES"), default=_DEFAULT_MODULES)
        cors_origins = _split_csv(os.environ.get("AGENT_CORS_ALLOW_ORIGINS"), default=[])

        timeout_raw = os.environ.get("AGENT_REQUEST_TIMEOUT_SECONDS")
        request_timeout_seconds = float(timeout_raw) if timeout_raw else None

        return cls(
            llm_provider_config=llm_provider_config,
            factory_id=factory_id,
            factory_name=factory_name,
            enabled_modules=enabled_modules,
            wb_datasource_profile=wb_datasource_profile,
            request_timeout_seconds=request_timeout_seconds,
            cors_allow_origins=cors_origins,
        )

    def llm_routes(self) -> dict:
        """Every cognitive node's route, all served by the one configured
        LLM client -- see LLMProviderConfig.build_routes's own docstring
        for why (one LLMClient/model per RuntimeContext today)."""
        return self.llm_provider_config.build_routes(_COGNITIVE_ROUTES)

    def runtime_db_url(self) -> str | None:
        """Resolves the runtime-event debug DB's DSN from the env var this
        settings object *names* (`runtime_db_url_env`) -- never stores the
        value itself. Returns None (not an error) when unset -- runtime
        event persistence is optional, see agent_api/runtime_events.py."""
        return os.environ.get(self.runtime_db_url_env)

    def is_mock_llm(self) -> bool:
        return self.llm_provider_config.provider == "mock"


def _split_csv(raw: str | None, *, default: list[str]) -> list[str]:
    if not raw:
        return list(default)
    return [item.strip() for item in raw.split(",") if item.strip()]
