"""Phase 5C-1: PlannerContext built from real OEE Module ReAct Subgraph
runs (capability-routed, same Harness as Phase 5B-2/5B-2.1) -- proves
TaskType-aware depth against genuine ModuleState snapshots, not
hand-crafted fixtures that might not match what the real Harness produces.
"""
from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
from agent.llm.context.evidence_selector import DeterministicEvidenceSelector
from agent.llm.context.planner_context import PlannerContextBuilder
from agent.state.enums import EntityAnalysisStatus, ModuleStatus, ObjectiveAction, TaskType

from .conftest import make_oee_skill_registry, run_oee_module_state_history


def _builder() -> PlannerContextBuilder:
    return PlannerContextBuilder(DeterministicEvidenceSelector(), DeterministicCapabilityRetriever(make_oee_skill_registry()))


# ============================================================================
# INFORMATION -- minimal context
# ============================================================================


def test_information_context_is_minimal_and_excludes_rca_machinery():
    history = run_oee_module_state_history(TaskType.INFORMATION)
    final_state = history[-1]
    assert final_state.status == ModuleStatus.COMPLETE

    outcome = _builder().build(final_state, run_id="run-ctx")
    context = outcome.context

    assert context.goal.task_type == TaskType.INFORMATION
    assert context.current_state.active_branches == []
    assert context.current_state.open_hypotheses == []
    assert context.current_state.relevant_entity_states == []
    assert context.relevant_knowledge == []  # INFORMATION's default budget is 0 knowledge items

    # only the current-status skill -- no RCA deep-dive / screening skill
    skill_ids = {s.skill_id for s in context.relevant_capabilities}
    assert skill_ids == {"oee.current_status"}

    assert 1 <= len(context.relevant_evidence) <= 2
    assert len(context.model_dump_json()) < 3500  # small context, matches the INFORMATION budget preset


# ============================================================================
# ANALYSIS -- rankings/evidence, no RCA failure-hypothesis context
# ============================================================================


def test_analysis_context_includes_screening_not_rca_deep_dive():
    history = run_oee_module_state_history(TaskType.ANALYSIS)
    final_state = history[-1]
    assert final_state.status == ModuleStatus.COMPLETE

    outcome = _builder().build(final_state, run_id="run-ctx")
    context = outcome.context

    assert context.goal.task_type == TaskType.ANALYSIS
    assert context.current_state.open_hypotheses == []  # ANALYSIS never does root-cause hypothesis testing

    skill_ids = {s.skill_id for s in context.relevant_capabilities}
    assert skill_ids == {"oee.equipment_screening"}  # not oee.rca_screening / oee.rca_equipment_detail

    assert len(context.relevant_evidence) >= 1
    assert context.current_state.top_findings  # the screening finding is present
    assert all(not f.is_root_cause for f in context.current_state.top_findings)  # ANALYSIS never claims root cause


# ============================================================================
# RCA -- mid-run: screening done, Availability top branch active, EQ001
# already investigated, EQ003 not yet
# ============================================================================


def _find_mid_rca_snapshot(history):
    candidates = [
        snapshot
        for snapshot in history
        if len(snapshot.objective_history) == 2 and any(e.objective_id == "OEE-obj-2" for e in snapshot.evidence)
    ]
    assert candidates, "expected a snapshot with EQ001 investigated but EQ003 not yet dispatched"
    return candidates[-1]


def test_rca_mid_run_context_includes_active_branch_and_eq001_excludes_unrelated():
    history = run_oee_module_state_history(TaskType.RCA)
    mid_state = _find_mid_rca_snapshot(history)

    # sanity on the fixture itself, matching the scenario description
    targets = [r.target_ref.ref_id for r in mid_state.objective_history.values()]
    assert targets == ["screen_equipment", "equipment_detail:EQ001"]
    assert mid_state.branches["branch-availability"].status.value == "active"

    outcome = _builder().build(mid_state, run_id="run-ctx")
    context = outcome.context

    assert context.goal.task_type == TaskType.RCA
    branch_ids = {b.branch_id for b in context.current_state.active_branches}
    assert branch_ids == {"branch-availability"}  # only the active branch, not Performance/Quality (still PENDING)

    entity_ids = {e.entity_id for e in context.current_state.relevant_entity_states}
    assert entity_ids <= {"EQ001", "EQ003", "EQ012"}  # Availability branch members only
    assert "EQ009" not in entity_ids  # Quality-branch equipment -- unrelated to the active branch

    evidence_summaries = " ".join(e.summary for e in context.relevant_evidence)
    assert "EQ001" in evidence_summaries or "Motor Failure" in evidence_summaries
    assert "Calibration" not in evidence_summaries  # Quality-pattern equipment's failure reason -- never investigated yet, must not leak in

    skill_ids = {s.skill_id for s in context.relevant_capabilities}
    assert skill_ids <= {"oee.rca_screening", "oee.rca_equipment_detail"}
    assert not (skill_ids & {"oee.equipment_screening", "oee.current_status"})

    assert context.budget.steps_remaining > 0
