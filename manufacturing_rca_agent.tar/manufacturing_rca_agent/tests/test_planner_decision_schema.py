"""Phase 5C-1: PlannerDecision / ObjectiveProposal typed output contract --
defined ahead of Phase 5C-2's Mock LLM Planner. Structurally cannot carry a
tool_id/skill_id/SQL/Python code/final RCA answer.
"""
import pytest
from pydantic import ValidationError

from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.state.enums import ObjectiveAction, TargetRefType
from agent.state.models import TargetRef


def test_objective_proposal_field_set_is_closed():
    assert set(ObjectiveProposal.model_fields.keys()) == {
        "action", "target_ref", "description", "expected_output", "requires_permission", "risk_level", "permission_type",
    }


def test_planner_decision_field_set_is_closed():
    assert set(PlannerDecision.model_fields.keys()) == {
        "decision", "next_objective", "priority", "rationale_summary", "stop_candidate",
    }


@pytest.mark.parametrize("forbidden_field", ["tool_id", "skill_id", "sql", "python_code", "final_answer", "root_cause_conclusion"])
def test_planner_decision_rejects_tool_skill_sql_code_and_final_answer_fields(forbidden_field):
    raw = {
        "decision": "dispatch",
        "next_objective": {
            "action": "equipment_screening",
            "target_ref": {"ref_type": "module", "ref_id": "screen_equipment"},
            "description": "screen",
            "expected_output": "abnormal equipment list",
        },
        "rationale_summary": "x",
        forbidden_field: "should never be accepted",
    }
    with pytest.raises(ValidationError):
        PlannerDecision.model_validate(raw)


@pytest.mark.parametrize("forbidden_field", ["tool_id", "skill_id", "sql", "python_code"])
def test_objective_proposal_rejects_tool_skill_sql_code_fields(forbidden_field):
    raw = {
        "action": "equipment_screening",
        "target_ref": {"ref_type": "module", "ref_id": "screen_equipment"},
        "description": "screen",
        "expected_output": "abnormal equipment list",
        forbidden_field: "should never be accepted",
    }
    with pytest.raises(ValidationError):
        ObjectiveProposal.model_validate(raw)


def test_valid_dispatch_decision_round_trips():
    decision = PlannerDecision(
        decision=PlannerDecisionType.DISPATCH,
        next_objective=ObjectiveProposal(
            action=ObjectiveAction.EQUIPMENT_DETAIL,
            target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="EQ001"),
            description="Deep-dive EQ001",
            expected_output="failure reason",
        ),
        priority=0.9,
        rationale_summary="Top Availability-loss equipment, contribution-ranked.",
    )
    restored = PlannerDecision.model_validate_json(decision.model_dump_json())
    assert restored == decision


def test_no_viable_objective_decision_has_no_next_objective():
    decision = PlannerDecision(decision=PlannerDecisionType.NO_VIABLE_OBJECTIVE, rationale_summary="Budget exhausted.", stop_candidate=True)
    assert decision.next_objective is None
    assert decision.stop_candidate is True
