"""Phase 5B-2: the full capability-routed path --
`Objective -> Executor -> CapabilityResolver -> Skill -> SkillRunner ->
ToolExecutionManager -> ToolRegistry -> Tool` -- exercised through the same
Module ReAct Subgraph harness as Phase 3/4A/5A (build_module_react_subgraph),
now wired with `capability=` instead of `tool=`.

Backward-compat requirement (explicit): the RCA COMPLETE/PARTIAL/FAILED
scenarios reproduce test_oee_planning_policy.py's Phase 5A outcomes exactly
-- OEEPlanningPolicy itself is unchanged for TaskType.RCA, and the RCA-only
`oee.rca_screening`/`oee.rca_equipment_detail` Skills are single-step
wrappers that reproduce OEEDataTool's exact query semantics.
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD, CurrentOEEStatus, RankedScreeningResult
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.planning.policies.mock import DeterministicMockPolicy
from agent.planning.policies.oee import OEEPlanningPolicy
from agent.skills.runner import SkillRunner
from agent.skills.models import SkillExecutionStatus
from agent.state.enums import (
    BranchStatus,
    EntityAnalysisStatus,
    ErrorType,
    FindingStatus,
    ModuleStatus,
    ObjectiveAction,
    ObjectiveStatus,
    ObservationStatus,
    ReflectorVerdict,
    TargetRefType,
    TaskType,
    TreeNodeStatus,
)
from agent.state.models import ModuleState, ModuleTask, Objective, TargetRef
from agent.state.payload import PayloadRegistry, StructuredPayload
from agent.tools.execution_manager import ToolExecutionManager
from agent.tools.models import ToolExecutionResult

from .conftest import make_budget, make_module_state, make_oee_capability_runtime, make_oee_skill_registry, make_oee_tool_registry


def _run(runtime, module_id, *, task_type=TaskType.RCA, budget=None):
    policy = OEEPlanningPolicy()
    graph = build_module_react_subgraph(policy, capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id=module_id, module_type="OEE", reason="test", confidence=0.9, priority=0.9)
    initial = build_initial_module_state(
        task, budget or make_budget(max_steps=6, max_tool_calls=20, max_depth_per_entity=3), run_id="run-1", task_type=task_type
    )
    config = {"configurable": {"thread_id": f"cap-{module_id}"}}
    result = app.invoke(initial, config=config)
    return ModuleState.model_validate(result)


# ============================================================================
# RCA -- backward compatibility with Phase 5A (test_oee_planning_policy.py)
# ============================================================================


def test_rca_complete_deep_dives_top_two_availability_equipment_and_finds_shared_cause():
    runtime = make_oee_capability_runtime(MOCK_EQUIPMENT, OEE_THRESHOLD)
    final_state = _run(runtime, "cap-complete")

    assert final_state.status == ModuleStatus.COMPLETE
    targets = [record.target_ref.ref_id for record in final_state.objective_history.values()]
    assert targets == ["screen_equipment", "equipment_detail:EQ001", "equipment_detail:EQ003"]
    assert all(r.status == ObjectiveStatus.COMPLETED for r in final_state.objective_history.values())
    assert [r.verdict for r in final_state.reflection_history] == [
        ReflectorVerdict.CONTINUE,
        ReflectorVerdict.CONTINUE,
        ReflectorVerdict.CANDIDATE_COMPLETE,
    ]

    final_finding = final_state.findings[-1]
    assert final_finding.status == FindingStatus.CONFIRMED
    assert final_finding.is_root_cause is True
    assert set(final_finding.entity_ids) == {"EQ001", "EQ003"}
    assert "Motor Failure" in final_finding.pattern

    availability = final_state.branches["branch-availability"]
    assert availability.status == BranchStatus.ACTIVE
    assert set(availability.entity_ids) == {"EQ001", "EQ003", "EQ012"}

    entities = final_state.entity_states
    assert entities["EQ001"].status == EntityAnalysisStatus.ROOT_CAUSE_FOUND
    assert entities["EQ003"].status == EntityAnalysisStatus.ROOT_CAUSE_FOUND
    assert entities["EQ012"].status == EntityAnalysisStatus.SCREENED

    tree = final_state.analysis_tree
    group_node = tree.nodes["group-motor-failure"]
    assert group_node.status == TreeNodeStatus.COMPLETED
    assert set(group_node.children_ids) == {"eq-EQ001", "eq-EQ003"}

    # per-step ToolCallRecord audit: 3 objectives, 1 tool call each (RCA
    # single-step skills), all through ToolExecutionManager
    assert len(final_state.tool_calls) == 3
    assert [tc.tool_id for tc in final_state.tool_calls] == ["query_oee_data", "query_equipment_detail", "query_equipment_detail"]
    assert all(tc.skill_id is not None for tc in final_state.tool_calls)


def test_rca_partial_when_availability_confirmed_but_downtime_detail_unavailable():
    runtime = make_oee_capability_runtime(
        MOCK_EQUIPMENT, OEE_THRESHOLD, detail_unavailable_targets=frozenset({"equipment_detail:EQ001", "equipment_detail:EQ003"})
    )
    final_state = _run(runtime, "cap-partial")

    assert final_state.status == ModuleStatus.PARTIAL
    assert len(final_state.findings) == 1
    finding = final_state.findings[0]
    assert finding.status == FindingStatus.HYPOTHESIS
    assert "Availability" in finding.pattern
    assert set(finding.entity_ids) == {"EQ001", "EQ003", "EQ012"}
    assert finding.is_root_cause is False
    assert final_state.entity_states["EQ001"].status == EntityAnalysisStatus.INVESTIGATING
    assert final_state.entity_states["EQ003"].status == EntityAnalysisStatus.INVESTIGATING
    assert len(final_state.limitations) == 1
    assert final_state.current_objective is None


def test_rca_failed_when_screening_itself_is_unavailable():
    runtime = make_oee_capability_runtime(MOCK_EQUIPMENT, OEE_THRESHOLD, query_unavailable=True)
    final_state = _run(runtime, "cap-failed")

    assert final_state.status == ModuleStatus.FAILED
    assert final_state.findings == []
    assert final_state.branches == {}
    assert final_state.entity_states == {}
    assert len(final_state.limitations) == 1
    assert len(final_state.objective_history) == 1
    assert final_state.objective_history["cap-failed-obj-1"].status == ObjectiveStatus.COMPLETED
    assert final_state.objective_history["cap-failed-obj-1"].termination_reason == "observation_error_retry"


def test_rca_final_state_round_trips_through_json():
    runtime = make_oee_capability_runtime(MOCK_EQUIPMENT, OEE_THRESHOLD)
    final_state = _run(runtime, "cap-json")
    restored = ModuleState.model_validate_json(final_state.model_dump_json())
    assert restored == final_state


# ============================================================================
# INFORMATION -- get current OEE status, no deep dive
# ============================================================================


def test_information_task_type_gets_current_status_without_deep_dive():
    runtime = make_oee_capability_runtime(MOCK_EQUIPMENT, OEE_THRESHOLD)
    final_state = _run(
        runtime, "cap-info", task_type=TaskType.INFORMATION, budget=make_budget(max_steps=6, max_tool_calls=10, max_depth_per_entity=2)
    )

    assert final_state.status == ModuleStatus.COMPLETE
    assert len(final_state.objective_history) == 1
    only_record = next(iter(final_state.objective_history.values()))
    assert only_record.target_ref.ref_id == "current_status"

    assert [tc.tool_id for tc in final_state.tool_calls] == ["query_oee_data", "aggregate_oee_status"]

    evidence = final_state.evidence[0]
    status = PayloadRegistry.unpack(evidence.structured_payload)
    assert isinstance(status, CurrentOEEStatus)
    assert status.equipment_count == len(MOCK_EQUIPMENT)
    assert status.worst_equipment_id == "EQ009"  # lowest OEE in the mock dataset (Quality-dominant loss)


# ============================================================================
# ANALYSIS -- screen and rank, no root-cause dive
# ============================================================================


def test_analysis_task_type_screens_and_ranks_without_root_cause_dive():
    runtime = make_oee_capability_runtime(MOCK_EQUIPMENT, OEE_THRESHOLD)
    final_state = _run(
        runtime, "cap-analysis", task_type=TaskType.ANALYSIS, budget=make_budget(max_steps=6, max_tool_calls=10, max_depth_per_entity=2)
    )

    assert final_state.status == ModuleStatus.COMPLETE
    assert len(final_state.objective_history) == 1
    only_record = next(iter(final_state.objective_history.values()))
    assert only_record.target_ref.ref_id == "screen_equipment"

    assert [tc.tool_id for tc in final_state.tool_calls] == ["query_oee_data", "filter_rows", "calculate_contribution", "ranking"]

    evidence = final_state.evidence[0]
    ranked = PayloadRegistry.unpack(evidence.structured_payload)
    assert isinstance(ranked, RankedScreeningResult)
    assert ranked.groups[0].pattern == "Availability"
    assert set(ranked.groups[0].equipment_ids) == {"EQ001", "EQ003", "EQ012"}

    # never claims a confirmed root cause -- that's RCA-only
    finding = final_state.findings[-1]
    assert finding.is_root_cause is False
    # no equipment-level EntityState/Branch bookkeeping was created --
    # ANALYSIS doesn't run the RCA deep-dive machinery at all
    assert final_state.entity_states == {}
    assert final_state.branches == {}


# ============================================================================
# Capability resolution failure -- typed error, ERROR Observation, no Human
# ============================================================================


def test_capability_resolution_failure_produces_error_observation_and_no_human_interrupt():
    runtime = make_oee_capability_runtime(MOCK_EQUIPMENT, OEE_THRESHOLD)
    policy = DeterministicMockPolicy(sources=["unsupported_target"], sufficiency_evidence_count=1)
    graph = build_module_react_subgraph(policy, capability=runtime)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id="cap-nf", module_type="OEE", reason="test", confidence=0.9, priority=0.9)
    initial = build_initial_module_state(task, make_budget(max_steps=3, max_tool_calls=5, max_depth_per_entity=2), run_id="run-1")
    config = {"configurable": {"thread_id": "cap-nf"}}

    result = app.invoke(initial, config=config)
    assert "__interrupt__" not in result  # never routes to Human

    final_state = ModuleState.model_validate(result)
    assert final_state.status == ModuleStatus.FAILED  # no findings ever gathered
    assert final_state.observations[0].status == ObservationStatus.ERROR
    assert final_state.observations[0].error.error_type == ErrorType.CAPABILITY_NOT_FOUND
    assert final_state.tool_calls == []  # resolution failed before any physical Tool call


# ============================================================================
# SkillRunner in isolation -- typed StructuredPayload round-trip through the
# full query -> filter -> contribution -> ranking chain
# ============================================================================


def test_skill_runner_chains_typed_payloads_through_equipment_screening():
    tool_registry = make_oee_tool_registry(MOCK_EQUIPMENT, OEE_THRESHOLD)
    skill_registry = make_oee_skill_registry()
    skill = skill_registry.get("oee.equipment_screening")

    runner = SkillRunner(tool_registry, ToolExecutionManager())
    objective = Objective(
        objective_id="o1", description="screen", action=ObjectiveAction.EQUIPMENT_SCREENING,
        target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="screen_equipment"),
        expected_output="x", priority_score=1.0, attempt_count=1,
    )
    module_state = make_module_state()

    outcome = runner.run(skill, objective, module_state)

    assert outcome.result.status == SkillExecutionStatus.SUCCESS
    assert [r.tool_id for r in outcome.tool_call_records] == ["query_oee_data", "filter_rows", "calculate_contribution", "ranking"]

    ranked = PayloadRegistry.unpack(outcome.result.output_payload)
    assert isinstance(ranked, RankedScreeningResult)
    assert ranked.groups[0].pattern == "Availability"

    # round-trips through JSON -- the envelope itself, not just the unpacked model
    restored = StructuredPayload.model_validate_json(outcome.result.output_payload.model_dump_json())
    assert restored == outcome.result.output_payload
    assert PayloadRegistry.unpack(restored) == ranked


# ============================================================================
# ToolExecutionManager in the production (SkillRunner) path -- replay dedup
# vs. genuine retry, not just the isolated unit test in
# test_tool_execution_manager.py
# ============================================================================


class _SpyCapabilityTool:
    def __init__(self, inner, counters: dict, label: str):
        self.inner = inner
        self.counters = counters
        self.label = label
        self.definition = inner.definition

    def run(self, request) -> ToolExecutionResult:
        self.counters[self.label] = self.counters.get(self.label, 0) + 1
        return self.inner.run(request)


def test_tool_execution_manager_dedups_replay_but_allows_real_retry_in_skill_runner():
    counters: dict = {}
    tool_registry = make_oee_tool_registry(MOCK_EQUIPMENT, OEE_THRESHOLD)
    spy = _SpyCapabilityTool(tool_registry.get("query_oee_data"), counters, "query_oee_data")
    tool_registry._tools["query_oee_data"] = spy  # test-only substitution, not a public registry API

    skill_registry = make_oee_skill_registry()
    skill = skill_registry.get("oee.rca_screening")
    manager = ToolExecutionManager()
    runner = SkillRunner(tool_registry, manager)
    module_state = make_module_state()

    objective = Objective(
        objective_id="o1", description="screen", action=ObjectiveAction.EQUIPMENT_SCREENING,
        target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="screen_equipment"),
        expected_output="x", priority_score=1.0, attempt_count=1,
    )

    # same objective, run twice -- simulates a checkpoint replay of the
    # exact same logical call: physical execution must NOT repeat
    runner.run(skill, objective, module_state)
    runner.run(skill, objective, module_state)
    assert counters["query_oee_data"] == 1

    # a genuinely new attempt at the same objective_id (Planner incremented
    # attempt_count -- a real retry, not a replay) DOES execute again
    retry_objective = objective.model_copy(update={"attempt_count": 2})
    runner.run(skill, retry_objective, module_state)
    assert counters["query_oee_data"] == 2
