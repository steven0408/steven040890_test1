"""Phase 5B-3B: semantic AnalyzerDecision validation -- beyond pydantic
schema validation, catches an LLM hallucinating a module/TaskType
combination that doesn't actually exist for this run. Also proves the
router-retry-then-fallback wiring: a semantically-invalid LLM response is
treated exactly like any other LLMInvalidOutputError.
"""
import pytest

from agent.graph.nodes.analyzer_llm import AnalyzerSemanticValidationError, DecisionSource, validate_analyzer_decision
from agent.llm.models import LLMCallStatus
from agent.llm.prompts.analyzer import AnalyzerDecision, ModuleSelection
from agent.state.enums import TaskType
from agent.state.models import FactoryContext

from .conftest import make_agent_state, make_analyzer_llm_service, make_module_registry

_FACTORY = FactoryContext(factory_id="factory-a", factory_name="Factory A", enabled_modules=["OEE", "Output", "WIP"])


def _decision(**overrides) -> AnalyzerDecision:
    base = dict(
        task_type=TaskType.RCA,
        selected_modules=[ModuleSelection(module_type="OEE", priority=0.9, confidence=0.9, rationale="x")],
        reasoning_summary="x",
        confidence=0.9,
    )
    base.update(overrides)
    return AnalyzerDecision(**base)


def test_valid_decision_passes():
    validate_analyzer_decision(_decision(), module_registry=make_module_registry(), factory_context=_FACTORY)  # must not raise


def test_hallucinated_module_rejected():
    decision = _decision(selected_modules=[ModuleSelection(module_type="Quality", priority=0.9, confidence=0.9, rationale="x")])
    with pytest.raises(AnalyzerSemanticValidationError):
        validate_analyzer_decision(decision, module_registry=make_module_registry(), factory_context=_FACTORY)


def test_module_not_enabled_for_this_factory_rejected():
    factory = FactoryContext(factory_id="factory-b", factory_name="Factory B", enabled_modules=["Output", "WIP"])  # no OEE
    with pytest.raises(AnalyzerSemanticValidationError):
        validate_analyzer_decision(_decision(), module_registry=make_module_registry(), factory_context=factory)


def test_module_disabled_at_catalog_level_rejected():
    from agent.catalog.module_registry import ModuleDefinition, ModuleRegistry

    registry = ModuleRegistry()
    registry.register(
        ModuleDefinition(module_type="OEE", name="OEE", description="x", supported_task_types=[TaskType.RCA], enabled=False)
    )
    with pytest.raises(AnalyzerSemanticValidationError):
        validate_analyzer_decision(_decision(), module_registry=registry, factory_context=_FACTORY)


def test_unsupported_task_type_for_module_rejected():
    from agent.catalog.module_registry import ModuleDefinition, ModuleRegistry

    registry = ModuleRegistry()
    registry.register(
        ModuleDefinition(module_type="OEE", name="OEE", description="x", supported_task_types=[TaskType.INFORMATION])
    )
    decision = _decision(task_type=TaskType.RCA)  # OEE here doesn't support RCA
    with pytest.raises(AnalyzerSemanticValidationError):
        validate_analyzer_decision(decision, module_registry=registry, factory_context=_FACTORY)


def test_duplicate_selected_modules_rejected():
    decision = _decision(
        selected_modules=[
            ModuleSelection(module_type="OEE", priority=0.9, confidence=0.9, rationale="x"),
            ModuleSelection(module_type="OEE", priority=0.5, confidence=0.5, rationale="y"),
        ]
    )
    with pytest.raises(AnalyzerSemanticValidationError):
        validate_analyzer_decision(decision, module_registry=make_module_registry(), factory_context=_FACTORY)


def test_empty_selected_modules_rejected():
    decision = _decision(selected_modules=[])
    with pytest.raises(AnalyzerSemanticValidationError):
        validate_analyzer_decision(decision, module_registry=make_module_registry(), factory_context=_FACTORY)


@pytest.mark.parametrize("bad_confidence", [-0.1, 1.5])
def test_out_of_range_module_confidence_rejected(bad_confidence):
    decision = _decision(selected_modules=[ModuleSelection(module_type="OEE", priority=0.9, confidence=bad_confidence, rationale="x")])
    with pytest.raises(AnalyzerSemanticValidationError):
        validate_analyzer_decision(decision, module_registry=make_module_registry(), factory_context=_FACTORY)


@pytest.mark.parametrize("bad_priority", [-1.0, 2.0])
def test_out_of_range_module_priority_rejected(bad_priority):
    decision = _decision(selected_modules=[ModuleSelection(module_type="OEE", priority=bad_priority, confidence=0.9, rationale="x")])
    with pytest.raises(AnalyzerSemanticValidationError):
        validate_analyzer_decision(decision, module_registry=make_module_registry(), factory_context=_FACTORY)


def test_out_of_range_decision_confidence_rejected():
    decision = _decision(confidence=1.2)
    with pytest.raises(AnalyzerSemanticValidationError):
        validate_analyzer_decision(decision, module_registry=make_module_registry(), factory_context=_FACTORY)


# ============================================================================
# Router-level integration: semantically-invalid LLM response is retried,
# then triggers deterministic fallback once retries are exhausted -- routing
# never reaches Coordinator with an invalid decision.
# ============================================================================


def test_semantically_invalid_llm_decision_retries_then_falls_back():
    hallucinated = _decision(selected_modules=[ModuleSelection(module_type="Quality", priority=0.9, confidence=0.9, rationale="hallucinated")])
    service, usage_sink, client = make_analyzer_llm_service(lambda req: hallucinated, max_retries=1)

    outcome = service.decide(make_agent_state(raw_text="為什麼今天 OEE 下降？"))

    assert outcome.source == DecisionSource.FALLBACK
    assert outcome.fallback_reason is not None
    assert outcome.decision.task_type == TaskType.RCA
    assert {m.module_type for m in outcome.decision.selected_modules} == {"OEE", "Output", "WIP"}

    # the LLM was actually called each retry (client saw the hallucinated
    # response every time -- validation, not the client, is what failed)
    assert len(client.calls) == 2  # initial attempt + 1 retry
    records = usage_sink.list_for_run("run-1")
    assert [r.status for r in records] == [LLMCallStatus.INVALID_OUTPUT, LLMCallStatus.INVALID_OUTPUT]
