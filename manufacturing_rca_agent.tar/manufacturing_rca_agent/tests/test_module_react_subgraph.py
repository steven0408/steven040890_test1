from langgraph.checkpoint.memory import InMemorySaver

from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.planning.policies.mock import DeterministicMockPolicy, Requirement
from agent.state.enums import (
    ErrorType,
    EvidenceQuality,
    FindingStatus,
    ModuleStatus,
    ObjectiveStatus,
    ObservationStatus,
    ReflectorVerdict,
)
from agent.state.models import ModuleState, ModuleTask
from agent.tools.base import ToolResult
from agent.tools.mocks.scripted_tool import ScriptedMockTool

from .conftest import make_budget


def _run(policy, tool, budget=None, module_id="mod"):
    graph = build_module_react_subgraph(policy, tool)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id=module_id, module_type=module_id, reason="test", confidence=0.9, priority=0.9)
    initial = build_initial_module_state(
        task, budget or make_budget(max_steps=5, max_tool_calls=5, max_depth_per_entity=3), run_id="run-1"
    )
    config = {"configurable": {"thread_id": f"module-{module_id}"}}

    result = app.invoke(initial, config=config)
    final_state = ModuleState.model_validate(result)
    history = list(reversed(list(app.get_state_history(config))))
    return final_state, history


# --- Case 1: single-cycle success ------------------------------------------


def test_case1_single_cycle_success():
    policy = DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1)
    tool = ScriptedMockTool(
        {"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}
    )

    final_state, _ = _run(policy, tool, module_id="case1")

    assert final_state.status == ModuleStatus.COMPLETE
    assert len(final_state.observations) == 1
    assert len(final_state.evidence) == 1
    assert len(final_state.findings) == 1
    assert final_state.findings[0].status == FindingStatus.CONFIRMED
    assert final_state.reflection_history[-1].verdict == ReflectorVerdict.CANDIDATE_COMPLETE
    assert final_state.current_objective.objective_id == "case1-obj-1"

    record = final_state.objective_history["case1-obj-1"]
    assert record.status == ObjectiveStatus.COMPLETED  # closed out by Completion Check, not by tool SUCCESS
    assert record.termination_reason == "candidate_complete"
    assert record.created_step == 1
    assert record.completed_step == 1
    assert record.observation_ids == [final_state.observations[0].observation_id]
    assert record.evidence_ids == [final_state.evidence[0].evidence_id]


def test_case1_write_ownership_boundaries():
    """Planner is the only node that ever sets current_objective/current_plan;
    Executor never touches them; Reflector never creates one; only
    Completion Check flips module_state.status."""
    policy = DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1)
    tool = ScriptedMockTool(
        {"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.STRONG)}
    )

    _, history = _run(policy, tool, module_id="case1b")

    before_gate = next(s for s in history if s.next == ("execution_gate",))
    after_gate = next(s for s in history if s.next == ("module_executor",))
    assert before_gate.values["current_objective"] == after_gate.values["current_objective"]

    before_executor = after_gate
    after_executor = next(s for s in history if s.next == ("module_reflector",))
    assert before_executor.values["current_objective"] == after_executor.values["current_objective"]
    assert before_executor.values["current_plan"] == after_executor.values["current_plan"]

    before_reflector = after_executor
    after_reflector = next(s for s in history if s.next == ("module_completion_check",))
    assert before_reflector.values["current_objective"] == after_reflector.values["current_objective"]
    assert before_reflector.values["status"] == after_reflector.values["status"] == ModuleStatus.RUNNING

    terminal = history[-1]
    assert terminal.values["status"] == ModuleStatus.COMPLETE


# --- Case 2: multi-cycle ReAct -----------------------------------------------


def test_case2_multi_cycle_continue_then_complete():
    policy = DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=2)
    tool = ScriptedMockTool(
        {"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="partial", quality=EvidenceQuality.MODERATE)}
    )

    final_state, _ = _run(policy, tool, module_id="case2")

    assert final_state.status == ModuleStatus.COMPLETE
    assert len(final_state.observations) == 2
    assert len(final_state.evidence) == 2
    assert [r.verdict for r in final_state.reflection_history] == [
        ReflectorVerdict.CONTINUE,
        ReflectorVerdict.CANDIDATE_COMPLETE,
    ]
    # a Finding is recorded each round (HYPOTHESIS, then CONFIRMED) --
    # nothing is lost across rounds
    assert len(final_state.findings) == 2
    assert final_state.findings[0].status == FindingStatus.HYPOTHESIS
    assert final_state.findings[1].status == FindingStatus.CONFIRMED
    assert final_state.metrics.step_count == 2
    assert final_state.metrics.tool_call_count == 2
    # round 2 got a brand-new objective, not a mutated round-1 one
    assert final_state.current_objective.objective_id == "case2-obj-2"


# --- Case 3: DATA_NOT_FOUND + alternative path -------------------------------


def test_case3_data_not_found_then_alternative_source_succeeds():
    policy = DeterministicMockPolicy(sources=["primary", "alternative"], sufficiency_evidence_count=1)
    tool = ScriptedMockTool(
        {
            "primary": ToolResult(status=ObservationStatus.ERROR, error_type=ErrorType.DATA_NOT_FOUND, error_message="no rows"),
            "alternative": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.MODERATE),
        }
    )

    final_state, _ = _run(policy, tool, module_id="case3ok")

    assert final_state.status == ModuleStatus.COMPLETE
    assert [obs.status for obs in final_state.observations] == [ObservationStatus.ERROR, ObservationStatus.SUCCESS]
    assert [obs.tool_name for obs in final_state.observations] == ["mock_tool:primary", "mock_tool:alternative"]
    assert [r.verdict for r in final_state.reflection_history] == [
        ReflectorVerdict.RETRY,
        ReflectorVerdict.CANDIDATE_COMPLETE,
    ]
    assert final_state.metrics.retry_count == 1
    assert final_state.limitations == []  # never gave up -> nothing to record


def test_case3_primary_and_alternative_both_unavailable_writes_limitation_and_fails():
    policy = DeterministicMockPolicy(sources=["primary", "alternative"], sufficiency_evidence_count=1)
    tool = ScriptedMockTool(
        {
            "primary": ToolResult(status=ObservationStatus.ERROR, error_type=ErrorType.DATA_NOT_FOUND, error_message="no rows"),
            "alternative": ToolResult(status=ObservationStatus.ERROR, error_type=ErrorType.DATA_NOT_FOUND, error_message="no rows"),
        }
    )

    final_state, _ = _run(policy, tool, module_id="case3fail")

    # zero findings were ever gathered (both sources errored) -> FAILED, not
    # PARTIAL; Case 4 below tests the PARTIAL/FAILED split explicitly.
    assert final_state.status == ModuleStatus.FAILED
    assert final_state.findings == []
    assert len(final_state.limitations) == 1
    assert final_state.limitations[0].related_error.error_type == ErrorType.DATA_NOT_FOUND
    assert final_state.current_objective is None
    assert final_state.control.gate_decision is None or True  # no human path exercised at all


def test_case3_partial_when_earlier_requirement_already_has_a_finding():
    """Rule confirmed after Phase 3 review:
    - some valid Finding already exists, but a LATER requirement's sources
      are all DATA_NOT_FOUND -> PARTIAL
    - zero Finding ever, analysis cannot proceed at all -> FAILED (covered
      by test_case3_primary_and_alternative_both_unavailable_writes_limitation_and_fails)

    Mirrors: OEE decline confirmed -> Availability decline confirmed ->
    maintenance detail DATA_NOT_FOUND on both known sources -> exact failure
    mechanism cannot be verified -> PARTIAL.
    """
    policy = DeterministicMockPolicy(
        requirements=[
            Requirement(sources=["availability"], sufficiency_evidence_count=1),
            Requirement(sources=["maintenance-primary", "maintenance-alternative"], sufficiency_evidence_count=1),
        ]
    )
    tool = ScriptedMockTool(
        {
            "availability": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="availability decline confirmed", quality=EvidenceQuality.STRONG),
            "maintenance-primary": ToolResult(status=ObservationStatus.ERROR, error_type=ErrorType.DATA_NOT_FOUND, error_message="no rows"),
            "maintenance-alternative": ToolResult(status=ObservationStatus.ERROR, error_type=ErrorType.DATA_NOT_FOUND, error_message="no rows"),
        }
    )

    final_state, _ = _run(policy, tool, budget=make_budget(max_steps=6, max_tool_calls=6, max_depth_per_entity=3), module_id="case3partial")

    assert final_state.status == ModuleStatus.PARTIAL
    assert len(final_state.findings) == 1  # from the "availability" requirement's success
    assert final_state.findings[0].status == FindingStatus.HYPOTHESIS  # never promoted -- overall is_sufficient never became True
    assert [obs.status for obs in final_state.observations] == [
        ObservationStatus.SUCCESS,
        ObservationStatus.ERROR,
        ObservationStatus.ERROR,
    ]
    assert len(final_state.limitations) == 1
    assert final_state.limitations[0].related_error.error_type == ErrorType.DATA_NOT_FOUND
    # the satisfied requirement's objective is cleanly closed out too, not just abandoned
    availability_obj_id = "case3partial-obj-1"
    assert final_state.objective_history[availability_obj_id].status == ObjectiveStatus.COMPLETED
    assert final_state.objective_history[availability_obj_id].termination_reason == "continue_insufficient_evidence"
    assert len(final_state.objective_history) == 3  # availability + maintenance-primary + maintenance-alternative


# --- Case 4: no viable objective / budget termination ------------------------


def test_case4a_partial_when_findings_exist_but_budget_runs_out():
    # sufficiency is unreachable -> the module keeps re-querying the same
    # (always-successful) source until the budget cuts it off.
    policy = DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=999)
    tool = ScriptedMockTool(
        {"primary": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.WEAK)}
    )
    tight_budget = make_budget(max_steps=2, max_tool_calls=5, max_depth_per_entity=3)

    final_state, _ = _run(policy, tool, budget=tight_budget, module_id="case4a")

    assert final_state.status == ModuleStatus.PARTIAL
    assert final_state.budget.used_steps == 2
    assert len(final_state.evidence) == 2
    assert len(final_state.findings) == 2
    assert all(f.status == FindingStatus.HYPOTHESIS for f in final_state.findings)


def test_case4b_failed_when_no_findings_and_cannot_execute():
    policy = DeterministicMockPolicy(sources=["primary"], sufficiency_evidence_count=1)
    tool = ScriptedMockTool(
        {"primary": ToolResult(status=ObservationStatus.ERROR, error_type=ErrorType.DATA_NOT_FOUND, error_message="no rows")}
    )

    final_state, _ = _run(policy, tool, module_id="case4b")

    assert final_state.status == ModuleStatus.FAILED
    assert final_state.findings == []
    assert len(final_state.limitations) == 1


# --- Serialization sanity (mirrors Phase 1/2) --------------------------------


def test_final_module_state_round_trips_through_json():
    policy = DeterministicMockPolicy(sources=["primary", "alternative"], sufficiency_evidence_count=1)
    tool = ScriptedMockTool(
        {
            "primary": ToolResult(status=ObservationStatus.ERROR, error_type=ErrorType.DATA_NOT_FOUND, error_message="no rows"),
            "alternative": ToolResult(status=ObservationStatus.SUCCESS, payload_summary="ok", quality=EvidenceQuality.MODERATE),
        }
    )

    final_state, _ = _run(policy, tool, module_id="case-serialize")

    payload = final_state.model_dump_json()
    restored = ModuleState.model_validate_json(payload)
    assert restored == final_state
