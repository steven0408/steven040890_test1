"""Phase 5B-3A: AnalyzerLLMService -- LLM decision path, deterministic
fallback on failure, and the typed AnalyzerDecision output contract that
structurally forbids Skill/Tool/objective selection.
"""
import pytest
from pydantic import ValidationError

from agent.graph.nodes.analyzer_llm import DecisionSource, make_analyzer_llm_node
from agent.llm.models import LLMProviderError, LLMTimeoutError
from agent.llm.prompts.analyzer import AnalyzerDecision, ModuleSelection
from agent.state.enums import TaskType
from agent.state.models import Goal, GoalScope

from .conftest import make_agent_state, make_analyzer_llm_service


# ============================================================================
# AnalyzerDecision schema -- Analyzer cannot output Skill/Tool/objective/step
# ============================================================================


def test_analyzer_decision_schema_has_no_skill_or_tool_or_objective_fields():
    fields = set(AnalyzerDecision.model_fields.keys())
    assert fields == {"task_type", "selected_modules", "reasoning_summary", "confidence"}
    assert set(ModuleSelection.model_fields.keys()) == {"module_type", "priority", "confidence", "rationale"}


@pytest.mark.parametrize("forbidden_field", ["skill_id", "tool_id", "objectives", "steps"])
def test_analyzer_decision_rejects_skill_tool_objective_step_fields(forbidden_field):
    raw = {
        "task_type": "rca",
        "selected_modules": [{"module_type": "OEE", "priority": 0.9, "confidence": 0.9, "rationale": "x"}],
        "reasoning_summary": "x",
        "confidence": 0.9,
        forbidden_field: "should never be accepted",
    }
    with pytest.raises(ValidationError):
        AnalyzerDecision.model_validate(raw)


# ============================================================================
# LLM success path
# ============================================================================


def test_llm_success_returns_llm_sourced_decision():
    canned = AnalyzerDecision(
        task_type=TaskType.INFORMATION,
        selected_modules=[ModuleSelection(module_type="OEE", priority=0.9, confidence=0.9, rationale="OEE status requested.")],
        reasoning_summary="User asked for current OEE.",
        confidence=0.9,
    )
    service, usage_sink, _ = make_analyzer_llm_service(lambda req: canned)

    outcome = service.decide(make_agent_state(raw_text="今天平均 OEE 多少？"))

    assert outcome.source == DecisionSource.LLM
    assert outcome.fallback_reason is None
    assert outcome.decision == canned
    assert len(usage_sink.list_for_run("run-1")) == 1


# ============================================================================
# Fallback on LLM failure -- timeout / provider error / invalid output
# ============================================================================


@pytest.mark.parametrize(
    "responder",
    [
        lambda req: (_ for _ in ()).throw(LLMTimeoutError("simulated timeout")),
        lambda req: (_ for _ in ()).throw(LLMProviderError("simulated provider outage")),
        lambda req: {"task_type": "rca", "selected_modules": [], "reasoning_summary": "x", "confidence": 0.9, "skill_id": "should be rejected"},
    ],
    ids=["timeout", "provider_error", "invalid_output"],
)
def test_llm_failure_falls_back_to_deterministic_decision(responder):
    service, usage_sink, _ = make_analyzer_llm_service(responder, max_retries=0)

    outcome = service.decide(make_agent_state(raw_text="為什麼今天 OEE 下降？"))

    assert outcome.source == DecisionSource.FALLBACK
    assert outcome.fallback_reason is not None
    assert outcome.decision.task_type == TaskType.RCA  # deterministic inference on this raw_text
    assert {m.module_type for m in outcome.decision.selected_modules} == {"OEE", "Output", "WIP"}
    # the failed LLM attempt(s) are still audited
    assert len(usage_sink.list_for_run("run-1")) >= 1


def test_analyzer_node_applies_fallback_decision_to_agent_state():
    service, _, _ = make_analyzer_llm_service(lambda req: (_ for _ in ()).throw(LLMTimeoutError("x")), max_retries=0)
    node = make_analyzer_llm_node(service)

    # Standardizer normally seeds a provisional global_goal first -- simulate that here
    state = make_agent_state(raw_text="今天平均 OEE 多少？")
    state = state.model_copy(
        update={
            "global_goal": Goal(
                goal_id="g1", raw_statement=state.user_request.raw_text, normalized_statement=state.user_request.raw_text,
                task_type=TaskType.RCA, scope=GoalScope(),
            )
        }
    )

    updates = node(state)
    assert updates["global_goal"].task_type == TaskType.INFORMATION  # Analyzer's decision overwrites Standardizer's provisional guess
    assert {t.module_type for t in updates["selected_modules"]} == {"OEE", "Output", "WIP"}
    assert all(t.task_type == TaskType.INFORMATION for t in updates["selected_modules"])


# ============================================================================
# TaskType cases (item 13) -- driven entirely by scripted LLM responses, not
# hardcoded node/service logic
# ============================================================================


def _decision(task_type: TaskType, module_types: list[str]) -> AnalyzerDecision:
    return AnalyzerDecision(
        task_type=task_type,
        selected_modules=[
            ModuleSelection(module_type=m, priority=0.9 - 0.1 * i, confidence=0.85, rationale=f"{m} relevant for {task_type.value}.")
            for i, m in enumerate(module_types)
        ],
        reasoning_summary=f"Mock decision for {task_type.value}.",
        confidence=0.85,
    )


def test_information_single_module():
    service, _, _ = make_analyzer_llm_service(lambda req: _decision(TaskType.INFORMATION, ["OEE"]))
    outcome = service.decide(make_agent_state(raw_text="今天平均 OEE 多少？"))
    assert outcome.decision.task_type == TaskType.INFORMATION
    assert [m.module_type for m in outcome.decision.selected_modules] == ["OEE"]


def test_analysis_single_module():
    service, _, _ = make_analyzer_llm_service(lambda req: _decision(TaskType.ANALYSIS, ["OEE"]))
    outcome = service.decide(make_agent_state(raw_text="哪些設備 OEE 比較差？"))
    assert outcome.decision.task_type == TaskType.ANALYSIS
    assert [m.module_type for m in outcome.decision.selected_modules] == ["OEE"]


def test_rca_single_module():
    service, _, _ = make_analyzer_llm_service(lambda req: _decision(TaskType.RCA, ["OEE"]))
    outcome = service.decide(make_agent_state(raw_text="為什麼今天 OEE 下降？"))
    assert outcome.decision.task_type == TaskType.RCA
    assert [m.module_type for m in outcome.decision.selected_modules] == ["OEE"]


def test_rca_multi_module():
    service, _, _ = make_analyzer_llm_service(lambda req: _decision(TaskType.RCA, ["Output", "OEE", "WIP"]))
    outcome = service.decide(make_agent_state(raw_text="為什麼今天產出不足？"))
    assert outcome.decision.task_type == TaskType.RCA
    assert {m.module_type for m in outcome.decision.selected_modules} >= {"Output", "OEE", "WIP"}
