"""Phase 5A: OEEPlanningPolicy exercised through the unchanged Module ReAct
Subgraph (Planner/Gate/Executor/Reflector/Completion Check) -- same harness
as Phase 3, only the injected policy + tool are new.
"""
from langgraph.checkpoint.memory import InMemorySaver

from agent.domain.oee.dataset import MOCK_EQUIPMENT, OEE_THRESHOLD
from agent.graph.nodes.module.bootstrap import build_initial_module_state
from agent.graph.nodes.module.module_subgraph import build_module_react_subgraph
from agent.planning.policies.oee import OEEPlanningPolicy
from agent.state.enums import (
    BranchStatus,
    EntityAnalysisStatus,
    FindingStatus,
    ModuleStatus,
    ObjectiveStatus,
    ReflectorVerdict,
    TreeNodeStatus,
)
from agent.state.models import ModuleState, ModuleTask
from agent.tools.mocks.oee_data_tool import OEEDataTool

from .conftest import make_budget


def _run(tool, module_id="OEE", budget=None):
    policy = OEEPlanningPolicy()
    graph = build_module_react_subgraph(policy, tool)
    checkpointer = InMemorySaver()
    app = graph.compile(checkpointer=checkpointer)

    task = ModuleTask(module_id=module_id, module_type="OEE", reason="test", confidence=0.9, priority=0.9)
    initial = build_initial_module_state(
        task, budget or make_budget(max_steps=6, max_tool_calls=6, max_depth_per_entity=3), run_id="run-1"
    )
    config = {"configurable": {"thread_id": f"oee-{module_id}"}}

    result = app.invoke(initial, config=config)
    final_state = ModuleState.model_validate(result)
    history = list(reversed(list(app.get_state_history(config))))
    return final_state, history


# ============================================================================
# COMPLETE
# ============================================================================


def test_complete_deep_dives_top_two_availability_equipment_and_finds_shared_cause():
    tool = OEEDataTool(MOCK_EQUIPMENT, OEE_THRESHOLD)

    final_state, _ = _run(tool, module_id="oee-complete")

    assert final_state.status == ModuleStatus.COMPLETE

    # dynamic planning: exactly screen -> EQ001 -> EQ003, not a fixed 5-equipment sweep
    objective_ids = list(final_state.objective_history.keys())
    assert objective_ids == ["oee-complete-obj-1", "oee-complete-obj-2", "oee-complete-obj-3"]
    targets = [record.target_ref.ref_id for record in final_state.objective_history.values()]
    assert targets == ["screen_equipment", "equipment_detail:EQ001", "equipment_detail:EQ003"]
    assert all(r.status == ObjectiveStatus.COMPLETED for r in final_state.objective_history.values())

    # step-level reflection stayed step-level; the *last* verdict is the
    # completion trigger, Reflector never picked EQ003 itself
    assert [r.verdict for r in final_state.reflection_history] == [
        ReflectorVerdict.CONTINUE,
        ReflectorVerdict.CONTINUE,
        ReflectorVerdict.CANDIDATE_COMPLETE,
    ]

    # final finding: shared root cause across EQ001/EQ003
    final_finding = final_state.findings[-1]
    assert final_finding.status == FindingStatus.CONFIRMED
    assert final_finding.is_root_cause is True
    assert set(final_finding.entity_ids) == {"EQ001", "EQ003"}
    assert "Motor Failure" in final_finding.pattern

    # branches: all three patterns registered from screening alone, only
    # Availability marked ACTIVE (selected branch)
    assert set(final_state.branches) == {"branch-availability", "branch-performance", "branch-quality"}
    availability = final_state.branches["branch-availability"]
    assert availability.status == BranchStatus.ACTIVE
    assert set(availability.entity_ids) == {"EQ001", "EQ003", "EQ012"}
    assert final_state.branches["branch-performance"].status == BranchStatus.PENDING
    assert final_state.branches["branch-quality"].status == BranchStatus.PENDING
    # Availability's aggregate contribution beats the other two individually
    assert availability.priority_score > final_state.branches["branch-performance"].priority_score
    assert availability.priority_score > final_state.branches["branch-quality"].priority_score

    # entity depth/status: only the two deep-dived equipment go past SCREENED;
    # not all abnormal equipment were walked to root cause
    entities = final_state.entity_states
    assert entities["EQ001"].status == EntityAnalysisStatus.ROOT_CAUSE_FOUND
    assert entities["EQ003"].status == EntityAnalysisStatus.ROOT_CAUSE_FOUND
    assert entities["EQ012"].status == EntityAnalysisStatus.SCREENED  # same branch, lower contribution, never dived
    assert entities["EQ007"].status == EntityAnalysisStatus.SCREENED  # Performance branch, untouched
    assert entities["EQ009"].status == EntityAnalysisStatus.SCREENED  # Quality branch, untouched
    assert "EQ002" not in entities  # normal equipment never enters the analysis at all

    # analysis tree: EQ001/EQ003 collapsed under one shared-failure group node
    tree = final_state.analysis_tree
    group_node = tree.nodes["group-motor-failure"]
    assert group_node.status == TreeNodeStatus.COMPLETED
    assert set(group_node.children_ids) == {"eq-EQ001", "eq-EQ003"}
    assert tree.nodes["eq-EQ001"].parent_id == "group-motor-failure"
    assert tree.nodes["eq-EQ003"].parent_id == "group-motor-failure"
    # EQ012 stayed a plain leaf under the Availability branch, not grouped
    assert tree.nodes["eq-EQ012"].parent_id == "branch-availability-node"


# ============================================================================
# PARTIAL
# ============================================================================


def test_partial_when_availability_confirmed_but_downtime_detail_unavailable():
    tool = OEEDataTool(
        MOCK_EQUIPMENT,
        OEE_THRESHOLD,
        unavailable_targets=frozenset({"equipment_detail:EQ001", "equipment_detail:EQ003"}),
    )

    final_state, _ = _run(tool, module_id="oee-partial")

    assert final_state.status == ModuleStatus.PARTIAL

    # Availability pattern is confirmed as dominant (from screening) even
    # though the deep dive never resolved
    assert len(final_state.findings) == 1
    finding = final_state.findings[0]
    assert finding.status == FindingStatus.HYPOTHESIS
    assert "Availability" in finding.pattern
    assert set(finding.entity_ids) == {"EQ001", "EQ003", "EQ012"}
    assert finding.is_root_cause is False

    # both top-2 candidates were tried and both failed -- no fabricated root cause
    assert final_state.entity_states["EQ001"].status == EntityAnalysisStatus.INVESTIGATING
    assert final_state.entity_states["EQ003"].status == EntityAnalysisStatus.INVESTIGATING

    assert len(final_state.limitations) == 1
    assert "OEE" in final_state.limitations[0].description
    assert final_state.current_objective is None


# ============================================================================
# FAILED
# ============================================================================


def test_failed_when_screening_itself_is_unavailable():
    tool = OEEDataTool(MOCK_EQUIPMENT, OEE_THRESHOLD, unavailable_targets=frozenset({"screen_equipment"}))

    final_state, _ = _run(tool, module_id="oee-failed")

    assert final_state.status == ModuleStatus.FAILED
    assert final_state.findings == []
    assert final_state.branches == {}
    assert final_state.entity_states == {}
    assert len(final_state.limitations) == 1
    assert len(final_state.objective_history) == 1
    assert final_state.objective_history["oee-failed-obj-1"].status == ObjectiveStatus.COMPLETED
    assert final_state.objective_history["oee-failed-obj-1"].termination_reason == "observation_error_retry"


def test_final_states_round_trip_through_json():
    scenarios = [
        OEEDataTool(MOCK_EQUIPMENT, OEE_THRESHOLD),
        OEEDataTool(MOCK_EQUIPMENT, OEE_THRESHOLD, unavailable_targets=frozenset({"equipment_detail:EQ001", "equipment_detail:EQ003"})),
        OEEDataTool(MOCK_EQUIPMENT, OEE_THRESHOLD, unavailable_targets=frozenset({"screen_equipment"})),
    ]
    for i, tool in enumerate(scenarios):
        final_state, _ = _run(tool, module_id=f"oee-json-{i}")
        restored = ModuleState.model_validate_json(final_state.model_dump_json())
        assert restored == final_state
