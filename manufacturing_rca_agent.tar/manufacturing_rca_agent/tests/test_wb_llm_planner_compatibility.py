"""Phase WB-2C item 38/39 (J/K): LLMPlanningPolicy(baseline_policy=WBPlanningPolicy())
compatibility via MockLLMClient, and PlannerContext WB capability
visibility. Proves WB can use the generic LLM Planner infrastructure --
not exhaustive dynamic LLM behavior (no real provider). All offline.
"""
from agent.capability.resolver import CapabilityResolver
from agent.domain.wb.synthetic import GOLDEN_DATE
from agent.llm.client import MockLLMClient
from agent.llm.config import LLMRouteConfig
from agent.llm.context.capability_retriever import DeterministicCapabilityRetriever
from agent.llm.context.evidence_selector import DeterministicEvidenceSelector
from agent.llm.context.planner_context import PlannerContextBuilder
from agent.llm.prompts.planner import ObjectiveProposal, PlannerDecision, PlannerDecisionType
from agent.llm.router import LLMRouter
from agent.llm.usage import InMemoryLLMUsageSink
from agent.modules.wb.package import build_wb_module_package
from agent.planning.policies.llm import LLMPlanningPolicy
from agent.planning.policies.wb import WBPlanningPolicy, build_wb_initial_entity_states
from agent.skills.registry import SkillRegistry
from agent.state.enums import ObjectiveAction, TargetRefType, TaskType
from agent.state.models import TargetRef
from agent.state.scope import ObjectiveScope, ScopeFilter, ScopeOperator, TimeScope, TimeScopeKind
from agent.tools.registry import ToolRegistry

from .conftest import make_module_state


def _wb_skill_registry() -> SkillRegistry:
    package = build_wb_module_package()
    registry = SkillRegistry()
    for directory in package.skill_directories:
        registry.load_directory(directory)
    return registry


def _wb_tool_registry() -> ToolRegistry:
    package = build_wb_module_package()
    registry = ToolRegistry()
    package.tool_registrations(registry)
    return registry


def _make_wb_llm_planning_policy(responder):
    skill_registry = _wb_skill_registry()
    tool_registry = _wb_tool_registry()
    context_builder = PlannerContextBuilder(DeterministicEvidenceSelector(), DeterministicCapabilityRetriever(skill_registry))
    usage_sink = InMemoryLLMUsageSink()
    client = MockLLMClient(responder)
    router = LLMRouter(routes={"planner": LLMRouteConfig(route="planner", model="mock-planner-v1", max_retries=1)}, client=client, usage_sink=usage_sink)
    policy = LLMPlanningPolicy(WBPlanningPolicy(), context_builder, router, skill_registry)
    return policy, skill_registry, tool_registry, context_builder


# ============================================================================
# Item 38: LLMPlanningPolicy(baseline_policy=WBPlanningPolicy()) compatibility
# ============================================================================


def test_llm_planning_policy_dispatches_a_valid_wb_proposal():
    decision = PlannerDecision(
        decision=PlannerDecisionType.DISPATCH,
        next_objective=ObjectiveProposal(
            action=ObjectiveAction.ANALYZE, capability_key="wb.wip.hold_analysis",
            target_ref=TargetRef(ref_type=TargetRefType.ENTITY, ref_id="ASE03"),
            scope=ObjectiveScope(time=TimeScope(kind=TimeScopeKind.SNAPSHOT_DATE, date=GOLDEN_DATE), filters=[ScopeFilter(dimension="plant", operator=ScopeOperator.EQ, value="ASE03")]),
            description="ASE03 Hold status", expected_output="hold status",
        ),
        priority=0.9, rationale_summary="User asked about ASE03 Hold.",
    )
    policy, _, _, _ = _make_wb_llm_planning_policy(lambda req: decision)
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    module_state = module_state.model_copy(update={
        "goal": module_state.goal.model_copy(update={"task_type": TaskType.ANALYSIS}),
        "entity_states": build_wb_initial_entity_states(),
    })

    objective = policy.propose_next_objective(module_state)

    assert objective is not None
    assert objective.action == ObjectiveAction.ANALYZE
    assert objective.capability_key == "wb.wip.hold_analysis"
    assert objective.target_ref.ref_id == "ASE03"
    assert objective.scope.filters[0].value == "ASE03"


def test_llm_planning_policy_falls_back_to_wb_deterministic_baseline_on_llm_failure():
    from agent.llm.models import LLMTimeoutError

    def responder(req):
        raise LLMTimeoutError("simulated timeout")

    policy, _, _, _ = _make_wb_llm_planning_policy(responder)
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    module_state = module_state.model_copy(update={
        "goal": module_state.goal.model_copy(update={"statement": "2026-08-12 ASE01 OEE狀況", "task_type": TaskType.INFORMATION}),
    })

    objective = policy.propose_next_objective(module_state)

    assert objective is not None
    assert objective.capability_key == "wb.oee.plant_status"  # WBPlanningPolicy's own deterministic baseline answer


def test_llm_proposal_rejecting_an_invalid_capability_key_falls_back():
    """An LLM proposal naming a capability_key that doesn't resolve for
    this domain/task_type must fail semantic validation and fall back --
    never silently dispatched."""
    decision = PlannerDecision(
        decision=PlannerDecisionType.DISPATCH,
        next_objective=ObjectiveProposal(
            action=ObjectiveAction.ANALYZE, capability_key="oee.equipment_screening",  # wrong domain entirely
            target_ref=TargetRef(ref_type=TargetRefType.MODULE, ref_id="WB"),
            scope=None, description="x", expected_output="x",
        ),
        priority=0.9, rationale_summary="x",
    )
    policy, _, _, _ = _make_wb_llm_planning_policy(lambda req: decision)
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    module_state = module_state.model_copy(update={
        "goal": module_state.goal.model_copy(update={"statement": "2026-08-12 ASE01 OEE狀況", "task_type": TaskType.INFORMATION}),
    })

    objective = policy.propose_next_objective(module_state)

    assert objective is not None
    assert objective.capability_key == "wb.oee.plant_status"  # fell back to the deterministic baseline, not the bad proposal


# ============================================================================
# Item 39/17: PlannerContext WB capability visibility
# ============================================================================


def test_planner_context_relevant_capabilities_include_wb_capability_keys():
    skill_registry = _wb_skill_registry()
    retriever = DeterministicCapabilityRetriever(skill_registry)
    summaries = retriever.retrieve(module_type="WB", task_type=TaskType.ANALYSIS, action_hint=None, limit=10)

    capability_keys = {s.capability_key for s in summaries}
    assert "wb.wip.hold_analysis" in capability_keys
    assert "wb.oee.status_analysis" in capability_keys
    assert all(s.capability_key is not None for s in summaries)  # every WB skill declares one


def test_planner_context_information_and_analysis_are_disjoint_capability_sets():
    skill_registry = _wb_skill_registry()
    retriever = DeterministicCapabilityRetriever(skill_registry)
    information = {s.skill_id for s in retriever.retrieve(module_type="WB", task_type=TaskType.INFORMATION, action_hint=None, limit=10)}
    analysis = {s.skill_id for s in retriever.retrieve(module_type="WB", task_type=TaskType.ANALYSIS, action_hint=None, limit=10)}
    assert information.isdisjoint(analysis)
    assert len(information) == 5  # Phase WB-3A adds wb.issue_status_summary
    assert len(analysis) == 10  # Phase WB-3A adds wb.issue_trend_analysis; WB-3B adds 5 historical/cross-source skills


def test_planner_context_never_mixes_in_oee_equipment_skills_for_wb_module():
    skill_registry = _wb_skill_registry()  # only WB skills loaded -- OEE skills never registered here
    retriever = DeterministicCapabilityRetriever(skill_registry)
    summaries = retriever.retrieve(module_type="WB", task_type=TaskType.ANALYSIS, action_hint=None, limit=10)
    assert all(s.skill_id.startswith("wb.") for s in summaries)


def test_planner_context_builder_produces_typed_context_with_wb_capabilities():
    _, skill_registry, _, context_builder = _make_wb_llm_planning_policy(lambda req: None)
    module_state = make_module_state(module_id="WB", module_type="WB", run_id="run-1")
    module_state = module_state.model_copy(update={
        "goal": module_state.goal.model_copy(update={"task_type": TaskType.ANALYSIS}),
        "entity_states": build_wb_initial_entity_states(),
    })

    outcome = context_builder.build(module_state, run_id="run-1")

    assert outcome.context.goal.module_type == "WB"
    assert outcome.context.goal.task_type == TaskType.ANALYSIS
    capability_keys = {s.capability_key for s in outcome.context.relevant_capabilities}
    assert capability_keys  # non-empty -- WB capabilities are visible to the typed context
    assert all(key is not None for key in capability_keys)
